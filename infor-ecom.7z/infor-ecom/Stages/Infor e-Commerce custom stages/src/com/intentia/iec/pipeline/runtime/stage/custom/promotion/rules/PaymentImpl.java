package com.intentia.iec.pipeline.runtime.stage.custom.promotion.rules;

import java.util.List;
import java.util.Map;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

public class PaymentImpl implements Rules {

	private static final Logger LOG = Logger.getLogger(PaymentImpl.class);
	
	private static PaymentImpl instance = null;

	private PromotionRule promotionRule = null;

	private String promotionId;

	private Map<String, List<String>> promotionalItemsMap;

	private XMLRequestHelper xmlHelper = null;

	private String languageCode = null;

	protected PaymentImpl() {
		// Exists only to defeat instantiation.
	}

	public static PaymentImpl getInstance() {
		if (instance == null) {
			instance = new PaymentImpl();
		}
		return instance;
	}

	public PromotionRule getPromotionRule() {
		return promotionRule;
	}

	public void setPromotionId(String promotionId) {
		this.promotionId = promotionId;
	}

	public void setPromotionRule(PromotionRule promotionRule) {
		this.promotionRule = promotionRule;
	}

	public void setPromotionalItemsMap(Map<String, List<String>> promotionalItemsMap) {
		this.promotionalItemsMap = promotionalItemsMap;
	}

	public boolean evaluateOrder(XMLResultset resultSet, XMLRequestHelper xmlHelper)
			throws ResultsetException {
		LOG.debug("Inside PaymentImpl.evaluateOrder()");
		boolean isValid = false;
		try {
			this.xmlHelper = xmlHelper;

			PromotionRule promotionRule = this.promotionRule;
			String ruleField = promotionRule.getField();
			String operator = promotionRule.getOperator();

			List<String> ruleValueList = promotionRule.getValues();
			if (RulesConstant.METHOD.equals(ruleField)) {
				isValid = this.evaluateMethod(resultSet, ruleValueList,
						operator);
			} else if (RulesConstant.CREDIT_CARD_TYPE.equals(ruleField)) {
				isValid = this.evaluateCreditCardType(resultSet, ruleValueList,
						operator);
			}
		} catch (TransformerException e) {
			e.printStackTrace();
		}

		return isValid;
	}

	public boolean evaluateOrderLine(XMLIterator xmlOrderline,
			XMLRequestHelper xmlHelper) throws TransformerException,
			ResultsetException {
		LOG.debug("Inside PaymentImpl.evaluateOrderLine()");
		boolean isValid = false;
		return isValid;
	}

	private boolean evaluateMethod(XMLResultset resultSet,
			List<String> ruleValueList, String operator)
			throws TransformerException {
		LOG.debug("Inside PaymentImpl.evaluateMethod()");
		boolean isValid = false;
		try {
			String paymentMethodIdFromRequest = resultSet.getString(RulesConstant.REQ_PAYMENT_METHOD_ID);
        	for (String paymentMethodId : ruleValueList) {
        		if(paymentMethodIdFromRequest.equalsIgnoreCase(paymentMethodId)){
        			isValid = true;
        		}
        	}
        } catch (ResultsetException e) {
            String msg = "Could not get order lines";
            LOG.error("Error Inside PaymentImpl.evaluateMethod() - "+msg);
        }
		return isValid;
	}

	private boolean evaluateCreditCardType(XMLResultset resultSet, List<String> ruleValueList, String operator)
			throws TransformerException {
		LOG.debug("Inside PaymentImpl.evaluateCreditCardType()");
		boolean isValid = false;
		try {
			String creditCardTypeCodeIdFromRequest = resultSet.getString(RulesConstant.REQ_PAYMENT_METHOD_CODEID);
        	for (String creditCardTypeCodeId : ruleValueList) {
        		if(creditCardTypeCodeId.equalsIgnoreCase(creditCardTypeCodeIdFromRequest)){
        			isValid = true;
        		}
        	}
        } catch (ResultsetException e) {
            String msg = "Could not get order lines";
            LOG.error("Error Inside PaymentImpl.evaluateCreditCardType() - "+msg);
        }
		return isValid;
	}

}
