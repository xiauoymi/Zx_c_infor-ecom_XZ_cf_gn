/**
 * 
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc;

/**
 * @author 14092
 * 
 */
public class UpdateQuantity extends AbstractPipelineStage {
    private static final Logger log = Logger.getLogger(UpdateQuantity.class);

    private Connection conn;

    private PreparedStatement pstmt;

    /*
     * (non-Javadoc)
     * 
     * @see com.intentia.iec.pipeline.runtime.AbstractPipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
     */
    @Override
    public void execute(PipelineContext context) throws PipelineRuntimeException {
        // TODO Auto-generated method stub
        if (!(context.getResponse() instanceof XMLResultset)) {
            throw new PipelineRuntimeException("XML Request is invalid");
        }
        conn = (Connection) CustomStagesHelper.getConnection("esales.cursor");
        XMLResultset response = getPreviousOrderResponse(context);        
        updateSubmittedOrderLine(response);
        cleanUp();
    }

    private XMLResultset getPreviousOrderResponse(PipelineContext context) throws PipelineRuntimeException {
        try {
            XMLResultset response = (XMLResultset) context.getResponse();
            log.debug(response);
            response.moveFirst();
            return response;
        } catch (Exception e) {
            throw new PipelineRuntimeException("Error trying to retrieve response data in PipelineContext");
        }
    }

    private void updateSubmittedOrderLine(XMLResultset response) throws PipelineRuntimeException {
        // Loop through the orderlines and update them
        try {
            if(response == null || response.isEmpty()) {
                log.debug("Reponse XML from the previous pipeline stage is null or empty. Terminating UpdateQuantity stage....");
                return;
            }
            
            String sql;
            sql = "update SubmittedOrderLine set RemainingQuantity=?, DeliveredQuantity=? where [key] = ?";
            pstmt = conn.prepareStatement(sql);
            // GO THROUGH EACH ORDERLINE
            XMLIterator orderline = (XMLIterator) response.getResultset(ConstantsForSales.ORDERLINE);
            if ((orderline == null) || orderline.isEmpty()) {
                log.debug("The sub resultset orderlines is null or empty: resultset is null = " + (orderline == null)
                        + " or resultset is empty = " + orderline.isEmpty());
                return;
            }
            orderline.beforeFirst();
            while (orderline.moveNext()) {
                updateSubmittedOrderLine2(pstmt, orderline);
            }
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Error executing updateSubmittedOrderHeader function", e);
        } catch (SQLException e) {
            throw new PipelineRuntimeException("Error executing updateSubmittedOrderHeader function", e);
        } finally {
            try {
                pstmt.close();
                pstmt = null;
            } catch (Exception e) {
            }
        }
    }

    private void updateSubmittedOrderLine2(PreparedStatement pstmt, XMLIterator orderline)
            throws PipelineRuntimeException {
        try {
            // GET VALUES FROM XML
            BigDecimal RemainingQuantity = orderline.getDecimal(ConstantsForSales.REMAININGQUANTITY);
            BigDecimal DeliveredQuantity = orderline.getDecimal(ConstantsForSales.DELIVEREDQUANTITY);
            String OrderLineID = orderline.getString(ConstantsForSales.ORDERLINEID);

            log.debug("Remaining Quantity:" + RemainingQuantity);
            log.debug("Delivered Quantity:" + DeliveredQuantity);
            log.debug("OrderLineID:" + OrderLineID);

            // SET PREPAREDSTATEMENT PARAMETERS
            pstmt.setBigDecimal(1, RemainingQuantity);
            pstmt.setBigDecimal(2, DeliveredQuantity);
            pstmt.setString(3, OrderLineID);

            pstmt.executeUpdate();
            pstmt.clearParameters();
        } catch (Exception e) {
            throw new PipelineRuntimeException("Problems updating SubmittedOrderLine", e);
        }
    }

    private void cleanUp() {
        try {
            conn.close();
            conn = null;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
