package com.intentia.iec.pipeline.runtime.stage.custom;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;

public class SaveOrderFileItems {

    private static final Logger LOG = Logger.getLogger(SaveOrderFileItems.class);

    private Connection conn = null;

    StringBuffer sqlOrderFileItemInsert = new StringBuffer(
            "INSERT INTO [OrderFileItem]([fileID],[rowNumber],[itemID],[suppliedQty])");

    public void appendOrderFileSQL(int pFileID, int pRowNumber, String pItemID, double pOrderQuanity) {

        String xItemID = pItemID.replace("\'", "\''");

        String orderfile = "\n SELECT " + pFileID + ", " + pRowNumber + ", '" + xItemID + "', " + pOrderQuanity;

        sqlOrderFileItemInsert.append(orderfile);
    }

    public void appendUnionAll() {

        String unionAll = "\n UNION ALL";

        sqlOrderFileItemInsert.append(unionAll);
    }

    public int execute() {

        int results = 0;

        try {
            initSQLConnection();
            Statement stmt = conn.createStatement();
            LOG.debug(sqlOrderFileItemInsert.toString());
            results = stmt.executeUpdate(sqlOrderFileItemInsert.toString());

        } catch (PipelineRuntimeException e) {
            throw new PipelineRuntimeException(e);
        } catch (SQLException e) {
            final String msg = "Error executing Order File Insert";
            throw new PipelineRuntimeException(e);
        } finally {
            closeSQLConnection();
            return results;
        }
    }

    // Create/Get MS SQL Connection
    private void initSQLConnection() throws PipelineRuntimeException {

        conn = (Connection) CustomStagesHelper.getConnection("esales.cursor");

        if (!(conn instanceof Connection)) {
            LOG.error("Error on establishing database connection");
        } else {
            LOG.debug("Succesfully created SQL Connection!");
        }

    }

    // Destroy/Close MS SQL Connection
    private void closeSQLConnection() {

        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                LOG.error("error closing connnection", e);
            }
        }

    }
}
