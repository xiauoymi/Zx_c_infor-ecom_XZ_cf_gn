/*
 * Created on 22-04-2006
 */
package com.intentia.iec.pipeline.runtime.custom.pim;

import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

/**
 * Utility class used for reading the delta publication specific processing
 * instruction: <tt>&lt;?delta version="1.0"?&gt;</tt>. The processing
 * instruction is important for determining the delta format version number,
 * which is useable when reading the delta publication
 * 
 * @author PEDJES0
 * 
 */
public final class ProcessingInstruction {

    private ProcessingInstruction() {
    }

    /**
     * This method reads through the processing instructions until the
     * processing instruction named 'delta' is reached. The method returns the
     * value of the processing instruction version.<br/><tt>
     * &lt;?delta version="1.0"?&gt;
     * </tt>
     * 
     * @param parser
     *            XMLStreamReader containing the XML version.
     * @return
     * @throws XMLStreamException
     * @throws CatalogParserException
     *             In case the delta processing instruction is missing or not as
     *             expected.
     */
    public static String readDeltaVersion(final XMLStreamReader parser) throws XMLStreamException,
            CatalogParserException {
        while (parser.hasNext()) {
            int event = parser.next();
            if (event == XMLStreamConstants.PROCESSING_INSTRUCTION && "delta".equals(parser.getPITarget())) {
                // validate PIData
                String piData = parser.getPIData();
                if (!piData.startsWith("version=")) {
                    throw new CatalogParserException(
                            "Invalid 'delta' processing instruction. Version were missing or not defined correctly: "
                                    + piData);
                }
                String result = piData.substring(9, piData.length() - 1);
                return result;
            } else if (event == XMLStreamConstants.START_ELEMENT) {
                throw new CatalogParserException(
                        "Invalid catalog delta XML document. 'delta' processing instruction is missing.");
            }
        }
        throw new CatalogParserException(
                "Invalid catalog delta XML document. 'delta' processing instruction is missing.");
    }
}
