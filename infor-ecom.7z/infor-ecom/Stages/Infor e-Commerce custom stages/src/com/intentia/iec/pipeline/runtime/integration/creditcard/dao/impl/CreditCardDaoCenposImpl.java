package com.intentia.iec.pipeline.runtime.integration.creditcard.dao.impl;

import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Service;
import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.PortInfo;

import org.apache.log4j.Logger;
import org.datacontract.schemas._2004._07.acriter_abi_cenpos_epayment_virtualterminal_v5.ProcessCreditCardRequest;
import org.datacontract.schemas._2004._07.acriter_abi_cenpos_epayment_virtualterminal_v5.ProcessCreditCardResponse;
import org.datacontract.schemas._2004._07.acriter_abi_cenpos_epayment_virtualterminal_v5.ProcessRecurringSaleRequest;
import org.tempuri.Transactional;
import org.tempuri.TransactionalWebService;
import org.tempuri.ProcessCreditCard;

import com.intentia.iec.pipeline.runtime.integration.creditcard.dao.CreditCardDao;
import com.intentia.iec.pipeline.runtime.integration.creditcard.dao.factory.WebserviceDaoFactory;
import com.intentia.iec.pipeline.runtime.integration.creditcard.exception.CreditCardConnectionException;
import com.intentia.iec.pipeline.runtime.integration.creditcard.exception.CreditCardException;
import com.intentia.iec.pipeline.runtime.integration.creditcard.model.CreditCard;
import com.intentia.iec.pipeline.runtime.integration.creditcard.model.Payment;
import com.intentia.iec.pipeline.runtime.integration.creditcard.model.TransactionResult;
import com.intentia.iec.pipeline.runtime.integration.creditcard.utils.CreditCardHelper;
import com.intentia.iec.pipeline.runtime.integration.creditcard.utils.SOAPLoggingHandler;

public class CreditCardDaoCenposImpl implements CreditCardDao {
	
	private static final Logger LOG = Logger.getLogger(CreditCardDaoCenposImpl.class);

	@Override
	public TransactionResult authorize(CreditCard creditCard, Payment payment) throws CreditCardConnectionException, CreditCardException {
		
		Transactional transactionalPort;
		ProcessRecurringSaleRequest wsRequest;
		
		try {
			transactionalPort = getTransactionalPort();
		} catch (MalformedURLException e) {
			throw new CreditCardConnectionException(e.toString());
		}
		
		//declare our model response objects
		TransactionResult outTransaction = new TransactionResult();
		
		try {
			wsRequest =  createAuthorizeRequestParams(creditCard, payment);	
		} catch (CreditCardException e) {
			throw new CreditCardException(e.toString());
		}

		//Set BindingProvider
		try {
			CreditCardHelper.setBindingProvider((BindingProvider)transactionalPort, new URL(WebserviceDaoFactory.WSDL_ENDPOINT_CREDITCARD));
		} catch(MalformedURLException e){
			throw new CreditCardConnectionException(e.toString()); 
		}
		
		//get the Cenpos response object
		ProcessCreditCardResponse wsResponse = transactionalPort.processCreditCard(wsRequest);
		LOG.debug("Web service call made...");

		//map the cenpos response object to our model response object
		if (wsResponse != null) {
			outTransaction.setRequestedAmount(wsResponse.getOriginalAmount());
			outTransaction.setAuthorizationNumber(wsResponse.getAutorizationNumber().getValue());
			outTransaction.setSuccessful(wsResponse.getResult()==0?true:false);
			outTransaction.setActualAuthorizedAmount(wsResponse.getAmount());
			outTransaction.setReferenceNumber(wsResponse.getReferenceNumber().getValue());
			outTransaction.setResponseCode(wsResponse.getResult().toString());
			outTransaction.setResponseMessage(wsResponse.getMessage().getValue());
			if (wsResponse.getResult() != 0) {
				LOG.error("Authorization was unsuccessful:");
				LOG.error("Result code: " + wsResponse.getResult());
				LOG.error("Message: " + wsResponse.getMessage().getValue());
			}
		} else {
			//outTransaction.setHasWSCallError(true);
			//outTransaction.setMsgCodeError("Code error null");
			//outTransaction.setMsgError("WSResponse is null");		
		}
		return outTransaction;
	}

	@Override
	public TransactionResult cancelAuthorize(TransactionResult transaction, CreditCard creditCard)
			throws CreditCardConnectionException {

		Transactional transactionalPort;
		try {
			transactionalPort = getTransactionalPort();
		} catch (MalformedURLException e) {
			throw new CreditCardConnectionException(e.toString());
		}
		
		//declare our model response objects
		TransactionResult outTransaction = new TransactionResult();
		ProcessCreditCardRequest wsRequest =  createCancelAuthorizeRequestParams(transaction, creditCard);		

		//Set BindingProvider
		try {
			CreditCardHelper.setBindingProvider((BindingProvider)transactionalPort, new URL(WebserviceDaoFactory.WSDL_ENDPOINT_CREDITCARD));
		} catch(MalformedURLException e){
			throw new CreditCardConnectionException(e.toString()); 
		}
		
		//get the Cenpos response object
		ProcessCreditCardResponse wsResponse = transactionalPort.processCreditCard(wsRequest);
		LOG.debug("Web service call made...");

		//map the cenpos response object to our model response object
		if (wsResponse != null) {
			outTransaction.setRequestedAmount(wsResponse.getOriginalAmount());
			outTransaction.setAuthorizationNumber(wsResponse.getAutorizationNumber().getValue());
			outTransaction.setSuccessful(wsResponse.getResult()==0?true:false);
			outTransaction.setActualAuthorizedAmount(wsResponse.getAmount());
			outTransaction.setReferenceNumber(wsResponse.getReferenceNumber().getValue());
			outTransaction.setResponseCode(wsResponse.getResult().toString());
			outTransaction.setResponseMessage(wsResponse.getMessage().getValue());
			if (wsResponse.getResult() != 0) {
				LOG.error("Authorization was unsuccessful:");
				LOG.error("Result code: " + wsResponse.getResult());
				LOG.error("Message: " + wsResponse.getMessage().getValue());
			}
		} else {
			//outTransaction.setHasWSCallError(true);
			//outTransaction.setMsgCodeError("Code error null");
			//outTransaction.setMsgError("WSResponse is null");		
		}
		return outTransaction;
	}
	
	private ProcessCreditCardRequest createCancelAuthorizeRequestParams(
			TransactionResult transaction, CreditCard creditCard) {
		org.datacontract.schemas._2004._07.acriter_abi_cenpos_epayment_virtualterminal.ObjectFactory merchantObjectFactory = new org.datacontract.schemas._2004._07.acriter_abi_cenpos_epayment_virtualterminal.ObjectFactory();
		JAXBElement<String> userID = merchantObjectFactory.createVirtualTerminalWebServiceRequestUserId(WebserviceDaoFactory.CREDITCARD_USER_ID);
		JAXBElement<String> password = merchantObjectFactory.createVirtualTerminalWebServiceRequestPassword(WebserviceDaoFactory.CREDITCARD_PASSWORD);
		
		org.datacontract.schemas._2004._07.acriter_abi_cenpos_epayment_virtualterminal_v5.ObjectFactory cardObjectFactory = new org.datacontract.schemas._2004._07.acriter_abi_cenpos_epayment_virtualterminal_v5.ObjectFactory();
		JAXBElement<String> refNum = cardObjectFactory.createProcessCardRequestReferenceNumber(transaction.getReferenceNumber());
		JAXBElement<String> authNum = cardObjectFactory.createProcessCardRequestAuthorizationNumber(transaction.getAuthorizationNumber());
		JAXBElement<String> lastDigits = cardObjectFactory.createProcessCardRequestCardLastFourDigits(creditCard.getLastDigits());
		JAXBElement<String> transType = cardObjectFactory.createProcessCardRequestTransactionType("Void");

		ProcessCreditCardRequest wsRequest = cardObjectFactory.createProcessCreditCardRequest();

		wsRequest.setMerchantId(new Integer(WebserviceDaoFactory.CREDITCARD_MERCHANT_ID));
		wsRequest.setPassword(password);
		wsRequest.setUserId(userID);
		wsRequest.setAmount(transaction.getAmount());
		wsRequest.setAuthorizationNumber(authNum);
		wsRequest.setCardLastFourDigits(lastDigits);
		wsRequest.setReferenceNumber(refNum);
		wsRequest.setTaxAmount(new BigDecimal(0));
		wsRequest.setTransactionType(transType);

		return wsRequest;	
	}

	private ProcessRecurringSaleRequest createAuthorizeRequestParams(CreditCard creditCard, Payment payment) throws CreditCardException{
		
		QName _ProcessRecurringSaleRequestRecurringSaleTokenId_QNAME = new QName("http://schemas.datacontract.org/2004/07/Acriter.ABI.CenPOS.EPayment.VirtualTerminal.v5.Common", "RecurringSaleTokenId");
		QName _ProcessCreditCardRequestNameOnCard_QNAME = new QName("http://schemas.datacontract.org/2004/07/Acriter.ABI.CenPOS.EPayment.VirtualTerminal.v5.Common", "NameOnCard");
		QName _ProcessDebitCardRequestTransactionType_QNAME = new QName("http://schemas.datacontract.org/2004/07/Acriter.ABI.CenPOS.EPayment.VirtualTerminal.v5.Common", "TransactionType");
		
		org.datacontract.schemas._2004._07.acriter_abi_cenpos_epayment_virtualterminal.ObjectFactory merchantObjectFactory = new org.datacontract.schemas._2004._07.acriter_abi_cenpos_epayment_virtualterminal.ObjectFactory();
		JAXBElement<String> userID = merchantObjectFactory.createVirtualTerminalWebServiceRequestUserId(WebserviceDaoFactory.CREDITCARD_USER_ID);
		JAXBElement<String> password = merchantObjectFactory.createVirtualTerminalWebServiceRequestPassword(WebserviceDaoFactory.CREDITCARD_PASSWORD);
		
		org.datacontract.schemas._2004._07.acriter_abi_cenpos_epayment_virtualterminal_v5.ObjectFactory cardObjectFactory = new org.datacontract.schemas._2004._07.acriter_abi_cenpos_epayment_virtualterminal_v5.ObjectFactory();
		JAXBElement<String> token = new JAXBElement<String>(_ProcessRecurringSaleRequestRecurringSaleTokenId_QNAME, String.class, ProcessRecurringSaleRequest.class, creditCard.getToken());
		JAXBElement<String> nameOnCard = new JAXBElement<String>(_ProcessCreditCardRequestNameOnCard_QNAME, String.class, ProcessCreditCardRequest.class, creditCard.getNameOnCard());
		JAXBElement<String> transType = new JAXBElement<String>(_ProcessDebitCardRequestTransactionType_QNAME, String.class, org.datacontract.schemas._2004._07.acriter_abi_cenpos_epayment_virtualterminal_v5.ProcessCardRequest.class, "RecurringAuth");

		ProcessRecurringSaleRequest wsRequest = new ProcessRecurringSaleRequest();
		LOG.debug("is CVV required: " + CreditCardHelper.isCvvRequired());
		if (CreditCardHelper.isCvvRequired()) {
			if (creditCard.getCvvNumber() != null)
			{
				QName _ProcessCreditCardRequestCardVerificationNumber_QNAME = new QName("http://schemas.datacontract.org/2004/07/Acriter.ABI.CenPOS.EPayment.VirtualTerminal.v5.Common", "CardVerificationNumber");
				JAXBElement<String> cvvNum = new JAXBElement<String>(_ProcessCreditCardRequestCardVerificationNumber_QNAME, String.class, ProcessCreditCardRequest.class, creditCard.getCvvNumber());
				wsRequest.setCardVerificationNumber(cvvNum);
			} else {
				throw new CreditCardException("CVV required but not found.");
			}
		}
		
		wsRequest.setMerchantId(new Integer(WebserviceDaoFactory.CREDITCARD_MERCHANT_ID));
		wsRequest.setPassword(password);
		wsRequest.setUserId(userID);
		wsRequest.setAmount(payment.getAmount());
		wsRequest.setNameOnCard(nameOnCard);
		wsRequest.setTaxAmount(new BigDecimal(0));
		wsRequest.setTransactionType(transType);
		wsRequest.setRecurringSaleTokenId(token);

		return wsRequest;		
	} 
	
	private Transactional getTransactionalPort() throws MalformedURLException{
		//initialize Transactional Serivce
		LOG.debug("CreditCard CenPOS initialize service: " + WebserviceDaoFactory.WSDL_URL_CREDITCARD);
		URL url_wsdl = new URL(WebserviceDaoFactory.WSDL_URL_CREDITCARD);
		QName qname = new QName("http://tempuri.org/", "TransactionalWebService");
		TransactionalWebService service = new TransactionalWebService(url_wsdl, qname);
		setSOAPLoggingHandler(service);
		Transactional transactionalPort = service.getPort(Transactional.class);
		return transactionalPort;
	}
	
	private void setSOAPLoggingHandler(Service service){
		service.setHandlerResolver(new HandlerResolver(){
			@Override
			public List<Handler> getHandlerChain(PortInfo portInfo) {
				List<Handler> handlerChain = new ArrayList<Handler>();
				handlerChain.add(new SOAPLoggingHandler());
				return handlerChain;
			}

		});
	}

}

