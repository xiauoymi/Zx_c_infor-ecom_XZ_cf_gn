/*
 * Created on 22-11-2004
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import org.apache.log4j.Logger;
import org.w3c.dom.Node;

import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.utils.RandomGUID;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

/**
 * This e-Sales custom stage is used to generate a unique Activation Code
 * whenever a user subscribes for a Newsletter.
 * 
 * 
 * The stage will create a random GUID, which it will set in the request for use
 * in the following stages for inserting into the database.
 * 
 * @author xinc0076
 */
public class GenerateActivationCode extends AbstractPipelineStage {

    private static final Logger LOG = Logger.getLogger(GenerateActivationCode.class);

    /**
     * Name of the Activation code attribute, which should be available in the
     * request.
     */
    public static final String ACTIVATION_CODE = "ActivationCode";

    // Local variables
    private XMLRequest request = null;

    /**
     * 
     */
    public GenerateActivationCode() {
        super();
    }

    public final void execute(final PipelineContext context) throws PipelineRuntimeException {

        request = (XMLRequest) context.getRequest();

        try {
            XMLRequest.extractRequestParameters(request);
            request.getParameters();

            // Generate a GUID to use as activation code.
            RandomGUID guid = new RandomGUID();
            String activationCode = guid.toString();
            if (LOG.isDebugEnabled()) {
                LOG.debug("Generated the Activation Code '" + activationCode);
            }

            // replace the value for the ActivationCode attribute
            Node node = XMLRequestHelper.getRequestNode(request, "request/entities/entity/attributes/attribute[@name='"
                    + ACTIVATION_CODE + "']/text()");
            node.setNodeValue(activationCode);

        } catch (RequestException e) {
            throw new PipelineRuntimeException(e);
        }

    }

}