package com.intentia.iec.pipeline.runtime.stage.custom.lucene.manager;

import java.util.Map;

import org.apache.lucene.document.Document;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.lucene.utils.IndexManagerUtil;

public class ResultsetDocumentHandler extends DefaultHandler {

    private static String RESULTSET_TAG = "resultset";

    private static String ROW_TAG = "row";

    private static String OBJECT_ATTRIB = "object";

    private static String SEPARATOR = "_";

    private String _objectName = null;

    private String _objectAlias = null;

    private IndexManager _indexManager = null;

    private String _keyAttrbiuteName = null;

    private String _keyAttrbiuteValue = null;

    private String _languageIDAttributeName = ConstantsForSales.LANGUAGE_ID_ATTRIBUTE;

    private Map<String, Document> _docMap = null;

    private Document _doc = null;

    private boolean _byDocMap;

    public ResultsetDocumentHandler(Map<String, Document> docMap, IndexManager manager, String keyAttribute) {
        this._docMap = docMap;
        this._indexManager = manager;
        this._keyAttrbiuteName = keyAttribute;
        this._byDocMap = true;
    }

    public ResultsetDocumentHandler(Document doc, IndexManager manager, String keyAttribute) {
        this._doc = doc;
        this._indexManager = manager;
        this._keyAttrbiuteName = keyAttribute;
        this._byDocMap = false;
    }

    public void startElement(String namespace, String localName, String qName, Attributes attributes) {
        String prefix = null;
        if (localName.equalsIgnoreCase(RESULTSET_TAG)) {
            if (_objectAlias != null)
                _objectName = _objectAlias;
            else
                _objectName = attributes.getValue(OBJECT_ATTRIB);
        } else {
            if (localName.equalsIgnoreCase(ROW_TAG)) {
                prefix = _objectName + SEPARATOR;
                if (_byDocMap) {
                    _doc = new Document();
                    _keyAttrbiuteValue = attributes.getValue(_keyAttrbiuteName);
                    IndexManagerUtil.addKeyField(_doc, _keyAttrbiuteValue);
                }
            } else {
                prefix = _objectName + SEPARATOR + localName + SEPARATOR;
                if (_byDocMap && _keyAttrbiuteValue != null)
                    _doc = _docMap.get(_keyAttrbiuteValue);
            }

            if (_doc != null) {
                String languageID = attributes.getValue(_languageIDAttributeName);
                for (int i = 0; i < attributes.getLength(); i++) {
                    String name = attributes.getLocalName(i);
                    String value = attributes.getValue(i);

                    IndexManagerUtil.addIndexField(_doc, _indexManager, prefix + name, value, languageID);
                }
                if (_byDocMap)
                    _docMap.put(_keyAttrbiuteValue, _doc);
            }
        }
        // TODO: Test on multiple cascading <subsets>
    }

    public void setLanguageIDAttributeName(final String name) {
        _languageIDAttributeName = name;
    }

    public void setObjectAlias(final String alias) {
        _objectAlias = alias;
    }
}