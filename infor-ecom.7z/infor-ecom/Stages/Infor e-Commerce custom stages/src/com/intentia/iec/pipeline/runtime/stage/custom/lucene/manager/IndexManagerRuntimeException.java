package com.intentia.iec.pipeline.runtime.stage.custom.lucene.manager;

/**
 * 
 * @author 15062
 * 
 */
public class IndexManagerRuntimeException extends RuntimeException {

    private static final long serialVersionUID = 7076097884377976161L;

    public IndexManagerRuntimeException(String message) {
        super(message);
    }

    public IndexManagerRuntimeException(String message, Throwable cause) {
        super(message, cause);
    }

    public IndexManagerRuntimeException(Throwable cause) {
        super(cause);
    }
}
