package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.Decimal;

public class IsNetPriceExist implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(IsNetPriceExist.class);

    private static String List_Price = "ListPrice";

    private static String Net_Price = "ResellPrice";

    private static String Promotion_Price = "PromotionPrice";

    public IsNetPriceExist() {
        super();
    }

    public void execute(PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("Inside IsNetPriceExist.execute()......");

        if (!(context.getResponse() instanceof XMLResultset)) {
            throw new PipelineRuntimeException("Contained response object MUST be of type 'XMLResultset'!");
        }

        XMLResultset response = (XMLResultset) context.getResponse();

        try {
            // loop over <item>
            response.beforeFirst();
            while (response.moveNext()) {
                BigDecimal listPrice = response.getDecimal(List_Price);
                BigDecimal netPrice = response.getDecimal(Net_Price);

                if ("true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.PROMOTIONS))) {

                    BigDecimal promotionPrice = response.getDecimal(Promotion_Price);

                    System.out.println("list Price = " + listPrice + " ,netPrice = " + netPrice + "promotionprice="
                            + promotionPrice);

                    if ((promotionPrice != null && promotionPrice.doubleValue() > 0)
                            && (listPrice.compareTo(promotionPrice) > 0) && (netPrice.compareTo(promotionPrice) >= 0)) {
                        LOG.debug("promotionPrice is the least= " + promotionPrice.toPlainString());
                        response.setString(List_Price, Decimal.toString(promotionPrice));

                    }

                    if ((netPrice != null && netPrice.doubleValue() > 0)
                            && (listPrice != null && listPrice.compareTo(netPrice) > 0)
                            && (promotionPrice != null && promotionPrice.compareTo(netPrice) >= 0)) {
                        LOG.debug("netPrice is the least= " + netPrice.toPlainString());
                        response.setString(List_Price, Decimal.toString(netPrice));
                    }
                } else {
                    if (netPrice != null && netPrice.doubleValue() > 0 && listPrice.compareTo(netPrice) > 0) {
                        LOG.debug("netPrice is trhe least(Promotions disabled)= " + netPrice.toPlainString());
                        response.setString(List_Price, Decimal.toString(netPrice));

                    }
                }

            }// end of while(xmlItem.moveNext())
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Failed to get values from result set!", e);
        }

    }

}
