package com.intentia.iec.pipeline.runtime.stage.custom.daf.drawing;


import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.intentia.icp.common.SearchArgument;

/**
 * Class that parses the request object from e-Sales.
 *
 */
public class DafDrawingRequestSaxHandler extends DefaultHandler {
	private String itemNumber = null;
	
	private String itemNumberOp = null;
	
	private String printNumber = null;
	
	private String printNumberOp = null;
	
	private String name = null;
	
	private String nameOp = null;
	
	private String serialNumber = null;
	
	private String serialNumberOp = null;
	
	private int resultSize = 0;
	
	private int startIndex = 0;
	
    private boolean inParam = false;
    
    private boolean inSubset = false;

    private String param = null;
    
    private String sortingField = null;
    
    private String sortingDirection = null;
    
    private String key = null;
    
    private String attributeName = null;
    
    private String attributePrintNumber = null;
    
    private String attributeIsDefault = null;
    
    private String attributeItemNumber = null;
    
    private String attributeSerialNumber = null;
    
    private String attributeImageMaster = null;
    
    private String status = null;

    private StringBuilder chars = new StringBuilder();
    
    private List<HotSpot> hotspots = new ArrayList<HotSpot>();

    /* (non-Javadoc)
     * @see org.xml.sax.helpers.DefaultHandler#startElement(java.lang.String, java.lang.String, java.lang.String, org.xml.sax.Attributes)
     */
    public void startElement(final String uri, final String localName, final String qName, final Attributes attributes) throws SAXException {
    	if (DafDrawingConstants.Attributes.attribute.equals(qName)) {
            inParam = true;
            param = attributes.getValue(DafDrawingConstants.Attributes.name);
        }
    	else if (DafDrawingConstants.Paging.paging.equals(qName)) {
    		if (attributes.getValue(DafDrawingConstants.Paging.limit) != null) {
    			resultSize = Integer.parseInt(attributes.getValue(DafDrawingConstants.Paging.limit));	
    		}
    		
    		if (attributes.getValue(DafDrawingConstants.Paging.offset) != null) {
    			startIndex = Integer.parseInt(attributes.getValue(DafDrawingConstants.Paging.offset));	
    		}
        }
    	else if (DafDrawingConstants.Binding.binding.equals(qName)) {
    		if (DafDrawingConstants.Binding.printNumber.equals(attributes.getValue(DafDrawingConstants.Binding.attribute))) {
    			printNumber = attributes.getValue(DafDrawingConstants.Binding.value);
    			
    			if (DafDrawingConstants.Binding.contains.equals(attributes.getValue(DafDrawingConstants.Binding.operator))) {
    				printNumberOp = SearchArgument.SEARCH_OP_LIKE;
    			}
    			else {
    				printNumberOp = SearchArgument.SEARCH_OP_EQUAL;
    			}
    		}
    		else if (DafDrawingConstants.Binding.itemNumber.equals(attributes.getValue(DafDrawingConstants.Binding.attribute))) {
    			itemNumber = attributes.getValue(DafDrawingConstants.Binding.value);
    			
    			if (DafDrawingConstants.Binding.contains.equals(attributes.getValue(DafDrawingConstants.Binding.operator))) {
    				itemNumberOp = SearchArgument.SEARCH_OP_LIKE;
    			}
    			else {
    				itemNumberOp = SearchArgument.SEARCH_OP_EQUAL;
    			}
    		}
    		else if (DafDrawingConstants.Binding.name.equals(attributes.getValue(DafDrawingConstants.Binding.attribute))) {
    			name = attributes.getValue(DafDrawingConstants.Binding.value);
    			
    			if (DafDrawingConstants.Binding.contains.equals(attributes.getValue(DafDrawingConstants.Binding.operator))) {
    				nameOp = SearchArgument.SEARCH_OP_LIKE;
    			}
    			else {
    				nameOp = SearchArgument.SEARCH_OP_EQUAL;
    			}
    		}
    		else if (DafDrawingConstants.Binding.serialNumber.equals(attributes.getValue(DafDrawingConstants.Binding.attribute))) {
    			serialNumber = attributes.getValue(DafDrawingConstants.Binding.value);
    			
    			if (DafDrawingConstants.Binding.contains.equals(attributes.getValue(DafDrawingConstants.Binding.operator))) {
    				serialNumberOp = SearchArgument.SEARCH_OP_LIKE;
    			}
    			else {
    				serialNumberOp = SearchArgument.SEARCH_OP_EQUAL;
    			}
    		}    		
    	}
		else if (DafDrawingConstants.Order.order.equals(qName)) {
            sortingField = attributes.getValue(DafDrawingConstants.Order.attribute);
            sortingDirection = attributes.getValue(DafDrawingConstants.Order.direction);    			
		}
		else if (DafDrawingConstants.Keys.key.equals(qName)) {
			key = attributes.getValue(DafDrawingConstants.Keys.value);               			
		} 
		else if (DafDrawingConstants.Subset.subset.equals(qName) 
				&& DafDrawingConstants.Subset.itemMap.equals(attributes.getValue(DafDrawingConstants.Subset.name))) {
			inSubset = true;
			this.hotspots.add(new HotSpot());
        }
    }

    /* (non-Javadoc)
     * @see org.xml.sax.helpers.DefaultHandler#endElement(java.lang.String, java.lang.String, java.lang.String)
     */
    public void endElement(final String uri, final String localName, final String qName) throws SAXException {
        if (inParam) {
        	if (inSubset == true) {
        		if (this.hotspots.size() > 0) {
        			HotSpot hs = this.hotspots.get(this.hotspots.size()-1);
        			
                	if (DafDrawingConstants.Subset.coordinate.equals(param)) {
                       hs.setCoordinate(chars.toString());
                    }
                	else if (DafDrawingConstants.Subset.itemNumber.equals(param)) {
                		hs.setItemNumber(chars.toString());
                    }
                	else if (DafDrawingConstants.Subset.shapeCode.equals(param)) {
                		hs.setShapeCode(chars.toString());
                    }
                	else if (DafDrawingConstants.Subset.serialNumber.equals(param)) {
                		hs.setSerialNumber(chars.toString());
                    }                	
        		}
        	}
        	else {
            	if (DafDrawingConstants.Attributes._name.equals(param)) {
                    this.attributeName = chars.toString();
                }
            	else if (DafDrawingConstants.Attributes.itemNumber.equals(param)) {
                    this.attributeItemNumber = chars.toString();
                }
            	else if (DafDrawingConstants.Attributes.printNumber.equals(param)) {
                    this.attributePrintNumber = chars.toString();
                }
            	else if (DafDrawingConstants.Attributes.serialNumber.equals(param)) {
                    this.attributeSerialNumber = chars.toString();
                }            	
            	else if (DafDrawingConstants.Attributes.isDefault.equals(param)) {
                    this.attributeIsDefault = chars.toString();
                }
            	else if (DafDrawingConstants.Attributes.imageMaster.equals(param)) {
                    this.attributeImageMaster = chars.toString();
                }
            	else if (DafDrawingConstants.Attributes.status.equals(param)) {
                    this.status = chars.toString();
                }
        	}

            inParam = false;
            chars.setLength(0);
        }
        if (inSubset == true) {
        	if (DafDrawingConstants.Subset.subset.equals(qName) == true) {
        		inSubset = false;	
        	}        	
        }
    }

    /* (non-Javadoc)
     * @see org.xml.sax.helpers.DefaultHandler#characters(char[], int, int)
     */
    public void characters(final char[] ch, final int start, final int length) throws SAXException {
        if (inParam) {
        	chars.append(ch, start, length);
        }
    }

	/**
	 * Returns the parsed Item Number
	 * @return
	 */
	public String getItemNumber() {
		return itemNumber;
	}

	/**
	 * Returns the parsed operator for the Item Number
	 * @return
	 */
	public String getItemNumberOp() {
		return itemNumberOp;
	}

	/**
	 * Returns the parsed Print Number
	 * @return
	 */
	public String getPrintNumber() {
		return printNumber;
	}

	/**
	 * Returns the parsed operator for the Print Number
	 * @return
	 */
	public String getPrintNumberOp() {
		return printNumberOp;
	}
	
	/**
	 * Returns the parsed Name
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * Returns the parsed operator for the Name
	 * @return
	 */
	public String getNameOp() {
		return nameOp;
	}

	/**
	 * Returns the parsed SerialNumber
	 * @return
	 */
	public String getSerialNumber() {
		return serialNumber;
	}

	/**
	 * Returns the parsed operator for the SerialNumber
	 * @return
	 */
	public String getSerialNumberOp() {
		return serialNumberOp;
	}

	/**
	 * Returns the parsed Result size
	 * @return
	 */
	public int getResultSize() {
		return resultSize;
	}

	/**
	 * Returns the parsed Start index
	 * @return
	 */
	public int getStartIndex() {
		return startIndex;
	}
	
	/**
	 * Returns the parsed Sorting field
	 * @return
	 */
	public String getSortingField() {
		return this.sortingField;
	}
	
	/**
	 * Returns the parsed Sorting direction
	 * @return
	 */
	public String getSortingDirection() {
		return this.sortingDirection;
	}
	
	/**
	 * Returns the parsed Key
	 * @return
	 */
	public String getKey() {
		return this.key;
	}

	/**
	 * Returns the parsed Attribute Name
	 * @return
	 */
	public String getAttributeName() {
		return this.attributeName;
	}

	/**
	 * Returns the parsed Attribute Print Number
	 * @return
	 */
	public String getAttributePrintNumber() {
		return this.attributePrintNumber;
	}

	/**
	 * Returns the parsed Attribute Item Number
	 * @return
	 */
	public String getAttributeItemNumber() {
		return this.attributeItemNumber;
	}

	/**
	 * Returns the parsed Attribute Serial Number
	 * @return
	 */
	public String getAttributeSerialNumber() {
		return this.attributeSerialNumber;
	}
	
	/**
	 * Returns the parsed Attribute Image Master
	 * @return
	 */
	public String getAttributeImageMaster() {
		return this.attributeImageMaster;
	}
	
	/**
	 * Returns the parsed Hot spots
	 * @return
	 */
	public List<HotSpot> getHotSpots() {
		return this.hotspots;
	}

	/**
	 * Returns the parsed Is Default 
	 * @return
	 */
	public String getAttributeIsDefault() {
		return this.attributeIsDefault;
	}
	
	/**
	 * @return
	 */
	public String getStatus() {
		return this.status;
	}
}