package com.intentia.iec.pipeline.runtime.stage.custom;

import java.util.Map;

import org.apache.commons.lang.StringEscapeUtils;

import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

public class StageUtilityHelper {

	private static final String BR_HTML_ELEMENT = "<br/>";
	private static final String NEXT_LINE_REGEX = "(\r\n|\n)";
	public static final String APP_DETAILS_IMAGES_ROOT_URL = "rootUrl";
	public static final String APP_DETAILS_IMAGES_ROOT_FOLDER = "RootFolder";

	public static String getValueFromApplicationData(String pParamName) {

		String paramValue;

		SearchPipelineExecuter spe = new SearchPipelineExecuter(
				ConstantsForSales.PIPELINE_PACKAGE,
				ConstantsForSales.APPLICATION_DATA,
				ConstantsForSales.APPLICATION_DATA_DETAILS);

		spe.setParam("param", pParamName);

		try {
			XMLResultset rs = spe.execute();
			rs.moveFirst();
			paramValue = rs.getString("ParameterValue");
		} catch (PipelineRuntimeException e) {
			paramValue = "";
		} catch (ResultsetException e) {
			paramValue = "";
		}

		return paramValue;

	}

	public static String getAppDataImagesRootFolder() {
		return getValueFromApplicationData(APP_DETAILS_IMAGES_ROOT_FOLDER);
	}

	public static String nl2br(String str) {
		if (str != null) {
			return str.replaceAll(NEXT_LINE_REGEX, BR_HTML_ELEMENT);
		}
		return str;
	}

	public static String toResultsetRow(Map<String, String> attributes) {
		StringBuilder row = new StringBuilder("<row ");
		for (Map.Entry<String, String> attr : attributes.entrySet()) {
			row.append(attr.getKey() + "=\""
					+ StringEscapeUtils.escapeXml(attr.getValue()) + "\" ");
		}
		row.append(" />");
		return row.toString();
	}
}
