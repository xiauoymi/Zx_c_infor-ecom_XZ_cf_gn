package com.intentia.iec.pipeline.runtime.stage.custom.daf.drawing;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;

/**
 * Sets the IsValidItem flag of a Drawing. This stage will query the database for valid product-child
 * values and check it against the Drawings found in DAF.
 *
 */
public class MarkValidItemStage extends AbstractPipelineStage {
	private static final Logger LOG = Logger.getLogger(MarkValidItemStage.class);
	
	private static final String MAINSET_ITEMS = "resultset/row";
	
	private static final String ITEM_NUMBER = "ItemNumber";
	
	private static final String SERIAL_NUMBER = "SerialNumber";
	
	private static final String PARENT = "Parent";
	
	private static final String CHILD = "Child";
	
	private static final String IS_VALID_ITEM = "IsValidItem";
	
	/**
	 * SQL statement to retrieve valid product-child values from the SpareParts table.
	 */
	private static final String SELECT_ITEMNUMBERS1 = 
		"select distinct i.itemNumber as Parent, i2.itemNumber as Child from SparePart sp " +
		"inner join Item i on sp.productID = i.id " +
		"inner join Item i2 on sp.sparePartID = i2.id " +
		"where i.itemNumber IN "; 
	
	private static final String UNION = " UNION ";
	
	/**
	 * SQL statement to retrieve valid product-child values from the AlternativeItems table.
	 */
	private static final String SELECT_ITEMNUMBERS2 = 
		"select distinct i.itemNumber as Parent, i2.itemNumber as Child from AlternativeItem ai " +
		"inner join Item i on ai.productId = i.id " +
		"inner join Item i2 on ai.alternativeItemId = i2.id " +
		"where i.itemNumber IN "; 

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.AbstractPipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public void execute(PipelineContext context) throws PipelineRuntimeException {
        if (!(context.getResponse() instanceof XMLResultset)) {
            throw new PipelineRuntimeException("XML Request is invalid");
        }

        // skip if Parts=disabled
        if (!"true".equals(CustomStagesHelper.getKeyValue(DafDrawingConstants.ApplicationProperty.SPS_ENABLED))) {
        	LOG.debug(DafDrawingConstants.ApplicationProperty.SPS_ENABLED + " is disabled. Skipping this stage.");
        	return;
        }
        
        Connection conn = (Connection) CustomStagesHelper.getConnection("esales.cursor");
        Statement stmt = null;
        try {
        	// get Item Numbers displayed in the page
			Set<String> set = getItemNumbers(context);
			if (set.isEmpty() == false) {
				// get query for Item Numbers displayed in page
				String sql = getSqlStatement(set);				
				stmt = conn.createStatement();

				LOG.debug("Executing SQL statement=" + sql);

				long startTime = System.currentTimeMillis();
				ResultSet sqlResultSet = stmt.executeQuery(sql);
				long stopTime = System.currentTimeMillis();
				LOG.debug("Total execution time: " + (stopTime - startTime) + " ms");

				// get valid items in the database
				Map<String,Set<String>> validItems = getValidItems(sqlResultSet);
				
				// set the IsValidItem in the XMLResultset
				markValidItems(context, validItems);
			}
		} catch (Exception e) {
			throw new PipelineRuntimeException(e);
		}
		finally {
			LOG.debug("Closing the statement object");
			if (stmt != null) {
				try {
					stmt.close();
				}
				catch (SQLException e) {
					LOG.error(e);
				}
				stmt = null;
			}
			
			LOG.debug("Closing the connection object");
			if (conn != null) {
				try {
					conn.close();
				}
				catch (SQLException e) {
					LOG.error(e);
				}
				conn = null;
			}
		}
	}
	
	/**
	 * Returns the Item Numbers displayed in the page
	 * @param context
	 * @return
	 * @throws ResultsetException
	 * @throws TransformerException
	 */
	private Set<String> getItemNumbers(PipelineContext context) throws ResultsetException, TransformerException {
		Set<String> itemNumbers = new HashSet<String>();
		XMLResultset resultset = (XMLResultset) context.getResponse();
		resultset.moveFirst();
		
		Document xmlDoc = resultset.getDocument();
		NodeList nodeList = XPathAPI.selectNodeList(xmlDoc, MAINSET_ITEMS);

		// iterate through the result set
		for (int i = 0; i < nodeList.getLength(); i++) {
			Element e = (Element) nodeList.item(i);
			if (e.getAttribute(ITEM_NUMBER) != null && !isSerialNumberPresent(e)) {
				itemNumbers.add(e.getAttribute(ITEM_NUMBER));
			}
		}
		
		return itemNumbers;
	}
	
	/**
	 * Checks if the serial number is present
	 * @param e
	 * @return
	 */
	private boolean isSerialNumberPresent(Element e) {
		if (e.getAttribute(SERIAL_NUMBER) != null && !"".equals(e.getAttribute(SERIAL_NUMBER))) {
			return true;
		}
		
		return false;
	}
	
	/**
	 * Returns a list of Item Numbers displayed in the page.
	 * @param set
	 * @return
	 */
	private String getInStatement(Set<String> set) {
		StringBuffer buf = new StringBuffer("(");		
		boolean first = true;
		
		if (set != null) {
			Iterator<String> it = set.iterator();
			while (it.hasNext() == true) {
				String itemNumber = it.next();
				if (first == false) {
					buf.append(",");
				}
				buf.append("'" + encodeSQL(itemNumber) + "'");
				first = false;
			}
			buf.append(")");
		}
		
		return buf.toString();
	}
	
	/**
	 * Returns the SQL statement to retrieve the product-child values in the e-Sales database.
	 * @param set
	 * @return
	 */
	private String getSqlStatement(Set<String> set) {
		String inStatement = getInStatement(set);
		return SELECT_ITEMNUMBERS1 + inStatement + UNION + SELECT_ITEMNUMBERS2 + inStatement;
	}
	
	/**
	 * Returns a Map of the product-child values in e-Sales.
	 * @param sqlResultSet
	 * @return
	 * @throws SQLException
	 */
	private Map<String,Set<String>> getValidItems(ResultSet sqlResultSet) throws SQLException {
		Map<String,Set<String>> validItems = new HashMap<String,Set<String>>();
		
		if (sqlResultSet != null) {
			while (sqlResultSet.next() == true) {
				// get parent
				String parent = sqlResultSet.getString(PARENT);

				if (validItems.get(parent) == null) {
					// if parent does not exist, add parent
					validItems.put(parent, new HashSet<String>());
				}
				// add child
				Set<String> children = validItems.get(parent);
				children.add(sqlResultSet.getString(CHILD));
			}
		}
		
		return validItems;
	}
	
	/**
	 * Sets the IsValidItem flag in the XMLResultset.
	 * @param context
	 * @param validItems
	 * @throws ResultsetException
	 * @throws TransformerException
	 */
	private void markValidItems(PipelineContext context, Map<String,Set<String>> validItems) throws ResultsetException, TransformerException {
		XMLResultset resultset = (XMLResultset) context.getResponse();
		resultset.moveFirst();

		Document xmlDoc = resultset.getDocument();
		NodeList parentNodeList = XPathAPI.selectNodeList(xmlDoc, MAINSET_ITEMS);
		
		// iterate through the main set
        for (int i = 0; i < parentNodeList.getLength(); i++) {
        	boolean parentValid = false;
        	Element parentElement = (Element) parentNodeList.item(i);        	
        	
        	// only set flag if serial number is NOT set
        	if (isSerialNumberPresent(parentElement) == false) {
            	// if parent is valid, set to 'Y'
            	if (parentElement.getAttribute(ITEM_NUMBER) != null && validItems.get(parentElement.getAttribute(ITEM_NUMBER)) != null) {
            		parentElement.setAttribute(IS_VALID_ITEM, DafDrawingConstants.YES);
            		parentValid = true;
            	}
            	else {
            		parentElement.setAttribute(IS_VALID_ITEM, DafDrawingConstants.NO);
            	}

            	NodeList childNodeList = parentElement.getChildNodes();
            	Set<String> childItems = validItems.get(parentElement.getAttribute(ITEM_NUMBER));

            	// iterate through the children
            	for (int j = 0; j < childNodeList.getLength(); j++) {
            		Element childElement = (Element) childNodeList.item(j);
            		
            		if (childElement.getAttribute(ITEM_NUMBER) != null) {
                		if (parentValid == false) {
                			// if parent is invalid, all children are invalid
                			childElement.setAttribute(IS_VALID_ITEM, DafDrawingConstants.NO);
                		}
                		else {
                			// if parent is valid, check if child is valid
                			 if (childItems.contains(childElement.getAttribute(ITEM_NUMBER)) == true && isSerialNumberPresent(childElement) == false) {
                				 childElement.setAttribute(IS_VALID_ITEM, DafDrawingConstants.YES);
                			 }
                			 else {
                				 childElement.setAttribute(IS_VALID_ITEM, DafDrawingConstants.NO);
                			 }
                		}
            		}
            	}
        	}
        }
	}
	
	/**
	 * Changes the ' to ''
	 * @param query
	 * @return
	 */
	private String encodeSQL(String query) {
		String ret = null;
		if (query != null) {			
			ret = query.replaceAll("'", "''");
		}
		
		return ret;
	}
}
