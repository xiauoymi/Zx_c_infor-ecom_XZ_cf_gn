package com.intentia.iec.pipeline.runtime.stage.custom.ia;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.w3c.dom.Node;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.ia.dao.IaDao;
import com.intentia.iec.pipeline.runtime.integration.ia.dao.impl.IaDaoRestImpl;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaConnectionException;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.ia.model.IaCampaign;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.utils.CommitPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

public class AddCampaignsToIaStage extends AbstractPipelineStage {

	private static final Logger log = Logger
			.getLogger(AddCampaignsToIaStage.class);

	private static final String ENTITY_XPATH = "request/entities/entity";

	private IaDao dao = null;

	private boolean useDummy = false;

	public AddCampaignsToIaStage() {
		// do nothing...
	}

	public AddCampaignsToIaStage(boolean useDummy) {
		this.useDummy = useDummy;
	}

	@Override
	public void execute(PipelineContext context)
			throws PipelineRuntimeException {
		log.debug("Start AddCampaignsToIaStage . . .");	
		
		CustomStagesHelper.extractRequestParameters(CustomStagesHelper
				.getRequest(context));
		
		XMLRequest request = (XMLRequest) context.getRequest();
		XMLResultset response = (XMLResultset) context.getResponse();
	
		boolean hasError = false;

		Parameters params = request.getParameters();
		String isScheduledJob = "";
		
		try {
			isScheduledJob = params.getString("runScheduleJobNow");
		} catch (Exception e) {	
			throw new PipelineRuntimeException(
					"Error getting parameter", e);
		}
		
		try {

			dao = new IaDaoRestImpl();
			Set<IaCampaign> campaigns = getCampaigns(request, response);
			hasError = addCampaignsToIa(campaigns);

			if("true".equals(isScheduledJob) && hasError)
			{
				throw new PipelineRuntimeException(
						"AddCampaignsToIaStage has error:" + hasError);
			}
			else if(hasError)
			{
				log.debug("AddCampaignsToIaStage has error:" + hasError);
			}
		} 
		catch(PipelineRuntimeException e){
			if("true".equals(isScheduledJob))
			{
				throw new PipelineRuntimeException(
						"Error while adding campaign to IA.", e);
			}
			else
			{
				log.debug("Error while adding campaign to IA.");
			}
		}
		catch (IaConnectionException e) {
			if("true".equals(isScheduledJob))
			{
				throw new PipelineRuntimeException(
						"Error while adding campaign to IA.", e);
			}
			else
			{
				log.debug("Error while adding campaign to IA.");
			}
		}
	}

	private Set<IaCampaign> getCampaigns(XMLRequest request,
			XMLResultset response) throws PipelineRuntimeException {
		Set<IaCampaign> campaigns = new HashSet<IaCampaign>();
		try {

			// TODO: Capture 'update' scenario here. check if flag
			// IsReplicatedToIA is not 'Y'

			if (response == null || response.isEmpty()) {
				response = getCampaignsNotInIa();
			}

			if (response != null && !response.isEmpty()) {
				response.beforeFirst();
				while (response.moveNext()) {
					IaCampaign campaign = new IaCampaign();
					campaign.setId(response.getString("CampaignID"));
					String name = response.getString("InternalName");
					if (name == null && request != null) {
						Node entityNode = XMLRequestHelper.getRequestNode(
								request, ENTITY_XPATH);
						XMLRequestHelper xmlHelper = new XMLRequestHelper(
								request);
						name = xmlHelper.getAttribute(entityNode,
								"InternalName");
					}
					campaign.setInternalName(name);
					campaigns.add(campaign);
				}
			} else {
				log.info("No campaigns found to add to IA.");
			}
		} catch (ResultsetException e) {
			throw new PipelineRuntimeException(
					"Error while retrieving campaign from Response XML: "
							+ response, e);
		} catch (TransformerException e) {
			throw new PipelineRuntimeException(
					"Error while retrieving campaign from Request XML: "
							+ response, e);
		}

		return campaigns;
	}

	private boolean addCampaignsToIa(Set<IaCampaign> campaigns)
			throws PipelineRuntimeException {
		boolean hasError = false;
		if (campaigns != null && !campaigns.isEmpty()) {
			log.debug("Adding the ff campaigns to IA: " + campaigns);
			Set<String> addedCampaigns = new HashSet<String>();

			for (IaCampaign campaign : campaigns) {
				try {
					dao.addCampaign(campaign);
					addedCampaigns.add(campaign.getId());
				} catch (IaRuntimeException e) {
					log.error("Error while adding campaign to IA : " + campaign, e);
					log.error("Details: " + e.getMessage());
					hasError = true;
				}
			}
			if(!hasError)
			{
				try {
					dao.deployPackage();
					updateCampaignFlagInDb(addedCampaigns);
				} catch (IaRuntimeException e) {
					log.error("Unable to deploy IA package after adding campaigns.", e);
				}
			}
		}
		return hasError;
	}

	private XMLResultset getCampaignsNotInIa() throws PipelineRuntimeException {
		if (useDummy) {
			return getDummyCampaignsNotInIa();
		} else {
			try {
				// Execute BO method
				SearchPipelineExecuter pipeline = new SearchPipelineExecuter(
						ConstantsForSales.PIPELINE_PACKAGE, "Campaign",
						"ListSimple", SearchPipelineExecuter.OR);
				pipeline.setBinding("IsReplicatedInIA", "Y", "ne"); // Not equal
																	// to 'Y'
				pipeline.setBinding("IsReplicatedInIA", "", "null");
				
				XMLResultset result = pipeline.execute();
				return result;
			} catch (PipelineRuntimeException e) {
				throw new PipelineRuntimeException(
						"Error while invoking the Campaign.ListBC pipeline.", e);
			}
		}
	}

	private void updateCampaignFlagInDb(Set<String> addedCampaigns)
			throws PipelineRuntimeException {
		try {
			// Execute BO method
			CommitPipelineExecuter pipeline = new CommitPipelineExecuter(
					ConstantsForSales.PIPELINE_PACKAGE, "Campaign",
					"UpdateIsReplicatedInIAFlag");
			for (String campaignId : addedCampaigns) {
				pipeline.addEntity();
				pipeline.setEntityKey("CampaignID", campaignId);
				pipeline.setAttribute("IsReplicatedInIA", "Y");
			}
			pipeline.execute();
		} catch (PipelineRuntimeException e) {
			throw new PipelineRuntimeException(
					"Error while setting IsReplicatedInIA flag to 'Y' of campaign IDs: "
							+ addedCampaigns, e);
		}
	}

	@SuppressWarnings("unused")
	private Set<IaCampaign> getDummyCampaigns(int count) {
		Set<IaCampaign> campaigns = new HashSet<IaCampaign>();
		for (int i = 0; i < count; i++) {
			IaCampaign campaign = new IaCampaign();
			String id = generateRandomId();
			campaign.setId(id);
			campaign.setInternalName("Test Campaign from IEC Unit Testing (Stage)");
			campaigns.add(campaign);
		}
		return campaigns;
	}

	private String generateRandomId() {
		Random rand = new Random();
		int randomNum = rand.nextInt((10000 - 100) + 1) + 100;
		return String.valueOf(randomNum);
	}

	private XMLResultset getDummyCampaignsNotInIa() {
		return new XMLResultset(
				"<?xml version=\"1.0\" encoding=\"UTF-8\"?><resultset object=\"Campaign\">	<row rownum=\"1\" BeginDate=\"2013-12-03T00:00:00\" CampaignID=\"3\" EndDate=\"2013-12-31T00:00:00\" InternalName=\"Test&#x20;Campaign&#x20;for&#x20;IA&#x20;(ECJ)\" IsActive=\"Y\" Type=\"C\"/>	<row rownum=\"2\" BeginDate=\"2013-11-01T00:00:00\" CampaignID=\"2\" EndDate=\"2014-11-30T00:00:00\" InternalName=\"New&#x20;Arrival&#x20;Craze!\" IsActive=\"Y\" Name=\"New&#x20;Arrival&#x20;Craze!\" Type=\"C\"/>	<row rownum=\"3\" BeginDate=\"2013-11-01T00:00:00\" CampaignID=\"1\" EndDate=\"2014-11-30T00:00:00\" InternalName=\"Summer&#x20;Sale&#x20;2014\" IsActive=\"Y\" Name=\"Summer&#x20;Sale&#x20;2014\" Type=\"C\"/></resultset>");
	}
}
