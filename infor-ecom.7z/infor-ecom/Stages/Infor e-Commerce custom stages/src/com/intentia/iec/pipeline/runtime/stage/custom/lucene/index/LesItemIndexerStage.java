package com.intentia.iec.pipeline.runtime.stage.custom.lucene.index;

import java.util.Iterator;
import java.util.Map;

import org.apache.lucene.document.Document;

import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.lucene.manager.ResultsetDocumentHandler;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

/**
 * 
 * @author 15062
 * 
 */
public final class LesItemIndexerStage extends AbstractIndexerStage {

    private static final String INDEX_NAME = "LesItem";

    private static final String BO_NAME = "Item";

    private static final String BO_METHOD_NAME = "GetItemsForLesItemIndex";

    private static final String KEY_ATTRIBUTE_NAME = ConstantsForSales.ITEM_ID;

    protected String getIndexName() {
        return INDEX_NAME;
    }

    protected String getKeyAttributeName() {
        return KEY_ATTRIBUTE_NAME;
    }

    protected String getBOName() {
        return BO_NAME;
    }

    protected String getBOMethodName() {
        return BO_METHOD_NAME;
    }

    protected void setAdditionalRequestParameters(SearchPipelineExecuter pipeline) {
        // TODO: Add parameters here (if needed)
    }

    protected void setAdditionalRequestBindings(SearchPipelineExecuter pipeline) {
        // TODO: Add bindings here (if needed)
    }

    protected void addMoreFields(Map<String, Document> docMap) throws PipelineRuntimeException {
        Iterator<String> it = docMap.keySet().iterator();
        while (it.hasNext()) {
            String key = it.next();
            Document doc = docMap.get(key);
            addCategories(doc);
            addFavoriteItemUsers(doc);
            // TODO: add users who add this item to their WishList
            addItemRatings(doc);
        }
    }

    private void addCategories(Document doc) throws PipelineRuntimeException {
        String[] categoryIDs = doc.getValues(ConstantsForSales.CATEGORY_ID_FIELD);
        if (categoryIDs != null && categoryIDs.length > 0) {
            SearchPipelineExecuter pipeline = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                    "Category", "GetCategoriesForLesItemIndex", SearchPipelineExecuter.OR);
            for (int i = 0; i < categoryIDs.length; i++) {
                pipeline.setBinding(ConstantsForSales.CATEGORY_ID_ATTRIBUTE, categoryIDs[i], "eq");
            }
            XMLResultset categories = pipeline.execute();

            ResultsetDocumentHandler handler = new ResultsetDocumentHandler(doc, _indexManager, KEY_ATTRIBUTE_NAME);
            parseXMLResultset(categories, handler);
        }
    }

    private void addFavoriteItemUsers(Document doc) throws PipelineRuntimeException {
        String[] itemIDs = doc.getValues(ConstantsForSales.KEY_FIELD);
        if (itemIDs != null && itemIDs.length > 0) {
            SearchPipelineExecuter pipeline = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "User",
                    "GetFavoriteItemUsersForLesItemIndex");
            pipeline.setParam(ConstantsForSales.ITEM_NUMBER_PARAM, itemIDs[0]);
            XMLResultset faveUsers = pipeline.execute();

            ResultsetDocumentHandler handler = new ResultsetDocumentHandler(doc, _indexManager, KEY_ATTRIBUTE_NAME);
            parseXMLResultset(faveUsers, handler);
        }
    }

    private void addItemRatings(Document doc) throws PipelineRuntimeException {
        String[] itemIDs = doc.getValues(ConstantsForSales.KEY_FIELD);
        if (itemIDs != null && itemIDs.length > 0) {
            SearchPipelineExecuter pipeline = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                    "UserRating", "GetUserItemRatingsForLesItemIndex");
            pipeline.setBinding(ConstantsForSales.ITEMNUMBER, itemIDs[0], "eq");
            XMLResultset ratings = pipeline.execute();

            ResultsetDocumentHandler handler = new ResultsetDocumentHandler(doc, _indexManager, KEY_ATTRIBUTE_NAME);
            parseXMLResultset(ratings, handler);
        }
    }

}