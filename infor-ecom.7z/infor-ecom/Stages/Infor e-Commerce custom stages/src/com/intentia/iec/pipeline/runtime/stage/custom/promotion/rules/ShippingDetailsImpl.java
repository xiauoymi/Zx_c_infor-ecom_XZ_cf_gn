package com.intentia.iec.pipeline.runtime.stage.custom.promotion.rules;

import java.util.List;
import java.util.Map;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

public class ShippingDetailsImpl implements Rules {

	private static final Logger LOG = Logger.getLogger(ShippingDetailsImpl.class);

	private static ShippingDetailsImpl instance = null;

	private PromotionRule promotionRule = null;

	private String promotionId;

	private Map<String, List<String>> promotionalItemsMap;
	
	private XMLRequestHelper xmlHelper = null;
	
	private String languageCode = null;
	
	protected ShippingDetailsImpl() {
		// Exists only to defeat instantiation.
	}

	public static ShippingDetailsImpl getInstance() {
		if (instance == null) {
			instance = new ShippingDetailsImpl();
		}
		return instance;
	}

	public PromotionRule getPromotionRule() {
		return promotionRule;
	}
	
	public void setPromotionId(String promotionId) {
		this.promotionId = promotionId;
	}
	
	public void setPromotionRule(PromotionRule promotionRule) {
		this.promotionRule = promotionRule;
	}
	
	public void setPromotionalItemsMap(Map<String, List<String>> promotionalItemsMap) {
		this.promotionalItemsMap = promotionalItemsMap;
	}
	
	public boolean evaluateOrder(XMLResultset resultSet, XMLRequestHelper xmlHelper) throws ResultsetException {
		LOG.debug("Inside ShippingDetailsImpl.evaluateOrder()");
		boolean isValid = false;
		try {
			PromotionRule promotionRule = this.promotionRule;		
			String ruleField = promotionRule.getField();
			String operator = promotionRule.getOperator();
			
			List<String> ruleValueList = promotionRule.getValues();
			this.xmlHelper = xmlHelper;
			if(RulesConstant.METHOD.equals(ruleField)){
				isValid = this.evaluateMethod(resultSet, ruleValueList, operator);
			} else if(RulesConstant.COUNTRY.equals(ruleField)){
				isValid = this.evaluateCountry(resultSet, ruleValueList, operator);
			} else if(RulesConstant.STATE.equals(ruleField)){
				isValid = this.evaluateState(resultSet, ruleValueList, operator);
			} else if(RulesConstant.ZIP_CODE.equals(ruleField)){
				isValid = this.evaluateZipCode(resultSet, ruleValueList, operator);
			}
		} catch (TransformerException e) {
			e.printStackTrace();
		}
		
		return isValid;		
	}
	
	public boolean evaluateOrderLine(XMLIterator xmlOrderline, XMLRequestHelper xmlHelper)
			throws TransformerException, ResultsetException {
		LOG.debug("Inside ShippingDetailsImpl.evaluateOrderLine()");
		boolean isValid = false;
		return isValid;
	}

	private boolean evaluateMethod(XMLResultset resultSet, List<String> ruleValueList, String operator)
			throws TransformerException{
		LOG.debug("Inside ShippingDetailsImpl.evaluateMethod()");
		boolean isValid = false;
		return isValid;
	}
	
	private boolean evaluateCountry(XMLResultset resultSet, List<String> ruleValueList, String operator)
			throws TransformerException{
		LOG.debug("Inside ShippingDetailsImpl.evaluateCountry()");
		boolean isValid = false;
		return isValid;
	}
	
	private boolean evaluateState(XMLResultset resultSet, List<String> ruleValueList, String operator)
			throws TransformerException{
		LOG.debug("Inside ShippingDetailsImpl.evaluateState()");
		boolean isValid = false;
		return isValid;
	}
	
	private boolean evaluateZipCode(XMLResultset resultSet, List<String> ruleValueList, String operator)
			throws TransformerException{
		LOG.debug("Inside ShippingDetailsImpl.evaluateZipCode()");
		boolean isValid = false;
		return isValid;
	}
	
}
