package com.intentia.iec.pipeline.runtime.stage.custom.search.sps.equipment;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.Sort;
import org.apache.lucene.search.SortField;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.search.CachedChainedFilter;
import com.intentia.iec.pipeline.runtime.stage.custom.search.CachedPrefixFilter;
import com.intentia.iec.pipeline.runtime.stage.custom.search.CachedTermsFilter;
import com.intentia.iec.pipeline.runtime.stage.custom.search.DataHolder;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Database;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Response;
import com.intentia.iec.pipeline.runtime.stage.custom.search.SearchUtils;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Strings;
import com.intentia.iec.pipeline.runtime.stage.custom.search.sps.AbstractSPSItemListStage;

/**
 * Class for searching equipments. This is called when the Equipment List is accessed.
 *
 */
public class EquipmentListStage extends AbstractSPSItemListStage {

	private static final Logger LOG = Logger.getLogger(EquipmentListStage.class);
	
    public static final CachedTermsFilter PARENT_EQUIPMENT_FILTER = new CachedTermsFilter(new Term(EquipmentStrings.Index.isParent,
            EquipmentStrings.Index.parent));

	/**
	 * Default constructor. Creates objects that are specific to indexing equipments.
	 * @throws PipelineRuntimeException
	 */
	public EquipmentListStage() throws PipelineRuntimeException {
		request = new EquipmentRequest();
		response = new Response();
		helper = new SearchUtils();
		queries = new EquipmentDatabaseImpl();
		dataholder = EquipmentManagerImpl.getInstance().getDataHolder();
	}

	/**
	 * Copies the parameters.
	 * @param queries
	 * @param dataholder
	 * @throws PipelineRuntimeException
	 */
	public EquipmentListStage(Database queries, DataHolder dataholder)
			throws PipelineRuntimeException {
		request = new EquipmentRequest();
		response = new Response();
		helper = new SearchUtils();
		this.queries = queries;
		this.dataholder = dataholder;
	}
    
    /**
     * Returns the default filters. For equipment search, the default filter is the user group ID since
     * the equipments should be visible to the owners only.
     * @return default filter containing the user group ID
     */
    public CachedChainedFilter getDefaultFilters() {
    	CachedChainedFilter filterChainCached = new CachedChainedFilter();
        CachedTermsFilter wrapper = new CachedTermsFilter();
        wrapper.addTerm(new Term(EquipmentStrings.Index.Equipment.userGroupId, request.getUserGroupId()));
        filterChainCached.add(wrapper);
        
        return filterChainCached;
    }
    
    /**
     * Returns a Map containing basic equipment information.
     * @param hits
     * @return
     * @throws PipelineRuntimeException
     */
    protected Map<String, Map<String, String>> getPageOfRowDataFromLucene(final Hits hits)
            throws PipelineRuntimeException {
        final Map<String, Map<String, String>> rows = new LinkedHashMap<String, Map<String, String>>();
        
        String lang = request.getLanguageCode();

        int pagingLimit = DEFAULT_PAGING_LIMIT;
        if (request.getPagingLimit() != null) {
            pagingLimit = Integer.parseInt(request.getPagingLimit());
        }

        int pagingOffset = 0;
        if (request.getPagingOffset() != null) {
            pagingOffset = Integer.parseInt(request.getPagingOffset());
        }

        try {
            for (int i = 0; i < pagingLimit && i < hits.length() - pagingOffset; i++) {
                Document doc = hits.doc(i + pagingOffset);
                Map<String, String> row = new HashMap<String, String>();
                row.put(Strings.Response.ItemList.name, doc.get(Strings.Index.Item.namePrefix + lang));
                row.put(Strings.Response.ItemList.description, doc.get(Strings.Index.Item.descriptionPrefix + lang));
                row.put(Strings.Response.ItemList.manufacturerName, doc.get(Strings.Index.Item.manufacturerName));
                row.put(Strings.Response.ItemList.mainCategoryName, doc.get(Strings.Index.Item.mainCategoryNamePrefix
                        + lang));
                
                // included serial number and equipment ID.
                row.put(EquipmentStrings.Response.EquipmentList.serialNumber, doc.get(EquipmentStrings.Index.Equipment.serialNumber));
                rows.put(doc.get(EquipmentStrings.Index.Equipment.equipmentId), row);
            }
        } catch (IOException e) {
            LOG.error("Error during hits retrieval", e);
            throw new PipelineRuntimeException(e);
        }
        return rows;
    }

	/**
	 * Add filters specific to equipment search. Equipment search may include search by serial number
	 * and searching of child equipments. 
	 * @param filterChainCached filter specified in the Equipment List page
	 */
	protected void addFilters(final CachedChainedFilter filterChainCached)
			throws PipelineRuntimeException {
        String searchRequestOrigin = request.getSearchRequestOrigin();
        String wildcardSearch = request.getWildcardSearch();
        boolean useWildcardSearch = false;
        if (searchRequestOrigin != null && wildcardSearch != null && wildcardSearch.equals(searchRequestOrigin) == true) {
        	useWildcardSearch = true;
        }        
			
		if (request instanceof EquipmentRequest) {
			EquipmentRequest req = (EquipmentRequest) request;
			StringBuilder logInfo = new StringBuilder(100);

			if (useWildcardSearch == false && req.getSerialNumber() != null && !"empty".equals(req.getSerialNumber())) {

				String serialNumber = req.getSerialNumber().toLowerCase();				

				Term serialNumberTerm = new Term(EquipmentStrings.Index.Equipment.serialNumber, serialNumber);
				CachedPrefixFilter cpf = new CachedPrefixFilter(serialNumberTerm);
				filterChainCached.add(cpf);

				logInfo.append("\n\t<serialNumber><![CDATA[").append(
						serialNumberTerm).append("]]></serialNumber>");
			}
			
			if (req.getChildEquipmentSearchString() != null && !"empty".equals(req.getChildEquipmentSearchString())) {
		            // for now, use item number as search parameter
		            String parentEquipment = req.getChildEquipmentSearchString();		            
	
		            if (parentEquipment != null) {
		                Term parentEquipmentTerm = new Term(EquipmentStrings.Index.Equipment.parentEquipmentId, parentEquipment);
		                filterChainCached.add(new CachedTermsFilter(parentEquipmentTerm));
		                logInfo.append("\n\t<parentEquipment><![CDATA[").append(parentEquipment).append("]]></parentEquipment>");
		            }
		    }
			
			if (includeSubComponents(req) == false) {
				// add filter to exclude subcomponents
				filterChainCached.add(PARENT_EQUIPMENT_FILTER);
				logInfo.append("\n\t<isParent><![CDATA[").append("Y").append("]]></isParent>");
			}
			
			if (logInfo.length() > 0) {
				LOG.info(logInfo.toString());
			}
		}
		super.addFilters(filterChainCached);
	}

	/**
	 * Returns the sorting used in the Equipment List. The search results may be sorted by serial number.
	 * If no sorting is specified, the sorting of the parent class is returned.
	 * @return sorting to be used
	 */
	protected Sort getSort() {
		String SORTING_FIELD_SERIALNUMBER = "SerialNumber";

		if (request.getSortingField() != null && SORTING_FIELD_SERIALNUMBER.equals(request.getSortingField()) == true) {
			boolean sortReverse = "descending".equals(request.getSortingDirection());
			String sortingField = EquipmentStrings.Index.Equipment.serialNumber;

			return new Sort(new SortField[] { new SortField(sortingField,
					SortField.STRING, sortReverse) });
		} else {
			return super.getSort();
		}
	}
	
	/**
	 * Subcomponents will only be searched on drill-down.
	 * @param req
	 * @return true if viewing equipment's components
	 */
	private boolean includeSubComponents(EquipmentRequest req) { 
		 if (req.getChildEquipmentSearchString() != null && !"empty".equals(req.getChildEquipmentSearchString())) {
			 return true;
		 }
		 
		 return false;
	}
}
