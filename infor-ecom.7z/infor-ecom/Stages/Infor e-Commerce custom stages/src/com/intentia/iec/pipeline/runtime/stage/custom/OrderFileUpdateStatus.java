package com.intentia.iec.pipeline.runtime.stage.custom;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.CommitPipelineExecuter;

/**
 * A simpler way of updating the order file status. This needs to be separated 
 * from the OrderFileOrderEntry method because that method is asynchronous in nature.
 *
 */
public class OrderFileUpdateStatus implements PipelineStage {
	
	private static final Logger LOG = Logger.getLogger(OrderFileOrderEntry.class);
	
    private static final String PARAM_FILEID = "id";
    
    private static final String PARAM_STATUS = "status";

    private static final String ORDERFILE_FILEID_ATTRIB = "FileID";

    private static final String ORDERFILE_STATUS_ATTRIB = "Status";

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.PipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	public void execute(PipelineContext pipelinecontext) throws PipelineRuntimeException {
		try {
			XMLRequest.extractRequestParameters((XMLRequest) pipelinecontext.getRequest());
			
			 final Parameters params = CustomStagesHelper.getRequestParameters(pipelinecontext);
			 
			 String id = params.getString(PARAM_FILEID);
			 String status = params.getString(PARAM_STATUS);
			 
			 LOG.debug("Updating status of file=" + id + " to status=" + status);
			 
			 updateOrderFileStatus(pipelinecontext, id, status);
		} catch (Exception e) {
			LOG.debug("Error updating order file status", e);
			throw new PipelineRuntimeException(e);
		}
	}

	/**
	 * Calls OrderFile.OrderFile_Update
	 * @param pipelinecontext
	 * @param id
	 * @param status
	 * @throws PipelineRuntimeException
	 * @throws TransformerException
	 */
	private void updateOrderFileStatus(PipelineContext pipelinecontext, String id, String status) throws PipelineRuntimeException, TransformerException {
		
		CommitPipelineExecuter coe = new CommitPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "OrderFile",
               "Update");
		
		coe.addEntity();
		coe.setEntityKey(ORDERFILE_FILEID_ATTRIB, id);
		coe.setAttribute(ORDERFILE_STATUS_ATTRIB, status);

		coe.execute();
	}
}
