package com.intentia.iec.pipeline.runtime.integration.creditcard.dao;

import com.intentia.iec.pipeline.runtime.integration.creditcard.exception.CreditCardConnectionException;
import com.intentia.iec.pipeline.runtime.integration.creditcard.exception.CreditCardException;
import com.intentia.iec.pipeline.runtime.integration.creditcard.model.CreditCard;
import com.intentia.iec.pipeline.runtime.integration.creditcard.model.Payment;
import com.intentia.iec.pipeline.runtime.integration.creditcard.model.TransactionResult;

public interface CreditCardDao {

	TransactionResult authorize(CreditCard creditCard, Payment payment) throws CreditCardConnectionException, CreditCardException;
	
	TransactionResult cancelAuthorize(TransactionResult transaction,
			CreditCard creditCard) throws CreditCardConnectionException;
	
}
