/*
 * Created on 03-03-2006
 */
package com.intentia.iec.pipeline.runtime.custom.pim;

import java.util.LinkedList;
import java.util.List;

/**
 * Class representing an XML request &lt;delete&gt; element (and its content).
 * 
 * @author PEDJES0
 * 
 */
public class DeleteSet {
    private final String key;

    private List children = null;

    public DeleteSet(final String key) {
        this.key = key;
    }

    public final String getKey() {
        return key;
    }

    public final void addChildSet(final String setName, final String childKey) {
        if (children == null) {
            children = new LinkedList();
        }

        children.add(new Subset(setName, childKey));
    }

    public final List getChildren() {
        return children;
    }
}
