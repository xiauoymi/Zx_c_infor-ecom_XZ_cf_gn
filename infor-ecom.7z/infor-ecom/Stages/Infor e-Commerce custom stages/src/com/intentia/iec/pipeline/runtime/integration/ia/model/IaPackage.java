package com.intentia.iec.pipeline.runtime.integration.ia.model;

public class IaPackage {

	private String name;
	private String location;
	private String accessLevel;
	private String lockType;
	private String xmlDesc;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getAccessLevel() {
		return accessLevel;
	}

	public void setAccessLevel(String accessLevel) {
		this.accessLevel = accessLevel;
	}

	public String getLockType() {
		return lockType;
	}

	public void setLockType(String lockType) {
		this.lockType = lockType;
	}

	public String getXmlDesc() {
		return xmlDesc;
	}

	public void setXmlDesc(String xmlDesc) {
		this.xmlDesc = xmlDesc;
	}

	@Override
	public String toString() {
		StringBuilder campaignStr = new StringBuilder();
		campaignStr.append("{");
		campaignStr.append("name :" + this.name);
		campaignStr.append(", location :" + this.location);
		campaignStr.append(", accessLevel :" + this.accessLevel);
		campaignStr.append(", lockType :" + this.lockType);
		campaignStr.append(", xmlDesc :" + this.xmlDesc);
		campaignStr.append("}");
		return campaignStr.toString();
	}

}
