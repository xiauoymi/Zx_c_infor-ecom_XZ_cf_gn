package com.intentia.iec.pipeline.runtime.stage.custom;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;

import java.sql.Connection;
import java.sql.ResultSet;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.utils.CommitPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;
import com.intentia.iec.sqlserver.runtime.jdbc.LogPreparedStatement;
import com.intentia.iec.connection.ConnectionFactory;

public class OrderFileOrderEntry extends GatewayOrderEntry {
    private static final Logger LOG = Logger.getLogger(OrderFileOrderEntry.class);

    private static final String PARAM_ORDERID = "orderID";

    private static final String PARAM_FILEID = "FileID";

    private static final String PARAM_LANGUAGECODE = "LanguageCode";

    private static final String PARAM_LANGUAGECODE_VALUE = "@LanguageCode";

    private static final String PARAM_ORDER_STATUS = "orderFileStatus";

    private static final String ORDERFILE_FILEID_ATTRIB = "FileID";

    private static final String ORDERFILE_STATUS_ATTRIB = "Status";

    private static final String ORDERFILE_LAST_ORDERID_ATTRIB = "LastSubmittedOrderId";

    private static final String ORDERFILE_STATUS_SUBMITTED = "submitted";

    private static final String ORDERFILE_STATUS_FAILED = "failed";

    private static final String SQL_EXEC_ORDER_CLEANUP = "EXEC OrderTransactionCleanUp ?, ?";
    
    private static final String PARAM_USERGROUP = "UserGroup";

    private static final String PARAM_USERGROUP_VALUE = "@UserGroupID";
    
    private static final String PARAM_APPROVALREQUIRED="approvalRequired";
    
    private static final String PARAM_METHOD="Method";
    
    private String fileID = null;

    private String orderID = null;

    private String submittedOrderID = null;

    private boolean orderSubmitted = false;

    private boolean mxvEnabled = false;

    /**
     * 
     */
    public void execute(PipelineContext pipelinecontext) throws PipelineRuntimeException {
    	boolean isFailedOrder = false;

    	try {
            try {
                XMLRequest.extractRequestParameters((XMLRequest) pipelinecontext.getRequest());

                final Parameters params = CustomStagesHelper.getRequestParameters(pipelinecontext);

                fileID = params.getString(PARAM_FILEID);

                orderID = params.getString(PARAM_ORDERID);

                addOrderLines(pipelinecontext, params);

                updatePrices(params, orderID);

                updatePaymentStatus(params, orderID);
                
                if((params.getString(PARAM_METHOD)!=null && params.getString(PARAM_METHOD).equals("Asynchronous")) 
                	&&(params.getString(PARAM_APPROVALREQUIRED)!=null && params.getString(PARAM_APPROVALREQUIRED).equals("Y"))){
                	if(checkApprovalLimit()){
                		throw new Exception("Orders for Approval is required");
                	}
                }
                
                XMLResultset ret = callOrderExecute(params, orderID);
                
                if (ret != null)
                    orderSubmitted = true;

                pipelinecontext.setResponse(ret);

                Parameters statusParams = ret.getParameters();

                mxvEnabled = ("true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.CONNECTORENABLED)));                

                if (mxvEnabled) {
                    int mvxStatus = statusParams.getint(ConstantsForSales.MVXSTATUS);
                    isFailedOrder = isFailedOrder(mvxStatus);

                    if (isFailedOrder == true) {
                        submittedOrderID = statusParams.getString(ConstantsForSales.GENERATEDORDERNO);
                    } else {
                        submittedOrderID = statusParams.getString(ConstantsForSales.SUBMITTEDORDERID);
                    }
                } else {
                    submittedOrderID = statusParams.getString(ConstantsForSales.SUBMITTEDORDERID);
                }

                LOG.debug("Submitted/Genrated Order ID = " + submittedOrderID);

            } catch (Exception e) {
                LOG.debug("Unable to process Order File with ID = '" + fileID + "', cause by:", e);
                throw new PipelineRuntimeException(e);
            }
        } catch (Throwable e) {
            orderSubmitted = false;
            LOG.debug("Capturing throwable exception: ", e);
            // will not throw any exception here else
            // all status updates will be rolled back
        } finally {
            if (orderSubmitted && submittedOrderID != null && !isFailedOrder) {
                updateOrderFileStatus(pipelinecontext, fileID, ORDERFILE_STATUS_SUBMITTED, submittedOrderID);
            } else {
                updateOrderFileStatus(pipelinecontext, fileID, ORDERFILE_STATUS_FAILED, null);
                cleanupFailedOrder(orderID, submittedOrderID);
            }
        }
    }

    /**
     * Insert the order lines in the db thru order file
     * 
     * @param pipelinecontext
     * @param params
     * @throws RequestException
     * @throws TransformerException
     * @throws PipelineRuntimeException
     */
    private void addOrderLines(PipelineContext pipelinecontext, final Parameters params)
            throws PipelineRuntimeException {
        try {
            XMLRequest request = (XMLRequest) pipelinecontext.getRequest();

            XMLRequestHelper xmlHelper = new XMLRequestHelper(request);
            xmlHelper.setParam(PARAM_LANGUAGECODE, params.getString(PARAM_LANGUAGECODE_VALUE));
            xmlHelper.setParam(PARAM_USERGROUP, params.getString(PARAM_USERGROUP_VALUE));
            xmlHelper.logRequest();

            executePipeline(pipelinecontext, ConstantsForSales.PIPELINE_PACKAGE + ".CurrentOrder"
                    + ".UpdateLineByOrderFile");

        } catch (Exception e) {
            LOG.debug("Error while adding items to the OrderLine", e);
            throw new PipelineRuntimeException(e);
        }
    }

    /**
     * Update the status of the order file
     * 
     * @param pKey
     * @param pStatus
     * @throws PipelineRuntimeException
     */
    private void updateOrderFileStatus(PipelineContext pipelinecontext, String pKey, String pStatus, String pOrderID)
            throws PipelineRuntimeException {
        try {
            XMLRequest request = (XMLRequest) pipelinecontext.getRequest();

            XMLRequestHelper xmlHelper = new XMLRequestHelper(request);
            xmlHelper.setParam(PARAM_ORDER_STATUS, pStatus);
            xmlHelper.logRequest();

            CommitPipelineExecuter coe = new CommitPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "OrderFile",
                    "Update");

            coe.addEntity();
            coe.setEntityKey(ORDERFILE_FILEID_ATTRIB, pKey);
            coe.setAttribute(ORDERFILE_STATUS_ATTRIB, pStatus);

            if (pOrderID != null)
                coe.setAttribute(ORDERFILE_LAST_ORDERID_ATTRIB, pOrderID);

            coe.execute();
        } catch (Exception e) {
            LOG.debug("Error while updating Order File status", e);
            throw new PipelineRuntimeException(e);
        }
    }

    private void cleanupFailedOrder(String orderID, String mvxOrderID) throws PipelineRuntimeException {
        Connection con = null;
        String conName = null;
        LogPreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conName = CustomStagesHelper.getConnectionName("esales.cursor");
            con = (Connection) ConnectionFactory.getConnection(conName);

            stmt = new LogPreparedStatement(con, SQL_EXEC_ORDER_CLEANUP);
            stmt.setInt(1, Integer.parseInt(orderID));
            stmt.setString(2, mvxOrderID);
            LOG.debug("Executing SQL Statement : " + stmt.getQuery());
            stmt.execute();

        } catch (Exception e) {
            LOG.debug("Error while cleaning up failed order's transactions", e);
            throw new PipelineRuntimeException(e);
        } finally {
            CustomStagesHelper.close(con, stmt, rs);
        }
    }
    
    private boolean isFailedOrder(int mvxStatus) {
    	if (mvxStatus > -1000 && (mvxStatus == -25 || mvxStatus == -30)) {
    		return true;
    	}
    	
    	return false;
    }
    
    private boolean checkApprovalLimit(){
    	try{
    		SearchPipelineExecuter spe = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
    				"CurrentOrder", "GetExistingOrder"); 
    		XMLResultset res=null;
    		spe.setBinding("OrderID", this.orderID, "eq");
    		res = spe.execute();
    		res.moveFirst();
    		if(res.getString("ApprovalRequired")!=null){
    			if(res.getString("ApprovalRequired").equals("Y")){
    				return true;
    			}
    		}
    	}
    	catch(Exception e){
    		
    	}
    	return false;
    }
    
}