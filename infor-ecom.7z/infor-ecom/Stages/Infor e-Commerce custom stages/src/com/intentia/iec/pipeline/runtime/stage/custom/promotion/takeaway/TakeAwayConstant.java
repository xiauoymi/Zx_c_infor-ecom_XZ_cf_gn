/**
 * 
 */
package com.intentia.iec.pipeline.runtime.stage.custom.promotion.takeaway;

/**
 * @author gsantiago
 *
 */
public final class TakeAwayConstant {

	public static final String FREE_ITEM = "freeItem";
    
    public static final String PRICE_DISCOUNT = "priceDiscount";
    
    public static final String FIX_PRICE = "fixPrice";
    
    public static final String FREE_SHIPPING = "freeShiping";
	
	// RULE FIELDS
	public static final String ITEM_NUMBER = "itemNumber";
	
	public static final String ITEM_CATEGORY = "itemCategory";
	
	public static final String ITEM_Assortment = "itemAssortment";
	
	public static final String ORDER_TOTAL = "orderTotal";

	public static final String PER_ITEM_IN_CART = "perItemInCart";
	
	public static final String ITEMS_IN_PROMO = "itemsInPromo";
	
	public static final String SELECTED_ITEMS = "selectedItems";
	
	public static final String METHOD = "method";
	
	// REQUEST FIELDS
	public static final String REQ_QUANTITY = "Quantity";
	
	public static final String REQ_GRAND_TOTAL = "GrandTotal";
	
	public static final String REQ_TOTAL_PRICE = "TotalPrice";
	
	public static final String REQ_TOTAL_DISCOUNT = "TotalDiscount";
	
	public static final String REQ_TOTAL_LINE_DISCOUNT = "TotalLineDiscount";
	
	public static final String REQ_ORDERHEADER_DISCOUNT = "OrderHeaderDiscount";
	
	public static final String REQ_LINE_TOTAL = "LineTotal";
	
	public static final String REQ_ITEM_ID = "ItemID";
	
	public static final String REQ_ITEM_NUMBER = "ItemNumber";
	
	public static final String REQ_PAYMENT_METHOD_CODEID = "PaymentMethodCodeID";

	public static final String REQ_IS_FREE_ITEM = "IsFreeItem";
	
	// OPERATORS
	
	public static final String OPERATOR_CONTAINS = "Contains";
	
	public static final String OPERATOR_PERCENT = "%";
	
	public static final String OPERATOR_EQUAL = "=";
	
	public static final String OPERATOR_NOT_EQUAL = "!=";
	
	public static final String OPERATOR_LESSTHAN = ">";
	
	public static final String OPERATOR_GREATERTHAN = "<";
	
	public static final String OPERATOR_LESSTHAN_EQUALTO = ">=";
	
	public static final String OPERATOR_GREATERTHAN_EQUALTO  = "<=";

	
	public static final String ZERO_BIG_DECIMAL_VALUE = "0.0000";

	public static final String ITEM_ID_PARAMETER = "@ItemId";
	public static final String LANGUAGE_CODE_PARAM = "@LanguageCode";
	public static final String CURRENCY_CODE_PARAM = "@CurrencyCode";
	public static final String USERGROUP_ID_PARAM = "@UserGroupID";
	public static final String USER_ID_PARAM = "@UserID";
	public static final String MVX_WAREHOUSE_CODE_PARAM = "@MvxWarehouse";
	public static final String IS_ACTIVE_PARAM = "@isActive";
	public static final String ALT_EXCHANGERATE_PARAM = "altExchangeRate";
	public static final String EXCHANGE_RATE_PARAM = "exchangeRate";
	public static final String EXECUTE_INCLUDE_TAX_PARAM = "executeIncludeTax";
	public static final String ITEM_CODE_PARAM = "itemCode";
	public static final String SELECTED_PROMOTIONID_PARAM = "SelectedPromotionID";
}
