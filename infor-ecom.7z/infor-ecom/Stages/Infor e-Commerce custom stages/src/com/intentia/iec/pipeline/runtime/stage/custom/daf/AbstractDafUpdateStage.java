package com.intentia.iec.pipeline.runtime.stage.custom.daf;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.xml.sax.SAXException;

import com.intentia.icp.common.CMException;
import com.intentia.icp.common.CMItems;
import com.intentia.icp.common.Connection;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;

/**
 * Defines the usual flow of a search stage when connected to DAF.
 * The usual flow is:
 * 	1. Get query.
 * 	2. Create connection to DAF.
 *	3a. If ID is not found, create item.
 *	3b. If ID is found, search item.
 *	4. Update item.
 *	5. Disconnect.
 *
 * The subclass must create the methods for:
 * 	1. Get query.
 * 	2. Create item.
 * 	3. Process search result.
 *
 */
public abstract class AbstractDafUpdateStage extends AbstractDafStage {
	
	private static final Logger LOG = Logger.getLogger(AbstractDafUpdateStage.class);

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.AbstractPipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public void execute(PipelineContext context) throws PipelineRuntimeException {
		
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
        
        CustomStagesHelper.extractRequestParameters(CustomStagesHelper.getRequest(context));
        XMLRequest request = (XMLRequest) context.getRequest();
        int[] dafStatus = {0};
        XMLResultset result = getEmptyResultSet();
		
		try {
			// parse request to get ID
			parseRequest(request);

			// initialize connection parameters
			initialize();
			LOG.debug("Creating DAF Connection(datastore=" + this.datastore + ", " +
					"username=" + this.username + ", " +
					"password=" + "<hidden>" + ", " +
					"schema=" + this.schema + ", " +
					"language=" + this.language + ", " +
					"sqluid=" + this.sqluid + ", " +
					"sqlpwd=" + "<hidden>" + ", " +
					"jdbcDriver=" + this.jdbcDriver + ", " +
					"jdbcUrl=" + this.jdbcUrl + ")");
			this.connection = new Connection(this.datastore, this.username, this.password, this.schema, this.language, this.sqluid, this.sqlpwd, this.jdbcDriver, this.jdbcUrl);		

			// create connection
			LOG.debug("Connecting to DAF Server");
			this.connection.connect();			
			
			// if key does not exist, add item
			if (isKeyExists() == false) {
				LOG.debug("Key exists=false adding item");
				long startTime = System.currentTimeMillis();
				result = addNewItem();
				long stopTime = System.currentTimeMillis();
				LOG.debug("Total add time: " + (stopTime - startTime) + " ms");
			}
			else {
				// get query string
				LOG.debug("Key exists=true updating item");
				String query = getQuery();
				if (query != null) {
					
					// search for ID
					LOG.debug("Performing DAF Search(query=" + query +
							" startIndex=" + getStartIndex() +
							" resultSize=" + getResultSize() +
							" retrieveOption=" + this.retrieveOption + ")");
					long startTime = System.currentTimeMillis();
					CMItems resultItems = CMItems.search(connection, query, getStartIndex(), getResultSize(), this.retrieveOption);
					long stopTime = System.currentTimeMillis();
					LOG.debug("Total search time: " + (stopTime - startTime) + " ms");

					// update search results
					startTime = System.currentTimeMillis();
					result = updateItems(resultItems, dafStatus);
					stopTime = System.currentTimeMillis();
					LOG.debug("Total update time: " + (stopTime - startTime) + " ms");
				}		
			}
		}
		catch (CMException e) {
			dafStatus[0] = -1;
			LOG.error(e);
		}
		catch (ParametersException e) {
			dafStatus[0] = -2;
			LOG.error(e);
		}
		catch (Exception e) {
			dafStatus[0] = -3;
			LOG.error(e);
		}
		finally {
			// perform clean-up
			if (this.connection != null) {
				boolean ret = this.connection.disconnectSilent();
				this.connection = null;
				LOG.debug("Disconnected to DAF Server: " + ret);
			}

			// if result was provided by subclass, set to context
			if (result != null) {
				context.setResponse(result);
			}

			// if response object (XMLResultset) is present, set the DAF status output parameter
			if (context.getResponse() != null) {
				setDafStatus(context, dafStatus[0]);	
			}

			// set other output parameters, if required by the subclass			
			setOutputParameters(context);
		}		
	}

	/**
	 * Helper method for setting the DAF status output parameter.
	 * @param context
	 * @param status
	 * @throws PipelineRuntimeException
	 */
	private void setDafStatus(PipelineContext context, int status) throws PipelineRuntimeException {
		LOG.debug(DafConstants.DAFSTATUS + "=" + status);
		CustomStagesHelper.setResponseParameter(context, DafConstants.DAFSTATUS, String.valueOf(status));
	}
	
	/**
	 * Parse request object.
	 * @param request
	 * @throws Exception
	 */
	public abstract void parseRequest(XMLRequest request) throws Exception;
	
	/**
	 * Checks if ID is included in the request.
	 * @return
	 */
	public abstract boolean isKeyExists();
	
	/**
	 * Creates a new item and adds it to DAF.
	 * @return the result set
	 * @throws CMException
	 * @throws ResultsetException
	 * @throws ParametersException
	 */
	public abstract XMLResultset addNewItem() throws CMException, ResultsetException, ParametersException;
	
	/**
	 * Updates search results
	 * @param resultItems from DAF
	 * @param dafStatus
	 * @return
	 * @throws CMException
	 */
	public abstract XMLResultset updateItems(CMItems resultItems, int[] dafStatus) throws CMException;
	
	/**
	 * Returns the query string that will be sent to DAF for searching.
	 * @return
	 * @throws ParametersException
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws Exception
	 */
	public abstract String getQuery() throws ParametersException, ParserConfigurationException, SAXException, Exception;
	
	/**
	 * Returns the required start index when searching.
	 * @return
	 */
	public abstract int getStartIndex();
	
	/**
	 * Returns the required result size when searching.
	 * @return
	 */
	public abstract int getResultSize();
	
	/**
	 * Sets other output parameters, if needed.
	 * @param context
	 * @throws PipelineRuntimeException
	 */
	public abstract void setOutputParameters(PipelineContext context) throws PipelineRuntimeException;
}
