package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.connection.ConnectorException;
import com.intentia.iec.connection.IMovexApiResultset;
import com.intentia.iec.connection.IMovexConnection;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.Decimal;

public class GetDynamicPriceFromM3ForDraftAndStandardOrder implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(GetDynamicPriceFromM3ForDraftAndStandardOrder.class);

    private static String ITEM_FIELD = "ItemID";

    private static String List_Price = "ListPrice";

    private static String Net_Price = "ResellPrice";

    private static String Discount_Amount = "DiscountAmount";

    private static String Min_QTY = "MinimumQty";

    private static String Unit_Code = "UnitCode";

    public GetDynamicPriceFromM3ForDraftAndStandardOrder() {
        super();
    }

    public void execute(PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("Inside GetDynamicPriceFromM3ForDraftAndStarndardOrder.execute()");

        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
        XMLRequest xmlRequest = (XMLRequest) context.getRequest();

        if (!(context.getResponse() instanceof XMLResultset)) {
            throw new PipelineRuntimeException("Contained response object MUST be of type 'XMLResultset'!");
        }
        XMLResultset response = (XMLResultset) context.getResponse();
        getDynamicPrice(response, xmlRequest, context);
    }

    private void getDynamicPrice(final XMLResultset xmlItem, XMLRequest xmlRequest, PipelineContext context)
            throws PipelineRuntimeException {
        String itemID = null;
        BigDecimal price = null;
        BigDecimal discountAmt = null;
        BigDecimal totPrice = null;
        BigDecimal priceArr[] = new BigDecimal[3];
        BigDecimal discPrice = null;

        try {
            // loop over <item>
            xmlItem.beforeFirst();

            LOG.debug("xmlItem =" + xmlItem.toString());

            while (xmlItem.moveNext()) {

                XMLIterator xmlOrderline = (XMLIterator) xmlItem.getResultset("OrderLine");

                LOG.debug("xmlOrderLine = " + xmlOrderline.toString());
                xmlOrderline.beforeFirst();

                while (xmlOrderline.moveNext()) {

                    itemID = xmlOrderline.getString(ITEM_FIELD);
                    if (itemID == null) {
                        LOG.debug("itemID was not present in this row, thus it is skipped!");
                        continue;
                        // skip this row, since we cannot compute with null
                        // values
                    } // end of if(itemID == null)

                    BigDecimal listPrice = xmlOrderline.getDecimal(List_Price);
                    BigDecimal netPrice = xmlOrderline.getDecimal(Net_Price);
                    String minQty = xmlOrderline.getString(Min_QTY);

                    System.out.println("list Price = " + listPrice + "netPrice = " + netPrice + " minQty = " + minQty);

                    if (minQty == null)
                        minQty = "1";

                    String unitCode = xmlOrderline.getString(Unit_Code).trim();

                    if (listPrice != null)
                        System.out.println("Inside getDynamicPrice , Item = " + itemID + ", listPrice = "
                                + listPrice.toPlainString());
                    if (netPrice != null)
                        System.out.println("Inside getDynamicPrice , Item = " + itemID + ", netPrice = "
                                + netPrice.toPlainString());

                    priceArr = getPriceFromM3(itemID, minQty, unitCode, xmlRequest, context); // getting
                                                                                                // price
                                                                                                // from
                                                                                                // M3
                                                                                                // Server

                    try {
                        price = priceArr[0];
                    } catch (Exception e) {
                        price = null;
                    }

                    try {
                        discountAmt = priceArr[2];
                    } catch (Exception e) {
                        discountAmt = null;
                    }
                    try {
                        totPrice = priceArr[1];
                    } catch (Exception e) {
                        totPrice = null;
                    }
                    if (price != null && price.doubleValue() > 0) {
                        LOG.debug("Setting M3 Price to List Price : " + price.doubleValue());
                        xmlOrderline.setString(List_Price, Decimal.toString(price));
                    }
                    if (discountAmt != null && discountAmt.doubleValue() > 0) {
                        LOG.debug("Setting M3 discount Price t0 discountamount: " + discountAmt.doubleValue());
                        xmlOrderline.setString(Discount_Amount, Decimal.toString(discountAmt));
                    }
                    if (totPrice != null && totPrice.doubleValue() > 0) {
                        LOG.debug("Setting M3 total Price t0 totalPrice: " + totPrice.doubleValue());
                        xmlOrderline.setString("TotalPrice", Decimal.toString(totPrice));
                    }

                    if ("true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.PROMOTIONS))) {
                        if (discountAmt != null && discountAmt.doubleValue() > 0 && price != null) {

                            discPrice = price.subtract(discountAmt);
                            if (price.compareTo(discPrice) >= 0) {
                                LOG.debug("Setting M3 discounted Price to List Price : " + price.doubleValue());
                                System.out.println("setting discounted price........" + discPrice);
                                xmlOrderline.setString(List_Price, Decimal.toString(discPrice));
                            }

                        }
                    }

                }// end of while(xmlOrderline.moveNext())
            }// end of while(xmlItem.moveNext())
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Failed to get values from result set!", e);
        }
    }

    private BigDecimal[] getPriceFromM3(String itemId, String minQty, String unitCode, XMLRequest request,
            PipelineContext context) throws PipelineRuntimeException {

        BigDecimal salesPrice = null;
        BigDecimal totPrice = null;
        BigDecimal discountAmt1 = null;
        BigDecimal discountAmt2 = null;
        BigDecimal discountAmt3 = null;
        BigDecimal discountAmt4 = null;
        BigDecimal discountAmt5 = null;
        BigDecimal discountAmt6 = null;
        BigDecimal qty = null;
        BigDecimal discountAmt = new BigDecimal(0);

        BigDecimal priceArr[] = new BigDecimal[3];

        try {
            XMLRequest.extractRequestParameters(request);

            LOG.debug("Inside getPriceFromM3() : " + itemId + " " + minQty + " " + unitCode);

            // get a connection to movex and execute the movex call
            IMovexConnection con = (IMovexConnection) CustomStagesHelper.getConnection("esales.OIS320MI");
            try {
                // Build up movex api request
                Map m3Inputs = new HashMap();
                // transaction name must be included
                m3Inputs.put(IMovexConnection.TRANSACTION, "GetPriceLine");
                // transaction input fields
                m3Inputs.put("CONO", request.getParameters().getString("mvxCompany"));
                m3Inputs.put("FACI", request.getParameters().getString("mvxFacility"));
                m3Inputs.put("CUNO", request.getParameters().getString("mvxCUNO"));
                m3Inputs.put("WHLO", request.getParameters().getString("mvxWareHouse"));
                m3Inputs.put("ORTP", request.getParameters().getString("mvxOrderType"));
                m3Inputs.put("ITNO", itemId);
                //Do not pass qty. Let M3 determine the default value. Fix for JT-149537 - Wrong Price Display
		//m3Inputs.put("ORQA", minQty);
                m3Inputs.put("ALUN", unitCode);
                m3Inputs.put("CFIN", "");

                IMovexApiResultset m3result = CustomStagesHelper.callMovex(context, con, m3Inputs, "mvxStatus");

                // salesPrice= m3result.getParamAsString("SAPR");
                // String totPrice= m3result.getParamAsString("LNAM");
                String orderDate = m3result.getParamAsString("ORDT");
                String cur = m3result.getParamAsString("CUCD");
                qty = new BigDecimal(m3result.getParamAsString("ORQA"));

                if (m3result.getParamAsString("SAPR") != null
                        && !m3result.getParamAsString("SAPR").equalsIgnoreCase("")) {
                    salesPrice = new BigDecimal(m3result.getParamAsString("SAPR")); // resetting
                                                                                    // value
                                                                                    // to
                                                                                    // the
                                                                                    // List
                                                                                    // Price
                    System.out.println("Price From M3 = " + salesPrice);
                    priceArr[0] = salesPrice;

                }
                if (m3result.getParamAsString("LNAM") != null
                        && !m3result.getParamAsString("LNAM").equalsIgnoreCase("")) {
                    totPrice = new BigDecimal(m3result.getParamAsString("LNAM")); // resetting
                                                                                    // value
                                                                                    // to
                                                                                    // the
                                                                                    // List
                                                                                    // Price
                    System.out.println("Total Price From M3 = " + totPrice);

                    priceArr[1] = totPrice;
                }

                //No need to calculate for the discount. Fix for JT-149537 - Wrong Price Display
		/*if (m3result.getParamAsString("DIA1") != null
                        && !m3result.getParamAsString("DIA1").equalsIgnoreCase("")) {
                    discountAmt1 = new BigDecimal(m3result.getParamAsString("DIA1"));

                    discountAmt = discountAmt.add(discountAmt1);

                }
                if (m3result.getParamAsString("DIA2") != null
                        && !m3result.getParamAsString("DIA2").equalsIgnoreCase("")) {
                    discountAmt2 = new BigDecimal(m3result.getParamAsString("DIA2")); // resetting
                                                                                        // value
                                                                                        // to
                                                                                        // the
                                                                                        // List
                                                                                        // Price

                    discountAmt = discountAmt.add(discountAmt2);

                }
                if (m3result.getParamAsString("DIA3") != null
                        && !m3result.getParamAsString("DIA3").equalsIgnoreCase("")) {
                    discountAmt3 = new BigDecimal(m3result.getParamAsString("DIA3")); // resetting
                                                                                        // value
                                                                                        // to
                                                                                        // the
                                                                                        // List
                                                                                        // Price

                    discountAmt = discountAmt.add(discountAmt3);
                }
                if (m3result.getParamAsString("DIA4") != null
                        && !m3result.getParamAsString("DIA4").equalsIgnoreCase("")) {
                    discountAmt4 = new BigDecimal(m3result.getParamAsString("DIA4")); // resetting
                                                                                        // value
                                                                                        // to
                                                                                        // the
                                                                                        // List
                                                                                        // Price

                    discountAmt = discountAmt.add(discountAmt4);
                }
                if (m3result.getParamAsString("DIA5") != null
                        && !m3result.getParamAsString("DIA5").equalsIgnoreCase("")) {
                    discountAmt5 = new BigDecimal(m3result.getParamAsString("DIA5")); // resetting
                                                                                        // value
                                                                                        // to
                                                                                        // the
                                                                                        // List
                                                                                        // Price

                    discountAmt = discountAmt.add(discountAmt5);
                }
                if (m3result.getParamAsString("DIA6") != null
                        && !m3result.getParamAsString("DIA6").equalsIgnoreCase("")) {
                    discountAmt6 = new BigDecimal(m3result.getParamAsString("DIA6")); // resetting
                                                                                        // value
                                                                                        // to
                                                                                        // the
                                                                                        // List
                                                                                        // Price

                    discountAmt = discountAmt.add(discountAmt6);
                }*/

                priceArr[2] = discountAmt;

                if (totPrice != null)
                    System.out.println("Total Price = " + totPrice);
                if (orderDate != null)
                    System.out.println("Order date = " + orderDate);
                if (cur != null)
                    System.out.println("Currency = " + cur);

            } finally {
                LOG.debug("Inside getPriceFromM3() closing connection............... ");
                if (con != null) {
                    try {
                        con.close(); // close connection
                    } catch (ConnectorException e) {
                        LOG.error("Failed to close connection!");
                        throw e;
                    }
                }
            }

        } catch (RequestException e) {
            throw new PipelineRuntimeException(e);
        } catch (ParametersException e) {
            throw new PipelineRuntimeException(e);
        } catch (ConnectorException e) {
            throw new PipelineRuntimeException(e);
        }

        return priceArr;
    }

}
