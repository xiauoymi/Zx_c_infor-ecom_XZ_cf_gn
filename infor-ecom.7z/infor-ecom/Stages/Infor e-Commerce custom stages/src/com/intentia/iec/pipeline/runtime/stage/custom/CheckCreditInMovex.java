/*
 * Created on 04-05-2006
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.connection.ConnectorException;
import com.intentia.iec.connection.IMovexApiResultset;
import com.intentia.iec.connection.IMovexConnection;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;

/**
 * <p>
 * The stage calls OIS100MI.CheckCredit to check a customers credit.
 * </p>
 * <p>
 * <b>Input in <code>PipelineContext</code>:</b> Request Parameters:
 * <ul>
 * <li><code>mvxCompany</code></li>
 * <li><code>mvxCustomerNo</code></li>
 * </ul>
 * </p>
 * <p>
 * <b>Generated output in <code>PipelineContext</code>: </b> <br>
 * Output parameters: <code>mvxStatus</code> (error if negative),
 * <code>apiErrorMessage</code>.
 * </p>
 * <p>
 * <code>mvxStatus</code> (integer): <br>
 * Connection error: -1000 <br>
 * </p>
 */
/*
 * The text uses the character code &#64; for @ to avoid to confuse the Java
 * auto formatter.
 */
public class CheckCreditInMovex extends AbstractPipelineStage {

    private static final Logger LOG = Logger.getLogger(SendUserInfoAsMail.class);

    // Input parameters to this stage.
    private static final String CUSTOMER_NO_PARAMETER = "mvxCustomerNo";

    // Internal variables
    private Parameters parameters = null;

    /*
     * (non-Javadoc) Pipeline entry point.
     */
    public void execute(final PipelineContext context) throws PipelineRuntimeException {

        // Verify type of request
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Request MUST be of type XMLRequest!");
        }

        XMLRequest request = (XMLRequest) context.getRequest();

        // Get a connection to Movex - if it fails we return from the stage
        // setting mvxStatus to -1010.
        IMovexConnection con = null;
        try {
            con = (IMovexConnection) CustomStagesHelper.getConnection(ConstantsForSales.OIS100MI);
        } catch (PipelineRuntimeException e) {
            con = null;
        }
        if (con == null) {
            LOG.error("Failed to connect to Movex");
            try {
                CustomStagesHelper.getResponseParameters(context).setint(ConstantsForSales.MVXSTATUS, -1010);
            } catch (ParametersException e) {
                LOG.error("Failed to set response parameters!");
            }
            return;
        }

        try {
            XMLRequest.extractRequestParameters(request);
            parameters = request.getParameters();

            String customerNo = parameters.getString(CUSTOMER_NO_PARAMETER);
            int mvxStatus = -1;
            String apiError = "";

            Map checkCredit = new HashMap();
            checkCredit.put(IMovexConnection.TRANSACTION, ConstantsForSales.CHECK_CREDIT);
            checkCredit.put(ConstantsForSales.CONO, parameters.getString(ConstantsForSales.MVXCOMPANY_PARAM));
            checkCredit.put(ConstantsForSales.CUNO, customerNo);
            IMovexApiResultset rs = CustomStagesHelper
                    .callMovex(context, con, checkCredit, ConstantsForSales.MVXSTATUS);
            if (rs == null) {
                LOG.error("CheckCredit failed (recordset), CUNO = " + customerNo);
            } else if (con.isOk()) {
                mvxStatus = 0;
            } else {
                LOG.error("CheckCredit failed (NOK), CUNO = " + customerNo);
                String lastMsg = con.getLastMessage();
                apiError = lastMsg.substring(16).trim();
            }
            CustomStagesHelper.getResponseParameters(context).setint(ConstantsForSales.MVXSTATUS, mvxStatus);
            CustomStagesHelper.setResponseParameter(context, ConstantsForSales.APIERRORMESSAGE, apiError);

        } catch (RequestException e) {
            throw new PipelineRuntimeException("Failed to operate on request", e);
        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Failed to get parameter from request", e);
        } finally {
            if (con != null) {
                try {
                    con.close();
                } catch (ConnectorException e) {
                    LOG.error("Failed to close connection!");
                }
            }
        }
    }
}
