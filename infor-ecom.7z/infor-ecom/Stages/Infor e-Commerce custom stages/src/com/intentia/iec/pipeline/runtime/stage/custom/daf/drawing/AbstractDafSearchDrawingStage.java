package com.intentia.iec.pipeline.runtime.stage.custom.daf.drawing;

import java.util.Iterator;

import org.apache.log4j.Logger;

import com.intentia.icp.common.CMCollection;
import com.intentia.icp.common.CMCollections;
import com.intentia.icp.common.CMException;
import com.intentia.icp.common.CMItem;
import com.intentia.icp.common.CMItems;
import com.intentia.icp.common.CMResource;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage;

/**
 * Abstract class for a DAF stage that searches Active Drawings.
 *
 */
public abstract class AbstractDafSearchDrawingStage extends AbstractDafSearchStage {
	private static final Logger LOG = Logger.getLogger(AbstractDafSearchDrawingStage.class);
	
	/**
	 * Set to true if the drawing number will be included in the result set.
	 */
	protected boolean outDrawingNumber = false;
	
	/**
	 * Set to true if the item number will be included in the result set.
	 */
	protected boolean outItemNumber = false;

	/**
	 * Set to true if the serial number will be included in the result set.
	 */
	protected boolean outSerialNumber = false;
	
	/**
	 * Set to true if the ID will be included in the result set.
	 */
	protected boolean outID = false;
	
	/**
	 * Set to true if the master image will be included in the result set.
	 */
	protected boolean outImageMaster = false;
	
	/**
	 * Set to true if the original file name will be included in the result set.
	 */
	protected boolean outOrgFileName = false;
	
	/**
	 * Set to true if the hot spots will be included in the result set.
	 */
	protected boolean outHotSpots = false;
	
	/**
	 * Set to true if the drawing name will be included in the result set.
	 */
	protected boolean outName = false;
	
	/**
	 * Set to true if the "is default drawing" will be included in the result set.
	 */
	protected boolean outIsDefault = false;
	
	/**
	 * Set to true if the status will be included in the result set.
	 */
	protected boolean outStatus = false;
	
	/**
	 * Set to true if the check out status will be included in the result set.
	 */
	protected boolean outIsCheckedOut = false;

	@Override
	public XMLResultset processResult(CMItems resultItems, int[] dafStatus) throws CMException {
		if (resultItems == null || resultItems.size() == 0) {
			LOG.debug("No search results found.");
		}
		else {
			LOG.debug("Search result: " + resultItems.size());
		}

		// create an XML object for the results
		String result = toXml(resultItems); 
		LOG.debug(result);
		
		return new XMLResultset(result);
	}
	
	/**
	 * Helper method for creating the XML containing the results.
	 * @param resultItems from DAF
	 * @return
	 * @throws CMException
	 */
	private String toXml(CMItems resultItems) throws CMException {
        StringBuilder buf = new StringBuilder("<?xml version='1.0' encoding='UTF-8'?>"
                + "<resultset object='BlowUpPrint'>");
        
        if (resultItems != null) {
        	for (int i = 0; i < resultItems.size(); i++) {
        		LOG.debug("Processing result #" + (i+1));
        		buf.append("<row ");
    			CMItem item = resultItems.get(i);
    			
    			// get Name
    			if (outName == true && item.getAttributeValue(DafDrawingConstants.ATTRIBUTE_NAME) instanceof String) {
    				String name = (String)item.getAttributeValue(DafDrawingConstants.ATTRIBUTE_NAME);
    				buf.append(DafDrawingConstants.FIELD_NAME + "='" + encodeXML(name) + "' "); 
    			}

    			// get PrintNumber
    			if (outDrawingNumber == true && item.getAttributeValue(DafDrawingConstants.ATTRIBUTE_DRAWING_NUMBER) instanceof String) {
    				String printNumber = (String)item.getAttributeValue(DafDrawingConstants.ATTRIBUTE_DRAWING_NUMBER);
    				buf.append(DafDrawingConstants.FIELD_DRAWING_NUMBER + "='" + encodeXML(printNumber) + "' "); 
    			}
    			
    			// get ItemNumber
    			if (outItemNumber == true && item.getAttributeValue(DafDrawingConstants.ATTRIBUTE_ITEM_NUMBER) instanceof String) {
    				String itemNumber = (String)item.getAttributeValue(DafDrawingConstants.ATTRIBUTE_ITEM_NUMBER);
    				buf.append(DafDrawingConstants.FIELD_ITEM_NUMBER + "='" + encodeXML(itemNumber) + "' "); 
    			}
    			
    			// get SerialNumber
    			if (outSerialNumber == true && item.getAttributeValue(DafDrawingConstants.ATTRIBUTE_SERIAL_NUMBER) instanceof String) {
    				String serialNumber = (String)item.getAttributeValue(DafDrawingConstants.ATTRIBUTE_SERIAL_NUMBER);
    				buf.append(DafDrawingConstants.FIELD_SERIAL_NUMBER + "='" + encodeXML(serialNumber) + "' "); 
    			}    			
    			
    			// get ID
    			if (outID == true) {
    				buf.append(DafDrawingConstants.FIELD_ID + "='" + encodeXML(item.getId()) + "' ");	
    			}
    			
    			// get isDefault
    			if (outIsDefault == true) {
    				Short isDefault = (Short)item.getAttributeValue(DafDrawingConstants.ATTRIBUTE_IS_DEFAULT);
    				buf.append(DafDrawingConstants.FIELD_IS_DEFAULT + "='" + encodeXML(DafDrawingUtils.convertDafIsDefault(isDefault)) + "' "); 
    			}
    			
    			// get status
    			if (outStatus == true) {
    				Short status = (Short)item.getAttributeValue(DafDrawingConstants.ATTRIBUTE_STATUS);
    				buf.append(DafDrawingConstants.FIELD_STATUS + "='" + encodeXML(DafDrawingUtils.convertDafStatus(status)) + "' ");
    			}
    			
    			// get isCheckedOut
    			if (outIsCheckedOut == true) {
    				buf.append(DafDrawingConstants.FIELD_ISCHECKEDOUT + "='" + encodeXML(item.isCheckedOut() ? DafDrawingConstants.YES : DafDrawingConstants.NO) + "' ");
    				buf.append(DafDrawingConstants.FIELD_CHECKEDOUTBY + "='" + encodeXML(item.getCheckedOut()) + "' ");
    			}
    			
    			// if any of the images will be included in the result set
    			if (outImageMaster == true || outOrgFileName == true) {
    				LOG.debug("Retrieving resource itemid=" + item.getId());
        			item.retrieveResources(this.connection);
        			
        			// get ImageMaster
        			CMResource cmResource = item.getResources().getFirstNoneConversionResource();
        			if (cmResource != null) {
            			String imageMaster = null;
            			if (outImageMaster == true) {
            				imageMaster = cmResource.getUrl().toString();	
            			}
            			else if (outOrgFileName == true) {
            				imageMaster = cmResource.getOrgFileName();	
            			}
            			
            			if (imageMaster != null) {
            				buf.append(DafDrawingConstants.FIELD_IMAGE_MASTER + "='" + encodeXML(imageMaster) + "' ");
            			}
        			}
    			}
    			
    			// get hot spots
    			boolean hasCollection = false;
    			if (outHotSpots == true) {
        			boolean first = true;
        			CMCollections collections = item.getCollections(DafDrawingConstants.ATTRIBUTE_HOTSPOTS);
        			if (collections != null) {
        				Iterator<?> it = collections.iterator();
        				if (it != null) {    					
        					while (it.hasNext() == true) {
        						boolean hasWritten = false;
        						CMCollection collection = (CMCollection) it.next();
        						boolean valid = DafDrawingUtils.isValidHotSpot(collection);
        						if (valid == true) {
        							// coordinate
        							if (first == true) {
        								buf.append(">");    								
        								first = false;   								
        							}
        							if (hasWritten == false) {
        								buf.append("<ItemMap ");	
        								hasWritten = true;
        							}
        							hasCollection = true;

        							String coordinates = (String)collection.getAttributeValue(DafDrawingConstants.ATTRIBUTE_COORDINATES);    		    				
        		    				buf.append(DafDrawingConstants.FIELD_COORDINATE + "='" + encodeXML(coordinates) + "' ");
        		    				
        		    				// item number
          							if (first == true) {
        								buf.append(">");    								
        								first = false;   								
        							}
        							if (hasWritten == false) {
        								buf.append("<ItemMap ");	
        								hasWritten = true;
        							}
        							hasCollection = true;

        							String itemNumber = (String)collection.getAttributeValue(DafDrawingConstants.ATTRIBUTE_ITEM_NUMBER);
        		    				buf.append(DafDrawingConstants.FIELD_ITEM_NUMBER + "='" + encodeXML(itemNumber) + "' ");
        		    				
        		    				// code
        		    				String shapeCode = DafDrawingUtils.convertDafShapeCode((Short)collection.getAttributeValue(DafDrawingConstants.ATTRIBUTE_SHAPE_CODE));
        		    				if (shapeCode != null) {
            							if (first == true) {
            								buf.append(">");    								
            								first = false;   								
            							}
            							if (hasWritten == false) {
            								buf.append("<ItemMap ");	
            								hasWritten = true;
            							}
            							hasCollection = true;    		    					

            							buf.append(DafDrawingConstants.FIELD_SHAPE_CODE + "='" + encodeXML(shapeCode) + "' ");
        		    				}
        		    				
        		    				// serial number
        		    				if (outSerialNumber == true) {
            		    				String serialNumber = (String)collection.getAttributeValue(DafDrawingConstants.ATTRIBUTE_SERIAL_NUMBER);
            		    				if (serialNumber != null) {
                							if (first == true) {
                								buf.append(">");    								
                								first = false;   								
                							}
                							if (hasWritten == false) {
                								buf.append("<ItemMap ");	
                								hasWritten = true;
                							}
                							hasCollection = true;    		    					

                							buf.append(DafDrawingConstants.FIELD_SERIAL_NUMBER + "='" + encodeXML(serialNumber) + "' ");
            		    				} 
        		    				}       		    				
        						}
        						
        						if (hasWritten == true) {
        							buf.append("/>");
        						}
            				}
        				}    							
        			}
    			}

    			if (hasCollection == false) {
    				buf.append("/>");	
    			}
    			else {
    				buf.append("</row>");
    			}
        	}
        }
		
        buf.append("</resultset>");
		return buf.toString();
	}
	
	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafStage#getAttributeToDafDatabaseField(java.lang.String)
	 */
	public String getAttributeToDafDatabaseField(String attribute) {
		if (attribute == null) {
			return null;
		}
		else if (DafDrawingConstants.FIELD_ITEM_NUMBER.equals(attribute) == true) {
			return DafDrawingConstants.ATTRIBUTE_ITEM_NUMBER;
		}
		else if (DafDrawingConstants.FIELD_DRAWING_NUMBER.equals(attribute) == true) {
			return DafDrawingConstants.ATTRIBUTE_DRAWING_NUMBER;
		}
		else if (DafDrawingConstants.FIELD_NAME.equals(attribute) == true) {
			return DafDrawingConstants.ATTRIBUTE_NAME;
		}
		else if (DafDrawingConstants.FIELD_SERIAL_NUMBER.equals(attribute) == true) {
			return DafDrawingConstants.ATTRIBUTE_SERIAL_NUMBER;
		}		
		
		return null;
	}
}
