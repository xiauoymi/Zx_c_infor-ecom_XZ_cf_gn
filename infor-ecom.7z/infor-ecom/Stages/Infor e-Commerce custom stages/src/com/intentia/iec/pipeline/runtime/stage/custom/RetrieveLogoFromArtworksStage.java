package com.intentia.iec.pipeline.runtime.stage.custom;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLConnection;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.xml.sax.SAXException;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.pipeline.runtime.PipelineContext;

/**
 * This is a sample implementation of the RetrieveLogoXmlStage. This class
 * accesses a servlet that contains logo information. The logo information is
 * represented as an XML. 
 * It takes as input the Logo ID which is passed via by the Sequential Configurator page.
 * The Logo ID is entered by the user.
 * 
 * The following is a sample XML returned by the servlet:
 * 
  <?xml version="1.0" encoding="ISO-8859-1"?>
  <CustomFeatures>	<Success>true</Success>
	<Message>Please perform the next function</Message>
	<Description>Description</Description>
	<SalesHoldCode>ABC</SalesHoldCode>
	<AutoRelease>Y</AutoRelease>
	<Features>
		<Feature>
			<Description>Logo 1 Desc</Description>
			<ID>ID1</ID>
			<LogoID>1</LogoID>
			<Option>ARIZ</Option>
		</Feature>
		<Feature>
			<Description>Logo 1 Name</Description>
			<ID>ID1</ID>
			<LogoID>1</LogoID>
			<Option>ARIZ</Option>
		</Feature>
		<Feature>
			<Description>Logo 1 Number of colors</Description>
			<ID>ID1</ID>
			<LogoID>1</LogoID>
			<Option>2</Option>
		</Feature>
		<Feature>
			<Description>Logo 1 Approval Status</Description>
			<ID>ID1</ID>
			<LogoID>1</LogoID>
			<Option>APRVDLOGO</Option>
		</Feature>
		<Feature>
			<Description>Logo 1 Sales Type</Description>
			<ID>ID1</ID>
			<LogoID>1</LogoID>
			<Option>CCCUST</Option>
		</Feature>
		<Feature>
			<Description>Logo 1 Color 1</Description>
			<ID>ID1</ID>
			<LogoID>1</LogoID>
			<Option>BLACK</Option>
		</Feature>
		<Feature>
			<Description>Logo 1 Color 2</Description>
			<ID>ID1</ID>
			<LogoID>1</LogoID>
			<Option>BLUE</Option>
		</Feature>
	</Features>
   </CustomFeatures>
 *
 */
public class RetrieveLogoFromArtworksStage extends RetrieveLogoXmlStage {

	/**
	 * The URL of the servlet that returns the XML data.
	 */
	private static String URL = "http://localhost:9083/ConnectorWeb/SchemaRetrieverServlet?ac=1&id=";
	
	/**
	 * The name of the parameter that will contain the Logo ID that will be searched.
	 */
	private static final String PARAMETER_LOGOID = "LogoID";
	
	/**
	 * The name of the parameter that will contain the Bulk Preset URL that will be searched.
	 */
	private static final String PARAMETER_BULKPRESET_URL = "BulkPreset";
	
	/**
	 * Logger.
	 */
	private static final Logger LOG = Logger.getLogger(RetrieveLogoXmlStage.class);
	
	/** 
	 * This method will call the servlet that contains the XML data. The response of the servlet
	 * is converted to a single String and then returned.
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.RetrieveLogoXmlStage#getLogoXml(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public String getLogoXml(PipelineContext context) {
		BufferedReader rd = null;
		String response = null;
		String url = null;

		try {
			// retrieve Logo ID parameter. this will be passed to the servlet			
			String logoId = getParameter(context, PARAMETER_LOGOID);
			LOG.debug("LogoID = " + logoId);
			
			LOG.debug("BulkPreset = " + getParameter(context, PARAMETER_BULKPRESET_URL));
			// retrieve Bulk Preset parameter. this will be passed to the servlet
			if (getParameter(context, PARAMETER_BULKPRESET_URL) != null && !getParameter(context, PARAMETER_BULKPRESET_URL).trim().isEmpty()) {
				url = URLDecoder.decode(getParameter(context, PARAMETER_BULKPRESET_URL), "UTF-8");
				LOG.debug("URL = " + URL);
			}else {
				url = URL;
			}
			

			// connect to the servlet if Logo ID was provided
			
			if (logoId != null) {
				// create the complete URL.
				url = url + logoId;
				
				// connect to the servlet
				LOG.debug("Opening ArtWorks server = " + url);
				URLConnection conn = new URL(url).openConnection();
				HttpURLConnection connection = (HttpURLConnection) conn;

				connection.setRequestMethod("GET");
				connection.setDoOutput(true);				

				// read response
				rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				String line = "";
				response = "";
				
				// iterate thru the response, creating a single String object
				LOG.debug("Setting ArtWorks response");
				while ((line = rd.readLine()) != null) {
					response += line;
				}
			}
			else {
				LOG.debug("Logo ID was not specified. Skipping stage.");
			}
		} catch (Exception e) {
			// log error
			e.printStackTrace();
			LOG.error(e);			
		}
		finally {
			if (rd != null) {
				try {
					rd.close();
				} catch (IOException e) {						
					LOG.error(e);
				}
				rd = null;
			}
		}	

		return response;
	}

	/*
	 * The <Feature> tag contains the questions and answers.
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.RetrieveLogoXmlStage#getQuestionAndAnswerContainer()
	 */
	public String getQuestionAndAnswerContainer() {
		return "Feature";
	}
	
	/* 
	 * The <Description> tag contains the question tag.
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.RetrieveLogoXmlStage#getQuestionTag()
	 */
	public String getQuestionTag() {
		return "ID";
	}
	
	/* 
	 * The <Option> tag contains the answer.
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.RetrieveLogoXmlStage#getAnswerTag()
	 */
	public String getAnswerTag() {
		return "Option";
	}

	/* 
	 * The unit tag is not used.
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.RetrieveLogoXmlStage#getUnitTag()
	 */	
	public String getUnitTag() {		
		return null;
	}
	
	/**
	 * Retrieves the parameter that will contain the Logo ID that will be searched.
	 * @param context
	 * @param parameter
	 * @return
	 * @throws ParametersException
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws Exception
	 */
	private String getParameter(PipelineContext context, String parameter) throws ParametersException, ParserConfigurationException, SAXException, Exception {
		XMLRequest request = (XMLRequest)context.getRequest();
		Parameters params = request.getParameters();
		
		return params.getString(parameter);
	}
}
