package com.intentia.iec.pipeline.runtime.integration.ia.utils;

import sun.misc.BASE64Encoder;

public class IaAuthTokenEncryptor {
	protected static final BASE64Encoder _base64Encoder = new BASE64Encoder();
    private static final char[] _kStf = {'\u0069', '\u0023', '\u00A1', '\u00CD', '\u0047', '\u0082',
        '\u00F3', '\u002D', '\u0010', '\u0028', '\u0066', '\u0024',
        '\u00B3', '\u0043', '\u00A2', '\u0009', '\u0067', '\u003B',
        '\u00D4', '\u0009', '\u00F5', '\u0043', '\u0060', '\u00CF',
        '\u0014', '\u0076', '\u0021', '\u00F5', '\u00B7', '\u0083',
        '\u0056', '\u002C', '\u0055', '\u00C4', '\u0028', '\n', /* '\u000a' <--> '\n'. */
        '\u0056', '\u0024', '\u0071', '\u0063', '\u00E4', '\u0066'};

    /**
     * XOR encypt a string using the RightPoint private key.
     * @param input the input String.
     * @return the encryped String.
     */
    public static String applyXOR(String input) {
        return applyXOR(input, _kStf);
    }

    /**
     * XOR encrypt a String with the given key.
     * @param input the string to encrypt.
     * @param key the key to XOR against.
     * @return the encrypted String.
     */
    public static String applyXOR(String input, char[] key) {
        char[] chars = new char[input.length()];
        char curChar = 0;
        int curKeyPos = 0;

        input.getChars(0, chars.length, chars, 0);
        for (int curCharPos = 0; curCharPos < chars.length; curCharPos++) {
            curChar = (char) (chars[curCharPos] ^ key[curKeyPos]);
            if (curChar == 0) {
                chars[curCharPos] = chars[curCharPos];
            } else {
                chars[curCharPos] = curChar;
            }
            curKeyPos++;
            if (curKeyPos == 42) {
                curKeyPos = 0;
            }
        }
        return new String(chars);
    }

}
