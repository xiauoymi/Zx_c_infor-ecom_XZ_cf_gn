/*
 * Created on 03-03-2006
 */
package com.intentia.iec.pipeline.runtime.custom.pim;

import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;

import java.io.CharArrayWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntime;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.util.FastStringBuffer;

/**
 * 
 * @author PEDJES0
 * 
 */
public class CatalogIntegrator {
    protected static final Logger LOG = Logger.getLogger(CatalogIntegrator.class);

    private CharArrayWriter writer = null;

    private XMLRequestWriter requestWriter = null;

    private String catalogName = null;

    private String catalogID = null;

    private Boolean updateCategoryExplosions = Boolean.FALSE;

    private Boolean generateVisibility = Boolean.FALSE;

    private Boolean cleanupProducts = Boolean.FALSE;

    private List productRelationUpdates = null;

    private List productRelationDeletes = null;

    // Make these static??

    private PipelineRuntime categoryCommitPipeline = null;

    private PipelineRuntime categoryDeletePipeline = null;

    private PipelineContext categoryContext = null;

    private PipelineRuntime productCommitPipeline = null;

    private PipelineRuntime productDeletePipeline = null;

    private PipelineContext productContext = null;

    private PipelineRuntime productRelationCommitPipeline = null;

    private PipelineRuntime productRelationDeletePipeline = null;

    private PipelineContext productRelationContext = null;

    private PipelineRuntime itemCommitPipeline = null;

    private PipelineRuntime itemDeletePipeline = null;

    private PipelineContext itemContext = null;

    private PipelineRuntime pimCatalogFinalizePipeline = null;

    private PipelineContext pimCatalogContext = null;

    private static final String PIPELINE_PACKAGE_PART = "com.intentia.iec.runtime.pipeline.";

    private static final String CATEGORY_BO = "Category";

    private static final String CATEGORY_COMMIT_METHOD = "IntegrateWithPIM";

    private static final String CATEGORY_DELETE_METHOD = "Delete";

    private static final String PRODUCT_BO = "Product";

    private static final String PRODUCT_COMMIT_METHOD = "IntegrateWithPIM";

    private static final String PRODUCT_DELETE_METHOD = "Delete";

    private static final String PRODUCTRELATION_BO = "ProductRelation";

    private static final String PRODUCTRELATION_COMMIT_METHOD = "IntegrateWithPIM";

    private static final String PRODUCTRELATION_DELETE_METHOD = "Delete";

    private static final String ITEM_BO = "Item";

    private static final String ITEM_COMMIT_METHOD = "IntegrateWithPIM";

    private static final String ITEM_DELETE_METHOD = "Delete";

    private static final String PIMCATALOG_BO = "PIMCatalog";

    private static final String PIMCATALOG_FINALIZE_METHOD = "FinalizeIntegration";

    private final String imageCatalogPrefix;

    private final boolean handleMultipleCatalogs;

    private final String visibilityCatalogID;

    private final ImageFileHandler imageHandler;

    static {
        System.setProperty("javax.xml.stream.XMLInputFactory", "weblogic.xml.stax.XMLStreamInputFactory");
        System.setProperty("javax.xml.stream.XMLOutputFactory", "weblogic.xml.stax.XMLStreamOutputFactory");
    }

    public CatalogIntegrator(final String imageCatalogPrefix, final boolean handleMultipleCatalogs,
            final String visibilityCatalogID, final ImageFileHandler imageHandler) {
        this.imageCatalogPrefix = imageCatalogPrefix;
        this.handleMultipleCatalogs = handleMultipleCatalogs;
        this.visibilityCatalogID = visibilityCatalogID;
        this.imageHandler = imageHandler;
    }

    public final String integrateCatalogXML(final File deltaXML) throws CatalogIntegrationException,
            XMLStreamException, CatalogParserException, CatalogImageException {

        InputStream in = null;
        try {
            in = new FileInputStream(deltaXML);

            return integrateCatalogXML(in);
        } catch (FileNotFoundException e) {
            throw new CatalogIntegrationException(e);
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    // Failed logging file. Not doing anything but logging,
                    // since execution might continue without problems.
                    FastStringBuffer error = new FastStringBuffer();
                    error.append("Failed closing catalog XML file '");
                    error.append(deltaXML.getAbsolutePath());
                    error.append("'. ");
                    LOG.error(error.toString());
                }
            }
        }
    }

    public final String integrateCatalogXML(final Reader reader) throws PipelineRuntimeException,
            CatalogIntegrationException, XMLStreamException, CatalogParserException, CatalogImageException {
        XMLStreamReader parser = XMLInputFactory.newInstance().createXMLStreamReader(reader);
        PIMReader pimReader = createPIMReader(parser);

        integratePIMCatalog(pimReader);
        // Product relations must be collected through out the
        // process and inserted in the end, in order to make the
        // replication work. This because a RelatedProductID might
        // otherwise not have been created yet.
        commitProductRelations();

        finalizeIntegration();

        return contructCatalogName();
    }

    public final String integrateCatalogXML(final InputStream in) throws CatalogIntegrationException,
            XMLStreamException, CatalogParserException, CatalogImageException {
        XMLStreamReader parser = XMLInputFactory.newInstance().createXMLStreamReader(in);
        PIMReader pimReader = createPIMReader(parser);

        integratePIMCatalog(pimReader);
        // Product relations must be collected through out the
        // process and inserted in the end, in order to make the
        // replication work. This because a RelatedProductID might
        // otherwise not have been created yet.
        commitProductRelations();

        finalizeIntegration();

        return contructCatalogName();
    }

    private String contructCatalogName() {
        if (catalogName != null) {
            FastStringBuffer buffer = new FastStringBuffer();
            buffer.append(catalogID);
            buffer.append("(");
            buffer.append(catalogName);
            buffer.append(")");
            return buffer.toString();
        }
        return catalogID;
    }

    private void integratePIMCatalog(final PIMReader pimReader) throws CatalogIntegrationException, XMLStreamException,
            CatalogParserException, CatalogImageException {
        XMLRequest request = null;
        Entity entity = null;
        if (pimReader.hasCatalog()) {
            switch (pimReader.readCatalogStatus()) {
            case PIMStatus.UPDATED:
            case PIMStatus.ADDED:
                entity = pimReader.readUpdate();
                integratePIMImage(pimReader, entity);
                request = toRequest(entity);
                catalogID = pimReader.getCatalogID();
                catalogName = pimReader.getCatalogName();
                commitCategory(request);
                integratePIMSections(pimReader);
                integratePIMProducts(pimReader);
                integratePIMItems(pimReader);
                break;
            case PIMStatus.UNMODIFIED:
                pimReader.skipCatalog();
                catalogID = pimReader.getCatalogID();
                catalogName = pimReader.getCatalogName();
                Entity images = integratePIMImage(pimReader, ConstantsForSales.PCM_CATALOG);
                if (images != null) {
                    request = toRequest(images);
                    commitCategory(request);
                }
                integratePIMSections(pimReader);
                integratePIMProducts(pimReader);
                integratePIMItems(pimReader);
                break;
            case PIMStatus.REMOVED:
                // TODO is it enough to execute delete on main category?????
                DeleteSet delete = pimReader.readSectionDelete();
                catalogID = pimReader.getCatalogID();
                catalogName = pimReader.getCatalogName();
                request = toRequest(delete);
                deleteCategory(request);
                break;
            default:
                FastStringBuffer error = new FastStringBuffer();
                error.append("Status '");
                error.append(PIMStatus.toString(pimReader.readItemStatus()));
                error.append("' not allowed for PIM catalog element.");
                throw new CatalogParserException(error.toString());
            }
        }
    }

    private void integratePIMChildSections(final PIMReader pimReader) throws CatalogIntegrationException,
            XMLStreamException, CatalogParserException, CatalogImageException {
        if (pimReader.hasChildSections()) {
            integratePIMSections(pimReader);
        }
    }

    private void integratePIMSections(final PIMReader pimReader) throws CatalogIntegrationException,
            XMLStreamException, CatalogParserException, CatalogImageException {
        XMLRequest request;
        while (pimReader.hasSection()) {
            switch (pimReader.readSectionStatus()) {
            case PIMStatus.UPDATED:
                Entity update = pimReader.readUpdate();
                integratePIMImage(pimReader, update);
                request = toRequest(update);
                commitCategory(request);

                // Integrate child sections
                integratePIMChildSections(pimReader);

                // Integrate any Product or Item info that the section
                // contains
                integratePIMProducts(pimReader);
                integratePIMItems(pimReader);
                break;
            case PIMStatus.CONNECTED:
                // TODO implement connected as an update of the
                // ParentCategoryID only
                updateCategoryExplosions = Boolean.TRUE;
                generateVisibility = Boolean.TRUE;

                Entity con = pimReader.readUpdate();
                integratePIMImage(pimReader, con);
                request = toRequest(con);
                commitCategory(request);

                // Integrate child sections
                integratePIMChildSections(pimReader);

                // Integrate any Product or Item info that the section
                // contains
                integratePIMProducts(pimReader);
                integratePIMItems(pimReader);
                break;
            case PIMStatus.ADDED:
                updateCategoryExplosions = Boolean.TRUE;
                generateVisibility = Boolean.TRUE;
                Entity insert = pimReader.readInsert();
                integratePIMImage(pimReader, insert);
                request = toRequest(insert);
                commitCategory(request);

                // Integrate child sections
                integratePIMChildSections(pimReader);

                // Integrate any Product or Item info that the section
                // contains
                integratePIMProducts(pimReader);
                integratePIMItems(pimReader);
                break;
            case PIMStatus.REMOVED:
                updateCategoryExplosions = Boolean.TRUE;
                generateVisibility = Boolean.TRUE;
                cleanupProducts = Boolean.TRUE;

                request = toRequest(pimReader.readSectionDelete());

                // Integrate child sections - child categories must be deleted
                // before the category corresponding to this section can be
                // deleted. This because e-Sales database constraints will
                // otherwise prevent the deletion of this category.
                // This implies that a structure in delta.xml with status
                // REMOVED should also contain all child structures (all with
                // status REMOVED) in order for delete integration to work.
                // 
                // It is not necessary to delete descendent products and items.
                // Products might be present in several catalogs. Even though a
                // product has been removed from one catalog it might still be
                // present in others. A product is therefore never deleted
                // during reading of delta.xml, but just disconnected from its
                // parent category. (This happens automaticly when deleting
                // parent category). A stored procedure will later delete all
                // products not having a parent category.
                // Items are not deleted at all, because they should be deleted
                // by M3 replication.
                integratePIMChildSections(pimReader);

                // Child categories (if any) have been deleted.
                // Now delete the category.
                deleteCategory(request);
                break;
            case PIMStatus.DISCONNECTED:
                updateCategoryExplosions = Boolean.TRUE;
                generateVisibility = Boolean.TRUE;
                // We do not integrate child sections or products, when a
                // section has the status of disconnected. This because the
                // section will be found elsewhere in the catalog, where it is
                // updated if necessary.
                request = toRequest(pimReader.readSectionDisconnect());
                commitCategory(request);
                break;
            case PIMStatus.UNMODIFIED:
                pimReader.skipSection();
                Entity images = integratePIMImage(pimReader, ConstantsForSales.PCM_STRUCTURE);
                if (images != null) {
                    request = toRequest(images);
                    commitCategory(request);
                }

                // Integrate child sections
                integratePIMChildSections(pimReader);

                integratePIMProducts(pimReader);
                integratePIMItems(pimReader);
                break;
            default:
                FastStringBuffer error = new FastStringBuffer();
                error.append("Error when integrating PIM catalog with e-Sales. Status '");
                error.append(PIMStatus.toString(pimReader.readSectionStatus()));
                error.append("' recognized, but not allowed for sections.");
                throw new CatalogParserException(error.toString());
            }
        }
    }

    private void integratePIMProducts(final PIMReader pimReader) throws CatalogIntegrationException,
            XMLStreamException, CatalogParserException, CatalogImageException {
        XMLRequest request = null;
        while (pimReader.hasProduct()) {
            switch (pimReader.readProductStatus()) {
            case PIMStatus.UPDATED:
            case PIMStatus.UNMODIFIED:
                // An unmodified product might still have modified images or
                // modified product relations. Therefore check if an image
                // update is necessary and likewise for the product
                // relations. An unmodified product might also contain
                // item/article updates.

                Entity update = pimReader.readUpdate();
                integratePIMImage(pimReader, update);
                request = toRequest(update);
                commitProduct(request);
                collectProductRelations(pimReader);
                integratePIMItems(pimReader);
                break;
            case PIMStatus.ADDED:
                generateVisibility = Boolean.TRUE;

                Entity insert = pimReader.readInsert();
                integratePIMImage(pimReader, insert);
                request = toRequest(insert);
                commitProduct(request);
                collectProductRelations(pimReader);
                integratePIMItems(pimReader);
                break;
            case PIMStatus.REMOVED:
            case PIMStatus.DISCONNECTED:
                generateVisibility = Boolean.TRUE;
                cleanupProducts = Boolean.TRUE;
                // When a product is DISCONNECTED we expect it to be
                // inserted in another place. Therefore just remove the
                // product-category relation.
                // When a product is REMOVED it might still exist in another
                // catalog also integrated with e-Sales. Therefore just
                // remove the product-category relation. A stored procedure
                // will clean up products without parent categories after
                // this custom stage exection.
                request = toRequest(pimReader.readProductDisconnect());
                deleteProduct(request);
                break;
            case PIMStatus.CONNECTED:
                generateVisibility = Boolean.TRUE;
                // TODO Replace this by a pimReader.readConnected()
                Entity con = pimReader.readInsert();
                integratePIMImage(pimReader, con);
                request = toRequest(con);
                commitProduct(request);
                collectProductRelations(pimReader);
                integratePIMItems(pimReader);
                break;
            /*
             * case PIMStatus.UNMODIFIED: // An unmodified product might still
             * have modified images or // modified product relations. Therefore
             * check if an image // update is necessary and likewise for the
             * product // relations. An unmodified product might also contain //
             * item/article updates. pimReader.skipProduct(); Entity images =
             * integratePIMImage(pimReader,ConstantsForSales.PCM_PRODUCT); if
             * (images != null) { request = toRequest(images);
             * commitProduct(request); } collectProductRelations(pimReader);
             * integratePIMItems(pimReader); break;
             */
            default:
                FastStringBuffer error = new FastStringBuffer();
                error.append("Status '");
                error.append(PIMStatus.toString(pimReader.readProductStatus()));
                error.append("' not allowed for PIM products");
                throw new CatalogParserException(error.toString());
            }
        }
    }

    private void integratePIMItems(final PIMReader pimReader) throws CatalogIntegrationException, XMLStreamException,
            CatalogParserException, CatalogImageException {
        XMLRequest request = null;
        while (pimReader.hasItem()) {
            switch (pimReader.readItemStatus()) {
            case PIMStatus.UPDATED:
                Entity update = pimReader.readUpdate();
                integratePIMImage(pimReader, update);
                request = toRequest(update);
                commitItem(request);
                break;
            case PIMStatus.ADDED:
                generateVisibility = Boolean.TRUE;
                // TODO Items connected to a category can be ADDED instead
                // of updated into the category or???
                Entity added = pimReader.readUpdate();
                integratePIMImage(pimReader, added);
                request = toRequest(added);
                commitItem(request);
                break;
            case PIMStatus.CONNECTED:
                generateVisibility = Boolean.TRUE;
                // TODO Replace this by a connected request.
                Entity connected = pimReader.readUpdate();
                integratePIMImage(pimReader, connected);
                request = toRequest(connected);
                commitItem(request);
                break;
            case PIMStatus.REMOVED:
            case PIMStatus.DISCONNECTED:
                generateVisibility = Boolean.TRUE;
                // When an item/article is DISCONNECTED we expect it to be
                // inserted in another place. Therefore just remove the
                // item-category or item-product relation.
                // Items are replicated from M3. They should therefore also be
                // deleted by M3 replication. Therefore just remove the
                // item-category/item-product relation - make a disconnect.
                request = toRequest(pimReader.readItemDisconnect());
                deleteItem(request);
                break;
            case PIMStatus.UNMODIFIED:
                pimReader.skipItem();
                Entity entity = integratePIMImage(pimReader, ConstantsForSales.PCM_ARTICLE);
                if (entity != null) {
                    request = toRequest(entity);
                    commitItem(request);
                }
                break;
            default:
                FastStringBuffer error = new FastStringBuffer();
                error.append("Status '");
                error.append(PIMStatus.toString(pimReader.readItemStatus()));
                error.append("' not allowed for PIM articles");
                throw new CatalogParserException(error.toString());
            }
        }
    }

    private void integratePIMImage(final PIMReader pimReader, final Entity entity) throws CatalogIntegrationException,
            CatalogParserException, XMLStreamException, CatalogImageException {
        // We expect only one image and therefore we skip the all images after
        // first occurence
        // of it if there are mutiple image element occurences.
        // structure.

        int cnt = 0;
        String id = null;

        while (pimReader.hasImage()) {
            cnt++;
            switch (pimReader.readImageStatus()) {
            case PIMStatus.UPDATED:
            case PIMStatus.ADDED:
            case PIMStatus.CONNECTED:
                if (cnt > 1) {
                    cnt = 0;
                    pimReader.skipImage();
                    break;
                }
                pimReader.readImageUpdate(entity);
                break;
            case PIMStatus.REMOVED:
            case PIMStatus.DISCONNECTED:
                if (cnt > 1) {
                    cnt = 0;
                    pimReader.skipImage();
                    break;
                }
                pimReader.readImageDelete(entity);
                break;
            case PIMStatus.UNMODIFIED:
                if (cnt > 1) {
                    cnt = 0;
                    pimReader.skipImage();
                    break;
                }
                pimReader.skipImage();
                break;
            default:
                FastStringBuffer error = new FastStringBuffer();
                error.append("Status '");
                error.append(PIMStatus.toString(pimReader.readItemStatus()));
                error.append("' not allowed for PIM images");
                throw new CatalogParserException(error.toString());
            }
        }
    }

    private Entity integratePIMImage(final PIMReader pimReader, String elementType) throws CatalogIntegrationException,
            CatalogParserException, XMLStreamException, CatalogImageException {
        Entity entity = null;
        // We expect only one image and therefore we skip the all images after
        // first occurence
        // of it if there are mutiple image element occurences.
        // structure.

        int cnt = 0;
        String id = null;

        try {
            if (elementType.equalsIgnoreCase(ConstantsForSales.PCM_CATALOG)
                    || elementType.equalsIgnoreCase(ConstantsForSales.PCM_STRUCTURE)) {
                id = (String) (pimReader.getParentIDStack().getLast());
            } else if (elementType.equalsIgnoreCase(ConstantsForSales.PCM_PRODUCT)) {
                id = pimReader.getProductID();
            } else if (elementType.equalsIgnoreCase(ConstantsForSales.PCM_ARTICLE)) {
                id = pimReader.getItemID();
            }
        } catch (Exception ex) {
            LOG.error("Error occurs while calling integratePIMImage() : ", ex);
        }

        while (pimReader.hasImage()) {
            cnt++;

            switch (pimReader.readImageStatus()) {
            case PIMStatus.UPDATED:
            case PIMStatus.ADDED:
            case PIMStatus.CONNECTED:
                if (cnt > 1) {
                    cnt = 0;
                    pimReader.skipImage();
                    break;
                }
                entity = pimReader.readImageUpdate(elementType);
                break;
            case PIMStatus.REMOVED:
                if (cnt > 1) {
                    cnt = 0;
                    pimReader.skipImage();
                    break;
                }
                entity = pimReader.readImageDelete(elementType);
                break;
            case PIMStatus.DISCONNECTED:
                if (cnt > 1) {
                    cnt = 0;
                    pimReader.skipImage();
                    break;
                }
                entity = pimReader.readImageDisconnect(elementType);
                break;
            case PIMStatus.UNMODIFIED:
                if (cnt > 1) {
                    cnt = 0;
                    pimReader.skipImage();
                    break;
                }
                pimReader.skipImage();
                break;
            default:
                FastStringBuffer error = new FastStringBuffer();
                error.append("Status '");
                error.append(PIMStatus.toString(pimReader.readImageStatus()));
                error.append("' not allowed for PIM images");
                throw new CatalogParserException(error.toString());
            }
        }
        return entity;
    }

    private void finalizeIntegration() throws CatalogIntegrationException {
        if (handleMultipleCatalogs) {
            if (LOG.isDebugEnabled()) {
                LOG.debug("Handling multiple catalogs");
            }

            if (visibilityCatalogID.equals(catalogID)) {
                updateCategoryExplosions = Boolean.FALSE;
            } else {
                generateVisibility = Boolean.FALSE;
            }
        }

        if (updateCategoryExplosions.booleanValue() || generateVisibility.booleanValue()
                || cleanupProducts.booleanValue()) {
            FastStringBuffer buffer = new FastStringBuffer("<?xml version='1.0' encoding='UTF-8'?><request><params>");
            buffer.append("<param name='updateCategoryExplosions'>");
            buffer.append(updateCategoryExplosions.booleanValue() ? "Y" : "N");
            buffer.append("</param>");
            buffer.append("<param name='generateVisibility'>");
            buffer.append(generateVisibility.booleanValue() ? "Y" : "N");
            buffer.append("</param>");
            buffer.append("<param name='cleanupProducts'>");
            buffer.append(cleanupProducts.booleanValue() ? "Y" : "N");
            buffer.append("</param>");
            buffer.append("</params></request>");
            XMLRequest request = new XMLRequest(buffer.toString());

            if (pimCatalogFinalizePipeline == null) {
                pimCatalogFinalizePipeline = initPipeline(PIMCATALOG_BO, PIMCATALOG_FINALIZE_METHOD);
                pimCatalogContext = new PipelineContext(PIMCATALOG_BO, PIMCATALOG_FINALIZE_METHOD);
            }
            pimCatalogContext.setRequest(request);
            try {
                pimCatalogFinalizePipeline.execute(pimCatalogContext);
            } catch (PipelineRuntimeException e) {
                throw new CatalogIntegrationException(e);
            }

        }
    }

    private void collectProductRelations(final PIMReader pimReader) throws XMLStreamException, CatalogParserException,
            CatalogIntegrationException {
        while (pimReader.hasProductRelation()) {
            switch (pimReader.readProductRelationStatus()) {
            case PIMStatus.CONNECTED:
                // Product relations are always read as updates. This
                // because a product (with product relations) might exists
                // in two different catalogs, both replicated to e-sales.
                // Therefore updates are required not to try and insert the
                // product relations twice.
                if (productRelationUpdates == null) {
                    productRelationUpdates = new LinkedList();
                }
                productRelationUpdates.add(pimReader.readProductRelationUpdate());
                break;
            case PIMStatus.DISCONNECTED:
                if (productRelationDeletes == null) {
                    productRelationDeletes = new LinkedList();
                }
                productRelationDeletes.add(pimReader.readProductRelationDelete());
                break;
            case PIMStatus.UNMODIFIED:
                pimReader.skipProductRelation();
                break;
            default:
                FastStringBuffer error = new FastStringBuffer();
                error.append("Status '");
                error.append(PIMStatus.toString(pimReader.readProductRelationStatus()));
                error.append("' not allowed for product relations");
                throw new CatalogParserException(error.toString());
            }
        }
    }

    private void commitProductRelations() throws CatalogIntegrationException {
        try {
            if (productRelationUpdates != null) {
                XMLRequest request = toCommitRequest(productRelationUpdates);
                if (productRelationCommitPipeline == null) {
                    productRelationCommitPipeline = initPipeline(PRODUCTRELATION_BO, PRODUCTRELATION_COMMIT_METHOD);
                    productRelationContext = new PipelineContext(PRODUCTRELATION_BO, PRODUCTRELATION_COMMIT_METHOD);
                }
                productRelationContext.setRequest(request);
                productRelationCommitPipeline.execute(productRelationContext);

            }

            if (productRelationDeletes != null) {
                XMLRequest request = toDeleteRequest(productRelationUpdates);
                if (productRelationDeletePipeline == null) {
                    productRelationDeletePipeline = initPipeline(PRODUCTRELATION_BO, PRODUCTRELATION_DELETE_METHOD);
                    productRelationContext = new PipelineContext(PRODUCTRELATION_BO, PRODUCTRELATION_DELETE_METHOD);
                }
                productRelationContext.setRequest(request);
                productRelationDeletePipeline.execute(productRelationContext);
            }
        } catch (PipelineRuntimeException e) {
            throw new CatalogIntegrationException(e);
        }
    }

    private void commitCategory(final XMLRequest request) throws CatalogIntegrationException {
        if (categoryCommitPipeline == null) {
            categoryCommitPipeline = initPipeline(CATEGORY_BO, CATEGORY_COMMIT_METHOD);
            categoryContext = new PipelineContext(CATEGORY_BO, CATEGORY_COMMIT_METHOD);
        }

        categoryContext.setRequest(request);
        try {
            categoryCommitPipeline.execute(categoryContext);
        } catch (PipelineRuntimeException e) {
            throw new CatalogIntegrationException(e);
        }
    }

    private void deleteCategory(final XMLRequest request) throws CatalogIntegrationException {
        if (categoryDeletePipeline == null) {
            categoryDeletePipeline = initPipeline(CATEGORY_BO, CATEGORY_DELETE_METHOD);
            categoryContext = new PipelineContext(CATEGORY_BO, CATEGORY_DELETE_METHOD);
        }

        categoryContext.setRequest(request);
        try {
            categoryDeletePipeline.execute(categoryContext);
        } catch (PipelineRuntimeException e) {
            throw new CatalogIntegrationException(e);
        }
    }

    private void commitProduct(final XMLRequest request) throws CatalogIntegrationException {
        if (productCommitPipeline == null) {
            productCommitPipeline = initPipeline(PRODUCT_BO, PRODUCT_COMMIT_METHOD);
            productContext = new PipelineContext(PRODUCT_BO, PRODUCT_COMMIT_METHOD);
        }

        productContext.setRequest(request);
        try {
            productCommitPipeline.execute(productContext);
        } catch (PipelineRuntimeException e) {
            throw new CatalogIntegrationException(e);
        }
    }

    private void deleteProduct(final XMLRequest request) throws CatalogIntegrationException {
        if (productDeletePipeline == null) {
            productDeletePipeline = initPipeline(PRODUCT_BO, PRODUCT_DELETE_METHOD);
            productContext = new PipelineContext(PRODUCT_BO, PRODUCT_DELETE_METHOD);
        }

        productContext.setRequest(request);
        try {
            productDeletePipeline.execute(productContext);
        } catch (PipelineRuntimeException e) {
            throw new CatalogIntegrationException(e);
        }

    }

    private void commitItem(final XMLRequest request) throws CatalogIntegrationException {
        if (itemCommitPipeline == null) {
            itemCommitPipeline = initPipeline(ITEM_BO, ITEM_COMMIT_METHOD);
            itemContext = new PipelineContext(ITEM_BO, ITEM_COMMIT_METHOD);
        }

        itemContext.setRequest(request);
        try {
            itemCommitPipeline.execute(itemContext);
        } catch (PipelineRuntimeException e) {
            throw new CatalogIntegrationException(e);
        }

    }

    private void deleteItem(final XMLRequest request) throws CatalogIntegrationException {
        if (itemDeletePipeline == null) {
            itemDeletePipeline = initPipeline(ITEM_BO, ITEM_DELETE_METHOD);
            itemContext = new PipelineContext(ITEM_BO, ITEM_DELETE_METHOD);
        }

        itemContext.setRequest(request);
        try {
            itemDeletePipeline.execute(itemContext);
        } catch (PipelineRuntimeException e) {
            throw new CatalogIntegrationException(e);
        }

    }

    /**
     * Method used for unit testing.
     * 
     * @param testPipeline
     *            Test pipeline.
     * @param context
     *            Test pipeline context.
     */
    protected final void setPIMCatalogFinalizePipeline(final PipelineRuntime testPipeline, final PipelineContext context) {
        pimCatalogFinalizePipeline = testPipeline;
        pimCatalogContext = context;
    }

    /**
     * Method used for unit testing.
     * 
     * @param testPipeline
     *            Test pipeline.
     * @param context
     *            Test pipeline context.
     */
    protected final void setCategoryCommitPipeline(final PipelineRuntime testPipeline, final PipelineContext context) {
        categoryCommitPipeline = testPipeline;
        categoryContext = context;
    }

    /**
     * Method used for unit testing.
     * 
     * @param testPipeline
     *            Test pipeline.
     * @param context
     *            Test pipeline context.
     */
    protected final void setCategoryDeletePipeline(final PipelineRuntime testPipeline, final PipelineContext context) {
        categoryDeletePipeline = testPipeline;
        categoryContext = context;
    }

    /**
     * Method used for unit testing.
     * 
     * @param testPipeline
     *            Test pipeline.
     * @param context
     *            Test pipeline context.
     */
    protected final void setProductCommitPipeline(final PipelineRuntime testPipeline, final PipelineContext context) {
        productCommitPipeline = testPipeline;
        productContext = context;
    }

    /**
     * Method used for unit testing.
     * 
     * @param testPipeline
     *            Test pipeline.
     * @param context
     *            Test pipeline context.
     */
    protected final void setProductDeletePipeline(final PipelineRuntime testPipeline, final PipelineContext context) {
        productDeletePipeline = testPipeline;
        productContext = context;
    }

    /**
     * Method used for unit testing.
     * 
     * @param testPipeline
     *            Test pipeline.
     * @param context
     *            Test pipeline context.
     */
    protected final void setProductRelationCommitPipeline(final PipelineRuntime testPipeline,
            final PipelineContext context) {
        productRelationCommitPipeline = testPipeline;
        productRelationContext = context;
    }

    /**
     * Method used for unit testing.
     * 
     * @param testPipeline
     *            Test pipeline.
     * @param context
     *            Test pipeline context.
     */
    protected final void setProductRelationDeletePipeline(final PipelineRuntime testPipeline,
            final PipelineContext context) {
        productRelationDeletePipeline = testPipeline;
        productRelationContext = context;
    }

    /**
     * Method used for unit testing.
     * 
     * @param testPipeline
     *            Test pipeline.
     * @param context
     *            Test pipeline context.
     */
    protected final void setItemCommitPipeline(final PipelineRuntime testPipeline, final PipelineContext context) {
        itemCommitPipeline = testPipeline;
        itemContext = context;
    }

    /**
     * Method used for unit testing.
     * 
     * @param testPipeline
     *            Test pipeline.
     * @param context
     *            Test pipeline context.
     */
    protected final void setItemDeletePipeline(final PipelineRuntime testPipeline, final PipelineContext context) {
        itemDeletePipeline = testPipeline;
        itemContext = context;
    }

    private static PipelineRuntime initPipeline(final String object, final String method)
            throws CatalogIntegrationException {
        // Build full class name
        final String pipelineClass = PIPELINE_PACKAGE_PART + object + "." + method;
        if (LOG.isDebugEnabled()) {
            LOG.debug("Initiating pipeline '" + pipelineClass + "'");
        }

        try {
            Class runtimeClass = Class.forName(pipelineClass);
            return (PipelineRuntime) runtimeClass.newInstance();
        } catch (ClassNotFoundException e1) {
            throw new CatalogIntegrationException("Could not find class '" + pipelineClass + "'", e1);
        } catch (IllegalAccessException e2) {
            throw new CatalogIntegrationException("Illegal access to class '" + pipelineClass + "'", e2);
        } catch (InstantiationException e3) {
            throw new CatalogIntegrationException("Could not instantiate class '" + pipelineClass + "'", e3);
        }
    }

    private XMLRequest toRequest(final Entity entity) throws CatalogIntegrationException {
        initRequestWriter();
        try {
            requestWriter.writeCommitStart();
            requestWriter.write(entity);
            requestWriter.writeCommitEnd();

            return new XMLRequest(writer.toString());
        } catch (XMLStreamException e) {
            throw new CatalogIntegrationException(e);
        } finally {
            writer.reset();
        }
    }

    private XMLRequest toCommitRequest(final List entities) throws CatalogIntegrationException {
        initRequestWriter();
        try {
            requestWriter.writeCommitStart();
            Iterator it = productRelationUpdates.iterator();
            while (it.hasNext()) {
                Entity entity = (Entity) it.next();
                requestWriter.write(entity);
            }

            requestWriter.writeCommitEnd();

            return new XMLRequest(writer.toString());
        } catch (XMLStreamException e) {
            throw new CatalogIntegrationException(e);
        } finally {
            writer.reset();
        }
    }

    private XMLRequest toRequest(final DeleteSet delete) throws CatalogIntegrationException {
        initRequestWriter();
        try {
            requestWriter.writeRequestStart();
            requestWriter.write(delete);
            requestWriter.writeRequestEnd();
            return new XMLRequest(writer.toString());
        } catch (XMLStreamException e) {
            throw new CatalogIntegrationException(e);
        } finally {
            writer.reset();
        }
    }

    private XMLRequest toDeleteRequest(final List deletes) throws CatalogIntegrationException {
        initRequestWriter();
        try {
            requestWriter.writeRequestStart();
            Iterator it = productRelationDeletes.iterator();
            while (it.hasNext()) {
                DeleteSet delete = (DeleteSet) it.next();
                requestWriter.write(delete);
            }

            requestWriter.writeRequestEnd();
            return new XMLRequest(writer.toString());
        } catch (XMLStreamException e) {
            throw new CatalogIntegrationException(e);
        } finally {
            writer.reset();
        }
    }

    private void initRequestWriter() {
        if (requestWriter == null) {
            writer = new CharArrayWriter();
            requestWriter = new XMLRequestWriter(writer);
        }
    }

    private PIMReader createPIMReader(final XMLStreamReader parser) throws XMLStreamException, CatalogParserException {
        String version = ProcessingInstruction.readDeltaVersion(parser);
        if ("1.0".equals(version)) {
            return new PIMReader(parser, imageCatalogPrefix, imageHandler);
        } else {
            throw new CatalogParserException("Can not handle catalog delta XML of version " + version);
        }
    }

}
