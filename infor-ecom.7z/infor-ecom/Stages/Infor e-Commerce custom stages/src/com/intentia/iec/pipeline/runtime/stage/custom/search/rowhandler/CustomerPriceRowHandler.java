package com.intentia.iec.pipeline.runtime.stage.custom.search.rowhandler;

import static com.intentia.iec.pipeline.runtime.stage.custom.search.IndexerUtils.addIndexedField;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.lucene.document.Document;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc;
import com.intentia.iec.pipeline.runtime.stage.custom.search.SearchUtils;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Strings;

/**
 *  Adds customer prices to the index. 
 */
public class CustomerPriceRowHandler implements Jdbc.RowHandler {
    private Document doc = null;

    public CustomerPriceRowHandler(Document doc) {
        this.doc = doc;
    }

    public void processRow(ResultSet rs) throws SQLException, PipelineRuntimeException {
        // field is price_customerid_currency
        String customerId = rs.getString(Strings.Database.Indexing.Item.CustomerPrice.customerId);
        String amount = rs.getString(Strings.Database.Indexing.Item.CustomerPrice.amount);
        String currencyCode = rs.getString(Strings.Database.Indexing.Item.CustomerPrice.currencyCode);
        if (currencyCode != null) {
            String field = Strings.Index.Item.pricePrefix + customerId + "_" + currencyCode;
            String value = SearchUtils.toPaddedString(amount);
            addIndexedField(doc, field.toLowerCase(), value.toLowerCase());
        }
    }
}
