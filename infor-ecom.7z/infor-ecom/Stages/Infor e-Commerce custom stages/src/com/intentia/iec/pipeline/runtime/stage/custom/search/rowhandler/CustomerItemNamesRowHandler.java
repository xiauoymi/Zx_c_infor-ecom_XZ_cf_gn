package com.intentia.iec.pipeline.runtime.stage.custom.search.rowhandler;

import static com.intentia.iec.pipeline.runtime.stage.custom.search.IndexerUtils.addIndexedField;
import static com.intentia.iec.pipeline.runtime.stage.custom.search.IndexerUtils.addTokenizedField;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.lucene.document.Document;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Strings;

/**
 *  Adds customer item names to the index.
 */
public class CustomerItemNamesRowHandler implements Jdbc.RowHandler {
    private Document doc = null;

    public CustomerItemNamesRowHandler(Document doc) {
        this.doc = doc;
    }

    public void processRow(ResultSet rs) throws SQLException, PipelineRuntimeException {
        String usergroupId = rs.getString(Strings.Database.Indexing.Item.CustomerItemID.usergroupId);
        String customerItemId = rs.getString(Strings.Database.Indexing.Item.CustomerItemID.customerItemId);

        addIndexedField(doc, Strings.Index.Item.customerItemIdPrefix + usergroupId, customerItemId.toLowerCase());
        addTokenizedField(doc, Strings.Index.Item.customerItemIdTokenizedPrefix + usergroupId, customerItemId
                .toLowerCase());
    }
}