package com.intentia.iec.pipeline.runtime.stage.custom.search;

import java.io.Serializable;

/**
 * Interface for object used for requesting indexing on a two-server set-up.
 */
public interface IndexerServerRequest extends Serializable {

}
