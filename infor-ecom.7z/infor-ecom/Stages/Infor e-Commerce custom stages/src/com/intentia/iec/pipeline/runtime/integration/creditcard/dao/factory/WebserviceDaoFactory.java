package com.intentia.iec.pipeline.runtime.integration.creditcard.dao.factory;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.integration.creditcard.dao.CreditCardAdminDao;
import com.intentia.iec.pipeline.runtime.integration.creditcard.dao.CreditCardDao;
import com.intentia.iec.pipeline.runtime.integration.creditcard.dao.impl.CreditCardAdminDaoCenposImpl;
import com.intentia.iec.pipeline.runtime.integration.creditcard.dao.impl.CreditCardDaoCenposImpl;
import com.intentia.iec.pipeline.runtime.integration.creditcard.exception.CreditCardConnectionException;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

public class WebserviceDaoFactory extends DaoFactory {

	private static final Logger LOG = Logger.getLogger(WebserviceDaoFactory.class);
	public static String WSDL_ENDPOINT_CREDITCARD;
	public static String WSDL_URL_CREDITCARD;
	public static String WSDL_ENDPOINT_CREDITCARD_ADMIN;
	public static String WSDL_URL_CREDITCARD_ADMIN;
	public static String CREDITCARD_MERCHANT_ID;
	public static String CREDITCARD_USER_ID;
	public static String CREDITCARD_PASSWORD;
	
	public WebserviceDaoFactory(){
		initWSDL();
	}

	public CreditCardDao getCreditCardDao() throws CreditCardConnectionException {
		return new CreditCardDaoCenposImpl();
	}
	
	public CreditCardAdminDao getCreditCardAdminDao() throws CreditCardConnectionException {
		return new CreditCardAdminDaoCenposImpl();
	}

	private void initWSDL(){
		try{
			LOG.debug("Init WSDL...");
			
			SearchPipelineExecuter spe = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "ApplicationData",	"Details");
			spe.setParam("param", "WSDL URL (CreditCard)");
			XMLResultset speResult = spe.execute();
			speResult.beforeFirst();
			while(speResult.moveNext())
				WSDL_URL_CREDITCARD = speResult.getString("ParameterValue");					
			
			spe.setParam("param", "WSDL URL Endpoint (CreditCard)");
			speResult = spe.execute();
			speResult.beforeFirst();
			while(speResult.moveNext())
				WSDL_ENDPOINT_CREDITCARD = speResult.getString("ParameterValue");
			
			spe.setParam("param", "WSDL URL (CreditCardAdmin)");
			speResult = spe.execute();
			speResult.beforeFirst();
			while(speResult.moveNext())
				WSDL_URL_CREDITCARD_ADMIN = speResult.getString("ParameterValue");					
			
			spe.setParam("param", "WSDL URL Endpoint (CCAdmin)");
			speResult = spe.execute();
			speResult.beforeFirst();
			while(speResult.moveNext())
				WSDL_ENDPOINT_CREDITCARD_ADMIN = speResult.getString("ParameterValue");
			
			spe.setParam("param", "CreditCardMerchantID");
			speResult = spe.execute();
			speResult.beforeFirst();
			while(speResult.moveNext())
				CREDITCARD_MERCHANT_ID = speResult.getString("ParameterValue");
			
			spe.setParam("param", "CreditCardUserID");
			speResult = spe.execute();
			speResult.beforeFirst();
			while(speResult.moveNext())
				CREDITCARD_USER_ID = speResult.getString("ParameterValue");
			
			spe.setParam("param", "CreditCardMerchantPassword");
			speResult = spe.execute();
			speResult.beforeFirst();
			while(speResult.moveNext())
				CREDITCARD_PASSWORD = speResult.getString("ParameterValue");
			
		} catch (Exception e) {
			LOG.debug("Error initWSDL", e);
		}	
	}
	
}
