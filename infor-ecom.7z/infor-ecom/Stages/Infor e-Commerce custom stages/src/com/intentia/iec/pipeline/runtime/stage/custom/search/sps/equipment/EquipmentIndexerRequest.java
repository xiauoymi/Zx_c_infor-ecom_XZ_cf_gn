package com.intentia.iec.pipeline.runtime.stage.custom.search.sps.equipment;

import com.intentia.iec.pipeline.runtime.stage.custom.search.IndexerServerRequest;

/**
 * Class that is used for requesting equipment indexing on a two-server set-up.
 */
public class EquipmentIndexerRequest implements IndexerServerRequest {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4815762514666730659L;
	
	private boolean includePrices = false;
	
	/**
	 * Copies the parameter.
	 * @param includePrices - if prices are included in the index
	 */
	public EquipmentIndexerRequest(boolean includePrices) {
		this.includePrices = includePrices;
	}

	/**
	 * Returns true if prices are to be included in the index, false otherwise.
	 * @return true if prices are to be included in the index, false otherwise.
	 */
	public boolean getIncludePrices() {
		return this.includePrices;
	}
}
