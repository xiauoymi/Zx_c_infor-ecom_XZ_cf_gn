package com.intentia.iec.pipeline.runtime.stage.custom;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

public class GetOrderFileItems implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(GetOrderFileItems.class);

    private Parameters parameters = null;

    private static final String FILE_ID_PARAMETER = "FileID";

    private static final String REQUESTED_DELIVERY_PARAMETER = "RequestedDeliveryDate";

    private static final String YOUR_REFERENCE_PARAMETER = "YourReference";

    private static final String CUSTOMER_ORDER_NO_PARAMETER = "CustomerOrderNo";

    private static final String COMMENT_TEXT_PARAMETER = "CommentText";

    private static final String CURRENCY_ID_PARAMETER = "CurrencyID";

    private static final String ORDER_NAME_PARAMETER = "OrderName";

    private static final String SHIPPING_ADDRESS1_PARAMETER = "ShippingAddress1";

    private static final String SHIPPING_COUNTRY_ID_PARAMETER = "ShippingCountryID";

    private static final String SHIPPING_REGION_PARAMETER = "ShippingRegion";

    private static final String SHIPPING_METHOD_ID_PARAMETER = "ShippingMethodID";

    private static final String PAYMENT_METHOD_ID_PARAMETER = "PaymentMethodID";

    private static final String ORDERFILEITEMS_ITEMID_ATTRIB = "ItemID";

    private static final String ORDERFILEITEMS_ORDER_QUANTITY_ATTRIB = "OrderQuantity";

    private static final String ADD_TO_CART_ONLY_PARAM = "addToCartOnly";

    private static final String INCLUDE_NULL_STAUS_PARAM = "includeNullStatus";

    private int fileID = 0;

    private String requestedDeliveryDate = null;

    private String yourReference = null;

    private String customerOrderNo = null;

    private String commentText = null;

    private String currencyID = null;

    private String orderName = null;

    private String shippingAddress1 = null;

    private String shippingCountryID = null;

    private String shippingRegion = null;

    private String shippingMethodID = null;

    private String paymentMethodID = null;

    public void execute(PipelineContext context) throws PipelineRuntimeException {

        getRequestParameters(context);

        addOrderFileItems(context);

    }

    private void getRequestParameters(PipelineContext context) throws PipelineRuntimeException {

        // Verify type of request
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Request MUST be of type XMLRequest!");
        }

        XMLRequest request = (XMLRequest) context.getRequest();

        try {

            XMLRequest.extractRequestParameters(request);
            parameters = request.getParameters();

            // Fetch request parameters
            fileID = parameters.getint(FILE_ID_PARAMETER);
            requestedDeliveryDate = parameters.getString(REQUESTED_DELIVERY_PARAMETER);
            yourReference = parameters.getString(YOUR_REFERENCE_PARAMETER);
            customerOrderNo = parameters.getString(CUSTOMER_ORDER_NO_PARAMETER);
            commentText = parameters.getString(COMMENT_TEXT_PARAMETER);
            currencyID = parameters.getString(CURRENCY_ID_PARAMETER);
            orderName = parameters.getString(ORDER_NAME_PARAMETER);
            shippingAddress1 = parameters.getString(SHIPPING_ADDRESS1_PARAMETER);
            shippingCountryID = parameters.getString(SHIPPING_COUNTRY_ID_PARAMETER);
            shippingRegion = parameters.getString(SHIPPING_REGION_PARAMETER);
            shippingMethodID = parameters.getString(SHIPPING_METHOD_ID_PARAMETER);
            paymentMethodID = parameters.getString(PAYMENT_METHOD_ID_PARAMETER);

        } catch (RequestException e) {
            throw new PipelineRuntimeException(e);
        } catch (ParametersException e) {
            throw new PipelineRuntimeException(e);
        }
    }

    // Save the process file to response
    private XMLResultset getOrderFileitems(int pFileID) throws PipelineRuntimeException {

        SearchPipelineExecuter seOrderItems = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                "OrderFileItem", "List");

        seOrderItems.setParam(FILE_ID_PARAMETER, String.valueOf(pFileID));

        seOrderItems.setParam(ADD_TO_CART_ONLY_PARAM, "Y");

        seOrderItems.setParam(INCLUDE_NULL_STAUS_PARAM, "N");

        XMLResultset rs = seOrderItems.execute();

        return rs;

    }

    private void addOrderFileItems(PipelineContext context) throws PipelineRuntimeException {

        try {
            XMLRequest xmlRequest = (XMLRequest) context.getRequest();

            parameters = xmlRequest.getParameters();

            Document xmlDoc = xmlRequest.getRequestDoc();

            XMLRequestHelper xmlHelper = new XMLRequestHelper(xmlDoc);

            xmlHelper.addEntity();

            Node enityNode = XPathAPI.selectSingleNode(xmlDoc, "request/entities/entity");

            xmlHelper.setAttribute(enityNode, "RequestedDeliveryDate", requestedDeliveryDate);
            xmlHelper.setAttribute(enityNode, "YourReference", yourReference);
            xmlHelper.setAttribute(enityNode, "CustomerOrderNo", customerOrderNo);
            xmlHelper.setAttribute(enityNode, "CommentText", commentText);
            xmlHelper.setAttribute(enityNode, "CurrencyID", currencyID);
            xmlHelper.setAttribute(enityNode, "OrderName", orderName);
            xmlHelper.setAttribute(enityNode, "ShippingAddress1", shippingAddress1);
            xmlHelper.setAttribute(enityNode, "ShippingCountryID", shippingCountryID);
            xmlHelper.setAttribute(enityNode, "ShippingRegion", shippingRegion);
            xmlHelper.setAttribute(enityNode, "ShippingMethodID", shippingMethodID);
            xmlHelper.setAttribute(enityNode, "PaymentMethodID", paymentMethodID);

            XMLResultset orderFileItems = getOrderFileitems(fileID);

            Node entity = XPathAPI.selectSingleNode(xmlDoc, "request/entities/entity");

            LOG.debug("OrderFileItems Count: " + orderFileItems.rowCount());

            for (int i = 0; i < orderFileItems.rowCount(); ++i) {
                xmlHelper.addSubset(entity, "OrderLine");
            }

            NodeList nodeList2 = XPathAPI.selectNodeList(xmlDoc,
                    "request/entities/entity/subsets/subset[@name=\"OrderLine\"]");

            orderFileItems.beforeFirst();

            for (int i = 0; i < nodeList2.getLength() && orderFileItems.moveNext(); i++) {
                Node node = nodeList2.item(i);
                xmlHelper.setAttribute(node, "ItemID", orderFileItems.getString(ORDERFILEITEMS_ITEMID_ATTRIB));
                xmlHelper
                        .setAttribute(node, "Quantity", orderFileItems.getString(ORDERFILEITEMS_ORDER_QUANTITY_ATTRIB));
            }
            xmlHelper.logRequest();

        } catch (RequestException e) {
            throw new PipelineRuntimeException(e);
        } catch (TransformerException e) {
            throw new PipelineRuntimeException(e);
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException(e);
        }

    }

}
