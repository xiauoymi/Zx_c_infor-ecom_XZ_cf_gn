/*
 * 
 */
package com.intentia.iec.pipeline.runtime.custom.pim;

/**
 * @author PEDJES0
 * 
 */
public class CatalogIntegrationException extends Exception {

    /**
     * 
     */
    public CatalogIntegrationException() {
        super();
    }

    /**
     * @param msg
     */
    public CatalogIntegrationException(String msg) {
        super(msg);
    }

    /**
     * @param cause
     */
    public CatalogIntegrationException(Throwable cause) {
        super(cause);
    }

    /**
     * @param msg
     * @param cause
     */
    public CatalogIntegrationException(String msg, Throwable cause) {
        super(msg, cause);
    }

}
