package com.intentia.iec.pipeline.runtime.stage.custom.equipment.location;

/**
 * WGS84 Ellipsoid reference.
 * See http://en.wikipedia.org/wiki/WGS_84 for details.
 *
 *
 */
public class WorldGeodeticSystem1984Converter extends CoordinateConverter{

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.equipment.location.CoordinateConverter#getInverseFlattening()
	 */
	@Override
	public double getInverseFlattening() {		
		return 298.257223563;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.equipment.location.CoordinateConverter#getSemiMajorAxisA()
	 */
	@Override
	public double getSemiMajorAxisA() {		
		return 6378137.0;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.equipment.location.CoordinateConverter#getSemiMajorAxisB()
	 */
	@Override
	public double getSemiMajorAxisB() {		
		return 6356752.314245;
	}
}
