package com.intentia.iec.pipeline.runtime.stage.custom.ia;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.ia.dao.IaDao;
import com.intentia.iec.pipeline.runtime.integration.ia.dao.impl.IaDaoRpImpl;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaConnectionException;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;

public class EndIaSessionStage extends AbstractPipelineStage {

	private static final Logger log = Logger
			.getLogger(GetIaCampaignScoreStage.class);

	private static final String DEFAULT_USER_ID = "0";
	private static final String DEFAULT_USERGROUP_ID = "0";

	@Override
	public void execute(PipelineContext context)
			throws PipelineRuntimeException {

		log.debug("Start EndIaSessionStage.execute() . . .");

		CustomStagesHelper.extractRequestParameters(CustomStagesHelper
				.getRequest(context));
		XMLRequest request = (XMLRequest) context.getRequest();
		Parameters requestParams = request.getParameters();
		
		IaDao dao;
		try {
			String sessionId = requestParams.getString("SessionId");
			String userId = StringUtils.defaultIfEmpty(
					requestParams.getString(ConstantsForSales.USER_ID_PARAM),
					DEFAULT_USER_ID);
			String groupId = StringUtils.defaultIfEmpty(requestParams
					.getString(ConstantsForSales._USERGROUPID_PARAM),
					DEFAULT_USERGROUP_ID);

			dao = new IaDaoRpImpl();
			dao.endSession(sessionId, userId, groupId);

		} catch (IaConnectionException e) {
			log.error(
					"Error while connecting to the Interaction Advisor server",
					e);
		} catch (ParametersException e) {
			throw new PipelineRuntimeException(
					"Error while setting the request params of Logout.EndSession pipeline",
					e);
		} catch (IaRuntimeException e) {
			log.error(
					"Error while retrieving campaigns from the Interaction Advisor server",
					e);
		}
	}
}
