package com.intentia.iec.pipeline.runtime.stage.custom.search;


/**
 * Request used for indexing items or spare parts.
 */
public class ItemIndexerServerRequest implements IndexerServerRequest {

    /**
     * 
     */
    private static final long serialVersionUID = -5249394543075068477L;

    private boolean indexNormalItems = false;

    private boolean isSPSEnabled = false;

    private boolean includeStyleItem = false;

    private boolean includePrices = false;

    /**
     * @param indexNormalItems
     * @param isSPSEnabled
     * @param includeStyleItem
     * @param includePrices
     */
    public ItemIndexerServerRequest(boolean indexNormalItems, boolean isSPSEnabled, boolean includeStyleItem,
            boolean includePrices) {
        this.indexNormalItems = indexNormalItems;
        this.isSPSEnabled = isSPSEnabled;
        this.includeStyleItem = includeStyleItem;
        this.includePrices = includePrices;
    }

    /**
     * @return
     */
    public boolean getIndexNormalItems() {
        return this.indexNormalItems;
    }

    /**
     * @return
     */
    public boolean getIsSPSEnabled() {
        return this.isSPSEnabled;
    }

    /**
     * @return
     */
    public boolean getIncludeStyleItem() {
        return this.includeStyleItem;
    }

    /**
     * @return
     */
    public boolean getIncludePrices() {
        return this.includePrices;
    }
}
