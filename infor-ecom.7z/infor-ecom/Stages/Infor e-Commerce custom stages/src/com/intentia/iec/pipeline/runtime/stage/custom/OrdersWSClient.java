package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import javax.xml.transform.TransformerException;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.integration.erp.dao.OrderDao;
import com.intentia.iec.pipeline.runtime.integration.erp.exception.ErpConnectionException;
import com.intentia.iec.pipeline.runtime.integration.erp.exception.ErpRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.erp.model.Charge;
import com.intentia.iec.pipeline.runtime.integration.erp.model.OrderLinesPrice;
import com.intentia.iec.pipeline.runtime.integration.erp.model.Tax;
import com.intentia.iec.pipeline.runtime.integration.erp.model.LinePrice;
import com.intentia.iec.pipeline.runtime.integration.erp.model.OrderLinePriceRequest;
import com.intentia.iec.pipeline.runtime.integration.erp.model.OrderTotal;
import com.intentia.iec.pipeline.runtime.integration.erp.model.OrderTotalRequest;
import com.intentia.iec.pipeline.runtime.integration.erp.utils.ErpUtilHelper;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;
import com.intentia.iec.pipeline.runtime.integration.erp.dao.factory.*;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Element;

/**
 * OrdersWSClient
 * 
 * Developed by: Gerald Tajonera
 * 
 * OrdersWSClient is a webservice client for GetOrderlinePrice and GetOrderTotal services in SyteLine.
 * 
 * For GetOrderlinePrice, it updates ResellPrice with SalesPrice response; LinePrice with LineAmount response
 * For GetOrderTotal, it updates ... 
 * 
 */
public class OrdersWSClient implements PipelineStage {

	private static final Logger LOG = Logger.getLogger(OrdersWSClient.class);
	private XMLResultset xmlResponse;
	private XMLRequestHelper xmlHelper;
	private XMLRequest xmlRequest;
	private NodeList nodeList;
	private Double grandTotal = 0.0;
	private Double totalPrice = 0.0;
	private Double totalDiscount = 0.0;
	private String accountingEntity;
	private String tenantId;
	private String orderID;
	private String warehouseId;
	private PipelineContext context;
	private String shippingAddressId;
	private Map<String,String> itemShippingAddressIDMap;
	
	public void execute(PipelineContext context) throws PipelineRuntimeException {			

		try {
			if (!(context.getRequest() instanceof XMLRequest)) {
				throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
			}	
			this.context = context;
			xmlRequest = (XMLRequest) context.getRequest();	
			XMLRequest.extractRequestParameters(xmlRequest);
			Document request = xmlRequest.getRequestDoc();
			this.orderID = getOrderIDFromRequest();
			//this.warehouseId = xmlRequest.getParameters().getString("@MvxWarehouse");
			
			this.xmlHelper = new XMLRequestHelper(request);
			Map<String, String> virtualMap = ErpUtilHelper.getVirtualEnterprise(); 
			this.tenantId = virtualMap.get("TenantId");
			this.accountingEntity = virtualMap.get("Facility");
			this.warehouseId=virtualMap.get("Warehouse");
			this.shippingAddressId=xmlRequest.getParameters().getString("shippingAddressId");
			// Get OrderHeader node in the request document
			NodeList orderHeaderNodeList = XPathAPI.selectNodeList(request, "request/entities/entity/keys");
			// Get OrderLine node in the request document
			this.nodeList = XPathAPI.selectNodeList(request,	"request/entities/entity/subsets/subset[@name=\"OrderLine\"]");
			Node orderHeadernode=null;
			
			//Get warehouse
			if(xmlRequest.getParameters().getString("warehouseId")!=null && !xmlRequest.getParameters().getString("warehouseId").trim().equals("")){
				this.warehouseId = xmlRequest.getParameters().getString("warehouseId");
			}
			
			if((this.shippingAddressId!=null && this.shippingAddressId.trim().equals(""))
					||CustomStagesHelper.getKeyValue("Shipping address.User Defined").equals("true")){
				this.shippingAddressId=null;
			}
			
			//Get Current Order
			XMLResultset rsExistingOrderLine=null;
			XMLIterator existingOrderLine=null;
			if(this.orderID!=null && !this.orderID.equals("")){
			rsExistingOrderLine=getExistingOrderline();
			rsExistingOrderLine.moveFirst();
			if(rsExistingOrderLine.getString("MvxShippingAddressID")!=null){
				this.shippingAddressId=rsExistingOrderLine.getString("MvxShippingAddressID");
			}
			rsExistingOrderLine.moveFirst();
			existingOrderLine = (XMLIterator) rsExistingOrderLine.getResultset(ConstantsForSales.ORDERLINE);	
			this.itemShippingAddressIDMap=getOrderLinesShippingAddressID(existingOrderLine);
			existingOrderLine.moveFirst();
			}
			if (this.nodeList!=null && this.nodeList.getLength() > 0) {
				//Call OrderLinePrice Webservice	
				processOrderLineWSRequest();
				
				//Call WS OrderTotal
				if(xmlRequest.getParameters().getString("computeTotal")!=null && xmlRequest.getParameters().getString("computeTotal").equals("Y")){
					this.totalPrice+=getOrderTotal(existingOrderLine);
					this.grandTotal = this.totalPrice;
				}
				else{
					processOrderTotalWSCall(createOrderLine(existingOrderLine));
				}
				
				
				orderHeadernode = orderHeaderNodeList.item(0);
				// set OrderHeader response attributes for Totals...
				this.xmlHelper.setAttribute(orderHeadernode, ConstantsForSales.GRANDTOTAL, Double.toString(this.grandTotal));
				this.xmlHelper.setAttribute(orderHeadernode, ConstantsForSales.TOTALPRICE, Double.toString(this.totalPrice));
				if (this.totalDiscount != 0.0) {
					// negate Discount value
					this.xmlHelper.setAttribute(orderHeadernode, ConstantsForSales.TOTALDISCOUNT, Double.toString(-1*this.totalDiscount));
				} else 
					this.xmlHelper.setAttribute(orderHeadernode, ConstantsForSales.TOTALDISCOUNT, Double.toString(this.totalDiscount));

			} else {
				// Get CurrentOrder XML response
				this.xmlResponse = (XMLResultset) context.getResponse();
				if ((this.xmlResponse == null) || (this.xmlResponse.isEmpty())) {
					//this.xmlResponse.moveFirst();
					if((existingOrderLine != null && existingOrderLine.rowCount()>0)&&
					(xmlRequest.getParameters().getString("computeTotal")!=null && xmlRequest.getParameters().getString("computeTotal").equals("Y"))){
						this.totalPrice+=getOrderTotal(existingOrderLine);
						this.grandTotal = this.totalPrice;
						orderHeadernode = orderHeaderNodeList.item(0);
						if(orderHeadernode != null){
							this.xmlHelper.setAttribute(orderHeadernode, ConstantsForSales.GRANDTOTAL, Double.toString(this.grandTotal));
							this.xmlHelper.setAttribute(orderHeadernode, ConstantsForSales.TOTALPRICE, Double.toString(this.totalPrice));
							if (this.totalDiscount != 0.0) {
								// negate Discount value
								this.xmlHelper.setAttribute(orderHeadernode, ConstantsForSales.TOTALDISCOUNT, Double.toString(-1*this.totalDiscount));
							} else {
								this.xmlHelper.setAttribute(orderHeadernode, ConstantsForSales.TOTALDISCOUNT, Double.toString(this.totalDiscount));
							}
						}
					}
					return;
	            }
				this.xmlResponse.moveFirst();
				this.orderID = xmlResponse.getString("OrderID");
				if((existingOrderLine==null || existingOrderLine.isEmpty())&&(this.orderID!=null && !this.orderID.equals(""))){
					rsExistingOrderLine=getExistingOrderline();
					rsExistingOrderLine.moveFirst();
					if(rsExistingOrderLine.getString("MvxShippingAddressID")!=null){
						this.shippingAddressId=rsExistingOrderLine.getString("MvxShippingAddressID");
					}
					rsExistingOrderLine.moveFirst();
					existingOrderLine = (XMLIterator) rsExistingOrderLine.getResultset(ConstantsForSales.ORDERLINE);	
					this.itemShippingAddressIDMap=getOrderLinesShippingAddressID(existingOrderLine);
					existingOrderLine.moveFirst();
				}
				// Get CurrentOrderLine Resultset response
				this.xmlResponse.moveFirst();
				XMLIterator lines = (XMLIterator) xmlResponse.getResultset(ConstantsForSales.ORDERLINE);
				if ((lines == null) || lines.isEmpty()) {
					return;
				}
				//Call OrderLinePrice & OrderTotalPrice Webservice	
				updateLineFromResponse(lines);
				if(xmlRequest.getParameters().getString("computeTotal")!=null && xmlRequest.getParameters().getString("computeTotal").equals("N")){
					return;
				}
				else if(xmlRequest.getParameters().getString("computeTotal")!=null && xmlRequest.getParameters().getString("computeTotal").equals("Y")){
					//manual computation of order total
					if(existingOrderLine != null){
						this.totalPrice+=getOrderTotal(lines,existingOrderLine);
					} 
					this.grandTotal = this.totalPrice;
				}
				else{
					//call order total webservice
					if(existingOrderLine != null){
						processOrderTotalWSCall(createOrderLineFromResponse(lines,existingOrderLine));					
					} else {
						processOrderTotalWSCall(createOrderLineFromResponse(lines));
					}
				}
				
				updateOrderHeaderTotalsToDB();
			}
		}catch (RequestException e) {
			LOG.error(e.getMessage());
			throw new PipelineRuntimeException(e);
		} catch (Exception e) {
			if(e.getCause() instanceof java.net.ConnectException || e.getCause() instanceof java.net.SocketTimeoutException){
				LOG.error("Error Execute Order Total Data - "+ e.getMessage());				
			} else {				
				LOG.error(e.getMessage());
			}
			setErrorFlag();
		}
	}

	/**
	 * Retrieves OrderID from XMLRequest 
	 * @throws ParametersException
	 * @return String OrderID
	 */
	private String getOrderIDFromRequest() throws ParametersException {
		String orderID = xmlRequest.getParameters().getString("orderID");
		if(orderID == null || orderID.trim().isEmpty()){
			String orderID1 = xmlRequest.getParameters().getString("orderID1");
			orderID = orderID1;
			String orderID2 = xmlRequest.getParameters().getString("orderID2");
			if(orderID1 == null || orderID1.trim().isEmpty()){
				orderID = orderID2;
			}
		}
		return orderID;
	}

	/**
	 * Retrieves Existing Orderlines from Current Order
	 * @param spe
	 * @return XMLIterator Orderlines
	 */
	private XMLResultset getExistingOrderline() {
		SearchPipelineExecuter spe = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
				"CurrentOrder", "GetExistingOrder"); 
		XMLResultset res=null;
		try{
			spe.setBinding("OrderID", this.orderID, "eq");
			res = spe.execute();
		}
		catch(Exception e){
			LOG.debug(e.toString()+" in retrieving current order");
		}
		return res;
	}
	
	private List<LinePrice> createOrderLineFromResponse(XMLIterator lines, XMLIterator currentLines) throws Exception {
		//Iterate OrderLines over NodeList
		
		List<LinePrice> orderLines= new ArrayList<LinePrice>();
		List<String> itemIDList= new ArrayList<String>();
		lines.beforeFirst();
		while(lines.moveNext()){				
			LinePrice orderline = new LinePrice();
			orderline.setItemId(lines.getString("ItemID"));
			itemIDList.add(lines.getString("ItemID"));
			orderline.setQuantity(Double.parseDouble(lines.getString("Quantity")));
			orderline.setUnitCode(ErpUtilHelper.getItemUnit(lines.getString("ItemID")));
			orderline.setWarehouseId(this.warehouseId);				
			orderline.setConfigurationNumber(xmlResponse.getString("ConfigurationID"));
			orderline.setCustomerItemId(xmlResponse.getString("CustomerItemID"));
			
			if(CustomStagesHelper.getKeyValue("ION.Webservice ShippingAddressID").equals("true")){
				if(lines.getString("MvxShippingAddressID")!=null){
					orderline.setShippingAddressId(lines.getString("MvxShippingAddressID"));
				}
				else{
					if(this.itemShippingAddressIDMap!=null){
						if(this.itemShippingAddressIDMap.get(lines.getString("ItemID"))!=null){
							orderline.setShippingAddressId(this.itemShippingAddressIDMap.get(lines.getString("ItemID")));
						}
						else{
							orderline.setShippingAddressId(this.shippingAddressId);
						}
					}
					else{
						orderline.setShippingAddressId(this.shippingAddressId);
					}
				}
			}
			orderLines.add(orderline);
		}
		
		while(currentLines.moveNext()){				
			LinePrice orderline = new LinePrice();
			String itemID=currentLines.getString("ItemID");
			if(!(itemID==null || itemID.equals(""))&& itemIDList.indexOf(itemID)==-1){
				orderline.setItemId(currentLines.getString("ItemID"));
				orderline.setQuantity(Double.parseDouble(currentLines.getString("Quantity")));
				orderline.setUnitCode(ErpUtilHelper.getItemUnit(currentLines.getString("ItemID")));
				orderline.setWarehouseId(this.warehouseId);				
				orderline.setConfigurationNumber(currentLines.getString("ConfigurationID"));
				orderline.setCustomerItemId(currentLines.getString("CustomerItemID"));
				
				if(CustomStagesHelper.getKeyValue("ION.Webservice ShippingAddressID").equals("true")){
					if(currentLines.getString("MvxShippingAddressID")!=null){
						orderline.setShippingAddressId(currentLines.getString("MvxShippingAddressID"));
					}
					else{
						if(this.itemShippingAddressIDMap!=null){
							if(this.itemShippingAddressIDMap.get(currentLines.getString("ItemID"))!=null){
								orderline.setShippingAddressId(this.itemShippingAddressIDMap.get(currentLines.getString("ItemID")));
							}
							else{
								orderline.setShippingAddressId(this.shippingAddressId);
							}
						}
						else{
							orderline.setShippingAddressId(this.shippingAddressId);
						}
					}
				}
				orderLines.add(orderline);
			}
		}
	
		
		return 	orderLines;	
	}
	
	private List<LinePrice> createOrderLine(XMLIterator currentLines) throws TransformerException, Exception{	
		LOG.debug("Inside createOrderLine(XMLIterator currentLines)");
		List<LinePrice> orderLines= new ArrayList<LinePrice>();
		List<String> itemIDList= new ArrayList<String>();
		for (int x = 0; x < nodeList.getLength(); x++) {
			Node node = nodeList.item(x);				
			LinePrice line = new LinePrice();
			String itemId = xmlHelper.getAttribute(node, "ItemID");
			if(itemId == null || "".equals(itemId)){
				//orderLines = ErpUtilHelper.getExistingOrderLines(this.orderID, this.warehouseId);
				break;
			}
			itemIDList.add(itemId);
			line.setItemId(xmlHelper.getAttribute(node, "ItemID"));
			line.setQuantity(new Double(xmlHelper.getAttribute(node, "Quantity")));
			line.setUnitCode(ErpUtilHelper.getItemUnit(xmlHelper.getAttribute(node, "ItemID")));
			line.setWarehouseId(this.warehouseId);				
			line.setConfigurationNumber(xmlHelper.getAttribute(node, "ConfigurationID"));
			line.setCustomerItemId(xmlHelper.getAttribute(node, "CustomerItemID"));
			
			if(CustomStagesHelper.getKeyValue("ION.Webservice ShippingAddressID").equals("true")){
				if(xmlHelper.getAttribute(node,"MvxShippingAddressID")!=null){
					line.setShippingAddressId(xmlHelper.getAttribute(node,"MvxShippingAddressID"));
				}
				else{
					if(this.itemShippingAddressIDMap!=null){
						if(this.itemShippingAddressIDMap.get(itemId)!=null){
							line.setShippingAddressId(this.itemShippingAddressIDMap.get(itemId));
						}
						else{
							line.setShippingAddressId(this.shippingAddressId);
						}
					}
					else{
						line.setShippingAddressId(this.shippingAddressId);
					}
				}
			}
			orderLines.add(line);				
		}
		currentLines.beforeFirst();
		while(currentLines.moveNext()){				
				LinePrice orderline = new LinePrice();
				if(itemIDList.indexOf(currentLines.getString("ItemID"))==-1){
				orderline.setItemId(currentLines.getString("ItemID"));
				orderline.setQuantity(Double.parseDouble(currentLines.getString("Quantity")));
				orderline.setUnitCode(ErpUtilHelper.getItemUnit(currentLines.getString("ItemID")));
				orderline.setWarehouseId(this.warehouseId);				
				orderline.setConfigurationNumber(currentLines.getString("ConfigurationID"));
				orderline.setCustomerItemId(currentLines.getString("CustomerItemID"));
				
				if(CustomStagesHelper.getKeyValue("ION.Webservice ShippingAddressID").equals("true")){
					if(currentLines.getString("MvxShippingAddressID")!=null){
						orderline.setShippingAddressId(currentLines.getString("MvxShippingAddressID"));
					}
					else{
						if(this.itemShippingAddressIDMap!=null){
							if(this.itemShippingAddressIDMap.get(currentLines.getString("ItemID"))!=null){
								orderline.setShippingAddressId(this.itemShippingAddressIDMap.get(currentLines.getString("ItemID")));
							}
							else{
								orderline.setShippingAddressId(this.shippingAddressId);
							}
						}
						else{
							orderline.setShippingAddressId(this.shippingAddressId);
						}
					}
				}
				this.totalPrice+=Double.parseDouble(currentLines.getString("LinePrice"));
				this.grandTotal=this.totalPrice;
				orderLines.add(orderline);
				}
		}
		return orderLines;
	}
	

	private void updateOrderHeaderTotalsToDB() throws PipelineRuntimeException, SQLException {
		PreparedStatement pstmt = null;
		Connection conn = null;
		try {
			conn = (Connection) CustomStagesHelper.getConnection("esales.cursor");			
			String orderUpdate = "UPDATE [OrderHeader] SET [GrandTotal] = ?, [TotalPrice] = ?, [TotalDiscount] = ? WHERE id = ? ";

			xmlResponse.beforeFirst();
			xmlResponse.moveNext();
			// set OrderHeader response attributes for Totals...
			xmlResponse.setString(ConstantsForSales.GRANDTOTAL, Double.toString(grandTotal));
			xmlResponse.setString(ConstantsForSales.TOTALPRICE, Double.toString(totalPrice));
			if (totalDiscount != 0.0) {
				// negate Discount value
				xmlResponse.setString(ConstantsForSales.TOTALDISCOUNT, Double.toString(-1*totalDiscount));
			} else 
				xmlResponse.setString(ConstantsForSales.TOTALDISCOUNT, Double.toString(totalDiscount));

			Document resDoc = xmlResponse.getDocument();
			pstmt = conn.prepareStatement(orderUpdate);

			// Get OrderHeader node in the request document
			NodeList orderHeaderNodeList = XPathAPI.selectNodeList(resDoc, "//row");
			Node orderHeadernode = orderHeaderNodeList.item(0);

			if (orderHeadernode != null) {
				BigDecimal grandTotal = orderHeadernode.getAttributes().getNamedItem(ConstantsForSales.GRANDTOTAL) != null ? 
						ErpUtilHelper.stringToDecimal(orderHeadernode.getAttributes().getNamedItem(ConstantsForSales.GRANDTOTAL).getNodeValue()) : new BigDecimal(0.0);			
						BigDecimal totalPrice = orderHeadernode.getAttributes().getNamedItem(ConstantsForSales.TOTALPRICE) != null ?
								ErpUtilHelper.stringToDecimal(orderHeadernode.getAttributes().getNamedItem(ConstantsForSales.TOTALPRICE).getNodeValue()) : new BigDecimal(0.0);			
								BigDecimal totalDiscount = orderHeadernode.getAttributes().getNamedItem(ConstantsForSales.TOTALDISCOUNT) != null ?
										ErpUtilHelper.stringToDecimal(orderHeadernode.getAttributes().getNamedItem(ConstantsForSales.TOTALDISCOUNT).getNodeValue()) : new BigDecimal(0.0);
										pstmt.setString(1, grandTotal.toString());
										pstmt.setString(2, totalPrice.toString());
										pstmt.setString(3, totalDiscount.toString());
										pstmt.setString(4, orderID);	
										pstmt.executeUpdate();
										pstmt.clearParameters();
			}

		} catch (SQLException se) {
			throw new PipelineRuntimeException("Error executing updateOrderHeaderTotalsFromWS function", se);
		} catch (Exception e) {
			throw new PipelineRuntimeException(e);
		} finally {
			pstmt.close();
			conn.close();
		}
	}


	private void updateLineFromResponse(XMLIterator lines) throws PipelineRuntimeException, ErpConnectionException, Exception {

		try {
			//Create OrderLinePriceRequest object
			OrderLinePriceRequest daoRequest = new OrderLinePriceRequest();
			daoRequest.setTenantId(tenantId);
			daoRequest.setAccountingEntityId(accountingEntity);
			daoRequest.setCurrencyId(xmlRequest.getParameters().getString("@CurrencyCode"));
			daoRequest.setCustomerPartyId(xmlRequest.getParameters().getString("mvxCUNO"));
			daoRequest.setUserName(WebserviceDaoFactory.WEBSERVICEUSERID);

			//Unknown OrderType 
			daoRequest.setOrderType(null);

			//Iterate OrderLines over NodeList
			List<LinePrice> orderLines= new ArrayList<LinePrice>();
			lines.beforeFirst();
			while(lines.moveNext()){				
				LinePrice orderline = new LinePrice();
				orderline.setItemId(lines.getString("ItemID"));
				orderline.setQuantity(Double.parseDouble(lines.getString("Quantity")));
				orderline.setUnitCode(ErpUtilHelper.getItemUnit(lines.getString("ItemID")));
				orderline.setWarehouseId(this.warehouseId);				
				orderline.setConfigurationNumber(lines.getString("ConfigurationID"));
				orderline.setCustomerItemId(lines.getString("CustomerItemID"));
				
				if(CustomStagesHelper.getKeyValue("ION.Webservice ShippingAddressID").equals("true")){
					if(lines.getString("MvxShippingAddressID")!=null){
						orderline.setShippingAddressId(lines.getString("MvxShippingAddressID"));
					}
					else{
						if(this.itemShippingAddressIDMap!=null){
							if(this.itemShippingAddressIDMap.get(lines.getString("ItemID"))!=null){
								orderline.setShippingAddressId(this.itemShippingAddressIDMap.get(lines.getString("ItemID")));
							}
							else{
								orderline.setShippingAddressId(this.shippingAddressId);
							}
						}
						else{
							orderline.setShippingAddressId(this.shippingAddressId);
						}
					}
				}
				orderLines.add(orderline);
			}
			daoRequest.setOrderlines(orderLines);			
			//Get ERP DAO implementation 
			OrderDao wsCallItem = DaoFactory.getDAOFactory().getOrderDao(); 
			OrderLinesPrice wsoutOrderLine = wsCallItem.getOrderLinePrice(daoRequest);

			HashMap<String, String> items = new HashMap<String, String>(); 
			//Update node with WS result 
			for (LinePrice out : wsoutOrderLine.getOrderline()){
				//Iterate over node item
				String itemID = out.getItemId();
				XMLIterator iterLine = getXMLOrderLine(itemID);
				items.put(itemID, itemID);
				Double lineDisPercent = new Double(out.getDiscountAmount()/out.getLineAmount()*100);
				// set OrderLine response attributes for Prices...
				iterLine.setString(ConstantsForSales.RESELLPRICE, Double.toString(out.getSalesPrice()));
				iterLine.setString(ConstantsForSales.LISTPRICE, Double.toString(out.getSalesPrice()));
				iterLine.setString(ConstantsForSales.LINEPRICE, Double.toString(out.getLineAmount()));
				iterLine.setString(ConstantsForSales.LINEDISCOUNT, Double.toString(out.getDiscountAmount()));
				iterLine.setString(ConstantsForSales.LINEDISPERCENT, Double.toString(Double.isNaN(lineDisPercent) ? 0 : lineDisPercent));
				iterLine.setString(ConstantsForSales.LINETOTAL, Double.toString(out.getTotalAmount()));
				iterLine.setString(ConstantsForSales.LINEEXTENDEDAMOUNT, Double.toString(out.getExtendedAmount()));
				iterLine.setString(ConstantsForSales.ITEM_TAX, Double.toString(out.getDistributedChargeAmount()));
				this.totalPrice+= out.getTotalAmount();
				this.grandTotal=this.totalPrice;
			}
			
			XMLIterator iterLine = (XMLIterator) xmlResponse.getResultset(ConstantsForSales.ORDERLINE);
			iterLine.beforeFirst();
			while (iterLine.moveNext()) {
				String currItemID = iterLine.getString("ItemID");
				String key = items.get(currItemID);
				if (key == null){
					CustomStagesHelper.updateRsAttribute(iterLine, ConstantsForSales.RESELLPRICE, "-1.00");
					CustomStagesHelper.updateRsAttribute(iterLine, ConstantsForSales.LISTPRICE, "-1.00");
					CustomStagesHelper.updateRsAttribute(iterLine, ConstantsForSales.LINEPRICE, "-1.00");
					CustomStagesHelper.updateRsAttribute(iterLine, ConstantsForSales.LINEDISCOUNT, "-1.00");
					CustomStagesHelper.updateRsAttribute(iterLine, ConstantsForSales.LINEDISPERCENT, "-1.00");
					CustomStagesHelper.updateRsAttribute(iterLine, ConstantsForSales.LINETOTAL, "-1.00");
					CustomStagesHelper.updateRsAttribute(iterLine, ConstantsForSales.LINEEXTENDEDAMOUNT, "-1.00");
					//CustomStagesHelper.updateRsAttribute(iterLine, ConstantsForSales.ITEM_TAX, "-1.00");
				}
			}			

			if(!wsoutOrderLine.getOrderline().isEmpty()){
				orderlineDBUpdates(wsoutOrderLine.getOrderline());
			}

			if (wsoutOrderLine.isHasWSCallError()){
				StringBuffer sb = new StringBuffer();
				sb.append("Error Code: ").append(wsoutOrderLine.getMsgCodeError()).append(" Description: ").append(wsoutOrderLine.getMsgError());
				try {
					if(xmlResponse == null){
						XMLResultset response = new XMLResultset();
						context.setResponse(response);
					}									
					CustomStagesHelper.setResponseParameter(context, "WSErrorMsg", sb.toString());
				} catch (PipelineRuntimeException e) {
					LOG.error(e.toString());
				}
				setErrorFlag();				
			}

		} catch (ResultsetException e) {
			LOG.debug("Error extracting OrderLine subset!", e);
		} 

	}

	private void processOrderLineWSRequest() throws ErpConnectionException, ParametersException, TransformerException, ErpRuntimeException, PipelineRuntimeException{
		//Create OrderLinePriceRequest object
		LOG.debug("Inside processOrderLineWSRequest()");
		OrderLinePriceRequest daoRequest = new OrderLinePriceRequest();
		daoRequest.setTenantId(tenantId);
		daoRequest.setAccountingEntityId(accountingEntity);
		daoRequest.setCurrencyId(xmlRequest.getParameters().getString("@CurrencyCode"));
		daoRequest.setCustomerPartyId(xmlRequest.getParameters().getString("mvxCUNO"));
		daoRequest.setUserName(WebserviceDaoFactory.WEBSERVICEUSERID);

		//Unknown OrderType
		daoRequest.setOrderType(null);

		//Transfer Node to OrderLine array
		List<LinePrice> orderLines= createOrderLine();
		daoRequest.setOrderlines(orderLines);
		//Get ERP DAO implementation 
		OrderDao wsCallItem = DaoFactory.getDAOFactory().getOrderDao(); 
		OrderLinesPrice wsoutOrderLine = wsCallItem.getOrderLinePrice(daoRequest);

		//Update node with WS result 
		for (LinePrice out : wsoutOrderLine.getOrderline()){
			//Iterate over node item
			String itemID = out.getItemId();
			Node node = getItemNode(itemID);
			// set OrderLine response attributes for Prices...		
			xmlHelper.setAttribute(node, ConstantsForSales.LINEPRICE, Double.toString(out.getLineAmount()));
			xmlHelper.setAttribute(node, ConstantsForSales.RESELLPRICE, Double.toString(out.getSalesPrice()));
			xmlHelper.setAttribute(node, ConstantsForSales.LINEDISCOUNT, Double.toString(out.getDiscountAmount()));
			xmlHelper.setAttribute(node, ConstantsForSales.LINEDISPERCENT, Double.toString(0));
			xmlHelper.setAttribute(node, ConstantsForSales.LINETOTAL, Double.toString(out.getTotalAmount()));
			xmlHelper.setAttribute(node, ConstantsForSales.LINEEXTENDEDAMOUNT, Double.toString(out.getExtendedAmount()));
			xmlHelper.setAttribute(node, ConstantsForSales.ITEM_TAX, Double.toString(out.getDistributedChargeAmount()));
			this.totalPrice +=out.getTotalAmount();
			this.grandTotal=this.totalPrice;
		}	

		if (wsoutOrderLine.isHasWSCallError()){
			setErrorFlag();
		}
	}

	private List<LinePrice> createOrderLine() throws TransformerException, PipelineRuntimeException{
		List<LinePrice> orderLines= new ArrayList<LinePrice>();
		for (int x = 0; x < nodeList.getLength(); x++) {
			Node node = nodeList.item(x);				
			LinePrice line = new LinePrice();
			String itemId = xmlHelper.getAttribute(node, "ItemID");
			if(itemId == null || "".equals(itemId)){
				orderLines = ErpUtilHelper.getExistingOrderLines(this.orderID, this.warehouseId);
				break;
			}
			line.setItemId(xmlHelper.getAttribute(node, "ItemID"));
			line.setQuantity(new Double(xmlHelper.getAttribute(node, "Quantity")));
			line.setUnitCode(ErpUtilHelper.getItemUnit(xmlHelper.getAttribute(node, "ItemID")));
			line.setWarehouseId(this.warehouseId);				
			line.setConfigurationNumber(xmlHelper.getAttribute(node, "ConfigurationID"));
			line.setCustomerItemId(xmlHelper.getAttribute(node, "CustomerItemID"));
			
			if(CustomStagesHelper.getKeyValue("ION.Webservice ShippingAddressID").equals("true")){
				if(xmlHelper.getAttribute(node,"MvxShippingAddressID")!=null){
					line.setShippingAddressId(xmlHelper.getAttribute(node,"MvxShippingAddressID"));
				}
				else{
					if(this.itemShippingAddressIDMap!=null){
						if(this.itemShippingAddressIDMap.get(itemId)!=null){
							line.setShippingAddressId(this.itemShippingAddressIDMap.get(itemId));
						}
						else{
							line.setShippingAddressId(this.shippingAddressId);
						}
					}
					else{
						line.setShippingAddressId(this.shippingAddressId);
					}
				}
			}
			orderLines.add(line);				
		}
		return orderLines;
	}

	private List<LinePrice> createOrderLineFromResponse(XMLIterator lines) throws Exception {
		//Iterate OrderLines over NodeList
		LOG.debug("Inside createOrderLineFromResponse(XMLIterator lines)");
		List<LinePrice> orderLines= new ArrayList<LinePrice>();
		lines.beforeFirst();
		while(lines.moveNext()){				
			LinePrice orderline = new LinePrice();
			orderline.setItemId(lines.getString("ItemID"));
			orderline.setQuantity(Double.parseDouble(lines.getString("Quantity")));
			orderline.setUnitCode(ErpUtilHelper.getItemUnit(lines.getString("ItemID")));
			orderline.setWarehouseId(this.warehouseId);				
			orderline.setConfigurationNumber(xmlResponse.getString("ConfigurationID"));
			orderline.setCustomerItemId(xmlResponse.getString("CustomerItemID"));
			
			if(CustomStagesHelper.getKeyValue("ION.Webservice ShippingAddressID").equals("true")){
				if(lines.getString("MvxShippingAddressID")!=null){
					orderline.setShippingAddressId(lines.getString("MvxShippingAddressID"));
				}
				else{
					if(this.itemShippingAddressIDMap!=null){
						if(this.itemShippingAddressIDMap.get(lines.getString("ItemID"))!=null){
							orderline.setShippingAddressId(this.itemShippingAddressIDMap.get(lines.getString("ItemID")));
						}
						else{
							orderline.setShippingAddressId(this.shippingAddressId);
						}
					}
					else{
						orderline.setShippingAddressId(this.shippingAddressId);
					}
				}
			}
			orderLines.add(orderline);				
		}
		return 	orderLines;	
	}
	
	private Node getItemNode(String itemId) throws TransformerException{
		Node node = null;
		for (int x = 0; x < nodeList.getLength(); x++) {
			Node currNode = nodeList.item(x);
			String currItemID = xmlHelper.getAttribute(currNode, "ItemID");
			if (itemId.equals(currItemID)){
				node = currNode;
				break;
			}
		}
		return node;		
	}

	private XMLIterator getXMLOrderLine(String itemID) throws ResultsetException{
		XMLIterator iterLine = (XMLIterator) xmlResponse.getResultset(ConstantsForSales.ORDERLINE);
		while (iterLine.moveNext()) {
			String currItemID = iterLine.getString("ItemID");
			if (itemID.equals(currItemID)){
				return iterLine;
			}
		}
		return null;
	}

	private void processOrderTotalWSCall(List<LinePrice> orderLines) throws PipelineRuntimeException,ParametersException,SQLException, ErpConnectionException, ErpRuntimeException{		
		// Building GetOrderTotal
		OrderTotalRequest daoTotalRequest = new OrderTotalRequest();
		daoTotalRequest.setTenantId(tenantId);
		daoTotalRequest.setAccountingEntityId(accountingEntity);
		daoTotalRequest.setCustomerPartyId(xmlRequest.getParameters().getString("mvxCUNO"));
		daoTotalRequest.setCurrencyId(xmlRequest.getParameters().getString("@CurrencyCode"));
		daoTotalRequest.setUserName(WebserviceDaoFactory.WEBSERVICEUSERID);
		daoTotalRequest.setOrderLines(orderLines);

		//Unknown OrderType 
		daoTotalRequest.setOrderType(null);

		//Call WS OrderLinePrice//Get ERP DAO implementation 
		OrderDao wsCallItem = DaoFactory.getDAOFactory().getOrderDao();  
		OrderTotal wsoutOrderTotal = wsCallItem.getOrderTotal(daoTotalRequest);	
		//Save charges and taxes to DB
		createXMLResultSetChargeTax(wsoutOrderTotal);	

		grandTotal = wsoutOrderTotal.getGrandTotal();
		totalDiscount = wsoutOrderTotal.getTotalDiscount();
		totalPrice = wsoutOrderTotal.getTotalPrice();

		if (wsoutOrderTotal.isHasWSCallError()){
			setErrorFlag();
		}		

	}
	
	private void processOrderTotalWSCall() throws PipelineRuntimeException,ParametersException,SQLException, ErpConnectionException, ErpRuntimeException{		
		// Building GetOrderTotal
		LOG.debug("Inside processOrderTotalWSCall()");
		List<LinePrice> orderLines = ErpUtilHelper.getExistingOrderLines(this.orderID, this.warehouseId,this.shippingAddressId);
		OrderTotalRequest daoTotalRequest = new OrderTotalRequest();
		daoTotalRequest.setTenantId(tenantId);
		daoTotalRequest.setAccountingEntityId(accountingEntity);
		daoTotalRequest.setCustomerPartyId(xmlRequest.getParameters().getString("mvxCUNO"));
		daoTotalRequest.setCurrencyId(xmlRequest.getParameters().getString("@CurrencyCode"));
		daoTotalRequest.setUserName(WebserviceDaoFactory.WEBSERVICEUSERID);
		daoTotalRequest.setOrderLines(orderLines);

		//Unknown OrderType 
		daoTotalRequest.setOrderType(null);

		//Call WS OrderLinePrice//Get ERP DAO implementation 
		OrderDao wsCallItem = DaoFactory.getDAOFactory().getOrderDao();  
		OrderTotal wsoutOrderTotal = wsCallItem.getOrderTotal(daoTotalRequest);	
		//Save charges and taxes to DB
		//createXMLResultSetChargeTax(wsoutOrderTotal);	

		grandTotal = wsoutOrderTotal.getGrandTotal();
		totalDiscount = wsoutOrderTotal.getTotalDiscount();
		totalPrice = wsoutOrderTotal.getTotalPrice();

		if (wsoutOrderTotal.isHasWSCallError()){
			setErrorFlag();
		}		

	}

	private void createXMLResultSetChargeTax(OrderTotal wsoutOrderTotal) {
		try{
			if(xmlResponse != null){
				Document document = xmlResponse.getDocument();
				if (document != null) {
					NodeList nodeList = XPathAPI.selectNodeList(document,"resultset/row");
					Node nodeRow = nodeList.item(0);
					//Charges
					if (wsoutOrderTotal.getDistributedCharges().size() > 0) {
						for (Charge charge : wsoutOrderTotal.getDistributedCharges()){
							//		if (charge.getCode() != null && !charge.getCode().isEmpty()){
							Element elemCharge = document.createElement("DistributedCharges");
							elemCharge.setAttribute("OrderID", orderID);
							elemCharge.setAttribute("ReasonCode", charge.getDescription());
							elemCharge.setAttribute("Value", Double.toString(charge.getAmount()));
							nodeRow.appendChild(elemCharge);
							//		}
						}
					}

					//Taxes
					if (wsoutOrderTotal.getDistributedTaxes().size() > 0) {
						for (Tax tax : wsoutOrderTotal.getDistributedTaxes()){
							//		if (tax.getCode() != null && !tax.getCode().isEmpty()){
							Element elemTax = document.createElement("DistributedTaxes");
							elemTax.setAttribute("OrderID", orderID);
							elemTax.setAttribute("ReasonCode", tax.getDescription());
							elemTax.setAttribute("Value", Double.toString(tax.getAmount()));
							nodeRow.appendChild(elemTax);
							//		}
						}
					}
					//Rounding Off
					Element elemRoundOff = document.createElement("RoundingOff");
					elemRoundOff.setAttribute("RoundingOff", wsoutOrderTotal.getRoundingOff()+"");
					nodeRow.appendChild(elemRoundOff);
				}
			}
		}catch (TransformerException e){
			LOG.error(e.toString());
		}catch (ResultsetException e){
			LOG.error(e.toString());	
		}
	}

	private void setErrorFlag(){
		try {
			if(xmlResponse == null){
				XMLResultset response = new XMLResultset();
				context.setResponse(response);
			}
			CustomStagesHelper.setResponseParameter(context, "hasWSError", "Y");
		} catch (PipelineRuntimeException e) {
			LOG.error(e.toString());	
		}
	}
	
	private void orderlineDBUpdates(List<LinePrice> orderline) throws SQLException{
		LOG.debug("Inside OrdersWSClient.orderlineDBUpdates()");    
		PreparedStatement pstmt = null;
		Connection conn = null;
		try {
			conn = (Connection) CustomStagesHelper.getConnection("esales.cursor");
			String updateOrderlineFrmWS = "UPDATE OrderLine set resellPrice = ?, linePrice = ?, lineTotal = ? WHERE orderId = ? AND itemNumber = ?";
			pstmt = conn.prepareStatement(updateOrderlineFrmWS);
			int orderlineSize = orderline.size();
			for (LinePrice out : orderline){
				
				String itemID = out.getItemId();
				
				pstmt.setString(1, Double.toString(out.getSalesPrice()));
				pstmt.setString(2, Double.toString(out.getLineAmount()));
				pstmt.setString(3, Double.toString(out.getTotalAmount()));
				pstmt.setString(4, this.orderID);
				pstmt.setString(5, itemID);
				pstmt.addBatch();				
			}
			int [] numOfUpdates = pstmt.executeBatch();
			LOG.debug("OrdersWSClient.orderlineDBUpdates() Successfull Update ["+numOfUpdates.length+"] of ["+orderlineSize+"]");  
			
		} catch (SQLException se) {
			LOG.error(se.toString());	
		} catch (Exception e) {
			LOG.error(e.toString());	
		} finally {
			pstmt.close();
			conn.close();
		}
	}
	
	private HashMap<String,String> getOrderLinesShippingAddressID(XMLIterator lines){
		HashMap<String,String> itemMap=new HashMap<String,String>();
		try {
			lines.moveFirst();
			while(lines.hasNext()){
				if(lines.getString("ItemID")!=null && lines.getString("MvxShippingAddressID")!=null){
					itemMap.put(lines.getString("ItemID"), lines.getString("MvxShippingAddressID"));
				}
				lines.moveNext();
			}
			return itemMap;
		} catch (ResultsetException e) {
			// TODO Auto-generated catch block
			LOG.debug(e.toString());
		}
		return new HashMap<String,String>();
	}
	
	private Double getOrderTotal(XMLIterator lines) throws Exception{
		double totalAmount=0;
		List<String> itemIDList= new ArrayList<String>();
		for (int x = 0; x < nodeList.getLength(); x++) {
			Node node = nodeList.item(x);				
			String itemId = xmlHelper.getAttribute(node, "ItemID");
			itemIDList.add(itemId);				
		}
		lines.beforeFirst();
		while(lines.moveNext()){				
			if(itemIDList.indexOf(lines.getString("ItemID"))==-1){
				totalAmount+=Double.parseDouble(lines.getString("LinePrice"));
			}
		}
		return totalAmount;
	}
	
	private Double getOrderTotal(XMLIterator lines,XMLIterator existinglines) throws Exception{
		double totalAmount= 0;
		List<String> itemIDList= new ArrayList<String>();
		lines.beforeFirst();
		while(lines.moveNext()){ 			
			String itemId = lines.getString("ItemID");
			if(itemId!=null && !itemId.equals("")){
				itemIDList.add(itemId);
			}
		}
		existinglines.beforeFirst();
		while(existinglines.moveNext()){				
			if(itemIDList.indexOf(existinglines.getString("ItemID"))==-1){
				totalAmount+=Double.parseDouble(existinglines.getString("LinePrice"));
			}
		}
		return totalAmount;
	}
}
