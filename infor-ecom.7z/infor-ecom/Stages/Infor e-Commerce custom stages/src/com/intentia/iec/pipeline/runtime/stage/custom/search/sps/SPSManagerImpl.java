package com.intentia.iec.pipeline.runtime.stage.custom.search.sps;

import java.util.Properties;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.search.DataHolder;
import com.intentia.iec.pipeline.runtime.stage.custom.search.DataHolderImpl;
import com.intentia.iec.pipeline.runtime.stage.custom.search.ManagerImpl;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Strings;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.util.FastStringBuffer;
import com.intentia.iec.util.PropertyLoader;

/**
 * Manages the spare parts index.
 * 
 */
public class SPSManagerImpl extends ManagerImpl {

    /** The Constant LOG. */
    private static final Logger LOG = Logger.getLogger(SPSManagerImpl.class);

    /**
     * The Constant DEFAULT_INDEX_FOLDER. This is the default folder location
     * for sps lucene indexes
     */
    private static final String DEFAULT_INDEX_FOLDER = "C:/lucene-index-sps";

    /**
     * Key use to retrieved SPS Parts Index Folder from the Database.
     */
    private static final String APP_DETAILS_SPS_INDEX_FOLDER = "PartsIndexFolder";

    /**
     * The Constant APP_PROP_FILTER_CAPACITY. Application Property in Design
     * Center which contains the SPS Filter Capacity
     */
    private static final String APP_PROP_FILTER_CAPACITY = "Search Engine (SPS).Filter Cache Capacity";

    /**
     * The Constant APP_PROP_INDEX_FOLDER. Application Property in Design Center
     * which indicates where the SPS lucene indexes will be created - else
     * DEFAULT_INDEX_FOLDER value will be used
     */
    private static final String APP_PROP_INDEX_FOLDER = "Search Engine (SPS).Index Folder";

    /** The instance. */
    private static SPSManagerImpl instance = new SPSManagerImpl();

    /**
     * Instantiates a new SpareParts manager.
     */
    private SPSManagerImpl() {
        Properties properties = PropertyLoader.loadProperties(APP_PROP_FILENAME);
        if (properties == null) {
            indexFolder = DEFAULT_INDEX_FOLDER;
            filterCacheCapacity = DEFAULT_FILTERCACHE_CAPACITY;
            applicationType = DEFAULT_APP_TYPE;
            LOG.debug("Error reading application properties" + " (using defaults instead)");
        } else {
            // Load index folder setting
            try {
                getSPSIndexFolderPath();
            } catch (PipelineRuntimeException e) {
                LOG.debug(e.getMessage());
            }
            // Load filter cache capacity setting
            String capStr = properties.getProperty(APP_PROP_FILTER_CAPACITY);
            int cap = 0;
            if (capStr != null) {
                cap = Integer.parseInt(capStr);
            }
            if (cap < MIN_FILTERCACHE_CAPACITY || cap > MAX_FILTERCACHE_CAPACITY) {
                cap = DEFAULT_FILTERCACHE_CAPACITY;
            }
            filterCacheCapacity = cap;
            // Load B2C pages setting
            capStr = properties.getProperty(APP_PROP_PAGES_B2C);
            if (capStr.equalsIgnoreCase("true")) {
                applicationType = Strings.Application.Type.b2c;
            } else {
                applicationType = Strings.Application.Type.b2b;
            }
        }
        LOG.debug("Index folder: " + indexFolder);
        LOG.debug("Filter cache capacity: " + filterCacheCapacity);
    }

    /**
     * Get Search Engine (SPS) Parts Index Folder Path from Application Data.
     * 
     * @throws PipelineRuntimeException
     */
    public String getSPSIndexFolderPath() throws PipelineRuntimeException {

        indexFolder = getValueFromApplicationData(APP_DETAILS_SPS_INDEX_FOLDER);

        if (null == indexFolder) {
            FastStringBuffer msg = new FastStringBuffer(100);
            msg.append("Missing application data: ").append(APP_DETAILS_SPS_INDEX_FOLDER);
            throw new PipelineRuntimeException(msg.toString());
        }
        LOG.debug("Search Engine (SPS) Index Folder Path: " + indexFolder.toString());
        return indexFolder;
    }

    /**
     * Gets the single instance of SPSManagerImpl.
     * 
     * @return single instance of SPSManagerImpl
     */
    public static SPSManagerImpl getInstance() {
        return instance;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.intentia.iec.pipeline.runtime.stage.custom.search.ManagerImpl#
     * getDataHolder()
     */
    public synchronized DataHolder getDataHolder() throws PipelineRuntimeException {
        if (dataHolder == null) {
            dataHolder = new DataHolderImpl(SPSManagerImpl.getInstance());
        }
        return dataHolder;
    }

    private String getValueFromApplicationData(String pParamName) {

        String paramValue;

        SearchPipelineExecuter spe = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                ConstantsForSales.APPLICATION_DATA, ConstantsForSales.APPLICATION_DATA_DETAILS);

        spe.setParam("param", pParamName);

        try {
            XMLResultset rs = spe.execute();
            rs.moveFirst();
            paramValue = rs.getString("ParameterValue");
        } catch (PipelineRuntimeException e) {
            paramValue = "";
        } catch (ResultsetException e) {
            paramValue = "";
        }

        return paramValue;

    }

    public String getParentFolder() {
        try {
            return this.getSPSIndexFolderPath();
        } catch (PipelineRuntimeException e) {
            LOG.debug("Error reading application date" + " (using defaults instead)");
            return DEFAULT_INDEX_FOLDER;
        }
    }
}
