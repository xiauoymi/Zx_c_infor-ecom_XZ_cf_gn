/*
 * Created on 23-03-2006
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.w3c.dom.Node;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.ApplicationParameter;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

/**
 * <p>
 * Patches the request for creating a user as received from SalesTool / SMS. The
 * stage is used in the pipeline for processing a user request as received from
 * SalesTool / SMS.
 * </p>
 * <p>
 * Inserts the key for a user with the given e-mail in the request. Patches the
 * locale code (LocaleID) in the request with an e-Sales code by mapping the
 * given SalesTool / SMS language code. For a new user default values and roles
 * are added.
 * </p>
 * <p>
 * <b>Input in <code>PipelineContext</code>:</b><br>
 * Parameters:
 * <ul>
 * <li><code>&#64;email</code> (mandatory for update)</li>
 * <li><code>&#64;customerNo</code> (mandatory)</li>
 * <li><code>&#64;languageCodeInSalesTool</code> (optional)</li>
 * </ul>
 * </p>
 * <p>
 * The parameter <code>&#64;email</code> tells what user to modify. The stage
 * finds the ID for the user and inserts the ID as key in the request, so the
 * request can be used in a following update stage.
 * </p>
 * <p>
 * The attribute <code>LocaleID</code> is the SalesTool GUID for a language,
 * e.g. <code>69910f8b-4917-11d5-ac23-0006294308d9</code> for English. The
 * following update stage maps the code to a standard code as used in e-Sales,
 * e.g. <code>en</code> by using a foreign key construct.
 * </p>
 * <p>
 * <b>Generated output in <code>PipelineContext</code>:</b><br>
 * <ul>
 * <li>The found key for the user.</li>
 * <li>The found language code for the given SalesTool language code is set in
 * the parameter <code>&#64;LanguageCode</code>.</li>
 * <li>For a new user: Default values and a role subset plus a new request
 * parameter &#64;sendMail = true.</li>
 * </ul>
 * </p>
 */
/*
 * The text uses the character code &#64; for @ to avoid to confuse the Java
 * auto formatter.
 */
public class PrepareSalesToolUserRequest implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(PrepareSalesToolUserRequest.class);

    private static final String ENTITY_XPATH = "/request/entities/entity";

    // Input parameters to this stage.
    private static final String EMAIL_PARAMETER = "@email";

    private static final String CUSTOMER_NO_PARAMETER = "@customerNo";

    private static final String SALES_TOOL_LANGUAGE_PARAMETER = "@languageCodeInSalesTool";

    // Output parameters from this stage
    private static final String LANGUAGE_PARAMETER = "@LanguageCode";

    private static final String SEND_MAIL_PARAMETER = "@sendMail";

    // Application URL
    private static final String URL_PARAMETER = "@url";

    private static final String URL_POSTFIX = "/esa/";

    // Subsets on User business object
    private static final String ROLE_SUBSET = "Role";

    // Attributes on Role business object
    private static final String ROLE_ID_ATTRIBUTE = "RoleID";

    // The roles with the feature element "Is User From SalesTool" should be
    // added to the new user.
    private static final String SALES_TOOL_FEATURE_ELEMENT = "98";

    // Local variables
    private XMLRequest request = null;

    private XMLRequestHelper requestHelper = null;

    private Parameters parameters = null;

    private Node entityNode = null;

    // From parameter
    private String email = null;

    private String customerNo = null;

    // From User search
    private String userID = null;

    private String masterCustomerNo = null;

    /*
     * (non-Javadoc) Pipeline entry point.
     */
    public void execute(final PipelineContext context) throws PipelineRuntimeException {

        // Verify type of request
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Request MUST be of type XMLRequest!");
        }

        request = (XMLRequest) context.getRequest();

        try {
            XMLRequest.extractRequestParameters(request);
            entityNode = XMLRequestHelper.getRequestNode(request, ENTITY_XPATH);
            if (entityNode == null) {
                LOG.debug("The request does not hold an entity node!");
                return;
            }
            parameters = request.getParameters();
            requestHelper = new XMLRequestHelper(request);

            boolean userFound = false;

            customerNo = parameters.getString(CUSTOMER_NO_PARAMETER);
            email = parameters.getString(EMAIL_PARAMETER);
            if ((email != null) && (email.length() >= 5)) {
                userFound = findUser(email);
            }

            addLocale();
            addUrl();

            if (userFound) {
                // Add the user ID as key to the request, so it becomes an
                // update request
                requestHelper.setKey(entityNode, userID);
                if ((customerNo != null) && !customerNo.equals(masterCustomerNo)) {
                    // The user already exists on a different customer / user
                    // group. We don't allow that and throws an exception-
                    throw new PipelineRuntimeException("The user '" + email + "' already exists for customer '"
                            + customerNo + "'.");
                }
            } else {
                if (LOG.isDebugEnabled()) {
                    LOG.info("Could not find user with e-mail '" + email + "' - create a user.");
                }
                addAttributesForCreate();
                addRoles();
                parameters.setboolean(SEND_MAIL_PARAMETER, true);
            }

        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Failed to obtain a parameter from request", e);
        } catch (TransformerException e) {
            throw new PipelineRuntimeException("Failed to get/set attribute in request", e);
        } catch (RequestException e) {
            throw new PipelineRuntimeException("Failed to operate on request", e);
        }
    }

    /**
     * Searches for the user given by the e-mail parameter. Sets two class
     * variables for user ID and customer number if the user is found.
     * 
     * @return Returns true if the user is found.
     * @throws PipelineRuntimeException
     */
    private boolean findUser(final String emailAddress) throws PipelineRuntimeException {

        // Business object
        final String userObject = "User";

        // Method to call to get the user ID.
        final String userMethod = "GetIdFromEmail";

        // Input parameter to user search method.
        final String emailParameter = "email";

        boolean userFound = false;

        try {
            // Get ID for the user with the given e-mail.
            SearchPipelineExecuter searchUser = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                    userObject, userMethod);
            searchUser.setParam(emailParameter, emailAddress);
            XMLResultset rsUser = searchUser.execute();
            if (rsUser.moveFirst()) {
                userID = rsUser.getString(ConstantsForSales.USER_ID_ATTRIBUTE);
                masterCustomerNo = rsUser.getString(ConstantsForSales.MASTER_USERGROUP_KEY_ATTRIBUTE);
                userFound = true;
            }
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Failed to operate on resultset", e);
        }
        return userFound;
    }

    /**
     * Sets attribute <code>LocaleID</code> and parameter
     * <code>&#64;LanguageCode</code> in the request.
     * 
     * @throws PipelineRuntimeException
     */
    private void addLocale() throws PipelineRuntimeException {

        // Business object
        final String localeObject = "Locale";

        // Method to call to get locale ID.
        final String localeMethod = "LookupVisibleLanguagesSimple";

        // Input parameter to locale search method.
        final String isVisibleParameter = "isVisible";

        // Output attribute for search method, and attribute to insert in
        // request.
        final String localeAttribute = "LocaleID";
        final String languageAttribute = "LanguageCode";
        final String salesToolLanguageAttribute = "LanguageCodeInSalesTool";

        try {
            String salesToolCode = parameters.getString(SALES_TOOL_LANGUAGE_PARAMETER);
            if ((salesToolCode == null) || (salesToolCode.length() == 0)) {
                LOG.debug("Parameter '" + SALES_TOOL_LANGUAGE_PARAMETER + "' not found - does not find locale ID!");
            } else {
                String localeCode = null;
                String languageCode = null;

                // Get all locales, so a proper one can be searched.
                SearchPipelineExecuter searchLocale = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                        localeObject, localeMethod);
                searchLocale.setParam(isVisibleParameter, "Y");
                XMLResultset rsLocale = searchLocale.execute();
                // Search for the SalesTool Language
                while (rsLocale.moveNext()) {
                    if (salesToolCode.equals(rsLocale.getString(salesToolLanguageAttribute))) {
                        localeCode = rsLocale.getString(localeAttribute);
                        languageCode = rsLocale.getString(languageAttribute);
                        break;
                    }
                }
                if (localeCode == null) {
                    rsLocale.beforeFirst();
                    // Search for the English Language
                    while (rsLocale.moveNext()) {
                        if ("en".equals(rsLocale.getString(languageAttribute))) {
                            localeCode = rsLocale.getString(localeAttribute);
                            languageCode = rsLocale.getString(languageAttribute);
                            LOG.debug("Couldn't find the language. Defaulted to 'en' language code.");
                            break;
                        }
                    }
                }
                if ((localeCode == null) && (!rsLocale.isEmpty())) {
                    // Just use the first in the returned list
                    rsLocale.moveFirst();
                    localeCode = rsLocale.getString(localeAttribute);
                    languageCode = rsLocale.getString(languageAttribute);
                    if (LOG.isDebugEnabled()) {
                        LOG.debug("Couldn't find the language. Took the first language code:" + languageCode);
                    }
                }
                if (localeCode != null) {
                    requestHelper.setAttribute(entityNode, ConstantsForSales.LOCALE_ATTRIBUTE, localeCode);
                    parameters.setString(LANGUAGE_PARAMETER, languageCode);
                }
            }
        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Locale: Failed to get/set a parameter from/in request", e);
        } catch (TransformerException e) {
            throw new PipelineRuntimeException("Locale: Failed to get/set attribute from/in request", e);
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Locale: Failed to operate on resultset", e);
        }
    }

    /**
     * Sets the parameter <code>&#64;url</code> in the request as the
     * application URL.
     * 
     * @throws PipelineRuntimeException
     */
    private void addUrl() throws PipelineRuntimeException {

        try {
            String url = ApplicationParameter.getValue(ConstantsForSales.APPLICATION_URL);
            if (url == null || (url.length() < 5)) {
                return;
            }
            parameters.setString(URL_PARAMETER, url + URL_POSTFIX);

        } catch (ParametersException e) {
            throw new PipelineRuntimeException("URL: Failed to get/set a parameter from/in request", e);
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("URL: Failed to operate on resultset", e);
        }
    }

    /**
     * Adds a subset <code>Roles</code> to the request.
     * 
     * @throws PipelineRuntimeException
     */
    private void addRoles() throws PipelineRuntimeException {

        // Business object
        final String roleObject = "Role";

        // Method to call to get locale ID.
        final String roleMethod = "WithFeatureElementLookup";

        // Input parameter to user search method.
        final String featureParameter = "@featureID";

        try {
            // Get roles to add to the new user.
            // They are marked with a specific feature element.
            SearchPipelineExecuter searchUser = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                    roleObject, roleMethod);
            searchUser.setParam(featureParameter, SALES_TOOL_FEATURE_ELEMENT);
            XMLResultset rsRole = searchUser.execute();
            if (!rsRole.moveFirst()) {
                LOG.info("Could not find role with featureID '" + SALES_TOOL_FEATURE_ELEMENT + "'");
            } else {
                Node subsetNode = requestHelper.addSubset(entityNode, ROLE_SUBSET);
                do {
                    String roleID = rsRole.getString(ROLE_ID_ATTRIBUTE);
                    requestHelper.setAttribute(subsetNode, ROLE_ID_ATTRIBUTE, roleID);
                } while (rsRole.moveNext());
            }
        } catch (TransformerException e) {
            throw new PipelineRuntimeException("Role: Failed to create attribute/subset in request", e);
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Role: Failed to operate on resultset", e);
        }

    }

    /**
     * Default values on create: Adds attributes with values to the request,
     * which are required when creating a new user. Password is added to trigger
     * generation of a new random password later in the pipeline.
     * 
     * @throws PipelineRuntimeException
     */
    private void addAttributesForCreate() throws PipelineRuntimeException {

        // Values
        final String yes = "Y";
        final String no = "N";

        try {
            // Customer / UserGroup
            requestHelper.setAttribute(entityNode, ConstantsForSales.MASTER_USERGROUP_KEY_ATTRIBUTE, customerNo);
            requestHelper.setAttribute(entityNode, ConstantsForSales.DEFAULT_USERGROUP_KEY_ATTRIBUTE, customerNo);
            // Password is added to trigger generation of a password - just
            // supply a value.
            requestHelper.setAttribute(entityNode, ConstantsForSales.PASSWORD_ATTRIBUTE, yes);
            // Other attributes requiring default values.
            requestHelper.setAttribute(entityNode, ConstantsForSales.PROMPT_FOR_ORDERLINE_DETAILS_ATTRIBUTE, no);
            requestHelper.setAttribute(entityNode, ConstantsForSales.SHOW_ALT_CURRENCY_ATTRIBUTE, no);
            requestHelper.setAttribute(entityNode, ConstantsForSales.PARTIAL_ORDERS_ATTRIBUTE, no);
            requestHelper.setAttribute(entityNode, ConstantsForSales.WISH_TO_BE_RESELLER_ATTRIBUTE, no);
        } catch (TransformerException e) {
            throw new PipelineRuntimeException("Create: Failed to set attribute in request", e);
        }
    }
}
