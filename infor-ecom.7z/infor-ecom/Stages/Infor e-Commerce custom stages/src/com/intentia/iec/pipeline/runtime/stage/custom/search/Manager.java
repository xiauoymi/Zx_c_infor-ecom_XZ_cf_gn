package com.intentia.iec.pipeline.runtime.stage.custom.search;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;

/** The singleton manager for the Lucene search implementation. */
public interface Manager {
    int getFilterCacheCapacity();

    DataHolder getDataHolder() throws PipelineRuntimeException;

    void reloadData() throws PipelineRuntimeException;

    String getParentFolder();

    String getNewFolderName();

    String getCurrentFolder();

    String getApplicationType();
}
