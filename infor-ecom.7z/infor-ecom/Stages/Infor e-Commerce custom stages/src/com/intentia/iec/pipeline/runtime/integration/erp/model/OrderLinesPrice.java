package com.intentia.iec.pipeline.runtime.integration.erp.model;

import java.util.List;

public class OrderLinesPrice {
	
	private List<LinePrice> orderline;	

	private boolean hasWSCallError;
	
	private String msgError;
	
	private String msgCodeError;

	public List<LinePrice> getOrderline() {
		return orderline;
	}

	public void setOrderline(List<LinePrice> orderline) {
		this.orderline = orderline;
	}

	public boolean isHasWSCallError() {
		return hasWSCallError;
	}

	public void setHasWSCallError(boolean hasWSCallError) {
		this.hasWSCallError = hasWSCallError;
	}

	public String getMsgError() {
		return msgError;
	}

	public void setMsgError(String msgError) {
		this.msgError = msgError;
	}

	public String getMsgCodeError() {
		return msgCodeError;
	}

	public void setMsgCodeError(String msgCodeError) {
		this.msgCodeError = msgCodeError;
	}

	

}
