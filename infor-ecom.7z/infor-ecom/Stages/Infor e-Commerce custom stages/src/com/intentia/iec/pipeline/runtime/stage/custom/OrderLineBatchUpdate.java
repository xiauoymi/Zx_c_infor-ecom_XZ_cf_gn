/*
 * Created on 05-28-2009
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;
import com.ibm.icu.text.NumberFormat;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.Request;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.Resultset;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.Decimal;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;
import com.intentia.iec.sqlserver.runtime.jdbc.LogPreparedStatement;
import com.intentia.iec.util.FastStringBuffer;

/**
 * <p>
 * Update Order Line in bulk manner. This will handle orders with large number
 * more order line like orders thru Order File uploads.
 * </p>
 */

public class OrderLineBatchUpdate implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(OrderLineBatchUpdate.class);

    private static final String ORDER_ID = "orderID";

    private static final String ORDER_LINE_STATUS = "orderLineStatus";

    private static final String ITEM_ID = "ItemID";

    private static final String LINE_DISCOUNT = "LineDiscount";

    private static final String LINE_PRICE = "LinePrice";

    private static final String LINE_DISCOUNT_PERCENT = "LineDisPercent";

    private static final String LINE_TOTAL = "LineTotal";

    private static final String QUANTITY = "Quantity";

    private static final String RESELL_PRICE = "ResellPrice";

    private static final String IS_LIST_PRICE = "IsListPrice";

    private static final String USE_CID = "UseCID";
    
    private PreparedStatement pstmt;

    private static final String SQL_INSERT = "INSERT INTO [OrderLine] ( " + "[itemNumber], " + "[lineDiscount], "
            + "[linePrice], " + "[lineDiscountPercent], " + "[lineTotal], " + "[quantity], " + "[resellPrice], "
            + "[isListPrice], " + "[status], " + "[orderId], " + "[useCID], " + "[drdlId]) " + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";

    private static final String SQL_UPDATE = "UPDATE [OrderLine] SET" + "[lineTotal] = ?, " + "[resellPrice] = ?, "
            + "[lineDiscount] = ?, " + "[isListPrice] = ?, " + "[linePrice] = ?, " + "[quantity] = ?, "
            + "[lineDiscountPercent] = ?, " + "[itemNumber] = ?, " + "[status] = ?, " + "[useCID] = ? "
            + "FROM [OrderLine] " + "WHERE [OrderLine].[orderId] = ? " + "AND [OrderLine].[id] = ?";

    private Connection conn;

    /*
     * (non-Javadoc) Pipeline entry point.
     */
    public void execute(final PipelineContext context) throws PipelineRuntimeException {

        // Retrieve XML request from context
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }

        Document request;
        XMLRequest xmlRequest;

        try {
            CustomStagesHelper.extractRequestParameters(CustomStagesHelper.getRequest(context));
            xmlRequest = (XMLRequest) context.getRequest();
            request = xmlRequest.getRequestDoc();

            Parameters parameters = xmlRequest.getParameters();

            initConnection();
            doBatchUpdate(request, parameters);
            String isION = CustomStagesHelper.getKeyValue("ION.Enabled");
            if (isION.equals("true")) {
            	updateOrderHeaderTotalsFromWS(request, parameters);
            }

        } catch (Exception e) {
            throw new PipelineRuntimeException("Failed to obtain XML request document from request", e);
        } finally {
            closeConnection();
        }
    }

    private void doBatchUpdate(Document request, Parameters parameters) throws PipelineRuntimeException {
        try {

            String orderLineID = null;
            String orderID = null;
            String orderLineStatus = null;

            boolean doInsert = false;
            boolean doUpdate = false;

            try {
                orderID = parameters.getString(ORDER_ID);
                orderLineStatus = parameters.getString(ORDER_LINE_STATUS);
            } catch (ParametersException e) {
                throw new PipelineRuntimeException("Failed to obtain " + ORDER_ID + " parameter from request, "
                        + e.getMessage(), e);
            }

            XMLRequestHelper xmlHelper = new XMLRequestHelper(request);

            if (LOG.isDebugEnabled()) {
                xmlHelper.logRequest();
            }

            NodeList nodeList = XPathAPI.selectNodeList(request,
                    "request/entities/entity/subsets/subset[@name=\"OrderLine\"]");

            LogPreparedStatement pstmtInsert = new LogPreparedStatement(conn, SQL_INSERT);
            LogPreparedStatement pstmtUpdate = new LogPreparedStatement(conn, SQL_UPDATE);
            FastStringBuffer sqlInsertStr = new FastStringBuffer();
            FastStringBuffer sqlUpdateStr = new FastStringBuffer();

            for (int i = 0; i < nodeList.getLength(); i++) {

                String itemID = null;

                BigDecimal lineDiscount = new BigDecimal("0.0000");
                BigDecimal linePrice = new BigDecimal("0.0000");
                BigDecimal lineDiscountPercent = new BigDecimal("0.0000");
                BigDecimal lineTotal = new BigDecimal("0.0000");
                BigDecimal resellerPrice = new BigDecimal("0.0000");

                double quantity = 0.0;
                String isListPrice = null;
                String useCID = null;
                int demandOrderLineId = 0;

                Node node = nodeList.item(i);
                orderLineID = xmlHelper.getKey(node);
                itemID = xmlHelper.getAttribute(node, ITEM_ID);

                if (xmlHelper.getAttribute(node, LINE_DISCOUNT) != null)
                    lineDiscount = stringToDecimal(xmlHelper.getAttribute(node, LINE_DISCOUNT));
                if (xmlHelper.getAttribute(node, LINE_PRICE) != null)
                    linePrice = stringToDecimal(xmlHelper.getAttribute(node, LINE_PRICE));
                if (xmlHelper.getAttribute(node, LINE_DISCOUNT_PERCENT) != null)
                    lineDiscountPercent = stringToDecimal(xmlHelper.getAttribute(node, LINE_DISCOUNT_PERCENT));
                if (xmlHelper.getAttribute(node, LINE_TOTAL) != null)
                    lineTotal = stringToDecimal(xmlHelper.getAttribute(node, LINE_TOTAL));
                if (xmlHelper.getAttribute(node, QUANTITY) != null)
                    quantity = Double.parseDouble(xmlHelper.getAttribute(node, QUANTITY));
                if (xmlHelper.getAttribute(node, RESELL_PRICE) != null)
                    resellerPrice = stringToDecimal(xmlHelper.getAttribute(node, RESELL_PRICE));
                if (xmlHelper.getAttribute(node, IS_LIST_PRICE) != null)
                    isListPrice = xmlHelper.getAttribute(node, IS_LIST_PRICE);
                if (xmlHelper.getAttribute(node, USE_CID) != null)
                    useCID = xmlHelper.getAttribute(node, USE_CID);
                if (xmlHelper.getAttribute(node, "DRDLSequence") != null) 
					demandOrderLineId = Integer.parseInt(xmlHelper.getAttribute(node, "DRDLSequence"));

                if (orderLineID == null) { // do OrderLine insert
                    pstmtInsert.setString(1, itemID);
                    pstmtInsert.setString(2, lineDiscount.toString());
                    pstmtInsert.setString(3, linePrice.toString());
                    pstmtInsert.setString(4, lineDiscountPercent.toString());
                    pstmtInsert.setString(5, lineTotal.toString());
                    pstmtInsert.setString(6, String.valueOf(quantity));
                    pstmtInsert.setString(7, resellerPrice.toString());
                    pstmtInsert.setString(8, isListPrice);
                    pstmtInsert.setString(9, orderLineStatus);
                    pstmtInsert.setString(10, orderID);
                    pstmtInsert.setString(11, useCID);
                    pstmtInsert.setString(12, String.valueOf(demandOrderLineId));
                    pstmtInsert.addBatch();
                    doInsert = true;
                    sqlInsertStr.append(pstmtInsert.getQuery() + "; \r\n");
                } else { // do OrderLine update
                    pstmtUpdate.setString(1, lineTotal.toString());
                    pstmtUpdate.setString(2, resellerPrice.toString());
                    pstmtUpdate.setString(3, lineDiscount.toString());
                    pstmtUpdate.setString(4, isListPrice);
                    pstmtUpdate.setString(5, linePrice.toString());
                    pstmtUpdate.setString(6, String.valueOf(quantity));
                    pstmtUpdate.setString(7, lineDiscountPercent.toString());
                    pstmtUpdate.setString(8, itemID);
                    pstmtUpdate.setString(9, orderLineStatus);
                    pstmtUpdate.setString(10, useCID);
                    pstmtUpdate.setString(11, orderID);
                    pstmtUpdate.setString(12, orderLineID);
                    pstmtUpdate.addBatch();
                    doUpdate = true;
                    sqlUpdateStr.append(pstmtUpdate.getQuery() + "\r\n");
                }
            }

            if (doInsert) {
                LOG.debug("Executing INSERT statement:\r\n" + sqlInsertStr);
                pstmtInsert.executeBatch();
            }

            if (doUpdate) {
                LOG.debug("Executing UPDATE statement:\r\n" + sqlUpdateStr);
                pstmtUpdate.executeBatch();
            }

        } catch (SQLException e) {
            throw new PipelineRuntimeException("Error while updating order lines, " + e);
        } catch (Exception e) {
            throw new PipelineRuntimeException("Failed to obtain XML request document from request", e);
        }
    }
    
    /**
     * Update the OrderHeaderTotalsFromWS
     * 
     * @param request
     * @throws PipelineRuntimeException
     */
    private void updateOrderHeaderTotalsFromWS(Document request, Parameters parameters) throws PipelineRuntimeException {
    	
    	try {
            LOG.debug("Entering updateOrderHeaderTotalsFromWS");
            
           	String orderUpdate = "UPDATE [OrderHeader] SET [GrandTotal] = ?, [TotalPrice] = ?, [TotalDiscount] = ? WHERE id = ? ";
           	
            pstmt = conn.prepareStatement(orderUpdate);
            
            XMLRequestHelper xmlHelper = new XMLRequestHelper(request);
			
			// Get OrderHeader node in the request document
	        NodeList orderHeaderNode = XPathAPI.selectNodeList(request,
                "request/entities/entity/keys");
	        
	        Node orderHeadernode = orderHeaderNode.item(0);
	        
	        BigDecimal grandTotal = new BigDecimal("0.0000");
	        
	        BigDecimal totalPrice = new BigDecimal("0.0000");
	        
	        BigDecimal totalDiscount = new BigDecimal("0.0000");
				
			if (xmlHelper.getAttribute(orderHeadernode, ConstantsForSales.GRANDTOTAL) != null)
                grandTotal =  stringToDecimal(xmlHelper.getAttribute(orderHeadernode, ConstantsForSales.GRANDTOTAL));
			if (xmlHelper.getAttribute(orderHeadernode, ConstantsForSales.TOTALPRICE) != null)
                totalPrice = stringToDecimal(xmlHelper.getAttribute(orderHeadernode, ConstantsForSales.TOTALPRICE));
			if (xmlHelper.getAttribute(orderHeadernode, ConstantsForSales.TOTALDISCOUNT) != null)
                totalDiscount = stringToDecimal(xmlHelper.getAttribute(orderHeadernode, ConstantsForSales.TOTALDISCOUNT));

            String orderID = parameters.getString("orderID");
            pstmt.setString(1, grandTotal.toString());
            pstmt.setString(2, totalPrice.toString());
			pstmt.setString(3, totalDiscount.toString());
			pstmt.setString(4, orderID);

            pstmt.executeUpdate();
            pstmt.clearParameters();

            LOG.debug("Exiting updateOrderHeaderTotalsFromWS");
    	} catch (SQLException se) {
            throw new PipelineRuntimeException("Error executing updateOrderHeaderTotalsFromWS function", se);
        } catch (ParametersException e) {
            throw new PipelineRuntimeException(e);
        } catch (Exception e) {
            throw new PipelineRuntimeException(e);
        }  finally {
            try {
                pstmt.close();
                pstmt = null;
            } catch (Exception e) {
                LOG.error("Error when trying to close prepared statement.");
            }
            try {
                conn.close();
                conn = null;
            } catch (Exception e) {
                LOG.error("Error when trying to close connection.");
            }
        }

    }

    private void initConnection() throws PipelineRuntimeException {
        conn = (Connection) CustomStagesHelper.getConnection("esales.cursor");
        if (!(conn instanceof Connection)) {
            throw new PipelineRuntimeException("Error on establishing database connection");
        } else {
            LOG.debug("Succesfully created SQL Connection!");
        }
    }

    // Destroy/Close MS SQL Connection
    private void closeConnection() throws PipelineRuntimeException {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                throw new PipelineRuntimeException("error closing connnection", e);
            }
        }
    }

    public BigDecimal stringToDecimal(String value) throws ParseException {
        NumberFormat nf = NumberFormat.getNumberInstance();
        //Number n = nf.parse(value);
		Number n = nf.parse(nf.format(new Double(value)));
        if (n instanceof com.ibm.icu.math.BigDecimal) {
            return new BigDecimal(((com.ibm.icu.math.BigDecimal) n).toString());
        } else if (n instanceof BigDecimal) {
            return (BigDecimal) n;
        } else if (n instanceof Long) {
            return new BigDecimal(n.toString());
        } else {
            FastStringBuffer error = new FastStringBuffer();
            error.append("Could not parse as decimal: ");
            error.append(value);
            error.append(". Parser returned unknown decimal type: ");
            error.append(n.getClass());
            throw new ParseException(error.toString(), 0);
        }
    }
}
