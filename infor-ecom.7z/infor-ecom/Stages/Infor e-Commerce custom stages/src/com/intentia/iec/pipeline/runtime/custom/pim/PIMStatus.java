/*
 * Created on 24-02-2006
 */
package com.intentia.iec.pipeline.runtime.custom.pim;

import com.intentia.iec.util.FastStringBuffer;

/**
 * <p>
 * Utility class for parsing the different statuses that a catalog and its
 * structures, products, product relations, articles or images can have in a
 * delta publication.
 * </p>
 * <p>
 * A status represents the status of what could be called an entity. An entity
 * is either a catalog root element, structure, product, product relation,
 * article or image. The status only represents the entity itself, i.e. the
 * status of a product does not represent the descendent articles and images but
 * only the product (and its attributes) itself. Note that images have their own
 * status even though part of a structure/product/article.
 * </p>
 * The statuses and their descriptions: <table BORDER="1">
 * <tr>
 * <td>Status</td>
 * <td>In delta.xml</td>
 * <td>description</td>
 * </tr>
 * <tr>
 * <td>ADDED</td>
 * <td>PCM_delta="ADDED".</td>
 * <td>The entity has been added to the catalog. This is the first occurence of
 * the entity within the delta.xml document. Any subsequent occurences of the
 * entity will have status CONNECTED.</td>
 * </tr>
 * <tr>
 * <td>UPDATED</td>
 * <td>PCM_delta="UPDATED".</td>
 * <td>The entity has been updated, but remains in the same location.</td>
 * </tr>
 * <tr>
 * <td>REMOVED</td>
 * <td>PCM_delta="REMOVED".</td>
 * <td>The entity has been removed from the catalog.</td>
 * </tr>
 * <tr>
 * <td>CONNECTED</td>
 * <td>PCM_delta="CONNECTED".</td>
 * <td>The entity already exists in the catalog, but has been added for the
 * second, third or ? time. Entities with status CONNECTED are never the first
 * occurences within the delta.xml document. The first occurence of an entity
 * will have either status ADDED or UNMODIFIED.</td>
 * </tr>
 * <tr>
 * <td>DISCONNECTED</td>
 * <td>PCM_delta="DISCONNECTED".</td>
 * <td>The entity exists in several locations in the catalog, but has been
 * removed from this particular location.</td>
 * </tr>
 * <tr>
 * <td>UNMODIFIED</td>
 * <td>no PCM_delta attribute.</td>
 * <td>The entity has not been modified or moved in any kind of way.</td>
 * </tr>
 * </table>
 * 
 * <p>
 * PIMStatus.parseStatus() method has been implemented to parse the status
 * values in the delta.xml file and return a whole number (a short) representing
 * the status. This because comparison of short values performe much better than
 * comparison of string values. (comparisons are executed in the switch case
 * constructions in the <code>CatalogIntegrator</code> class).
 * </p>
 * 
 * @author pedjes0
 * 
 */
public class PIMStatus {
    public static final short ADDED = 0;

    public static final short UPDATED = 1;

    public static final short REMOVED = 2;

    public static final short CONNECTED = 3;

    public static final short DISCONNECTED = 4;

    public static final short UNMODIFIED = 5;

    public static final String STATUS_REMOVED = "REMOVED";

    public static final String STATUS_ADDED = "ADDED";

    public static final String STATUS_UPDATED = "UPDATED";

    public static final String STATUS_DISCONNECTED = "DISCONNECTED";

    public static final String STATUS_CONNECTED = "CONNECTED";

    // private constructor because class entirely contains static methods.
    private PIMStatus() {
    }

    public static short parseStatus(final String status) throws CatalogParserException {
        if (status == null) {
            return UNMODIFIED;
        }
        if (status.length() > 0) {
            if (status.charAt(0) == 'A' && STATUS_ADDED.equals(status)) {
                return ADDED;
            } else if (status.charAt(0) == 'R' && STATUS_REMOVED.equals(status)) {
                return REMOVED;
            } else if (status.charAt(0) == 'U' && STATUS_UPDATED.equals(status)) {
                return UPDATED;
            } else if (status.charAt(0) == 'D' && STATUS_DISCONNECTED.equals(status)) {
                return DISCONNECTED;
            } else if (status.charAt(0) == 'C' && STATUS_CONNECTED.equals(status)) {
                return CONNECTED;
            }
        }
        FastStringBuffer error = new FastStringBuffer();
        error.append("Error when reading the delta publish PIM catalog. Unknown status '");
        error.append(status);
        error.append("' occured.");
        throw new CatalogParserException(error.toString());
    }

    public static String toString(final short status) throws CatalogParserException {
        switch (status) {
        case ADDED:
            return STATUS_ADDED;
        case REMOVED:
            return STATUS_REMOVED;
        case UPDATED:
            return STATUS_UPDATED;
        case DISCONNECTED:
            return STATUS_DISCONNECTED;
        case CONNECTED:
            return STATUS_CONNECTED;
        case UNMODIFIED:
            return null;
        default:
            FastStringBuffer error = new FastStringBuffer();
            error.append("Illegal status value '");
            error.append(Short.toString(status));
            error.append("' .");
            throw new CatalogParserException(error.toString());
        }
    }
}
