package com.intentia.iec.pipeline.runtime.stage.custom;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.Resultset;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntime;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.CommitPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

public class GatewayOrderEntry implements PipelineStage {
    private static final Logger LOG = Logger.getLogger(GatewayOrderEntry.class);

    private static final String PARAM_SUBMITORDER = "submitOrder";

    private static final String PARAM_USERGROUPID = "userGroupID";

    private static final String PARAM_A_USERGROUPID = "@UserGroupID";

    private static final String PARAM_USERID = "userID";

    private static final String PARAM_A_USERID = "@UserID";

    private static final String PARAM_NEWORDERID = "newOrderID";

    private static final String PARAM_ORDERID = "orderID";

    private static final String PARAM_USERGROUPKEY = "UserGroupID";

    private static final String PARAM_ORDERRESTRICTION = "orderID_restriction";

    private static final String PARAM_LANGUAGECODE = "@LanguageCode";

    private static final String PARAM_NOTAPPROVER = "notApprover";

    private static final String PARAM_RORC = "RORC";

    private static final String PARAM_M3WAREHOUSE = "@MvxWarehouse";

    private static final String PARAM_AGREEMENTID = "AgreementID";

    private static final String PARAM_CARDEXPIRY = "cardExpiryDate";

    private static final String PARAM_CARDSECCODE = "cardSecurityCode";

    private static final String PARAM_CREDITCARDNUMBER = "creditCardNumber";

    private static final String PARAM_OLINEAVAILABLE = "orderLineAvailable";

    private static final String PARAM_TERMSOFPAYMENT = "termsofpayment";

    private static final String PARAM_PAYMENTCODE = "PaymentCode";

    private static final String PARAM_A_CURRENCYCODE = "@CurrencyCode";

    private static final String PARAM_CALCDELIVERYFEE = "calculateDeliveryFee";

    private static final String PARAM_CALCITEMPRICE = "calculateItemPrice";

    private static final String PARAM_PERSONALDISCOUNT = "calculatePersonalDiscount";

    private static final String PARAM_SHIPPINGFEE = "calculateShippingFee";

    private static final String PARAM_CURRENCYCODE = "currencyCode";

    private static final String PARAM_LISTPRICEGROUP = "listPriceGroupId";

    private static final String PARAM_NETPRICEGROUP = "netPriceGroupId";

    private static final String PARAM_ALTEXGRATE = "altExchangeRate";

    private static final String PARAM_EXGRATE = "exchangeRate";

    private static final String PARAM_NOTADMIN = "notAdmin";

    private static final String PARAM_NOTRESELLERADMIN = "notAdminNorResellerAdmin";

    private static final String PARAM_EXECINLTAX = "executeIncludeTax";

    private static final String PARAM_PAYMENTSTATUS = "paymentStatus";

    private static final String PARAM_STATUSAPP = "statusApp";

    private static final String PARAM_APPROVEDDATE = "approvedDate";

    private static final String PARAM_APPROVERID = "approverId";
    
    private static final String PARAM_MVXCUNO = "mvxCUNO";

    private static final String ATTR_ORDERID = "OrderID";

    private static final String ATTR_COMPANYID = "CompanyID";
    
    private static final String ATTR_SHIPPINGADDRESSID = "ShippingAddressID";

    private static final String ELEM_KEY = "key";

    private static final String ELEM_KEYS = "keys";

    private static final String ELEM_ATTRIBUTE = "attribute";

    private static final String ELEM_ATTR_NAME = "name";

    private static final String ELEM_ATTR_VALUE = "value";
    
    private static final String PARAM_WAREHOUSEID="warehouseId";
    
    private static final String PARAM_SHIPPINGADDRESSID="shippingAddressId";
    
    /**
     * 
     */
    public void execute(PipelineContext pipelinecontext) throws PipelineRuntimeException {

        try {

            XMLRequest.extractRequestParameters((XMLRequest) pipelinecontext.getRequest());

            final Parameters params = CustomStagesHelper.getRequestParameters(pipelinecontext);

            XMLResultset rs = initializeOrder(params);
            Parameters initParams = rs.getParameters();
            String newOrderIDTmp = initParams.getString(PARAM_NEWORDERID);
            
            updateShippingAddressID(newOrderIDTmp);

            addOrderLines(pipelinecontext, params, newOrderIDTmp);

            updatePrices(params, newOrderIDTmp);

            updatePaymentStatus(params, newOrderIDTmp);

            XMLResultset ret = callOrderExecute(params, newOrderIDTmp);
            Parameters mvxStatusPrams = ret.getParameters();
            int mvxStatus = mvxStatusPrams.getint(ConstantsForSales.MVXSTATUS);
            String submittedOrderID = mvxStatusPrams.getString(ConstantsForSales.SUBMITTEDORDERID);
            if (mvxStatus < 0) {
                // int stats = mvxStatusPrams.getint(ConstantsForSales.STATUS);
                throw new PipelineRuntimeException("An error was returned by M3 with an error code: " + mvxStatus);
            }

            setXMLResponse(pipelinecontext, params, submittedOrderID);
        } catch (PipelineRuntimeException e) {
            LOG.debug(e.getMessage());
            throw e;
        } catch (Exception e) {
            LOG.debug(e.getMessage());
            throw new PipelineRuntimeException(e);
        }
    }
    
    /**
     * Update the Order's shippingAddressID to <blank>
     * 
     * @param newOrderIDTmp
     * @throws PipelineRuntimeException
     */
    private void updateShippingAddressID(String newOrderIDTmp) 
    		throws RequestException, TransformerException, PipelineRuntimeException {
    	CommitPipelineExecuter tmpOrder = new CommitPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                "CurrentOrder", "UpdateInfo");
    	
    	tmpOrder.addEntity();
    	tmpOrder.setEntityKey(ATTR_ORDERID, newOrderIDTmp);
    	tmpOrder.setParam(PARAM_ORDERID, newOrderIDTmp);
    	tmpOrder.setAttribute(ATTR_ORDERID, newOrderIDTmp);
    	tmpOrder.setAttribute(ATTR_SHIPPINGADDRESSID, null);
    	
    	tmpOrder.execute();
    }

    /**
     * Insert the order lines in the db
     * 
     * @param pipelinecontext
     * @param params
     * @param newOrderIDTmp
     * @throws RequestException
     * @throws TransformerException
     * @throws PipelineRuntimeException
     */
    protected void addOrderLines(PipelineContext pipelinecontext, final Parameters params, String newOrderIDTmp)
            throws RequestException, TransformerException, PipelineRuntimeException {
        // insert order lines
        XMLRequest request = (XMLRequest) pipelinecontext.getRequest();
        org.w3c.dom.Document xmlDoc = request.getRequestDoc();
        Node nd = XPathAPI.selectSingleNode(xmlDoc, "request/entities/entity/keys/key[@name='" + ATTR_ORDERID + "']");

        if (nd == null) {
            Element keyElem = xmlDoc.createElement(ELEM_KEY);
            keyElem.setAttribute(ELEM_ATTR_NAME, ATTR_ORDERID);
            keyElem.setAttribute(ELEM_ATTR_VALUE, newOrderIDTmp);
            Node keysElem = XPathAPI.selectSingleNode(xmlDoc, "request/entities/entity/keys");
            if (keysElem == null) {
                keysElem = xmlDoc.createElement(ELEM_KEYS);
            }
            keysElem.appendChild(keyElem);
            Node entityKeyAttr = XPathAPI.selectSingleNode(xmlDoc, "request/entities/entity");
            entityKeyAttr.appendChild(keysElem);
        } else {
            ((Element) nd).getAttributeNode(ELEM_ATTR_VALUE).setValue(newOrderIDTmp);
        }

        // Add/Update the correct company id
        Node companyIDAttr = XPathAPI.selectSingleNode(xmlDoc, "request/entities/entity/attributes/attribute[@name='"
                + ATTR_COMPANYID + "']");

        if (companyIDAttr == null) {
            Element attrElem = xmlDoc.createElement(ELEM_ATTRIBUTE);
            attrElem.setAttribute(ELEM_ATTR_NAME, ATTR_COMPANYID);
            attrElem.appendChild(xmlDoc.createTextNode(paramGetString(params, PARAM_USERGROUPKEY)));
            companyIDAttr = XPathAPI.selectSingleNode(xmlDoc, "request/entities/entity/attributes");
            companyIDAttr.appendChild(attrElem);
        } else {
            companyIDAttr.getFirstChild().setNodeValue(paramGetString(params, PARAM_USERGROUPKEY));
        }

        XMLRequestHelper xmlHelper = new XMLRequestHelper(request);
        xmlHelper.setParam(PARAM_ORDERID, newOrderIDTmp);
        xmlHelper.logRequest();

        executePipeline(pipelinecontext, ConstantsForSales.PIPELINE_PACKAGE + ".CurrentOrder" + ".Update");
    }

    /**
     * Create a temporary order
     * 
     * @param params
     * @return
     * @throws PipelineRuntimeException
     */
    private XMLResultset initializeOrder(final Parameters params) throws PipelineRuntimeException {
        // create an temoprary order
        CommitPipelineExecuter orderInit = new CommitPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                "CurrentOrder", "Init");
        orderInit.setParam(PARAM_SUBMITORDER, paramGetString(params, PARAM_SUBMITORDER));
        orderInit.setParam(PARAM_USERGROUPID, paramGetString(params, PARAM_A_USERGROUPID));
        orderInit.setParam(PARAM_USERID, paramGetString(params, PARAM_A_USERID));
        XMLResultset rs = orderInit.execute();
        return rs;
    }

    /**
     * Update the prices of the temporary order
     * 
     * @param params
     * @param newOrderIDTmp
     * @throws PipelineRuntimeException
     */
    protected void updatePrices(final Parameters params, String newOrderIDTmp) throws PipelineRuntimeException {
        // Update Item prices
        CommitPipelineExecuter calculatePrice = new CommitPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                "CurrentOrder", "Calculate");
        calculatePrice.setParam(PARAM_CALCDELIVERYFEE, paramGetString(params, PARAM_CALCDELIVERYFEE));
        calculatePrice.setParam(PARAM_CALCITEMPRICE, paramGetString(params, PARAM_CALCDELIVERYFEE));
        calculatePrice.setParam(PARAM_PERSONALDISCOUNT, paramGetString(params, PARAM_PERSONALDISCOUNT));
        calculatePrice.setParam(PARAM_SHIPPINGFEE, paramGetString(params, PARAM_SHIPPINGFEE));
        calculatePrice.setParam(PARAM_CURRENCYCODE, paramGetString(params, PARAM_A_CURRENCYCODE));
        calculatePrice.setParam(PARAM_LISTPRICEGROUP, paramGetString(params, PARAM_LISTPRICEGROUP));
        calculatePrice.setParam(PARAM_NETPRICEGROUP, paramGetString(params, PARAM_NETPRICEGROUP));
        calculatePrice.setParam(PARAM_ORDERID, newOrderIDTmp);

        calculatePrice.execute();
    }

    /**
     * Send the order to movex
     * 
     * @param params
     * @param newOrderIDTmp
     * @return
     * @throws PipelineRuntimeException
     */
    protected XMLResultset callOrderExecute(final Parameters params, String newOrderIDTmp)
            throws PipelineRuntimeException {
        // Send order to movex and save to order history
        CommitPipelineExecuter orderExecute = new CommitPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                "CurrentOrder", "Execute");
        // TODO: other parameters
        orderExecute.setParam(PARAM_ORDERID, newOrderIDTmp);
        String orderIDRestiction = paramGetString(params, PARAM_ORDERRESTRICTION);
        if (null == orderIDRestiction) {
            orderIDRestiction = newOrderIDTmp;
        }
        orderExecute.setParam(PARAM_ORDERRESTRICTION, orderIDRestiction);
        orderExecute.setParam(PARAM_LANGUAGECODE, paramGetString(params, PARAM_LANGUAGECODE));
        orderExecute.setParam(PARAM_NOTAPPROVER, paramGetString(params, PARAM_NOTAPPROVER));
        orderExecute.setParam(PARAM_RORC, paramGetString(params, PARAM_RORC));
        orderExecute.setParam(PARAM_M3WAREHOUSE, paramGetString(params, PARAM_M3WAREHOUSE));
        orderExecute.setParam(PARAM_A_USERGROUPID, paramGetString(params, PARAM_A_USERGROUPID));
        orderExecute.setParam(PARAM_USERGROUPKEY, paramGetString(params, PARAM_USERGROUPKEY));
        orderExecute.setParam(PARAM_MVXCUNO, paramGetString(params, PARAM_MVXCUNO));
        orderExecute.setParam(PARAM_A_CURRENCYCODE, paramGetString(params, PARAM_A_CURRENCYCODE));
        orderExecute.setParam(PARAM_A_USERID, paramGetString(params, PARAM_A_USERID));
        orderExecute.setParam(PARAM_AGREEMENTID, paramGetString(params, PARAM_AGREEMENTID));
        orderExecute.setParam(PARAM_CARDEXPIRY, paramGetString(params, PARAM_CARDEXPIRY));
        orderExecute.setParam(PARAM_CARDSECCODE, paramGetString(params, PARAM_CARDSECCODE));
        orderExecute.setParam(PARAM_CREDITCARDNUMBER, paramGetString(params, PARAM_CREDITCARDNUMBER));
        orderExecute.setParam(PARAM_OLINEAVAILABLE, paramGetString(params, PARAM_OLINEAVAILABLE));
        orderExecute.setParam(PARAM_TERMSOFPAYMENT, paramGetString(params, PARAM_TERMSOFPAYMENT));
        orderExecute.setParam(PARAM_PAYMENTCODE, paramGetString(params, PARAM_PAYMENTCODE));
        orderExecute.setParam(PARAM_SHIPPINGADDRESSID,paramGetString(params, PARAM_SHIPPINGADDRESSID));
        orderExecute.setParam(PARAM_WAREHOUSEID,paramGetString(params, PARAM_WAREHOUSEID));
        orderExecute.setParam(ConstantsForSales.SIMULATE_EXECUTE_SUBMIT, "true");
        XMLResultset ret = orderExecute.execute();
        return ret;
    }

    /**
     * Update the payment status
     * 
     * @param params
     * @throws PipelineRuntimeException
     */
    protected void updatePaymentStatus(final Parameters params, String newOrderid) throws PipelineRuntimeException {
        CommitPipelineExecuter approveOrder = new CommitPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                "CurrentOrder", "OrderForApprovalApprove");
        approveOrder.addEntity();
        approveOrder.setEntityKey(ATTR_ORDERID, newOrderid);
        approveOrder.setParam(PARAM_PAYMENTSTATUS, paramGetString(params, PARAM_PAYMENTSTATUS));
        approveOrder.setParam(PARAM_STATUSAPP, paramGetString(params, PARAM_STATUSAPP));
        approveOrder.setParam(PARAM_APPROVEDDATE, paramGetString(params, PARAM_APPROVEDDATE));
        approveOrder.setParam(PARAM_APPROVERID, paramGetString(params, PARAM_A_USERID));
        approveOrder.execute();
    }

    /**
     * Retrive the order for output to gateway
     * 
     * @param pipelinecontext
     * @param params
     * @param submittedOrderID
     * @throws PipelineRuntimeException
     */
    protected void setXMLResponse(PipelineContext pipelinecontext, final Parameters params, String submittedOrderID)
            throws PipelineRuntimeException {
        // Output the Order
        SearchPipelineExecuter orderHistory = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                "PreviousOrder",
                // "Details");
                "DownloadOrder");
        // orderHistory.setBinding(ATTR_ORDERID, submittedOrderID, "eq");
        orderHistory.setParam(ATTR_ORDERID, submittedOrderID);
        orderHistory.setParam(PARAM_LANGUAGECODE, paramGetString(params, PARAM_LANGUAGECODE));
        orderHistory.setParam(PARAM_ALTEXGRATE, paramGetString(params, PARAM_ALTEXGRATE));
        orderHistory.setParam(PARAM_EXGRATE, paramGetString(params, PARAM_EXGRATE));
        orderHistory.setParam(PARAM_EXECINLTAX, paramGetString(params, PARAM_EXECINLTAX));
        orderHistory.setParam(PARAM_NOTADMIN, paramGetString(params, PARAM_NOTADMIN));
        orderHistory.setParam(PARAM_NOTRESELLERADMIN, paramGetString(params, PARAM_NOTRESELLERADMIN));
        orderHistory.setParam(PARAM_USERID, paramGetString(params, PARAM_A_USERID));
        orderHistory.setParam(PARAM_USERGROUPID, paramGetString(params, PARAM_USERGROUPKEY));

        pipelinecontext.setResponse(orderHistory.execute());
    }

    /**
     * Utility to get parameters
     * 
     * @param params
     * @param key
     * @return
     * @throws PipelineRuntimeException
     */
    protected String paramGetString(Parameters params, String key) throws PipelineRuntimeException {
        String ret = null;
        try {
            ret = params.getString(key);
        } catch (Exception e) {
            throw new PipelineRuntimeException(e);
        }
        return ret;
    }

    /**
     * Utility to execute a Business Object method
     * 
     * @param pipelinecontext
     * @param pipelineClass
     * @throws PipelineRuntimeException
     */
    protected void executePipeline(PipelineContext pipelinecontext, String pipelineClass)
            throws PipelineRuntimeException {
        try {

            Class runtimeClass = Class.forName(pipelineClass);
            PipelineRuntime pipeline = (PipelineRuntime) runtimeClass.newInstance();
            pipeline.execute(pipelinecontext);
        } catch (ClassNotFoundException e1) {
            LOG.fatal((new StringBuilder()).append("Could not find class '").append(pipelineClass).append("'")
                    .toString(), e1);
            throw new PipelineRuntimeException(e1);
        } catch (IllegalAccessException e2) {
            LOG.fatal((new StringBuilder()).append("Illegal access to class '").append(pipelineClass).append("'")
                    .toString(), e2);
            throw new PipelineRuntimeException(e2);
        } catch (InstantiationException e3) {
            LOG.fatal((new StringBuilder()).append("Could not instantiate class '").append(pipelineClass).append("'")
                    .toString(), e3);
            throw new PipelineRuntimeException(e3);
        }
    }

}
