/*
 * Created on 22-11-2004
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

/**
 * This e-Sales custom stage is used to clear all deleted Item(i.e. Deleted from
 * Item table ) from Google Base Server and have also delete from
 * SearchEngineItem table.
 * 
 * @author xinc0082(Mayur)
 */
public class SearchEngineItemDelete extends AbstractPipelineStage {

    private static final Logger LOG = Logger.getLogger(SearchEngineItemDelete.class);

    public SearchEngineItemDelete() {
        super();
    }

    public final void execute(final PipelineContext context) throws PipelineRuntimeException {

        LOG.debug("Inside SearchEngineItemDelete().execute()........");

        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
        XMLRequest xmlRequest = (XMLRequest) context.getRequest();

        boolean flag = false;
        try {
            flag = XMLRequestHelper.isDeleteRequest(xmlRequest);

            // LOG.debug("Inside SearchEngineItemDelete().execute() flag = " +
            // flag);
        } catch (Exception ex) {

        }

        // if it is delete request then only it would delete frm search engine
        if (flag) {
            try {
                UploadItemToSearchEngine.deleteItemFromSearchEngine();
            } catch (Exception e1) {
                LOG.error("Error occurred into SearchEngineItemDelete.execute() ,  ", e1);
            }
        } else {// end of if(flag)

            LOG.debug("Search Engine is not enable so operation is aborting.........");
        }
    }
}