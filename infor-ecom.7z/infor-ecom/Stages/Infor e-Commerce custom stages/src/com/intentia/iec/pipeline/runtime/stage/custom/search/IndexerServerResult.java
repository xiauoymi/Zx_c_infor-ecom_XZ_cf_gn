package com.intentia.iec.pipeline.runtime.stage.custom.search;

import java.io.Serializable;

/**
 * This is the result of indexing on a two-server set-up.
 *
 */
public class IndexerServerResult implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -312695590078700451L;

    private boolean wasSuccessful = false;

    private byte[] zipContent = null;

    public IndexerServerResult() {
    }

    public IndexerServerResult(boolean wasSuccesful, byte[] zipContent) {
        this.wasSuccessful = wasSuccesful;
        this.zipContent = zipContent;
    }

    public boolean wasSuccessful() {
        return this.wasSuccessful;
    }

    public byte[] getZipContent() {
        return this.zipContent;
    }
}
