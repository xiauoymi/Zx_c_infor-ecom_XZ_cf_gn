package com.intentia.iec.pipeline.runtime.integration.erp.exception;

public class ErpRuntimeException extends Exception {

	private static final long serialVersionUID = 1L;
	
	private String errorCode;

	private String message;
	

	public ErpRuntimeException(String errorCode) {
		super();
		this.errorCode = errorCode;
	}

	public ErpRuntimeException(String errorCode, String message) {
		super(message);
		this.errorCode = errorCode;
		this.message = message;
	}

	public ErpRuntimeException(String errorCode, Throwable cause) {
		super(cause);
		this.errorCode = errorCode;
		this.message = cause.getMessage();
	}

	public ErpRuntimeException(String errorCode, String message, Throwable cause) {
		super(message, cause);
		this.errorCode = errorCode;
		this.message = message;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
