package com.intentia.iec.pipeline.runtime.integration.ia.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.intentia.iec.pipeline.runtime.integration.ia.dao.IaDao;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaConnectionException;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaNotSupportedApiException;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.ia.model.IaCampaign;
import com.intentia.iec.pipeline.runtime.integration.ia.model.IaPromotion;
import com.intentia.iec.pipeline.runtime.integration.ia.model.IaRecommendation;
import com.intentia.iec.pipeline.runtime.integration.ia.utils.IaRestApiClient;
import com.intentia.iec.pipeline.runtime.integration.ia.utils.IaConstants.AcceptanceLevel;

public class IaDaoRestImpl implements IaDao {

	private static final Logger log = Logger.getLogger(IaDaoRpImpl.class);

	private static final String NOT_SUPPORTED_API_MSG = "Not supported by IA's RP API. Use IA's REST API instead.";

	private IaRestApiClient restClient = null;

	public IaDaoRestImpl() throws IaConnectionException {
		restClient = IaRestApiClient.getInstance();
	}

	@Override
	public void addCampaign(IaCampaign campaign) throws IaRuntimeException {
		if (campaign != null) {
			log.debug("Adding campaign to IA: " + campaign);
			restClient.createCampaign(campaign);
		}
	}

	@Override
	public void addPromotion(IaPromotion promotion) throws IaRuntimeException {
		if (promotion != null) {
			log.debug("Adding promotion to IA: " + promotion);
			restClient.createPromotion(promotion);
		}
	}

	@Override
	public void refinePackage() throws IaRuntimeException {
		restClient.refinePackage();
	}

	@Override
	public void deployPackage() throws IaRuntimeException {
		restClient.deployPackage();
	}

	@Override
	public List<IaCampaign> getCampaigns(String event,
			Map<String, String> params) throws IaRuntimeException {
		throw new IaRuntimeException(new IaNotSupportedApiException(
				NOT_SUPPORTED_API_MSG));
	}

	@Override
	public List<IaPromotion> getPromotions(String event,
			Map<String, String> params) throws IaRuntimeException {
		throw new IaRuntimeException(new IaNotSupportedApiException(
				NOT_SUPPORTED_API_MSG));
	}

	@Override
	public List<IaRecommendation> getRecommendations(String event,
			Map<String, String> params) throws IaRuntimeException {
		throw new IaRuntimeException(new IaNotSupportedApiException(
				NOT_SUPPORTED_API_MSG));
	}

	@Override
	public void extendCampaigns(String ids, Map<String, String> params)
			throws IaRuntimeException {
		throw new IaRuntimeException(new IaNotSupportedApiException(
				NOT_SUPPORTED_API_MSG));
	}

	@Override
	public void acceptCampaigns(String ids, AcceptanceLevel level, Map<String, String> params)
			throws IaRuntimeException {
		throw new IaRuntimeException(new IaNotSupportedApiException(
				NOT_SUPPORTED_API_MSG));
	}

	@Override
	public void extendPromotions(String ids, Map<String, String> params)
			throws IaRuntimeException {
		throw new IaRuntimeException(new IaNotSupportedApiException(
				NOT_SUPPORTED_API_MSG));
	}

	@Override
	public void acceptPromotions(String ids, AcceptanceLevel level, Map<String, String> params)
			throws IaRuntimeException {
		throw new IaRuntimeException(new IaNotSupportedApiException(
				NOT_SUPPORTED_API_MSG));
	}

	@Override
	public void deleteCampaign(IaCampaign campaign) throws IaRuntimeException {
		if (campaign != null) {
			log.debug("Deleting campaign from IA: " + campaign);
			restClient.deleteCampaign(campaign);
		}
		
	}

	@Override
	public void deletePromotion(IaPromotion promotion)
			throws IaRuntimeException {
		
		if (promotion != null) {
			log.debug("Deleting promotion from IA: " + promotion);
			restClient.deletePromotion(promotion);
		}
	}

	@Override
	public void endSession(String sessionId, String userId, String groupId)
			throws IaRuntimeException {
		// TODO Auto-generated method stub
		
	}
}
