package com.intentia.iec.pipeline.runtime.integration.erp.model;

import java.util.List;

public class CatalogPrice {
	
	private List<Item> items;	

	private boolean hasWSCallError;
	
	private String msgError;
	
	private String msgCodeError;

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	public boolean isHasWSCallError() {
		return hasWSCallError;
	}

	public void setHasWSCallError(boolean hasWSCallError) {
		this.hasWSCallError = hasWSCallError;
	}

	public String getMsgError() {
		return msgError;
	}

	public void setMsgError(String msgError) {
		this.msgError = msgError;
	}

	public String getMsgCodeError() {
		return msgCodeError;
	}

	public void setMsgCodeError(String msgCodeError) {
		this.msgCodeError = msgCodeError;
	}

}
