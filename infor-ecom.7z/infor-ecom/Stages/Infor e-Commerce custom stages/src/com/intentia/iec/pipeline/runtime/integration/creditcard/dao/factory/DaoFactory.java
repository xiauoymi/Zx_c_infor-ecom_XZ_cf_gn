package com.intentia.iec.pipeline.runtime.integration.creditcard.dao.factory;

import org.apache.log4j.Logger;

import com.intentia.iec.pipeline.runtime.integration.creditcard.dao.CreditCardAdminDao;
import com.intentia.iec.pipeline.runtime.integration.creditcard.dao.CreditCardDao;
import com.intentia.iec.pipeline.runtime.integration.creditcard.exception.CreditCardConnectionException;

public abstract class DaoFactory {
	
	private static final Logger LOG = Logger.getLogger(DaoFactory.class);
	public abstract CreditCardDao getCreditCardDao() throws CreditCardConnectionException;
	public abstract CreditCardAdminDao getCreditCardAdminDao() throws CreditCardConnectionException;

	public static DaoFactory getDAOFactory() throws CreditCardConnectionException{	
		return new WebserviceDaoFactory();
	}

}