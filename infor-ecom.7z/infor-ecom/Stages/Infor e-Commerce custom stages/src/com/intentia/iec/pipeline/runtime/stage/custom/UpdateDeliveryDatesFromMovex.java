/*
 * Created on 19-03-2004
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.util.FastStringBuffer;

/**
 * <p>
 * The stage <code>UpdateDeliveryDatesFromMovex</code> updates delivery dates
 * for the products according to what Movex tells is the delivery date.<br>
 * The stage is meant to be placed in a pipeline in an order business object.
 * </p>
 * <p>
 * The stage will exit immediately if application property
 * <code>Movex Connector / Enable</code> is false.
 * </p>
 * <p>
 * <b>Required input in <code>PipelineContext</code>:</b><br>
 * Input parameter: orderLineAvailable. The stage requires that the
 * <code>PipelineContext</code> contains a response representing an order with
 * attributes MvxCompany and MvxWarehouse and with order lines.
 * </p>
 * <p>
 * <b>Generated output in <code>PipelineContext</code>:</b><br>
 * When done the stage has modified the commit request in the
 * <code>PipelineContext</code>. Output parameter: mvxStatus (error if
 * negative).
 * </p>
 */
public class UpdateDeliveryDatesFromMovex implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(UpdateDeliveryDatesFromMovex.class);

    // Input parameter to signal if availablity should be checked.
    private static final String ORDERLINEAVAILABLE = "orderLineAvailable";

    // Internal variables
    private String mvxCompany = null;

    private String mvxWarehouse = null;

    /**
     * The stage entry point.
     * 
     * @see com.intentia.iec.pipeline.runtime.PipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
     */
    public void execute(PipelineContext context) throws PipelineRuntimeException {

        // Movex connector not enabled => skip stage
        if (!"true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.CONNECTORENABLED))) {
            return;
        }

        CustomStagesHelper.extractRequestParameters(CustomStagesHelper.getRequest(context));
        String orderLineAvailable = getParamValueAsString(ORDERLINEAVAILABLE, context);

        if (!"true".equals(orderLineAvailable)) {
            LOG.debug("Parameter orderLineAvailable is not true: " + orderLineAvailable);
            return;
        }

        boolean executeSubmit = Boolean.valueOf(
                getParamValueAsString(ConstantsForSales.SIMULATE_EXECUTE_SUBMIT, context)).booleanValue();

        if (!executeSubmit) {
            LOG.debug("Simulate Order Skip");
            return;
        }

        try {
            XMLResultset result = (XMLResultset) context.getResponse();
            if ((result == null) || (result.isEmpty())) {
                LOG.debug("The resultset passed to this stage is null or empty: resultset is null = "
                        + (result == null) + " or resultset is empty = " + result.isEmpty());
                return;
            }
            result.moveFirst();
            String requestedDeliveryDateHead = result.getString(ConstantsForSales.REQUESTEDDELIVERYDATE);

            XMLIterator lines = (XMLIterator) result.getResultset(ConstantsForSales.ORDERLINE);
            if ((lines == null) || lines.isEmpty()) {
                LOG.debug("The sub resultset orderlines is null or empty: resultset is null = " + (lines == null)
                        + " or resultset is empty = " + lines.isEmpty());
                return;
            }

            mvxCompany = result.getString(ConstantsForSales.MVXCOMPANY);
            mvxWarehouse = result.getString(ConstantsForSales.MVXWAREHOUSE);

            // Update the requested delivery dates on the lines to ensure they
            // have a value
            updateLineDeliveryDates(lines, requestedDeliveryDateHead);

            // Update delivery dates according to what Movex promises
            // updateATPDates(context, lines);

        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Could not get order lines from resultset.", e);
        }
    }

    /**
     * Update the requested delivery dates on the lines to ensure they have a
     * value - the value given in the call.
     * <p>
     * The method is meant to be called from other classes too.
     * 
     * @param lines
     *            the order lines to iterate - as an XMLIterator
     * @param requestedDeliveryDate
     *            date to insert of an empty date
     * @throws PipelineRuntimeException
     */
    public static void updateLineDeliveryDates(XMLIterator lines, String requestedDeliveryDate)
            throws PipelineRuntimeException {

        lines.beforeFirst();
        try {
            while (lines.moveNext()) {
                String lineDeliveryDate = lines.getString(ConstantsForSales.REQUESTEDDELIVERYDATE);

                if (lineDeliveryDate == null || "".equals(lineDeliveryDate)) {
                    // use requested delivery date from order header instead
                    if (LOG.isDebugEnabled()) {
                        FastStringBuffer msg = new FastStringBuffer(
                                "Using requested delivery date from order header: '");
                        msg.append(requestedDeliveryDate);
                        msg.append("'.");
                        LOG.debug(msg.toString());
                    }
                    if (requestedDeliveryDate != null) {
                        lines.setString(ConstantsForSales.REQUESTEDDELIVERYDATE, requestedDeliveryDate);
                    }
                    if (((requestedDeliveryDate == null) || ("".equals(requestedDeliveryDate)))
                            && ((lineDeliveryDate == null) || ("".equals(lineDeliveryDate)))) {
                        FastStringBuffer msg1 = new FastStringBuffer(
                                "Using Current Date as requested delivery as Date in Header in Null: '");

                        String dateStr = getDateString();
                        lines.setString(ConstantsForSales.REQUESTEDDELIVERYDATE, dateStr);
                        msg1.append(dateStr);
                        msg1.append("'.");
                        LOG.debug(msg1.toString());
                    }
                }
            }
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Could not loop orderline resultset to set delivery dates.", e);
        }
        // always needs to reset the resultset!
        lines.beforeFirst();
    }

    /**
     * Updates delivery date for all order lines.
     * 
     * @param context
     *            the pipeline context
     * @param lines
     *            the subset with order lines to update
     * @throws PipelineRuntimeException
     */
    private void updateATPDates(PipelineContext context, XMLIterator lines) throws PipelineRuntimeException {

        // prepare getting ATP for the order lines
        lines.beforeFirst();

        try {
            while (lines.moveNext()) {
                // get ATP for a line
                updateATPForLine(context, lines);
            }
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Could not loop orderline resultset to set delivery dates.", e);
        }
        // always needs to reset the resultset!
        lines.beforeFirst();
    }

    /**
     * Updates delivery date for a single order line (item). The date is fetched
     * from Movex as the latest available to promise (ATP) date in the returned
     * list to find out when all items can be delivered.
     * <p>
     * The method does not convert to a Date class, but uses a String as the
     * date format is comparable: yyyymmddTHHMMSS.
     * 
     * @param context
     *            the pipeline context
     * @param lines
     *            the subset with position on order line to update
     * @throws PipelineRuntimeException
     */
    private void updateATPForLine(PipelineContext context, XMLIterator lines) throws PipelineRuntimeException {

        // Pipeline for getting the deliver available to pget ATP date
        SearchPipelineExecuter findDeliveryDate = new SearchPipelineExecuter("com.intentia.iec.runtime.pipeline",
                "MvxOrderPromise", "GetOrderPromise");
        // java.util.Date currDate=new java.util.Date(System.getDate());

        try {
            String requestedDeliveryDate = lines.getString(ConstantsForSales.REQUESTEDDELIVERYDATE);
            if ((requestedDeliveryDate == null) || ("".equals(requestedDeliveryDate))) {
                String dateStr = getDateString();
                requestedDeliveryDate = dateStr;
            }
            findDeliveryDate.setParam(ConstantsForSales.MVXCOMPANY_PARAM, mvxCompany);
            findDeliveryDate.setParam(ConstantsForSales.MVXWAREHOUSE_PARAM, mvxWarehouse);
            findDeliveryDate.setParam(ConstantsForSales.ITEMID_PARAM, lines.getString(ConstantsForSales.ITEMID));
            findDeliveryDate.setParam(ConstantsForSales.REQUESTEDQUANTITY, lines.getString(ConstantsForSales.QUANTITY));
            findDeliveryDate.setParam(ConstantsForSales.REQUESTEDDELIVERYDATE_PARAM, requestedDeliveryDate);
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException(
                    "Failed to fetch information for Order Promise pipeline from order line in resultset.", e);
        }

        // Send the request to Movex (execute the pipeline).
        XMLResultset dates = findDeliveryDate.execute();
        try {
            // Loop the returned resultset to find the latest date to find out
            // when all items can be delivered.
            String latestDate = null;
            if (dates != null) {
                while (dates.moveNext()) {
                    String date = dates.getString(ConstantsForSales.ATPDATE);
                    if (latestDate == null) {
                        latestDate = date;
                    } else if (latestDate.compareTo(date) < 0) {
                        latestDate = date;
                    }
                }
            }
            if (latestDate != null) {
                // Set the delivery date in the order line
                lines.setString(ConstantsForSales.REQUESTEDDELIVERYDATE, latestDate);
            }
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Failed to set delivery date in order line resultset", e);
        }
    }

    /**
     * Gets a named parameter from the parameter block in the pipeline context.
     * 
     * @param parameterName
     *            name of the requested parameter
     * @param params
     *            pipeline request parameters including requested parameter
     * @return the parameter value as a string - empty if not found
     */
    private String getParamValueAsString(final String parameterName, PipelineContext context) {
        try {
            return ((XMLRequest) context.getRequest()).getParameters().getString(parameterName);
        } catch (ParametersException e) {
            LOG.error("Try to get parameter: " + parameterName);
            return "";
        }
    }

    public static String getDateString() {
        java.util.Calendar cal = new java.util.GregorianCalendar();

        int yy = cal.get(cal.YEAR); // 2002
        int mm = cal.get(cal.MONTH) + 1; // 0=Jan, 1=Feb, ...
        int dd = cal.get(cal.DAY_OF_MONTH);

        String dStr = String.valueOf(dd);
        String mStr = String.valueOf(mm);
        String yStr = String.valueOf(yy);

        if (mm < 10) {
            mStr = "0" + mStr;
        }
        if (dd < 10) {
            dStr = "0" + dStr;
        }

        String dateStr = yStr + "-" + mStr + "-" + dStr + "T00:00:00.000";
        return dateStr;
    }
}
