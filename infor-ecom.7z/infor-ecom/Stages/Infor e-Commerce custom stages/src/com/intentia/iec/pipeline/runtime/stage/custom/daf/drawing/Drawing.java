package com.intentia.iec.pipeline.runtime.stage.custom.daf.drawing;

import java.util.ArrayList;
import java.util.List;


/**
 * Class that represents a Drawing in e-Sales and DAF.
 *
 */
class Drawing {

	private String itemNumber = null;
	
	private String serialNumber = null;
	
	private String id = null;
	
	private String name = null;
	
	private String drawingNumber = null;
	
	private String imageMaster = null;
	
	private List<HotSpot> list = new ArrayList<HotSpot>();
	
	private String isDefault = null;
	
	/**
	 * Constructor
	 * @param id
	 * @param name
	 * @param drawingNumber
	 * @param itemNumber
	 * @param isDefault
	 */
	public Drawing(String id, String name, String drawingNumber, String itemNumber, String isDefault) {
		this(id, name, drawingNumber, itemNumber, null, isDefault);
	}
	
	/**
	 * @param id
	 * @param name
	 * @param drawingNumber
	 * @param itemNumber
	 * @param serialNumber
	 * @param isDefault
	 */
	public Drawing(String id, String name, String drawingNumber, String itemNumber, String serialNumber, String isDefault) {
		this.id = id;
		this.name = name;
		this.drawingNumber = drawingNumber;
		this.itemNumber = itemNumber;
		this.serialNumber = serialNumber;
		this.isDefault = isDefault;
	}
	
	/**
	 * Returns Is Default
	 * @return
	 */
	public String getIsDefaut() {
		return this.isDefault;
	}
	
	/**
	 * Returns the ID
	 * @return
	 */
	public String getId() {
		return this.id;
	}
	
	/**
	 * Returns the Name
	 * @return
	 */
	public String getName() {
		return this.name;
	}
	
	/**
	 * Returns the Drawing Number
	 * @return
	 */
	public String getDrawingNumber() {
		return this.drawingNumber;
	}
	
	/**
	 * Returns the Master Image
	 * @return
	 */
	public String getImageMaster() {
		return this.imageMaster;
	}
	
	/**
	 * Sets the Master Image
	 * @param imageMaster
	 */
	public void setImageMaster(String imageMaster) {
		this.imageMaster = imageMaster;
	}
	
	/**
	 * Adds all hot spots in the List
	 * @param list
	 */
	public void addHotSpots(List<HotSpot> list) {
		this.list.addAll(list);
	}
	
	/**
	 * Returns the Item Number
	 * @return
	 */
	public String getItemNumber() {
		return this.itemNumber;
	}
	
	/**
	 * Returns the Serial Number
	 * @return
	 */
	public String getSerialNumber() {
		return this.serialNumber;
	}
	
	/**
	 * Returns all Hot spots.
	 * @return
	 */
	public List<HotSpot> getHotSpots() {
		return this.list;
	}	
}
