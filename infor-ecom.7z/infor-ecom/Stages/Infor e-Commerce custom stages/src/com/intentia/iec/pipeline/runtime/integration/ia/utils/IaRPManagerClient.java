package com.intentia.iec.pipeline.runtime.integration.ia.utils;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.epiphany.rpbean.RPManager;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaConnectionException;

public class IaRPManagerClient {

	private static final Logger log = Logger.getLogger(IaRPManagerClient.class);
	private static final int REFRESH_RATE = 1; // in minutes

	private RPManager manager = null;
	private long creationTime = 0;

	private static IaRPManagerClient instance;

	private IaRPManagerClient() {
		// do nothing...
	}

	public static IaRPManagerClient getInstance() throws IaConnectionException {
		try {
			if (instance == null) {
				log.debug("Creating new instance of IaRPManagerClient...");
				synchronized (IaRPManagerClient.class) {
					instance = new IaRPManagerClient();
					initialize();
				}
			} else if (needToRefresh(instance.creationTime)) {
				log.debug("Refreshing IaRPManagerClient...");
				initialize();
			}
		} catch (Exception e) {
			throw new IaConnectionException(
					"Unable to create RPManager instance", e);
		}

		return instance;
	}

	public static IaRPManagerClient getInstance(Map<String, String> config)
			throws IaConnectionException {
		try {
			if (instance == null) {
				log.debug("Creating new instance of IaRPManagerClient using config = "
						+ config + "...");
				synchronized (IaRPManagerClient.class) {
					instance = new IaRPManagerClient();
					initialize(config);
				}
			}
		} catch (Exception e) {
			throw new IaConnectionException(
					"Unable to create RPManager instance", e);
		}

		return instance;
	}

	private static void initialize() throws IaConnectionException {
		IaConfig config = IaConfig.getInstance();
		instance.manager = new RPManager();
		instance.manager.setServerName(config.getServerAddress());
		instance.manager.setServerPort(config.getPortNumber());
		instance.manager.setUserName(config.getUsername());
		instance.manager.setPassword(config.getPassword());
		instance.manager.setCampaignPackageName(config.getPackageName());
		instance.manager.setLoginTimeout(config.getLoginTimeout());
		instance.manager.setServerAvailabilityPollingInterval(config
				.getPollingInterval());
		instance.manager.setTimeout(config.getRequestTimeout());

		boolean success = instance.manager.login();
		instance.creationTime = System.currentTimeMillis();
		
		if (!success) {
			throw new IaConnectionException(
					"RPManager unable to login. \ncaused by: "
							+ instance.manager.getLastError());
		}
	}

	// For unit testing...
	private static void initialize(Map<String, String> config)
			throws IaConnectionException {
		instance.manager = new RPManager();
		instance.manager
				.setServerName(config.get(IaConstants.CONF_SERVER_NAME));
		instance.manager.setServerPort(Integer.parseInt(config
				.get(IaConstants.CONF_PORT_NUMBER)));
		instance.manager.setUserName(config.get(IaConstants.CONF_USERNAME));
		instance.manager.setPassword(config.get(IaConstants.CONF_PASSWORD));
		instance.manager.setCampaignPackageName(config
				.get(IaConstants.CONF_PACKAGE_NAME));
		instance.manager.setLoginTimeout(Float.parseFloat(config
				.get(IaConstants.CONF_LOGIN_TIMEOUT)));
		instance.manager.setServerAvailabilityPollingInterval(Float
				.parseFloat(config.get(IaConstants.CONF_POLLING_INTERVAL)));
		instance.manager.setTimeout(Float.parseFloat(config
				.get(IaConstants.CONF_REQUEST_TIMEOUT)));
		log.debug("IaConfig : " + config);

		boolean success = instance.manager.login();
		if (!success) {
			throw new IaConnectionException(
					"RPManager unable to login. \ncaused by: "
							+ instance.manager.getLastError());
		}
	}

	public RPManager getRpManager() {
		if (instance != null) {
			return instance.manager;
		} else {
			return null;
		}
	}

	public static void kill(RPManager manager) {
		manager.logout();
		manager = null;
	}

	private static boolean needToRefresh(long creationTime) {
		long currentTime = System.currentTimeMillis();
		return TimeUnit.MILLISECONDS.toMinutes(currentTime - creationTime) >= REFRESH_RATE;
	}
}
