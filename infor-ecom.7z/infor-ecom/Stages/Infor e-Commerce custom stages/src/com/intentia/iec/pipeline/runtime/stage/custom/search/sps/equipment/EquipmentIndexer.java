package com.intentia.iec.pipeline.runtime.stage.custom.search.sps.equipment;

import static com.intentia.iec.pipeline.runtime.stage.custom.search.IndexerUtils.addIndexedField;
import static com.intentia.iec.pipeline.runtime.stage.custom.search.IndexerUtils.addTokenizedField;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Indexer;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc;
import com.intentia.iec.pipeline.runtime.stage.custom.search.SearchUtils;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Strings;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc.RowHandler;
import com.intentia.iec.pipeline.runtime.stage.custom.search.rowhandler.CategoryRowHandler;
import com.intentia.iec.pipeline.runtime.stage.custom.search.rowhandler.CustomerItemNamesRowHandler;
import com.intentia.iec.pipeline.runtime.stage.custom.search.rowhandler.CustomerPriceRowHandler;
import com.intentia.iec.pipeline.runtime.stage.custom.search.rowhandler.PriceRowHandler;
import com.intentia.iec.pipeline.runtime.stage.custom.search.rowhandler.TaxCustomerPriceRowHandler;
import com.intentia.iec.pipeline.runtime.stage.custom.search.rowhandler.TaxPriceRowHandler;

/**
 * Class for indexing Equipment information.
 */
public class EquipmentIndexer implements Indexer {

	private static final Logger LOG = Logger.getLogger(EquipmentIndexer.class);
	private Map<String, String> categoryPathById = null;
	private Jdbc jdbc = null;
	private boolean includePrices = false;

	/**
	 * Selects all equipments.
	 */
	private Jdbc.StatementHolder stmtEquipments = null;

	/**
	 * Item details of equipments. 
	 */
	private Jdbc.StatementHolder stmtEquipmentItemDetails = null;

	private Jdbc.StatementHolder stmtMainCategoryNames = null;

	/**
	 * All other item details of equipments.
	 */
	private Jdbc.StatementHolder stmtEquipmentDetails = null;
	private static final int LOG_ROW_MODULUS = 1000;

    /**
     * Copies the parameters.
     * @param categoryPathById
     * @param jdbc
     * @param includePrices
     */
    public EquipmentIndexer(Map<String, String> categoryPathById, final Jdbc jdbc, boolean includePrices) {
        this.categoryPathById = categoryPathById;
        this.jdbc = jdbc;
        this.includePrices = includePrices;
        
        // currently, price search is disabled for equipments
        // remove the following code if it will be enabled again
        this.includePrices = false;
    }

    /**
     * Creates the sql statements that are used for indexing.
     * @param con
     * @throws PipelineRuntimeException
     */
    protected void prepareStatements(final Connection con) throws PipelineRuntimeException {
        
        try {
			this.stmtEquipments = new Jdbc.StatementHolder(con, EquipmentStrings.Database.Indexing.Equipment.Equipments.sql);
			this.stmtEquipmentItemDetails = new Jdbc.StatementHolder(con, EquipmentStrings.Database.Indexing.Equipment.Items.sql);
			this.stmtMainCategoryNames = new Jdbc.StatementHolder(con, Strings.Database.Indexing.Item.MainCategoryNames.sql);
			this.stmtEquipmentDetails = new Jdbc.StatementHolder(con, (String[]) getItemDetailsSql().toArray(new String[0]));
		} catch (SQLException e) {
			throw new PipelineRuntimeException(e);
		}
    }    

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.search.Indexer#index(org.apache.lucene.index.IndexWriter)
	 */
	public void index(IndexWriter writer) throws PipelineRuntimeException {
        Connection con = null;
        try {
            con = jdbc.getConnection();
            prepareStatements(con);
            indexItems(writer);
        } finally {
            PreparedStatement[] stmts = new PreparedStatement[] {stmtEquipments.stmt};
            jdbc.close(stmts);
            jdbc.close(con);
        }		
	}
	
	/**
	 * Indexes all equipment information.
	 * @param writer
	 * @throws PipelineRuntimeException
	 */
	private void indexItems(final IndexWriter writer) throws PipelineRuntimeException {
		LOG.info("Indexing equipments");
		int startCount = writer.docCount();
		
		jdbc.execute(stmtEquipments, new Object[0], new Jdbc.RowHandler() {

			/* (non-Javadoc)
			 * @see com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc.RowHandler#processRow(java.sql.ResultSet)
			 */
			public void processRow(ResultSet rs) throws SQLException,
					PipelineRuntimeException {
				if (rs.getRow() % LOG_ROW_MODULUS == 0) {
					LOG.info("Indexing equipment #" + rs.getRow());
				}
					
				String userGroupId = rs.getString(EquipmentStrings.Database.Indexing.Equipment.Equipments.userGroupId);
				String equipmentId = rs.getString(EquipmentStrings.Database.Indexing.Equipment.Equipments.equipmentId);
				String serialNumber = rs.getString(EquipmentStrings.Database.Indexing.Equipment.Equipments.serialNumber);
				String itemId = rs.getString(EquipmentStrings.Database.Indexing.Equipment.Equipments.itemId);
				String isParent = rs.getString(EquipmentStrings.Database.Indexing.Equipment.Equipments.isParent);
				
				Document doc = new Document();
				addIndexedField(doc, Strings.Index.entryType, Strings.Index.item);
				
				addIndexedField(doc, EquipmentStrings.Index.Equipment.userGroupId, userGroupId);
				addIndexedField(doc, EquipmentStrings.Index.Equipment.equipmentId, equipmentId);
				addIndexedField(doc, EquipmentStrings.Index.Equipment.serialNumber, serialNumber.toLowerCase());
				
				if (isParent != null) {
					addIndexedField(doc, EquipmentStrings.Index.isParent, EquipmentStrings.Index.parent);
				}
				
				addEquipmentItemDetails(doc, itemId, equipmentId);
				
				try {
					writer.addDocument(doc);
				} catch (IOException e) {
					LOG.error("Problem adding item to index", e);
					throw new PipelineRuntimeException(e);
				}
			}			
		});
		
		int stopCount = writer.docCount();
		LOG.info("Finished indexing " + (stopCount - startCount) + " equipments");
	}
	
	/**
	 * Indexes the item details of the equipment. 
	 * @param doc
	 * @param itemId
	 * @param equipmentId
	 * @throws PipelineRuntimeException
	 */
	private void addEquipmentItemDetails(Document doc, String itemId, String equipmentId) throws PipelineRuntimeException {
		 jdbc.execute(this.stmtEquipmentItemDetails, new Object[] {itemId}, new EquipmentDetailsRowHandler(doc, equipmentId));
	}
	
	/**
	 * Indexes the category names and equipment details.
	 * @param doc
	 * @param itemId
	 * @param mainCategoryId
	 * @param itemNumber
	 * @param equipmentId
	 * @throws PipelineRuntimeException
	 */
	private void addOtherEquipmentDetails(Document doc, String itemId, String mainCategoryId, String itemNumber, String equipmentId) throws PipelineRuntimeException {
		addMainCategoryNames(doc, mainCategoryId);
		addEquipmentDetails(doc, itemId, itemNumber, equipmentId);
	}
	
	/**
	 * Indexes all equipment details.
	 * @param doc
	 * @param itemId
	 * @param itemNumber
	 * @param equipmentId
	 * @throws PipelineRuntimeException
	 */
	private void addEquipmentDetails(Document doc, String itemId, String itemNumber, String equipmentId) throws PipelineRuntimeException {
        Object[] params = (Object[]) getParameters(itemId, equipmentId).toArray(new Object[0]);
        Jdbc.RowHandler[] rowHandlers = (Jdbc.RowHandler[]) getRowHandlers(doc, itemNumber, equipmentId).toArray(
                new Jdbc.RowHandler[0]);
        jdbc.execute(stmtEquipmentDetails, params, rowHandlers);
	}
	
    /**
     * Returns a list of sql statements that are used for indexing equipments.
     * @return
     */
    private List<String> getItemDetailsSql() {
        List<String> list = Collections.synchronizedList(new ArrayList<String>());
        list.add(EquipmentStrings.Database.Indexing.Equipment.NamesDescriptionsAndSerialNumber.sql);
        list.add(Strings.Database.Indexing.Item.Categories.sql);
        list.add(Strings.Database.Indexing.Item.CustomerItemID.sql);
        
        list.add(EquipmentStrings.Database.Indexing.Equipment.ParentEquipments.sql);

        if (this.includePrices == true) {
            list.add(Strings.Database.Indexing.Item.Price.sql);
            list.add(Strings.Database.Indexing.Item.TaxPrice.sql);
            list.add(Strings.Database.Indexing.Item.CustomerPrice.sql);
            list.add(Strings.Database.Indexing.Item.TaxCustomerPrice.sql);
        }

        return list;
    }
    
    /**
     * Returns a list of parameters that are used for indexing equipments.
     * @param itemId
     * @param equipmentId
     * @return
     */
    private List<Object> getParameters(String itemId, String equipmentId) {
        List<Object> list = Collections.synchronizedList(new ArrayList<Object>());
        // names, descriptions and serial number
        list.add(equipmentId);

        // category
        list.add(itemId);

        // customer item name
        list.add(itemId);        
        
        // parent equipment
        list.add(equipmentId);

        // price related fields
        if (this.includePrices == true) {
            // price
            list.add(itemId);

            // tax price
            list.add(itemId);

            // customer price
            list.add(itemId);

            // tax customer price
            list.add(itemId);
        }

        return list;
    }
    
    /**
     * Returns a list of RowHandlers that processes the results of SQL queries.
     * @param doc
     * @param itemNumber
     * @param equipmentId
     * @return
     */
    private List<RowHandler> getRowHandlers(Document doc, String itemNumber, String equipmentId) {
        List<Jdbc.RowHandler> list = Collections.synchronizedList(new ArrayList<Jdbc.RowHandler>());

        // names, descriptions and serialNumber
        list.add(new NamesDescriptionsAndSerialNumberRowHandler(doc, itemNumber));

        // category
        list.add(new CategoryRowHandler(doc, this.categoryPathById));       

        // customer item name
        list.add(new CustomerItemNamesRowHandler(doc));
        
        // parent equipment
        list.add(new ParentEquipmentsRowHandler(doc));

        // price related fields
        if (this.includePrices == true) {
            // price
            list.add(new PriceRowHandler(doc));

            // price
            list.add(new TaxPriceRowHandler(doc));

            // customer price
            list.add(new CustomerPriceRowHandler(doc));

            // tax customer price
            list.add(new TaxCustomerPriceRowHandler(doc));
        }

        return list;
    }

    /**
     * Lookup the name in all languages for the main category of the item.
     * @param doc
     * @param mainCategoryId
     * @throws PipelineRuntimeException
     */
    private void addMainCategoryNames(final Document doc, final String mainCategoryId) throws PipelineRuntimeException {
        if (mainCategoryId != null) {
            jdbc.execute(stmtMainCategoryNames, new Object[] {mainCategoryId}, new Jdbc.RowHandler() {
                public void processRow(final ResultSet rs) throws SQLException {
                    String languageCode = rs.getString(Strings.Database.Indexing.Item.MainCategoryNames.languageCode);
                    String name = rs.getString(Strings.Database.Indexing.Item.MainCategoryNames.name);
                    addIndexedField(doc, Strings.Index.Item.mainCategoryNamePrefix + languageCode, name);
                }
            });
        }
    }
	
	/**
	 * Processes the result of equipment details query. The columns are stored in the index. 
	 */
	private class EquipmentDetailsRowHandler implements Jdbc.RowHandler {
		private Document doc = null;
		private String equipmentId = null;
		
		/**
		 * Copies the parameters.
		 * @param doc
		 * @param equipmentId
		 */
		private EquipmentDetailsRowHandler(Document doc, String equipmentId) {
			this.doc = doc;
			this.equipmentId = equipmentId;
		}
		
		/* (non-Javadoc)
		 * @see com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc.RowHandler#processRow(java.sql.ResultSet)
		 */
		public void processRow(ResultSet rs) throws SQLException, PipelineRuntimeException {
			 String itemId = rs.getString(Strings.Database.Indexing.Item.Items.id);
             String itemNumber = rs.getString(Strings.Database.Indexing.Item.Items.itemNumber);
             String manufacturerId = rs.getString(Strings.Database.Indexing.Item.Items.manufacturerId);
             String manufacturerName = rs.getString(Strings.Database.Indexing.Item.Items.manufacturerName);
             String mainCategoryId = rs.getString(Strings.Database.Indexing.Item.Items.mainCategoryId);
             String brandId = rs.getString(Strings.Database.Indexing.Item.Items.brandId);
             String supplierId = rs.getString(Strings.Database.Indexing.Item.Items.supplierId);
             
             addIndexedField(doc, Strings.Index.Item.itemId, itemId);
             addIndexedField(doc, Strings.Index.Item.itemNumber, itemNumber.toLowerCase());
             addIndexedField(doc, Strings.Index.Item.manufacturerId, manufacturerId);
             addIndexedField(doc, Strings.Index.Item.manufacturerName, manufacturerName);
             addIndexedField(doc, Strings.Index.Item.brandId, brandId);
             if (supplierId != null) {
                 addIndexedField(doc, Strings.Index.Item.supplierId, supplierId.toLowerCase());
             }

             // write a default price of 0.0
             if (includePrices == true) {
                 addIndexedField(doc, Strings.Index.Item.price.toLowerCase(), SearchUtils.toPaddedString(0.0));
                 addIndexedField(doc, Strings.Index.Item.taxPrice.toLowerCase(), SearchUtils.toPaddedString(0.0));
             }

             addOtherEquipmentDetails(doc, itemId, mainCategoryId, itemNumber, equipmentId); 
		}
	}
	
	/**
	 * RowHandler for parent equipment query. The parent equipment ID is indexed.
	 *
	 */
	private class ParentEquipmentsRowHandler implements Jdbc.RowHandler {
		private Document doc = null;
		
	    /**
	     * Copies the parameter.
	     * @param doc
	     */
	    private ParentEquipmentsRowHandler(Document doc) {
	    	this.doc = doc;
	    }

		/* (non-Javadoc)
		 * @see com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc.RowHandler#processRow(java.sql.ResultSet)
		 */
		public void processRow(ResultSet rs) throws SQLException,
				PipelineRuntimeException {
			String parentEquipmentId = rs.getString(EquipmentStrings.Database.Indexing.Equipment.ParentEquipments.parentEquipmentId);
			addIndexedField(doc, EquipmentStrings.Index.Equipment.parentEquipmentId, parentEquipmentId);			
		}		
	}
	
	/**
	 * RowHandler for names, descriptions and serial number that are used for quick search.
	 *
	 */
	private class NamesDescriptionsAndSerialNumberRowHandler implements Jdbc.RowHandler {
		private Document doc = null;
				
		private String itemNumber = null;
		
	    /**
	     * Copies the parameters.
	     * @param doc
	     * @param itemNumber
	     */
	    private NamesDescriptionsAndSerialNumberRowHandler(Document doc, String itemNumber) {
	    	this.doc = doc;
	    	this.itemNumber = itemNumber;	    	
	    }

		/* (non-Javadoc)
		 * @see com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc.RowHandler#processRow(java.sql.ResultSet)
		 */
		public void processRow(ResultSet rs) throws SQLException, PipelineRuntimeException {		
			StringBuilder fulltext = new StringBuilder(100);
			fulltext.append(this.itemNumber);
			String languageCode = rs.getString(EquipmentStrings.Database.Indexing.Equipment.NamesDescriptionsAndSerialNumber.languageCode);
			String name = rs.getString(EquipmentStrings.Database.Indexing.Equipment.NamesDescriptionsAndSerialNumber.name);
			String description = rs.getString(EquipmentStrings.Database.Indexing.Equipment.NamesDescriptionsAndSerialNumber.description);
			String serialNumber = rs.getString(EquipmentStrings.Database.Indexing.Equipment.NamesDescriptionsAndSerialNumber.serialNumber);
			
			if (name != null) {
			    addIndexedField(doc, Strings.Index.Item.namePrefix + languageCode, name);
			    addTokenizedField(doc, Strings.Index.Item.nameTokenizedPrefix + languageCode, name);
			    fulltext.append(' ').append(name);
			}
			
			if (description != null) {
			    addTokenizedField(doc, Strings.Index.Item.descriptionPrefix + languageCode, description);
			    fulltext.append(' ').append(description);
			}
			
			// Include serial number in the quick search.
			if (serialNumber != null) {
				fulltext.append(' ').append(serialNumber);
			}			
			
			addTokenizedField(doc, Strings.Index.Item.fullTextPrefix + languageCode, fulltext.toString());
		}		
	}
}
