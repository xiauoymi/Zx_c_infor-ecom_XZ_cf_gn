package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

import org.apache.log4j.Logger;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.utils.Decimal;

/**
 * The purpose of this class is to get the conversion rate and change a value
 * from one currency to another. E.g. convert USD to EUR or vice versa. This
 * class is used by CalculateMerchantCurrencyValues and
 * CalculateShopperCurrencyValues for displaying/saving converted values in the
 * RFQ Details page.
 * 
 * @author Kristina Camille Lutz
 * 
 */
public class CurrencyConverter {

    private static final Logger LOG = Logger.getLogger(CurrencyConverter.class);

    private static final String EXCHANGERATE_SQL = "select [main].[exchangeRate] from [Currency] as [main] where [main].[currencyCode] = ?";

    private static final String DECIMALS_SQL = "select [main].[decimals] from [Currency] as [main] where [main].[currencyCode] = ?";

    private int srcCurrencyScale = getDefaultScale();
    
    private int destCurrencyScale = getDefaultScale();

    private int rounding = BigDecimal.ROUND_HALF_UP;

    private BigDecimal conversionRate;

    /**
     * Constructor
     * 
     * @param srcCurrency -
     *            source currency. E.g. When converting values from USD to EUR,
     *            srcCurrency is USD
     * @param destCurrency -
     *            target currency. E.g. When converting values from USD to EUR,
     *            destCurrency is EUR
     * @param destCurrencyExchangeRate -
     *            exchange rate of target currency as computed against the
     *            master currency
     * @throws PipelineRuntimeException
     */
    public CurrencyConverter(String srcCurrency, String destCurrency, BigDecimal destCurrencyExchangeRate)
            throws PipelineRuntimeException {
        LOG.debug("Entering CurrencyConverter constructor");
        BigDecimal srcCurrencyExchangeRate = getExchangeRate(srcCurrency);
        setConversionRate(calculateConversionRate(srcCurrencyExchangeRate, destCurrencyExchangeRate));
        setSrcCurrencyScale(calculateCurrencyScale(srcCurrency));
        setDestCurrencyScale(calculateCurrencyScale(destCurrency));
        LOG.debug("Exiting CurrencyConverter constructor");
    }

    /**
     * Constructor
     * 
     * @param srcCurrency -
     *            source currency. E.g. When converting values from USD to EUR,
     *            srcCurrency is USD
     * @param srcCurrencyExchangeRate -
     *            exchange rate of source currency as computed against the
     *            master currency
     * @param destCurrency -
     *            target currency. E.g. When converting values from USD to EUR,
     *            destCurrency is EUR
     * @throws PipelineRuntimeException
     */
    public CurrencyConverter(String srcCurrency, BigDecimal srcCurrencyExchangeRate, String destCurrency)
            throws PipelineRuntimeException {
        LOG.debug("Entering CurrencyConverter constructor");
        BigDecimal destCurrencyExchangeRate = getExchangeRate(destCurrency);
        setConversionRate(calculateConversionRate(srcCurrencyExchangeRate, destCurrencyExchangeRate));
        setSrcCurrencyScale(calculateCurrencyScale(srcCurrency));
        setDestCurrencyScale(calculateCurrencyScale(destCurrency));
        LOG.debug("Exiting CurrencyConverter constructor");
    }

    /**
     * Set the scale to be used for converting a monetary value
     * @param scale to be used for converting a monetary value
     */
    public void setSrcCurrencyScale(int scale) {
        this.srcCurrencyScale = scale;
    }

    /**
     * Returns the scale used for converting a monetary value
     * @return scale used for converting a monetary value
     */
    public int getSrcCurrencyScale() {
        return srcCurrencyScale;
    }
    
    /**
     * Set the scale to be used for converting a monetary value
     * @param scale to be used for converting a monetary value
     */
    public void setDestCurrencyScale(int scale) {
        this.destCurrencyScale = scale;
    }

    /**
     * Returns the scale used for converting a monetary value
     * @return scale used for converting a monetary value
     */
    public int getDestCurrencyScale() {
        return destCurrencyScale;
    }

    /**
     * Set the rounding mode to be used for converting a monetary value
     * @param rounding
     */
    public void setRounding(int rounding) {
        this.rounding = rounding;
    }

    /**
     * Returns the rounding mode used for converting a monetary value
     * @return
     */
    public int getRounding() {
        return rounding;
    }
    
    /**
     * Set the converstion rate to be used for transforming one currency to another
     * @param conversionRate
     */
    public void setConversionRate(BigDecimal conversionRate) {
        this.conversionRate = conversionRate;
    }

    /**
     * Returns the converstion rate used for transforming one currency to another
     * @return
     */
    public BigDecimal getConversionRate() {
        return conversionRate;
    }
    
    /**
     * Converts the value from one currency to another
     * @param price - value to be converted to another currency
     * @return String value of (price * conversion rate)
     */
    public String getConvertedValue(BigDecimal price) {        
        return String.valueOf(getConversionRate().multiply(price.setScale(getSrcCurrencyScale(), getRounding())).setScale(getDestCurrencyScale(), getRounding()));
    }

    /**
     * Returns default scale used by e-Sales based on application property Numbers.Decimal
     * @return default scale based on application property Numbers.Decimal
     */
    public static int getDefaultScale() {
        return Decimal.ZERO.scale();
    }

    /**
     * Retrieve the scale of a currency from Currency table particularly in the
     * decimals column
     * 
     * @param currency -
     *            Currency value e.g. EUR
     * @return scale from Currency.decimals column
     */
    private static int calculateCurrencyScale(String currency) {
        LOG.debug("Entering calculateCurrencyScale method");
        int decimals = getDefaultScale();

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            con = (Connection) CustomStagesHelper.getConnection(ConstantsForSales.DATABASE_CONNECTION_KEY);
            stmt = con.prepareStatement(DECIMALS_SQL);
            stmt.setObject(1, currency, Types.VARCHAR);
            rs = stmt.executeQuery();

            if (rs.next()) {
                try {
                    // set scale based on the decimals value of the currency
                    decimals = (rs.getInt("decimals"));
                } catch (Exception ex) {
                    LOG.error("Error in getting scale", ex);
                }
            }
        } catch (Exception e) {
            LOG.error("Error in getting scale : ", e);
        } finally {
            //always close the connection
            CustomStagesHelper.close(con, stmt, rs);
        }

        LOG.debug("Exiting calculateCurrencyScale method");
        return decimals;
    }

    /**
     * Retrieves the exchange rate from the database based on the Currency table
     * 
     * @param currency -
     *            Currency value e.g. EUR
     * @return exchange rate from Currency.exchangeRate column
     */
    private static BigDecimal getExchangeRate(String currency) {
        LOG.debug("Entering getExchangeRate method");
        BigDecimal exchangeRate = new BigDecimal(0);
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            con = (Connection) CustomStagesHelper.getConnection(ConstantsForSales.DATABASE_CONNECTION_KEY);
            stmt = con.prepareStatement(EXCHANGERATE_SQL);
            stmt.setObject(1, currency, Types.VARCHAR);
            rs = stmt.executeQuery();

            if (rs.next()) {
                try {
                    exchangeRate = new BigDecimal(rs.getString("exchangeRate"));
                } catch (Exception ex) {
                    LOG.error("Error in getting exchange rate", ex);
                }
            }
        } catch (Exception e) {
            LOG.error("Error in getting exchange rate : ", e);
        } finally {
            //always close the connection
            CustomStagesHelper.close(con, stmt, rs);
        }

        LOG.debug("Exiting getExchangeRate method");
        return exchangeRate;
    }

    /**
     * Compute the conversion rate based on the exchange rates from input
     * parameters. Logic similar to the conversionRate function of
     * CalculateAltCurrency class
     * 
     * @param srcCurrencyExchangeRate -
     *            the exchange rate from the original currency to the master
     *            currency
     * @param destCurrencyExchangeRate -
     *            the exchange rate from the target currency to master currency
     * @return conversion rate to transform values from srcCurrency to destCurrency
     * @throws PipelineRuntimeException
     *             if either of the parameters are negative or if the divisor is
     *             zero
     */
    private BigDecimal calculateConversionRate(BigDecimal srcCurrencyExchangeRate, BigDecimal destCurrencyExchangeRate)
            throws PipelineRuntimeException {
        LOG.debug("Entering calculateConversionRate method");

        // avoid negative, infinite, and NaN conversion rate values
        if (srcCurrencyExchangeRate.compareTo(Decimal.ZERO) < 1) {
            throw new PipelineRuntimeException(
                    "The supplied exchange rate for the source currency was negative or zero, it must be a positive number");
        }
        if (destCurrencyExchangeRate.compareTo(Decimal.ZERO) < 0) {
            throw new PipelineRuntimeException(
                    "The supplied exchange rate for the target currency was negative, it must be positive");
        }

        // Logic similar to conversionRate method of CalculateAltCurrency class
        // Trying to set scale depending on the size of the result.
        int scale = 20;
        if (destCurrencyExchangeRate.compareTo(srcCurrencyExchangeRate.multiply(new BigDecimal("1000000000"))) == 1) {
            // if x/y < 10E-10 ==>> y > x*10E10
            // then dealing with small numbers. Set scale to 30
            scale = 30;
        } else if (srcCurrencyExchangeRate.compareTo(destCurrencyExchangeRate.multiply(new BigDecimal("1000000000"))) == 1) {
            // if x/y > 10E10 ==>> x > y*10E10
            // then dealing with huge a number. Set scale to 0
            scale = 0;
        }

        LOG.debug("Exiting calculateConversionRate method");
        return destCurrencyExchangeRate.divide(srcCurrencyExchangeRate, scale, BigDecimal.ROUND_HALF_UP);
    }

}
