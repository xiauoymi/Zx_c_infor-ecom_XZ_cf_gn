package com.intentia.iec.pipeline.runtime.stage.custom;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.connection.ConnectorException;
import com.intentia.iec.connection.IMovexApiResultset;
import com.intentia.iec.connection.IMovexConnection;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.utils.CommitPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

public class ChangeOrderDetailsInM3 extends AbstractPipelineStage {

    private static final Logger LOG = Logger.getLogger(ChangeOrderDetailsInM3.class);

    private static final String ACTION_ADD = "add";

    private static final String ACTION_UPDATE = "update";

    private static final String ACTION_DELETE = "delete";

    private static final String SOURCE_CHANGE_ORDER_PAGE = "ChangeOrderPage";

    private static final String SOURCE_ORDER_LINE_DETAILS_PAGE = "OrderLineDetailsPage";

    private static final String SOURCE_SHOPPING_CART = "ShoppingCart";

    private static final String ERROR_UPDATE_FAILED = "UpdateFailed";

    private static final String ERROR_DELETE_FAILED = "DeleteFailed";

    private static final String ERROR_ADD_FAILED = "AddFailed";

    private static final String INITIAL_ORDERLINE_STATUS = "22";

    private static final String DELETED_ORDERLINE_STATUS = "90";

    private static final int ERROR_MVXSTATUS = -1001;

    private StringBuffer _errorMessage = new StringBuffer("Missing Required Parameters: ");

    private int _missingRequiredRequestParams = 0;

    private String _actionType = null;

    private String _updateSource = null;

    private String _previousOrderID = null;

    private String _currentOrderID = null;

    private String _languageCode = null;

    private String _mvxWarehouse = null;

    private PipelineContext _context = null;

    private IMovexConnection _mvxConnection = null;

    private XMLRequestHelper _xmlHelper = null;

    private Map<String, String> _updateDeleteFieldMapping = null;

    private Map<String, String> _addFieldMapping = null;

    private Map<String, String> _previousCurrentAttribMapping = null;

    private Map<String, String> _lineStatus = null;

    private int _mvxStatus = 0;

    @Override
    public void execute(PipelineContext context) throws PipelineRuntimeException {
        try {
            _context = context;
            XMLRequest request = (XMLRequest) context.getRequest();

            // Verify type of request
            if (!(request instanceof XMLRequest)) {
                throw new PipelineRuntimeException("Request MUST be of type XMLRequest!");
            }

            // Populate API Parameter - BO Attribute mapping
            initMappings();

            // Get Request parameters
            getRequestParameters(request);

            Document xmlDoc = request.getRequestDoc();
            _xmlHelper = new XMLRequestHelper(xmlDoc);
            _xmlHelper.logRequest();

            _lineStatus = new HashMap<String, String>();

            if (_mvxConnection == null)
                openMvxConnection();

            if (_mvxStatus >= 0) {
                LOG.debug("Start updating Order #: " + _previousOrderID + " ...");
                if (_actionType.equalsIgnoreCase(ACTION_UPDATE))
                    updateOrderLines(xmlDoc);
                else if (_actionType.equalsIgnoreCase(ACTION_ADD))
                    addOrderLines();
                else
                    throw new PipelineRuntimeException("Unknown change Order action type '" + _actionType + "'");
            }

            // Set Response XML
            updateXMLReponse();
        } catch (RequestException e) {
            throw new PipelineRuntimeException("Unable to extract request document", e);
        } finally {
            closeMvxConnection();
        }
    }

    private void initMappings() {
        _updateDeleteFieldMapping = new HashMap<String, String>();
        _updateDeleteFieldMapping.put(ConstantsForSales.ORDERID, ConstantsForSales.ORNO);
        _updateDeleteFieldMapping.put(ConstantsForSales.LINENUMBER, ConstantsForSales.PONR);
        _updateDeleteFieldMapping.put(ConstantsForSales.QUANTITY, ConstantsForSales.ORQA);
        _updateDeleteFieldMapping.put(ConstantsForSales.REQUESTEDDELIVERYDATE, ConstantsForSales.DWDZ);
        _updateDeleteFieldMapping.put(ConstantsForSales.MVXSHIPPINGADDRESSID, ConstantsForSales.ADID);

        _addFieldMapping = new HashMap<String, String>();
        _addFieldMapping.put(ConstantsForSales.ORDERID, ConstantsForSales.ORNO);
        _addFieldMapping.put(ConstantsForSales.ITEMID, ConstantsForSales.ITNO);
        _addFieldMapping.put(ConstantsForSales.QUANTITY, ConstantsForSales.ORQT);
        _addFieldMapping.put(ConstantsForSales.REQUESTEDDELIVERYDATE, ConstantsForSales.DWDZ);
        _addFieldMapping.put(ConstantsForSales.MVXSHIPPINGADDRESSID, ConstantsForSales.ADID);
        _addFieldMapping.put(ConstantsForSales.MVXCONFIGURABLENUMBER, ConstantsForSales.CFIN);
        _addFieldMapping.put(ConstantsForSales.ORDERLINEID, ConstantsForSales.DRDL);

    }

    private void getRequestParameters(XMLRequest request) throws PipelineRuntimeException {

        try {
            XMLRequest.extractRequestParameters(request);
            Parameters parameters = request.getParameters();
            _actionType = parameters.getString(ConstantsForSales.ACTION_TYPE_PARAM);
            _updateSource = parameters.getString(ConstantsForSales.UPDATE_SOURCE_PARAM);
            _previousOrderID = parameters.getString(ConstantsForSales.PREVIOUS_ORDERID_PARAM);

            validateRequiredRequestParameters(_actionType, ConstantsForSales.ACTION_TYPE_PARAM);
            validateRequiredRequestParameters(_updateSource, ConstantsForSales.UPDATE_SOURCE_PARAM);
            validateRequiredRequestParameters(_previousOrderID, ConstantsForSales.PREVIOUS_ORDERID_PARAM);

            if (ACTION_ADD.equalsIgnoreCase(_actionType) && SOURCE_SHOPPING_CART.equalsIgnoreCase(_updateSource)) {
                _currentOrderID = parameters.getString(ConstantsForSales.CURRENT_ORDERID_PARAM);
                _languageCode = parameters.getString(ConstantsForSales.LANGUAGE_CODE_SQL_PARAM);
                _mvxWarehouse = parameters.getString(ConstantsForSales.MVXWAREHOUSE_PARAM);

                validateRequiredRequestParameters(_currentOrderID, ConstantsForSales.CURRENT_ORDERID_PARAM);
                validateRequiredRequestParameters(_languageCode, ConstantsForSales.LANGUAGE_CODE_SQL_PARAM);
                validateRequiredRequestParameters(_mvxWarehouse, ConstantsForSales.MVXWAREHOUSE_PARAM);
            }

            if (_missingRequiredRequestParams > 0) {
                final String msg = _errorMessage.toString();
                LOG.error(msg);
                throw new PipelineRuntimeException(msg);
            }

        } catch (RequestException e) {
            throw new PipelineRuntimeException("Unable to extract request parameters", e);
        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Unable to parse request parameters", e);
        }
    }

    private void validateRequiredRequestParameters(String paramVariable, String param) {
        if (paramVariable == null) {
            _errorMessage.append(" [").append(param).append("] ");
            _missingRequiredRequestParams++;
        }
    }

    private NodeList getOrderLines(Document xmlDoc) throws PipelineRuntimeException {
        try {
            return XPathAPI.selectNodeList(xmlDoc, "request/entities/entity/subsets/subset[@name=\"OrderLine\"]");
        } catch (TransformerException e) {
            throw new PipelineRuntimeException("Unable to parse request XML", e);
        }
    }

    private String getOrderLineID(Node line) throws PipelineRuntimeException {
        String key = null;
        try {
            Node keyNode = XPathAPI.selectSingleNode(line, "keys/key/@value");
            if (keyNode != null)
                key = keyNode.getNodeValue();
            if (key == null) {
                LOG.error("Missing OrderLineID");
                throw new PipelineRuntimeException("Missing OrderLineID");
            }
        } catch (TransformerException e) {
            LOG.error(e);
            throw new PipelineRuntimeException("Unable to parse request XML", e);
        }
        return key;
    }

    private void updateOrderLines(Document xmlDoc) throws PipelineRuntimeException {
        try {
            NodeList orderLines = getOrderLines(xmlDoc);
            String transName = null;
            Map<String, Map> updatedLines = new HashMap<String, Map>();

            for (int i = 0; i < orderLines.getLength(); i++) {
                Map<String, String> apiParams = new HashMap<String, String>();
                Map<String, String> updatedAttribs = new HashMap<String, String>();
                Node line = orderLines.item(i);

                String orderLineID = getOrderLineID(line);
                String action = _xmlHelper.getAttribute(line, ConstantsForSales.CHANGE_ORDER_ACTION);
                String lineNumber = _xmlHelper.getAttribute(line, ConstantsForSales.LINENUMBER);

                apiParams.put(_updateDeleteFieldMapping.get(ConstantsForSales.ORDERID), _previousOrderID);
                apiParams.put(_updateDeleteFieldMapping.get(ConstantsForSales.LINENUMBER), lineNumber);

                if (ACTION_UPDATE.equalsIgnoreCase(action)) {
                    LOG.debug("   Updating Line #: " + lineNumber);
                    transName = "ChgLineBatchEnt";

                    if (_updateSource.equalsIgnoreCase(SOURCE_CHANGE_ORDER_PAGE)) {
                        String quantity = _xmlHelper.getAttribute(line, ConstantsForSales.QUANTITY);
                        if (quantity != null) {
                            apiParams.put(_updateDeleteFieldMapping.get(ConstantsForSales.QUANTITY), quantity);
                            if (callMvxAPI(transName, apiParams) != null) {
                                updatedAttribs.put(ConstantsForSales.QUANTITY, _xmlHelper.getAttribute(line,
                                        ConstantsForSales.QUANTITY));
                            } else {
                                _lineStatus.put(lineNumber, ERROR_UPDATE_FAILED);
                            }
                        }
                    } else if (_updateSource.equalsIgnoreCase(SOURCE_ORDER_LINE_DETAILS_PAGE)) {
                        String requestedDeliveryDate = _xmlHelper.getAttribute(line,
                                ConstantsForSales.REQUESTEDDELIVERYDATE);
                        String mvxShippingAddress = _xmlHelper.getAttribute(line,
                                ConstantsForSales.MVXSHIPPINGADDRESSID);
                        apiParams.put(_updateDeleteFieldMapping.get(ConstantsForSales.REQUESTEDDELIVERYDATE),
                                SubmitOrderToMovex.getMovexDate(requestedDeliveryDate));
                        apiParams.put(_updateDeleteFieldMapping.get(ConstantsForSales.MVXSHIPPINGADDRESSID),
                                mvxShippingAddress);
                        if (callMvxAPI(transName, apiParams) != null) {
                            updatedAttribs.put(ConstantsForSales.REQUESTEDDELIVERYDATE, requestedDeliveryDate);
                            updatedAttribs.put(ConstantsForSales.YOURREFERENCE, _xmlHelper.getAttribute(line,
                                    ConstantsForSales.YOURREFERENCE));
                            if (mvxShippingAddress != null)
                                updateShippingAddressAttributes(updatedAttribs, line);
                        } else {
                            _lineStatus.put(lineNumber, ERROR_UPDATE_FAILED);
                        }
                    } else {
                        throw new PipelineRuntimeException("Unknown update source '" + action + "'");
                    }
                } else if (ACTION_DELETE.equalsIgnoreCase(action)) {
                    LOG.debug("   Deleting Line #: " + lineNumber);
                    transName = "DelLineBatchEnt";
                    if (callMvxAPI(transName, apiParams) != null) {
                        updatedAttribs.put(ConstantsForSales.ORDERLINESTATUSID, DELETED_ORDERLINE_STATUS);
                    } else {
                        _lineStatus.put(lineNumber, ERROR_DELETE_FAILED);
                    }
                } else {
                    throw new PipelineRuntimeException("Unknown change OrderLine action type '" + action + "'");
                }
                updatedLines.put(orderLineID, updatedAttribs);
            }
            // Update previous order details in the database
            updatePreviousOrder(updatedLines);
        } catch (TransformerException e) {
            throw new PipelineRuntimeException("Unable to parse request XML", e);
        }
    }

    private void updateShippingAddressAttributes(Map<String, String> updatedAttribs, Node line)
            throws PipelineRuntimeException {
        try {
            updatedAttribs.put(ConstantsForSales.SHIPPINGADDRESS1, _xmlHelper.getAttribute(line,
                    ConstantsForSales.SHIPPINGADDRESS1));
            updatedAttribs.put(ConstantsForSales.SHIPPINGADDRESS2, _xmlHelper.getAttribute(line,
                    ConstantsForSales.SHIPPINGADDRESS2));
            updatedAttribs.put(ConstantsForSales.SHIPPINGADDRESS3, _xmlHelper.getAttribute(line,
                    ConstantsForSales.SHIPPINGADDRESS3));
            updatedAttribs.put(ConstantsForSales.SHIPPINGADDRESS4, _xmlHelper.getAttribute(line,
                    ConstantsForSales.SHIPPINGADDRESS4));
            updatedAttribs.put(ConstantsForSales.SHIPPINGCITY, _xmlHelper.getAttribute(line,
                    ConstantsForSales.SHIPPINGCITY));
            updatedAttribs.put(ConstantsForSales.SHIPPINGCOMPANY, _xmlHelper.getAttribute(line,
                    ConstantsForSales.SHIPPINGCOMPANY));
            updatedAttribs.put(ConstantsForSales.SHIPPINGCOUNTRY, _xmlHelper.getAttribute(line,
                    ConstantsForSales.SHIPPINGCOUNTRY));
            updatedAttribs.put(ConstantsForSales.SHIPPINGCOUNTRYID, _xmlHelper.getAttribute(line,
                    ConstantsForSales.SHIPPINGCOUNTRYID));
            updatedAttribs.put(ConstantsForSales.SHIPPINGNAME, _xmlHelper.getAttribute(line,
                    ConstantsForSales.SHIPPINGNAME));
            updatedAttribs.put(ConstantsForSales.SHIPPINGREGION, _xmlHelper.getAttribute(line,
                    ConstantsForSales.SHIPPINGREGION));
            updatedAttribs.put(ConstantsForSales.SHIPPINGSTATEID, _xmlHelper.getAttribute(line,
                    ConstantsForSales.SHIPPINGSTATEID));
            updatedAttribs.put(ConstantsForSales.SHIPPINGZIP, _xmlHelper.getAttribute(line,
                    ConstantsForSales.SHIPPINGZIP));
        } catch (TransformerException e) {
            throw new PipelineRuntimeException("Unable to update Shipping Address attributes", e);
        }
    }

    private void addOrderLines() throws PipelineRuntimeException {
        if (SOURCE_SHOPPING_CART.equalsIgnoreCase(_updateSource)) {
            try {
                XMLResultset currentOrder = getCurrentOrder();
                if (currentOrder != null && !currentOrder.isEmpty()) {
                    currentOrder.moveFirst();
                    XMLIterator currentOrderLines = (XMLIterator) currentOrder
                            .getResultset(ConstantsForSales.ORDERLINE);
                    if (currentOrderLines != null && !currentOrderLines.isEmpty()) {
                        currentOrderLines.beforeFirst();
                        while (currentOrderLines.moveNext()) {
                            String itemNumber = currentOrderLines.getString(ConstantsForSales.ITEMID);
                            String itemName = currentOrderLines.getString(ConstantsForSales.ITEMNAME);

                            Map<String, String> apiParams = new HashMap<String, String>();
                            apiParams.put(_addFieldMapping.get(ConstantsForSales.ORDERID), _previousOrderID);
                            apiParams.put(_addFieldMapping.get(ConstantsForSales.ITEMID), itemNumber);
                            apiParams.put(_addFieldMapping.get(ConstantsForSales.QUANTITY), currentOrderLines
                                    .getString(ConstantsForSales.QUANTITY));
                            apiParams.put(_addFieldMapping.get(ConstantsForSales.REQUESTEDDELIVERYDATE),
                                    SubmitOrderToMovex.getMovexDate(currentOrderLines
                                            .getString(ConstantsForSales.REQUESTEDDELIVERYDATE)));
                            apiParams.put(_addFieldMapping.get(ConstantsForSales.MVXSHIPPINGADDRESSID),
                                    currentOrderLines.getString(ConstantsForSales.MVXSHIPPINGADDRESSID));
                            apiParams.put(_addFieldMapping.get(ConstantsForSales.MVXCONFIGURABLENUMBER),
                                    currentOrderLines.getString(ConstantsForSales.MVXCONFIGURABLENUMBER));
                            apiParams.put(_addFieldMapping.get(ConstantsForSales.ORDERLINEID), currentOrderLines
                                    .getString(ConstantsForSales.ORDERLINEID));
                            apiParams.put(ConstantsForSales.DRDN, _currentOrderID);
                            apiParams.put(ConstantsForSales.WHLO, _mvxWarehouse);

                            LOG.debug("   Adding Item #: " + itemNumber);
                            IMovexApiResultset result = callMvxAPI("AddLineBatchEnt", apiParams);
                            if (result != null) {

                                /*
                                 * Succeeding lines will be commented out for
                                 * now due to a known defect of the API
                                 * 'OIS100MI:AddLineBatchEnt' where in if you
                                 * add a kit item it will always return a value
                                 * of '00001' for the PONR (line number) output
                                 * parameter.
                                 * 
                                 * Hence, a workaround fix were introduced at
                                 * MergeMovexOrderDetails.mergeCurrentOrdersDetails()
                                 * in which some order line details will be
                                 * merged from the CurrentOrderLine table
                                 * instead. But this is applicable if and only
                                 * if the merging was triggered by "Change
                                 * Order: Add Shopping Cart" functionality.
                                 */

                                // Map<String, String> lineAttribs = new
                                // HashMap<String, String>();
                                // String lineNumber =
                                // String.valueOf(Integer.parseInt(result
                                // .getParamAsString(ConstantsForSales.PONR)));
                                // String suffixNumber =
                                // String.valueOf(Integer.parseInt(result
                                // .getParamAsString(ConstantsForSales.POSX)));
                                //
                                // String orderLineID = _previousOrderID + "_" +
                                // lineNumber + "_" + suffixNumber;
                                // lineAttribs.put(ConstantsForSales.ORDERLINEID,
                                // orderLineID);
                                // lineAttribs.put(ConstantsForSales.LINENUMBER,
                                // lineNumber);
                                // lineAttribs.put(ConstantsForSales.LINESUFFIX,
                                // suffixNumber);
                                //
                                // List currentOrderAttribNames =
                                // currentOrderLines.getNames();
                                // Iterator it =
                                // currentOrderAttribNames.iterator();
                                // while (it.hasNext()) {
                                // String name = (String) it.next();
                                // if
                                // (ConstantsForSales.ORDERLINEID.equals(name)
                                // || ConstantsForSales.COMMENT.equals(name))
                                // ; // Ignore this attribute
                                // else if
                                // (ConstantsForSales.SHIPPINGCOUNTRY.equals(name))
                                // lineAttribs.put(ConstantsForSales.SHIPPINGCOUNTRYNAME,
                                // currentOrderLines
                                // .getString(name));
                                // else
                                // lineAttribs.put(name,
                                // currentOrderLines.getString(name));
                                // }
                                // lineAttribs.put(ConstantsForSales.ORDERLINESTATUSID,
                                // INITIAL_ORDERLINE_STATUS);
                                // updateSubmittedOrderLine(lineAttribs);
                            } else {
                                _lineStatus.put(itemNumber + " - " + itemName, ERROR_ADD_FAILED);
                            }
                        }
                    }

                }
            } catch (ResultsetException e) {
                throw new PipelineRuntimeException("Unable to add items from the shopping cart.", e);
            }
        }
    }

    private XMLResultset getCurrentOrder() throws PipelineRuntimeException {
        SearchPipelineExecuter pipeline = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                "CurrentOrder", "LineDetails");
        pipeline.setParam("@LanguageCode", _languageCode);
        pipeline.setParam("orderID", _currentOrderID);
        pipeline.setParam("orderStatusID", "tmp");
        pipeline.setParam("restrict", "true");
        return pipeline.execute();
    }

    private IMovexApiResultset callMvxAPI(final String transName, Map<String, String> params) {
        IMovexApiResultset result = null;
        try {
            PipelineContext tempContext = new PipelineContext();
            params.put(IMovexConnection.TRANSACTION, transName);
            result = CustomStagesHelper.callMovex(tempContext, _mvxConnection, params, ConstantsForSales.MVXSTATUS);

            if (result != null) {
                int mvxStatus = CustomStagesHelper.getResponseParameters(tempContext).getint(
                        ConstantsForSales.MVXSTATUS);
                if (mvxStatus < 0) {
                    _mvxStatus = mvxStatus;
                    LOG.error("Error while calling M3 API OIS100MI : " + transName);
                    return null;
                } else {
                    if (result.getParamAsString(ConstantsForSales.STAT) == null) {
                        LOG.debug("   API Status : [FAILED] : " + _mvxConnection.getLastMessage());
                        return null;
                    } else
                        LOG.debug("   API Status : [OK]");
                }
            } else {
                _mvxStatus = ERROR_MVXSTATUS;
                LOG.error("Resultset returned by 'OIS100MI : " + transName + "' is null.");
                return null;
            }
        } catch (ParametersException e) {
            _mvxStatus = ERROR_MVXSTATUS;
            LOG.error("Unable to parse response paremeters", e);
            return null;
        } catch (PipelineRuntimeException e) {
            _mvxStatus = ERROR_MVXSTATUS;
            LOG.error("Error while calling M3 API OIS100MI : " + transName, e);
            return null;
        }
        return result;
    }

    private void openMvxConnection() {
        try {
            _mvxConnection = (IMovexConnection) CustomStagesHelper.getConnection(ConstantsForSales.OIS100MI);
            if (_mvxConnection == null) {
                _mvxStatus = ERROR_MVXSTATUS;
                LOG.error("Unable to connect to Movex.");
            }
        } catch (PipelineRuntimeException e) {
            _mvxStatus = ERROR_MVXSTATUS;
            LOG.error("Unable to connect to Movex.", e);
        }
    }

    private void closeMvxConnection() throws PipelineRuntimeException {
        if (_mvxConnection != null) {
            try {
                _mvxConnection.close();
                _mvxConnection = null;
            } catch (ConnectorException e) {
                throw new PipelineRuntimeException("Unable to close M3 connection", e);
            }
        }
    }

    private void updatePreviousOrder(Map<String, Map> updatedLines) throws PipelineRuntimeException {
        CommitPipelineExecuter pipeline = new CommitPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                "PreviousOrder", "UpdateOrderLine");
        pipeline.addEntity();
        pipeline.setEntityKey(ConstantsForSales.ORDERID, _previousOrderID);

        Iterator<String> itLines = updatedLines.keySet().iterator();
        while (itLines.hasNext()) {
            String orderLineID = itLines.next();
            pipeline.addSubset(ConstantsForSales.ORDERLINE);
            pipeline.setSubsetKey(ConstantsForSales.ORDERLINEID, orderLineID);
            Map attributes = updatedLines.get(orderLineID);
            Iterator itAttrib = attributes.keySet().iterator();
            while (itAttrib.hasNext()) {
                String name = (String) itAttrib.next();
                String value = (String) attributes.get(name);
                if (value != null)
                    pipeline.setSubsetAttribute(name, value);
            }
        }
        pipeline.execute();
    }

    private void updateXMLReponse() throws PipelineRuntimeException {
        XMLResultset response = new XMLResultset();
        try {
            response.moveNext();
            // create Order Header
            response.appendRow();
            response.appendField(ConstantsForSales.ORDERID, _previousOrderID);
            // create Order Lines
            Iterator it = _lineStatus.keySet().iterator();
            while (it.hasNext()) {
                Object key = it.next();
                Object value = _lineStatus.get(key);

                XMLIterator orderLine = (XMLIterator) response.appendResultset(ConstantsForSales.ORDERLINE);
                orderLine.appendRow();
                orderLine.appendField(ConstantsForSales.LINENUMBER, (String) key);
                orderLine.appendField(ConstantsForSales.CHANGE_ORDER_STATUS, (String) value);
            }
            _context.setResponse(response);

            // Set context output parameter
            CustomStagesHelper.setResponseParameter(_context, ConstantsForSales.MVXSTATUS, String.valueOf(_mvxStatus));

            LOG.debug("Generated XML: " + ((XMLResultset) _context.getResponse()).toString());
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Unable to set XML response", e);
        }
    }

}
