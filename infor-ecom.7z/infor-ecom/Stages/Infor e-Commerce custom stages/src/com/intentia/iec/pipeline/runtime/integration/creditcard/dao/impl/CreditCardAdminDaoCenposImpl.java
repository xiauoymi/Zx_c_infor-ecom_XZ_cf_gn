package com.intentia.iec.pipeline.runtime.integration.creditcard.dao.impl;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Service;
import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.PortInfo;

import org.apache.log4j.Logger;

import cenpos.admin.common.v5.DeleteRecurringSaleInformationRequest;
import cenpos.admin.common.v5.DeleteRecurringSaleInformationResponse;
import cenpos.admin.org.tempuri.Administration;
import cenpos.admin.org.tempuri.AdministrationWebService;

import com.intentia.iec.pipeline.runtime.integration.creditcard.dao.CreditCardAdminDao;
import com.intentia.iec.pipeline.runtime.integration.creditcard.dao.factory.WebserviceDaoFactory;
import com.intentia.iec.pipeline.runtime.integration.creditcard.exception.CreditCardConnectionException;
import com.intentia.iec.pipeline.runtime.integration.creditcard.model.CreditCard;
import com.intentia.iec.pipeline.runtime.integration.creditcard.model.TransactionResult;
import com.intentia.iec.pipeline.runtime.integration.creditcard.utils.CreditCardHelper;
import com.intentia.iec.pipeline.runtime.integration.creditcard.utils.SOAPLoggingHandler;

public class CreditCardAdminDaoCenposImpl implements CreditCardAdminDao {

	private static final Logger LOG = Logger.getLogger(CreditCardDaoCenposImpl.class);

	@Override
	public TransactionResult deleteCreditCard(CreditCard creditCard) throws CreditCardConnectionException {
		Administration adminPort;
		try {
			adminPort = getAdminPort();
		} catch (MalformedURLException e) {
			throw new CreditCardConnectionException(e.toString());
		}
		
		//declare our model response objects
		TransactionResult outTransaction = new TransactionResult();

		LOG.debug("Endpoint URL.... " + WebserviceDaoFactory.WSDL_ENDPOINT_CREDITCARD_ADMIN);
		//map the Cenpos request object for this call to our model request object for this call
		DeleteRecurringSaleInformationRequest wsRequest =  createDeleteCreditCardRequestParams(creditCard);	
		LOG.debug("wsRequest created....");

		//Set BindingProvider
		try {
			CreditCardHelper.setBindingProvider((BindingProvider)adminPort, new URL(WebserviceDaoFactory.WSDL_ENDPOINT_CREDITCARD_ADMIN));
		} catch(MalformedURLException e){
			throw new CreditCardConnectionException(e.toString()); 
		}
		
		//get the Cenpos response object
		LOG.debug("Calling web service...");
		DeleteRecurringSaleInformationResponse wsResponse = adminPort.deleteRecurringSaleInformation(wsRequest);
		LOG.debug("Web service call made.");

		//map the cenpos response object to our model response object
		if (wsResponse != null) {
			LOG.debug("wsResponse.getResult(): " + wsResponse.getResult());
			outTransaction.setSuccessful(wsResponse.getResult()==0?true:false);
		} else {
			//outTransaction.setHasWSCallError(true);
			//outTransaction.setMsgCodeError("Code error null");
			//outTransaction.setMsgError("WSResponse is null");		
		}
		return outTransaction;
	}
	
	private Administration getAdminPort() throws MalformedURLException{
		//initialize Transactional Serivce
		LOG.debug("CreditCard CenPOS initialize service: " + WebserviceDaoFactory.WSDL_URL_CREDITCARD_ADMIN);
		URL url_wsdl = new URL(WebserviceDaoFactory.WSDL_URL_CREDITCARD_ADMIN);
		LOG.debug("url: " + url_wsdl);
		QName qname = new QName("http://tempuri.org/", "AdministrationWebService");
		LOG.debug("qname: " + qname);
		AdministrationWebService service = new AdministrationWebService(url_wsdl, qname);
		LOG.debug("service initialized...");
		setSOAPLoggingHandler(service);
		Administration adminPort = service.getPort(Administration.class);
		LOG.debug("adminPort initialized...");
		return adminPort;
	}
	
	private DeleteRecurringSaleInformationRequest createDeleteCreditCardRequestParams(CreditCard creditCard){
		QName deleteRequestQName = new QName("http://schemas.datacontract.org/2004/07/Acriter.ABI.CenPOS.EPayment.VirtualTerminal.v5.Common", "DeleteRecurringSaleInformationResponse");
		QName addRecurringQName = new QName("http://schemas.datacontract.org/2004/07/Acriter.ABI.CenPOS.EPayment.VirtualTerminal.v5.Common", "RecurringSaleTokenId");
		
		org.datacontract.schemas._2004._07.acriter_abi_cenpos_epayment_virtualterminal.ObjectFactory merchantObjectFactory = new org.datacontract.schemas._2004._07.acriter_abi_cenpos_epayment_virtualterminal.ObjectFactory();
		JAXBElement<String> userID = merchantObjectFactory.createVirtualTerminalWebServiceRequestUserId(WebserviceDaoFactory.CREDITCARD_USER_ID);
		JAXBElement<String> password = merchantObjectFactory.createVirtualTerminalWebServiceRequestPassword(WebserviceDaoFactory.CREDITCARD_PASSWORD);
		
		JAXBElement<String> token = new JAXBElement<String>(addRecurringQName, String.class, DeleteRecurringSaleInformationRequest.class, creditCard.getToken());

		DeleteRecurringSaleInformationRequest wsRequest = new DeleteRecurringSaleInformationRequest();
		
		wsRequest.setMerchantId(new Integer(WebserviceDaoFactory.CREDITCARD_MERCHANT_ID));
		wsRequest.setPassword(password);
		wsRequest.setUserId(userID);
		wsRequest.setRecurringSaleTokenId(token);
		
		return wsRequest;		
	} 
	
	private void setSOAPLoggingHandler(Service service){
		service.setHandlerResolver(new HandlerResolver(){
			@Override
			public List<Handler> getHandlerChain(PortInfo portInfo) {
				List<Handler> handlerChain = new ArrayList<Handler>();
				handlerChain.add(new SOAPLoggingHandler());
				return handlerChain;
			}

		});
	}
}
