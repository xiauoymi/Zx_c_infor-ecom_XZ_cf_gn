package com.intentia.iec.pipeline.runtime.stage.custom.daf.drawing;

/**
 * Contains DAF definitions for Drawing.
 *
 */
public interface DafDrawingConstants {
	
	public static interface ApplicationProperty {
		public static final String EQUIPMENT_PORTAL = "Application.Equipment Portal";
		
		public static final String SPS_ENABLED = "Application.SPS Enabled";	
	}
	
	/**
	 * Drawing entity name.
	 */
	public static final String ENTITY_NAME = "ESA_Drawing";
	
	/**
	 * Root
	 */
	public static final String TABLE = "/ESA_Drawing";
	
	/**
	 * Attribute for Drawing Name
	 */
	public static final String ATTRIBUTE_NAME = "MDS_Name";
	
	/**
	 * Attribute for Drawing Status (Draft, Approved, Invalid)
	 */
	public static final String ATTRIBUTE_STATUS = "MDS_Status";
	
	/**
	 * Attribute for Drawing Number
	 */
	public static final String ATTRIBUTE_DRAWING_NUMBER = "ESA_DrawingNumber";
	
	/**
	 * Attribute for Item Number
	 */
	public static final String ATTRIBUTE_ITEM_NUMBER = "ESA_ItemNumber";

	/**
	 * Attribute for Serial Number
	 */
	public static final String ATTRIBUTE_SERIAL_NUMBER = "ESA_SerialNumber";
	
	/**
	 * Attribute for Is Default
	 */
	public static final String ATTRIBUTE_IS_DEFAULT = "ESA_DefaultDrawing";
	
	/**
	 * Attribute for the Hot spots
	 */
	public static final String ATTRIBUTE_HOTSPOTS = "ESA_DrawingHotspots";
	
	/**
	 * Attribute for the Coordinate 
	 */
	public static final String ATTRIBUTE_COORDINATES = "ESA_Coordinates";
	
	/**
	 * Attribute for the Shape code
	 */
	public static final String ATTRIBUTE_SHAPE_CODE = "ESA_ShapeCode";
	
	/**
	 * e-Sales field for Drawing Name
	 */
	public static final String FIELD_NAME = "Name";
	

	/**
	 * e-Sales field for Serial Name
	 */
	public static final String FIELD_SERIAL_NUMBER = "SerialNumber";
	
	/**
	 * e-Sales field for Drawing Number
	 */
	public static final String FIELD_DRAWING_NUMBER = "PrintNumber";
	
	/**
	 * e-Sales field for Item Number
	 */
	public static final String FIELD_ITEM_NUMBER = "ItemNumber";
	
	/**
	 * e-Sales field for Is Default
	 */
	public static final String FIELD_IS_DEFAULT = "IsDefault";
	
	/**
	 * e-Sales field for Status
	 */
	public static final String FIELD_STATUS = "Status";
	
	/**
	 * e-Sales field for IsCheckedOut
	 */
	public static final String FIELD_ISCHECKEDOUT = "IsCheckedOut";
	
	/**
	 * e-Sales field for CheckedOutBy
	 */
	public static final String FIELD_CHECKEDOUTBY = "CheckedOutBy";
	
	/**
	 * e-Sales field for ID
	 */
	public static final String FIELD_ID = "ID";
	
	/**
	 * e-Sales field for Image Master
	 */
	public static final String FIELD_IMAGE_MASTER = "ImageMaster";
	
	/**
	 * e-Sales field for Coordinate
	 */
	public static final String FIELD_COORDINATE = "Coordinate";
	
	/**
	 * e-Sales field for Shape Code
	 */
	public static final String FIELD_SHAPE_CODE = "ShapeCode";
	
	/**
	 * e-Sales field for Has Drawing
	 */
	public static final String FIELD_HAS_DRAWING = "HasDrawing";
	
	/**
	 * Attribute for Drawing Name with '@'
	 */
	public static final String COLUMN_NAME = "@" + ATTRIBUTE_NAME;
	
	/**
	 * Attribute for Drawing Number with '@'
	 */
	public static final String COLUMN_DRAWING_NUMBER = "@" + ATTRIBUTE_DRAWING_NUMBER;
	
	/**
	 * Attribute for Item Number with '@'
	 */
	public static final String COLUMN_ITEM_NUMBER = "@" + ATTRIBUTE_ITEM_NUMBER;

	/**
	 * Attribute for Serial Number with '@'
	 */
	public static final String COLUMN_SERIAL_NUMBER = "@" + ATTRIBUTE_SERIAL_NUMBER;
	
	/**
	 * Attribute for Is Default with '@'
	 */
	public static final String COLUMN_IS_DEFAULT = "@" + ATTRIBUTE_IS_DEFAULT;
	
	/**
	 * Attribute for Hot spot with '@'
	 */
	public static final String COLUMN_HOTSPOTS = "@" + ATTRIBUTE_HOTSPOTS;
	
	/**
	 * Attribute for Coordinate with '@'
	 */
	public static final String COLUMN_COORDINATES = "@" + ATTRIBUTE_COORDINATES;
	
	/**
	 * Attribute for Shape Code with '@'
	 */
	public static final String COLUMN_SHAPE_CODE = "@" + ATTRIBUTE_SHAPE_CODE;
	
	/**
	 * Attribute for Status with '@'
	 */
	public static final String COLUMN_STATUS = "@" + ATTRIBUTE_STATUS;
	
	/**
	 * Drawing Item ID
	 */
	public static final String COLUMN_ITEMID = "@ITEMID";
	
	/**
	 * Entity Name for a Drawing resource
	 */
	public static final String RESOURCE_ENTITY_NAME = "ICMBASE";
	
	/**
	 * Used to denote 'true' for boolean e-Sales field
	 */
	public static final String YES = "Y";
	
	/**
	 * Used to denote 'false' for boolean e-Sales field
	 */
	public static final String NO = "N";
	
	
	/**
	 * Status code definitions in DAF.
	 *
	 */
	public static interface DAFStatusCodes {
		public final static short DRAFT = 5;		
		public final static short APPROVED = 20;		
		public final static short INVALID = 80;
	}
	
	/**
	 * Status code definitions in e-Sales.
	 *
	 */
	public static interface StatusCodes {
		public final static String DRAFT = "DraftBlowUpPrintStatus";		
		public final static String APPROVED = "ApprovedBlowUpPrintStatus";		
		public final static String INVALID = "InvalidBlowUpPrintStatus";
	}
	
	
	/**
	 * Supported shape codes.
	 *
	 */
	public static interface ShapeCodes {
		public final static String CIRCLE = "ItemShapeCircle";
		public final static String RECTANGLE = "ItemShapeRectangle";
		public final static String POLYGON = "ItemShapePolygon";
	}	

    /**
     * Paging from e-Sales request object.
     *
     */
    public static interface Paging {
    	public final static String paging = "paging";

    	public final static String limit = "limit";

    	public final static String offset = "offset";
    }    
    
    /**
     * Binding from e-Sales request object.
     *
     */
    public static interface Binding {
    	public final static String binding = "binding";

    	public final static String attribute = "attribute";

    	public final static String value = "value";
        
    	public final static String operator = "operator";
        
    	public final static String contains = "CONTAINS";

    	public final static String itemNumber = "ItemNumber";

    	public final static String printNumber = "PrintNumber";
    	
    	public final static String serialNumber = "SerialNumber";
        
    	public final static String name = "Name";
    }
    
    /**
     * Search direction from e-Sales request object.
     *
     */
    public static interface Order {
    	public final static String order = "order";

    	public final static String attribute = "attribute";

    	public final static String direction = "direction";
    }
    
    /**
     * Search keys from e-Sales request object.
     *
     */
    public static interface Keys {
    	public final static String key = "key";

    	public final static String value = "value";
    }
    
    /**
     * Attributes from e-Sales request object.
     *
     */
    public static interface Attributes {
    	public final static String attribute = "attribute";
    	
    	public final static String name = "name";
    	
    	public final static String _name = "Name";
    	
    	public final static String itemNumber = "ItemNumber";
    	
    	public final static String printNumber = "PrintNumber";
    	
    	public final static String serialNumber = "SerialNumber";
    	
    	public final static String isDefault = "IsDefault";
    	
    	public final static String imageMaster = "ImageMaster";
    	
    	public final static String status = "Status";
    }
    
    /**
     * Subset from e-Sales request object.
     *
     */
    public static interface Subset {
    	public final static String subset = "subset";
    	
    	public final static String name = "name";
    	
    	public final static String itemMap = "ItemMap";
    	
    	public final static String coordinate = "Coordinate";
    	
    	public final static String shapeCode = "ShapeCode";
    	
    	public final static String itemNumber = "ItemNumber";
    	
    	public final static String serialNumber = "SerialNumber";
    }
}
