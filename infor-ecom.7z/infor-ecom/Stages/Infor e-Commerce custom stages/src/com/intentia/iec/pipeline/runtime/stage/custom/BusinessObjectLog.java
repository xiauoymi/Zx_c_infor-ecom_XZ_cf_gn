/*
 * Created on 29-03-2004
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.util.Properties;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;
import com.intentia.iec.sqlserver.common.DatabaseType;
import com.intentia.iec.sqlserver.runtime.procedure.Parameter;
import com.intentia.iec.sqlserver.runtime.procedure.StageCallIteratorProcedure;
import com.intentia.iec.util.FastStringBuffer;
import com.intentia.iec.util.PropertyLoader;

/**
 * <p>
 * The <code>BusinessObjectLog</code> stage inserts log statements in the
 * table <code>BusinessObjectLog</code>, if the request is a non-empty
 * delete, insert, or update. The actual insert is performed by the stored
 * procedure <code>InsertBusinessObjectLog</code>.<br>
 * The stage inserts a row in <code>BusinessObjectLog</code> containing the
 * following information:
 * <ul>
 * <li>Command - the type of request, i.e. delete, insert, or update.</li>
 * <li>BusinessObject - the name of the business object performing the command.
 * </li>
 * <li>BusinessObjectID - the key from the request.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <b>Required input in <code>PipelineContext</code>: </b> <br>
 * The <code>PipelineContext</code> must contain a non-empty delete, insert,
 * or update. If the request is a search then nothing the stage does nothing.
 * </p>
 * 
 * <p>
 * <b>Generated output in <code>PipelineContext</code>: </b> <br>
 * </p>
 */

public class BusinessObjectLog extends AbstractPipelineStage {
    private static final Logger LOG = Logger.getLogger(BusinessObjectLog.class);

    // source/target for procedure parameters
    // fieldnames for procedure parameters
    private static final String COMMAND_FIELD = "command";

    private static final String BUSINESS_OBJECT_FIELD = "businessObject";

    private static final String CONNECTION_PROPERTIES = "/connections.properties";

    private String command = null;

    // the type of database action, i.e. insert, update, delete
    private String businessObjectName = null;

    private String businessObjectIDName = null;

    // the key name in update/insert
    private XMLResultset response = null;

    /**
     * <p>
     * Insert log statement for delete, insert, or update requests in the table
     * <code>BusinessObjectLog</code>.
     * </p>
     * 
     * @throws PipelineRuntimeException
     * @see com.intentia.iec.pipeline.runtime.PipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
     */
    public void execute(PipelineContext context) throws PipelineRuntimeException {
        if (findProcedureParameters(context)) {
            updateTable();
        }
    }

    /**
     * <p>
     * Method to set the command, businessObjectName, and businessObjectID if
     * request is a delete, insert, or update.
     * </p>
     * 
     * @param context
     *            the <code>PipelineContext</code>.
     * @return false if search request else true.
     * @throws PipelineRuntimeException
     *             if a no key is available in the (delete) request
     */
    private boolean findProcedureParameters(PipelineContext context) throws PipelineRuntimeException {

        businessObjectName = context.getObjectName();

        // is it a search request => do nothing
        XMLRequest request = CustomStagesHelper.getRequest(context);

        if (XMLRequestHelper.isSearchRequest(request)) {
            if (LOG.isDebugEnabled()) {
                FastStringBuffer msg = new FastStringBuffer();
                msg.append("The request was a search request, thus the stage '");
                msg.append(BusinessObjectLog.class.getName());
                msg.append("' does nothing!");
                LOG.debug(msg.toString());
            }
            return false;
        }
        // or is it a delete request
        if (XMLRequestHelper.isDeleteRequest(request)) {
            command = "del";
            businessObjectIDName = getKeyNameFromResponse(context);

            if (businessObjectIDName == null) {
                LOG
                        .info("Key name was not set in response from update/insert/delete statement!. Assuming this is equivalent to no inserts");
                return false;
            }

            response = getResponse(context);
            return true;

        }

        // or is it an insert request
        if (XMLRequestHelper.isInsertRequest(request)) {
            command = "ins";
            businessObjectIDName = getKeyNameFromResponse(context);

            if (businessObjectIDName == null) {
                LOG
                        .info("Key name was not set in response from update/insert/delete statement!. Assuming this is equivalent to no inserts");
                return false;
            }

            response = getResponse(context);
            return true;
        }

        // or is it an update request
        if (XMLRequestHelper.isUpdateRequest(request)) {
            command = "upd";
            businessObjectIDName = getKeyNameFromResponse(context);

            if (businessObjectIDName == null) {
                LOG
                        .info("Key name was not set in response from update/insert/delete statement!. Assuming this is aquivalent to no inserts");
                return false;
            }

            response = getResponse(context);
            return true;
        }

        // the request was empty, e.g.
        // <request>
        // <params />
        // <entities />
        // </request>
        // is a valid request, i.e. it does nothing!
        return false;
    }

    /**
     * <p>
     * Helper method to fetch keyName from reponse in the
     * <code>PipelineContext</code>.
     * </p>
     * 
     * @param context
     * @return name of the key
     * @throws PipelineRuntimeException
     *             if no key name was found
     */
    private String getKeyNameFromResponse(PipelineContext context) throws PipelineRuntimeException {
        // get the key from the response/result
        Parameters parameters = getResponse(context).getParameters();
        String keyName = null;
        try {
            keyName = parameters.getString("keyName");
        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Failed to get the key name from response!", e);
        }

        return keyName;
    }

    /**
     * <p>
     * Execute the stored procedure <code>InsertBusinessObjectLog</code> to
     * update the table BusinessObjectLog. The procedure is executing
     * <code>StageCallIteratorProcedure</code>.
     * </p>
     * 
     * @throws PipelineRuntimeException
     */
    private void updateTable() throws PipelineRuntimeException {
        Properties connectionProperties = PropertyLoader.loadProperties(CONNECTION_PROPERTIES);

        StageCallIteratorProcedure procedure = new StageCallIteratorProcedure("EXEC InsertBusinessObjectLog ?, ?, ?",
                connectionProperties);

        int varcharType = DatabaseType.parseTypeName("varchar");

        procedure.addInputParam("@Command", 1, varcharType, Parameter.PIPELINE_CONTEXT, COMMAND_FIELD);
        procedure.addInputParam("@BusinessObject", 2, varcharType, Parameter.PIPELINE_CONTEXT, BUSINESS_OBJECT_FIELD);
        procedure.addInputParam("@BusinessObjectID", 3, varcharType, Parameter.RESULT, businessObjectIDName);

        // create separate context for call to procedure
        PipelineContext procedureContext = new PipelineContext();
        procedureContext.setResponse(response);

        // add parameters to context
        procedureContext.put(COMMAND_FIELD, command);
        procedureContext.put(BUSINESS_OBJECT_FIELD, businessObjectName);
        // execute procedure
        procedure.execute(procedureContext);
    }
}
