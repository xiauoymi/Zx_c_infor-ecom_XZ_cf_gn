package com.intentia.iec.pipeline.runtime.stage.custom;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.connection.ConnectorException;
import com.intentia.iec.connection.IMovexApiResultset;
import com.intentia.iec.connection.IMovexConnection;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;

public class CreateTextBlock implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(CreateTextBlock.class);

    private static final String CRS980MI = "esales.CRS980MI";

    private static final String ADD_TEXTBLOCK_HEAD = "AddTxtBlockHead";

    private static final String ADD_TEXTBLOCK_LINE = "AddTxtBlockLine";

    private static final String DELETE_TEXTBLOCK = "DltTxtBlockLins";

    private static final String TFIL_VALUE = "MSYTXH00";

    private IMovexConnection con = null;

    private Parameters requestParameters = null;

    private String mvxCompany = null;

    private String mvxFacility = null;

    private String productNumber = null;

    private String structureType = null;

    private String sequenceNumber = null;

    private String featureType = null;

    private String textId = null;

    private String personalText = null;

    public void execute(final PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("Entering CreateTextBlock.execute()");
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }

        XMLRequest request = (XMLRequest) context.getRequest();

        try {
            con = (IMovexConnection) CustomStagesHelper.getConnection(CRS980MI);

            XMLRequest.extractRequestParameters(request);
            requestParameters = request.getParameters();

            mvxCompany = requestParameters.getString(ConstantsForSales.MVXCOMPANY);
            mvxFacility = requestParameters.getString(ConstantsForSales.MVXFACILITY);
            productNumber = requestParameters.getString("ProductNumber");
            structureType = requestParameters.getString("StructureType");
            sequenceNumber = String.format("%03d", requestParameters.getint("SequenceNumber"));
            featureType = requestParameters.getString("FeatureType");
            textId = requestParameters.getString("TextBlockID");
            personalText = requestParameters.getString("PersonalText");

            if (!addTextBlockHead(context)) {
                throw new PipelineRuntimeException("Failed to add text block head.");
            }

            if (!addTextBlockLines(context)) {
                deleteTextBlock(context);                
                throw new PipelineRuntimeException("Failed to add text block lines.");
            }

        } catch (RequestException e) {
            throw new PipelineRuntimeException("Failed to operate on request", e);
        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Failed to get parameter from request", e);
        } catch (PipelineRuntimeException e) {
            if (con == null) {
                LOG.error("Failed to connect to Movex", e);
            } else {
                throw e;
            }
        } finally {
            if (con != null) {
                try {
                    con.close();
                } catch (ConnectorException e) {
                    LOG.error("Failed to close connection!");
                }
            }
        }

        LOG.debug("Exiting CreateTextBlock.execute()");
    }

    private boolean addTextBlockHead(final PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("Entering CreateTextBlock.addTextBlockHead()");
        //FACI/PRNO/STRT/SQNU/FTID
        String fileKey = mvxFacility + productNumber + structureType + sequenceNumber + featureType;
        
        Map input = new HashMap();
        input.put(IMovexConnection.TRANSACTION, ADD_TEXTBLOCK_HEAD);
        input.put("CONO", mvxCompany);
        input.put("TXID", textId);
        input.put("FILE", "MPFEHE00");
        input.put("KFLD", fileKey);
        input.put("USID", con.getUserName());
        input.put("TFIL", TFIL_VALUE);
		
        IMovexApiResultset rs = CustomStagesHelper.callMovex(context, con, input, ConstantsForSales.MVXSTATUS);
        if (rs == null) {
            LOG.error("Resultset is empty.");
            return false;
        }

        if (!con.isOk()) {
            LOG.error("Failed to add new text block head. " + con.getLastMessage());
            return false;
        } else {
            LOG.debug("Inserted Text Block Head");
        }
        LOG.debug("Exiting CreateTextBlock.addTextBlockHead()");
        return true;
    }

    private boolean addTextBlockLines(final PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("Entering CreateTextBlock.addTextBlockLines()");
        String text = personalText.replaceAll("\\r", "");
        String[] lines = text.split("\\n");

        for (int x = 0; x < lines.length; x++) {
            if (!addTextBlockLine(context, lines[x]))
                return false;
        }
        LOG.debug("Exiting CreateTextBlock.addTextBlockLines()");
        return true;
    }

    private boolean addTextBlockLine(final PipelineContext context, String line) throws PipelineRuntimeException {
        //LOG.debug("Entering CreateTextBlock.addTextBlockLine()");
        Map input = new HashMap();
        input.put(IMovexConnection.TRANSACTION, ADD_TEXTBLOCK_LINE);
        input.put("CONO", mvxCompany);
        input.put("TXID", textId);
        input.put("TX60", line);
        input.put("TFIL", TFIL_VALUE);
        
        //LOG.debug("Inserting text block line: " + line);
        IMovexApiResultset rs = CustomStagesHelper.callMovex(context, con, input, ConstantsForSales.MVXSTATUS);
        if (rs == null) {
            LOG.error("Resultset is empty.");
            return false;
        }

        if (!con.isOk()) {
            LOG.error("Failed to add new text block line. " + con.getLastMessage());
            return false;
        //} else {
        //    LOG.debug("Inserted Text Block Line: " + rs.getParamAsString("LINO"));
        }
        
        //LOG.debug("Exiting CreateTextBlock.addTextBlockLine()");
        return true;
    }
    
    private boolean deleteTextBlock(final PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("Entering CreateTextBlock.deleteTextBlock()");
        Map input = new HashMap();
        input.put(IMovexConnection.TRANSACTION, DELETE_TEXTBLOCK);
        input.put("CONO", mvxCompany);
        input.put("TXID", textId);
        input.put("TFIL", TFIL_VALUE);
        
        IMovexApiResultset rs = CustomStagesHelper.callMovex(context, con, input, ConstantsForSales.MVXSTATUS);
        if (rs == null) {
            LOG.error("Resultset is empty.");
            return false;
        }

        if (!con.isOk()) {
            LOG.error("Failed to delete text block. " + con.getLastMessage());
            return false;
        } else {
            LOG.debug("Deleted Text Block");
        }
        LOG.debug("Exiting CreateTextBlock.deleteTextBlock()");
        return true;
        
    }
}
