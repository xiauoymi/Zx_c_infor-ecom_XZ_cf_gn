package com.intentia.iec.pipeline.runtime.stage.custom.daf.drawing;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;

/**
 * Sets the IsValidItem flag of a Drawing. This stage will query the database for valid AsBuilt Structure
 * and check it against the Drawings found in DAF.
 *
 */
public class MarkValidEquipmentStage extends AbstractPipelineStage {
	private static final Logger LOG = Logger.getLogger(MarkValidEquipmentStage.class);
	
	private static final String MAINSET_ITEMS = "resultset/row";
	
	private static final String ITEM_NUMBER = "ItemNumber";
	
	private static final String SERIAL_NUMBER = "SerialNumber";
	
	private static final String PARENTITEM = "ParentItemNumber";
	
	private static final String PARENTSERIAL = "ParentSerialNumber";
	
	private static final String CHILDITEM = "ChildItemNumber";
	
	private static final String CHILDSERIAL = "ChildSerialNumber";
	
	private static final String IS_VALID_ITEM = "IsValidItem";
	
	/**
	 * SQL statement to retrieve valid product-child values from the AsBuiltStructure table.
	 */
	private static final String SELECT_EQUIPMENT = 
		"select distinct p.itemNumber as ParentItemNumber, parent.serialNumber as ParentSerialNumber, c.itemNumber as ChildItemNumber, child.serialNumber as ChildSerialNumber " +
		"from AsBuiltStructure asb " +
		"inner join Equipment parent on asb.parentEquipmentId=parent.id " +
		"inner join Item p on parent.itemId=p.id " +
		"inner join Equipment child on asb.childEquipmentId=child.id " +
		"inner join Item c on child.itemId=c.id " +
		"where p.itemNumber in ";	

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.AbstractPipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public void execute(PipelineContext context) throws PipelineRuntimeException {
        if (!(context.getResponse() instanceof XMLResultset)) {
            throw new PipelineRuntimeException("XML Request is invalid");
        }

        // skip if Equipment=disabled
        if (!"true".equals(CustomStagesHelper.getKeyValue(DafDrawingConstants.ApplicationProperty.EQUIPMENT_PORTAL))) {
        	LOG.debug(DafDrawingConstants.ApplicationProperty.EQUIPMENT_PORTAL + " is disabled. Skipping this stage.");
        	return;
        }
        
        Connection conn = (Connection) CustomStagesHelper.getConnection("esales.cursor");
        Statement stmt = null;
        try {
        	// get Item Numbers displayed in the page
			Set<Equipment> set = getSerialNumbers(context);
			if (set.isEmpty() == false) {
				// get query for Item Numbers displayed in page
				String sql = getSqlStatement(set);				
				stmt = conn.createStatement();

				LOG.debug("Executing SQL statement=" + sql);

				long startTime = System.currentTimeMillis();
				ResultSet sqlResultSet = stmt.executeQuery(sql);
				long stopTime = System.currentTimeMillis();
				LOG.debug("Total execution time: " + (stopTime - startTime) + " ms");

				// get valid items in the database
				Map<Equipment,Set<Equipment>> validEquipment = getValidEquipment(sqlResultSet);
				
				// set the IsValidItem in the XMLResultset
				markValidEquipment(context, validEquipment);
			}
		} catch (Exception e) {
			throw new PipelineRuntimeException(e);
		}
		finally {
			LOG.debug("Closing the statement object");
			if (stmt != null) {
				try {
					stmt.close();
				}
				catch (SQLException e) {
					LOG.error(e);
				}
				stmt = null;
			}
			
			LOG.debug("Closing the connection object");
			if (conn != null) {
				try {
					conn.close();
				}
				catch (SQLException e) {
					LOG.error(e);
				}
				conn = null;
			}
		}
	}
	
	/**
	 * Returns the Item Numbers displayed in the page
	 * @param context
	 * @return
	 * @throws ResultsetException
	 * @throws TransformerException
	 */
	private Set<Equipment> getSerialNumbers(PipelineContext context) throws ResultsetException, TransformerException {
		Set<Equipment> serialNumbers = new HashSet<Equipment>();
		XMLResultset resultset = (XMLResultset) context.getResponse();
		resultset.moveFirst();
		
		Document xmlDoc = resultset.getDocument();
		NodeList nodeList = XPathAPI.selectNodeList(xmlDoc, MAINSET_ITEMS);

		// iterate through the result set
		for (int i = 0; i < nodeList.getLength(); i++) {
			Element e = (Element) nodeList.item(i);
			if (e.getAttribute(ITEM_NUMBER) != null && isSerialNumberPresent(e) == true) {
				Equipment equipment = new Equipment(e.getAttribute(ITEM_NUMBER), e.getAttribute(SERIAL_NUMBER));
				serialNumbers.add(equipment);
			}
		}
		
		return serialNumbers;
	}
	
	/**
	 * Checks if the serial number is present
	 * @param e
	 * @return
	 */
	private boolean isSerialNumberPresent(Element e) {
		if (e.getAttribute(SERIAL_NUMBER) != null && !"".equals(e.getAttribute(SERIAL_NUMBER))) {
			return true;
		}
		
		return false;
	}
	
	/**
	 * Returns a list of Item Numbers displayed in the page.
	 * @param set
	 * @return
	 */
	private String getInStatement(Set<Equipment> set) {
		StringBuffer buf = new StringBuffer("(");		
		boolean first = true;
		
		if (set != null) {
			Iterator<Equipment> it = set.iterator();
			while (it.hasNext() == true) {
				Equipment equipment = it.next();
				if (first == false) {
					buf.append(",");
				}
				buf.append("'" + encodeSQL(equipment.getItemNumber()) + "'");
				first = false;
			}
			buf.append(")");
		}
		
		return buf.toString();
	}
	
	/**
	 * Returns the SQL statement to retrieve the product-child values in the e-Sales database.
	 * @param set
	 * @return
	 */
	private String getSqlStatement(Set<Equipment> set) {
		String inStatement = getInStatement(set);
		return SELECT_EQUIPMENT + inStatement;
	}
	
	/**
	 * Returns a Map of the product-child values in e-Sales.
	 * @param sqlResultSet
	 * @return
	 * @throws SQLException
	 */
	private Map<Equipment,Set<Equipment>> getValidEquipment(ResultSet sqlResultSet) throws SQLException {
		Map<Equipment,Set<Equipment>> validItems = new HashMap<Equipment,Set<Equipment>>();
		
		if (sqlResultSet != null) {
			while (sqlResultSet.next() == true) {
				// get parent
				String parentItem = sqlResultSet.getString(PARENTITEM);
				String parentSerialNumber = sqlResultSet.getString(PARENTSERIAL);
				
				Equipment parentEquipment = new Equipment(parentItem, parentSerialNumber);

				if (validItems.get(parentEquipment) == null) {
					// if parent does not exist, add parent
					validItems.put(parentEquipment, new HashSet<Equipment>());
				}

				String childItem = sqlResultSet.getString(CHILDITEM);
				String childSerialNumber = sqlResultSet.getString(CHILDSERIAL);
				Equipment childEquipment = new Equipment(childItem, childSerialNumber);

				// add child
				Set<Equipment> children = validItems.get(parentEquipment);
				children.add(childEquipment);
			}
		}
		
		return validItems;
	}
	
	/**
	 * Sets the IsValidItem flag in the XMLResultset.
	 * @param context
	 * @param validItems
	 * @throws ResultsetException
	 * @throws TransformerException
	 */
	private void markValidEquipment(PipelineContext context, Map<Equipment,Set<Equipment>> validEquipment) throws ResultsetException, TransformerException {
		XMLResultset resultset = (XMLResultset) context.getResponse();
		resultset.moveFirst();

		Document xmlDoc = resultset.getDocument();
		NodeList parentNodeList = XPathAPI.selectNodeList(xmlDoc, MAINSET_ITEMS);
		
		// iterate through the main set
        for (int i = 0; i < parentNodeList.getLength(); i++) {
        	boolean parentValid = false;
        	Element parentElement = (Element) parentNodeList.item(i);        	
        	
        	// only set flag if serial number is NOT set
        	if (isSerialNumberPresent(parentElement) == true) {
        		
        		Equipment parentEquipment = new Equipment(parentElement.getAttribute(ITEM_NUMBER), parentElement.getAttribute(SERIAL_NUMBER));        		
        		
            	// if parent is valid, set to 'Y'
            	if (parentElement.getAttribute(ITEM_NUMBER) != null && validEquipment.get(parentEquipment) != null) {
            		parentElement.setAttribute(IS_VALID_ITEM, DafDrawingConstants.YES);
            		parentValid = true;
            	}
            	else {
            		parentElement.setAttribute(IS_VALID_ITEM, DafDrawingConstants.NO);
            	}

            	NodeList childNodeList = parentElement.getChildNodes();
            	Set<Equipment> childEquipmentList = validEquipment.get(parentEquipment);

            	// iterate through the children
            	for (int j = 0; j < childNodeList.getLength(); j++) {
            		Element childElement = (Element) childNodeList.item(j);
            		
            		if (childElement.getAttribute(ITEM_NUMBER) != null) {
                		if (parentValid == false) {
                			// if parent is invalid, all children are invalid
                			childElement.setAttribute(IS_VALID_ITEM, DafDrawingConstants.NO);
                		}
                		else {
                			Equipment childEquipment = new Equipment(childElement.getAttribute(ITEM_NUMBER), childElement.getAttribute(SERIAL_NUMBER));
                			
                			// if parent is valid, check if child is valid
                			 if (childEquipmentList.contains(childEquipment) == true && isSerialNumberPresent(childElement) == true) {
                				 childElement.setAttribute(IS_VALID_ITEM, DafDrawingConstants.YES);
                			 }
                			 else {
                				 childElement.setAttribute(IS_VALID_ITEM, DafDrawingConstants.NO);
                			 }
                		}
            		}
            	}
        	}
        }
	}
	
	/**
	 * Changes the ' to ''
	 * @param query
	 * @return
	 */
	private String encodeSQL(String query) {
		String ret = null;
		if (query != null) {			
			ret = query.replaceAll("'", "''");
		}
		
		return ret;
	}
}
