/*
 * Created on 06-25-2009
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Node;
import javax.xml.transform.TransformerException;
import java.lang.reflect.Method;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;
import com.intentia.iec.pipeline.runtime.stage.utils.PasswordValidator;

/**
 * <p>
 * Validates user's password based on the specified active password policies
 * found in the PasswordPolicy table.
 * </p>
 * <p>
 * <b>Input in <code>PipelineContext</code>:</b><br>
 * Parameters:
 * <ul>
 * <li><code>Password</code> (mandatory)</li>
 * <li><code>&#64LanguageCode</code> </li>
 * </ul>
 * </p>
 * <p>
 * <b>Generated output in <code>PipelineContext</code>:</b><br>
 * Parameters:
 * <ul>
 * <li></li>
 * <li><code>validationResult</code> a boolean value as the result of the
 * validation</li>
 * <li><code>validationErrorMsg</code> the error messages of the violated
 * policies (if any)</li>
 * </ul>
 * </p>
 * 
 * 
 * The text uses the character code &#64; for @ to avoid to confuse the Java
 * auto formatter.
 */
public class ValidatePassword implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(ValidatePassword.class);

    private static final String ENTITY_XPATH = "request/entities/entity";

    private static final String PARAM_XPATH = "request/params/param";

    private static final String PASSWORD_VALIDATOR_CLASS = "com.intentia.iec.pipeline.runtime.stage.utils.PasswordValidator";

    private static final String ERROR_MSG_PREFIX = "<li>";

    private static final String ERROR_MSG_SUFFIX = "</li>\n";

    private static final String ERROR_MSG_DATA_SECTION = "%%0";

    private static final String ATTRIB_PASSWORD = "Password";

    private static final String ATTRIB_ENABLED = "Enabled";

    private static final String ATTRIB_INTERNAL_NAME = "InternalName";

    private static final String ATTRIB_VALIDATOR = "Validator";

    private static final String ATTRIB_PARAM_VALUE = "ParamValue";

    private static final String ATTRIB_PARAM_TYPE = "ParamType";

    private static final String ATTRIB_ERROR_MSG = "ErrorMsg";

    private static final String PARAM_PREVALIDATION = "@prevalidation";

    private static final String PARAM_LANGUAGE_CODE = "@LanguageCode";

    private static final String PARAM_SKIP_STAGES = "@SkipThisStage";

    private static final String PARAM_IS_VALID_PASSWORD = "IsValidPassword";

    private static final String PARAM_VALIDATION_ERROR_MSG = "ValidationErrorMsg";

    private static final String PARAM_PASSWORD = "Password";

    private static final String PARAM_SEND_MAIL = "@sendMail";

    private static final String PARAM_GENERATED_PASSWORD = "@generatedPassword";

    private boolean hasVoilation = false;

    private String validationErrorMsg = "";

    private String languageCode = null;

    /*
     * (non-Javadoc) Pipeline entry point.
     */
    public void execute(final PipelineContext context) throws PipelineRuntimeException {

        // Verify type of request
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Request MUST be of type XMLRequest!");
        }

        XMLRequest request = (XMLRequest) context.getRequest();

        try {
            Node entityNode = XMLRequestHelper.getRequestNode(request, ENTITY_XPATH);
            XMLRequestHelper xmlHelper = new XMLRequestHelper(request);

            String strKey = null;
            if (entityNode != null)
                strKey = xmlHelper.getKey(entityNode);

            XMLRequest.extractRequestParameters(request);
            Parameters inParams = request.getParameters();

            String userPassword = getUserPassword(entityNode, request, inParams);
            languageCode = inParams.getString(PARAM_LANGUAGE_CODE);
            if (languageCode == null)
                languageCode = "en";

            if (userPassword == null) {
                LOG.debug("User Password is null, terminating password validation...");
                return; // nothing to validate
            }

            LOG.debug("User Password = " + userPassword);

            doValidation(userPassword);

            XMLResultset response = (XMLResultset) context.getResponse();

            if (response == null)
                response = new XMLResultset();

            Parameters outParams = response.getParameters();

            if (hasVoilation) {
                updateParameter(request, PARAM_SKIP_STAGES, "true");
                outParams.setString(PARAM_VALIDATION_ERROR_MSG, validationErrorMsg);
            } else if ((strKey != null) && (!"Y".equals(inParams.getString(PARAM_PREVALIDATION)))) {
                inParams.setboolean(PARAM_SEND_MAIL, true);
                inParams.setString(PARAM_GENERATED_PASSWORD, userPassword);
            }
            outParams.setString(PARAM_IS_VALID_PASSWORD, String.valueOf(!hasVoilation));
            context.setResponse(response);
        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Failed to get parameter from request", e);
        } catch (RequestException e) {
            throw new PipelineRuntimeException("Failed to get request from context", e);
        } catch (Exception e) {
            throw new PipelineRuntimeException("Unable to validate user password.", e);
        }

    }

    private String getUserPassword(Node entityNode, XMLRequest request, Parameters params)
            throws PipelineRuntimeException {
        try {
            if (params.getString(PARAM_PASSWORD) != null) {
                LOG.debug("Extracting user password from input parameter '" + PARAM_PASSWORD + "'.");
                return params.getString(PARAM_PASSWORD);
            } else {
                XMLRequestHelper requestHelper = new XMLRequestHelper(request);
                if (entityNode == null) {
                    LOG.debug("The request does not hold an entity node!");
                    return null;
                }
                try {
                    LOG.debug("Extracting user password from input attribute '" + ATTRIB_PASSWORD + "'.");
                    return requestHelper.getAttribute(entityNode, ATTRIB_PASSWORD);
                } catch (TransformerException e) {
                    LOG.debug("Missing attribute: " + ATTRIB_PASSWORD, e);
                    return null;
                }
            }
        } catch (Exception e) {
            throw new PipelineRuntimeException("Failed to extract user password", e);
        }
    }

    private void doValidation(String userPassword) throws PipelineRuntimeException {
        try {
            int violationCounter = 0;
            XMLResultset policies = getPasswordPolicies();
            policies.beforeFirst();
            while (policies.moveNext()) {

                String validator = policies.getString(ATTRIB_VALIDATOR);
                String paramValue = policies.getString(ATTRIB_PARAM_VALUE);
                String paramType = policies.getString(ATTRIB_PARAM_TYPE);
                String errorMsg = policies.getString(ATTRIB_ERROR_MSG);

                if (validator != null) {
                    if (!callPolicyValidator(userPassword, validator, paramValue, paramType)) {
                        violationCounter++;
                        if (errorMsg != null && !"".equals(errorMsg)) {
                            validationErrorMsg += ERROR_MSG_PREFIX;
                            if (paramType != null) {
                                String[] arrErrorMsg = errorMsg.split(ERROR_MSG_DATA_SECTION);
                                validationErrorMsg += arrErrorMsg[0] + paramValue;
                                if (arrErrorMsg.length > 1) {
                                    validationErrorMsg += arrErrorMsg[1];
                                }
                            } else {
                                validationErrorMsg += errorMsg;
                            }
                            validationErrorMsg += ERROR_MSG_SUFFIX;
                        }
                    }
                }
            }

            if (violationCounter > 0)
                hasVoilation = true;

        } catch (Exception e) {
            throw new PipelineRuntimeException("Failed to validate user password", e);
        }
    }

    private boolean callPolicyValidator(String sPassword, String sValidatorName, String sParamValue, String sParamType)
            throws PipelineRuntimeException {
        try {
            Class passwordValidationClass = Class.forName(PASSWORD_VALIDATOR_CLASS);
            PasswordValidator validatorClass = (PasswordValidator) passwordValidationClass.newInstance();
            Class paramClass = null;
            int argCount = 1;

            if (sParamType != null)
                argCount++;

            Object[] args = new Object[argCount];
            Class[] paramClasses = new Class[argCount];

            paramClasses[0] = String.class;
            args[0] = sPassword;

            if (sParamType == null) {
                // do nothing
            } else if ("int".equals(sParamType)) {
                paramClasses[1] = int.class;
                args[1] = new Integer(sParamValue);
            } else if ("String".equals(sParamType)) {
                paramClasses[1] = String.class;
                args[1] = sParamValue;
            } else if ("boolean".equals(sParamType)) {
                paramClasses[1] = boolean.class;
                args[1] = new Boolean(sParamValue);
            } else if ("double".equals(sParamType)) {
                paramClasses[1] = double.class;
                args[1] = new Double(sParamValue);
            } else {
                throw new PipelineRuntimeException("Unhandled paramater type at callPolicyValidator() method.");
            }
            // TODO: Add entries for other datatypes here (as needed)

            Method validatorMethod = passwordValidationClass.getMethod(sValidatorName, paramClasses);

            Object result = validatorMethod.invoke(validatorClass, args);

            return ((Boolean) result).booleanValue();

        } catch (ClassNotFoundException e) {
            throw new PipelineRuntimeException("Validator class not found: " + PASSWORD_VALIDATOR_CLASS, e);
        } catch (NoSuchMethodException e) {
            throw new PipelineRuntimeException("Validator method not found: '" + sValidatorName + "()'", e);
        } catch (InstantiationException e) {
            throw new PipelineRuntimeException("Failed to create new instance of Validator Class: '"
                    + PASSWORD_VALIDATOR_CLASS, e);
        } catch (Exception e) {
            throw new PipelineRuntimeException("Error found while invoking validator method: '" + sValidatorName
                    + "()'", e);
        }
    }

    private XMLResultset getPasswordPolicies() throws PipelineRuntimeException {
        try {

            SearchPipelineExecuter findPasswordPolicies = new SearchPipelineExecuter(
                    ConstantsForSales.PIPELINE_PACKAGE, "PasswordPolicy", "List");

            findPasswordPolicies.setParam(PARAM_LANGUAGE_CODE, "en");
            findPasswordPolicies.setBinding(ATTRIB_ENABLED, "Y", "eq");

            return findPasswordPolicies.execute();

        } catch (PipelineRuntimeException e) {
            throw new PipelineRuntimeException("Failed to fectch Password Policies", e);
        }
    }

    private void updateParameter(XMLRequest request, String paramName, String paramValue)
            throws PipelineRuntimeException {
        try {
            XMLRequestHelper xmlHelper = new XMLRequestHelper(request);
            org.w3c.dom.Document xmlDoc = request.getRequestDoc();
            String nodePath = PARAM_XPATH + "[@name='" + paramName + "']";
            Node paramNode = XPathAPI.selectSingleNode(xmlDoc, nodePath);

            if (paramNode != null) {
                paramNode.getFirstChild().setNodeValue(paramValue);
            } else {
                xmlHelper.setParam(paramName, paramValue);
            }

            xmlHelper.logRequest();

        } catch (RequestException e) {
            throw new PipelineRuntimeException("Failed to process request XML ", e);
        } catch (TransformerException e) {
            throw new PipelineRuntimeException("Failed to set request parameter '" + paramName + "'", e);
        } catch (Exception e) {
            throw new PipelineRuntimeException("Error while updating request parameter " + paramName + "'", e);
        }
    }
}
