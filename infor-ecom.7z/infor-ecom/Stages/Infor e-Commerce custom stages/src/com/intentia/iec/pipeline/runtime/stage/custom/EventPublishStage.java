package com.intentia.iec.pipeline.runtime.stage.custom;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Iterator;
import java.util.List;

import com.lawson.eventhub.EventData;
import com.lawson.eventhub.EventOperation;
import com.lawson.eventhub.publisher.Publisher;
import com.lawson.eventhub.publisher.PublisherConnectionException;
import com.lawson.eventhub.publisher.PublisherException;
import com.lawson.eventhub.util.logging.ILogger;
import com.lawson.eventhub.util.logging.SystemLogger;

public class EventPublishStage implements PipelineStage {

	/**
	**	EventPublishStage executes in the following conditions
	**	Movex connector is enabled
	**	ION connection and ION.Process Customer were enabled 
	**	ION connection and ION.Process Sales Order were enabled
	**
	**	params:
	**	tableName
	**/

    private static final Logger LOG = Logger.getLogger(EventPublishStage.class);

    private XMLRequest xmlRequest = null;
	
	private XMLResultset result = null;
	
	private Publisher publisher = null;
	
	private String PUBLISHER_NAME = null;
	
	public static String SERVER_ADRESS = null;
	
	public static int SERVER_PORT = Integer.MIN_VALUE;
	
	public static ILogger LOGGER = new SystemLogger(EventPublishStage.class.getName());
	
	private static Map<String, String> data = new HashMap<String, String>();
		
	private String tableName = null;
	
	private List attributes = null;
	
	private String Key = null;
	
	private SearchPipelineExecuter spe = null;
	
	private String currentOrderID = null;
		
	public void execute(PipelineContext context) throws PipelineRuntimeException {
        
		LOG.debug("Inside EventPublishStage.execute()");
		
		try {
			//@SuppressWarnings("unused")
			setup();
		} catch (PublisherConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (PublisherException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 

        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
        xmlRequest = (XMLRequest) context.getRequest();

        try {
            XMLRequest.extractRequestParameters(xmlRequest);
            
        } catch (RequestException e) {
            throw new PipelineRuntimeException("Error extracting request parameters!", e);
        }
        
        try {
        	if (xmlRequest.getParameters().getString("Method").equals("Asynchronous")) {
	        	LOG.debug("Submitting Order Method: " +xmlRequest.getParameters().getString("Method"));
	        	
	        	currentOrderID = xmlRequest.getParameters().getString("orderID");
	        	
	        	// Retrieving LogIn credentials in ApplicationData table.
	    		try {
	    			spe = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "PreviousOrder",
	    	                "GetSubmittedOrderIDForEventPublishStage");
	    	        
	    			spe.setParam("currentOrderID", currentOrderID);
	    		
	    		} catch (Exception e) {
	    			LOG.debug("Error Executing SearchPipelineExecuterStage For WebServiceUSerID in ApplicationData!", e);
	    		}
	        }
        } catch (Exception e) {
        	LOG.debug("Error Parsing parameters!", e);
        }
        
        // Movex connector not enabled => skip stage
		// ION not enabled => skip
		// ION.Process Customer not enabled => skip
		// ION.Process Sales Order not enabled => skip
        if (!"true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.CONNECTORENABLED)) && 
			(!"true".equals(CustomStagesHelper.getKeyValue("ION.Enabled")) &&
			((!"true".equals(CustomStagesHelper.getKeyValue("ION.Process Customer"))) || 
			!"true".equals(CustomStagesHelper.getKeyValue("ION.Process Sales Order"))))) {
			LOG.debug("EventPublishStage is not completed.");
			LOG.debug("Check Application Property to enable EventPublishStage");
			LOG.debug("Movex Connector: " +CustomStagesHelper.getKeyValue(ConstantsForSales.CONNECTORENABLED));
			LOG.debug("ION Enabled: " +CustomStagesHelper.getKeyValue("ION.Enabled"));
			LOG.debug("ION.Process Customer: " +CustomStagesHelper.getKeyValue("ION.Process Customer"));
			LOG.debug("ION.Process Sales Order: " +CustomStagesHelper.getKeyValue("ION.Process Sales Order"));
            return;
        }
        
		// XML manipulation
		try {
			tableName = xmlRequest.getParameters().getString("tableName");
			
			if (!xmlRequest.getParameters().getString("Method").equals("Asynchronous")) {
				result = (XMLResultset) context.getResponse(); 
				result.beforeFirst();
		        result.moveNext();
				attributes = result.getNames();
			} else {
				result = spe.execute();
				result.beforeFirst();
    			result.moveNext();
				attributes = result.getNames();
			}
			
			if (tableName.equals("ProcessCustomerPartyMaster")) {
				Key = "UserGroupID";
			} else {	
				Key = "SubmittedOrderID";
			}
			
			// clear Hashmap to eliminate redunduncy.
			data.clear();
			
			// iterate XML nodes
			Iterator iAttributes = attributes.iterator();
			while (iAttributes.hasNext()) {
				// saving parsed XML to Hashmap
				String attributeName = (String) iAttributes.next();
				String attributeValue = getAttributeValueFromResponse(attributeName, result);
				data.put(attributeName, attributeValue);
			}
		
		} catch (ResultsetException e) {
			LOG.debug("Failed manipulating Resultset");
		} catch (Exception e) {
			LOG.debug("Error extracting tableName param");
		}
		
		//publish Event method
		publish(Key, tableName, data, 'A');

        LOG.debug("Exiting EventPublishStage.execute()");
    }

    private void setup() throws PublisherConnectionException, PublisherException, IOException, IOException {
		
		LOG.debug("Initializing Publisher connection.");
		LOG.debug("Extracting MEC connection properties");
		// initialize Publisher
		try {
			// extracting MEC properties in ESA Application property
			PUBLISHER_NAME = CustomStagesHelper.getKeyValue("MEC.Publisher");
			SERVER_ADRESS = CustomStagesHelper.getKeyValue("MEC.Server");
			String port = CustomStagesHelper.getKeyValue("MEC.Port");
			SERVER_PORT = Integer.parseInt(port);
		} catch (NumberFormatException e1) {
			throw new NumberFormatException(e1.toString());
		} catch (Exception e) {
			LOG.debug("Error extracting MEC properties", e);
		}
		
		LOG.debug("PUBLISHER_NAME: " +PUBLISHER_NAME);
		LOG.debug("SERVER_ADRESS: " +SERVER_ADRESS);
		LOG.debug("SERVER_PORT: " +SERVER_PORT);

		//check if Publisher already initialized
		publisher = Publisher.getInstance(PUBLISHER_NAME);
		if (publisher == null) {
			// initiate the publisher
			publisher.initInstance(PUBLISHER_NAME, true, SERVER_ADRESS, SERVER_PORT, LOGGER);
		}
	}

	private void commonInfo(EventData eventData) {

		eventData.addElement("Company", "");
		eventData.addElement("UserId", "");
		eventData.addElement("LanguageCode", "");
		// etc etc

	}

	public void publish(String document, String tableName, Map<String, String> data, char operation) {
		
		LOG.debug("Inside EventPublishStage.publish() method");
		if (data.containsKey(document)) {
			
			publisher = Publisher.getInstance(PUBLISHER_NAME);
			if (publisher == null) {
				LOG.debug("PUBLISHER_NAME: " +PUBLISHER_NAME + " does not exist!");
				return;
			}

			// here we build the EventData and publish it
			// as an extra bonus we can use the column info
			// and only send columns that are defined in the xml
			
			switch (operation) {
			case 'A': {
				if (publisher.subscriptionExists(tableName, EventOperation.CREATE)) {
					
					EventData eventData = new EventData(tableName, EventOperation.CREATE);
					eventData.setPublisher(PUBLISHER_NAME);
					commonInfo(eventData);
					
					// building full load  to publish
					LOG.debug("Building EventData");
					Set<String> theColumns = data.keySet();
					for(String key : data.keySet()){
						if(theColumns.contains(key)){
							String dta = data.get(key);
							eventData.addElement(key, dta);
						}
					}
					
					LOG.debug("Publishing Eventdata");
					// Publish data
					publisher.postEvent(eventData);
					LOG.debug("EventData PUBLISHED!");
				} else {
					LOG.debug("EventHub subscription does not exist!");
					LOG.debug("Publishing details:");
					LOG.debug("Publisher: " +PUBLISHER_NAME);
					LOG.debug("Document name: " +tableName);
					LOG.debug("Operation: " +operation);
				}	
				break;
			}
			case 'U': {
				if (publisher.subscriptionExists(tableName, EventOperation.UPDATE)) {
				
					EventData eventData = new EventData(tableName, EventOperation.UPDATE);
					eventData.setPublisher(PUBLISHER_NAME);
					commonInfo(eventData);
					
					// building full load  to publish
					LOG.debug("Building EventData");
					Set<String> theColumns = data.keySet();
					for(String key : data.keySet()){
						if(theColumns.contains(key)){
							String dta = data.get(key);
							eventData.addElement(key, dta);
						}
					}
					
					LOG.debug("Publishing Eventdata");
					// Publish data
					publisher.postEvent(eventData);
					LOG.debug("EventData PUBLISHED!");
				} else {
					LOG.debug("EventHub subscription does not exist!");
					LOG.debug("Publishing details:");
					LOG.debug("Publisher: " +PUBLISHER_NAME);
					LOG.debug("Document name: " +tableName);
					LOG.debug("Operation: " +operation);
				}	

				break;
			}
			}
		}
		/*
		// close publisher
		try {
			closePublisher();
		} catch (PublisherException e) {
			LOG.debug("Failed closing Publisher");
		}*/
	}
	
	private void closePublisher() throws PublisherException {
		// close publisher
		if (publisher != null) {
			publisher.close();
		}
	}		
	
    private String getAttributeValueFromResponse(String attributeName, XMLResultset result) {
        LOG.debug("Inside EventPublishStage.getAttributeValueFromResponse");
        String attributeValue = null;
        try { 
            if ((result == null) || (result.isEmpty())) {
                return attributeValue;
            }
            
			attributeValue = result.getString(attributeName);
            LOG.debug(attributeName + ":" + attributeValue);
        } catch (ResultsetException e) {
            LOG.debug(attributeName + "is not in the response.");
        }      
        LOG.debug("Exiting EventPublishStage.getAttributeValuFromResponse");
        return attributeValue;
    }

}
