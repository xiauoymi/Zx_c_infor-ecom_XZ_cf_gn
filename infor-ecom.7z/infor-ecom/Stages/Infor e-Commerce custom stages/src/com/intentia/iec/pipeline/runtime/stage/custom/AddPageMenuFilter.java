/*
 * Created on 19-04-2007
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.sqlserver.runtime.jdbc.JDBCReader;
import com.intentia.iec.util.FastStringBuffer;
import com.intentia.iec.util.PropertyLoader;

/**
 * This custom stage is important for the feature: <b>Filters menues based on an
 * application property as well as Menu Ids depending on User Role</b>. The
 * custom stage reads the application properties from the generated file
 * "../&lt;appName&gt;.ear/config/application.properties" and uses that in a
 * query that returns a set of Menu Ids(based on value of application property
 * related to its corresponding page as well as based on feature elements. That
 * set of menus is used to create dynamic bindings based on menu ids to filter
 * the menues returned by the search stage being next in the method pipeline.
 * Note that the application.properties file just contains the <i>Application
 * Property Groups</i> values seen in the Design Center Application Properties
 * tabs.
 * 
 * The clause for application property is such that
 * <ol>
 * <li>Menues where the business object attribute 'Menu.PageAppProperty' has
 * the value of <code>NULL</code> are included in the result.</li>
 * <li>Menues where the value of the business object attribute
 * 'Menu.PageAppProperty' is an application property name and this application
 * property has the value of <code>true</code> are inluded in the result.</li>
 * </ol>
 * 
 * @author Arup Guha
 */
public class AddPageMenuFilter extends AbstractPipelineStage {
    private static final Logger LOG = Logger.getLogger(AddPageMenuFilter.class);

    private static final String REQUEST_START = "<?xml version='1.0' encoding='UTF-8'?><request><params><param name='@LanguageCode'>";

    private static final String REQUEST_MID = "</param><param name='@UserID'>";

    private static final String REQUEST_MID_ = "</param><param name='@RootInternalName'>";

    private static String appPropertyBinding = null;

    private static boolean initialized = false;

    public static void initializeBindings(PipelineContext context) throws PipelineRuntimeException {
        if (!initialized) {
            // If requestEnd is already initialized then there is no reason to
            // enter the synchronized (and performance consuming) block.
            synchronized (AddPageMenuFilter.class) {
                // check initialization again just in case
                if (appPropertyBinding == null) {
                    if (LOG.isDebugEnabled()) {
                        LOG.debug("Initializing menu bindings based on application properties.");
                    }

                    Properties props = PropertyLoader.loadProperties("/application.properties");
                    Iterator entries = props.entrySet().iterator();
                    StringBuffer appPropBinding = new StringBuffer();
                    while (entries.hasNext()) {
                        Map.Entry entry = (Map.Entry) entries.next();
                        if ("false".equals(entry.getValue())) {
                            appPropBinding.append("'" + entry.getKey().toString() + "', ");
                        }
                    }

                    appPropBinding.deleteCharAt(appPropBinding.lastIndexOf(","));

                    appPropertyBinding = appPropBinding.toString();

                    initialized = true;
                    if (LOG.isDebugEnabled()) {
                        LOG.debug("Finished initializing menu bindings.");
                    }
                }
            }
        }
    }

    public static String fetchResultSet(PipelineContext context) throws PipelineRuntimeException {
        Connection con = null;

        PreparedStatement stmt = null;

        XMLRequest request = getRequest(context);

        ResultSet rs = null;
        try {
            XMLRequest.extractRequestParameters(request);
            String userId = request.getParameters().getString("@UserID");
            String rootInternalName = request.getParameters().getString("@RootInternalName");

            String showOnlyB2CMenu = request.getParameters().getString("@ShowOnlyB2CMenu");

            String roleID = request.getParameters().getString("@RoleID");

            FastStringBuffer query = new FastStringBuffer();

            query
                    .append("SELECT DISTINCT [menu].[id] FROM [Menu] [menu] JOIN ( SELECT [main].[id] AS [Id], [main].[low] AS [Low], [main].[high] AS [High] FROM [Menu] [main] LEFT JOIN [Page] [page] ON [main].[pageId] = [page].[id] INNER JOIN [Menu] [parent] ON [main].[low] BETWEEN [parent].[low] AND [parent].[high] INNER JOIN [PageFeature] [pagefeature] ON [page].[id] = [pagefeature].[pageId]");

            // Add feature check only if the user is not Guest in B2C scenario
            if (!("true".equalsIgnoreCase(showOnlyB2CMenu) && "Guest".equalsIgnoreCase(roleID))) {
                query
                        .append("INNER JOIN [RoleFeature] [rolefeature] ON [pagefeature].[featureId] = [rolefeature].[featureId] INNER JOIN [UserRole] [userRole] ON [rolefeature].[roleId] = [userRole].[roleId] AND userRole.userId = ? ");
            }
            // If its B2C guest, fetch all the menus, a registered user would
            // see. Those will be the feature elements assigned to the role
            // GuestB2C
            else {
                query
                        .append("INNER JOIN [RoleFeature] [rolefeature] ON [pagefeature].[featureId] = [rolefeature].[featureId] INNER JOIN [Role] [role] ON [rolefeature].[roleId] = [role].[id] AND role.[key] = 'GuestB2C' ");
            }

            query.append("WHERE [parent].[internalName]=?");

            // Condition to fetch only B2C menus for Content links when method
            // parameter @ShowOnlyB2CMenu is true
            if ("true".equalsIgnoreCase(showOnlyB2CMenu)) {
                query.append(" AND [main].[isB2CMenu] = 'Y' ");
            }

            query
                    .append(" AND ([page].[appProperty] IS NULL OR [page].[appProperty] NOT IN (")
                    .append(appPropertyBinding)
                    .append(
                            "))) [parent] ON ([menu].[low] <=[parent].[Low] AND [menu].[high]>=[parent].[High]) AND [menu].[level]>0 ORDER BY [menu].[id] ASC");

            con = (Connection) CustomStagesHelper.getConnection("esales.cursor");

            if (LOG.isDebugEnabled()) {
                LOG.debug("SQL query = " + query.toString());
            }

            stmt = con.prepareStatement(query.toString());

            if (!("true".equalsIgnoreCase(showOnlyB2CMenu) && "Guest".equalsIgnoreCase(roleID))) {
                stmt.setString(1, userId);
                stmt.setString(2, rootInternalName);
            } else {
                stmt.setString(1, rootInternalName);
            }

            rs = stmt.executeQuery();

            JDBCReader reader = new JDBCReader(rs);
            XMLResultset result = reader.getContent();

            // From here the bindings for Id will be generated.
            FastStringBuffer end = new FastStringBuffer();
            end.append("</param></params><search>");

            end.append("<bindings operator='or'>");
            try {
                if (result.isEmpty()) {
                    end.append("<binding attribute='Id' operator='eq' value='");
                    end.append("0");
                    end.append("'/>");
                } else {
                    result.beforeFirst();
                    while (result.hasNext()) {
                        result.moveNext();
                        end.append("<binding attribute='Id' operator='eq' value='");
                        end.append(result.getString("id"));
                        end.append("'/>");
                    }
                }
            } catch (ResultsetException e) {
                throw new PipelineRuntimeException(e);
            } finally {
                CustomStagesHelper.close(con, stmt, rs);
            }

            end.append("</bindings></search>");
            end.append("</request>");

            return end.toString();

        } catch (RequestException e) {
            throw new PipelineRuntimeException(e);
        } catch (ParametersException e) {
            throw new PipelineRuntimeException(e);
        } catch (SQLException e) {
            throw new PipelineRuntimeException(e);
        }

    }

    public final void execute(final PipelineContext context) throws PipelineRuntimeException {
        initializeBindings(context);

        if (context.getRequest() == null) {
            if (LOG.isDebugEnabled()) {
                LOG.debug("Request not available. Ending stage execution!");
            }
            return;
        }

        try {
            XMLRequest request = getRequest(context);
            XMLRequest.extractRequestParameters(request);

            // Create new request containing the expected parameters and the
            // application property bindings
            FastStringBuffer buffer = new FastStringBuffer();
            buffer.append(REQUEST_START);
            buffer.append(request.getParameters().getString("@LanguageCode"));
            buffer.append(REQUEST_MID);
            buffer.append(request.getParameters().getString("@UserID"));
            buffer.append(REQUEST_MID_);
            buffer.append(request.getParameters().getString("@RootInternalName"));
            // use the staticly build request end including necessary bindings
            buffer.append(fetchResultSet(context));
            if (LOG.isDebugEnabled()) {
                LOG.debug("XMLRequest :" + buffer.toString());
            }
            XMLRequest createdRequest = new XMLRequest(buffer.toString());

            if (LOG.isDebugEnabled()) {
                FastStringBuffer debug = new FastStringBuffer("Replacing request: ");
                debug.append(request.getRequestString());
                debug.append(" with request: ");
                debug.append(createdRequest.getRequestString());
                LOG.debug(debug.toString());
            }

            context.setRequest(createdRequest);
        } catch (ParametersException e) {
            throw new PipelineRuntimeException(e);
        } catch (RequestException e) {
            throw new PipelineRuntimeException(e);
        }
    }
}
