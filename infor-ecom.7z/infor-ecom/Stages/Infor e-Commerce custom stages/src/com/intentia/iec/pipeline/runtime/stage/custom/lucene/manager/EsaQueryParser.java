package com.intentia.iec.pipeline.runtime.stage.custom.lucene.manager;

import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.Query;

import com.intentia.iec.pipeline.runtime.stage.custom.lucene.utils.IndexManagerUtil;

/**
 * 
 * @author 15062
 * 
 */
public class EsaQueryParser extends QueryParser {

    private IndexManager _indexManager = null;

    private String _localeCode = null;

    public EsaQueryParser(String field, IndexManager manager, String localeCode) {
        super(IndexManagerUtil.standardizeFieldName(field), manager.getAnalyzer());
        this._indexManager = manager;
        this._localeCode = localeCode;
    }

    @Override
    protected final Query getFieldQuery(String field, String queryText) throws ParseException {
        field = IndexManagerUtil.standardizeFieldName(field);
        queryText = IndexManagerUtil.standardizeFieldValue(field, queryText, _indexManager);
        field = localizeFieldName(field);
        return super.getFieldQuery(field, queryText);
    }

    @Override
    protected final Query getFieldQuery(String field, String queryText, int slop) throws ParseException {
        field = IndexManagerUtil.standardizeFieldName(field);
        queryText = IndexManagerUtil.standardizeFieldValue(field, queryText, _indexManager);
        field = localizeFieldName(field);
        return super.getFieldQuery(field, queryText, slop);
    }

    @Override
    protected final Query getPrefixQuery(String field, String termStr) throws ParseException {
        field = IndexManagerUtil.standardizeFieldName(field);
        termStr = IndexManagerUtil.standardizeFieldValue(field, termStr, _indexManager);
        field = localizeFieldName(field);
        return super.getPrefixQuery(field, termStr);
    }

    @Override
    protected final Query getRangeQuery(String field, String start, String end, boolean inclusive)
            throws ParseException {
        field = IndexManagerUtil.standardizeFieldName(field);
        start = IndexManagerUtil.standardizeFieldValue(field, start, _indexManager);
        end = IndexManagerUtil.standardizeFieldValue(field, end, _indexManager);
        field = localizeFieldName(field);
        return super.getRangeQuery(field, start, end, inclusive);
    }

    private String localizeFieldName(final String field) {
        if (_indexManager.isLocalizedField(field)) {
            return field + "_" + _localeCode;
        } else
            return field;
    }
}
