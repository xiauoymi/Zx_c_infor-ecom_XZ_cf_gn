package com.intentia.iec.pipeline.runtime.integration.ia.dao.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.epiphany.rpbean.RPManager;
import com.epiphany.rpbean.RPRequest;
import com.epiphany.rpbean.RPResponse;
import com.intentia.iec.pipeline.runtime.integration.ia.dao.IaDao;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaConnectionException;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaNotSupportedApiException;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.ia.model.IaCampaign;
import com.intentia.iec.pipeline.runtime.integration.ia.model.IaPromotion;
import com.intentia.iec.pipeline.runtime.integration.ia.model.IaRecommendation;
import com.intentia.iec.pipeline.runtime.integration.ia.utils.IaConfig;
import com.intentia.iec.pipeline.runtime.integration.ia.utils.IaConstants;
import com.intentia.iec.pipeline.runtime.integration.ia.utils.IaRPManagerClient;
import com.intentia.iec.pipeline.runtime.integration.ia.utils.IaConstants.AcceptanceLevel;

public class IaDaoRpImpl implements IaDao {

	private static final float DEFAULT_SCORE = 0f;  

	private static final Logger log = Logger.getLogger(IaDaoRpImpl.class);

	private static final String NOT_SUPPORTED_API_MSG = "Not supported by IA's RP API. Use IA's REST API instead.";

	private static final String COMM_EXTENDED_EVENT = "CommunicationExtended";

	private static final String COMM_ACCEPTED_EVENT = "CommunicationAccepted";

	private static final String COMM_ENDSESSION_EVENT = "EndSession";
	
	private RPManager manager = null;

	private String dataDelimiter = null;

	public IaDaoRpImpl() throws IaConnectionException {
		this.manager = IaRPManagerClient.getInstance().getRpManager();
		this.dataDelimiter = IaConfig.getInstance().getDataDelimiter();
	}

	public IaDaoRpImpl(RPManager manager) throws IaConnectionException {
		this.manager = manager;
		this.dataDelimiter = IaConfig.getInstance().getDataDelimiter();
	}

	@Override
	public List<IaCampaign> getCampaigns(String event,
			Map<String, String> params) throws IaRuntimeException {
		List<IaCampaign> results = new ArrayList<IaCampaign>();
		RPResponse response = invoke(event, params);
		if (response != null && response.getOfferCount() > 0) {
			for (int i = 0; i < response.getOfferCount(); i++) {
				IaCampaign campaign = new IaCampaign();
				campaign.setId(response.getAttributeValue(i, "eCommId"));
				campaign.setInternalName(response.getAttributeValue(i, "Name"));
				campaign.setScore(getScoreValue(response.getAttributeValue(i,
						"Likelihood")));
				// Add to result set
				results.add(campaign);
			}
			Collections.sort(results, IaCampaign.Comparator);
		}

		// For testing only
		// results = getDummyCampaigns();
		
		log.debug("getCampaigns() results =" + results);

		return results;
	}

	@Override
	public List<IaPromotion> getPromotions(String event,
			Map<String, String> params) throws IaRuntimeException {
		List<IaPromotion> results = new ArrayList<IaPromotion>();
		RPResponse response = invoke(event, params);
		if (response != null && response.getOfferCount() > 0) {
			for (int i = 0; i < response.getOfferCount(); i++) {
				IaPromotion promo = new IaPromotion();
				promo.setId(response.getAttributeValue(i, "eCommId"));
				promo.setInternalName(response.getAttributeValue(i, "Name"));
				promo.setScore(getScoreValue(response.getAttributeValue(i,
						"Likelihood")));
				// Add to result set
				results.add(promo);
			}
			Collections.sort(results, IaPromotion.Comparator);
		}
		
		log.debug("getPromotions() results =" + results);

		return results;
	}

	@Override
	public List<IaRecommendation> getRecommendations(String event,
			Map<String, String> params) throws IaRuntimeException {
		List<IaRecommendation> results = new ArrayList<IaRecommendation>();
		RPResponse response = invoke(event, params);
		if (response.getOfferCount() > 0) {
			for (int i = 0; i < response.getOfferCount(); i++) {
				String itemNumbersStr = response.getAttributeValue(i,
						"eCommItemNumbers");
				String itemScoreStr = response.getAttributeValue(i,
						"eCommItemScores");

				log.debug("eCommItemNumbers = " + itemNumbersStr);
				log.debug("eCommItemNumbers = " + itemScoreStr);

				if (itemNumbersStr != null && itemScoreStr != null) {
					String[] itemNumbersArr = StringUtils.split(itemNumbersStr,
							dataDelimiter);
					String[] itemScoreArr = StringUtils.split(itemScoreStr,
							dataDelimiter);
					int index = 0;
					for (String itemNumber : itemNumbersArr) {
						IaRecommendation recommendation = new IaRecommendation();
						recommendation.setItemNumber(itemNumber);
						if (index < itemScoreArr.length) {
							recommendation
									.setScore(getScoreValue(itemScoreArr[index]));
						}
						// Add to result set
						results.add(recommendation);
						index++;
					}
				}
			}
			Collections.sort(results, IaRecommendation.Comparator);
		}

		log.debug("getRecommendations() results =" + results);
		return results;
	}

	@Override
	public void addCampaign(IaCampaign campaign) throws IaRuntimeException {
		throw new IaRuntimeException(new IaNotSupportedApiException(
				NOT_SUPPORTED_API_MSG));
	}

	@Override
	public void addPromotion(IaPromotion promotion) throws IaRuntimeException {
		throw new IaRuntimeException(new IaNotSupportedApiException(
				NOT_SUPPORTED_API_MSG));
	}

	@Override
	public void refinePackage() throws IaRuntimeException {
		throw new IaRuntimeException(new IaNotSupportedApiException(
				NOT_SUPPORTED_API_MSG));
	}

	@Override
	public void deployPackage() throws IaRuntimeException {
		throw new IaRuntimeException(new IaNotSupportedApiException(
				NOT_SUPPORTED_API_MSG));
	}

	@Override
	public void extendCampaigns(String ids, Map<String, String> params)
			throws IaRuntimeException {
		updateCommLearning(COMM_EXTENDED_EVENT, "Campaign", ids, params);
	}

	@Override
	public void extendPromotions(String ids, Map<String, String> params)
			throws IaRuntimeException {
		updateCommLearning(COMM_EXTENDED_EVENT, "Promotion", ids, params);
	}
	
	@Override
	public void acceptCampaigns(String ids, AcceptanceLevel level, Map<String, String> params)
			throws IaRuntimeException {
		if (params == null) {
			params = new HashMap<String, String>();
		}
		params.put(IaConstants.EVENT_PARAM_ACCEPT_LEVEL, String.valueOf(level));
		updateCommLearning(COMM_ACCEPTED_EVENT, "Campaign", ids, params);
	}

	@Override
	public void acceptPromotions(String ids, AcceptanceLevel level, Map<String, String> params)
			throws IaRuntimeException {
		if (params == null) {
			params = new HashMap<String, String>();
		}
		params.put(IaConstants.EVENT_PARAM_ACCEPT_LEVEL, String.valueOf(level));
		updateCommLearning(COMM_ACCEPTED_EVENT, "Promotion", ids, params);
	}
	
	@Override
	public void deleteCampaign(IaCampaign campaign) throws IaRuntimeException {
		throw new IaRuntimeException(new IaNotSupportedApiException(
				NOT_SUPPORTED_API_MSG));
	}

	@Override
	public void deletePromotion(IaPromotion promotion)
			throws IaRuntimeException {
		throw new IaRuntimeException(new IaNotSupportedApiException(
				NOT_SUPPORTED_API_MSG));
	}

	private RPResponse invoke(String event, Map<String, String> params)
			throws IaRuntimeException {

		// Apply IA's data delimeter first (if needed)
		applyDataDelimiter(params);

		log.debug("Calling IA API [event:" + event + ", params: " + params
				+ "]...");
		RPRequest request = manager.newRequest(event);
		for (Map.Entry<String, String> param : params.entrySet()) {
			request.setData(param.getKey(), param.getValue());
		}
		RPResponse response = request.sendRequest();
		if (response != null && !response.isSuccess()) {
			throw new IaRuntimeException(
					"RPResponse is not successful.  \ncaused by: "
							+ response.getErrorMessage());
		}
		log.debug("Interaction Advisor API [event: " + event
				+ "] Response Count = " + response.getOfferCount());

		return response;
	}

	private void applyDataDelimiter(Map<String, String> params) {
		log.debug("IA default data delimeter = "
				+ IaConstants.DEF_DATA_DELIMITER);
		log.debug("IA config data delimeter = " + this.dataDelimiter);

		// If custom data delimiter is set
		if (!IaConstants.DEF_DATA_DELIMITER.equals(this.dataDelimiter)) {
			for (String value : params.values()) {
				if (value != null) {
					value.replaceAll(IaConstants.DEF_DATA_DELIMITER,
							this.dataDelimiter);
				}
			}
		}
	}

	@SuppressWarnings("unused")
	private float getIaScore(RPResponse response, int i) {
		try {
			return getScoreValue(response.getAttributeValue(i,
					"eCommItemScores"));
		} catch (NumberFormatException e) {
			log.error("Error while pasring Likelihood. Set default = "
					+ DEFAULT_SCORE);
			return DEFAULT_SCORE;
		}
	}

	private float getScoreValue(String score) {
		if (score != null) {
			try {
				return new Float(score);
			} catch (NumberFormatException e) {
				log.error("Error while pasring Likelihood. Set default = "
						+ DEFAULT_SCORE);
				return DEFAULT_SCORE;
			}
		} else {
			return DEFAULT_SCORE;
		}
	}

	private RPResponse updateCommLearning(String event, String type,
			String ids, Map<String, String> params) throws IaRuntimeException {
		if (params == null) {
			params = new HashMap<String, String>();
		}
		params.put("eCommIds", ids);
		params.put("TargetType", type);
		RPResponse response = invoke(event, params);
		log.debug("response.isSuccess = " + response.isSuccess());

		if (!response.isSuccess()) {
			throw new IaRuntimeException("Error while invoking '" + event + "["
					+ type + "]'.", new Throwable(
					"RPResponse.isSuccess() is false."));
		}
		return response;
	}

	@SuppressWarnings("unused")
	private List<IaCampaign> getDummyCampaigns() {
		List<IaCampaign> dummies = new ArrayList<IaCampaign>();

		IaCampaign campaign1 = new IaCampaign();
		campaign1.setInternalName("Tets 1");
		campaign1.setId("1");
		campaign1.setScore(3);
		dummies.add(campaign1);

		IaCampaign campaign2 = new IaCampaign();
		campaign2.setInternalName("Tets 2");
		campaign2.setId("2");
		campaign2.setScore(2);
		dummies.add(campaign2);

		IaCampaign campaign3 = new IaCampaign();
		campaign3.setInternalName("Tets 3");
		campaign3.setId("3");
		campaign3.setScore(1);
		dummies.add(campaign3);

		IaCampaign campaign4 = new IaCampaign();
		campaign4.setInternalName("Tets 4");
		campaign4.setId("4");
		campaign4.setScore(4);
		dummies.add(campaign4);

		Collections.sort(dummies, IaCampaign.Comparator);

		return dummies;
	}

	@Override
	public void endSession(String sessionId, String userId, String groupId)
			throws IaRuntimeException {
		
		HashMap<String, String> params = new HashMap<String, String>();
		
		String type = "Session";
		String event = COMM_ENDSESSION_EVENT;
		
		params.put("SessionId", sessionId);
		params.put("UserId", userId);
		params.put("GroupId", groupId);
		
		RPResponse response = invoke(event, params);
		
		log.debug("response.isSuccess = " + response.isSuccess());

		if (!response.isSuccess()) {
			throw new IaRuntimeException("Error while invoking '" + event + "["
					+ type + "]'.", new Throwable(
					"RPResponse.isSuccess() is false."));
		}	
	}
}
