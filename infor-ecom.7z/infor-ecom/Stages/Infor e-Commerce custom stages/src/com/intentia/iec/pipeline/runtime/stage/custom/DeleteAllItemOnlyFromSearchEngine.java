/*
 * Created on 22-11-2004
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import org.apache.log4j.Logger;

import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;

/**
 * This e-Sales custom stage is used to delete all item from google base server
 * and SearchEngineItem table only but not from base data table i.e. Item Table.
 * 
 * @author xinc0082(Mayur)
 */
public class DeleteAllItemOnlyFromSearchEngine extends AbstractPipelineStage {

    private static final Logger LOG = Logger.getLogger(DeleteAllItemOnlyFromSearchEngine.class);

    public DeleteAllItemOnlyFromSearchEngine() {
        super();
    }

    public final void execute(final PipelineContext context) throws PipelineRuntimeException {

        LOG.debug("Inside DeleteAllItemOnlyFromSearchEngine().execute()........");

        try {
            UploadItemToSearchEngine.deleteAllItemOnlyFromSearchEngine();
        } catch (Exception e1) {
            LOG.error("Error occured inside DeleteAllItemOnlyFromSearchEngine.execute() ,  ", e1);
        }
    }
}