/*
 * Created on 26-02-2004.
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.sqlserver.common.DatabaseType;
import com.intentia.iec.sqlserver.runtime.procedure.StageCallProcedure;
import com.intentia.iec.util.FastStringBuffer;

/**
 * <p>
 * This <code>DeleteConfigurationValues</code> stage ensures that any update
 * to a configuration is treated as an delete/insert instead of a regular
 * update. The stage simply calls a procedure to delete the existing
 * configuration values. Since the underlying application layer treats update
 * with no existing rows for the key as inserts, the delete will trigger an
 * insert instead of an update.
 * </p>
 * 
 * <p>
 * The reason for this behaviour is that, when changing the configuration the
 * new one may have fewer or more values than the old and therefore it is
 * necessary to use a delete/insert method to ensure data correctness and avoid
 * errors.
 * </p>
 * 
 * <p>
 * <b>Required input in <code>PipelineContext</code>:</b><br>
 * </p>
 * 
 * <p>
 * <b>Generated output in <code>PipelineContext</code>:</b><br>
 * </p>
 */

public final class DeleteConfigurationValues implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(DeleteConfigurationValues.class);

    private static final String VALUE = "value";

    private static final String VARCHAR = "varchar";

    private static final String SOURCE = "pipeline";

    private static final String PARAM_NAME = "@ConfigurationID";

    private static final String PARAM_FIELD = "ConfigurationID";

    private static final String CONFIGURATION_ID_XPATH = "/request/entities/entity/keys/key[@name='ConfigurationID']";

    private static final String NO_KEY_NAME_XPATH = "/request/entities/entity/keys/key[1]";

    private static final String EXECUTE_PROCEDURE = "EXEC DeleteConfigurationValues ?";

    private String configurationID = null;

    /**
     * <p>
     * Delete the existing configuration for a specific
     * <code>ConfigurationID</code>.
     * </p>
     * 
     * @throws PipelineRuntimeException
     *             if request is not of type <code>XMLRequest</code> or the
     *             method fails to obtain the request as a <code>Document</code>.
     * @see com.intentia.iec.pipeline.runtime.PipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
     */
    public void execute(PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("Attempting to delete configuration values before updating with new values!");

        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Request MUST be of type XMLRequest!");
        }
        XMLRequest xmlRequest = (XMLRequest) context.getRequest();

        Document xmlDoc;
        try {
            xmlDoc = xmlRequest.getRequestDoc();
        } catch (RequestException e) {
            throw new PipelineRuntimeException("Failed to get request document as XML", e);
        }

        // only perform the rest of the stage if a Configuration ID was found
        if (setConfigurationID(xmlDoc)) {
            callProcedure();
        }
    }

    /**
     * <p>
     * </p>
     * 
     * @param xmlDoc
     *            the request document.
     * @return true if a ConfigurationID was found and false if no ID was
     *         available
     * @throws PipelineRuntimeException
     *             if the method fails to extract the configuration ID
     */
    private boolean setConfigurationID(Document xmlDoc) throws PipelineRuntimeException {
        // extract configuration ID from request
        Node keyNode = null;
        try {
            keyNode = XPathAPI.selectSingleNode(xmlDoc, CONFIGURATION_ID_XPATH);
            if (keyNode == null) {
                keyNode = XPathAPI.selectSingleNode(xmlDoc, NO_KEY_NAME_XPATH);
                if (keyNode == null) {
                    FastStringBuffer msg = new FastStringBuffer();
                    msg.append("No configuration value ID found at either ");
                    msg.append(CONFIGURATION_ID_XPATH);
                    msg.append(" nor ");
                    msg.append(NO_KEY_NAME_XPATH);
                    msg.append(" in request - stage does nothing ...");
                    LOG.debug(msg.toString());
                    return false;
                }
            }
        } catch (TransformerException e1) {
            FastStringBuffer msg = new FastStringBuffer();
            msg.append("Failed to extract key value at either ");
            msg.append(CONFIGURATION_ID_XPATH);
            msg.append(" or ");
            msg.append(NO_KEY_NAME_XPATH);
            msg.append("  from request!");
            throw new PipelineRuntimeException(msg.toString(), e1);
        }
        // return value of configuration ID
        configurationID = keyNode.getAttributes().getNamedItem(VALUE).getNodeValue();
        return true;
    }

    /**
     * <p>
     * Method to execute the stored procedure
     * <code>TVFDeleteConfigurationValues</code>.
     * </p>
     * 
     * @throws PipelineRuntimeException
     * @see com.intentia.iec.sqlserver.runtime.procedure.StageCallProcedure
     */
    private void callProcedure() throws PipelineRuntimeException {

        StageCallProcedure procedure = new StageCallProcedure(EXECUTE_PROCEDURE);
        PipelineContext context = new PipelineContext();

        // setup procedure parameters
        int varcharType = DatabaseType.parseTypeName(VARCHAR);
        procedure.addInputParam(PARAM_NAME, 1, varcharType, SOURCE, PARAM_FIELD);

        // add parameters to context
        context.put(PARAM_FIELD, configurationID);

        // run procedure
        procedure.execute(context);
    }
}
