package com.intentia.iec.pipeline.runtime.stage.custom.promotion.takeaway;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

public class FreeItemImpl implements TakeAway {

	private static final Logger LOG = Logger.getLogger(FreeItemImpl.class);
	
	private static FreeItemImpl instance = null;
	
	private PromotionTakeAway promotionTakeAway = null;

	private List<String> promotionalItems = null;
	
	private Map<String, String> itemDetailsMap = null;
	
	protected FreeItemImpl() {
	      // Exists only to defeat instantiation.
	}
	public static FreeItemImpl getInstance() {
		if(instance == null) {
			instance = new FreeItemImpl();
		}
	return instance;
	}

	public void setPromotionalItems(List<String> promotionalItems) {
		this.promotionalItems = promotionalItems;
	}

	public void setItemParametersMap(Map<String, String> itemDetailsMap) {
		this.itemDetailsMap = itemDetailsMap;
	}
	/**
	 * @return the promotionTakeAway
	 */
	public PromotionTakeAway getPromotionTakeAway() {
		return promotionTakeAway;
	}
	/**
	 * @param promotionTakeAway the promotionTakeAway to set
	 */
	public void setPromotionTakeAway(PromotionTakeAway promotionTakeAway) {
		this.promotionTakeAway = promotionTakeAway;
	}
	
	/**
	 * Apply Header Level Promotion Take Away
	 */
	public void applyHeaderTakeaway(XMLResultset resultSet) {
		LOG.debug("Inside FreeItemImpl.applyHeaderTakeaway()");
		PromotionTakeAway takeAway = this.promotionTakeAway;
		String takeAwayField = takeAway.getField();
		String takeAwayOperator = takeAway.getOperator();
		if(TakeAwayConstant.ITEM_NUMBER.equals(takeAwayField)){
			this.applyFreeItemByItemNumber(resultSet);
		} else if(TakeAwayConstant.ITEMS_IN_PROMO.equals(takeAwayField)){
			this.applyFreeItemByItemsInPromo(resultSet);
		} 

	}
	
	/**
	 * Apply Line Level Promotion Take Away
	 */
	public void applyLineTakeAway(XMLResultset resultSet, XMLIterator xmlOrderline) {
		LOG.debug("Inside FreeItemImpl.applyLineTakeAway()");
		PromotionTakeAway takeAway = this.promotionTakeAway;
		String takeAwayField = takeAway.getField();
		if(TakeAwayConstant.ITEMS_IN_PROMO.equals(takeAwayField)){
			this.applyFreeItemByItemsInPromo(resultSet,xmlOrderline);
		}else if(TakeAwayConstant.ITEM_NUMBER.equals(takeAwayField)){
				this.applyFreeItemByItemNumber(resultSet);
		}
		
	}

	private void applyFreeItemByItemNumber(XMLResultset resultSet){
		LOG.debug("Inside FreeItemImpl.applyFreeItemByItemNumber()");
		PromotionTakeAway takeAway = this.promotionTakeAway;
		//Should be Quantity
		List<String> takeAwayValueList = takeAway.getValues();
		String extraParam = takeAway.getExtraParams();
		String freeItem = takeAwayValueList.get(0);
		if(extraParam == null || "".equals(extraParam)){
			extraParam = "1";
		}
		
		XMLIterator orderLine = null;
        try {
            orderLine = (XMLIterator) resultSet.getResultset(ConstantsForSales.ORDERLINE);
            if (orderLine == null){
            	orderLine = (XMLIterator) resultSet.appendResultset(ConstantsForSales.ORDERLINE);            	
            }
            
            //MOVE TO THE LAST LINE OF ORDERLINES AND APPEND A  NEW ROW
            orderLine.move(orderLine.rowCount());
            orderLine.appendRow();
            
            orderLine.appendField(TakeAwayConstant.REQ_IS_FREE_ITEM, "Y");
            Map<String, String> itemDetailsMap = this.getFreeItemDetails(freeItem);
            itemDetailsMap.put(ConstantsForSales.QUANTITY, extraParam);
            
            if(takeAway.getPromotionID() != null && !"".equals(takeAway.getPromotionID())){
            	itemDetailsMap.put(ConstantsForSales.PROMOTION_ID, takeAway.getPromotionID());            	
            } else {
            	itemDetailsMap.put(ConstantsForSales.PROMOTION_ID, "");
            }
            
            updateOrderLineAttributes(orderLine, itemDetailsMap);
            
        } catch (ResultsetException e) {
            LOG.debug("Error FreeItemImpl.applyFreeItemByItemNumber() "+e.getMessage());
        } catch (PipelineRuntimeException e) {
			LOG.debug("Error FreeItemImpl.applyFreeItemByItemNumber() "+e.getMessage());
		}
	}
	
	private void applyFreeItemByItemAssortment(){
		//not supported
		LOG.debug("Inside FreeItemImpl.applyFreeItemByItemAssortment()");
	}

	private void applyFreeItemByItemsInPromo(XMLResultset resultSet){
		LOG.debug("Inside FreeItemImpl.applyFreeItemByItemsInPromo()");
		PromotionTakeAway takeAway = this.promotionTakeAway;
		//Should be Quantity
		List<String> takeAwayValueList = takeAway.getValues();
		String extraParam = takeAway.getExtraParams();
        String freeItem = takeAwayValueList.get(0);
		if(extraParam == null || "".equals(extraParam)){
			extraParam = "1";
		}
		
		if(!this.promotionalItems.isEmpty() && this.promotionalItems.contains(freeItem)){
			XMLIterator orderLine = null;
			try {
				orderLine = (XMLIterator) resultSet.getResultset(ConstantsForSales.ORDERLINE);
				if (orderLine == null){
					orderLine = (XMLIterator) resultSet.appendResultset(ConstantsForSales.ORDERLINE);            	
				}
				
				//MOVE TO THE LAST LINE OF ORDERLINES AND APPEND A  NEW ROW
				orderLine.move(orderLine.rowCount());
				orderLine.appendRow();
				
				orderLine.appendField(TakeAwayConstant.REQ_IS_FREE_ITEM, "Y");
				Map<String, String> itemDetailsMap = this.getFreeItemDetails(freeItem);
				itemDetailsMap.put(ConstantsForSales.QUANTITY, extraParam);
				
				if(takeAway.getPromotionID() != null && !"".equals(takeAway.getPromotionID())){
					itemDetailsMap.put(ConstantsForSales.PROMOTION_ID, takeAway.getPromotionID());            	
				} else {
					itemDetailsMap.put(ConstantsForSales.PROMOTION_ID, "");
				}
				
				updateOrderLineAttributes(orderLine, itemDetailsMap);
				
			} catch (ResultsetException e) {
	            LOG.debug("Error FreeItemImpl.applyFreeItemByItemsInPromo() "+e.getMessage());
	        } catch (PipelineRuntimeException e) {
				LOG.debug("Error FreeItemImpl.applyFreeItemByItemsInPromo() "+e.getMessage());
			}			
		} else {
			LOG.debug("No Match for Takeaway Free Item in the Promotional Item");
		}
		
	}
	
	private void applyFreeItemByItemsInPromo(XMLResultset resultSet, XMLIterator xmlOrderline){
		LOG.debug("Inside FreeItemImpl.applyFreeItemByItemsInPromo()");
		PromotionTakeAway takeAway = this.promotionTakeAway;
		//Should be Quantity
		List<String> takeAwayValueList = takeAway.getValues();
		String freeItemQty = takeAwayValueList.get(0);
		String freeItem = "";
		try {
			freeItem = xmlOrderline.getString(TakeAwayConstant.REQ_ITEM_ID);
		} catch (ResultsetException e1) {
			e1.printStackTrace();
		}
		if(freeItemQty == null || "".equals(freeItemQty)){
			freeItemQty = "1";
		}
		
		try {
			
			xmlOrderline.appendRow();
            
			xmlOrderline.appendField(TakeAwayConstant.REQ_IS_FREE_ITEM, "Y");
            Map<String, String> itemDetailsMap = this.getFreeItemDetails(freeItem);
            itemDetailsMap.put(ConstantsForSales.QUANTITY, freeItemQty);
            
            if(takeAway.getPromotionID() != null && !"".equals(takeAway.getPromotionID())){
            	itemDetailsMap.put(ConstantsForSales.PROMOTION_ID, takeAway.getPromotionID());            	
            } else {
            	itemDetailsMap.put(ConstantsForSales.PROMOTION_ID, "");
            }
            
            updateOrderLineAttributes(xmlOrderline, itemDetailsMap);
            
        } catch (ResultsetException e) {
            LOG.debug("Error FreeItemImpl.applyFreeItemByItemsInPromo() "+e.getMessage());
        } catch (PipelineRuntimeException e) {
        	LOG.debug("Error FreeItemImpl.applyFreeItemByItemsInPromo() "+e.getMessage());
		} 
	}
	
	private Map<String, String> getFreeItemDetails(String itemNumber){
		LOG.debug("Inside FreeItemImpl.getFreeItemDetails()");
		Map<String, String> itemDetailsMap = new HashMap<String, String>();
		
		SearchPipelineExecuter pipeline = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                "Item", "DetailsBC");
    	pipeline.setParam(TakeAwayConstant.LANGUAGE_CODE_PARAM,
				this.itemDetailsMap.get(TakeAwayConstant.LANGUAGE_CODE_PARAM));
    	pipeline.setParam("ItemID0", itemNumber);
    	
    	try {
			XMLResultset itemDetails = pipeline.execute();
			
			if (itemDetails != null && !itemDetails.isEmpty()) {
				itemDetails.moveFirst();
				
//				REMOVE SKU ATTRIBUTE FREE ITEM IS CONSIDERED NORMAL ITEM 				
				itemDetailsMap.put(ConstantsForSales.ITEMID, itemDetails.getString(ConstantsForSales.ITEMID));
				itemDetailsMap.put(ConstantsForSales.ITEM_NAME, itemDetails.getString(ConstantsForSales.ITEMID));
				itemDetailsMap.put(ConstantsForSales.ITEM_DESCRIPTION, itemDetails.getString(ConstantsForSales.ITEMID));
				itemDetailsMap.put(ConstantsForSales.ITEMNUMBER, itemDetails.getString(ConstantsForSales.ITEMID));
				
				itemDetailsMap.put(ConstantsForSales.UNIT, itemDetails.getString(ConstantsForSales.UNIT));
				itemDetailsMap.put(ConstantsForSales.UNITCODE, itemDetails.getString(ConstantsForSales.UNITCODE));
				
				XMLIterator itemImageIterator = (XMLIterator)itemDetails.getResultset(ConstantsForSales.ITEM_IMAGES);
				String itemImageThumb = "";
				if (itemImageIterator != null && !itemImageIterator.isEmpty()) {
					itemImageIterator.beforeFirst();
					while (itemImageIterator.moveNext()) {
						itemImageIterator.getString(ConstantsForSales.ITEM_IMAGE_THUMB);
					}
				}
				itemDetailsMap.put(ConstantsForSales.ITEM_IMAGE_THUMB, itemImageThumb);
			}
			
		} catch (PipelineRuntimeException e) {
			e.printStackTrace();
		} catch (ResultsetException e) {
			e.printStackTrace();
		}
		
		
		return itemDetailsMap;
	}

    private void updateOrderLineAttributes(XMLIterator xmlOrderline, Map<String, String> itemDetails) throws PipelineRuntimeException, ResultsetException {
    	LOG.debug("Inside FreeItemImpl.updateOrderLineAttributes()");

    	updRsAttr(xmlOrderline, ConstantsForSales.ORDERLINEID, itemDetails.get(ConstantsForSales.ORDERLINEID) );
    	updRsAttr(xmlOrderline, ConstantsForSales.ITEMID, itemDetails.get(ConstantsForSales.ITEMID) );
    	updRsAttr(xmlOrderline, ConstantsForSales.ITEMNAME, itemDetails.get(ConstantsForSales.ITEMNAME) );
    	updRsAttr(xmlOrderline, "ItemNameEnglish", itemDetails.get(ConstantsForSales.ITEMNAME) );
    	updRsAttr(xmlOrderline, ConstantsForSales.ITEM_DESCRIPTION, itemDetails.get(ConstantsForSales.ITEM_DESCRIPTION) );
    	updRsAttr(xmlOrderline, ConstantsForSales.ITEM_IMAGE_THUMB, itemDetails.get(ConstantsForSales.ITEM_IMAGE_THUMB) );
    	updRsAttr(xmlOrderline, ConstantsForSales.QUANTITY, itemDetails.get(ConstantsForSales.QUANTITY) );
    	updRsAttr(xmlOrderline, ConstantsForSales.UNIT, itemDetails.get(ConstantsForSales.UNIT) );
    	updRsAttr(xmlOrderline, ConstantsForSales.UNITCODE, itemDetails.get(ConstantsForSales.UNITCODE) );
    	updRsAttr(xmlOrderline, ConstantsForSales.PROMOTION_ID, itemDetails.get(ConstantsForSales.PROMOTION_ID));

    	// ZERO VALUES
    	updRsAttr(xmlOrderline, ConstantsForSales.LINEPRICE, TakeAwayConstant.ZERO_BIG_DECIMAL_VALUE);
    	updRsAttr(xmlOrderline, ConstantsForSales.LISTPRICE, TakeAwayConstant.ZERO_BIG_DECIMAL_VALUE);
    	updRsAttr(xmlOrderline, ConstantsForSales.RESELLPRICE, TakeAwayConstant.ZERO_BIG_DECIMAL_VALUE);
    	updRsAttr(xmlOrderline, ConstantsForSales.LINEDISPERCENT, TakeAwayConstant.ZERO_BIG_DECIMAL_VALUE);
    	updRsAttr(xmlOrderline, ConstantsForSales.LINEDISCOUNT, TakeAwayConstant.ZERO_BIG_DECIMAL_VALUE);
    	updRsAttr(xmlOrderline, ConstantsForSales.LINETAX, TakeAwayConstant.ZERO_BIG_DECIMAL_VALUE);
    	updRsAttr(xmlOrderline, ConstantsForSales.LINETOTAL, TakeAwayConstant.ZERO_BIG_DECIMAL_VALUE);
    	updRsAttr(xmlOrderline, ConstantsForSales.ITEM_TAX, TakeAwayConstant.ZERO_BIG_DECIMAL_VALUE);
    	updRsAttr(xmlOrderline, ConstantsForSales.MODULAR_QTY, TakeAwayConstant.ZERO_BIG_DECIMAL_VALUE);
    	updRsAttr(xmlOrderline, ConstantsForSales.MINIMUM_QTY, TakeAwayConstant.ZERO_BIG_DECIMAL_VALUE);
    	updRsAttr(xmlOrderline, ConstantsForSales.IS_ACTIVE, "Y");
    	updRsAttr(xmlOrderline, ConstantsForSales.IS_VISIBLE, "Y");
    	updRsAttr(xmlOrderline, ConstantsForSales.ISLISTPRICE, "N");
    	updRsAttr(xmlOrderline, ConstantsForSales.USECID, "N");
    	updRsAttr(xmlOrderline, ConstantsForSales.ORDERLINESTATUS, "tmp");
    	updRsAttr(xmlOrderline, "LineShip", TakeAwayConstant.ZERO_BIG_DECIMAL_VALUE);
    	updRsAttr(xmlOrderline, "Item1_id_ConstraintGenerated", "");
    	updRsAttr(xmlOrderline, "ShippingAddress3", "");
    	updRsAttr(xmlOrderline, "ShippingAddress4", "");
    }
	
    
	private String updRsAttr(final XMLResultset rs, final String rsPar, final String value) {
        return CustomStagesHelper.updateRsAttribute(rs, rsPar, value);
    }
    
    private String updRsAttr(final XMLIterator rs, final String rsPar, final String value) {
        return CustomStagesHelper.updateRsAttribute(rs, rsPar, value);
    }
}
