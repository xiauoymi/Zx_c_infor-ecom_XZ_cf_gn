package com.intentia.iec.pipeline.runtime.stage.custom.lucene.search;

import org.apache.lucene.index.Term;
import org.apache.lucene.misc.ChainedFilter;
import org.apache.lucene.search.CachingWrapperFilter;
import org.apache.lucene.search.Filter;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.QueryWrapperFilter;
import org.apache.lucene.search.TermQuery;

import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;

public class LesUserGroupSearcherStage extends AbstractSearcherStage {

    private static final String INDEX_NAME = "LesUserGroup";

    private static final String KEY_ATTRIBUTE_NAME = ConstantsForSales.USERGROUPID;

    private static final String BO_NAME = "UserGroup";

    private static final String BO_METHOD_NAME = "LesSearch";

    protected String getIndexName() {
        return INDEX_NAME;
    }

    protected String getKeyAttributeName() {
        return KEY_ATTRIBUTE_NAME;
    }

    protected Filter createSearchFilters() throws PipelineRuntimeException {
        ChainedFilter filters = null;
        try {
            if (!"true".equalsIgnoreCase(_requestParameters.getString(ConstantsForSales.IS_MERCHANT_ADMIN_PARAM))) {

                String userGroup = _requestParameters.getString(ConstantsForSales.USER_GROUP_KEY_PARAM);
                Filter userGroupFilter = new CachingWrapperFilter(new QueryWrapperFilter(new TermQuery(new Term(
                        ConstantsForSales.USER_GROUP_KEY_FIELD, userGroup))));

                // TODO: Add more filters here (if needed)

                filters = new ChainedFilter(new Filter[] {userGroupFilter}, ChainedFilter.AND);
            }
        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Unable to define search security filter", e);
        }

        return filters;
    }

    protected XMLResultset getSearchResultDetails(Hits hits) throws PipelineRuntimeException {
        return querySearchResultDetails(hits, BO_NAME, BO_METHOD_NAME, KEY_ATTRIBUTE_NAME);
    }
}
