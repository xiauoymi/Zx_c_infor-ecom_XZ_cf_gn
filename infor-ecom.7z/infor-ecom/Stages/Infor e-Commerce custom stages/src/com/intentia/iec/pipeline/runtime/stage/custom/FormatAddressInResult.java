/*
 * Created on 08-03-2006
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

/**
 * <p>
 * The <code>FormatAddressInResult</code> stage formats one or more addresses
 * in the result. The stage is meant to be placed after a search stage.
 * </p>
 * 
 * <p>
 * <b>Required input in <code>PipelineContext</code>:</b><br>
 * Parameters:
 * <ul>
 * <li><code>prefix</code> (optional)</li>
 * </ul>
 * The parameter <code>prefix</code> tells what prefix the attribute names
 * have, e.g. <code>Shipping</code> means <code>ShippingCountryID</code>.
 * </p>
 * <p>
 * Attributes (mentioned without prefix):
 * <ul>
 * <li><code>CountryID</code></li>
 * <li><code>StateID</code></li>
 * <li><code>City</code></li>
 * <li><code>Zip</code></li>
 * <li><code>Address3</code></li>
 * <li><code>Address4</code></li>
 * </ul>
 * </p>
 * 
 * <p>
 * <b>Generated output in <code>PipelineContext</code>:</b><br>
 * When done the stage has added a value to the attributes:
 * <ul>
 * <li><code>Address3</code></li>
 * <li><code>Address4</code></li>
 * </ul>
 * </p>
 * 
 * <p>
 * The prefix does also apply here, so it can be <code>ShippingAddress3</code>
 * if <code>prefix</code> is <code>Shipping</code>.
 * </p>
 */
public class FormatAddressInResult implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(FormatAddressInResult.class);

    // Parameters extracted from request
    private String prefix;

    /**
     * <p>
     * The stage formats the address fields <code>Address3</code> and
     * <code>Address4</code>.
     * </p>
     * 
     * @throws PipelineRuntimeException
     *             if {conditions for throwing}
     * @see com.intentia.iec.pipeline.runtime.PipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
     */
    public void execute(PipelineContext context) throws PipelineRuntimeException {

        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Request MUST be of type XMLRequest!");
        }

        XMLRequest request = (XMLRequest) context.getRequest();
        if (!XMLRequestHelper.isSearchRequest(request)) {
            // The stage is only of use in an update request.
            LOG.debug("Not an search request - bail out!");
            return;
        }

        try {
            // Get parameters
            XMLRequest.extractRequestParameters(request);
            Parameters parameters = request.getParameters();
            prefix = n2E(parameters.getString(FormatAddress.PREFIX_PARAMETER));

            XMLResultset result = (XMLResultset) context.getResponse();
            if ((result == null) || (result.isEmpty())) {
                LOG.debug("The resultset is empty - bail out!");
                return;
            }

            // Make an instance of the formatter class so it can be reused in
            // the loop.
            FormatAddress formatter = new FormatAddress();

            // Loop the rows in the main set and format the address.
            result.beforeFirst();
            while (result.moveNext()) {
                formatAddress(result, formatter);
            }

            // Reset the position in the resultset so it is correct for the next
            // use.
            result.beforeFirst();

        } catch (final ResultsetException e) {
            final String msg = "Could not traverse the resultset.";
            LOG.error(msg, e);
            throw new PipelineRuntimeException(msg, e);
        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Failed to obtain a parameter from request", e);
        } catch (RequestException e) {
            throw new PipelineRuntimeException("Failed to operate on request", e);
        }
    }

    /**
     * Formats the address for a the current row in the given resultset.
     * 
     * @param result
     *            XMLResultset to operate on
     * @param formatter
     *            Address formatting class to use.
     * @throws PipelineRuntimeException
     */
    private void formatAddress(final XMLResultset result, final FormatAddress formatter)
            throws PipelineRuntimeException {

        String countryCode = n2E(getString(result, prefix + FormatAddress.COUNTRY_ATTRIBUTE));
        String stateCode = n2E(getString(result, prefix + FormatAddress.STATE_ATTRIBUTE));
        String city = n2E(getString(result, prefix + FormatAddress.CITY_ATTRIBUTE));
        String zip = n2E(getString(result, prefix + FormatAddress.ZIP_ATTRIBUTE));
        if (countryCode.length() == 0) {
            LOG.debug("Attribute for country code must be present in order to format an address!");
            return;
        }

        // Do the formatting
        formatter.format(countryCode, stateCode, city, zip);

        // Insert returned values as attributes in the main request.
        setString(result, prefix + FormatAddress.ADDRESS3_ATTRIBUTE, formatter.getAddress3());
        setString(result, prefix + FormatAddress.ADDRESS4_ATTRIBUTE, formatter.getAddress4());

        final String address4 = getString(result, prefix + FormatAddress.ADDRESS3_ATTRIBUTE);
        if (address4 == null) {
            return;
        }
    }

    /**
     * Get attribute value by name from resultset in context.
     * 
     * @param rs
     *            resultset including requested attribute
     * @param attributeName
     *            name of the requested attribute
     * @return the attribute value as a string - null if not found
     */
    private String getString(final XMLResultset rs, final String attributeName) {

        try {
            return (String) rs.getString(attributeName);
        } catch (ResultsetException e) {
            return null;
        }
    }

    /**
     * Set attribute value by name from resultset in context. If it fails to do
     * so it just logs the error.
     * 
     * @param rs
     *            resultset including requested attribute
     * @param attributeName
     *            name of the requested attribute
     * @param attributeValue
     *            value of the requested attribute
     */
    private void setString(final XMLResultset rs, final String attributeName, final String attributeValue) {

        try {
            rs.setString(attributeName, attributeValue);
        } catch (ResultsetException e) {
            LOG.debug("Failed to set attribute '" + attributeName + "' to '" + attributeValue + "'");
        }
    }

    /**
     * Ensure that the string is not null.
     * 
     * @param s
     *            String to check.
     * @return returns the string empty if string is null.
     */
    private String n2E(final String s) {

        if (s == null) {
            return "";
        } else {
            return s;
        }
    }
}
