package com.intentia.iec.pipeline.runtime.stage.custom.search;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Arrays;

import org.apache.log4j.Logger;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Filter;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.MatchAllDocsQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Sort;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;

public final class SearchUtils {
    private static final Logger LOG = Logger.getLogger(SearchUtils.class);

    // same as database initialization
    private static final int NUMERIC_PRECISION = 19;

    private static final int SCALE_PRECISION = 4;

    // for '.'
    private static final int SEPARATOR_LENGTH = 1;

    // for '.'
    public static final String PRICE_PREFIX = "p";

    private static final int PRICE_LENGTH = 1 + NUMERIC_PRECISION + SEPARATOR_LENGTH + SCALE_PRECISION;

    // %024.4f
    public static final String PRICE_FORMAT = PRICE_PREFIX + "%0" + PRICE_LENGTH + "." + SCALE_PRECISION + "f";

    public static final BigDecimal MIN_SEARCH_PRICE = new BigDecimal("0.0");

    public static final BigDecimal MAX_SEARCH_PRICE = new BigDecimal("9999999999999999999.9999");

    public CachedChainedFilter getStandardFilters(Database queries, Request request, DataHolder dataholder)
            throws PipelineRuntimeException {
        CachedChainedFilter filterChainCached = new CachedChainedFilter();

        String[] assortmentIds = queries.getAssortmentIdsForUser(request.getUserId(), request.getUserGroupId());
        if (assortmentIds.length > 0) {
            Arrays.sort(assortmentIds); // maximize cache hit rate
            CachedTermsFilter wrapper = new CachedTermsFilter();
            for (int i = 0; i < assortmentIds.length; i++) {
                wrapper.addTerm(new Term("assortmentId", assortmentIds[i]));
            }
            filterChainCached.add(wrapper);
        } else {
            return null;
        }

        if (dataholder.isWarehousingUsed()) {
            CachedTermsFilter wrapper = new CachedTermsFilter();
            wrapper.addTerm(new Term("warehouseId", request.getWarehouseId()));
            filterChainCached.add(wrapper);
        }

        return filterChainCached;
    }

    public Hits search(DataHolder dataholder, final Query q, final FilterBase cf, final Sort s)
            throws PipelineRuntimeException, BooleanQuery.TooManyClauses {
        Query query = q;
        if (query == null) {
            query = new MatchAllDocsQuery();
        }

        Filter filter = null;
        if (cf != null) {
            filter = cf.getFilter(dataholder);
        }

        Sort sort = s;
        if (sort == null) {
            sort = new Sort(); // Sort by relevance
        }

        try {
            long start = System.nanoTime();
            Hits hits = dataholder.getIndexSearcher().search(query, filter, sort);
            LOG.info("Number of hits: " + hits.length());
            LOG.info("Lucene search time in microseconds: " + (System.nanoTime() - start) / 1000L);
            return hits;
        } catch (IOException e) {
            LOG.error("Error executing Lucene search", e);
            throw new PipelineRuntimeException();
        }
    }

    /**
     * Creates a string with padded zeroes.
     * 
     * @param value
     * @return
     */
    public static String toPaddedString(BigDecimal value) {
        double d = value.doubleValue();
        String ret = toPaddedString(d);

        return ret;
    }

    /**
     * Creates a string with padded zeroes.
     * 
     * @param value
     * @return
     */
    public static String toPaddedString(double value) {
        String ret = String.format(PRICE_FORMAT, value);
        return ret;
    }

    /**
     * Creates a string with padded zeroes.
     * 
     * @param value
     * @return
     */
    public static BigDecimal toBigDecimal(String value) {
        BigDecimal ret = null;
        try {
            ret = new BigDecimal(value);
        } catch (Exception e) {
            ret = new BigDecimal(0);
        }

        return ret;
    }

    /**
     * Creates a string with padded zeroes.
     * 
     * @param value
     * @return
     */
    public static String toPaddedString(String value) {
        BigDecimal dec = toBigDecimal(value);
        String ret = toPaddedString(dec);

        return ret;
    }
}
