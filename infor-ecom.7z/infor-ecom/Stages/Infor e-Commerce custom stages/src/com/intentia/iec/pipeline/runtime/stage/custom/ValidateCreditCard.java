/*
 * Created on 17-03-2004
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.output.Resultset;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.connection.ConnectorException;
import com.intentia.iec.connection.IMovexApiResultset;
import com.intentia.iec.connection.IMovexConnection;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;

public final class ValidateCreditCard implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(SubmitOrderToMovex.class);

    // Internal variables
    private PipelineContext context = null;

    private Parameters requestParameters = null;

    private String mvxCompany = null;

    // Variables added as a part of Credit Card Payment Feature.

    private IMovexConnection movexCC = null;

    private String creditCardNumber = null;

    private String cardExpDate = null;

    /**
     * The stage entry point.
     * 
     * @see com.intentia.iec.pipeline.runtime.PipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
     */
    public void execute(final PipelineContext pipelineContext) throws PipelineRuntimeException {

        // Movex connector not enabled => skip stage
        if (!"true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.CONNECTORENABLED))) {
            return;
        }

        context = pipelineContext;

        int mvxStatus = -1010;

        try {
            // New movex connection for Credit Card API- CRCCINMI
            movexCC = (IMovexConnection) CustomStagesHelper.getConnection(ConstantsForSales.CRCCINMI);

            if (movexCC == null) {
                return;
            }

            // Extract the request parameters.
            CustomStagesHelper.extractRequestParameters(CustomStagesHelper.getRequest(context));
            requestParameters = CustomStagesHelper.getRequestParameters(context);

            XMLResultset resultSet = (XMLResultset) context.getResponse();
            if ((resultSet == null) || (!resultSet.moveFirst())) {
                LOG.debug("Aborting send order because there is no order");
                mvxStatus = -1008;
                return;
            }

            mvxCompany = resultSet.getString(ConstantsForSales.MVXCOMPANY);
            // Initialize these two varibales from request for credit card
            // validation.
            creditCardNumber = getRequestParameter(ConstantsForSales.CREDIT_CARD_NUMBER);
            cardExpDate = getRequestParameter(ConstantsForSales.CARD_EXPIRY_DATE);

            if (!getValidateInfo(resultSet)) {
                return;
            } else {
                mvxStatus = 1;
            }

        } catch (PipelineRuntimeException e) {

            if (movexCC == null) {
                // Assume that is was not possible to create a connection.
                LOG.error("Failed to connect to Movex", e);
            } else {
                // Otherwise throw the exception again.
                throw e;
            }
        } catch (ResultsetException e) {

            mvxStatus = -1011;
            LOG.error("Failed to open resultset", e);
        } finally {

            if (movexCC != null) {
                try {
                    movexCC.close();
                } catch (ConnectorException e) {
                    LOG.error("Failed to close the movexCC connection!");
                }
            }
            try {
                // set specific return code for Movex - see confirm
                CustomStagesHelper.getResponseParameters(context).setint(ConstantsForSales.MVXSTATUS, mvxStatus);
                // set common return code for execute
                CustomStagesHelper.getResponseParameters(context).setint(ConstantsForSales.STATUS,
                        mvxStatus >= 0 ? 0 : -100);

            } catch (ParametersException e) {
                LOG.error("Failed to set response parameters!");
            }
        }
    }

    private boolean getValidateInfo(final XMLResultset main) throws PipelineRuntimeException {

        /*
         * This method Validates a given credit card number against M3. Required
         * inputs are Card Number, Card Exp Date, MvxCompany, MvxDivision.
         */

        Map validate = new HashMap();
        validate.put(IMovexConnection.TRANSACTION, ConstantsForSales.GET_VALIDATE_INFO);
        validate.put(ConstantsForSales.CONO, mvxCompany);
        validate.put(ConstantsForSales.DIVI, getAttribute(ConstantsForSales.MVXDIVISION, main));
        validate.put(ConstantsForSales.CANU, creditCardNumber);
        validate.put(ConstantsForSales.EXP0, cardExpDate);

        IMovexApiResultset res = CustomStagesHelper.callMovex(context, movexCC, validate, ConstantsForSales.MVXSTATUS);
        if (res == null) {
            return false;
        }

        if (movexCC.isOk()) {
            return true;
        } else {
            LOG.error("Failed to validate the Credit Card: " + movexCC.getLastMessage());
            return false;
        }
    }

    private String getRequestParameter(final String parameterName) {

        String param = null;
        try {
            param = requestParameters.getString(parameterName);
        } catch (ParametersException e) {
            LOG.error("Missing parameter: " + parameterName);
        }
        if (param == null) {
            param = "";
        }
        return param;
    }

    private String getAttribute(final String name, final Resultset rs) {

        String attr = null;
        try {
            attr = rs.getString(name);
        } catch (ResultsetException e) {
            String msg = "Missing attribute: " + name;
            LOG.error(msg, e);
        }
        if (attr == null) {
            attr = "";
        }
        return attr;
    }

}
