package com.intentia.iec.pipeline.runtime.integration.erp.dao.factory;


import com.intentia.iec.pipeline.runtime.integration.erp.dao.ItemDao; 
import com.intentia.iec.pipeline.runtime.integration.erp.dao.OrderDao;
import com.intentia.iec.pipeline.runtime.integration.erp.exception.ErpConnectionException;
import org.apache.log4j.Logger;

public abstract class DaoFactory {
	
	private static final Logger LOG = Logger.getLogger(DaoFactory.class);
	public abstract ItemDao getItemDao() throws ErpConnectionException;
	public abstract OrderDao getOrderDao() throws ErpConnectionException;

	public enum IONConnector {
		Webservice;	
	}

	public static DaoFactory getDAOFactory() throws ErpConnectionException{	
		switch(getIONConnector()){
		case Webservice:
			return new WebserviceDaoFactory();
		default:
			return new WebserviceDaoFactory();
		}
	}

	public static IONConnector getIONConnector(){
	/*	String applicationDataERP = "";
		try{
			SearchPipelineExecuter spe = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "ApplicationData",	"Details");
			spe.setParam("param", "ION ERP");
			XMLResultset speResult = spe.execute();
			speResult.beforeFirst();
			while (speResult.moveNext()){
				if (speResult.getString("Parameter").equals("ION ERP")){
					applicationDataERP = speResult.getString("ParameterValue");
					break;
				}
			}
		} catch (Exception e) {
			LOG.debug("Error getIONConnector", e);
		}
	*/		
		return IONConnector.valueOf("Webservice");
	}

}
