package com.intentia.iec.pipeline.runtime.stage.custom.daf;

/**
 * DAF-related definitions.
 *
 */
public interface DafConstants {
	
	/**
	 * Output parameter containing the DAF status.
	 */
	public static final String DAFSTATUS = "dafStatus";
	
    /**
     * Possible error code values for DAF status.
     *
     */
    public interface ErrorCodes {
		/**
		 * Error in connection
		 */
		public static final int DAF_TRANSACTION_ERROR = -1;
		
		/**
		 * Error parsing the search query
		 */
		public static final int DAF_PARSE_ERROR = -2;
		
		/**
		 * Other exceptions generated during searching
		 */
		public static final int DAF_OTHER_ERROR = -3;
    	
		/**
		 * Item is checked out and cannot be edited
		 */
		public static final int ITEM_CHECKED_OUT = -4;
    	
		/**
		 * Item being updated is missing or has been deleted
		 */
		public static final int ITEM_NOT_FOUND = -5;
    }
}
