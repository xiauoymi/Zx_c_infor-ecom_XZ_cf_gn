package com.intentia.iec.pipeline.runtime.stage.custom.search.sps;

import static com.intentia.iec.pipeline.runtime.stage.custom.search.IndexerUtils.addIndexedField;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.lucene.document.Document;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.search.ItemIndexer;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc.RowHandler;

/**
 * 
 */
public class SPSItemIndexer extends ItemIndexer {

    protected static final Logger LOG = Logger.getLogger(SPSItemIndexer.class);

    /**
     * Copies parameters.
     * 
     * @param categoryPathById
     * @param jdbc
     */
    public SPSItemIndexer(Map<String, String> categoryPathById, Jdbc jdbc) {
        super(categoryPathById, jdbc);
        
        // currently, price search is disabled for spare parts
        // remove the following code if it will be enabled again
        this.includePrices = false;
    }

    /**
     * Copies parameters.
     * 
     * @param categoryPathById
     * @param jdbc
     * @param isStyleItemEnabled
     */
    public SPSItemIndexer(Map<String, String> categoryPathById, final Jdbc jdbc, boolean isStyleItemEnabled,
            boolean includePrices) {
        super(categoryPathById, jdbc, true, isStyleItemEnabled, includePrices);

        // currently, price search is disabled for spare parts
        // remove the following code if it will be enabled again
        this.includePrices = false;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.intentia.iec.pipeline.runtime.stage.custom.search.ItemIndexer#prepareStatements(java.sql.Connection)
     */
    protected void prepareStatements(final Connection con) throws PipelineRuntimeException {
        // use SPS specific SQL statement (index only parent items and spare
        // parts)
        String sqlItems = SPSStrings.Database.Indexing.Item.Items.sql;

        if (this.isStyleItemEnabled == false) {
            LOG.debug("Application.ItemListStyleItem set to False - will exclude all style items from Indexing operation");
            sqlItems = SPSStrings.Database.Indexing.Item.Items.sqlWithoutStyles;
        }

        // add parent item details
        List<String> sqlItemDetails = getItemDetailsSql();
        sqlItemDetails.add(SPSStrings.Database.Indexing.Item.SpareParts.sql);

        prepareStatements(con, sqlItems, sqlItemDetails);
    }

    /**
     * 
     * Implementation of RowHandler for indexing parent items of spare parts.
     * 
     */
    private class ParentItemsListHandler implements Jdbc.RowHandler {
        private Document doc = null;

        /**
         * @param doc
         */
        private ParentItemsListHandler(Document doc) {
            this.doc = doc;
        }

        /*
         * (non-Javadoc)
         * 
         * @see com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc.RowHandler#processRow(java.sql.ResultSet)
         */
        public void processRow(ResultSet rs) throws SQLException, PipelineRuntimeException {
            String parentItem = rs.getString(SPSStrings.Database.Indexing.Item.SpareParts.parentItem);
            addIndexedField(this.doc, SPSStrings.Index.Item.parentItem, parentItem);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.intentia.iec.pipeline.runtime.stage.custom.search.ItemIndexer#getParameters(java.lang.String)
     */
    protected List<Object> getParameters(String itemId) {
        // override ItemIndexer. add parameter for parent items
        List<Object> list = super.getParameters(itemId);

        // parent items
        list.add(itemId);
        list.add(itemId);

        return list;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.intentia.iec.pipeline.runtime.stage.custom.search.ItemIndexer#getRowHandlers(org.apache.lucene.document.Document,
     *      java.lang.String)
     */
    protected List<RowHandler> getRowHandlers(Document doc, String itemNumber) {
        // override ItemIndexer. add RowHandler for parent items
        List<Jdbc.RowHandler> list = super.getRowHandlers(doc, itemNumber);

        // parent items
        list.add(new ParentItemsListHandler(doc));

        return list;
    }

}
