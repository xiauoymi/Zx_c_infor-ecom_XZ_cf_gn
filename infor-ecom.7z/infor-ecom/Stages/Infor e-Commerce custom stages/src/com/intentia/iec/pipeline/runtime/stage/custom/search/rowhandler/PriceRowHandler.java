package com.intentia.iec.pipeline.runtime.stage.custom.search.rowhandler;

import static com.intentia.iec.pipeline.runtime.stage.custom.search.IndexerUtils.addIndexedField;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.lucene.document.Document;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc;
import com.intentia.iec.pipeline.runtime.stage.custom.search.SearchUtils;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Strings;

/** 
 * Add prices to the index. 
 */
public class PriceRowHandler implements Jdbc.RowHandler {
    private Document doc = null;

    public PriceRowHandler(Document doc) {
        this.doc = doc;
    }

    public void processRow(ResultSet rs) throws SQLException, PipelineRuntimeException {
        String listPriceGroupId = rs.getString(Strings.Database.Indexing.Item.Price.listPriceGroupId);
        String resellPriceGroupId = rs.getString(Strings.Database.Indexing.Item.Price.resellPriceGroupId);
        String customerId = rs.getString(Strings.Database.Indexing.Item.Price.customerId);
        String priceListPrice = rs.getString(Strings.Database.Indexing.Item.Price.priceListPrice);
        String netListPrice = rs.getString(Strings.Database.Indexing.Item.Price.netListPrice);
        String currencyCode = rs.getString(Strings.Database.Indexing.Item.Price.currencyCode);

        if (listPriceGroupId == null && resellPriceGroupId == null) {
            // for prices with customer prices but no list price/net price
            if (customerId != null && currencyCode != null) {
                // field is price_listprice_netprice_customerid_currency
                String field = Strings.Index.Item.pricePrefix + customerId + "_" + currencyCode;
                String value = SearchUtils.toPaddedString(netListPrice);
                addIndexedField(doc, field.toLowerCase(), value.toLowerCase());
            }
        } else {
            // for prices with list price/net price
            // field is price_listprice_netprice_currency
            String field = Strings.Index.Item.pricePrefix + listPriceGroupId + "_" + resellPriceGroupId + "_"
                    + currencyCode;
            String value = SearchUtils.toPaddedString(priceListPrice);
            addIndexedField(doc, field.toLowerCase(), value.toLowerCase());
            if (customerId != null && currencyCode != null) {
                // for prices with list price/net price and customer price
                // field is price_listprice_netprice_customerid_currency
                field = Strings.Index.Item.pricePrefix + listPriceGroupId + "_" + resellPriceGroupId + "_"
                        + customerId + "_" + currencyCode;
                value = SearchUtils.toPaddedString(netListPrice);
                addIndexedField(doc, field.toLowerCase(), value.toLowerCase());
            }
        }
    }
}