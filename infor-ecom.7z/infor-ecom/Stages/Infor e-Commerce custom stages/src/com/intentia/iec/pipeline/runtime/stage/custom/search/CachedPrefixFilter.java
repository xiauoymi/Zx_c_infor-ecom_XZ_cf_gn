package com.intentia.iec.pipeline.runtime.stage.custom.search;

import org.apache.lucene.index.Term;
import org.apache.lucene.search.Filter;
import org.apache.lucene.search.PrefixFilter;

/**
 * A simple wrapper around the Lucene PrefixFilter that allows the filter to be
 * stored in the filter cache.
 */
public final class CachedPrefixFilter extends FilterBase {
    private Term term;

    /**
     * Constructs a new object with the supplied term as the prefix.
     * 
     * @param term
     *            the prefix term
     */
    public CachedPrefixFilter(final Term term) {
        this.term = term;
    }

    public String createCacheKey() {
        return "PrefixFilter{" + term.field() + "=" + term.text() + "}";
    }

    public Filter createFilter(final DataHolder dataHolder) {
        return new PrefixFilter(term);
    }
}
