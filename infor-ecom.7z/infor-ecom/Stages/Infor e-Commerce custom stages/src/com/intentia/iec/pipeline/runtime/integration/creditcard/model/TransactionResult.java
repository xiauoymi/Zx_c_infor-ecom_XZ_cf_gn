package com.intentia.iec.pipeline.runtime.integration.creditcard.model;

import java.math.BigDecimal;

public class TransactionResult {

	private boolean isSuccessful;
	
	private BigDecimal requestedAmount;
	
	private BigDecimal actualAuthorizedAmount;
	
	private String authorizationNumber;
	
	private String referenceNumber;
	
	private CreditCard card;
	
	private String token;
	
	private BigDecimal amount;
	
	private String responseCode;
	
	private String responseMessage;

	/**
	 * @return the isSuccessful
	 */
	public boolean isSuccessful() {
		return isSuccessful;
	}

	/**
	 * @param isSuccessful the isSuccessful to set
	 */
	public void setSuccessful(boolean isSuccessful) {
		this.isSuccessful = isSuccessful;
	}

	/**
	 * @return the requestedAmount
	 */
	public BigDecimal getRequestedAmount() {
		return requestedAmount;
	}

	/**
	 * @param requestedAmount the requestedAmount to set
	 */
	public void setRequestedAmount(BigDecimal requestedAmount) {
		this.requestedAmount = requestedAmount;
	}

	/**
	 * @return the actualAuthorizedAmount
	 */
	public BigDecimal getActualAuthorizedAmount() {
		return actualAuthorizedAmount;
	}

	/**
	 * @param actualAuthorizedAmount the actualAuthorizedAmount to set
	 */
	public void setActualAuthorizedAmount(BigDecimal actualAuthorizedAmount) {
		this.actualAuthorizedAmount = actualAuthorizedAmount;
	}

	/**
	 * @return the authorizationNumber
	 */
	public String getAuthorizationNumber() {
		return authorizationNumber;
	}

	/**
	 * @param authorizationNumber the authorizationNumber to set
	 */
	public void setAuthorizationNumber(String authorizationNumber) {
		this.authorizationNumber = authorizationNumber;
	}

	/**
	 * @return the card
	 */
	public CreditCard getCard() {
		return card;
	}

	/**
	 * @param card the card to set
	 */
	public void setCard(CreditCard card) {
		this.card = card;
	}

	/**
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * @param token the token to set
	 */
	public void setToken(String token) {
		this.token = token;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	/**
	 * @return the amount
	 */
	public BigDecimal getAmount() {
		return amount;
	}

	/**
	 * @param amount the amount to set
	 */
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	/**
	 * @return the responseCode
	 */
	public String getResponseCode() {
		return responseCode;
	}

	/**
	 * @param responseCode the responseCode to set
	 */
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	/**
	 * @return the responseMessage
	 */
	public String getResponseMessage() {
		return responseMessage;
	}

	/**
	 * @param responseMessage the responseMessage to set
	 */
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
}
