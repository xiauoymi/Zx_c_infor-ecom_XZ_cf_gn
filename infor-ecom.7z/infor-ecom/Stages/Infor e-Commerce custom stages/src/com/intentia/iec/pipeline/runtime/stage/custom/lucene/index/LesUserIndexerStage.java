package com.intentia.iec.pipeline.runtime.stage.custom.lucene.index;

import java.util.Iterator;
import java.util.Map;

import org.apache.lucene.document.Document;

import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.lucene.manager.ResultsetDocumentHandler;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

/**
 * 
 * @author 15062
 * 
 */
public final class LesUserIndexerStage extends AbstractIndexerStage {

    private static final String INDEX_NAME = "LesUser";

    private static final String BO_NAME = "User";

    private static final String BO_METHOD_NAME = "GetUsersForLesUserIndex";

    private static final String KEY_ATTRIBUTE_NAME = ConstantsForSales.USER_ID_ATTRIBUTE;

    protected String getIndexName() {
        return INDEX_NAME;
    }

    protected String getKeyAttributeName() {
        return KEY_ATTRIBUTE_NAME;
    }

    protected String getBOName() {
        return BO_NAME;
    }

    protected String getBOMethodName() {
        return BO_METHOD_NAME;
    }

    protected void setAdditionalRequestParameters(SearchPipelineExecuter pipeline) {
        // TODO: Add parameters here (if needed)
    }

    protected void setAdditionalRequestBindings(SearchPipelineExecuter pipeline) {
        // TODO: Add bindings here (if needed)
    }

    protected void addMoreFields(Map<String, Document> docMap) throws PipelineRuntimeException {
        Iterator<String> it = docMap.keySet().iterator();
        while (it.hasNext()) {
            String key = it.next();
            Document doc = docMap.get(key);
            addLocalizedUserRoles(doc);
            addFavoriteAndWishListItems(doc);
            addRatedItems(doc);
        }
    }

    private void addLocalizedUserRoles(Document doc) throws PipelineRuntimeException {
        String[] roleIDs = doc.getValues(ConstantsForSales.ROLE_ID_FIELD);
        if (roleIDs != null && roleIDs.length > 0) {
            SearchPipelineExecuter pipeline = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "Role",
                    "GetDetailsForIndex", SearchPipelineExecuter.OR);
            for (int i = 0; i < roleIDs.length; i++) {
                pipeline.setBinding(ConstantsForSales.ROLE_ID_ATTRIBUTE, roleIDs[i], "eq");
            }
            XMLResultset rolesDetails = pipeline.execute();

            ResultsetDocumentHandler handler = new ResultsetDocumentHandler(doc, _indexManager, KEY_ATTRIBUTE_NAME);
            parseXMLResultset(rolesDetails, handler);
        }
    }

    private void addFavoriteAndWishListItems(Document doc) throws PipelineRuntimeException {
        String[] userID = doc.getValues(ConstantsForSales.KEY_FIELD);
        if (userID != null && userID.length > 0) {
            try {
                // Lookup all ItemList Codes
                SearchPipelineExecuter codeLookup = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                        "Code", "Lookup");
                codeLookup.setParam(ConstantsForSales.CODE_TYPE_PARAM, "ItemList");
                codeLookup.setParam(ConstantsForSales.LANGUAGE_CODE_SQL_PARAM, "en");
                XMLResultset codeDetails = codeLookup.execute();

                if (codeDetails != null && !codeDetails.isEmpty()) {
                    codeDetails.beforeFirst();
                    while (codeDetails.moveNext()) {
                        String codeID = codeDetails.getString(ConstantsForSales.ID_ATTRIBUTE);
                        String code = codeDetails.getString(ConstantsForSales.CODE_ATTRIBUTE);
                        SearchPipelineExecuter pipeline = new SearchPipelineExecuter(
                                ConstantsForSales.PIPELINE_PACKAGE, "FavoriteItem", "GetFavoriteItemsForLesUserIndex");
                        pipeline.setBinding(ConstantsForSales.CODE_ID_ATTRIBUTE, codeID, "eq");
                        pipeline.setBinding(ConstantsForSales.USER_ID_ATTRIBUTE, userID[0], "eq");
                        XMLResultset items = pipeline.execute();
                        ResultsetDocumentHandler handler = new ResultsetDocumentHandler(doc, _indexManager,
                                KEY_ATTRIBUTE_NAME);
                        handler.setObjectAlias(code);
                        parseXMLResultset(items, handler);
                    }
                }
            } catch (ResultsetException e) {
                throw new PipelineRuntimeException("Unable to lookup 'FavouriteItem' code id", e);
            }
        }
    }

    private void addRatedItems(Document doc) throws PipelineRuntimeException {
        String[] userID = doc.getValues(ConstantsForSales.KEY_FIELD);
        if (userID != null && userID.length > 0) {
            SearchPipelineExecuter pipeline = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                    "UserRating", "GetRatedItemsForLesUserIndex");
            pipeline.setBinding(ConstantsForSales.USER_ID_ATTRIBUTE, userID[0], "eq");
            XMLResultset reatedItems = pipeline.execute();

            ResultsetDocumentHandler handler = new ResultsetDocumentHandler(doc, _indexManager, KEY_ATTRIBUTE_NAME);
            parseXMLResultset(reatedItems, handler);
        }
    }
}