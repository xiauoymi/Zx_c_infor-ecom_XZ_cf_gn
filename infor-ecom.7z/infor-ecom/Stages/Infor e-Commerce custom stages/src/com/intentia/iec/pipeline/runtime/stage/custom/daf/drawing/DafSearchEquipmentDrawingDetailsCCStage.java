package com.intentia.iec.pipeline.runtime.stage.custom.daf.drawing;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.xml.sax.SAXException;

import com.intentia.icp.common.CMCollection;
import com.intentia.icp.common.CMCollections;
import com.intentia.icp.common.CMException;
import com.intentia.icp.common.CMItem;
import com.intentia.icp.common.CMItems;
import com.intentia.icp.common.SearchArgument;
import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage;

/**
 * Search for serialized Drawing details. Used in Customer Center Drawing Details page.
 *
 */
public class DafSearchEquipmentDrawingDetailsCCStage extends AbstractDafSearchStage {
	private static final Logger LOG = Logger.getLogger(DafSearchEquipmentDrawingDetailsCCStage.class);
	
	private String itemNumber = null;
	
	private String serialNumber = null;
	
	private static final String PARENTITEMNUMBER = "ParentItemNumber";
	
	private static final String PARENTSERIALNUMBER = "ParentSerialNumber";
	
	private static final String CHILDITEMNUMBER = "ChildItemNumber";
	
	private static final String CHILDSERIALNUMBER = "ChildSerialNumber";
	
	private static final String PARAM_ITEM_NUMBER = "@ItemNumber";
	
	private static final String PARAM_SERIAL_NUMBER = "@SERN";
	
	/**
	 * SQL statement that retrieves all as-built structure values from e-Sales database.
	 */
	private static final String SQL = 
		"select distinct p.itemNumber as ParentItemNumber, parent.serialNumber as ParentSerialNumber, c.itemNumber as ChildItemNumber, child.serialNumber as ChildSerialNumber " +
		"from AsBuiltStructure asb " +
		"inner join Equipment parent on asb.parentEquipmentId=parent.id " +
		"inner join Item p on parent.itemId=p.id " +
		"inner join Equipment child on asb.childEquipmentId=child.id " +
		"inner join Item c on child.itemId=c.id";

	/**
	 * Must have hot spots and sorted according to Is Default and creation date.
	 * This is different from MarkHasDrawingStage.WITH_HOTSPOTS
	 */
	private static final String WITH_HOTSPOTS = ") AND " + DafDrawingConstants.COLUMN_NAME + " IS NOT NULL AND " + DafDrawingConstants.COLUMN_DRAWING_NUMBER + " IS NOT NULL AND ESA_DrawingHotspots/@ESA_SerialNumber!=\"\" AND ESA_DrawingHotspots/@ESA_Coordinates IS NOT NULL AND ESA_DrawingHotspots/@ESA_ShapeCode IS NOT NULL AND ESA_DrawingHotspots/@ESA_ItemNumber IS NOT NULL AND " + DafDrawingConstants.COLUMN_STATUS + " = " + DafDrawingConstants.DAFStatusCodes.APPROVED + "] SORTBY(@ESA_DefaultDrawing DESCENDING, @CREATETS ASCENDING)";
	
	/**
	 * XQuery for retrieving drawings of equipment displayed in the Drawing Details page.
	 */
	private static final String SELECT_EQUIPMENT = DafDrawingConstants.TABLE + "[" + DafDrawingConstants.COLUMN_SERIAL_NUMBER + " IN (";	

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getQuery(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public String getQuery(PipelineContext context) throws ParametersException, ParserConfigurationException, SAXException, Exception {
		String ret = null;
		XMLRequest request = (XMLRequest)context.getRequest();
		Parameters params = request.getParameters();
		
		this.serialNumber = params.getString(PARAM_SERIAL_NUMBER);
		this.itemNumber = params.getString(PARAM_ITEM_NUMBER);
		
		// item number must be present
		if (this.itemNumber != null) {
			StringBuffer buf = new StringBuffer();

			appendQuery(buf, DafDrawingConstants.COLUMN_ITEM_NUMBER, SearchArgument.SEARCH_OP_EQUAL, this.itemNumber);
			appendQuery(buf, DafDrawingConstants.COLUMN_SERIAL_NUMBER, SearchArgument.SEARCH_OP_EQUAL, this.serialNumber);
			
			ret = DafDrawingConstants.TABLE + "[("+ buf.toString() + WITH_HOTSPOTS;
		}

		return ret;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getResultSize()
	 */
	@Override
	public int getResultSize() {
		return 0;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getStartIndex()
	 */
	@Override
	public int getStartIndex() {
		return 0;
	}
	
	/**
	 * Returns all visible as-built structure values from e-Sales database.
	 * @return
	 */
	private Map<Equipment, Set<Equipment>> getAsBuiltStructure() {
		Map<Equipment, Set<Equipment>> ret = new HashMap<Equipment, Set<Equipment>>();
		
		Connection conn = null; 
		PreparedStatement stmt = null;
		try {
			conn = (Connection) CustomStagesHelper.getConnection("esales.cursor");
			stmt = conn.prepareStatement(SQL);			
			
			LOG.debug("Executing SQL statement=" + SQL);

			long startTime = System.currentTimeMillis();
			ResultSet sqlResultSet = stmt.executeQuery();
			long stopTime = System.currentTimeMillis();
			LOG.debug("Total execution time: " + (stopTime - startTime) + " ms");			

			if (sqlResultSet != null) {
				while (sqlResultSet.next() == true) {
					// get parent, child
					String parentItemNumber = sqlResultSet.getString(PARENTITEMNUMBER);
					String parentSerialNumber = sqlResultSet.getString(PARENTSERIALNUMBER);
					String childItemNumber = sqlResultSet.getString(CHILDITEMNUMBER);
					String childSerialNumber = sqlResultSet.getString(CHILDSERIALNUMBER);
					
					Equipment parent = new Equipment(parentItemNumber, parentSerialNumber);
					
					// store product-child in Map
					if (parentItemNumber != null && parentSerialNumber != null
							&& childItemNumber != null && childSerialNumber != null) {
						// add parent if it does not exist
						if (ret.get(parent) == null) {
							ret.put(parent, new HashSet<Equipment>());
						}
						// add child to parent
						Set<Equipment> parentSet = ret.get(parent);
						
						Equipment child = new Equipment(childItemNumber, childSerialNumber);
						parentSet.add(child);
					}
				}
			}
			
		} catch (PipelineRuntimeException e) {
			LOG.error(e);
		} catch (SQLException e) {
			LOG.error(e);
		}
		finally {
			LOG.debug("Closing statement object");
			if (stmt != null) {
				try {
					stmt.close();
				}
				catch (SQLException e) {
					LOG.error(e);
				}
				stmt = null;
			}

			LOG.debug("Closing connection object");
			if (conn != null) {
				try {
					conn.close();
				}
				catch (SQLException e) {
					LOG.error(e);
				}
				conn = null;
			}
		}
		
		LOG.debug("Asbuilt structure for this user=" + ret.size());
		return ret;
	}
	
	/**
	 * Returns all Equipment in all Hot spots in all Drawings of the item displayed in the Drawing Details page.
	 * @param resultItems
	 * @return
	 */
	private Set<Equipment> getAllEquipmentInDrawingHotspots(CMItems resultItems) {
		Set<Equipment> ret = new HashSet<Equipment>();
		
		if (resultItems != null) {
			for (int i = 0; i < resultItems.size(); i++) {
				CMItem item = resultItems.get(i);
				
				// iterate through hot spots
				CMCollections collections = item.getCollections(DafDrawingConstants.ATTRIBUTE_HOTSPOTS);				
				if (collections != null && collections.size() > 0) {
					Iterator<?> it = collections.iterator();
					while (it.hasNext() == true) {
						CMCollection collection = (CMCollection) it.next();
						
						// validate hot spots
						if (DafDrawingUtils.isValidHotSpot(collection) == true) {
							// add to Set
							Equipment e = new Equipment((String) collection.getAttributeValue(DafDrawingConstants.ATTRIBUTE_ITEM_NUMBER),
									(String) collection.getAttributeValue(DafDrawingConstants.ATTRIBUTE_SERIAL_NUMBER));
							ret.add(e);
						}
					}
				}
				
			}
		}
		
		LOG.debug("Equipment in drawing hotspots=" + ret.size());
		return ret;
	}
	
	/**
	 * Get query string for searching Drawings of equipment in the hotspots
	 * @param equipmentInHotspots equipment in the drawing Hot spots
	 * @return
	 */
	private String getXQueryForDrillDownDrawings(Set<Equipment> equipmentInHotspots) {
		String ret = null;
		StringBuffer buf = new StringBuffer(SELECT_EQUIPMENT);		
		boolean first = true;
		
		if (equipmentInHotspots != null) {
			// iterate through equipment
			Iterator<Equipment> it = equipmentInHotspots.iterator();
			while (it.hasNext() == true) {
				Equipment equipment = it.next();
				if (first == false) {
					buf.append(",");
				}
				buf.append("\"" + escapeXQuery(equipment.getSerialNumber()) + "\"");
				first = false;
			}
			buf.append(WITH_HOTSPOTS);
			
			ret = buf.toString();
		} 
		
		return ret;
	}
	
	
	/**
	 * Search for Drawings of equipment in hot spots. The results are used for determining if drill-down is possible.
	 * @param itemNumbersInHotspots
	 * @return
	 */
	private CMItems getDrillDownDrawings(Set<Equipment> equipmentInHotspots) {
		// get query string
		String query = getXQueryForDrillDownDrawings(equipmentInHotspots);
		CMItems resultItems = null;

		if (query != null) {
			LOG.debug("Performing DAF Search(query=" + query +
					" startIndex=" + 0 +
					" resultSize=" + 0 +
					" retrieveOption=" + this.retrieveOption + ")");			
			try {
				long startTime = System.currentTimeMillis();
				resultItems = CMItems.search(this.connection, query, 0, 0, this.retrieveOption);
				long stopTime = System.currentTimeMillis();
				LOG.debug("Total search time: " + (stopTime - startTime) + " ms");
				LOG.debug("Number of drawings for drill-down=" + resultItems.size());
			} catch (CMException e) {
				LOG.error(e);
			}	
		}
		return resultItems ;		
	}
	
	/**
	 * Returns a map of valid Drawings. A Drawing is valid if it has valid hot spots. The items in the hot spots must also be valid as defined in the e-Sales database.
	 * @param resultItems
	 * @param visibleProductChild
	 * @param loadImage
	 * @return
	 */
	private Map<Equipment, List<Drawing>> createListOfValidDrawings(CMItems resultItems, Map<Equipment, Set<Equipment>> asbuiltStructure, boolean loadImage) {
		Map<Equipment, List<Drawing>> ret = new HashMap<Equipment, List<Drawing>>();
		
		if (resultItems != null) {
			for (int i = 0; i < resultItems.size(); i++) {
				CMItem item = resultItems.get(i);
				String id = item.getId();
				String name = (String) item.getAttributeValue(DafDrawingConstants.ATTRIBUTE_NAME);
				String drawingNumber = (String) item.getAttributeValue(DafDrawingConstants.ATTRIBUTE_DRAWING_NUMBER);
				String itemNumber = (String) item.getAttributeValue(DafDrawingConstants.ATTRIBUTE_ITEM_NUMBER);
				String serialNumber = (String) item.getAttributeValue(DafDrawingConstants.ATTRIBUTE_SERIAL_NUMBER);
				String isDefault = (String) DafDrawingUtils.convertDafIsDefault((Short) item.getAttributeValue(DafDrawingConstants.ATTRIBUTE_IS_DEFAULT));
				
				// check if item number is valid product
				Equipment e = new Equipment(itemNumber, serialNumber);
				
				if (asbuiltStructure.get(e) != null) {
					Set<Equipment> children = asbuiltStructure.get(e);					
					CMCollections collections = item.getCollections(DafDrawingConstants.ATTRIBUTE_HOTSPOTS);
					List<HotSpot> hotspots = new ArrayList<HotSpot>();					
					
					if (collections != null && collections.size() > 0) {
						Iterator<?> it = collections.iterator();
						while (it.hasNext() == true) {
							CMCollection collection = (CMCollection) it.next();
							// check if valid hot spot and item refers to valid child							
							Equipment c = new Equipment((String)collection.getAttributeValue(DafDrawingConstants.ATTRIBUTE_ITEM_NUMBER), (String)collection.getAttributeValue(DafDrawingConstants.ATTRIBUTE_SERIAL_NUMBER));
							
							if (DafDrawingUtils.isValidHotSpot(collection) == true 
									&& children.contains(c)) {
								HotSpot hs = new HotSpot();
								hs.setCoordinate((String) collection.getAttributeValue(DafDrawingConstants.ATTRIBUTE_COORDINATES));
								hs.setItemNumber((String) collection.getAttributeValue(DafDrawingConstants.ATTRIBUTE_ITEM_NUMBER));
								hs.setSerialNumber((String) collection.getAttributeValue(DafDrawingConstants.ATTRIBUTE_SERIAL_NUMBER));
								hs.setShapeCode(DafDrawingUtils.convertDafShapeCode((Short) collection.getAttributeValue(DafDrawingConstants.ATTRIBUTE_SHAPE_CODE)));
								hotspots.add(hs);
							}							
						}
					}
					
					// only add to valid Drawings list if there is a valid hot spot
					if (hotspots.isEmpty() == false) {
						// create a new Drawing object
						Drawing drawing = new Drawing(id, name, drawingNumber, itemNumber, serialNumber, isDefault);
						boolean addDrawing = true;
						if (loadImage == true) {
							try {
								long start = System.currentTimeMillis();
								item.retrieveResources(this.connection);
								long end = System.currentTimeMillis();
								LOG.debug("Total execution time for retrieveResources=" + (end-start));
								if (item.getResources() != null && item.getResources().getFirstNoneConversionResource() != null && item.getResources().getFirstNoneConversionResource().getUrl() != null) {
									drawing.setImageMaster(item.getResources().getFirstNoneConversionResource().getUrl().toString());
								}
								else {
									addDrawing = false;
								}
							} catch (CMException exc) {
								LOG.error(exc);
							}
						}
						
						if (addDrawing == true) {
							// add all valid hot spots to Drawing object
							drawing.addHotSpots(hotspots);
							
							// add Drawing object to List
							List<Drawing> list = ret.get(e);
							if (list == null) {
								list = new ArrayList<Drawing>();
								ret.put(e, list);
							}
							list.add(drawing);
						}
					}
				}
			}
		}
		
		LOG.debug("List of valid drawings=" + ret.size());
		return ret;
	}
	

	/**
	 * Check if the equipment has a drawing.
	 * @param itemNumber
	 * @param serialNumber
	 * @param drawings
	 * @return
	 */
	private boolean hasDrawing(String itemNumber, String serialNumber, Map<Equipment, List<Drawing>> drawings) {
		boolean ret = false;
		
		Equipment e = new Equipment(itemNumber, serialNumber);
		
		if (drawings.get(e) != null && drawings.get(e).size() > 0) {
			return true;
		}
		
		return ret;
	}
	
	/**
	 * Sets the Has Drawing attribute of the hot spots in level1.
	 * @param level1
	 * @param level2
	 */
	private void setHotSpotHasDrawing(Map<Equipment, List<Drawing>> level1, Map<Equipment, List<Drawing>> level2) {

		if (level1 != null && level2 != null) {
			// iterate through level1
			Iterator<Equipment> keys = level1.keySet().iterator();
			while (keys.hasNext() == true) {
				
				List<Drawing> listOfDrawings = level1.get(keys.next());
				
				// iterate through hot spots
				Iterator<Drawing> drawings = listOfDrawings.iterator();			
				while (drawings.hasNext() == true) {
					Drawing d = drawings.next();
					List<HotSpot> list = d.getHotSpots();

					for (int j = 0; j < list.size(); j++) {
						HotSpot s = list.get(j);
						
						// check if the hot spot Item Number has a drawing in level2
						if (hasDrawing(s.getItemNumber(), s.getSerialNumber(), level2) == true) {
							s.setHasDrawing(DafDrawingConstants.YES);
						}
					}					
				}
			}
		}
	}
	
	/**
	 * Creates a Map of valid Drawings for an equipment. The Has Drawing attribute is also set.
	 * @param firstLevelDrawings
	 * @param drillDownDrawings
	 * @param asbuiltStructure
	 * @return
	 */
	private Map<Equipment, List<Drawing>> createListOfValidDrawings(CMItems firstLevelDrawings, CMItems drillDownDrawings, Map<Equipment, Set<Equipment>> asbuiltStructure) {
		if (asbuiltStructure != null && asbuiltStructure.size() > 0) {
			long startTime = 0;
			long stopTime = 0;
			// create level1 and level2 Drawings List
			// level1 is Drawings of the current item displayed in the page
			// level2 is Drawings of all items of all hot spots of level1
			startTime = System.currentTimeMillis();
			Map<Equipment, List<Drawing>> level1 = createListOfValidDrawings(firstLevelDrawings, asbuiltStructure, true);
			stopTime = System.currentTimeMillis();
			LOG.debug("Total execution time for level 1=" + (stopTime - startTime) + " ms");
			
			startTime = System.currentTimeMillis();
			Map<Equipment, List<Drawing>> level2 = createListOfValidDrawings(drillDownDrawings, asbuiltStructure, false);
			stopTime = System.currentTimeMillis();
			LOG.debug("Total execution time for level 2=" + (stopTime - startTime) + " ms");

			// set the Has Drawing attribute to "Y"
			startTime = System.currentTimeMillis();
			setHotSpotHasDrawing(level1, level2);
			stopTime = System.currentTimeMillis();
			LOG.debug("Total execution time for creating result set=" + (stopTime - startTime) + " ms");
			
			return level1;
		}
		return null;
	}
	
	/**
	 * Creates an XMLResultset containing the Drawings for the item displayed on the page.
	 * @param validDrawings
	 * @return
	 */
	private XMLResultset createXMLResultset(Map<Equipment, List<Drawing>> validDrawings) {
		 StringBuilder buf = new StringBuilder("<?xml version='1.0' encoding='UTF-8'?>"
	                + "<resultset object='BlowUpPrint'>");
	        
        if (validDrawings != null) {
        	Iterator<Equipment> keys = validDrawings.keySet().iterator(); 

        	while (keys.hasNext() == true) {
        		List<Drawing> listOfDrawings = validDrawings.get(keys.next());
        		
        		for (int i = 0; i < listOfDrawings.size(); i++) {
               		buf.append("<row ");
        			Drawing drawing = listOfDrawings.get(i);
        			
        			// get Name
       				String name = drawing.getName();
       				buf.append(DafDrawingConstants.FIELD_NAME + "='" + encodeXML(name) + "' ");

        			// get PrintNumber
       				String printNumber = drawing.getDrawingNumber();
       				buf.append(DafDrawingConstants.FIELD_DRAWING_NUMBER + "='" + encodeXML(printNumber) + "' ");
        			
        			// get ItemNumber
        			String itemNumber = drawing.getItemNumber();
        			buf.append(DafDrawingConstants.FIELD_ITEM_NUMBER + "='" + encodeXML(itemNumber) + "' ");
        			
        			// get SerialNumber
        			String serialNumber = drawing.getSerialNumber();
        			buf.append(DafDrawingConstants.FIELD_SERIAL_NUMBER + "='" + encodeXML(serialNumber) + "' ");        			
        			
        			// get ID
       				buf.append(DafDrawingConstants.FIELD_ID + "='" + encodeXML(drawing.getId()) + "' ");
        			
        			// get isDefault
       				buf.append(DafDrawingConstants.FIELD_IS_DEFAULT + "='" + encodeXML(drawing.getIsDefaut()) + "' ");
        			
       				// get ImageMaster
       				buf.append(DafDrawingConstants.FIELD_IMAGE_MASTER + "='" + encodeXML(drawing.getImageMaster()) + "' ");
        			
       				// get hot spots
        			boolean hasCollection = false;
        			boolean first = true;
        			List<HotSpot> list = drawing.getHotSpots();

        			if (list != null) {
        				Iterator<HotSpot> it = list.iterator();

        				if (it != null) {
        					while (it.hasNext() == true) {
        						boolean hasWritten = false;
        						HotSpot hotSpot = it.next();

        						// coordinate
    							if (first == true) {
    								buf.append(">");    								
    								first = false;   								
    							}
    							if (hasWritten == false) {
    								buf.append("<ItemMap ");	
    								hasWritten = true;
    							}
    							hasCollection = true;

    							String coordinates = hotSpot.getCoordinate();    		    				
    		    				buf.append(DafDrawingConstants.FIELD_COORDINATE + "='" + encodeXML(coordinates) + "' ");
    		    				
    		    				// item number
      							if (first == true) {
    								buf.append(">");    								
    								first = false;   								
    							}
    							if (hasWritten == false) {
    								buf.append("<ItemMap ");	
    								hasWritten = true;
    							}
    							hasCollection = true;

    		    				buf.append(DafDrawingConstants.FIELD_ITEM_NUMBER + "='" + encodeXML(hotSpot.getItemNumber()) + "' ");
    		    				
    		    				buf.append(DafDrawingConstants.FIELD_SERIAL_NUMBER + "='" + encodeXML(hotSpot.getSerialNumber()) + "' ");
    		    				
    		    				buf.append(DafDrawingConstants.FIELD_SHAPE_CODE + "='" + encodeXML(hotSpot.getShapeCode()) + "' ");
    		    				
    		    				if (DafDrawingConstants.YES.equals(hotSpot.getHasDrawing()) == true) {
    		    					buf.append(DafDrawingConstants.FIELD_HAS_DRAWING + "='" + encodeXML(DafDrawingConstants.YES) + "' ");
    		    				}
    		    				else {
    		    					buf.append(DafDrawingConstants.FIELD_HAS_DRAWING + "='" + encodeXML(DafDrawingConstants.NO) + "' ");
    		    				}
        						
        						if (hasWritten == true) {
        							buf.append("/>");
        						}
            				}
        				}    							
        			}

        			if (hasCollection == false) {
        				buf.append("/>");	
        			}
        			else {
        				buf.append("</row>");
        			}
        		}
        	}
        }
		
        buf.append("</resultset>");
		return new XMLResultset(buf.toString());
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#processResult(com.intentia.icp.common.CMItems, int[])
	 */
	@Override
	public XMLResultset processResult(CMItems resultItems, int[] dafStatus)throws CMException, ParametersException {
		if (resultItems != null && resultItems.size() > 0) {
			LOG.debug("Number of drawings for equipment=" + resultItems.size());
			// test if equipment exists in esa db
			Map<Equipment, Set<Equipment>> asbuiltStructure = getAsBuiltStructure();
			String itemNumber = (String) resultItems.get(0).getAttributeValue(DafDrawingConstants.ATTRIBUTE_ITEM_NUMBER);
			String serialNumber = (String) resultItems.get(0).getAttributeValue(DafDrawingConstants.ATTRIBUTE_SERIAL_NUMBER);
			
			// means item exists in esa db
			Equipment e = new Equipment(itemNumber, serialNumber);
			if (asbuiltStructure.get(e) != null) {
				Set<Equipment> equipmentInHotspots = getAllEquipmentInDrawingHotspots(resultItems);
				if (equipmentInHotspots.size() > 0) {
					
					// get drill-down drawings
					CMItems drillDownDrawings = getDrillDownDrawings(equipmentInHotspots);
					Map<Equipment, List<Drawing>> validDrawings = createListOfValidDrawings(resultItems, drillDownDrawings, asbuiltStructure);					
					return createXMLResultset(validDrawings);
				}
			}
		}
		
		return getEmptyResultSet();
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#setOutputParameters(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public void setOutputParameters(PipelineContext context) throws PipelineRuntimeException {	
		// intentionally blank
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafStage#getAttributeToDafDatabaseField(java.lang.String)
	 */
	@Override
	public String getAttributeToDafDatabaseField(String attribute) {
		return null;
	}
	
	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#skipStage(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	public boolean skipStage(PipelineContext context) throws ParametersException, PipelineRuntimeException {
		if (!"true".equals(CustomStagesHelper.getKeyValue(DafDrawingConstants.ApplicationProperty.EQUIPMENT_PORTAL))) {
			return true;
		}

		XMLRequest request = (XMLRequest)context.getRequest();
		Parameters params = request.getParameters();
		String test = params.getString(PARAM_SERIAL_NUMBER);
		if (test == null || "".equals(test)) {
			LOG.debug(PARAM_SERIAL_NUMBER + " is NOT present, skipping stage.");
			return true;
		}
		
		return false;
	}
}
