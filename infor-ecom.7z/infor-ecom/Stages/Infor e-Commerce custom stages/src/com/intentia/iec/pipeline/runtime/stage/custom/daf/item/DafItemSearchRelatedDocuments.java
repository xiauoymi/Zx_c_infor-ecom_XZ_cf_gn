package com.intentia.iec.pipeline.runtime.stage.custom.daf.item;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import com.intentia.icp.common.CMCollection;
import com.intentia.icp.common.CMCollections;
import com.intentia.icp.common.CMException;
import com.intentia.icp.common.CMItem;
import com.intentia.icp.common.CMItems;
import com.intentia.icp.common.CMResource;
import com.intentia.icp.common.CMResources;
import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage;

/**
 * Class for retrieving all related documents from DAF.
 *
 */
public class DafItemSearchRelatedDocuments extends AbstractDafSearchStage {
	private static final String RELATEDDOCUMENT = "RelatedDocument";
	
	private static final Logger LOG = Logger.getLogger(DafItemSearchRelatedDocuments.class);

	private static final String ITEM_ID = "ItemID";

	private static final String PARAMETER_ITEM_ID = "@itemId";	
	
	private static final String SELECT_ITEMNUMBER = DafItemRelatedDocumentConstants.TABLE + "[" + DafItemRelatedDocumentConstants.Collection.ITEM_NUMBERS + "/" + DafItemRelatedDocumentConstants.Collection.ItemNumbers.Column.ITEM_NUMBER + "=";
	
	private static final String WHICH_IS_APPROVED = " AND " + DafItemRelatedDocumentConstants.Attribute.Column.STATUS + " = " + DafItemRelatedDocumentConstants.Status.APPROVED + "]";
	
	private static final String DOCUMENT_NAME = "DocumentName";
	
	private static final String FILE_NAME = "FileName";
	
	private static final String ICON = "Icon";
	
	private static final String MIME_TYPE = "MimeType";
	
	private static final String URL = "URL";
	
	private static final String BINDING_ITEM_ID = "request/search/bindings/bindings/binding";
	
	private static final String ATTRIBUTE = "attribute";
	
	private static final String VALUE = "value";
	
	private static final String DEFAULT_RESULTSET = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><resultset object=\"Item\"/>";
	
	private String itemNumber = null;
	
	/**
	 * Returns the generated query that will be fed to DB2
	 * @return
	 */
	private String getXQuery() {
		if (itemNumber == null) {
			return null;
		}
		else {
			StringBuffer buf = new StringBuffer(SELECT_ITEMNUMBER);
			buf.append("\"" + escapeXQuery(this.itemNumber) + "\"");			
			buf.append(WHICH_IS_APPROVED);
			
			return buf.toString();
		}
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getQuery(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public String getQuery(PipelineContext context) throws ParametersException, ParserConfigurationException, SAXException, Exception {
		XMLRequest request = (XMLRequest) context.getRequest();
		
		Parameters params = request.getParameters();
		this.itemNumber = params.getString(PARAMETER_ITEM_ID);
		
		if (this.itemNumber == null) {
			Document xmlDoc = request.getRequestDoc();
			Element binding = (Element)XPathAPI.selectSingleNode(xmlDoc, BINDING_ITEM_ID);
			
			if (binding != null && ITEM_ID.equals(binding.getAttribute(ATTRIBUTE)) == true) {
				this.itemNumber = binding.getAttribute(VALUE);
			}
		}
		
		return getXQuery();
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getResultSize()
	 */
	@Override
	public int getResultSize() {
		// return all documents
		return 0;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getStartIndex()
	 */
	@Override
	public int getStartIndex() {
		return 0;
	}
	
	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafStage#getEmptyResultSet()
	 */
	@Override
	public XMLResultset getEmptyResultSet() {
        return new XMLResultset(DEFAULT_RESULTSET);        
	}
	
	/**
	 * Retrieve the Document Name. The name is inside a collection.
	 * @param item
	 * @return
	 */
	private String getDocumentName(CMItem item) {
		if (item != null) {
			CMCollections collections = item.getCollections(DafItemRelatedDocumentConstants.Collection.DOCUMENT_NAME);

			if (collections != null) {
				for (int i = 0; i < collections.size(); i++) {
					CMCollection collection = collections.get(i);

					// return the first instance of the document name
					if (collection != null && collection.getAttributeValue(DafItemRelatedDocumentConstants.Collection.DocumentName.DOCUMENT_NAME) != null) {
						return collection.getAttributeValue(DafItemRelatedDocumentConstants.Collection.DocumentName.DOCUMENT_NAME).toString();	
					}
				}
			}
		}
		return null;
	}
	
	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#processResult(com.intentia.icp.common.CMItems, int[])
	 */
	@Override
	public XMLResultset processResult(CMItems resultItems, int[] dafStatus) throws CMException, ParametersException, ResultsetException {
		// create a new ResultSet
		XMLResultset rsItems = new XMLResultset(DEFAULT_RESULTSET);
		rsItems.moveNext();
		rsItems.appendRow();
		rsItems.appendField(ITEM_ID, this.itemNumber);

		if (resultItems != null && resultItems.size() > 0) {
			LOG.debug("Number of related documents for item=" + resultItems.size());

			for (int i = 0; i < resultItems.size(); i++) {
				CMItem item = resultItems.get(i);				
				String documentName = getDocumentName(item);

				if (documentName != null) {
					String url = null;
					String fileName = null;
					String icon = null;
					String mimeType = null;
					
					LOG.debug("Retrieving resource for item=" + item.getId());
					item.retrieveResources(this.connection);
					
					CMResources resources = item.getResources();
					if (resources != null) {
						// get url, icon and filename
						CMResource resource = resources.getFirstNoneConversionResource();
						if (resource != null && resource.getUrl() != null) {
							url = resource.getUrl().toString();
							fileName = resource.getOrgFileName();
							mimeType = resource.getMimeType();
							
							for (int j = 0; j < resources.size(); j++) {
								resource = resources.get(j);
								
								// use the preview image
								if (DafItemRelatedDocumentConstants.ImageType.PREVIEW.equals(resource.getAttributeValue(DafItemRelatedDocumentConstants.Resource.Attribute.IMAGE_TYPE)) == true) {
									icon = resource.getUrl().toString();
									break;
								}
							}
						}
					}

					// the attributes must be present
					if (mimeType != null && url != null && fileName != null) {
						XMLIterator rsRelatedDocuments = (XMLIterator)rsItems.appendResultset(RELATEDDOCUMENT);
						rsRelatedDocuments.appendRow();

						rsRelatedDocuments.appendField(DOCUMENT_NAME, documentName);
						rsRelatedDocuments.appendField(MIME_TYPE, mimeType);
						rsRelatedDocuments.appendField(URL, url);
						rsRelatedDocuments.appendField(FILE_NAME, fileName);
						
						// if icon/preview image is present
						if (icon != null) {
							rsRelatedDocuments.appendField(ICON, icon);
						}
					}
				}
			}
		}
		return rsItems;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#setOutputParameters(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public void setOutputParameters(PipelineContext context) throws PipelineRuntimeException {
		// intentionally blank
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafStage#getAttributeToDafDatabaseField(java.lang.String)
	 */
	@Override
	public String getAttributeToDafDatabaseField(String attribute) {
		return null;
	}	
}
