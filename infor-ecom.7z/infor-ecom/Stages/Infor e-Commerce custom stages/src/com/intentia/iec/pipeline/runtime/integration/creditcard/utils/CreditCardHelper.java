package com.intentia.iec.pipeline.runtime.integration.creditcard.utils;

import java.net.URL;

import javax.xml.ws.BindingProvider;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

public class CreditCardHelper {
	
	private static final Logger LOG = Logger.getLogger(CreditCardHelper.class);

	public static void setBindingProvider(BindingProvider bindingProvider, URL url){
		LOG.debug("setBindingProvider Endpoint: "+url.toString());
		bindingProvider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,url.toString());
	}
	
	public static boolean isCvvRequired() {
		String appDetailsCvvRequired = null;
		boolean isCvvRequired = false;
		try{
			SearchPipelineExecuter spe = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "ApplicationData",	"Details");
			spe.setParam("param", "CreditCardRequireCVV");
			XMLResultset speResult = spe.execute();
			speResult.beforeFirst();
			while(speResult.moveNext())
				appDetailsCvvRequired = speResult.getString("ParameterValue");
		} catch (Exception e) {
			LOG.debug("Error isCvvRequired()", e);
		}
		LOG.debug("app details is cvv required value: " + appDetailsCvvRequired);
		if (appDetailsCvvRequired != null && appDetailsCvvRequired.equals("true")) {
			isCvvRequired = true;
		}
		return isCvvRequired;
	}
	
}
