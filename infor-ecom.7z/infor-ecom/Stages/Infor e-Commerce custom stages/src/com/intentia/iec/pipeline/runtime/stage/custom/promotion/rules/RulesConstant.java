/**
 * 
 */
package com.intentia.iec.pipeline.runtime.stage.custom.promotion.rules;

/**
 * @author gsantiago
 *
 */
public final class RulesConstant {

	// RULE FIELDS
	public static final String ITEM_NUMBER = "itemNumber";
	
	public static final String ITEM_Assortment = "itemAssortment";
	
	public static final String ITEM_CATEGORY = "itemCategory";
	
	public static final String TOTAL_NUMBER_OF_ITEMS = "totalNumberOfItems";
	
	public static final String ORDER_TOTAL = "orderTotal";
	
	public static final String ITEMS_IN_PROMO = "itemsInPromo";
	
	public static final String PER_ITEMS_IN_PROMO = "perItemsInPromo";
	
	public static final String ANY_ITEMS_IN_PROMO = "anyItemsInPromo";
	
	public static final String CREDIT_CARD_TYPE = "creditCardType";
	
	public static final String METHOD = "method";
	
	public static final String COUNTRY = "country";
	
	public static final String STATE = "state";
	
	public static final String ZIP_CODE = "zipCode";
	
	// REQUEST FIELDS
	public static final String REQ_QUANTITY = "Quantity";
	
	public static final String REQ_GRAND_TOTAL = "TotalPrice";
	
	public static final String REQ_LINE_TOTAL = "LineTotal";
	
	public static final String REQ_ITEM_ID = "ItemID";
	
	public static final String REQ_ITEM_NUMBER = "ItemNumber";
	
	public static final String REQ_PAYMENT_METHOD_CODEID = "PaymentMethodCodeID";
	
	public static final String REQ_PAYMENT_METHOD_ID = "PaymentMethodID";
	
	// OPERATORS
	
	public static final String OPERATOR_CONTAINS = "Contains";
	
	public static final String OPERATOR_EQUAL = "=";
	
	public static final String OPERATOR_NOT_EQUAL = "!=";
	
	public static final String OPERATOR_GREATERTHAN = ">";
	
	public static final String OPERATOR_GREATERTHAN_EQUALTO  = ">=";
	
	public static final String OPERATOR_LESSTHAN = "<";
	
	public static final String OPERATOR_LESSTHAN_EQUALTO = "<=";

	public static final String BUY_ITEM_CONTAINS = "Contains";
	
	public static final String BUY_ITEM = "buyItem";
    
	public static final String AMOUNT = "amount";
    
	public static final String QUANTITY = "quantity";
    
	public static final String PAYMENT = "payment";
    
	public static final String SHIPPING_DETAILS = "shippingDetails";
	
	
	public static final String ZERO_BIG_DECIMAL_VALUE = "0.0000";
	
	public static final String EMPTY_VALUE = "";
	
}
