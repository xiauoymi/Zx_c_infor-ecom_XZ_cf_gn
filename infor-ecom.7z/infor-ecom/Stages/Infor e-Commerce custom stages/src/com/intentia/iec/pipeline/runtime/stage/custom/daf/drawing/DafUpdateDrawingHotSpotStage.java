package com.intentia.iec.pipeline.runtime.stage.custom.daf.drawing;

import java.io.StringReader;
import java.util.Iterator;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.log4j.Logger;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.intentia.icp.common.CMCollection;
import com.intentia.icp.common.CMException;
import com.intentia.icp.common.CMItem;
import com.intentia.icp.common.CMItems;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafUpdateStage;
import com.intentia.iec.pipeline.runtime.stage.custom.daf.DafConstants;

/**
 * Updates the Drawing hot spots on DAF.
 *
 */
public class DafUpdateDrawingHotSpotStage extends AbstractDafUpdateStage {
	private static final Logger LOG = Logger.getLogger(DafUpdateDrawingHotSpotStage.class);
	
	private DafDrawingRequestSaxHandler handler = null;	

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafUpdateStage#addNewItem()
	 */
	@Override
	public XMLResultset addNewItem() throws CMException, ResultsetException, ParametersException {
		// will never add new item since this is always an update
		return null;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafUpdateStage#getQuery()
	 */
	@Override
	public String getQuery() throws ParametersException, ParserConfigurationException, SAXException, Exception {
        if (this.handler.getKey() != null) {
        	return DafDrawingConstants.TABLE + "[" + DafDrawingConstants.COLUMN_ITEMID + " = \"" + this.handler.getKey() + "\"]";	
        }		

        return null;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafUpdateStage#getResultSize()
	 * expect only 1
	 */
	@Override
	public int getResultSize() {
		return 1;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafUpdateStage#getStartIndex()
	 */
	@Override
	public int getStartIndex() {
		return 0;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafUpdateStage#isKeyExists()
	 */
	@Override
	public boolean isKeyExists() {
		// this is always update
		return true;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafUpdateStage#parseRequest(com.intentia.iec.businessobject.input.XMLRequest)
	 */
	@Override
	public void parseRequest(XMLRequest request) throws Exception {
		try {
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser parser = factory.newSAXParser();
			
			this.handler = new DafDrawingRequestSaxHandler();
	        String xml = request.getRequestString();
	        LOG.debug("Parsing request:\n" + xml);
	        parser.parse(new InputSource(new StringReader(xml)), handler);	       
		}
		catch (Exception e) {
			throw e;
		}
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafUpdateStage#setOutputParameters(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public void setOutputParameters(PipelineContext context) throws PipelineRuntimeException {
		// intentionally blank
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafUpdateStage#updateItems(com.intentia.icp.common.CMItems, int[])
	 */
	@Override
	public XMLResultset updateItems(CMItems resultItems, int[] dafStatus) throws CMException {
		if (resultItems != null && resultItems.size() > 0) {
			CMItem item = resultItems.get(0);
			if (item.isCheckedOut() == false) {
				// can only update if item is not checked out
				LOG.debug("Checking out item=" + item.getId());
				item.checkOut(this.connection);

				// remove all existing hot spots
				item.clearCollections();
				
				// add all hot spots from page
				List<HotSpot> list = this.handler.getHotSpots();
				if (list != null) {
					Iterator<HotSpot> it = list.iterator();
					while (it.hasNext() == true) { 
						HotSpot hs = it.next();
						CMCollection cmCollection = new CMCollection();
						cmCollection.setEntityName(DafDrawingConstants.ATTRIBUTE_HOTSPOTS);
						cmCollection.setAttributeValue(DafDrawingConstants.ATTRIBUTE_COORDINATES, hs.getCoordinate());
						cmCollection.setAttributeValue(DafDrawingConstants.ATTRIBUTE_ITEM_NUMBER, hs.getItemNumber());
						cmCollection.setAttributeValue(DafDrawingConstants.ATTRIBUTE_SERIAL_NUMBER, hs.getSerialNumber());
						cmCollection.setAttributeValue(DafDrawingConstants.ATTRIBUTE_SHAPE_CODE, new Short(DafDrawingUtils.convertDafShapeCode(hs.getShapeCode())));
						item.addCollection(cmCollection);
					}
				}
				
				LOG.debug("Updating item=" + item.getId());
				item.update(this.connection);
				
				LOG.debug("Checking in item=" + item.getId());
				item.checkIn(this.connection);
			}
			else {
				LOG.debug("Cannot update item is checked out=" + item.getId());
				dafStatus[0] = DafConstants.ErrorCodes.ITEM_CHECKED_OUT;
			}
		}
		else {
			LOG.debug("Item not found");
			dafStatus[0] = DafConstants.ErrorCodes.ITEM_NOT_FOUND;
		}
		return getEmptyResultSet();
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafStage#getAttributeToDafDatabaseField(java.lang.String)
	 */
	@Override
	public String getAttributeToDafDatabaseField(String attribute) {
		return null;
	}
}
