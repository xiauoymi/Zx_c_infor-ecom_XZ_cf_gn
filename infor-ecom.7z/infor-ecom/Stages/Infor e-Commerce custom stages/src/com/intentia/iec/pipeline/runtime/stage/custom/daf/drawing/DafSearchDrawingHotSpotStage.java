package com.intentia.iec.pipeline.runtime.stage.custom.daf.drawing;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.xml.sax.SAXException;

import com.intentia.icp.common.SearchArgument;
import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;

/**
 * Searches all Drawing Hot spots in DAF.
 *
 */
public class DafSearchDrawingHotSpotStage extends AbstractDafSearchDrawingStage  {
	private static final Logger LOG = Logger.getLogger(DafSearchDrawingHotSpotStage.class);
	
	private static final String PARAMETER_ID = "@ID";
	
	 /**
	 * Sets the output attributes. 
	 */
	public DafSearchDrawingHotSpotStage() {
		 this.outDrawingNumber = true;
		 this.outItemNumber = true;
		 this.outName = true;
		 this.outID = true;
		 this.outImageMaster = true;
		 this.outHotSpots = true;
		 this.outIsCheckedOut = true;
		 
		 // if Equipment=enabled, output serial number
		 try {
			if ("true".equals(CustomStagesHelper.getKeyValue(DafDrawingConstants.ApplicationProperty.EQUIPMENT_PORTAL))) {
				 this.outSerialNumber = true;		 
			}
		} catch (PipelineRuntimeException e) {
			LOG.error(e);
		}			 
	 }

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getQuery(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public String getQuery(PipelineContext context) throws ParametersException, ParserConfigurationException, SAXException, Exception {
		XMLRequest request = (XMLRequest) context.getRequest();
		StringBuffer buf = new StringBuffer();
		
		Parameters params = request.getParameters();
		String id = params.getString(PARAMETER_ID);
		
		// search by @ITEMID
		appendQuery(buf, DafDrawingConstants.COLUMN_ITEMID, SearchArgument.SEARCH_OP_EQUAL, id);
		
		return DafDrawingConstants.TABLE + "["+ buf.toString() + "] ";	
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getResultSize()
	 * expect only 1
	 */
	@Override
	public int getResultSize() {
		return 1;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getStartIndex()
	 */
	@Override
	public int getStartIndex() {
		return 0;
	}

	@Override
	public void setOutputParameters(PipelineContext context) throws PipelineRuntimeException {	
		// intentionally blank
	}
}
