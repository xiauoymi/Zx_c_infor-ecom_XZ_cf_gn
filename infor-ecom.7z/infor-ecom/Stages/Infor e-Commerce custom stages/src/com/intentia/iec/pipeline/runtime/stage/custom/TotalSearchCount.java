package com.intentia.iec.pipeline.runtime.stage.custom;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.output.Resultset;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;

public class TotalSearchCount extends AbstractPipelineStage {
	private static final Logger logger = Logger.getLogger(TotalSearchCount.class);

	@Override
	public void execute(PipelineContext context)
			throws PipelineRuntimeException {
		logger.debug("Inside TotalItemCount.execute()");
		
		// Retrieve XML resultset from context
		XMLResultset resultset = getResponse(context);
		String totalSearchCount = "";
		try {
			totalSearchCount = getTotalSearchCount(resultset);
		} catch (ResultsetException ex) {
			throw new PipelineRuntimeException(ex);
		}
		
		CustomStagesHelper.setResponseParameter(context, "TotalSearchCount", totalSearchCount);
	}
	
	 private String getTotalSearchCount(Resultset resultset) throws ResultsetException {
		 String totalSearchCount = "";
		 if (resultset != null
				 && resultset.moveFirst()) {
			 totalSearchCount = resultset.getString("QUERY_RESULT_COUNT");
		 }
		 return totalSearchCount;
	 }
}