package com.intentia.iec.pipeline.runtime.stage.custom.search;

import java.io.StringReader;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.log4j.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;

// removed final so that SPS can inherit from this class
public class Request {
    private static final Logger LOG = Logger.getLogger(Request.class);

    // search field values (bindings)
    private String searchFullText; // "//binding[@attribute='FullText']/@value"

    private String searchName; // "//binding[@attribute='Name']/@value"

    private String searchNumber; // "//binding[@attribute='ItemID']/@value"

    private String searchCategory; // "//binding[@attribute='CategoryID']/@value"

    private String searchManufacturer; // "//binding[@attribute='ManufacturerID']/@value"

    // parameters
    private String currencyCode; // "//param[@name='@CurrencyCode']/text()"

    private String languageCode; // "//param[@name='@LanguageCode']/text()"

    private String warehouseId; // "//param[@name='@MvxWarehouse']/text()"

    private String shippingCountryCode; // "//param[@name='@ShippingCountryCode']/text()"

    private String userGroupId; // "//param[@name='@UserGroupID']/text()"

    private String userId; // "//param[@name='@UserID']/text()"

    private String listPriceGroupId; // "//param[@name='@ListPriceGroup']/text()"

    private String resellPriceGroupId; // "//param[@name='@ResellPriceGroup']/text()"

    private String parentCategoryKey; // "//param[@name='ParentCategoryID']/text()"

    // Additional parameters for version 13.1
    protected String searchRequestOrigin; // "//param[@name='@SearchRequestOrigin']/text()"

    private String quickSearchString; // "//param[@name='@QuickSearchString']/text()"

    private String itemNumber; // "//param[@name='@ItemNumber']/text()"

    private String itemName; // "//param[@name='@ItemNname']/text()"

    private String categoryKeySearch; // "//param[@name='@categoryKeySearch']/text()"

    private String manufacturerId; // "//param[@name='@ManufacturerID']/text()"

    private String brandId; // "//param[@name='@brandId']/text()"

    private String supplierId; // "//param[@name='@supplierId']/text()"	

    // paging attributes
    private String pagingOffset; // "//paging/@offset"

    private String pagingLimit; // "//paging/@limit"

    // sorting order attributes
    private String sortingField; // "//search/ordering/order/@attribute"

    private String sortingDirection; // "//search/ordering/order/@direction"

    private String customerItemID = null;

    // price search-related attributes
    private String minPrice = null;

    private String maxPrice = null;

    private String minNetListPrice = null;

    private String maxNetListPrice = null;

    private String alternateCurrencyCode = null;

    private String alternateExchangeRate = null;

    private String exchangeRate = null;

    private String executeIncludeTax = null;

    private String netListPriceNotNull = null;

    private String currencyDecimal = null;

    private boolean includeCustomerID = false;
	
	private String wildcardSearch = null;
	
	private String flagCampaign;

    /**
     * Extracts the parameters from the request. It is the combined set of all
     * parameter-like request values used in all search stages.
     * 
     * @param request
     *            The XML request document for input to the pipeline.
     * @throws PipelineRuntimeException
     *             if there is a problem parsing the request XML
     */
    public void parseRequest(final XMLRequest request) throws PipelineRuntimeException {
        try {
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser parser = factory.newSAXParser();

            DefaultHandler handler = new RequestSaxHandler();
            String xml = request.getRequestString();
            LOG.debug("Parsing request:\n" + xml);
            parser.parse(new InputSource(new StringReader(xml)), handler);
        } catch (Exception e) {
            LOG.error("Error extracting request info", e);
            throw new PipelineRuntimeException();
        }
    }

    public String getSearchFullText() {
        return searchFullText;
    }

    public String getSearchName() {
        return searchName;
    }

    public String getSearchNumber() {
        return searchNumber;
    }

    public String getSearchCategory() {
        return searchCategory;
    }

    public String getSearchManufacturer() {
        return searchManufacturer;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public String getLanguageCode() {
        return languageCode;
    }

    public String getWarehouseId() {
        return warehouseId;
    }

    public String getShippingCountryCode() {
        return shippingCountryCode;
    }

    public String getUserGroupId() {
        return userGroupId;
    }

    public String getUserId() {
        return userId;
    }

    public String getSortingField() {
        return sortingField;
    }

    public String getSortingDirection() {
        return sortingDirection;
    }

    public String getListPriceGroupId() {
        return listPriceGroupId;
    }

    public String getResellPriceGroupId() {
        return resellPriceGroupId;
    }

    public String getParentCategoryKey() {
        return parentCategoryKey;
    }

    public String getPagingOffset() {
        return pagingOffset;
    }

    public String getPagingLimit() {
        return pagingLimit;
    }

    public String getQuickSearchString() {
        return quickSearchString;
    }

    public String getSearchRequestOrigin() {
        return searchRequestOrigin;
    }

    public String getItemNumber() {
        return itemNumber;
    }

    public String getItemName() {
        return itemName;
    }

    public String getCategoryKeySearch() {
        return categoryKeySearch;
    }

    public String getManufacturerId() {
        return manufacturerId;
    }

    public String getBrandId() {
        return brandId;
    }

    public String getSupplierId() {
        return supplierId;
    }

    public String getCustomerItemID() {
        return customerItemID;
    }

    public boolean getIncludeCustomerItemID() {
        return includeCustomerID;
    }

    public String getMinPrice() {
        return this.minPrice;
    }

    public String getMaxPrice() {
        return this.maxPrice;
    }

    public String getMinNetListPrice() {
        return this.minNetListPrice;
    }

    public String getMaxNetListPrice() {
        return this.maxNetListPrice;
    }

    public String getAlternateCurrencyCode() {
        return this.alternateCurrencyCode;
    }

    public String getAlternateExchangeRate() {
        return this.alternateExchangeRate;
    }

    public String getExchangeRate() {
        return this.exchangeRate;
    }

    public String getExecuteIncludeTax() {
        return this.executeIncludeTax;
    }

    public String getNetListPriceNotNull() {
        return this.netListPriceNotNull;
    }

    public String getCurrencyDecimal() {
        return this.currencyDecimal;
    }

	public String getWildcardSearch() {  
		return this.wildcardSearch;
	}
	
	public String getFlagCampaign() {
		return flagCampaign;
	}	
	
    protected class RequestSaxHandler extends DefaultHandler {
        protected boolean inParam;

        protected String param;

        protected StringBuilder chars = new StringBuilder();

        public void startElement(final String uri, final String localName, final String qName,
                final Attributes attributes) throws SAXException {
            if (Strings.Request.Param.param.equals(qName)) {
                inParam = true;
                param = attributes.getValue(Strings.Request.Param.name);
            } else if (Strings.Request.Binding.binding.equals(qName)) {
                if (Strings.Request.Binding.fullText.equals(attributes.getValue(Strings.Request.Binding.attribute))) {
                    searchFullText = attributes.getValue(Strings.Request.Binding.value);
                } else if (Strings.Request.Binding.name.equals(attributes.getValue(Strings.Request.Binding.attribute))) {
                    searchName = attributes.getValue(Strings.Request.Binding.value);
                } else if (Strings.Request.Binding.itemId
                        .equals(attributes.getValue(Strings.Request.Binding.attribute))) {
                    searchNumber = attributes.getValue(Strings.Request.Binding.value);
                } else if (Strings.Request.Binding.categoryId.equals(attributes
                        .getValue(Strings.Request.Binding.attribute))) {
                    searchCategory = attributes.getValue(Strings.Request.Binding.value);
                } else if (Strings.Request.Binding.manufacturerId.equals(attributes
                        .getValue(Strings.Request.Binding.attribute))) {
                    searchManufacturer = attributes.getValue(Strings.Request.Binding.value);
                }
            } else if (Strings.Request.Paging.paging.equals(qName)) {
                pagingLimit = attributes.getValue(Strings.Request.Paging.limit);
                pagingOffset = attributes.getValue(Strings.Request.Paging.offset);
            } else if (Strings.Request.Order.order.equals(qName)) {
                sortingField = attributes.getValue(Strings.Request.Order.attribute);
                sortingDirection = attributes.getValue(Strings.Request.Order.direction);
            }
        }

        public void endElement(final String uri, final String localName, final String qName) throws SAXException {
            if (inParam) {
                if (Strings.Request.Param.currencyCode.equals(param)) {
                    currencyCode = chars.toString();
                } else if (Strings.Request.Param.languageCode.equals(param)) {
                    languageCode = chars.toString();
                } else if (Strings.Request.Param.mvxWarehouse.equals(param)) {
                    warehouseId = chars.toString();
                } else if (Strings.Request.Param.shippingCountryCode.equals(param)) {
                    shippingCountryCode = chars.toString();
                } else if (Strings.Request.Param.userGroupId.equals(param)) {
                    userGroupId = chars.toString();
                } else if (Strings.Request.Param.userId.equals(param)) {
                    userId = chars.toString();
                } else if (Strings.Request.Param.listPriceGroup.equals(param)) {
                    listPriceGroupId = chars.toString();
                } else if (Strings.Request.Param.resellPriceGroup.equals(param)) {
                    resellPriceGroupId = chars.toString();
                } else if (Strings.Request.Param.parentCategoryId.equals(param)) {
                    parentCategoryKey = chars.toString();
                } else if (Strings.Request.Param.fullText.equals(param)) {
                    searchFullText = chars.toString();
                } else if (Strings.Request.Param.searchRequestOrigin.equals(param)) {
                    String paramStr = chars.toString();
                    if (Strings.Request.SearchOrigin.B2C.equals(paramStr))
                        searchRequestOrigin = Strings.Request.SearchOrigin.B2C;
                    else if (Strings.Request.SearchOrigin.B2B_QUICKSEARCH.equals(paramStr))
                        searchRequestOrigin = Strings.Request.SearchOrigin.B2B_QUICKSEARCH;
                    else {
                        Manager manager = ManagerImpl.INSTANCE;
                        String applicationType = manager.getApplicationType();
                        if (applicationType.equals(Strings.Application.Type.b2c)) {
                            searchRequestOrigin = Strings.Request.SearchOrigin.B2C;
                        } else {
                            searchRequestOrigin = Strings.Request.SearchOrigin.B2B_FILTER;
                        }
                    }
                } else if (Strings.Request.Param.quickSearchString.equals(param)) {
                    quickSearchString = chars.toString();
                } else if (Strings.Request.Param.searchRequestOrigin.equals(param)) {
                    searchRequestOrigin = chars.toString();
                } else if (Strings.Request.Param.itemNumber.equals(param)) {
                    itemNumber = chars.toString();
                } else if (Strings.Request.Param.customerItemID.equals(param)) {
                    customerItemID = chars.toString();
                } else if (Strings.Request.Param.minPrice.equals(param)) {
                    minPrice = chars.toString();
                } else if (Strings.Request.Param.maxPrice.equals(param)) {
                    maxPrice = chars.toString();
                } else if (Strings.Request.Param.b2cMinPrice.equals(param)) {
                    minNetListPrice = chars.toString();
                } else if (Strings.Request.Param.b2cMaxPrice.equals(param)) {
                    maxNetListPrice = chars.toString();
                } else if (Strings.Request.Param.alternateCurrencyCode.equals(param)) {
                    alternateCurrencyCode = chars.toString();
                } else if (Strings.Request.Param.alternateExchangeRate.equals(param)) {
                    alternateExchangeRate = chars.toString();
                } else if (Strings.Request.Param.exchangeRate.equals(param)) {
                    exchangeRate = chars.toString();
                } else if (Strings.Request.Param.executeIncludeTax.equals(param)) {
                    executeIncludeTax = chars.toString();
                } else if (Strings.Request.Param.netListPriceNotNull.equals(param)) {
                    netListPriceNotNull = chars.toString();
                } else if (Strings.Request.Param.currencyDecimal.equals(param)) {
                    currencyDecimal = chars.toString();
                } else if (Strings.Request.Param.itemName.equals(param)) {
                    itemName = chars.toString();
                } else if (Strings.Request.Param.categoryKeySearch.equals(param)) {
                    categoryKeySearch = chars.toString();
                } else if (Strings.Request.Param.manufacturerId.equals(param)) {
                    manufacturerId = chars.toString();
                } else if (Strings.Request.Param.brandId.equals(param)) {
                    brandId = chars.toString();
                } else if (Strings.Request.Param.supplierId.equals(param)) {
                    supplierId = chars.toString();
                } else if (Strings.Request.Param.includeCustomerItemID.equals(param)) {
                    includeCustomerID = Boolean.valueOf(chars.toString());
                } else if (Strings.Request.Param.wildcardSearch.equals(param)) {
                	wildcardSearch = chars.toString();
                } else if (Strings.Request.Param.flagCampaign.equals(param)) {
					flagCampaign = chars.toString();
				}
                inParam = false;
                chars.setLength(0);
            }
        }

        public void characters(final char[] ch, final int start, final int length) throws SAXException {
            if (inParam) {
                chars.append(ch, start, length);
            }
        }
    }
}
