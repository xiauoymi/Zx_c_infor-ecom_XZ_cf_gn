package com.intentia.iec.pipeline.runtime.stage.custom.lucene.index;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.Term;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.ParserAdapter;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.custom.lucene.manager.IndexManager;
import com.intentia.iec.pipeline.runtime.stage.custom.lucene.manager.IndexManagerRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.lucene.manager.ResultsetDocumentHandler;
import com.intentia.iec.pipeline.runtime.stage.custom.lucene.utils.IndexLogUtil;
import com.intentia.iec.pipeline.runtime.stage.custom.lucene.utils.IndexManagerUtil;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

/**
 * 
 * @author 15062
 * 
 */
public abstract class AbstractIndexerStage extends AbstractPipelineStage {

    private static final Logger LOG = Logger.getLogger(AbstractIndexerStage.class);
    
    private static final int NUMBER_OF_LOGS_PER_BATCH = 2000;

    private String _indexName = null;

    private String _keyAttributeName = null;

    private String _boName = null;

    private String _boMethodName = null;

    private Set<String> _indexLogsToDelete = new HashSet<String>();

    protected IndexManager _indexManager = null;

    protected Parameters _requestParameters = null;

    protected abstract String getIndexName();

    protected abstract String getKeyAttributeName();

    protected abstract String getBOName();

    protected abstract String getBOMethodName();

    protected abstract void setAdditionalRequestParameters(SearchPipelineExecuter pipeline);

    protected abstract void setAdditionalRequestBindings(SearchPipelineExecuter pipeline);

    protected abstract void addMoreFields(Map<String, Document> docMap) throws PipelineRuntimeException;

    /**
     * 
     * @param context
     * @throws PipelineRuntimeException
     */
    public void execute(final PipelineContext context) throws PipelineRuntimeException {
        try {
            boolean rebuildIndex = false;

            if (!(context.getRequest() instanceof XMLRequest)) {
                throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
            }

            CustomStagesHelper.extractRequestParameters(CustomStagesHelper.getRequest(context));
            XMLRequest request = (XMLRequest) context.getRequest();
            _requestParameters = request.getParameters();

            if (_requestParameters.getString(ConstantsForSales.REBUILD_INDEX_PARAM) != null)
                rebuildIndex = Boolean
                        .parseBoolean(_requestParameters.getString(ConstantsForSales.REBUILD_INDEX_PARAM));

            LOG.debug("Updating index files...");
            updateIndex(rebuildIndex);

        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Unable to parse request parameters", e);
        }
    }

    /**
     * 
     * @param context
     * @throws PipelineRuntimeException
     */
    public void updateIndex(final boolean rebuildIndex) throws PipelineRuntimeException {
        boolean result = false;
        boolean hasModifications = true;
        String previousIndexStatus = null;
        try {
            _indexName = getIndexName();
            _keyAttributeName = getKeyAttributeName();
            _boName = getBOName();
            _boMethodName = getBOMethodName();

            if (_indexName != null) {
                _indexManager = IndexManager.getInstance(_indexName);
            } else {
                throw new PipelineRuntimeException("Index name is not define!");
            }

            if (_indexManager.getIndexStatus() == null
                    && ConstantsForSales.STATUS_CODE_FAILED.equals(IndexManagerUtil.getIndexCurrentStatus(_indexName))) {
                _indexManager.setIndexStatus(ConstantsForSales.STATUS_CODE_FAILED, true);
            }

            if (!ConstantsForSales.STATUS_CODE_UPDATING.equals(_indexManager.getIndexStatus())
                    && !ConstantsForSales.STATUS_CODE_REBUILDING.equals(_indexManager.getIndexStatus())) {

                if (rebuildIndex) {
                    LOG.debug("Empty index logs before rebuilding index files.");
                    IndexLogUtil.deleteLogsByIndexName(_indexName);
                }

                previousIndexStatus = _indexManager.getIndexStatus();
                Map<String, Document> docsToIndex = createDocumentsToIndex(rebuildIndex);

                if (docsToIndex != null && !docsToIndex.isEmpty()) {
                    if (rebuildIndex)
                        result = _indexManager.rebuildIndex(docsToIndex);
                    else
                        result = _indexManager.updateIndex(docsToIndex);
                } else {
                    LOG.info("No documents to index.");
                    result = true;
                    hasModifications = false;
                }

                if (!rebuildIndex && result) {
                    // Cleanup index file
                    Term[] keyTermsToDelete = createKeyTermsToDelete();
                    if (keyTermsToDelete != null && keyTermsToDelete.length > 0) {
                        result = _indexManager.cleanupIndex(keyTermsToDelete);
                    } else if (!hasModifications) {
                        hasModifications = false;
                    }

                    if (_indexLogsToDelete != null && !_indexLogsToDelete.isEmpty()) {
                        LOG.info("Deleting processed index logs of '" + _indexName + "'...");
                        IndexLogUtil.deleteLogsByID(_indexLogsToDelete);
                        _indexLogsToDelete.clear();
                    }
                }
            } else {
                hasModifications = false;
                LOG.info("Cannot modify index '" + _indexName
                        + "' at the moment. An existing index update process is still ongoing.");
            }
        } catch (IndexManagerRuntimeException e) {
            result = false;
            throw new PipelineRuntimeException("Unable to update index " + _indexName, e);
        } catch (PipelineRuntimeException e) {
            result = false;
            throw new PipelineRuntimeException("Unable to update index " + _indexName, e);
        } finally {
            if (hasModifications) {
                if (result)
                    _indexManager.setIndexStatus(ConstantsForSales.STATUS_CODE_OK);
                else
                    _indexManager.setIndexStatus(ConstantsForSales.STATUS_CODE_FAILED);
            } else {
                if (previousIndexStatus != null)
                    _indexManager.setIndexStatus(previousIndexStatus);
                else
                    _indexManager.setIndexStatus(ConstantsForSales.STATUS_CODE_OK);
            }
        }
    }

    private Map<String, Document> createDocumentsToIndex(final boolean rebuildIndex) throws PipelineRuntimeException {
        Map<String, Document> docsToIndex = new HashMap<String, Document>();

        LOG.info("Start creating documents for '" + _indexName + "'...");
        long startTime = System.nanoTime();

        if (rebuildIndex)
            _indexManager.setIndexStatus(ConstantsForSales.STATUS_CODE_REBUILDING);
        else
            _indexManager.setIndexStatus(ConstantsForSales.STATUS_CODE_UPDATING);

        int offset = 0;
        int limit = NUMBER_OF_LOGS_PER_BATCH;
        XMLResultset items = null;

        try {
            do {
                items = queryRecordsToIndex(_boName, _boMethodName, this._keyAttributeName, rebuildIndex, offset, limit);

                if (items != null && !items.isEmpty()) {
                    ResultsetDocumentHandler handler = new ResultsetDocumentHandler(docsToIndex, _indexManager,
                            _keyAttributeName);
                    parseXMLResultset(items, handler);
                    if (docsToIndex.size() > 0)
                        addMoreFields(docsToIndex);
                }
                offset += limit;

            } while (!rebuildIndex && items != null && !items.isEmpty());
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Unable to test if XMLResult is empty", e);
        }
        
        long endTime = System.nanoTime();
        LOG.info("Finished creating all " + docsToIndex.size() + " documents to index in "
                + IndexManagerUtil.getTimeInterval(startTime, endTime));

        return docsToIndex;
    }

    private Term[] createKeyTermsToDelete() throws PipelineRuntimeException {
        Term[] terms = null;
        try {
            XMLResultset deleteLogs = IndexLogUtil.getLogs(_indexName, IndexLogUtil.DELETE_ACTION);
            if (deleteLogs != null && !deleteLogs.isEmpty()) {
                _indexManager.setIndexStatus(ConstantsForSales.STATUS_CODE_UPDATING);

                terms = new Term[deleteLogs.rowCount()];
                int i = 0;
                deleteLogs.beforeFirst();
                while (deleteLogs.moveNext()) {
                    terms[i] = new Term(ConstantsForSales.KEY_FIELD, deleteLogs
                            .getString(ConstantsForSales.INDEX_KEY_FIELD_ATTRIBUTE));
                    i++;
                    _indexLogsToDelete.add(deleteLogs.getString(ConstantsForSales.LOG_ID_ATTRIBUTE));
                }
            }
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Unable to create key terms to delete", e);
        }
        return terms;
    }

    /**
     * 
     * @param doRebuild
     * @return
     * @throws PipelineRuntimeException
     */
    protected XMLResultset queryRecordsToIndex(final String boName, final String boMethodName,
            final String bindingAttribute, final boolean rebuildIndex, final int offset, final int limit)
            throws PipelineRuntimeException {
        XMLResultset result = null;
        
        try {

            SearchPipelineExecuter pipeline = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, boName,
                    boMethodName, SearchPipelineExecuter.OR);
            if (rebuildIndex == true) {
                LOG.debug("Fetching all '" + boName + "' records to index...");
            } else {
                LOG.debug("Fetching updated '" + boName + "' records to index...");
                XMLResultset updateLogs = IndexLogUtil.getLogs(_indexName, IndexLogUtil.ADD_UPDATE_ACTION, offset, limit);
                if (updateLogs.isEmpty()) {
                    // nothing to update
                    return null;
                }
                updateLogs.beforeFirst();
                while (updateLogs.moveNext()) {
                    pipeline.setBinding(bindingAttribute, updateLogs
                            .getString(ConstantsForSales.INDEX_KEY_FIELD_ATTRIBUTE), "eq");
                    _indexLogsToDelete.add(updateLogs.getString(ConstantsForSales.LOG_ID_ATTRIBUTE));
                }
            }

            Set<?> paramNames = _requestParameters.getParameterNames();
            for (Object param : paramNames) {
                String paramName = (String) param;
                pipeline.setParam(paramName, _requestParameters.getString(paramName));
            }

            // Add request parameters
            setAdditionalRequestParameters(pipeline);

            // Add request bindings
            setAdditionalRequestBindings(pipeline);
            result = pipeline.execute();

        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Unable to add request parameters", e);
        } catch (IndexManagerRuntimeException e) {
            throw new PipelineRuntimeException("Unable to fetch update logs", e);
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Unable to parse result xml", e);
        }

        return result;
    }

    protected void addAttributesAsFields(final NamedNodeMap attributes, Document doc, final String namePrefix) {
        for (int i = 0; i < attributes.getLength(); i++) {
            Node attribute = attributes.item(i);
            if (attribute != null) {
                String name = attribute.getNodeName();
                String value = attribute.getNodeValue();
                if (name.equals(_keyAttributeName))
                    IndexManagerUtil.addKeyField(doc, value);
                else
                    IndexManagerUtil.addIndexField(doc, _indexManager, namePrefix + name, value);
            }
        }
    }

    protected void parseXMLResultset(XMLResultset resulset, ResultsetDocumentHandler handler)
            throws PipelineRuntimeException {
        try {
            if (resulset != null && !resulset.isEmpty()) {
                SAXParserFactory spf = SAXParserFactory.newInstance();
                SAXParser sp = spf.newSAXParser();
                ParserAdapter pa = new ParserAdapter(sp.getParser());
                pa.setContentHandler(handler);
                pa.parse(getInputSource(resulset));
            }
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Unable to read XMLResultset", e);
        } catch (FactoryConfigurationError e) {
            throw new PipelineRuntimeException("Unable to get new SAXParserFactory instance", e);
        } catch (ParserConfigurationException e) {
            throw new PipelineRuntimeException("Unable to configure SAXParser properly", e);
        } catch (IOException e) {
            throw new PipelineRuntimeException("Unable to parse XMLResultset", e);
        } catch (SAXException e) {
            throw new PipelineRuntimeException("Unable to parse XMLResultset", e);
        }
    }

    private InputSource getInputSource(XMLResultset resulset) throws PipelineRuntimeException {
        try {
            Source source = new DOMSource(resulset.getDocument());
            StringWriter stringWriter = new StringWriter();
            Result result = new StreamResult(stringWriter);
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer();
            transformer.transform(source, result);
            return new InputSource((Reader) new StringReader(stringWriter.toString()));
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Unable to get XMLResultset document", e);
        } catch (TransformerFactoryConfigurationError e) {
            throw new PipelineRuntimeException("Unable to get new TransformerFactory instance", e);
        } catch (TransformerConfigurationException e) {
            throw new PipelineRuntimeException("Unable to get new XML Transformer", e);
        } catch (TransformerException e) {
            throw new PipelineRuntimeException("Unable to get transform XMLResulset", e);
        }
    }
}