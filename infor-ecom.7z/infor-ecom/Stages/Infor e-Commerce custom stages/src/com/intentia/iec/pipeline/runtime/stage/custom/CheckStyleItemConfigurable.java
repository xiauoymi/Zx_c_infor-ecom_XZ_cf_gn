package com.intentia.iec.pipeline.runtime.stage.custom;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;

import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.connection.ConnectorException;
import com.intentia.iec.connection.IMovexApiResultset;
import com.intentia.iec.connection.IMovexConnection;
import com.intentia.iec.businessobject.output.XMLIterator;


public class CheckStyleItemConfigurable implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(CheckStyleItemConfigurable.class);

    private static final String SEQUENTIAL_CONFIG_ENABLED = "Items.Sequential configurator";

    private XMLRequest xmlRequest = null;
	
	private IMovexConnection movex = null;
	
	private String company = "";
	
	private String facility = "";
	
	private String itemNumber = "";
	
	private static final String variant = "V1";

    public void execute(PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("Entering CheckStyleItemConfigurable.execute()");

        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
        xmlRequest = (XMLRequest) context.getRequest();

        try {
            XMLRequest.extractRequestParameters(xmlRequest);
        } catch (RequestException e) {
            throw new PipelineRuntimeException("Error extracting request parameters!", e);
        }

        // Movex connector not enabled => skip stage
        if (!"true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.CONNECTORENABLED))) {
            return;
        }

        if (!"true".equals(CustomStagesHelper.getKeyValue(SEQUENTIAL_CONFIG_ENABLED))) {
            return;
        }

		// extracting CONO, FACI and ITEM parameters.
		try {
			company = xmlRequest.getParameters().getString("MvxCompany");
			facility = xmlRequest.getParameters().getString("MvxFacility");
			itemNumber = xmlRequest.getParameters().getString("ItemID");
		} catch (ParametersException e) {
			System.out.println("Failed to extract parameters!");
		}
		
		LOG.debug("Company: " +company);
		LOG.debug("Facility: " +facility);
		LOG.debug("Item: " +itemNumber);
		
		if (itemNumber == null || "".equals(itemNumber)) {
            itemNumber = getItemNumberFromResponse(context);
        }
		
		try {
			boolean isConfigurable = checkIfConfigurableStyle(itemNumber, company, facility, context);		
			LOG.debug("isConfigurable: " +isConfigurable);
			
			if (!isConfigurable) {
	            CustomStagesHelper.setResponseParameter(context, "isMvxConfigurable", "Y");
	        } else {
	            CustomStagesHelper.setResponseParameter(context, "isMvxConfigurable", "N");
	        }
		}
		finally {
			if (this.movex != null) {
				try {
					 LOG.debug("Closing movex connection");
					this.movex.close();
				} catch (ConnectorException e) {}
				this.movex = null;
			}
		}


        LOG.debug("Exiting CheckStyleItemConfigurable.execute()");
    }

    private String getItemNumberFromResponse(PipelineContext context) {
        LOG.debug("Entering CheckStyleItemConfigurable.getItemNumberAttribute");
        String itemNumber = "";
        XMLResultset result = (XMLResultset) context.getResponse();
        try { 
            if ((result == null) || (result.isEmpty())) {
                return itemNumber;
            }
            result.moveFirst();
            itemNumber = result.getString("ItemID");
			LOG.debug("ItemID :" + itemNumber);
        } catch (ResultsetException e) {
            LOG.debug("ItemID is not in the response.");
        }      
        LOG.debug("Exiting CheckStyleItemConfigurable.getItemNumberAttribute");
        return itemNumber;
    }
	
	private boolean checkIfConfigurableStyle(String itemNumber, String company, String facility, PipelineContext context) throws PipelineRuntimeException {
		
		// New movex connection for CRS990MI
		movex = (IMovexConnection) CustomStagesHelper.getConnection("esales.CRS990MI");
	
		if (movex == null) {
			return true;
		}
		
		// retrieve product features
		Map m3ProdIn = new HashMap();
		// API transaction
		m3ProdIn.put(IMovexConnection.TRANSACTION, "LstBrowse");
		// API input data
		m3ProdIn.put("FLDI", "PUPRNO");
		m3ProdIn.put("VARI", variant);
		m3ProdIn.put("KV01", company);
		m3ProdIn.put("KV02", facility);
		m3ProdIn.put("KV03", itemNumber);
		m3ProdIn.put("KV04", "001");
		
		IMovexApiResultset APIresults = CustomStagesHelper.callMovex(context, movex, m3ProdIn, "mvxStatus");
		// iterate list product features connected
		Iterator resultsIte = APIresults.iterator();
		
		int x = 0;
		int featureSize = 0;
		int indexProduct = 0;
		int index = 0;
		boolean isConfigurable = true;
		
		String[] productFeature = new String[APIresults.size()];
		
		while (resultsIte.hasNext()) {
			Map feat = (Map) resultsIte.next();
			productFeature[x] = (String) feat.get("FV01");
			x++;
			indexProduct = x;
		}
		
		// retrieve style features
		Map m3StyleIn = new HashMap();
		// API transaction
		m3StyleIn.put(IMovexConnection.TRANSACTION, "LstBrowse");
		// API input data
		m3StyleIn.put("FLDI", "HUSTYN");
		m3StyleIn.put("VARI", variant);
		m3StyleIn.put("KV01", company);
		m3StyleIn.put("KV02", itemNumber);
		
		IMovexApiResultset m3results = CustomStagesHelper.callMovex(context, movex, m3StyleIn, "mvxStatus");
		// iterate list style features connected
		Iterator m3resultsIte = m3results.iterator();
		
		x = 0;
		int indexStyle = 0;
		String[] styleFeature = new String[m3results.size()];
				
		while (m3resultsIte.hasNext()) {
			Map stylefeat = (Map) m3resultsIte.next();
			styleFeature[x] = (String) stylefeat.get("FV01");
			x++;
			indexStyle = x;
		}
	
		if (indexProduct > indexStyle) {
			isConfigurable = false;
			return isConfigurable;
		} else if (indexProduct == 0) {
			isConfigurable = true;
			return isConfigurable;	
		} else {
			for (int i=0; i<indexProduct; i++) {
				if (isConfigurable) {
					for (int j=0; j<indexStyle; j++) {
						if (productFeature[i].equals(styleFeature[j])) {
							isConfigurable = true;
							LOG.debug("style: " +styleFeature[j]);
							LOG.debug("product: "+productFeature[i]);
							LOG.debug("isConfigurable: "+isConfigurable);
							break;
						} else {
							isConfigurable = false;
							LOG.debug("style: " +styleFeature[j]);
							LOG.debug("product: "+productFeature[i]);
							LOG.debug("isConfigurable: "+isConfigurable);
						}
					}
				}
			}
			return isConfigurable;
		}		
	}
}