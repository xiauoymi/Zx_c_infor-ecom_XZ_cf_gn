package com.intentia.iec.pipeline.runtime.stage.custom;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;

public class MergeConfigurableSKU implements PipelineStage {
	
	private static final Logger LOG = Logger.getLogger(MergeConfigurableSKU.class);
	
	private static final String PARAM_MERGE = "mergeconfigurable";
	
	private class SkuMvxConfigurableIDKey {
		private String sku = null;
		
		private String mvxConfigurableID = null;
		
		private SkuMvxConfigurableIDKey(String sku, String mvxConfigurableID) {
			this.sku = sku;
			this.mvxConfigurableID = mvxConfigurableID;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime
					* result
					+ ((mvxConfigurableID == null) ? 0 : mvxConfigurableID
							.hashCode());
			result = prime * result + ((sku == null) ? 0 : sku.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final SkuMvxConfigurableIDKey other = (SkuMvxConfigurableIDKey) obj;
			if (mvxConfigurableID == null) {
				if (other.mvxConfigurableID != null)
					return false;
			} else if (!mvxConfigurableID.equals(other.mvxConfigurableID))
				return false;
			if (sku == null) {
				if (other.sku != null)
					return false;
			} else if (!sku.equals(other.sku))
				return false;
			return true;
		}
		
		
	}

	public void execute(PipelineContext context) throws PipelineRuntimeException {
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }      
        
        String mergeSKUProperty = CustomStagesHelper.getKeyValue("Ordering.Merge SKU in orderlines");
        if (mergeSKUProperty != null && Boolean.valueOf(mergeSKUProperty) == false) {
        	throw new PipelineRuntimeException("Should not invoke this method if Ordering.Merge SKU in orderlines=false");
        }
        
        CustomStagesHelper.extractRequestParameters(CustomStagesHelper.getRequest(context));
		Parameters requestParameters = CustomStagesHelper.getRequestParameters(context);
		if (requestParameters != null) {
			try {
				String merge = requestParameters.getString(PARAM_MERGE);
				LOG.debug("Parameter for merging was found="+merge);	
				if (merge != null) {
					if (Boolean.valueOf(merge) == false) {
						LOG.debug("Explicitly skipping stage");	
						return;
					}
				}
			} catch (ParametersException e) {
				// ignore
			} 
		}
        
        if (context.getResponse() instanceof XMLResultset) {
        	XMLResultset result = (XMLResultset) context.getResponse();        	
        	
            try {
            	Document document = result.getDocument();
            	if (document != null) {
            		
            		Set<Element> deletedNodes = new HashSet<Element>();
            		Map<SkuMvxConfigurableIDKey, Set<Element>> configSkus = new HashMap<SkuMvxConfigurableIDKey, Set<Element>>();
            		
	        		NodeList nodeList = XPathAPI.selectNodeList(document,"resultset/row/OrderLine");
	        		if (nodeList != null && nodeList.getLength() > 0) {
	        			
	        			for (int i = 0; i < nodeList.getLength(); i++) {
	        				Element node = (Element)nodeList.item(i);
	        				
	        				String sku = node.getAttribute("SKU");	
//	        				String itemId = node.getAttribute("ItemID");
	        				String mvxConfigurableID = node.getAttribute("MvxConfigurableID");
	        				SkuMvxConfigurableIDKey key = null;	        				
	        				
	        				if (sku != null && sku.length() > 0) {
	        					StringBuffer sb = new StringBuffer("resultset/row/OrderLine[(");
	        					sb.append("@SKU=\"");
	        					sb.append(sku);
	        					sb.append("\"");
	        					sb.append(" and ");
	        					
	        					if (mvxConfigurableID != null && mvxConfigurableID.length() > 0) {
	        						sb.append("@MvxConfigurableID=\"");
	                                sb.append(mvxConfigurableID);
	                                sb.append("\"");
	                                
	                                key = new SkuMvxConfigurableIDKey(sku, mvxConfigurableID);
	        					}
	        					else {
	        						sb.append("not(@MvxConfigurableID)");
	        						
	        						key = new SkuMvxConfigurableIDKey(sku, null);
	        					}	        					
	        					
	        					sb.append(")]");
        					
	        					NodeList similarNodes = XPathAPI.selectNodeList(document,sb.toString());
	        					// TODO: Only group if more than equal to 1?
	        					if (similarNodes != null && similarNodes.getLength() > 0) {
			        				Set<Element> s = configSkus.get(key);
			        				if (s == null) {
			        					s = new HashSet<Element>();
			        					configSkus.put(key, s);
			        				}
			        				s.add(node);		        				
			        				
			        				deletedNodes.add(node);
	        					}
	        				}
	        			}
	        			
	        			if (deletedNodes.size() > 0 && configSkus.size() > 0) {
		        			
	        				Iterator<Element> it = null;	        				
	        				
	        				Node main = XPathAPI.selectSingleNode(document, "resultset/row");
	        				if (main != null) {
	        					Iterator<SkuMvxConfigurableIDKey> keys = configSkus.keySet().iterator();
	        					while (keys.hasNext() == true) {
	        						SkuMvxConfigurableIDKey key = keys.next();
	        						Set<Element> elements = configSkus.get(key);

	        						List<Element> sortedElements = new ArrayList<Element>(elements);
	        						Collections.sort(sortedElements, new Comparator<Object>() {

										public int compare(Object o1, Object o2) {
											if (o1 instanceof Element && o2 instanceof Element) {
												Element e1 = (Element)o1;
												Element e2 = (Element)o2;
												
												// sort by ItemID first.
												String s1 = e1.getAttribute("ItemID");
												String s2 = e2.getAttribute("ItemID");
												
												if (s1.compareTo(s2) != 0) {
													return s1.compareTo(s2);
												}
												
												// then sort by MvxConfigurableID
												s1 = e1.getAttribute("MvxConfigurableID");
												s2 = e2.getAttribute("MvxConfigurableID");
												
												if (s1 == null && s2 == null) {
													return 0;
												}
												if (s1 == null && s2 != null) {
													return -1;
												}
												if (s1 != null && s2 == null) {
													return 1;
												}
												
												return s1.compareTo(s2);
											}
											return 0;
										}});
	        						
	        						
	        						Element clone = null;
	        						
	        						it = sortedElements.iterator();	        						
	        						while (it.hasNext() == true) {
	        							Element e = it.next();
	        							
	        							if (clone == null) {
	        								clone = (Element) e.cloneNode(true);
	        								main.appendChild(clone);
	        								clone.setAttribute("ItemID", key.sku);
	        								clone.setAttribute("ItemName", e.getAttribute("SKUName"));
	        								clone.setAttribute("ItemDescription", e.getAttribute("SKUDescription"));
	        							}
	        							else {
	        								addAndSave(clone, e, "Quantity");
	        								addAndSave(clone, e, "ListPrice");
	        								addAndSave(clone, e, "ResellPrice");
	        								addAndSave(clone, e, "LineTotal");
	        								addAndSave(clone, e, "LinePrice");
	        							}
	    	        					if (e.getParentNode() != null) {
	    	        						e.getParentNode().removeChild(e);
	    	        					}	        							
	        							clone.appendChild(e);
	        						}
	        					}
	        				}
	        				
	        				deletedNodes.clear();
	        			}
	        		}
            	}
            }
            catch (Exception e) {
            	throw new PipelineRuntimeException("Error in merging Configurable SKUs", e);
            }
        }
        
        XMLResultset resultset = (XMLResultset) context.getResponse();
        LOG.debug("Resultset after Merge = "+resultset.toString());		
	}
	
	private double add(Element e, Element f, String attribute) {
		if (e != null && f != null && attribute != null) {
			double q = Double.parseDouble(e.getAttribute(attribute));
			double r = Double.parseDouble(f.getAttribute(attribute));
			
			return q+r;
		}
		
		return 0;
	}
	
	private void addAndSave(Element e, Element f, String attribute) {
		try {
			double t = add(e, f, attribute);
			e.setAttribute(attribute, Double.toString(t));		        									
		}
		catch (Exception x) {}
	}

}
