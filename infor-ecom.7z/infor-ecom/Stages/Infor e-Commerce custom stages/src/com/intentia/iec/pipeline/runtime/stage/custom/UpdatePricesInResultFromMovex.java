/*
 * Created on 13-04-2004
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.output.Resultset;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;

/**
 * Stage to get the latest prices for the current user / user group from Movex
 * for the items in the current resultset.
 * <p>
 * <b>Required input in <code>PipelineContext</code>:</b><br>
 * Input parameters: <code>mvxCompany</code>, <code>mvxFacility</code>,
 * <code>mvxOrderType</code>, <code>mvxWareHouse</code>,
 * <code>&#64;CurrencyCode</code>, <code>&#64;ListPriceGroup</code>, and
 * <code>UserGroupID</code>
 * <p>
 * <b>Generated output in <code>PipelineContext</code>:</b><br>
 * Output parameters: <code>mvxStatus</code> (error if negative)
 */
/*
 * The text uses the character code &#64; for @ to avoid to confuse the Java
 * auto formatter.
 */
public final class UpdatePricesInResultFromMovex extends UpdatePricesFromMovex implements PipelineStage {

    static final Logger LOG = Logger.getLogger(UpdatePricesInResultFromMovex.class);

    /**
     * The stage entry point.
     * 
     * @see com.intentia.iec.pipeline.runtime.PipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
     */
    public void execute(final PipelineContext context) throws PipelineRuntimeException {
        // Movex connector not enabled => skip stage
        if (!"true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.CONNECTORENABLED))) {
            return;
        }
        CustomStagesHelper.extractRequestParameters(CustomStagesHelper.getRequest(context));
        // Call the actual update function in the derived class
        update(context);
    }

    /**
     * Updates prices for all items in the request.
     * 
     * @param context
     *            PipelineContext
     * @throws PipelineRuntimeException
     */
    protected void update(final PipelineContext context) throws PipelineRuntimeException {
        try {
            XMLResultset result = (XMLResultset) context.getResponse();
            if ((result == null) || (result.isEmpty())) {
                return;
            }
            result.moveFirst();
            XMLIterator lines = (XMLIterator) result.getResultset(ConstantsForSales.ORDERLINE);
            if ((lines == null) || lines.isEmpty()) {
                return;
            }
            lines.beforeFirst();
            boolean cont = true;
            while (cont && lines.moveNext()) {
                cont = updateLine(context, lines);
            }
            // Reset the position in the resultset so it is correct for the next
            // use.
            lines.beforeFirst();
        } catch (final ResultsetException e) {
            final String msg = "Could not traverse the resultset.";
            LOG.error(msg, e);
            throw new PipelineRuntimeException(msg, e);
        }
    }

    /**
     * Updates prices for a single item.
     * 
     * @param Helper
     *            class for getting and calculating item prices
     * @param XML
     *            node in result with information for a item
     * @return true if prices were updated (OK)
     * @throws PipelineRuntimeException
     */
    private boolean updateLine(final PipelineContext context, final XMLIterator line) throws PipelineRuntimeException {
        final String itemID = getString(line, ConstantsForSales.ITEMID);
        final String mvxConfigNo = getString(line, ConstantsForSales.MVXCONFIGURABLENUMBER);
        final String quantity = getString(line, ConstantsForSales.QUANTITY);
        ItemPrices itemPrices = new ItemPrices(context);
        if (itemPrices.getPrices(itemID, mvxConfigNo, quantity)) {
            try {
                line.setString(ConstantsForSales.RESELLPRICE, itemPrices.getResellPrice());
                line.setString(ConstantsForSales.LINEPRICE, itemPrices.getLinePrice());
                line.setString(ConstantsForSales.LINEDISCOUNT, itemPrices.getDiscount());
                line.setString(ConstantsForSales.LINEDISPERCENT, itemPrices.getDisPercent());
                line.setString(ConstantsForSales.LINETOTAL, itemPrices.getLineTotal());
                line.setString(ConstantsForSales.ISLISTPRICE, itemPrices.getIsListPrice());
            } catch (final ResultsetException e) {
                final String msg = "Could not write to the " + ConstantsForSales.ORDERLINE
                        + " subset using the Movex price.";
                LOG.error(msg, e);
                throw new PipelineRuntimeException(msg, e);
            }
            return true;
        } else {
            return false;
        }
    }

    /**
     * Get attribute value from resultset by attribute name.<br>
     * Throws exception if not found.
     * 
     * @param resultset
     *            to get attribute from
     * @param name
     *            of attribute
     * @return attribute value as String
     * @throws PipelineRuntimeException
     */
    private String getString(final Resultset resultset, final String name) throws PipelineRuntimeException {
        try {
            return (String) resultset.getString(name);
        } catch (final ResultsetException e) {
            String msg = "Missing parameter: " + name;
            LOG.error(msg, e);
            throw new PipelineRuntimeException(msg, e);
        }
    }
}
