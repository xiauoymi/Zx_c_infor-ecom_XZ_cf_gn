package com.intentia.iec.pipeline.runtime.stage.custom.search.sps.equipment;

/**
 * Definitions of SQL queries and attributes specific to equipment search.
 *
 */
public interface EquipmentStrings {
	
	interface Database {
		interface Indexing {
			
			interface Equipment {
				interface Equipments {
					public static final String userGroupId = "userGroupId";

					public static final String equipmentId = "equipmentId";
					
					public static final String isParent = "isParent";
					
					public static final String serialNumber = "serialNumber";
					
					public static final String itemId = "itemId";

					public static final String sql = 
						" select distinct cev.userGroupId as " + userGroupId + ", "
						+ "case when eq.userGroupId is not null and exists (select 1 from AsBuiltStructure where parentEquipmentId=eq.id) then 'Y' else NULL end as " + isParent + ", "
						+ equipmentId + ", " + serialNumber + ", " + itemId
						+ " from Equipment eq "
						+ " inner join CustomerEquipmentVisible cev "
						+ " 	on eq.id=cev.equipmentId ";						
				}
				
				interface Items {
					public static final String sql = ""
                        + " select                                                                  "
                        + "     i.id,                                                               "
                        + "     i.itemNumber,                                                       "
                        + "     m.[key] as manufacturerId,                                          "
                        + "     m.name as manufacturerName,                                         "
                        + "     i.mainCategoryId,                                                   "
                        + "     b.[key] as brandId, 												" 
                        + "     i.supplierId 														"
                        + " from Item i                                                             "
                        + "     left outer join Manufacturer m                                      "
                        + "         on m.id = i.manufacturerId                                      "
                        + "    	left outer join Brand b                           					"
                        + "        	on b.id = i.brandId 											"
                        + " where					                                                "
                        + "     i.typeCodeId = (select id from Code where [key] = 'normalItemCode') "
                        + "		and i.id = ?";					
				}
				
				interface ParentEquipments {
					public static final String parentEquipmentId = "parentEquipmentId";
					public static final String sql = 
						" select parentEquipmentId from AsBuiltStructure "
						+ " where childEquipmentId = ? ";
				}
				
				interface NamesDescriptionsAndSerialNumber {
                    public static String languageCode = "languageCode";

                    public static String name = "name";

                    public static String description = "description";
                    
                    public static String serialNumber = "serialNumber";

                    public static String sql = "select " + languageCode + ", " + name + ", " + description + ", " + serialNumber 
                    	+ " from ItemText it inner join Equipment eq on it.itemId = eq.itemId where eq.id= ?";					
				}
			}
		}
		
		interface Searching {
			interface Equipment {
				interface PassiveAttributes {
					public static final String sqlHead =                             
					 " select                                                       		"
					+ "		eq.id as equipmentId,											"
                    + "     i.id,                                                    		"
                    + "     i.itemNumber,                                            		"
                    + "     i.hasSubItems,                                           		"
                    + "     i.isEmphasized,                                          		"
                    + "     tg2.rate,                                                 		"
                    + "     isnull(img.thumbImage,(select value from ApplicationData 		"
                    + "             where parameter = 'DefItemImageThumb'))          		"
                    + "         as imageThumb,                                       		"
                    + "     lp.amount as listPrice,                                  		"
                    + "     rp.amount as resellPrice,                                		"
                    + "     m.[key] as manufacturerId,                               		"
                    + "     coalesce(i.minQty, 1) as minQty,                         		"
                    + "     coalesce(i.modularQty, 1) as modularQty,                 		"
                    + "     i.isMvxConfigurable,                                     		"
                    + "     f.styleId,                                               		"
                    + "     i.supplierId,                                            		"
                    + "     b.[key] as brandId,                                  			"
                    + "     b.name as brandName,                                 			"
                    + "     it.description as description,                              	"
                    + "     mc.[key] as mainCategoryId,                              		"
                    + "     mct.name as mainCategoryName,                              		"
                    + "     m.name as manufacturerName,                              		"
                    + "     isnull(img.previewImage,(select value from ApplicationData 		"
                    + "             where parameter = 'DefItemImagePreview'))          		"
                    + "         as imagePreview,                                     		"
                    + " 	case when i.id in (select styleId from StyleRelation) 			"
                    + "			then 'Y' else 'N' end as isStyle, 							"
                    + " 	dbo.GetNetListPrice(lp.amount, rp.amount, 						"
                    + "			cid.maxDiscount, cp.amount) as netListPrice, 				"
                    + " 	dbo.GetTaxPrice(lp.amount, rp.amount, cid.maxDiscount, 			"
                    + " 		cp.amount, tg2.rate) as taxPrice, 							"
                    + " 	uct.text as unit, 												"
                    + " 	uc.code as unitCode, 											"
                    + " 	i.rating as itemRating,											"
                    + "     citem.customerItemId as customerItemId,						"
                    + "		case when exists" 
                    + "			(SELECT 1 from AsBuiltStructure asb where asb.parentEquipmentId = eq.id)"
                    + "			then 'Y' else 'N' end as hasChildEquipments,						"
                    + "		case when exists ("
                    + "			SELECT 1 from Item i2 INNER JOIN ItemVisible iv on i2.id = iv.itemId and i2.isActive = 'Y' LEFT JOIN UserAssortment ua ON ua.assortmentId = iv.assortmentId"
                    + "			WHERE i2.id = eq.itemId "
                    + "			AND ua.userId = ? AND ua.userGroupId = ?"
                    + "			AND (0 = (SELECT COUNT(*) FROM WarehouseItem) OR 0 < (SELECT COUNT(*) FROM WarehouseItem wi INNER JOIN Warehouse w ON w.[id] = wi.warehouseId WHERE iv.itemId = wi.itemId AND w.warehouse = ?))"
                    + "		) then 'Y' else 'N' end as isVisible,							"
					+ "		case when EXISTS (SELECT 1 from BlowUpPrint bup "
					+ "			inner join Item bupItem on bup.itemId=bupItem.id "
					+ "			inner join BlowUpPrintItem bupi on bup.id=bupi.blowUpPrintId "
					+ "			where bupItem.itemNumber=i.itemNumber and bup.serialNumber=eq.serialNumber and bup.statusCode = 'ApprovedBlowUpPrintStatus') THEN 'Y' ELSE 'N' END as HasDrawing, "                    
                    + "		eq.serialNumber as serialNumber									"
                    + " from Equipment eq "                    
                    + "		inner join Item i                                               "
                    + "			on eq.itemId = i.id 										"
                    + " 	left join ItemTaxGroup tg 										" 
                    + "    		on i.id = tg.itemId 										"
                    + " 	left join TaxGroup tg2 											"
                    + "    		on tg2.id = IsNull(tg.taxGroupId, 							"
                    + "				(select defaultTaxGroupId 								"
                    + "					from Country where countryCode = ?)) 				"
                    + "     left join Price lp                                       		"
                    + "         on i.id = lp.itemId                                  		"
                    + "             and lp.priceGroupId = ? 								" 
                    + "				and lp.currencyCode = ?  								"
                    + "     left join Price rp                                       		"
                    + "         on i.id = rp.itemId                                  		"
                    + "             and rp.priceGroupId = ? 								" 
                    + "				and rp.currencyCode = ?  								"
                    + "     left join Manufacturer m                                 		"
                    + "         on i.manufacturerId = m.id                           		"
                    + "     left join StyleFeatureRelation f                         		"
                    + "         on i.id = f.styleId                                  		"
                    + " 	left join ItemImages img 								 		" 
                    + "			on i.itemNumber = img.itemNumber				 	 		"
                    + "			and not exists (select * from ItemImages img2 	 	 		"
                    + "				where img.id = img2.id and img.defaultImage ='N')		"
                    + " 	left join Brand b on b.id = i.brandId			 				" 
                    + " 	left join ItemText it 											"
                    + "			on it.itemId = i.id 										" 
                    + " 			and it.languageCode = ?									"
                    + "		left join CustomerItemDiscount cid								" 
                    + "    		on	i.id = cid.itemId 										"
                    + "				and cid.customerId = ? 									" 
                    + " 	left join Code uc 												"
                    + "			on i.unitCodeId = uc.id 									" 
                    + " 	left join CodeText uct 											"
                    + "			on uc.id = uct.codeId										" 
                    + "				and uct.languageCode = ? 								"
                    + " 	left join Category mc 											" 
                    + "			on i.mainCategoryId = mc.id 								"
                    + " 	left join CategoryText mct 										" 
                    + "			on mc.id = mct.categoryId 									"
                    + "				and mct.languageCode = ? 								" 
                    + " 	left join CustomerPrice cp 										"
                    + "    		on i.id = cp.itemId 										" 
                    + "       		and cp.customerId = ? 									"
                    + "       		and cp.currencyCode = ? 								" 
                    + "		left join CustomerItem citem"
                    + "			on i.id = citem.itemId" 
                    + "				and citem.userGroupId = ?"		
                    + " where 					                                      		"
                    + "     i.typeCodeId =                                       		"
                    + "         (select id from Code where [key] = 'normalItemCode') 		" 
                    + " and eq.id in (";
					
					public static final String sqlHeadParentView =                             
						 " select                                                       		"
						+ "		eq.id as equipmentId,											"
	                    + "     i.id,                                                    		"
	                    + "     i.itemNumber,                                            		"
	                    + "     i.hasSubItems,                                           		"
	                    + "     i.isEmphasized,                                          		"
	                    + "     tg2.rate,                                                 		"
	                    + "     isnull(img.thumbImage,(select value from ApplicationData 		"
	                    + "             where parameter = 'DefItemImageThumb'))          		"
	                    + "         as imageThumb,                                       		"
	                    + "     lp.amount as listPrice,                                  		"
	                    + "     rp.amount as resellPrice,                                		"
	                    + "     m.[key] as manufacturerId,                               		"
	                    + "     coalesce(i.minQty, 1) as minQty,                         		"
	                    + "     coalesce(i.modularQty, 1) as modularQty,                 		"
	                    + "     i.isMvxConfigurable,                                     		"
	                    + "     f.styleId,                                               		"
	                    + "     i.supplierId,                                            		"
	                    + "     b.[key] as brandId,                                  			"
	                    + "     b.name as brandName,                                 			"
	                    + "     it.description as description,                              	"
	                    + "     mc.[key] as mainCategoryId,                              		"
	                    + "     mct.name as mainCategoryName,                              		"
	                    + "     m.name as manufacturerName,                              		"
	                    + "     isnull(img.previewImage,(select value from ApplicationData 		"
	                    + "             where parameter = 'DefItemImagePreview'))          		"
	                    + "         as imagePreview,                                     		"
	                    + " 	case when i.id in (select styleId from StyleRelation) 			"
	                    + "			then 'Y' else 'N' end as isStyle, 							"
	                    + " 	dbo.GetNetListPrice(lp.amount, rp.amount, 						"
	                    + "			cid.maxDiscount, cp.amount) as netListPrice, 				"
	                    + " 	dbo.GetTaxPrice(lp.amount, rp.amount, cid.maxDiscount, 			"
	                    + " 		cp.amount, tg2.rate) as taxPrice, 							"
	                    + " 	uct.text as unit, 												"
	                    + " 	uc.code as unitCode, 											"
	                    + " 	i.rating as itemRating,											"
	                    + "     citem.customerItemId as customerItemId,						"
	                    + "		case when exists" 
	                    + "			(SELECT 1 from AsBuiltStructure asb where asb.parentEquipmentId = eq.id)"
	                    + "			then 'Y' else 'N' end as hasChildEquipments,						"
	                    + "		case when exists ("
	                    + "			SELECT 1 from Item i2 INNER JOIN ItemVisible iv on i2.id = iv.itemId and i2.isActive = 'Y' LEFT JOIN UserAssortment ua ON ua.assortmentId = iv.assortmentId"
	                    + "			WHERE i2.id = eq.itemId "
	                    + "			AND ua.userId = ? AND ua.userGroupId = ?"
	                    + "			AND (0 = (SELECT COUNT(*) FROM WarehouseItem) OR 0 < (SELECT COUNT(*) FROM WarehouseItem wi INNER JOIN Warehouse w ON w.[id] = wi.warehouseId WHERE iv.itemId = wi.itemId AND w.warehouse = ?))"
	                    + "		) then 'Y' else 'N' end as isVisible,							"
						+ "		case when EXISTS (SELECT 1 from BlowUpPrint bup "
						+ "			inner join Item bupItem on bup.itemId=bupItem.id "
						+ "			inner join BlowUpPrintItem bupi on bup.id=bupi.blowUpPrintId "
						+ "			where bupItem.itemNumber=i.itemNumber and bup.serialNumber=eq.serialNumber and bup.statusCode = 'ApprovedBlowUpPrintStatus') THEN 'Y' ELSE 'N' END as HasDrawing, "	                    
	                    + "		eq.serialNumber as serialNumber,								"
	                    + "		i.isActive,														"
	                    + "		asb.position "	                    
	                    + " from Equipment eq "                    
	                    + "		inner join Item i                                               "
	                    + "			on eq.itemId = i.id 										"
	                    + " 	left join ItemTaxGroup tg 										" 
	                    + "    		on i.id = tg.itemId 										"
	                    + " 	left join TaxGroup tg2 											"
	                    + "    		on tg2.id = IsNull(tg.taxGroupId, 							"
	                    + "				(select defaultTaxGroupId 								"
	                    + "					from Country where countryCode = ?)) 				"
	                    + "     left join Price lp                                       		"
	                    + "         on i.id = lp.itemId                                  		"
	                    + "             and lp.priceGroupId = ? 								" 
	                    + "				and lp.currencyCode = ?  								"
	                    + "     left join Price rp                                       		"
	                    + "         on i.id = rp.itemId                                  		"
	                    + "             and rp.priceGroupId = ? 								" 
	                    + "				and rp.currencyCode = ?  								"
	                    + "     left join Manufacturer m                                 		"
	                    + "         on i.manufacturerId = m.id                           		"
	                    + "     left join StyleFeatureRelation f                         		"
	                    + "         on i.id = f.styleId                                  		"
	                    + " 	left join ItemImages img 								 		" 
	                    + "			on i.itemNumber = img.itemNumber				 	 		"
	                    + "			and not exists (select * from ItemImages img2 	 	 		"
	                    + "				where img.id = img2.id and img.defaultImage ='N')		"
	                    + " 	left join Brand b on b.id = i.brandId			 				" 
	                    + " 	left join ItemText it 											"
	                    + "			on it.itemId = i.id 										" 
	                    + " 			and it.languageCode = ?									"
	                    + "		left join CustomerItemDiscount cid								" 
	                    + "    		on	i.id = cid.itemId 										"
	                    + "				and cid.customerId = ? 									" 
	                    + " 	left join Code uc 												"
	                    + "			on i.unitCodeId = uc.id 									" 
	                    + " 	left join CodeText uct 											"
	                    + "			on uc.id = uct.codeId										" 
	                    + "				and uct.languageCode = ? 								"
	                    + " 	left join Category mc 											" 
	                    + "			on i.mainCategoryId = mc.id 								"
	                    + " 	left join CategoryText mct 										" 
	                    + "			on mc.id = mct.categoryId 									"
	                    + "				and mct.languageCode = ? 								" 
	                    + " 	left join CustomerPrice cp 										"
	                    + "    		on i.id = cp.itemId 										" 
	                    + "       		and cp.customerId = ? 									"
	                    + "       		and cp.currencyCode = ? 								" 
	                    + "		left join CustomerItem citem"
	                    + "			on i.id = citem.itemId" 
	                    + "				and citem.userGroupId = ?"
	                    + "		left join AsBuiltStructure asb									"
	                    + "			on asb.childEquipmentId = eq.id " 
	                    + "				and asb.parentEquipmentId = ? "
	                    + "		left join Equipment parEquipment "
	                    + "			on asb.parentEquipmentId = parEquipment.id "
	                    + "		left join Item parItem "
	                    + "			on parEquipment.itemId = parItem.id"
	                    + " where 					                                      		"
	                    + "     i.typeCodeId =                                       		"
	                    + "         (select id from Code where [key] = 'normalItemCode') 		" 
	                    + " and eq.id in (";					
					
					public static final String equipmentId = "equipmentId";
					
					public static final String serialNumber = "serialNumber";
					
					public static final String hasChildEquipments = "hasChildEquipments";
					
					public static final String id = "id";
					
					public static final String isVisible = "isVisible";
					
					public static final String position = "Position";
					
					public static final String hasDrawing = "HasDrawing";
				}
			}
		}
	}
	
	interface Index {

		interface Equipment  {
			public static final String equipmentId = "equipmentId";
			
			public static final String userGroupId = "userGroupId";
			
			public static final String serialNumber = "serialNumber";
			
			public static final String parentEquipmentId = "parentEquipmentId";
		}
		
		public static final String isParent = "isParent";
		
		public static final String parent = "Y";
	}
	
	interface Request {
		interface Param {
			public static final String serialNumber = "@SerialNumber";
			
			public static final String childEquipmentSearchString = "@ChildEquipmentSearchString";
			
			public static final String wildcardSearch = "@WildCardSearch";
		}
	}
	
	interface Response {
		interface EquipmentList {	        
        	public static final String equipmentId = "EquipmentID";
        	
        	public static final String serialNumber = "SerialNumber";
        	
        	public static final String systemItemId = "SystemItemID";
        	
        	public static final String hasChildEquipments = "HasChildEquipments";
        	
        	public static final String id = "ID";
        	
        	public static final String position = "Position";
        	
        	public static final String isVisible = "IsVisible";
        	
        	public static final String hasDrawing = "HasDrawing";
		}
	}
}
