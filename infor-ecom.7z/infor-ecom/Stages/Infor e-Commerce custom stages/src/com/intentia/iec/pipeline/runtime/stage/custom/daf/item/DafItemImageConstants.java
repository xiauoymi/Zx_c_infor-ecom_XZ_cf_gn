package com.intentia.iec.pipeline.runtime.stage.custom.daf.item;

public final class DafItemImageConstants {
	
	/**
	 * Root
	 */
	public static final String TABLE = "/ESA_ItemImage";
	
	/**
	 * Item Image attributes
	 *
	 */
	public interface Attribute {
		public static final String STATUS = "MDS_Status";
		
		public static final String IS_DEFAULT = "ESA_Default";
		
		public static final String ITEM_NUMBER = "ESA_ItemNumber";
		
		/**
		 * References used when searching
		 *
		 */
		public interface Column {
			public static final String STATUS = "@" + Attribute.STATUS;
			
			public static final String IS_DEFAULT = "@" + Attribute.IS_DEFAULT;
			
			public static final String ITEM_NUMBER = "@" + Attribute.ITEM_NUMBER;			
		}
	}
	
	/**
	 * Resource attributes
	 *
	 */
	public interface Resource {
		public interface Attribute {
			public static final String IMAGE_TYPE = "MDS_ImageType";
			
			public static final String IMAGE_WIDTH = "MDS_ImageWidth";
			
			public static final String IMAGE_HEIGHT = "MDS_ImageHeight";			
		}
	}
	
	/**
	 * Status definitions
	 *
	 */
	public interface Status {
		public static final short DRAFT = 5;
		
		public static final short APPROVED = 20;
		
		public static final short INVALID = 80;
	}
	
	/**
	 * Image types displayed on e-Sales. These are converted from the original image.
	 * The original image is not displayed.
	 *
	 */
	public interface ImageType {
		public static final String THUMBNAIL = "ESA_Thumbnail";
		
		public static final String PREVIEW = "ESA_Preview";
		
		public static final String MASTER = "ESA_Master";
	}	
}
