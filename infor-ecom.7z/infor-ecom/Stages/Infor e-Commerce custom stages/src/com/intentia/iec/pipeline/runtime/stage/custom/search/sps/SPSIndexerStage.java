package com.intentia.iec.pipeline.runtime.stage.custom.search.sps;

import java.util.Map;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.search.IndexerStage;
import com.intentia.iec.pipeline.runtime.stage.custom.search.ItemIndexer;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Manager;

/**
 * Stage class that is called by LuceneSPS.Index.
 * This will index all spare parts.
 */
public class SPSIndexerStage extends IndexerStage {

    /*
     * (non-Javadoc)
     * 
     * @see com.intentia.iec.pipeline.runtime.stage.custom.search.IndexerStage#getManager()
     */
    protected Manager getManager() {
        // override to return SPSManagerImpl instance instead.
        return SPSManagerImpl.getInstance();
    }

    /* (non-Javadoc)
     * @see com.intentia.iec.pipeline.runtime.stage.custom.search.IndexerStage#createItemIndexer(java.util.Map, com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc)
     */
    protected ItemIndexer createItemIndexer(Map<String, String> categoryPathById, Jdbc jdbc) {
        // override to return SPSItemIndexer instead
        return new SPSItemIndexer(categoryPathById, jdbc);
    }

    /**
     * Returns false.
     * @return false
     */
    protected boolean isIndexNormalItems() {        
        return false;
    }

    /**
     * Returns true.
     * @return true
     */
    protected boolean isSpsEnabled() throws PipelineRuntimeException {
        // sps must be enabled when indexing spare parts
        return true;
    }
}
