package com.intentia.iec.pipeline.runtime.stage.custom;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.Resultset;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.connection.ConnectorException;
import com.intentia.iec.connection.IMovexApiResultset;
import com.intentia.iec.connection.IMovexConnection;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

public class GetInvoiceDetailsFromMovex implements PipelineStage {

    // Internal variables

    private IMovexConnection movexInvoice = null;

    private IMovexConnection movexCustomer = null;

    private IMovexConnection movexCustomerOrder = null;

    private Parameters parameters = null;

    private String invoiceNumber = null;

    private String invoiceYear = null;

    private String mvxCompany = null;

    private String mvxDivision = null;

    private String userGroupID = null;

    private static final Logger LOG = Logger.getLogger(GetInvoiceDetailsFromMovex.class);

    public void execute(PipelineContext context) throws PipelineRuntimeException {

        // Movex connector not enabled => skip stage
        if (!"true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.CONNECTORENABLED))) {
            throw new PipelineRuntimeException("Movex Connector is Disabled!");
        }

        int mvxStatus = -1010;

        try {

            getRequestParameters(context);

            validateInvoiceNumberToESales();

            initMovexConnection();

            // Load parameters for Invoice headers
            Map header = new HashMap();
            header.put(IMovexConnection.TRANSACTION, "LstInvHead");
            header.put("CONO", mvxCompany);
            header.put("DIVI", mvxDivision);
            header.put("YEA4", invoiceYear);
            header.put("IVNO", invoiceNumber);
            IMovexApiResultset resHead = CustomStagesHelper.callMovex(context, movexInvoice, header,
                    ConstantsForSales.MVXSTATUS);

            LOG.debug("Invoice Header Size: " + resHead.size());

            if (resHead.size() == 0) {
                LOG.fatal("Invalid Invoice number or Year");
                throw new PipelineRuntimeException("Invalid Invoice number or Year");
            }

            // Information type for Net Invoice Line
            int netInformationType = 30;

            // Load parameters for Invoice Lines
            Map mapNetInvoiceLine = new HashMap();
            mapNetInvoiceLine.put(IMovexConnection.TRANSACTION, "LstInvLineByTyp");
            mapNetInvoiceLine.put("CONO", mvxCompany);
            mapNetInvoiceLine.put("DIVI", mvxDivision);
            mapNetInvoiceLine.put("YEA4", invoiceYear);
            mapNetInvoiceLine.put("IVNO", invoiceNumber);
            mapNetInvoiceLine.put("IVTP", String.valueOf(netInformationType));

            IMovexApiResultset resNetInvoiceline = CustomStagesHelper.callMovex(context, movexInvoice,
                    mapNetInvoiceLine, ConstantsForSales.MVXSTATUS);

            LOG.debug("Invoice Line Size: " + resNetInvoiceline.size());

            if (resNetInvoiceline.size() == 0) {
                LOG.fatal("No invoice line found for invoice number: " + invoiceNumber);
            }

            IMovexApiResultset invoiceDiscounts = getDiscountInvoice(context);

            Map mapOrderHeader = new HashMap();
            mapOrderHeader.put(IMovexConnection.TRANSACTION, "GetHead");
            mapOrderHeader.put("CONO", mvxCompany);
            mapOrderHeader.put("ORNO", resNetInvoiceline.getParamAsString("ORNO"));
            IMovexApiResultset resOrderHeader = CustomStagesHelper.callMovex(context, movexCustomerOrder,
                    mapOrderHeader, ConstantsForSales.MVXSTATUS);

            LOG.debug("Order Header Size: " + resOrderHeader.size());

            if (resOrderHeader.size() == 0) {
                LOG.fatal("No Order found for order number: " + resNetInvoiceline.getParamAsString("ORNO"));
                throw new PipelineRuntimeException("No Order found for order number: "
                        + resNetInvoiceline.getParamAsString("ORNO"));
            }

            XMLResultset rsInvoice = new XMLResultset();
            rsInvoice.moveNext();
            rsInvoice.appendRow();

            // Invoice Header
            rsInvoice.appendField("InvoiceNumber", invoiceNumber);
            rsInvoice.appendField("InvoiceDate", resHead.getParamAsString("IDAT"));
            rsInvoice.appendField("Currency", resHead.getParamAsString("CUCD"));
            rsInvoice.appendField("DueDate", resHead.getParamAsString("DUDT"));
            rsInvoice.appendField("AmountLocal", resHead.getParamAsString("AMT1"));
            rsInvoice.appendField("AmountForeign", resHead.getParamAsString("AMT2"));
            rsInvoice.appendField("VoucherNumber", resHead.getParamAsString("VONO"));
            rsInvoice.appendField("PaymentTerm", resOrderHeader.getParamAsString("TEPY"));
            rsInvoice.appendField("OurReference", resOrderHeader.getParamAsString("OREF"));
            // rsInvoice.appendField("CustomerName",
            // resHead.getParamAsString("CUNM"));
            rsInvoice.appendField("Payer", getCustomerNameByID(context, resHead.getParamAsString("PYNO")));
            rsInvoice.appendField("PayerAddress", getAddress(resNetInvoiceline.getParamAsString("ORNO"), "3", context));
            rsInvoice.appendField("TotalVAT", getVATInvoice(context));

            Iterator itrInvoice = resNetInvoiceline.iterator();

            while (itrInvoice.hasNext()) {

                Map mvxLine = (Map) itrInvoice.next();

                XMLIterator rsl = (XMLIterator) rsInvoice.appendResultset("InvoiceLine"); // <<--
                // List

                rsl.appendRow();

                // load parameters for Delivery Head
                Map deliveryHeader = new HashMap();
                deliveryHeader.put(IMovexConnection.TRANSACTION, "GetDelHead");
                deliveryHeader.put("CONO", mvxCompany);
                deliveryHeader.put("ORNO", resNetInvoiceline.getParamAsString("ORNO"));
                deliveryHeader.put("WHLO", resNetInvoiceline.getParamAsString("WHLO"));
                deliveryHeader.put("DLIX", resNetInvoiceline.getParamAsString("DLIX"));
                IMovexApiResultset resDeliveryHeader = CustomStagesHelper.callMovex(context, movexInvoice,
                        deliveryHeader, ConstantsForSales.MVXSTATUS);

                LOG.debug(resDeliveryHeader.toString());

                if (resDeliveryHeader.size() == 0) {
                    LOG.fatal("No delivery header found for delivery number: "
                            + resNetInvoiceline.getParamAsString("DLIX"));
                    throw new PipelineRuntimeException("No delivery header found for delivery number: "
                            + resNetInvoiceline.getParamAsString("DLIX"));
                }

                // Invoice Line
                // rsl.appendField("CustomerName", (String)
                // mvxLine.get("CUNM"));
                rsl.appendField("CustomerName", getCustomerNameByID(context, getCustomerIDByOrderNumber(context,
                        (String) mvxLine.get("ORNO"))));
                rsl.appendField("CustomerAdress", getAddress((String) mvxLine.get("ORNO"), "1", context));
                rsl.appendField("OrderNumber", (String) mvxLine.get("ORNO"));
                rsl.appendField("DeliveryNumber", (String) mvxLine.get("DLIX"));
                rsl.appendField("AmountLocal", (String) mvxLine.get("AMT1"));
                rsl.appendField("AmountForeign", (String) mvxLine.get("AMT2"));
                // rsl.appendField("VAT", (String) mvxLine.get("VTAM"));
                rsl.appendField("Warehouse", (String) mvxLine.get("WHLO"));
                // rsl.appendField("InvoiceReference", (String)
                // mvxLine.get("IVRF"));
                rsl.appendField("DiscountAmount", getAPIResultSetValue(invoiceDiscounts, "DLIX", (String) mvxLine
                        .get("DLIX"), "AMT1"));

                // Get Delivery Numbers
                Map mapDeliveryLineNumber = new HashMap();
                mapDeliveryLineNumber.put(IMovexConnection.TRANSACTION, "LstDelLine");
                mapDeliveryLineNumber.put("CONO", mvxCompany);
                mapDeliveryLineNumber.put("ORNO", (String) mvxLine.get("ORNO"));
                mapDeliveryLineNumber.put("DLIX", (String) mvxLine.get("DLIX"));
                mapDeliveryLineNumber.put("WHLO", (String) mvxLine.get("WHLO"));

                IMovexApiResultset resDeliveryLineNumber = CustomStagesHelper.callMovex(context, movexInvoice,
                        mapDeliveryLineNumber, ConstantsForSales.MVXSTATUS);

                Iterator iterDeliveryNumber = resDeliveryLineNumber.iterator();

                while (iterDeliveryNumber.hasNext()) {

                    Map deliveryLineNumbers = (Map) iterDeliveryNumber.next();

                    // load parameters for Delivery Line
                    Map deliveryLine = new HashMap();
                    deliveryLine.put(IMovexConnection.TRANSACTION, "GetDelLine");
                    deliveryLine.put("CONO", mvxCompany);
                    deliveryLine.put("ORNO", (String) mvxLine.get("ORNO"));
                    deliveryLine.put("DLIX", (String) deliveryLineNumbers.get("DLIX"));
                    deliveryLine.put("WHLO", (String) deliveryLineNumbers.get("WHLO"));
                    deliveryLine.put("PONR", (String) deliveryLineNumbers.get("PONR"));
                    deliveryLine.put("POSX", (String) deliveryLineNumbers.get("POSX"));

                    IMovexApiResultset resDeliveryLine = CustomStagesHelper.callMovex(context, movexInvoice,
                            deliveryLine, ConstantsForSales.MVXSTATUS);

                    Iterator itrDeliveryLine = resDeliveryLine.iterator();

                    Map mapDeliveryLine = (Map) itrDeliveryLine.next();

                    XMLIterator rsDeliveryline = (XMLIterator) rsl.appendResultset("DeliveryLine");
                    rsDeliveryline.appendRow();
                    // Delivery Line
                    rsDeliveryline.appendField("LineNumber", (String) mapDeliveryLine.get("PONR"));
                    rsDeliveryline.appendField("ItemNumber", (String) mapDeliveryLine.get("ITNO"));
                    rsDeliveryline.appendField("ItemName", (String) mapDeliveryLine.get("ITDS"));
                    rsDeliveryline.appendField("BasicUnitofMeasure", (String) mapDeliveryLine.get("UNMS"));
                    rsDeliveryline.appendField("InvoicedQuantity", (String) mapDeliveryLine.get("QTY4"));
                    rsDeliveryline.appendField("SalesPrice", (String) mapDeliveryLine.get("SAPR"));
                    rsDeliveryline.appendField("OrderNumber", (String) mapDeliveryLine.get("ORNO"));
                    rsDeliveryline.appendField("LinePrice", (String) mapDeliveryLine.get("LNAM"));
                    rsDeliveryline.appendField("NetPrice", computeNetPrice((String) mapDeliveryLine.get("LNAM"),
                            (String) mapDeliveryLine.get("QTY4")));

                }

            }

            LOG.debug(rsInvoice.toString());
            context.setResponse(rsInvoice);

        } catch (Exception e) {
            throw new PipelineRuntimeException(e);
        } finally {

            closeMovexConnection();
        }

    }

    public boolean isDecimal(String number) {

        double testValue = 0;

        try {
            testValue = (Double.parseDouble(number));
        } catch (NumberFormatException e) {
            return false;
        }

        if (testValue > 0) {
            return true;
        } else {
            return false;
        }
    }

    private String getAddress(String orderNumber, String addressType, PipelineContext context) {

        StringBuffer address = new StringBuffer();

        IMovexApiResultset resOrderAddress;

        try {
            Map mapOrderAddress = new HashMap();
            mapOrderAddress.put(IMovexConnection.TRANSACTION, "GetAddress");
            mapOrderAddress.put("CONO", mvxCompany);
            mapOrderAddress.put("ORNO", orderNumber);
            mapOrderAddress.put("ADRT", addressType);
            resOrderAddress = CustomStagesHelper.callMovex(context, movexCustomerOrder, mapOrderAddress,
                    ConstantsForSales.MVXSTATUS);

            address.append(resOrderAddress.getParamAsString("CUA1")).append(", ").append(
                    resOrderAddress.getParamAsString("CUA2")).append(", ").append(
                    resOrderAddress.getParamAsString("CUA3")).append(", ").append(
                    resOrderAddress.getParamAsString("CUA4"));

        } catch (PipelineRuntimeException e) {

            LOG.error("There was error on Retrieving adress for Order Number: " + orderNumber + " Adress Type: "
                    + addressType);
        }

        return address.toString();

    }

    private void getRequestParameters(PipelineContext context) throws RequestException, ParametersException,
            PipelineRuntimeException {

        XMLRequest request = (XMLRequest) context.getRequest();

        LOG.debug(request.toString());
        XMLRequest.extractRequestParameters(request);
        parameters = request.getParameters();

        invoiceYear = parameters.getString("invoiceYear");
        invoiceNumber = parameters.getString("invoiceNumber");
        userGroupID = parameters.getString("userGroupID");
        // userGroupKey = parameters.getString("@UserGroupID");
        mvxCompany = parameters.getString("mvxCompany");
        mvxDivision = parameters.getString("mvxDivision");

        if ("".equalsIgnoreCase(invoiceYear) || invoiceYear == null) {
            throw new PipelineRuntimeException("Validation failed on: Invoice Year Required field is missing");
        }

        if (!isDecimal(invoiceYear)) {
            throw new PipelineRuntimeException(
                    "Validation failed on: Invoice year should only contain numeric characters");
        }

        if (invoiceYear.length() != 4) {
            throw new PipelineRuntimeException(
                    "Validation failed on: Invoice year should only contain 4 numeric characters");
        }

        if ("".equalsIgnoreCase(invoiceNumber) || invoiceNumber == null) {
            throw new PipelineRuntimeException("Validation failed on: Invoice Number Required field is missing");
        }

        if (!isDecimal(invoiceNumber)) {
            throw new PipelineRuntimeException(
                    "Validation failed on: Invoice number should only contain numeric characters");
        }

        LOG.debug("Invoice Number: " + invoiceNumber);
        LOG.debug("Invoice Year: " + invoiceYear);
        LOG.debug("Mvx Company: " + mvxCompany);
        LOG.debug("Mvx Division: " + mvxDivision);
        LOG.debug("User Group ID: " + userGroupID);

    }

    private void validateInvoiceNumberToESales() throws PipelineRuntimeException, ResultsetException {

        XMLResultset rsInvoiceList = null;
        SearchPipelineExecuter findInvoice = null;

        findInvoice = new SearchPipelineExecuter("com.intentia.iec.runtime.pipeline", "Invoice", "List");

        if (!isDecimal(invoiceNumber)) {
            LOG.fatal("Invalid Invoice number or Year");
            throw new PipelineRuntimeException("Invalid Invoice number or Year");
        }

        findInvoice.setParam("@UserGroupID", userGroupID);
        findInvoice.setBinding("Number", invoiceNumber, "eq");

        rsInvoiceList = findInvoice.execute();

        LOG.debug(rsInvoiceList.toString());

        LOG.debug("Invoice Header Row Count: " + rsInvoiceList.rowCount());

        if (rsInvoiceList.rowCount() == 0) {
            LOG.fatal("Invalid Invoice number or Year");
            throw new PipelineRuntimeException("Invalid Invoice number or Year");
        }

    }

    private String getVATInvoice(PipelineContext context) throws PipelineRuntimeException, ResultsetException {

        String VAT = "0";

        // Information type for VAT Invoice Line
        int VATInformationType = 40;

        // Load parameters for Invoice Lines
        Map mapVATInvoiceLine = new HashMap();
        mapVATInvoiceLine.put(IMovexConnection.TRANSACTION, "LstInvLineByTyp");
        mapVATInvoiceLine.put("CONO", mvxCompany);
        mapVATInvoiceLine.put("DIVI", mvxDivision);
        mapVATInvoiceLine.put("YEA4", invoiceYear);
        mapVATInvoiceLine.put("IVNO", invoiceNumber);
        mapVATInvoiceLine.put("IVTP", String.valueOf(VATInformationType));

        IMovexApiResultset resVATInvoiceline = CustomStagesHelper.callMovex(context, movexInvoice, mapVATInvoiceLine,
                ConstantsForSales.MVXSTATUS);

        LOG.debug("Invoice Line Size: " + resVATInvoiceline.size());

        if (resVATInvoiceline.size() == 0) {
            LOG.debug("No VAT found for invoice number: " + invoiceNumber);
        } else {
            VAT = resVATInvoiceline.getParamAsString("AMT1");
        }

        return VAT;

    }

    private String getAPIResultSetValue(IMovexApiResultset rsAPI, String paramSearchKey, String paramSearchValue,
            String paramKeyReturn) {
        Iterator rsIterator = rsAPI.iterator();
        String ret = "";
        while (rsIterator.hasNext()) {
            Map mvxLine = (Map) rsIterator.next();
            if (paramSearchValue.equals(mvxLine.get(paramSearchKey))) {
                ret = mvxLine.get(paramKeyReturn) == null ? "" : (String) mvxLine.get(paramKeyReturn);
                break;
            }
        }
        return ret;
    }

    private IMovexApiResultset getDiscountInvoice(PipelineContext context) throws PipelineRuntimeException,
            ResultsetException {

        // Information type for VAT Invoice Line
        int VATInformationType = 32;

        // Load parameters for Invoice Lines
        Map mapVATInvoiceLine = new HashMap();
        mapVATInvoiceLine.put(IMovexConnection.TRANSACTION, "LstInvLineByTyp");
        mapVATInvoiceLine.put("CONO", mvxCompany);
        mapVATInvoiceLine.put("DIVI", mvxDivision);
        mapVATInvoiceLine.put("YEA4", invoiceYear);
        mapVATInvoiceLine.put("IVNO", invoiceNumber);
        mapVATInvoiceLine.put("IVTP", String.valueOf(VATInformationType));

        IMovexApiResultset resVATInvoiceline = CustomStagesHelper.callMovex(context, movexInvoice, mapVATInvoiceLine,
                ConstantsForSales.MVXSTATUS);

        LOG.debug("Invoice Line Size: " + resVATInvoiceline.size());

        if (resVATInvoiceline.size() == 0) {
            LOG.debug("No Discount found for invoice number: " + invoiceNumber);
        }

        return resVATInvoiceline;
    }

    private String computeNetPrice(String lineAmount, String qty) {

        String netPrice = "0.0";

        try {
            netPrice = String.valueOf(Double.parseDouble(lineAmount) / Double.parseDouble(qty));
        } catch (NumberFormatException e) {
            LOG.error("Unable to compute net price");
        } catch (NullPointerException e) {
            LOG.error("Unable to compute net price");
        }

        return String.valueOf(netPrice);

    }

    private void initMovexConnection() throws PipelineRuntimeException {

        LOG.debug("Initilizing Movex Connection ...");

        movexInvoice = (IMovexConnection) CustomStagesHelper.getConnection("esales.OIS350MI");

        movexCustomer = (IMovexConnection) CustomStagesHelper.getConnection("esales.CRS610MI");

        movexCustomerOrder = (IMovexConnection) CustomStagesHelper.getConnection("esales.OIS100MI");

        if (movexInvoice == null) {
            throw new PipelineRuntimeException("Cannot create a connection to Movex");
        }

        if (movexCustomer == null) {
            throw new PipelineRuntimeException("Cannot create a connection to Movex");
        }

        if (movexCustomerOrder == null) {
            throw new PipelineRuntimeException("Cannot create a connection to Movex");
        }

    }

    private String getCustomerNameByID(PipelineContext context, String customerNumber) throws PipelineRuntimeException {

        String customerName = "";

        Map mapBasicCustomerInfo = new HashMap();
        mapBasicCustomerInfo.put(IMovexConnection.TRANSACTION, "GetBasicData");
        mapBasicCustomerInfo.put("CONO", mvxCompany);
        mapBasicCustomerInfo.put("CUNO", customerNumber);

        IMovexApiResultset resBasicCustomerInfo = CustomStagesHelper.callMovex(context, movexCustomer,
                mapBasicCustomerInfo, ConstantsForSales.MVXSTATUS);

        if (resBasicCustomerInfo.size() == 0) {
            LOG.debug("No Customer found for customer number: " + customerNumber);
        } else {
            customerName = resBasicCustomerInfo.getParamAsString("CUNM");
        }

        return customerName;

    }

    public boolean isValidDate(String date) {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy");
        Date testDate = null;

        try {
            testDate = sdf.parse(date);
        }

        catch (ParseException e) {
            return false;
        }

        if (!sdf.format(testDate).equals(date)) {
            return false;
        }

        return true;

    }

    private String getCustomerIDByOrderNumber(PipelineContext context, String orderNumberNumber)
            throws PipelineRuntimeException {

        String customerID = "";

        Map mapOrderHeader = new HashMap();
        mapOrderHeader.put(IMovexConnection.TRANSACTION, "GetHead");
        mapOrderHeader.put("ORNO", orderNumberNumber);

        IMovexApiResultset resOrderHeader = CustomStagesHelper.callMovex(context, movexCustomerOrder, mapOrderHeader,
                ConstantsForSales.MVXSTATUS);

        if (resOrderHeader.size() == 0) {
            LOG.debug("No Customer found for Order number: " + orderNumberNumber);
        } else {
            customerID = resOrderHeader.getParamAsString("CUNO");
        }

        return customerID;

    }

    private void closeMovexConnection() {

        LOG.debug("Closing All Movex Connection ...");

        if (movexInvoice != null) {
            try {
                movexInvoice.close();
            } catch (ConnectorException e) {
                LOG.error("Failed to close the connection!");
            }
        }

        if (movexCustomer != null) {
            try {
                movexCustomer.close();
            } catch (ConnectorException e) {
                LOG.error("Failed to close the connection!");
            }
        }

        if (movexCustomerOrder != null) {
            try {
                movexCustomerOrder.close();
            } catch (ConnectorException e) {
                LOG.error("Failed to close the connection!");
            }
        }

    }

}
