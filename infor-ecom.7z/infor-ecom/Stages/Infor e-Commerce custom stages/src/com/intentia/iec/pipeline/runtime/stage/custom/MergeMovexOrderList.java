/*
 * Created on 29-03-2004
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.intentia.iec.util.FastStringBuffer;
import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.output.Resultset;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.connection.ConnectorException;
import com.intentia.iec.connection.IMovexApiResultset;
import com.intentia.iec.connection.IMovexConnection;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;

/**
 * Stage to merge order status from Movex into a list of orders.
 * <p>
 * <b>Generated output in <code>PipelineContext</code>:</b><br>
 * Output parameter: <code>mvxStatus</code> (error if negative)
 * <p>
 */
public class MergeMovexOrderList implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(MergeMovexOrderList.class);

    /**
     * The stage entry point.
     * 
     * @see com.intentia.iec.pipeline.runtime.PipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
     */
    public void execute(final PipelineContext context) throws PipelineRuntimeException {

        // Movex connector not enabled => skip stage
        if (!"true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.CONNECTORENABLED))) {
            return;
        }

        XMLResultset order;
        int rows = 0;
        List headAttributes = null;

        try {
            order = (XMLResultset) context.getResponse();
            if ((order == null) || order.isEmpty()) {
                return;
            }
            rows = order.rowCount();
            order.moveFirst();
            headAttributes = order.getNames();
        } catch (ResultsetException e) {
            String msg = "Could not manipulate order resultset.";
            LOG.error(msg, e);
            throw new PipelineRuntimeException(msg, e);
        }

        // if no orders or order status not available
        if (rows < 1 || headAttributes == null || !headAttributes.contains(ConstantsForSales.ORDERSTATUS)) {
            return;
        }

        // Get a connection to Movex - if it fails we return from the stage
        // setting mvxStatus to -1010.
        IMovexConnection con = null;
        try {
            con = (IMovexConnection) CustomStagesHelper.getConnection(ConstantsForSales.OIS100MI);
        } catch (PipelineRuntimeException e) {
            con = null;
        }
        if (con == null) {
            LOG.error("Failed to connect to Movex");
            try {
                CustomStagesHelper.getResponseParameters(context).setint(ConstantsForSales.MVXSTATUS, -1010);
            } catch (ParametersException e) {
                LOG.error("Failed to set response parameters!");
            }
            return;
        }

        try {
            // loop and update orders
            order.beforeFirst();

            try {
                while (order.moveNext()) {
                    if (mergeHeader(context, con, null) == null) {
                        break;
                    }
                }

                if (LOG.isDebugEnabled()) {
                    FastStringBuffer msg = new FastStringBuffer("Response XML as merged from Movex:\n");
                    msg.append(context.getResponse().toString());
                    LOG.debug(msg.toString());
                }
            } catch (ResultsetException e) {
                String msg = "Could not loop orders";
                LOG.error(msg, e);
                throw new PipelineRuntimeException(msg, e);
            }
        } catch (PipelineRuntimeException e) {

            if (con == null) {
                // Assume that is was not possible to create a connection.
                LOG.error("Failed to connect to Movex", e);
            } else {
                // Otherwise throw the exception again.
                throw e;
            }
        } finally {
            if (con != null) {
                try {
                    con.close();
                } catch (ConnectorException e) {
                    LOG.error("Failed to close connection!");
                }
            }
            try {
                if ((order != null) && !order.isEmpty()) {
                    // Reset the position in the resultset so it is correct for
                    // the next use.
                    order.beforeFirst();
                }
            } catch (ResultsetException e) {
                LOG.error("Failed to reset order resultset!", e);
            }
        }
    }

    /**
     * Get parameter value by name from parameter block in context.
     * 
     * @param parameterName
     *            name of the requested paramerer
     * @param params
     *            pipeline request parameters including requested parameter
     * @return the parameter value as a string
     */
    protected String getString(final String parameterName, final Parameters params) {
        try {
            return params.getString(parameterName);
        } catch (ParametersException e) {
            LOG.error("Try to get parameter: " + parameterName);
            return "";
        }
    }

    /**
     * Get attribute value by name from resultset in context.
     * 
     * @param attributeName
     *            name of the requested paramerer
     * @param rs
     *            resultset including requested parameter
     * @return the parameter value as a string
     * @throws PipelineRuntimeException
     */
    protected String getString(final String attributeName, final Resultset rs) throws PipelineRuntimeException {
        try {
            return (String) rs.getString(attributeName);
        } catch (ResultsetException e) {
            String msg = "Missing attribute: " + attributeName;
            LOG.error(msg, e);
            throw new PipelineRuntimeException(msg, e);
        }
    }

    /**
     * Update attribute in resultset with a value from a Movex API resultset.
     * <p>
     * Uses current position in both resultsets.
     * 
     * @param rs
     *            resultset to update
     * @param rsPar
     *            name on attribute in resultset
     * @param apiRes
     *            Movex API resultset to be used as source
     * @param apiPar
     *            name on field in Movex API resultset
     * @param defVal
     *            default value to use if field is missing
     * @return the new value or null if update failed.
     */
    protected String updRsAttr(XMLResultset rs, String rsPar, IMovexApiResultset apiRes, String apiPar, String defVal) {
        return CustomStagesHelper.updateRsAttribute(rs, rsPar, apiRes, apiPar, defVal);
    }

    /**
     * Merge order header information from Movex into local resultset.
     * <p>
     * Calls Movex API OIS100MI/GetHead.<br>
     * 
     * @param context
     *            pipeline context
     * @param con
     *            Movex connection
     * @return Movex API resultset created for merge
     * @throws PipelineRuntimeException
     */
    protected IMovexApiResultset mergeHeader(PipelineContext context, IMovexConnection con, final String orderID)
            throws PipelineRuntimeException {

        XMLResultset order = (XMLResultset) context.getResponse();

        // get CONO, ORNO for a Movex call using OIS100MI:GetHead
        Map header = new HashMap();
        header.put(IMovexConnection.TRANSACTION, ConstantsForSales.GET_HEAD);
        header.put(ConstantsForSales.CONO, getString(ConstantsForSales.MVXCOMPANY, order));
        header.put(ConstantsForSales.ORNO, (orderID != null) ? orderID : getString(ConstantsForSales.ORDERID, order));

        // retrieve order header data from Movex
        IMovexApiResultset apiRes = CustomStagesHelper.callMovex(context, con, header, ConstantsForSales.MVXSTATUS);
        if (apiRes != null) {
            // update Order header.
            String defaultVal = "0";

            updRsAttr(order, ConstantsForSales.ORDERSTATUS, apiRes, ConstantsForSales.STAT, defaultVal);
            updRsAttr(order, ConstantsForSales.ORDERLINELOSTATUSID, apiRes, ConstantsForSales.ORSL, defaultVal);
            updRsAttr(order, ConstantsForSales.ORDERLINEHISTATUSID, apiRes, ConstantsForSales.ORST, defaultVal);
        }

        return apiRes;
    }
}
