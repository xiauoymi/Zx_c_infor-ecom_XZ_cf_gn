/*
 * Created on 27-12-2005
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.util.HashMap;
import java.util.Map;

/**
 * String constants for parameters, attributes, Movex fields, etc. used in
 * programming the e-Sales order stages.
 */
public final class ConstantsForSales {

    /*
     * Package / or path for classes
     */
    public static final String PIPELINE_PACKAGE = "com.intentia.iec.runtime.pipeline";

    /*
     * Request / Response XML Header
     */
    public static final String XML_DATA_HEADER = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
    
    /*
     * Application property file names
     */

    public static final String APP_PROP_FILENAME = "/application.properties";

    public static final String APPLICATION_DATA = "ApplicationData";

    public static final String APPLICATION_DATA_DETAILS = "Details";

    /*
     * String constants for fetching database connection names from connection
     * properties. The key is made from customStageConnectKey (lower case) +
     * connection type.
     */
    public static final String DATABASE_CONNECTION_KEY = "esales.cursor";

    public static final String SMS_DATABASE_CONNECTION_KEY = "salestool.cursor";

    /*
     * String constants for fetching Movex connection names from connection
     * properties. The key is made from customStageConnectKey (lower case) +
     * APIname.
     */
    public static final String OIS100MI = "esales.OIS100MI";

    public static final String CRCCINMI = "esales.CRCCINMI";

    public static final String OIS840MI = "esales.OIS840MI";

    public static final String OIS005MI = "esales.OIS005MI";

    /*
     * String constants for application properties used for controlling the
     * behavior of the e-Sales order stages. (in alphabetic order)
     */

    // The main switch for the Movex connection. If missing or false no calls
    // are made to Movex and the stages returns immediately.
    public static final String CONNECTORENABLED = "Movex Connector.Enable";

    public static final String CREATENEWCUSTOMER = "Movex Connector.Create New Customer";

    public static final String CONFIRM_STAT_POSITION = "Movex Ordering.Confirm NOK Status Position";

    public static final String CONFIRM_MESSAGE_POSITION = "Movex Ordering.Confirm NOK Message Position";

    public static final String DOCUMENTCLASS = "Movex Ordering.Comment Document Class";

    public static final String DISCOUNTMODEL = "Movex Ordering.Discount Model";

    public static final String INITIAL_ORDER_STATUS = "Ordering.Initial Order Status";

    public static final String JOINTDELIVERYCODE = "Movex Ordering.Joint Delivery Code";

    public static final String MAP_CITY_TO = "Movex Ordering.Map City to Movex Field";

    public static final String MERGESHIPPINGADDRESS = "Movex Ordering.Merge Shipping Address";

    public static final String UPDATINGORDERLINES = "Movex Ordering.Update OrderLine IDs";

    public static final String USERDEFINEDSHIPPINGADDRESS = "Shipping address.User Defined";

    public static final String PROMOTIONS = "Movex Ordering.Promotions";

    public static final String ESALESSIMULATE = "ESASIMULATE";

    public static final String SIMULATE_ORDER_CUST_ORNO = "SimulateRequireCUOR";
    
    public static final String M3_PROMOTIONS_ENABLED = "Application.M3 Promotions Enabled";
    
    public static final String SIMULATE_ORDER = "Movex Ordering.Simulate Order";
    
    
    /*
     * String constants for parameters in Application Data / Details.
     */
    public static final String APPLICATION_URL = "ApplicationUrl";
    
    public static final String PROMOTION_DISCOUNT_MODEL = "DiscountModel";

    /*
     * String constants for user activity
     */
    
    public static final String APPLICATION_USER_ACTIVITY_THRESHOLD = "UserActivityCleanupThreshold";
    
    public static final String APPLICATION_USER_ACTIVITY_THRESHOLD_DEF = "10";
    
    
    // e-mail address to send notification on Movex order error
    public static final String MAIL_RECEIEVER_FOR_ORDER_ERROR = "MailReceiverForOrderError";

    // Movex Order Status
    public static final String INVALID_ORDERLINE_STAT = "25";

    public static final String EXCEED_CREDIT_LIMIT_STAT = "30";
    
    public static final String EXCEED_CREDIT_LIMIT_ERR_CODE = "XCR2402";
    
    //Movex Discount Origin
    
    public static final String DISCOUNT_ORIGIN_MANUAL_8 = "8";
    
    
    //TEXT TYPE
    public static final String ORDERLINE_TEXT_2 = "2";
    
    public static final String PRE_TEXT_1 = "1";
    public static final String POST_TEXT_2 = "2";

    /*
     * Input parameters (in alphabetic order)
     */    
    
    public static final String ALT_EXCHANGE_RATE_PARAM = "altExchangeRate";
    
    public static final String APPROVER_FEATURE_ID_PARAM = "@apprfeatureID";
    
    public static final String ACTION_TYPE_PARAM = "actionType";

    public static final String CODE_PARAM = "code";

    public static final String CODE_TYPE_PARAM = "codeType";

    public static final String CURRENCYCODE_PARAM = "@CurrencyCode";
    
    public static final String CURRENT_ORDERID_PARAM = "currentOrderID";

    public static final String CUSTOMERITEMID = "CustomerItemID";
    
    public static final String UPDATE_SOURCE_PARAM = "updateSource";
    
    public static final String EXCHANGE_RATE_PARAM = "exchangeRate";

    public static final String EXCLUDED_ORDER_STATUS_PARAM = "excludedOrderStatus";

    public static final String INDEX_NAME_PARAM = "indexName";

    public static final String IS_MERCHANT_ADMIN_PARAM = "isMerchantAdmin";

    public static final String IS_VISIBLE_PARAM = "isVisible";

    public static final String LANGUAGE_CODE_PARAM = "languageCode";

    public static final String LANGUAGE_CODE_SQL_PARAM = "@LanguageCode";

    public static final String LISTPRICEGROUP_PARAM = "@ListPriceGroup";

    public static final String MVXCOMPANY_PARAM = "mvxCompany";

    public static final String MVXFACILITY_PARAM = "mvxFacility";

    public static final String MVXORDERTYPE_PARAM = "mvxOrderType";

    public static final String MVXWAREHOUSE_PARAM = "mvxWareHouse";
    
    public static final String NOT_ADMIN_QUOTE = "notAdminQuotes";

    public static final String ORDERID_PARAM = "orderId";
    
    public static final String ORDER_ID_PARAM = "orderID";
    
    public static final String ORDERLINESTATUS_PARAM = "orderLineStatus";
    
    public static final String ORDERLINEAVAILABLE_PARAM = "orderLineAvailable";
    
    public static final String PREVIOUS_ORDERID_PARAM = "previousOrderID";

    public static final String ITEMID_PARAM = "itemID";

    public static final String ITEMNUMBER = "ItemNumber";

    public static final String ITEM_NUMBER_PARAM = "@ItemNumber";

    public static final String ITEMNAME = "ItemName";

    public static final String MVXCONFIGURABLENUMBER_PARAM = "mvxConfigurableNumber";

    public static final String QUERY_STRING_PARAM = "queryString";

    public static final String REQUESTEDDELIVERYDATE_PARAM = "requestedDeliveryDate";

    public static final String RESOLVE_BASKET = "resolveBasket";
    
    public static final String RUN_SCHEDULE_JOB_NOW = "runScheduleJobNow";

    public static final String SIMULATE_PARAM = "simulate";

    public static final String SIMULATE_VALIDATOR_PARAM = "SimulateOrderValidated";

    public static final String SIMULATE_EXECUTE_SUBMIT = "executeSubmit";

    public static final String SIMULATE_EXECUTE_MERGE = "executeMerge";

    public static final String SKIP_GET_DEATAILS_STAGE_PARAM = "skipGetDetailsStage";

    public static final String SKIP_SEARCH_STAGE_PARAM = "skipSearchStage";

    public static final String SKIP_SORITNG_RESULT_PARAM = "skipSortingResult";

    // specify if order line validation is needed ("Y")
    public static final String VALIDATE_ORDER_LINES = "ValidateOrderLines";

    // Credit Card Authorization related parameters.
    public static final String TERMS_OF_PAYMENT = "termsofpayment";

    public static final String CREDIT_CARD_NUMBER = "creditCardNumber";

    public static final String CARD_EXPIRY_DATE = "cardExpiryDate";

    public static final String CARD_SECURITY_CODE = "cardSecurityCode";

    public static final String PAYCD = "PaymentCode";

    public static final String REBUILD_INDEX_PARAM = "rebuildIndex";

    public static final String USER_GROUP_KEY_PARAM = "userGroupKey";
    
    public static final String USER_ID_PARAM = "@UserID";

    public static final String WHERE_IN_PARAM = "@WhereIn";
    
    public static final String _MVXWAREHOUSE_PARAM = "@MvxWarehouse";
    
    public static final String _USERGROUPID_PARAM = "@UserGroupID";

    /*
     * Output parameters (in alphabetic order)
     */
    public static final String APIERRORMESSAGE = "apiErrorMessage";

    public static final String CREDITCARDAUTHSTATUS = "creditCardAuthStatus";

    public static final String CURRENCY = "Currency";

    public static final String GENERATEDORDERNO = "generatedOrderNo";

    public static final String MVXSTATUS = "mvxStatus";

    public static final String TRANSACTIONREFERENCENUMBER = "TransactionReferenceNumber";

    public static final String SUBMITTEDORDERID = "submittedOrderID";

    public static final String STATUS = "status";

    public static final String THIRDPARTYPROVIDER = "thirdPartyProvider";

    public static final String TOTAL_SEARCH_COUNT_PARAM = "TotalSearchCount";

    /*
     * Attributes on User business object.
     */
    public static final String USER_ID_ATTRIBUTE = "UserID";

    public static final String EMAIL_ATTRIBUTE = "Email";

    public static final String EMAIL_ID_ATTRIBUTE = "EmailID";

    public static final String FIRST_NAME_ATTRIBUTE = "FirstName";

    public static final String MIDDLE_NAME_ATTRIBUTE = "MiddleName";

    public static final String LAST_NAME_ATTRIBUTE = "LastName";

    public static final String PHONE_ATTRIBUTE = "Phone";

    public static final String MASTER_USERGROUP_KEY_ATTRIBUTE = "MasterUserGroupID";

    public static final String MASTER_USERGROUP_NAME_ATTRIBUTE = "MasterUserGroupName";

    public static final String DEFAULT_USERGROUP_KEY_ATTRIBUTE = "DefaultUserGroupID";

    public static final String PASSWORD_ATTRIBUTE = "Password";

    public static final String LOCALE_ATTRIBUTE = "LocaleID";

    public static final String PROMPT_FOR_ORDERLINE_DETAILS_ATTRIBUTE = "PromptForOrderLineDetails";

    public static final String SHOW_ALT_CURRENCY_ATTRIBUTE = "ShowAltCurrency";

    public static final String PARTIAL_ORDERS_ATTRIBUTE = "PartialOrders";

    public static final String WISH_TO_BE_RESELLER_ATTRIBUTE = "WishToBeReseller";

    public static final String USER_NAME_ATTRIBUTE = "UserName";
    
    /*
     * Business object name and subset. (in alphabetic order)
     */
    public static final String PROMOTION = "Promotion";
    
    public static final String SELECTED_PROMOTIONS = "Promotions";
    
    public static final String PROMOTION_LIST = "PromotionList";
    
    public static final String RULES = "Rules";
    
    public static final String VALUE = "Value";
    
    public static final String EXTRA_VALUE = "ExtraValue";
    
    public static final String ITEM = "Item";
    
    public static final String PRODUCT = "Product";
    
    public static final String PRODUCT_ID = "ProductID";
    
    public static final String NAME = "Name";
    
    public static final String CAMPAIGN_ID = "CampaignID";
    
    public static final String PROMOTION_INTERNAL_NAME ="InternalName";
    
    /*
     * Business object attributes. (in alphabetic order)
     */
    public static final String ACCEPTPARTIAL = "AcceptPartial";

    public static final String ACTION_ATTRIBUTE = "Action";

    public static final String APPROVAL_LIMIT_ATTRIBUTE = "ApprovalLimit";

    public static final String ATPDATE = "ATPDate";

    public static final String CATEGORY_ID_ATTRIBUTE = "CategoryID";
    
    public static final String CHANGE_ORDER_ACTION = "ChangeOrderAction";
    
    public static final String CHANGE_ORDER_STATUS = "ChangeOrderStatus";

    public static final String CODE_ATTRIBUTE = "Code";

    public static final String CODE_ID_ATTRIBUTE = "CodeID";

    public static final String COMMENT = "Comment";

    public static final String COMMENTTEXT = "CommentText";

    public static final String COMPANYID = "CompanyID";

    public static final String COUNTRY_ID_ATTRIBUTE = "CountryID";

    public static final String CONFIRMEDDELIVERYDATE = "ConfirmedDeliveryDate";

    public static final String CREDITCARDTYPE = "CreditCardType";

    public static final String CUSTOMERORDERNO = "CustomerOrderNo";

    public static final String CURRENCYID = "CurrencyID";

    public static final String CURRENTORDERID = "CurrentOrderID";

    public static final String DELIVEREDQUANTITY = "DeliveredQuantity";

    public static final String DISCOUNTAMOUNT = "DiscountAmount";

    public static final String DISCOUNTAMOUNT1 = "DiscountAmount1";

    public static final String DISCOUNTAMOUNT2 = "DiscountAmount2";

    public static final String DISCOUNTAMOUNT3 = "DiscountAmount3";

    public static final String DISCOUNTAMOUNT4 = "DiscountAmount4";

    public static final String DISCOUNTAMOUNT5 = "DiscountAmount5";

    public static final String DISCOUNTAMOUNT6 = "DiscountAmount6";
    
    public static final String FIELD_CODE = "FieldCode";

    public static final String GRANDTOTAL = "GrandTotal";
    
    public static final String HAS_TAKEAWAY = "HasTakeAway";

    public static final String ID_ATTRIBUTE = "ID";

    public static final String INDEX_KEY_FIELD_ATTRIBUTE = "IndexKeyField";

    public static final String INDEX_NAME_ATTRIBUTE = "IndexName";

    public static final String INDEXER_CLASSNAME_ATTRIBUTE = "IndexerClassName";

    public static final String INTERNAL_NAME_ATTRIBUTE = "InternalName";

    public static final String ISLISTPRICE = "IsListPrice";

    public static final String IS_OPTIMIZED_ATTRIBUTE = "IsOptimized";
    
    public static final String IS_ACTIVE = "IsActive";
    
    public static final String IS_VISIBLE = "IsVisible";

    public static final String ITEMID = "ItemID";
    
    public static final String ITEM_IMAGES = "ItemImages";
    
    public static final String ITEM_DESCRIPTION = "Description";
    
    public static final String ITEM_IMAGE_THUMB = "ItemImageThumb";

    public static final String ITEM_TAX = "ItemTax";
    
    public static final String KEY_ATTRIBUTE = "Key";

    public static final String LAST_MODIFIED_DATE_ATTRIBUTE = "LastModifiedDate";

    public static final String LINEDISCOUNT = "LineDiscount";

    public static final String LANGUAGE_CODE_ATTRIBUTE = "LanguageCode";

    public static final String LANGUAGE_ID_ATTRIBUTE = "LanguageID";

    public static final String LINEDISPERCENT = "LineDisPercent";

    public static final String LINENUMBER = "LineNumber";

    public static final String LINEPRICE = "LinePrice";

    public static final String LINESUFFIX = "LineSuffix";

    public static final String LINETAX = "LineTax";

    public static final String LINETOTAL = "LineTotal";
    
    public static final String LINEDISTRIBUTEDCHARGEAMOUNT = "DistributedChargeAmount";
    
    public static final String LINEEXTENDEDAMOUNT = "LineExtendedAmount";

    public static final String LISTPRICE = "ListPrice";

    public static final String LISTPRICEGROUPID = "ListPriceGroupID";

    public static final String LOG_ID_ATTRIBUTE = "LogID";

    public static final String MINIMUM_QTY = "MinimumQty";
    
    public static final String MODULAR_QTY = "ModularQty";
    
    public static final String MVXCOMPANY = "MvxCompany";

    public static final String MVXCONFIGURABLENUMBER = "MvxConfigurableNumber";
    
    public static final String MVX_CONFIGURABLE_ID = "MvxConfigurableID";

    public static final String MVXDIVISION = "MvxDivision";

    public static final String MVXFACILITY = "MvxFacility";

    public static final String MVXORDERTYPE = "MvxOrderType";
    
    public static final String MVXORDERTYPESO = "MvxOrderTypeSO";

    public static final String MVXSHIPPINGADDRESSID = "MvxShippingAddressID";

    public static final String MVXWAREHOUSE = "MvxWarehouse";

    public static final String NUMBER_OF_RECORDS_ATTRIBUTE = "NumberOfRecords";

    public static final String NUMBER_OF_FIELDS_ATTRIBUTE = "NumberOfFields";

    public static final String NUMBER_OF_TERMS_ATTRIBUTE = "NumberOfTerms";
    
    public static final String OPERATOR_CODE = "OperatorCode";
    
    public static final String OPERATOR_TEXT = "OperatorText";

    public static final String ORDERHEADERDISCOUNT = "OrderHeaderDiscount";

    public static final String ORDERID = "OrderID";

    public static final String ORDERDATE = "OrderDate";

    public static final String ORDERLINE = "OrderLine";

    public static final String ORDERLINECOMMENT = "OrderLineComment";

    public static final String ORDERLINEHISTATUSID = "OrderLineHiStatusID";

    public static final String ORDERLINEID = "OrderLineID";

    public static final String ORDERLINELOSTATUSID = "OrderLineLoStatusID";

    public static final String ORDERSTATUS = "OrderStatus";

    public static final String ORDERLINESTATUS = "OrderLineStatus";

    public static final String ORDERLINESTATUSID = "OrderLineStatusID";

    public static final String ORDERTOTALTOPAY = "OrderTotalToPay";

    public static final String OWNREFNO = "OwnRefNo";

    public static final String PAYMENTCODE = "PaymentCode";
    
    public static final String PROMOTION_CODE = "PromotionCode";
    
    public static final String PROMOTION_ID = "PromotionID";
    
    public static final String PROMOTIONS_ATTRIBUTE = "Promotions";

    public static final String QUANTITY = "Quantity";

    public static final String QUANTITYSALESPRICE = "QuantitySalesPrice";

    public static final String REMAININGQUANTITY = "RemainingQuantity";

    public static final String REQUESTEDDELIVERYDATE = "RequestedDeliveryDate";

    public static final String REQUESTEDQUANTITY = "requestedQuantity";

    public static final String RESELLPRICE = "ResellPrice";

    public static final String ROLE_ID_ATTRIBUTE = "RoleID";

    public static final String ROLE_NAME_ATTRIBUTE = "Name";

    public static final String ROUNDINGOFF = "RoundingOff";
    
    public static final String RULE_CODE = "RuleCode";

    public static final String SHADOWORDERID = "ShadowOrderID";

    public static final String SALESPRICE = "SalesPrice";

    public static final String SEARCH_ROW_NUMBER_ATTRIBUTE = "SearchRowNumber";

    public static final String SEARCH_HIT_SCORE_ATTRIBUTE = "SearchHitScore";

    public static final String SENDER_ID_ATTRIBUTE = "SenderID";

    public static final String SHIPPINGADDRESS1 = "ShippingAddress1";

    public static final String SHIPPINGADDRESS2 = "ShippingAddress2";

    public static final String SHIPPINGADDRESS3 = "ShippingAddress3";

    public static final String SHIPPINGADDRESS4 = "ShippingAddress4";

    public static final String SHIPPINGADDRESSID = "ShippingAddressID";

    public static final String SHIPPINGCITY = "ShippingCity";

    public static final String SHIPPINGCOMPANY = "ShippingCompany";

    public static final String SHIPPINGCOUNTRY = "ShippingCountry";
    
    public static final String SHIPPINGCOUNTRYNAME = "ShippingCountryName";

    public static final String SHIPPINGCOUNTRYID = "ShippingCountryID";

    public static final String SHIPPINGMETHODID = "ShippingMethodID";
    
    public static final String SHIPPINGNAME = "ShippingName";
    
    public static final String SHIPPINGREGION = "ShippingRegion";

    public static final String SHIPPINGSTATEID = "ShippingStateID";
    
    public static final String SHIPPINGZIP = "ShippingZip";

    public static final String SKU = "SKU";
    
    public static final String STATUS_ATTRIBUTE = "Status";
    
    public static final String TEXT_ATTRIBUTE = "Text";

    public static final String TMPORDERID = "TmpOrderID";

    public static final String TOTALDELIVERYFEE = "TotalDeliveryFee";

    /* 6787 Service Charge fix */
    public static final String TOTALCHARGEDESC = "TotalChargeDesc";

    public static final String TOTALDISCOUNT = "TotalDiscount";

    public static final String TOTALPRICE = "TotalPrice";
    
    public static final String TOTAL_LINE_DISCOUNT = "TotalLineDiscount";
    
    public static final String TOTALQUANTITY = "TotalQuantity";

    public static final String TOTALSHIP = "TotalShip";

    public static final String TOTALTAX = "TotalTax";

    public static final String UNITCODE = "UnitCode";

    public static final String UNITCODEID = "UnitCodeID";

    public static final String UNIT = "Unit";

    public static final String USECID = "UseCID";

    public static final String USERGROUPID = "UserGroupID";

    public static final String USERGROUPKEY = "UserGroupKey";

    public static final String YOURREFERENCE = "YourReference";

    /*
     * Movex API function names.
     */

    public static final String ADD = "Add"; // Add Item Per Customer (CID)

    public static final String ADD_AUTH = "AddAuth";

    public static final String ADD_BATCH_ADDRESS = "AddBatchAddress";

    public static final String ADD_BATCH_HEAD = "AddBatchHead";

    public static final String ADD_BATCH_LINE = "AddBatchLine";

    public static final String ADD_BATCH_TEXT = "AddBatchText";

    public static final String ADD_VOID = "AddVoid";

    public static final String AUTH_CREDIT_CARD = "AuthCreditCard";

    public static final String CONFIRM = "Confirm";

    public static final String DEL = "Del"; // Delete Item Per Customer (CID)

    public static final String DEL_BATCH_HEAD = "DelBatchHead";

    public static final String DEL_HEAD = "DelHead";

    public static final String DEL_LINE = "DelLine";

    public static final String GET = "Get"; // Get Item Per Customer (CID)

    public static final String GET_ADDRESS = "GetAddress";

    public static final String GET_HEAD = "GetHead";

    public static final String GET_ORDER_NO = "GetOrderNo";

    public static final String GET_ORDER_VALUE = "GetOrderValue";

    public static final String GET_VALIDATE_INFO = "GetValidateInfo";

    public static final String LST_LINE = "LstLine";

    public static final String LST_ERR_MSG = "LstErrMsgOrder";

    public static final String CHECK_CREDIT = "CheckCredit";

    public static final String GET_LINE_TEXT = "GetLineText";

    /*
     * Movex API parameter names. (in alphabetic order)
     */
    public static final String ADID = "ADID";

    public static final String ADRT = "ADRT";

    public static final String ALUN = "ALUN";

    public static final String AVTD = "AVTD";

    public static final String BRAM = "BRAM";

    public static final String CFIN = "CFIN";

    public static final String CONO = "CONO";

    public static final String CSCD = "CSCD";

    public static final String CUA1 = "CUA1";

    public static final String CUA2 = "CUA2";

    public static final String CUA3 = "CUA3";

    public static final String CUA4 = "CUA4";

    // Customer�s purchase order date
    public static final String CUDT = "CUDT";

    public static final String CUNM = "CUNM";

    public static final String CUNO = "CUNO";

    public static final String CUPO = "CUPO";

    public static final String CUOR = "CUOR";

    public static final String DIA1 = "DIA1";

    public static final String DIA2 = "DIA2";

    public static final String DIA3 = "DIA3";

    public static final String DIA4 = "DIA4";

    public static final String DIA5 = "DIA5";

    public static final String DIA6 = "DIA6";
    
    public static final String DICD = "DICD";

    public static final String DISY = "DISY";
    
    public static final String DRDN = "DRDN";

    public static final String DRDL = "DRDL";

    public static final String DRDX = "DRDX";

    public static final String DWDT = "DWDT";

    public static final String DWDZ = "DWDZ";

    public static final String ECAR = "ECAR";

    public static final String EFAM = "EFAM";

    public static final String EXAM = "EXAM";

    /* 6787 Service Charge fix */
    public static final String EXTX = "EXTX";

    // e-Sales order value in OIS100MI.AddBatchHead.
    // Set value to "1" to simulate order.
    public static final String CCEC = "CCEC";

    public static final String CSC2 = "CSC2";

    public static final String CSC1 = "CSC1";

    public static final String CUCD = "CUCD";

    public static final String ESOV = "ESOV";

    public static final String FACI = "FACI";

    public static final String ITNO = "ITNO";

    public static final String ITDS = "ITDS";

    public static final String IVQT = "IVQT";

    public static final String DLQT = "DLQT";

    public static final String JDCD = "JDCD";

    public static final String LNAM = "LNAM";

    public static final String MODL = "MODL";

    public static final String MOD1 = "MOD1";

    public static final String NEPR = "NEPR";

    public static final String NLAM = "NLAM";

    public static final String NTAM = "NTAM";

    public static final String ODAM = "ODAM";

    public static final String ONET = "ONET";

    public static final String ORDT = "ORDT";

    public static final String ORNO = "ORNO";

    public static final String ORNR = "ORNR";

    public static final String ORQA = "ORQA";

    public static final String ORQT = "ORQT";

    public static final String ORSL = "ORSL";

    public static final String ORST = "ORST";

    public static final String ORTP = "ORTP";

    public static final String OTBA = "OTBA";

    public static final String OTDP = "OTDP";

    public static final String PARM = "PARM";

    public static final String PLTB = "PLTB";

    public static final String PONO = "PONO";

    public static final String PONR = "PONR";

    public static final String POPN = "POPN";

    public static final String PRRF = "PRRF";

    public static final String POSX = "POSX";

    public static final String PYCD = "PYCD";

    public static final String RIDN = "RIDN";

    public static final String RIDL = "RIDL";

    public static final String RIDX = "RIDX";

    public static final String RLDT = "RLDT";

    public static final String RLDZ = "RLDZ";

    public static final String ROAM = "ROAM";

    public static final String SACD = "SACD";

    public static final String SAPR = "SAPR";

    public static final String SPUN = "SPUN";

    public static final String STAT = "STAT";

    public static final String TEDL = "TEDL";

    public static final String TEL1 = "TEL1";

    public static final String TEPY = "TEPY";

    public static final String TOPY = "TOPY";

    public static final String TOWN = "TOWN";

    public static final String TXHE = "TXHE";

    public static final String TYPE = "TYPE";

    public static final String TXPY = "TXPY";

    public static final String TYTR = "TYTR";

    public static final String VTAM = "VTAM";

    public static final String WHLO = "WHLO";

    public static final String YREF = "YREF";

    // CRCCINMI.GetValidateInfo CRCCINMI.AddAuth
    public static final String CANU = "CANU";

    public static final String CCAA = "CCAA";

    public static final String CTPY = "CTPY";

    public static final String DIVI = "DIVI";

    public static final String EXP0 = "EXP0";

    public static final String NREF = "NREF";

    public static final String RORC = "RORC";

    public static final String TRDP = "TRDP";

    // OIS100MI.GetOrderValue
    public static final String INET = "INET";

    public static final String INTA = "INTA";

    public static final String IDAM = "IDAM";

    public static final String IXAM = "IXAM";

    public static final String IFAM = "IFAM";

    public static final String IRVA = "IRVA";

    public static final String IVTA = "IVTA";

    public static final String ITOA = "ITOA";

    public static final String IROA = "IROA";

    public static final String ITOP = "ITOP";

    public static final String IRAM = "IRAM";

    public static final String ISUM = "ISUM";

    public static final String ITPR = "ITPR";

    public static final String TX60 = "TX60";

    public static final String MDTA = "MDTA";

    public static final String CODT = "CODT";

    // PCM Fields for PCM - E-Sales Integration

    public static final String PCM_CATALOG = "catalog";

    public static final String PCM_STRUCTURE = "structure";

    public static final String PCM_PRODUCT = "product";

    public static final String PCM_ARTICLE = "article";

    // ShadowOrder Attributes
    public static final String BATCH_NUMBER = "BatchNumber";

    public static final String CHARGE = "Charge";

    public static final String CHARGE_TEXT = "ChargeText";

    public static final String COMPANY_ID = "CompanyID";

    public static final String COMPANY_NAME = "CompanyName";

    public static final String CURRENCY_CODE = "CurrencyCode";
    
    public static final String CURRENCY_RATE = "CurrencyRate";

    public static final String CURRENT_ORDER_ID = "CurrentOrderID";

    public static final String CUSTOMER_ORDER_NO = "CustomerOrderNo";

    public static final String DELIVERY_METHOD = "DeliveryMethod";

    public static final String DELIVERY_METHOD_TEXT = "DeliveryMethodText";

    public static final String DELIVERY_TERMS = "DeliveryTerms";

    public static final String DELIVER_TERMS_TEXT = "DeliveryTermsText";

    public static final String DISCOUNT_PERCENT = "DiscountPercent";

    public static final String EXTERNAL_CHARGE = "ExternalCharge";

    public static final String GROSS_ORDER_VALUE = "GrossOrderValue";

    public static final String MVX_COMPANY = "MvxCompany";

    public static final String MVX_ORDER_TYPE = "MvxOrderType";

    public static final String MVX_WAREHOUSE = "MvxWarehouse";

    public static final String NET_ORDER_AMOUNT = "NetOrderAmount";

    public static final String ORDER_DATE = "OrderDate";

    public static final String ORDER_DISCOUNT = "OrderDiscount";

    public static final String ORDER_NUMBER = "OrderNumber";

    public static final String ORDER_DISCOUNT_AMOUNT = "OrderDiscountAmount";

    public static final String ORDER_LINE_DISCOUNT_AMOUNT = "OrderLineDiscountAmount";

    public static final String PAYMENT_TERMS = "PaymentTerms";

    public static final String PAYMENT_TERMS_TEXT = "PaymentTermsText";

    public static final String PRICE_LIST_TABLE = "PriceListTable";

    public static final String PURCHASE_ORDER_DATE = "PurchaseOrderDate";

    public static final String REQUESTED_DELIVERY_DATE = "RequestedDeliveryDate";

    public static final String ROUNDING_OFF = "RoundingOff";

    public static final String SHADOW_ORDER_ID = "ShadowOrderID";

    public static final String TIMESTAMP = "TimeStamp";

    public static final String TOTAL = "Total";

    public static final String VAT_AMOUNT = "VatAmount";

    // ShadowOrderLine Attributes
    
    public static final String SHADOW_ORDERLINE = "ShadowOrderLine"; 
    public static final String ALIAS = "Alias";

    public static final String BATCH_LINE_NUMBER = "BatchLineNumber";
    
    public static final String BATCH_ORDER_NUMBER = "BatchOrderNumber";

    public static final String CONFIRMED_DELIVERY_DATE = "ConfirmedDeliveryDate";

    public static final String CURRENT_ORDER_LINE = "CurrentOrderLine";

    public static final String CUSTOMER_LINE_NUMBER = "CustomerLineNumber";

    public static final String CUSTOMER_ORDER_NUMBER = "CustomerOrderNumber";

    public static final String DEMAND_LINE_NO = "DemandLineNo";

    public static final String DEMAND_ORDER_NO = "DemandOrderNo";

    public static final String DISCOUNT1 = "Discount1";

    public static final String DISCOUNT2 = "Discount2";

    public static final String DISCOUNT3 = "Discount3";

    public static final String DISCOUNT4 = "Discount4";

    public static final String DISCOUNT5 = "Discount5";

    public static final String DISCOUNT6 = "Discount6";

    public static final String ITEM_ID = "ItemID";

    public static final String ITEM_NAME = "ItemName";

    public static final String LINE_NUMBER = "LineNumber";

    public static final String LINE_SUFFIX = "LineSuffix";

    public static final String MVX_CONFIGURABLE_NUMBER = "MvxConfigurableNumber";

    public static final String NET_LINE_AMOUNT = "NetLineAmount";

    public static final String NET_PRICE = "NetPrice";

    public static final String ORDERED_QUANTITY = "OrderedQuantity";

    public static final String PRICELIST = "PriceList";

    public static final String SALES_PRICE = "SalesPrice";

    public static final String SALES_PRICE_QUANTITY = "SalesPriceQuantity";

    public static final String SHADOW_ORDER_LINE_ID = "ShadowOrderLineID";

    // SHADOW ORDER FIELD == API FIELD MAPPING
    public static final Map getShadowOrderHeaderAPIMapping() {
        Map<String, String> fieldMapping = new HashMap<String, String>();
        fieldMapping.put(CHARGE, EXAM);
        fieldMapping.put(CHARGE_TEXT, EXTX);
        fieldMapping.put(COMPANY_ID, CUNO);
        fieldMapping.put(CURRENCY_CODE, CUCD);
        fieldMapping.put(CUSTOMER_ORDER_NO, CUOR);
        fieldMapping.put(DELIVERY_METHOD, MODL);
        fieldMapping.put(DELIVERY_METHOD_TEXT, MOD1);
        fieldMapping.put(DELIVERY_TERMS, TEDL);
        fieldMapping.put(DELIVER_TERMS_TEXT, TEL1);
        fieldMapping.put(DISCOUNT_PERCENT, OTDP);
        fieldMapping.put(EXTERNAL_CHARGE, EFAM);
        fieldMapping.put(GROSS_ORDER_VALUE, BRAM);
        fieldMapping.put(MVX_ORDER_TYPE, ORTP);
        fieldMapping.put(MVX_WAREHOUSE, WHLO);
        fieldMapping.put(NET_ORDER_AMOUNT, NTAM);
        fieldMapping.put(ORDER_DATE, ORDT);
        fieldMapping.put(ORDER_DISCOUNT, OTBA);
        fieldMapping.put(ORDER_NUMBER, ORNO);
        fieldMapping.put(PAYMENT_TERMS, TEPY);
        fieldMapping.put(PAYMENT_TERMS_TEXT, TXPY);
        fieldMapping.put(PRICE_LIST_TABLE, PLTB);
        fieldMapping.put(PURCHASE_ORDER_DATE, CUDT);
        fieldMapping.put(REQUESTED_DELIVERY_DATE, RLDT);
        fieldMapping.put(ROUNDING_OFF, ROAM);
        fieldMapping.put(TOTAL, TOPY);
        fieldMapping.put(VAT_AMOUNT, VTAM);
        return fieldMapping;
    }

    public static final Map getShadowOrderLineAPIMapping() {
        Map<String, String> fieldMapping = new HashMap<String, String>();
        fieldMapping.put(ALIAS, POPN);
        fieldMapping.put(BATCH_LINE_NUMBER, RIDL);
        fieldMapping.put(BATCH_ORDER_NUMBER, RIDN);
        fieldMapping.put(CONFIRMED_DELIVERY_DATE, CODT);
        fieldMapping.put(CURRENCY, CUCD);
        fieldMapping.put(CUSTOMER_LINE_NUMBER, CUPO);
        fieldMapping.put(CUSTOMER_ORDER_NUMBER, CUOR);
        fieldMapping.put(DEMAND_LINE_NO, DRDL);
        fieldMapping.put(DEMAND_ORDER_NO, DRDN);
        fieldMapping.put(DISCOUNT1, DIA1);
        fieldMapping.put(DISCOUNT2, DIA2);
        fieldMapping.put(DISCOUNT3, DIA3);
        fieldMapping.put(DISCOUNT4, DIA4);
        fieldMapping.put(DISCOUNT5, DIA5);
        fieldMapping.put(DISCOUNT6, DIA6);
        fieldMapping.put(ITEM_ID, ITNO);
        fieldMapping.put(ITEM_NAME, ITDS);
        fieldMapping.put(LINE_NUMBER, PONR);
        fieldMapping.put(LINE_SUFFIX, POSX);
        fieldMapping.put(MVX_CONFIGURABLE_NUMBER, CFIN);
        fieldMapping.put(NET_LINE_AMOUNT, NLAM);
        fieldMapping.put(NET_PRICE, NEPR);
        fieldMapping.put(ORDERED_QUANTITY, ORQT);
        fieldMapping.put(PRICELIST, PRRF);
        fieldMapping.put(UNIT, SPUN);
        fieldMapping.put(REQUESTED_DELIVERY_DATE, DWDT);
        fieldMapping.put(SALES_PRICE, SAPR);
        fieldMapping.put(SALES_PRICE_QUANTITY, SACD);
        fieldMapping.put(MVX_WAREHOUSE, WHLO);
        return fieldMapping;
    }
    
    public static final Map getOrderLineAPIMapping() {
        Map<String, String> fieldMapping = new HashMap<String, String>();
        fieldMapping.put(ITEMID, ConstantsForSales.ITNO);
        fieldMapping.put(ITEMNAME, ConstantsForSales.ITDS);
        fieldMapping.put(LINENUMBER, ConstantsForSales.PONR);
        fieldMapping.put(LINESUFFIX, ConstantsForSales.POSX);
        fieldMapping.put(CONFIRMEDDELIVERYDATE, ConstantsForSales.CODT);
        fieldMapping.put(LINEPRICE, ConstantsForSales.NLAM);
        fieldMapping.put(QUANTITY, ConstantsForSales.ORQT);
        fieldMapping.put(REQUESTEDDELIVERYDATE, ConstantsForSales.DWDT);
        fieldMapping.put(ORDERLINECOMMENT, ConstantsForSales.PONR);
        fieldMapping.put(UNITCODE, ConstantsForSales.SPUN);
        fieldMapping.put(CUSTOMER_ORDER_NUMBER, CUOR);
        fieldMapping.put(MVX_CONFIGURABLE_ID, CFIN);
        fieldMapping.put(CUSTOMERITEMID, ConstantsForSales.POPN);
        return fieldMapping;
    }
    
    public static final Map<String, String> getCurrent_ShadowOrderHeaderMapping() {
    	Map<String, String> fieldMapping = new HashMap<String, String>();
    	fieldMapping.put(ConstantsForSales.CHARGE, ConstantsForSales.CHARGE);
    	fieldMapping.put(ConstantsForSales.CHARGE_TEXT, ConstantsForSales.CHARGE_TEXT);
    	fieldMapping.put(ConstantsForSales.TOTALPRICE, ConstantsForSales.GROSS_ORDER_VALUE);
    	fieldMapping.put(ConstantsForSales.GRANDTOTAL, ConstantsForSales.NET_ORDER_AMOUNT);
    	fieldMapping.put(ConstantsForSales.TOTALDISCOUNT,ConstantsForSales.ORDER_DISCOUNT_AMOUNT);
    	fieldMapping.put(ConstantsForSales.TOTAL_LINE_DISCOUNT,ConstantsForSales.ORDER_LINE_DISCOUNT_AMOUNT);
    	return fieldMapping;
    }
    
    public static final Map<String, String> getCurrent_ShadowOrderLineMapping() {
    	Map<String, String> fieldMapping = new HashMap<String, String>();
    	fieldMapping.put(ConstantsForSales.ITEM_DESCRIPTION, ConstantsForSales.ITEM_NAME);
    	fieldMapping.put(ConstantsForSales.ITEM_ID, ConstantsForSales.ITEM_ID);
    	fieldMapping.put(ConstantsForSales.LINEDISPERCENT, ConstantsForSales.LINEDISPERCENT);
    	fieldMapping.put(ConstantsForSales.LINEPRICE, ConstantsForSales.LINEPRICE);
    	fieldMapping.put(ConstantsForSales.LINETOTAL, ConstantsForSales.NET_LINE_AMOUNT);
    	fieldMapping.put(ConstantsForSales.QUANTITY, ConstantsForSales.ORDERED_QUANTITY);
    	fieldMapping.put(ConstantsForSales.RESELLPRICE, ConstantsForSales.SALES_PRICE);
    	fieldMapping.put(ConstantsForSales.UNITCODE, ConstantsForSales.UNIT);
    	fieldMapping.put(ConstantsForSales.CONFIRMEDDELIVERYDATE, ConstantsForSales.CONFIRMEDDELIVERYDATE);
    	fieldMapping.put(ConstantsForSales.IS_VISIBLE, ConstantsForSales.IS_VISIBLE);
    	fieldMapping.put(ConstantsForSales.IS_ACTIVE, ConstantsForSales.IS_VISIBLE);
		fieldMapping.put(ConstantsForSales.MVXWAREHOUSE, ConstantsForSales.MVXWAREHOUSE);
    	return fieldMapping;
    }

    /*
     * Lucene related constants (alphabetical order)
     */
    public static final String DEFAULT_INDEX_FOLDER = "c:\\lucene-index-so";

    public static final String DEFAULT_LANGUAGE_CODE = "en";

    public static final int DEFAULT_PAGING_LIMIT = 11;

    public static final String INDEX_FOLDER_APP_PROP = "Search Engine.Index Folder";

    public static final String UNOPTIMIZED_DOC_LIMIT_APP_PROP = "Search Engine.Unoptimized Document Limit";

    public static final String SORTABLE_FIELD_PREFIX = "sort_";

    /*
     * Lucene Index Field Name constants (alphabetical order).
     */

    public static final String APPROVE_STATUS_FIELD = "approvestatus";

    public static final String CATEGORY_ID_FIELD = "categoryid";

    public static final String COUNTRY_ID_FIELD = "countryid";

    public static final String ITEM_ID_FIELD = "itemid";

    public static final String KEY_FIELD = "keyfield";

    public static final String KEYWORD_FIELD = "keyword";

    public static final String LUCENE_DATE_FORMAT = "yyyyMMdd";

    public static final String MASTER_USER_GROUP_ID_FIELD = "masterusergroupid";

    public static final String NAME_FIELD = "name";

    public static final String ORDER_STATUS_FIELD = "orderstatus";

    public static final String RFQ_STATUS_FIELD = "rfqstatus";

    public static final String TYPE_STRING = "string";

    public static final String TYPE_INTEGER = "integer";

    public static final String TYPE_DECIMAL = "decimal";

    public static final String TYPE_DATE = "date";

    public static final String STATUS_CODE_OK = "OKLuceneIndexStatus";

    public static final String STATUS_CODE_FAILED = "FailedLuceneIndexStatus";

    public static final String STATUS_CODE_REBUILDING = "RebuildingLuceneIndexStatus";

    public static final String STATUS_CODE_UPDATING = "UpdatingLuceneIndexStatus";

    public static final String USER_COMPANY_FIELD = "company";

    public static final String USER_GROUP_KEY_FIELD = "usergroupkey";

    public static final String USER_ROLE_FIELD = "role";

    public static final String ROLE_ID_FIELD = "roleid";


}
