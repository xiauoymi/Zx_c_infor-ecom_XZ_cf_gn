package com.intentia.iec.pipeline.runtime.stage.custom.search.rowhandler;

import static com.intentia.iec.pipeline.runtime.stage.custom.search.IndexerUtils.addIndexedField;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import org.apache.lucene.document.Document;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Strings;

/**
 * Lookup all the categories the item is a member of, also indirectly via a
 * product. The CategoryItemExtension table is populated by the
 * Category.UpdateExplosions scheduled job. The Lucene.Index job should be
 * scheduled to run later.
 */
public class CategoryRowHandler implements Jdbc.RowHandler {
    private Document doc = null;
    
    private Map<String, String> categoryPathById;

    public CategoryRowHandler(Document doc, Map<String, String> categoryPathById) {
        this.doc = doc;
        this.categoryPathById = categoryPathById;
    }

    public void processRow(ResultSet rs) throws SQLException, PipelineRuntimeException {
        String categoryId = rs.getString(Strings.Database.Indexing.Item.Categories.categoryId);
        String path = categoryPathById.get(categoryId);
        addIndexedField(this.doc, Strings.Index.Item.categoryPath, path);
    }
}
