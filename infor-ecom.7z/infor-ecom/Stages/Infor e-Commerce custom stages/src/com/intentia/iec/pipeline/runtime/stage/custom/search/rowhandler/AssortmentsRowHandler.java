package com.intentia.iec.pipeline.runtime.stage.custom.search.rowhandler;

import static com.intentia.iec.pipeline.runtime.stage.custom.search.IndexerUtils.addIndexedField;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.lucene.document.Document;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Strings;

/**
 * Lookup all the assortments an item is member of. The ItemVisible table is
 * populated by the Item.GenerateVisibility scheduled job. The
 * SearchEngine.Index job should be scheduled to run later.
 */
public class AssortmentsRowHandler implements Jdbc.RowHandler {
    private Document doc = null;

    public AssortmentsRowHandler(Document doc) {
        this.doc = doc;
    }

    public void processRow(ResultSet rs) throws SQLException, PipelineRuntimeException {
        String assortmentId = rs.getString(Strings.Database.Indexing.Item.Assortments.assortmentId);
        addIndexedField(doc, Strings.Index.Item.assortmentId, assortmentId);
    }
}
