package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;


public class GetPromotionCode implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(GetPromotionCode.class);

    private int PROMOTION_CODE_LIMIT = 0;
    
    private static final int GENERATED_8_CODE_LENGTH = 8;
    
    private static final int GENERATED_10_CODE_LENGTH = 10;
    
    private static final int GENERATED_12_CODE_LENGTH = 12;
    
    private static final String ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    
    private static final String NUMERIC = "0123456789";

    private static final String HASH_KEY_MD5 = "MD5";
    
    private static final String HASH_KEY_SHA = "SHA";
    
    private static final String PROMOTION_GENERATED_CODE = "Code";
    
    public GetPromotionCode() {
        super();
    }

    public void execute(PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("Inside GetPromotionCode.execute()");

        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
        XMLRequest xmlRequest = (XMLRequest) context.getRequest();

        this.setGeneratedCodeLength();
        
        String AppPromotionEncodingKey = CustomStagesHelper.getKeyValue("Promotion.HASH KEY");
        if(AppPromotionEncodingKey.equals("")){
        	AppPromotionEncodingKey = GetPromotionCode.HASH_KEY_MD5;
        }
        
        
        String promotionCodeKey = "";
        if(GetPromotionCode.HASH_KEY_MD5.equals(AppPromotionEncodingKey)){
        	promotionCodeKey = getPromotionMD5CodeKey();        	
        } else if(GetPromotionCode.HASH_KEY_SHA.equals(AppPromotionEncodingKey)) {
        	promotionCodeKey = getPromotionSHACodeKey();
    	} else {
    		// 3rd party Encoding Scheme
    	}

        StringBuilder responseSb = new StringBuilder();
        responseSb.append("<?xml version='1.0' encoding='UTF-8'?>");
        responseSb.append("<resultset object=\"PromotionKey\">");
        responseSb.append("<row "+GetPromotionCode.PROMOTION_GENERATED_CODE+"=\""+promotionCodeKey+"\"/>");
        responseSb.append("</resultset>");
        
        if (context.getResponse() == null) {
        	context.setResponse(new XMLResultset(responseSb.toString()));			        
        }
        
    }

    /**
     * Retrieved from Properties File Promotion Code Length.
     * 
     * @throws PipelineRuntimeException
     */
    private void setGeneratedCodeLength() throws PipelineRuntimeException{
    	String strCodelength = CustomStagesHelper.getKeyValue("Promotion.CODE LENGTH");
    	int AppPromotionCodeLength = 0;
    	if(strCodelength.equals("")){
    		AppPromotionCodeLength = GetPromotionCode.GENERATED_8_CODE_LENGTH;
        } else {
        	AppPromotionCodeLength = Integer.parseInt(strCodelength);
        }
    	
    	if(AppPromotionCodeLength > 0){
    		this.PROMOTION_CODE_LIMIT = AppPromotionCodeLength;
    	} else {
    		this.PROMOTION_CODE_LIMIT = GetPromotionCode.GENERATED_8_CODE_LENGTH;
    	}
    }

    /**
     * Create a Generated Code using MD5 Encryption.
     * 
     * @return String Promotion Code Key
     * @throws PipelineRuntimeException
     */
    private String getPromotionMD5CodeKey() throws PipelineRuntimeException {
        String promotionCodeKey = "";
        MessageDigest mesDigest;
		try {
			mesDigest = MessageDigest.getInstance(GetPromotionCode.HASH_KEY_MD5);
			String alphaNumericStr = getRandomAlphaNumericString();
			mesDigest.update(alphaNumericStr.getBytes(),0,alphaNumericStr.length());
			String encodedKey = new BigInteger(1,mesDigest.digest()).toString(16).toUpperCase();
			promotionCodeKey = encodedKey.substring(0, this.PROMOTION_CODE_LIMIT);
		} catch (NoSuchAlgorithmException e) {
			throw new PipelineRuntimeException();
		}
        return promotionCodeKey;
    }
   
    /**
     * Create a Generated Code using SHA Encryption.
     * 
     * @return String Promotion Code Key
     * @throws PipelineRuntimeException
     */
    private String getPromotionSHACodeKey() throws PipelineRuntimeException {
        String promotionCodeKey = "";
        MessageDigest mesDigest;
		try {
			mesDigest = MessageDigest.getInstance(GetPromotionCode.HASH_KEY_SHA);
			String alphaNumericStr = getRandomAlphaNumericString();
			mesDigest.update(alphaNumericStr.getBytes(),0,alphaNumericStr.length());
			String encodedKey = new BigInteger(1,mesDigest.digest()).toString(16).toUpperCase();
			promotionCodeKey = encodedKey.substring(0, this.PROMOTION_CODE_LIMIT);
			
		} catch (NoSuchAlgorithmException e) {
			throw new PipelineRuntimeException();
		}
        return promotionCodeKey;
    }
    
    /**
     * Generate Random String used for creating Hash Value for Message Digest.
     * 
     * @return Random String used for creating Hash Value
     */
    private String getRandomAlphaNumericString(){
    	StringBuilder alphaNumerString =  new StringBuilder();
    	Random random = new Random();
    	char [] alphaChars = GetPromotionCode.ALPHA.toCharArray();
    	char [] numericChars = GetPromotionCode.NUMERIC.toCharArray();
    	for (int i = 0; i < 5; i++) {
    	    char c = alphaChars[random.nextInt(alphaChars.length)];
    	    alphaNumerString.append(c);
    	    c = numericChars[random.nextInt(numericChars.length)];
    	    alphaNumerString.append(c);
    	}
    	return alphaNumerString.toString();
    }
    
    
    
    public static void main (String args[]){
    	GetPromotionCode gpc = new GetPromotionCode();
		try {
			System.out.println("MD5 Key: "+ gpc.getPromotionMD5CodeKey());
			System.out.println("SHA Key: "+ gpc.getPromotionSHACodeKey());
			
		} catch (PipelineRuntimeException e) {
			e.printStackTrace();
		}
    }
    
}
