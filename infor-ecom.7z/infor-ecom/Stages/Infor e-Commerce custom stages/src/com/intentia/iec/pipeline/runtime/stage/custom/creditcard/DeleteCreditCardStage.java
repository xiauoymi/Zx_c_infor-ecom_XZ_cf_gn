package com.intentia.iec.pipeline.runtime.stage.custom.creditcard;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.creditcard.dao.CreditCardAdminDao;
import com.intentia.iec.pipeline.runtime.integration.creditcard.dao.factory.DaoFactory;
import com.intentia.iec.pipeline.runtime.integration.creditcard.exception.CreditCardConnectionException;
import com.intentia.iec.pipeline.runtime.integration.creditcard.model.CreditCard;
import com.intentia.iec.pipeline.runtime.integration.creditcard.model.TransactionResult;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;

public class DeleteCreditCardStage extends AbstractPipelineStage {

	private static final Logger log = Logger
			.getLogger(AuthorizeCreditCardPaymentStage.class);
	
	
	@Override
	public void execute(PipelineContext context) throws PipelineRuntimeException {
		//get params from pipeline
		log.debug("Start DeleteCreditCardStage.execute() . . .");

		CustomStagesHelper.extractRequestParameters(CustomStagesHelper
				.getRequest(context));

		XMLRequest request = (XMLRequest) context.getRequest();
		Parameters requestParams = request.getParameters();
		TransactionResult transactionResult = getTransactionResult(requestParams);
		XMLResultset resultset = getResponse(context);
		
		log.debug("AuthorizeCreditCardPaymentStage.java ================ Is transactionResult null? " + (transactionResult == null));
		log.debug("AuthorizeCreditCardPaymentStage.java ================ is successful: " + transactionResult.isSuccessful());
		
		CustomStagesHelper.setResponseParameter(context, "isDeleteSuccessful", String.valueOf(transactionResult.isSuccessful()));
	}
	
	private TransactionResult getTransactionResult(Parameters requestParams) {
		CreditCard creditCard = new CreditCard();
		TransactionResult result = new TransactionResult();
		
		try {
			creditCard.setToken(requestParams.getString("token"));
			CreditCardAdminDao dao = DaoFactory.getDAOFactory().getCreditCardAdminDao();
			result = dao.deleteCreditCard(creditCard);

			log.debug("Credit Card Authorization : " + result);
		} catch (CreditCardConnectionException e) {
			log.error(
					"Error while connecting to Credit Card Web Service",
					e);
		} catch (ParametersException e) {
			log.error(
					"Error getting parameter",
					e);
		} 
		return result;
	}
}
