package com.intentia.iec.pipeline.runtime.stage.custom.search;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Collection;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.apache.log4j.Logger;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.search.IndexerStage.MyAnalyzer;

/**
 * Utility class containing helper methods for indexing.
 */
public class IndexerStageUtils {
	
	private static final Logger LOG = Logger.getLogger(IndexerStageUtils.class);

	public static final String FOLDER_PREFIX;
    static { // Prevents in-lining
        FOLDER_PREFIX = "Index ";
    }
	
    private static final String TEMP_FOLDER_PREFIX = "/Temp ";
    
    private static final String ZIPFILENAME = "temp.zip";

    
    /**
     * Orchestrates the indexing work. Handles commit or rollback. 
     * @param manager
     * @param baseDataIndexer
     * @param itemIndexer
     * @throws PipelineRuntimeException
     */
    public static void doIndexing(final Manager manager, final Indexer baseDataIndexer, final Indexer itemIndexer)
            throws PipelineRuntimeException {
        String indexFolder = manager.getParentFolder();
        String newFolder = manager.getNewFolderName();
        String folder = indexFolder + TEMP_FOLDER_PREFIX + newFolder;
        Directory dir = null;

        try {
            dir = FSDirectory.getDirectory(folder);
        } catch (IOException e) {
            LOG.error("Error opening index folder " + folder, e);
            throw new PipelineRuntimeException();
        }

        try {
            IndexWriter writer;
            try {
                writer = new IndexWriter(dir, false, new MyAnalyzer(), true);
            } catch (IOException e) {
                LOG.error("Problem creating IndexWriter", e);
                throw new PipelineRuntimeException();
            }

            try {
                LOG.info("Beginning indexing");

                baseDataIndexer.index(writer);
                itemIndexer.index(writer);

                try {
                    writer.optimize();
                    writer.close();
                } catch (IOException e) {
                    LOG.error("Problem optimizing or closing IndexWriter", e);
                    throw new PipelineRuntimeException();
                }

                LOG.info("Indexing finished");

                try {
                    dir.close();
                } catch (IOException e) {
                    LOG.error("Error closing directory. " + "The index might be corrupted.", e);
                    throw new PipelineRuntimeException();
                }

                useNewIndex(manager, indexFolder, newFolder);
				
				deletePrevDir(indexFolder, newFolder);
            } catch (PipelineRuntimeException e) {
                LOG.error("Error during indexing", e);
                throw e;
            }
        } finally {
            try {
                dir.close();
            } catch (IOException e) {
                LOG.error("Error closing directory. " + "The index might be corrupted.", e);
                throw new PipelineRuntimeException();
            }
        }
    }
    
    /**
     * Uses new index file
     * 
     * @param manager
     * @param indexFolder
     * @param newFolder
     * @throws PipelineRuntimeException
     */
    private static void useNewIndex(Manager manager, String indexFolder, String newFolder)
            throws PipelineRuntimeException {
        File src = new File(indexFolder, TEMP_FOLDER_PREFIX + newFolder);

        // Check that the new index can be read
        IndexReader ir = null;
        try {
            ir = IndexReader.open(src);
            // This is how the Luke tool checks an index
            Collection<?> fn = ir.getFieldNames(IndexReader.FieldOption.ALL);
            if (fn.isEmpty()) {
                throw new PipelineRuntimeException();
            }
        } catch (Exception e) {
            LOG.error("The newly created index is invalid", e);
            throw new PipelineRuntimeException();
        } finally {
            try {
                ir.close();
            } catch (IOException e) {
                LOG.error("Error closing IndexReader", e);
                throw new PipelineRuntimeException();
            }
        }

        File dest = new File(indexFolder, FOLDER_PREFIX + newFolder);
        LOG.debug("Renaming " + src.getAbsolutePath() + " to " + dest.getAbsolutePath());
        if (!src.renameTo(dest)) {
            LOG.error("Error renaming index folder");
            throw new PipelineRuntimeException();
        }

        manager.reloadData(); // New index now in use
    }
    
    /**
     * Sends the indexing request to the Index Server.
     * @param url
     * @param port
     * @param manager
     * @param indexerServerRequest
     * @throws PipelineRuntimeException
     */
    public static void sendIndexRequest(String url, int port, Manager manager, IndexerServerRequest indexerServerRequest) throws PipelineRuntimeException {
        Socket s = null;
        ObjectOutputStream out = null;
        ObjectInputStream in = null;
        try {
            // Create Socket
            LOG.debug("Connecting to " + url + ":" + port);
            s = new Socket(url, port);
            out = new ObjectOutputStream(new BufferedOutputStream(s.getOutputStream()));

            // Send request
            out.writeObject(indexerServerRequest);
            out.flush();

            // Wait for response
            LOG.debug("Waiting for response");
            in = new ObjectInputStream(new BufferedInputStream(s.getInputStream()));
            Object response = in.readObject();
            if (response instanceof IndexerServerResult) {
                // check for expected response type
                IndexerServerResult result = (IndexerServerResult) response;
                if (result.wasSuccessful() == true) {
                    LOG.info("Indexing successful");

                    String indexFolder = manager.getParentFolder();
                    createFolder(indexFolder);
                    byte[] zipContent = result.getZipContent();
                    if (zipContent != null) {
                        LOG.debug("file size: " + zipContent.length + " byte(s)");
                    }
                    // create zip file
                    String fileName = indexFolder + "/" + ZIPFILENAME;
                    writeZip(fileName, zipContent);

                    // use zip file
                    unzipFile(manager, fileName);

                    // cleanup
                    deleteZipFile(fileName);
                } else {
                    LOG.error("Indexing failed");
                    throw new PipelineRuntimeException("Indexing failed");
                }
            } else {
                LOG.error("Unexpected result");
                throw new PipelineRuntimeException("Unexpected result");
            }
        } catch (Exception e) {
            LOG.error("Error ", e);
            throw new PipelineRuntimeException(e);
        } finally {
            if (out != null) {
                LOG.debug("Closing output stream...");
                try {
                    out.close();
                    LOG.debug("Closing output stream done");
                } catch (IOException e) {
                    LOG.debug("Closing output stream error", e);
                }
                out = null;
            }
            if (in != null) {
                LOG.debug("Closing input stream...");
                try {
                    in.close();
                    LOG.debug("Closing input stream done");
                } catch (IOException e) {
                    LOG.debug("Closing input stream error", e);
                }
                out = null;
            }
            if (s != null) {
                LOG.debug("Closing socket...");
                try {
                    s.close();
                    LOG.debug("Closing socket done");
                } catch (IOException e) {
                    LOG.debug("Closing socket error", e);
                }
                s = null;
            }
        }
    }
    
    /**
     * @param folderName
     */
    private static void createFolder(String folderName) {
        if (folderName != null) {
            File f = new File(folderName);
            if (f.exists() == false) {
                boolean res = f.mkdirs();
                LOG.debug("Create parent directories for lucene=" + res);
            }
        }
    }
    
    /**
     * Writes the binary data to file
     * 
     * @param fileName
     * @param zipContent
     * @throws IOException
     */
    private static void writeZip(String fileName, byte[] zipContent) throws IOException {
        if (zipContent != null) {
            LOG.debug("Unzipping: " + fileName);

            FileOutputStream fos = null;
            try {
                fos = new FileOutputStream(fileName);
                fos.write(zipContent);
            } catch (FileNotFoundException e) {
                LOG.error(e);
                throw e;
            } catch (IOException e) {
                LOG.error(e);
                throw e;
            } finally {
                if (fos != null) {
                    try {
                        fos.close();
                    } catch (IOException e) {
                        LOG.error(e);
                    }
                    fos = null;
                }
            }
        }
    }

    /**
     * Unzips the file and uses it as the new index.
     * 
     * @param manager
     * @param fileName
     * @throws Exception
     */
    private static void unzipFile(Manager manager, String fileName) throws Exception {
        LOG.debug("Unzipping: " + fileName);

        int BUFFER = 1024;
        String indexFolder = manager.getParentFolder();
        String newFolder = manager.getNewFolderName();
        String path = indexFolder + TEMP_FOLDER_PREFIX + newFolder + "/";

        BufferedOutputStream dest = null;
        BufferedInputStream is = null;
        ZipFile zipfile = null;

        boolean success = false;

        LOG.debug("Creating directory: " + path);
        File f = new File(path);
        f.mkdir();

        try {
            ZipEntry entry = null;
            zipfile = new ZipFile(fileName);
            Enumeration<?> e = zipfile.entries();
            // unzip all elements
            while (e.hasMoreElements() == true) {
                entry = (ZipEntry) e.nextElement();

                // write entry
                LOG.debug("Extracting: " + entry + " to " + path + entry.getName());
                is = new BufferedInputStream(zipfile.getInputStream(entry));
                int count;
                byte data[] = new byte[BUFFER];
                FileOutputStream fos = new FileOutputStream(path + entry.getName());
                dest = new BufferedOutputStream(fos, BUFFER);
                while ((count = is.read(data, 0, BUFFER)) != -1) {
                    dest.write(data, 0, count);
                }

                // cleanup
                dest.flush();
                dest.close();
                dest = null;
            }
            success = true;
        } catch (Exception e) {
            LOG.error(e);
            throw e;
        } finally {
            if (dest != null) {
                try {
                    dest.close();
                } catch (IOException e) {
                    LOG.error(e);
                }
                dest = null;
            }
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    LOG.error(e);
                }
                is = null;
            }
            if (zipfile != null) {
                try {
                    zipfile.close();
                } catch (IOException e) {
                    LOG.error(e);
                }
                zipfile = null;
            }
        }
        // use as new index
        if (success == true) {
            useNewIndex(manager, indexFolder, newFolder);
			
			deletePrevDir(indexFolder, newFolder);
        }
    }

    /**
     * Deletes file
     * 
     * @param fileName
     */
    private static void deleteZipFile(String fileName) {
        File f = new File(fileName);
        f.delete();
    }
	
    private static void deletePrevDir(String dir, String newFolderName) {
        // delete old indexes
        File folder = new File(dir);
        File[] listOfFiles = folder.listFiles();
        String dirname = null;
        for (int i = 0; i < listOfFiles.length; i++) {
           if (listOfFiles[i].isDirectory()) {
        	 dirname = listOfFiles[i].getName(); 
             if (!listOfFiles[i].getName().equals(FOLDER_PREFIX + newFolderName)) {
            	 boolean success = deleteDir(listOfFiles[i]);
            	 if (success) LOG.info("Deleted directory " + dirname); 
             }
           }
        }        
    }    
    
    private static boolean deleteDir(File dir) {
        if (dir.isDirectory()) {
            String[] children = dir.list();
            for (int i=0; i<children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
        }
        return dir.delete();
    }
	
}
