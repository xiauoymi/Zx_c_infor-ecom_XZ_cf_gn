package com.intentia.iec.pipeline.runtime.stage.custom.search;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;

/**
 * 
 * @author
 * 
 */
// removed final so that SPS can inherit from this class
public class ItemListStage extends AbstractItemListStage {    
    
    /**
     * 
     * @throws PipelineRuntimeException
     */
    public ItemListStage() throws PipelineRuntimeException {
        request = new Request();
        response = new Response();
        helper = new SearchUtils();
        queries = new DatabaseImpl();
        dataholder = ManagerImpl.INSTANCE.getDataHolder();
    }

    /**
     * 
     * @param queries
     * @param dataholder
     * @throws PipelineRuntimeException
     */
    public ItemListStage(Database queries, DataHolder dataholder) throws PipelineRuntimeException {
        request = new Request();
        response = new Response();
        helper = new SearchUtils();
        this.queries = queries;
        this.dataholder = dataholder;
    } 
}
