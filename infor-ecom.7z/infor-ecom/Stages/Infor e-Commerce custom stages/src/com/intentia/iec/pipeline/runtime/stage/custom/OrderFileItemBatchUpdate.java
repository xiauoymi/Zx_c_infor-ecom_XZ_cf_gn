package com.intentia.iec.pipeline.runtime.stage.custom;

import java.sql.Connection;
import java.sql.SQLException;
import org.apache.log4j.Logger;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.sqlserver.runtime.jdbc.LogPreparedStatement;
import com.intentia.iec.util.FastStringBuffer;

public class OrderFileItemBatchUpdate {

    private static final Logger LOG = Logger.getLogger(OrderFileItemBatchUpdate.class);

    private Connection conn = null;

    private static final String SQL_INSERT = "INSERT INTO [OrderFileItem]([fileID],[rowNumber],"
            + " [itemID], [suppliedQty]) VALUES (?,?,?,?)";

    private static final String SQL_UPDATE = "UPDATE [main] SET [validQty] = ?, [status] = ?, [itemID] = ?, [isCID] = ?, [AddToCart] = ? "
            + " FROM [OrderFileItem] [main] WHERE [main].[id] = ?";

    LogPreparedStatement pstmtInsert;

    LogPreparedStatement pstmtUpdate;

    FastStringBuffer sqlInsertStr = new FastStringBuffer();

    FastStringBuffer sqlUpdateStr = new FastStringBuffer();

    public OrderFileItemBatchUpdate(String SQLcommand) throws PipelineRuntimeException {
        super();
        try {
            initSQLConnection();
        } catch (PipelineRuntimeException e) {
            throw new PipelineRuntimeException();
        }
        if (SQLcommand.trim().equalsIgnoreCase("INSERT")) {
            pstmtInsert = new LogPreparedStatement(conn, SQL_INSERT);
        } else if (SQLcommand.trim().equalsIgnoreCase("UPDATE")) {
            pstmtUpdate = new LogPreparedStatement(conn, SQL_UPDATE);
        } else {
            throw new PipelineRuntimeException("Unsupported SQL command ...");
        }

    }

    public void addToBatchInsert(int pFileID, int pRowNumber, String pItemID, String pOrderQuanity) {

        try {
            pstmtInsert.setInt(1, pFileID);
            pstmtInsert.setInt(2, pRowNumber);
            pstmtInsert.setString(3, pItemID);
            pstmtInsert.setString(4, pOrderQuanity);
            pstmtInsert.addBatch();
        } catch (SQLException e) {
            LOG.debug("Error in adding insert statement");
        }

        sqlInsertStr.append(pstmtInsert.getQuery() + "; \r\n");
    }

    public void addToBatchUpdate(String pID, double pValidQty, String pStatus, String pAddToCart, String pItemID,
            String pIsCID) {

        try {
            pstmtUpdate.setDouble(1, pValidQty);
            pstmtUpdate.setString(2, pStatus);
            pstmtUpdate.setString(3, pItemID);
            pstmtUpdate.setString(4, pIsCID);
            pstmtUpdate.setString(5, pAddToCart);
            pstmtUpdate.setString(6, pID);
            pstmtUpdate.addBatch();

        } catch (SQLException e) {
            LOG.debug("Error in adding update statement");
        }

        sqlUpdateStr.append(pstmtUpdate.getQuery() + "; \r\n");
    }

    public int executeBatchUpdate() throws PipelineRuntimeException {

        int result = 0;

        try {
            LOG.debug("Executing UPDATE statement:\r\n" + sqlUpdateStr);
            int[] results = pstmtUpdate.executeBatch();
            for (int i = 0; i < results.length; i++) {
                result += results[i];
            }

        } catch (SQLException e) {
            throw new PipelineRuntimeException("Error in executing OrderFileItem Batch update ...");
        } finally {
            try {
                if (pstmtUpdate != null) {
                    pstmtUpdate.close();
                }
            } catch (SQLException e) {
                LOG.error("Error in closing SQL Statement ...");
            }
            closeSQLConnection();
            return result;

        }

    }

    public int executeBatchInsert() throws PipelineRuntimeException {

        int result = 0;

        try {
            LOG.debug("Executing INSERT statement:\r\n" + sqlInsertStr);
            int[] results = pstmtInsert.executeBatch();
            for (int i = 0; i < results.length; i++) {
                result += results[i];
            }

        } catch (SQLException e) {
            throw new PipelineRuntimeException("Error in executing OrderFileItem Batch insert ...");
        } finally {
            try {
                if (pstmtInsert != null) {
                    pstmtInsert.close();
                }
            } catch (SQLException e) {
                LOG.error("Error in closing SQL Statement ...");
            }
            closeSQLConnection();
            return result;

        }

    }

    // Create/Get MS SQL Connection
    private void initSQLConnection() throws PipelineRuntimeException {

        conn = (Connection) CustomStagesHelper.getConnection("esales.cursor");

        if (!(conn instanceof Connection)) {
            LOG.error("Error on establishing database connection");
        } else {
            LOG.debug("Succesfully created SQL Connection!");
        }

    }

    // Destroy/Close MS SQL Connection
    private void closeSQLConnection() {

        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                LOG.error("error closing connnection", e);
            }
        }

    }

}
