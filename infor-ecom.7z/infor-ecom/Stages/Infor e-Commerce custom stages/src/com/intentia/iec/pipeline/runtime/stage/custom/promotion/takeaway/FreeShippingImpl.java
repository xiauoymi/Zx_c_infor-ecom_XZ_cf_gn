package com.intentia.iec.pipeline.runtime.stage.custom.promotion.takeaway;

import java.util.List;
import java.util.Map;

import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;

public class FreeShippingImpl implements TakeAway {

	private static FreeShippingImpl instance = null;
	
	private PromotionTakeAway promotionTakeAway = null;

	private List<String> promotionalItems = null;

	private Map<String, String> itemDetailsMap = null;
	
	protected FreeShippingImpl() {
	      // Exists only to defeat instantiation.
	}
	public static FreeShippingImpl getInstance() {
		if(instance == null) {
			instance = new FreeShippingImpl();
		}
	return instance;
	}
	
	/**
	 * @return the promotionTakeAway
	 */
	public PromotionTakeAway getPromotionTakeAway() {
		return promotionTakeAway;
	}
	/**
	 * @param promotionTakeAway the promotionTakeAway to set
	 */
	public void setPromotionTakeAway(PromotionTakeAway promotionTakeAway) {
		this.promotionTakeAway = promotionTakeAway;
	}
	
	public void setPromotionalItems(List<String> promotionalItems) {
		this.promotionalItems = promotionalItems;
	}
	
	public void setItemParametersMap(Map<String, String> itemDetailsMap) {
		this.itemDetailsMap = itemDetailsMap;
	}
	
	public void applyHeaderTakeaway(XMLResultset resultSet) {
		PromotionTakeAway takeAway = this.promotionTakeAway;
		String takeAwayField = takeAway.getField();
		String takeAwayOperator = takeAway.getOperator();

		if(TakeAwayConstant.METHOD.equals(takeAwayField)){
			this.applyFreeShippingByMethod();
		}

	}
	public void applyLineTakeAway(XMLResultset resultSet, XMLIterator xmlOrderline) {
		// TODO Auto-generated method stub
		
	}

	private void applyFreeShippingByMethod(){
		// not supported
	}
	
}
