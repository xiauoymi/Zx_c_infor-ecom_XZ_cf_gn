/*
 * Created on 23-03-2006
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

/**
 * <p>
 * Executes the method CurrentOrder_GetForParameters and inserts the returned
 * attributes as parameters in the current request.
 * </p>
 * <p>
 * <b>Input in <code>PipelineContext</code>:</b><br>
 * Parameters:
 * <ul>
 * <li><code>&#64;orderID</code> (mandatory)</li>
 * </ul>
 * </p>
 * <p>
 * <b>Generated output in <code>PipelineContext</code>:</b><br>
 * Parameters:
 * <ul>
 * <li><code>mvxCompany</code> from MvxCompany</li>
 * <li><code>mvxFacility</code> from MvxFacility</li>
 * <li><code>mvxWareHouse</code> from MvxWarehouse</li>
 * <li><code>mvxOrderType</code> from MvxOrderType</li>
 * <li><code>&#64;listPriceGroupId</code> from ListPriceGroupID</li>
 * </ul>
 * </p>
 */
/*
 * The text uses the character code &#64; for @ to avoid to confuse the Java
 * auto formatter.
 */
public class OrderAttributesToParameters implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(OrderAttributesToParameters.class);

    // Local variables
    private static Map mapAttributesToParameters = null;

    private XMLRequest request = null;

    private Parameters parameters = null;

    /*
     * (non-Javadoc) Pipeline entry point.
     */
    public void execute(final PipelineContext context) throws PipelineRuntimeException {

        // Verify type of request
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Request MUST be of type XMLRequest!");
        }

        request = (XMLRequest) context.getRequest();

        try {
            XMLRequest.extractRequestParameters(request);
            parameters = request.getParameters();

            // Build static map
            if (mapAttributesToParameters == null) {
                buildMap();
            }

            addParameters();

        } catch (RequestException e) {
            throw new PipelineRuntimeException("Failed to operate on request", e);
        }
    }

    /**
     * Builds the map between attributes and parameters called
     * mapAttributesToParameters .
     */
    private void buildMap() throws PipelineRuntimeException {

        mapAttributesToParameters = new HashMap();
        mapAttributesToParameters.put(ConstantsForSales.MVXCOMPANY, ConstantsForSales.MVXCOMPANY_PARAM);
        mapAttributesToParameters.put(ConstantsForSales.MVXFACILITY, ConstantsForSales.MVXFACILITY_PARAM);
        mapAttributesToParameters.put(ConstantsForSales.MVXWAREHOUSE, ConstantsForSales.MVXWAREHOUSE_PARAM);
        mapAttributesToParameters.put(ConstantsForSales.MVXORDERTYPE, ConstantsForSales.MVXORDERTYPE_PARAM);
        mapAttributesToParameters.put(ConstantsForSales.LISTPRICEGROUPID, ConstantsForSales.LISTPRICEGROUP_PARAM);
        mapAttributesToParameters.put(ConstantsForSales.CURRENCYID, ConstantsForSales.CURRENCYCODE_PARAM);
    }

    /**
     * Adds attributes listed in the map as parameters to the request in the
     * context.
     * 
     * @throws PipelineRuntimeException
     */
    private void addParameters() throws PipelineRuntimeException {

        // Business object
        final String orderObject = "CurrentOrder";

        // Method to call to get locale ID.
        final String infoMethod = "GetForParameters";

        try {
            String orderId = parameters.getString("orderID");
            if ((orderId == null) || (orderId.length() == 0)) {
                LOG.debug("Parameter '" + "orderID" + "' not found - aborting");
                return;
            }

            SearchPipelineExecuter searchOrder = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                    orderObject, infoMethod);
            searchOrder.setParam("orderID", orderId);
            XMLResultset resultSet = searchOrder.execute();
            if (resultSet.isEmpty()) {
                LOG.error("Couldn't find the order, orderId = " + orderId);
                return;
            }

            resultSet.moveFirst();

            // Loop the attributes in the result set and see if the attribute is
            // in the map
            List attributes = resultSet.getNames();
            Iterator i = attributes.iterator();
            while (i.hasNext()) {
                String attributeName = (String) i.next();
                String parameterName = (String) mapAttributesToParameters.get(attributeName);
                if (parameterName != null) {
                    String value = resultSet.getString(attributeName);
                    parameters.setString(parameterName, value);
                }
            }

        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Locale: Failed to get/set a parameter from/in request", e);
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Locale: Failed to operate on resultset", e);
        }
    }
}
