/*
 * Created on 05-02-2004
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.traversal.DocumentTraversal;
import org.w3c.dom.traversal.NodeFilter;
import org.w3c.dom.traversal.NodeIterator;

import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.Decimal;
import com.intentia.iec.util.FastStringBuffer;

/**
 * <p>
 * The <code>CalculateAltCurrency</code> stage computes the price in the
 * alternative currency. The mappings between the currency attributes are
 * defined in application property group <code>customStages</code> as the
 * element <code>altCurrencyAttributes</code>.<br>
 * <b>Example mappings:</b><br>
 * DeltaPrice:DeltaPriceAltCurrency;DiscountedPrice:DiscountedPriceAltCurrency;GrandTotal:GrandTotalAltCurrency;<br>
 * The above string contains three mappings between a currency field and an
 * alternative currency field. The mappings are required to be separated with a '<b>;</b>'.
 * The first mapping specify that the field <code>DeltaPrice</code> contains
 * the currency and the corresponding alternative currency should be placed in
 * the field <code>DeltaPriceAltCurrency</code>. Thus the separation between
 * the currency and the alternative currency field names is required to be '<b>:</b>'.
 * </p>
 * 
 * <p>
 * <b>Required input in <code>PipelineContext</code>:</b><br>
 * The parameters <code>altExchangeRate</code> and <code>exchangeRate</code>
 * (both of type double) must be available as parameters in the request from the
 * <code>PipelineContext</code>. These are needed to compute the conversion
 * rate between the currencies and the alternate currencies.
 * </p>
 * 
 * <p>
 * <b>Generated output in <code>PipelineContext</code>:</b><br>
 * The stage adds values to the alternate currencies attributes in the
 * resultset.
 * </p>
 */
public final class CalculateAltCurrency implements PipelineStage {
    /**
     * Name of the exchange rate parameter, which should be available in the
     * request parameters.
     */
    public static final String EXCHANGE_RATE = "exchangeRate";

    /**
     * Name of the alternative exchange rate parameter, which should be
     * available in the request parameters.
     */
    public static final String ALT_EXCHANGE_RATE = "altExchangeRate";

    /**
     * Key for fetching application property containing the currency mappings,
     * i.e. the application property specifying the mappings between the
     * currencies attributes and the corresponding alternative currencies
     * attributes.
     */
    public static final String ALT_CURRENCY_KEY = CustomStagesHelper.KEY_VALUE_PREFIX + "altCurrencyAttributes";

    private static final Logger LOG = Logger.getLogger(CalculateAltCurrency.class);

    private static Map _currencyAttributes = null;

    /**
     * <p>
     * Find the currency mappings from the <tt>application.properties</tt>
     * file, compute the conversion rate and alternate currencies. Insert these
     * new currencies in the resultset from the <code>PipelineContext</code>.
     * </p>
     * <p>
     * If result set is empty then the stage will just execute without any
     * action, since there are no rows/entries to work on.
     * </p>
     * <p>
     * If the result set does not contain the attribute(s) to map from (e.g.
     * price) then the stage will just execute without any action, since there
     * no attributes to work on.
     * </p>
     * 
     * @throws PipelineRuntimeException
     *             if request is not instanceof <code>XMLRequest</code>
     * @see com.intentia.iec.pipeline.runtime.PipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
     */
    public void execute(final PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("Inside CalculateAltCurrency.execute()");

        if (_currencyAttributes == null) {
            setupCurrencyFields();
        }

        if (_currencyAttributes.isEmpty()) {
            return;
        }

        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
        XMLRequest xmlRequest = (XMLRequest) context.getRequest();

        if (!(context.getResponse() instanceof XMLResultset)) {
            throw new PipelineRuntimeException("Contained response object MUST be of type 'XMLResultset'!");
        }
        XMLResultset response = (XMLResultset) context.getResponse();

        BigDecimal conversionRate = conversionRate(xmlRequest);

        setAltCurrency(conversionRate, response);
    }

    /**
     * <p>
     * Parse key value pair from the application property group
     * <code>customStages</code> and populate a Map with these currency
     * mappings. The mapiing specify which currency field corresponds to which
     * alternate currency field.
     * </p>
     * 
     * @throws PipelineRuntimeException
     */
    private void setupCurrencyFields() throws PipelineRuntimeException {

        _currencyAttributes = new HashMap();

        String keyValueString = CustomStagesHelper.getKeyValue(ALT_CURRENCY_KEY);

        if (keyValueString == null) {
            FastStringBuffer msg = new FastStringBuffer();
            msg.append("No property found for key 'AltCurrencyFields' in file '");
            msg.append(CustomStagesHelper.APPLICATION_PROPS);
            msg.append("'. Thus no Alternate currency calculation will be performed!");
            LOG.debug(msg.toString());
            return;
        }
        String[] keyValuePair = keyValueString.split(";");

        if (keyValuePair == null) {
            FastStringBuffer msg = new FastStringBuffer();
            msg.append("Key value string '");
            msg.append(keyValueString);
            msg.append("' from property 'AltCurrencyFields' in file '");
            msg.append(CustomStagesHelper.APPLICATION_PROPS);
            msg.append("' is NOT valid! ");
            msg.append("The string should have format 'key:value;key:value'!");
            LOG.debug(msg);
            return;
        }

        for (int i = 0; i < keyValuePair.length; i++) {
            String[] currencies = keyValuePair[i].split(":");
            if ((currencies[0] == null) || (currencies[1] == null)) {
                FastStringBuffer msg = new FastStringBuffer();
                msg.append("The key value pair number ");
                msg.append(String.valueOf(i + 1));
                msg.append(" in the key value string '");
                msg.append(keyValueString);
                msg.append("' from property 'AltCurrencyFields' in file '");
                msg.append(CustomStagesHelper.APPLICATION_PROPS);
                msg.append("' is NOT valid! ");
                msg.append("The string should have format 'key:value;key:value'!");
                LOG.debug(msg);
                return;
            }
            _currencyAttributes.put(currencies[0], currencies[1]);
        }
    }

    /**
     * <p>
     * Compute the conversion rate based on the exchange rates from parameters
     * in the request. The method will return 0.0 if the conversion rate is not
     * a number or infinite (exchange rate = 0).
     * </p>
     * 
     * @param xmlRequest
     *            the <code>XMLRequest</code> to fetch the exchange rates
     *            from.
     * @return convertion rate
     * @throws PipelineRuntimeException
     *             if either exchange rate is negative
     */
    private BigDecimal conversionRate(final XMLRequest xmlRequest) throws PipelineRuntimeException {
        LOG.debug("inside CalculateAltCurrency.conversionRate()");
        // get parameters from request
        CustomStagesHelper.extractRequestParameters(xmlRequest);
        BigDecimal exchangeRate = CustomStagesHelper.getDecimalValue(xmlRequest.getParameters(), EXCHANGE_RATE);
        BigDecimal alternateExchangeRate = CustomStagesHelper.getDecimalValue(xmlRequest.getParameters(),
                ALT_EXCHANGE_RATE);

        // avoid negative, infinite, and NaN conversion rate values
        if (exchangeRate.compareTo(Decimal.ZERO) < 1) {
            throw new PipelineRuntimeException(
                    "The supplied exchange rate was negative or zero, it must a positive number");
        }
        if (alternateExchangeRate.compareTo(Decimal.ZERO) < 0) {
            throw new PipelineRuntimeException(
                    "The supplied alternative currency exchange rate was negative, it must be positive");
        }

        // Trying to set scale depending on the size of the result. But is this
        // necessary?
        int scale = 20;
        if (alternateExchangeRate.compareTo(exchangeRate.multiply(new BigDecimal("1000000000"))) == 1) {
            // if x/y < 10E-10 ==>> y > x*10E10
            // then dealing with small numbers. Set scale to 30
            scale = 30;
        } else if (exchangeRate.compareTo(alternateExchangeRate.multiply(new BigDecimal("1000000000"))) == 1) {
            // if x/y > 10E10 ==>> x > y*10E10
            // then dealing with huge a number. Set scale to 0
            scale = 0;
        }

        return alternateExchangeRate.divide(exchangeRate, scale, BigDecimal.ROUND_HALF_UP);
    }

    /**
     * <p>
     * Set the alternative currency on the resultset. The method extracts the
     * resultset as a DOM <code>Document</code> and iterates through all the
     * elements. In the iteration each element is checked for attribute name
     * matching a key in the currency map, if a match is found the value of the
     * original currency is extracted and the alternate currency value is
     * computed and inserted as the value of the corresponding attribute from
     * the currency map.
     * </p>
     * 
     * @param conversionRate
     *            the conversion rate between the currencies.
     * @param resultset
     *            the <code>XMLResultset</code> to where the alternative
     *            currencies should be inserted.
     * @throws PipelineRuntimeException
     *             if the method fails to obtain the <code>XMLResultset</code>
     *             as a <code>Document</code>.
     */
    private void setAltCurrency(final BigDecimal conversionRate, final XMLResultset resultset)
            throws PipelineRuntimeException {
        LOG.debug("inside CalculateAltCurrency.setAltCurrency()");

        Document xmlDoc;
        try {
            resultset.beforeFirst();
            xmlDoc = resultset.getDocument();
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Failed to obtain result set as XML document!", e);
        }

        // create an iterator that runs over all elements in the result set
        int whatToShow = NodeFilter.SHOW_ELEMENT;
        NodeIterator iterator = ((DocumentTraversal) xmlDoc).createNodeIterator(xmlDoc, whatToShow, null, true);

        // run through all elements and check for attribute names that matches
        // any in the map
        Element resultsetElement = (Element) iterator.nextNode();
        while (resultsetElement != null) {

            NamedNodeMap attributeNames = resultsetElement.getAttributes();
            for (int i = 0; i < attributeNames.getLength(); i++) {
                // get attribute name and check for for it currency Map
                Attr attribute = (Attr) attributeNames.item(i);
                String currencyName = attribute.getName();

                if (_currencyAttributes.containsKey(currencyName)) {
                    String altCurrencyField = (String) _currencyAttributes.get(currencyName);

                    // get the currency value
                    String currencyValue = ((Element) resultsetElement).getAttribute(currencyName);
                    if (LOG.isDebugEnabled()) {
                        FastStringBuffer msg = new FastStringBuffer();
                        msg.append("Found alternate currency attribute '");
                        msg.append(currencyName);
                        msg.append("' with matching currency field '");
                        msg.append(altCurrencyField);
                        msg.append("'.");
                        LOG.debug(msg.toString());
                    }

                    // compute altCurrency value and insert it as value for
                    // attribute
                    BigDecimal altCurrencyValue;
                    try {
                        BigDecimal currency = new BigDecimal(currencyValue);
                        altCurrencyValue = conversionRate.multiply(currency);
                    } catch (NumberFormatException e1) {
                        FastStringBuffer msg = new FastStringBuffer();
                        msg.append("Failed to parse the value from the result set attribute ");
                        msg.append(currencyName);
                        msg.append(" with the value ");
                        msg.append(currencyValue);
                        msg.append(". Ensure that the value can be parsed as a double.");
                        msg.append(". The alternate currency value inserted was 0.0000!");
                        LOG.info(msg.toString());
                        altCurrencyValue = new BigDecimal("0.0000");
                    }

                    // add atribute to result set row (element)
                    resultsetElement.setAttribute(altCurrencyField, Decimal.toString(altCurrencyValue));
                }
            }
            resultsetElement = (Element) iterator.nextNode();
        }
    }
}
