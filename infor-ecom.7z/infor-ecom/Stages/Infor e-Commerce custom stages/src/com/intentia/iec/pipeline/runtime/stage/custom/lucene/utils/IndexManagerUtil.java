package com.intentia.iec.pipeline.runtime.stage.custom.lucene.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.log4j.Logger;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.solr.util.NumberUtils;

import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.lucene.manager.IndexManager;
import com.intentia.iec.pipeline.runtime.stage.custom.lucene.manager.IndexManagerRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.utils.CommitPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.util.XMLDateFormat;

/**
 * @author 15062
 * 
 */
public final class IndexManagerUtil {

    private static final Logger LOG = Logger.getLogger(IndexManagerUtil.class);

    /**
     * 
     * @param doc
     * @param value
     */
    public static void addKeyField(Document doc, final String value) {
        if (value != null)
            doc.add(new Field(ConstantsForSales.KEY_FIELD, value, Field.Store.YES, Field.Index.UN_TOKENIZED));
    }

    /**
     * 
     * @param doc
     * @param manager
     * @param attributeName
     * @param value
     */
    public static void addIndexField(Document doc, final IndexManager manager, final String attributeName,
            final String value) {
        addIndexField(doc, manager, attributeName, value, null);
    }

    /**
     * 
     * @param doc
     * @param manager
     * @param attributeName
     * @param value
     * @param languageCode
     */
    public static void addIndexField(Document doc, final IndexManager manager, final String attributeName,
            String value, final String languageCode) {
        if (attributeName != null && value != null) {
            Set<String> fields = manager.getIndexFields(attributeName);
            if (fields != null && !fields.isEmpty()) {
                for (String fieldName : fields) {
                    if (ConstantsForSales.TYPE_DATE.equalsIgnoreCase(manager.getFieldType(fieldName)))
                        value = standardizeDateFormat(value);
                    value = standardizeFieldValue(fieldName, value, manager);
                    Field.Index tokenization = manager.getFieldTokenization(fieldName);
                    if (manager.isLocalizedField(fieldName)) {
                        if (languageCode != null) {
                            String localizedFieldName = fieldName + "_" + languageCode;
                            doc.add(new Field(localizedFieldName, value, Field.Store.NO, tokenization));
                            if (manager.isSortableField(fieldName))
                                doc.add(new Field(ConstantsForSales.SORTABLE_FIELD_PREFIX + localizedFieldName, value,
                                        Field.Store.NO, Field.Index.UN_TOKENIZED));
                        } else {
                            Set<String> languageCodes = manager.getLanguageCodes();
                            for (String code : languageCodes) {
                                String localizedFieldName = fieldName + "_" + code;
                                doc.add(new Field(localizedFieldName, value, Field.Store.NO, tokenization));
                                if (manager.isSortableField(fieldName))
                                    doc.add(new Field(ConstantsForSales.SORTABLE_FIELD_PREFIX + localizedFieldName,
                                            value, Field.Store.NO, Field.Index.UN_TOKENIZED));
                            }
                        }
                    } else {
                        doc.add(new Field(fieldName, value, Field.Store.NO, tokenization));
                        if (manager.isSortableField(fieldName))
                            doc.add(new Field(ConstantsForSales.SORTABLE_FIELD_PREFIX + fieldName, value,
                                    Field.Store.NO, Field.Index.UN_TOKENIZED));
                    }
                }
            }
        }
        // Add to "keyword" field
        addKeywordField(doc, manager, value, languageCode);
    }

    private static void addKeywordField(Document doc, final IndexManager manager, final String value,
            final String languageCode) {
        if (value != null) {
            if (manager.hasLocalizedFields()) {
                if (languageCode != null) {
                    doc.add(new Field(ConstantsForSales.KEYWORD_FIELD + "_" + languageCode, value, Field.Store.NO,
                            Field.Index.TOKENIZED));
                } else {
                    Set<String> languageCodes = manager.getLanguageCodes();
                    for (String code : languageCodes) {
                        doc.add(new Field(ConstantsForSales.KEYWORD_FIELD + "_" + code, value, Field.Store.NO,
                                Field.Index.TOKENIZED));
                    }
                }
            } else {
                doc.add(new Field(ConstantsForSales.KEYWORD_FIELD, value, Field.Store.NO, Field.Index.TOKENIZED));
            }
        }
    }

    public static String standardizeFieldName(final String field) {
        String standardizeFieldName = field;
        // lower case field name
        standardizeFieldName = standardizeFieldName.toLowerCase();
        // remove all trailing and in-between whitespaces
        standardizeFieldName = standardizeFieldName.replaceAll("\\s+", "");
        return standardizeFieldName;
    }

    public static String standardizeFieldValue(final String fieldName, final String fieldValue,
            final IndexManager manager) {
        String fieldType = manager.getFieldType(fieldName);
        String standardizeValue = "";

        if (ConstantsForSales.TYPE_INTEGER.equalsIgnoreCase(fieldType)) {
            try {
                int value = Integer.parseInt(fieldValue);
                standardizeValue = NumberUtils.int2sortableStr(value);
            } catch (NumberFormatException e) {
                LOG.error("Unable to parse integer value of '" + fieldName + "' = " + fieldValue, e);
                // ignore exception
            }
        } else if (ConstantsForSales.TYPE_DECIMAL.equalsIgnoreCase(fieldType)) {
            try {
                double value = Double.parseDouble(fieldValue);
                standardizeValue = NumberUtils.double2sortableStr(value);
            } catch (NumberFormatException e) {
                LOG.error("Unable to parse decimal value of '" + fieldName + "' = " + fieldValue, e);
                // ignore exception
            }
        } else if (ConstantsForSales.TYPE_DATE.equalsIgnoreCase(fieldType)) {
            try {
                DateFormat formatter = new SimpleDateFormat(ConstantsForSales.LUCENE_DATE_FORMAT);
                Date date = formatter.parse(fieldValue);
                standardizeValue = NumberUtils.double2sortableStr(date.getTime() + ".00");
            } catch (ParseException e) {
                LOG.error("Unable to parse date value of '" + fieldName + "' = " + fieldValue, e);
                // ignore exception
            }
        } else { // use the original value
            standardizeValue = fieldValue;
        }

        return standardizeValue;
    }

    public static XMLResultset sortXMLResultset(final XMLResultset result) throws IndexManagerRuntimeException {
        XMLResultset sortedXML = null;
        String xslPath = "xml/SortedXMLResultset.xsl";

        try {
            IndexManagerUtil util = new IndexManagerUtil();
            InputStream xslFile = util.getClass().getResourceAsStream(xslPath);
            DOMSource unsorted = new DOMSource(result.getDocument());
            ByteArrayOutputStream sorted = new ByteArrayOutputStream();
            TransformerFactory tFactory = TransformerFactory.newInstance();
            Transformer transformer = tFactory.newTransformer(new StreamSource(xslFile));
            transformer.transform(unsorted, new StreamResult(sorted));
            sortedXML = new XMLResultset(sorted.toString());
            xslFile.close();
            sorted.close();
        } catch (ResultsetException e) {
            throw new IndexManagerRuntimeException("Unable to get XML result set document", e);
        } catch (TransformerConfigurationException e) {
            throw new IndexManagerRuntimeException("Unable to sort XML result set", e);
        } catch (TransformerException e) {
            throw new IndexManagerRuntimeException("Unable to sort XML result set", e);
        } catch (IOException e) {
            throw new IndexManagerRuntimeException("Unable to close streams after sortting XML result set", e);
        }

        return sortedXML;
    }

    public static String standardizeDateFormat(final String value) {
        String formattedDate = null;
        try {
            XMLDateFormat format = new XMLDateFormat();
            Date date = format.parse(value);
            DateFormat formatter = new SimpleDateFormat(ConstantsForSales.LUCENE_DATE_FORMAT);
            formattedDate = formatter.format(date);
        } catch (ParseException e) {
            LOG.debug("Unable to parse date value " + value, e);
            return null;
        }

        return formattedDate;
    }

    public static String getTimeInterval(final long nanoStart, final long nanoEnd) {
        return "[" + (nanoEnd - nanoStart) / 1000000000 + "s:" + ((nanoEnd - nanoStart) % 1000000000) / 10000000
                + "ms]";
    }

    public static XMLResultset getIndexDetails(final String indexName) throws IndexManagerRuntimeException {
        XMLResultset result = null;
        if (indexName != null) {
            try {
                SearchPipelineExecuter pipeline = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                        "LuceneLES", "GetIndexDetails");
                pipeline.setBinding("IndexName", indexName, "eq");
                result = pipeline.execute();
            } catch (PipelineRuntimeException e) {
                throw new IndexManagerRuntimeException("Unable to get index details of '" + indexName + "'", e);
            }
        }
        return result;
    }

    public static XMLResultset getIndexList() throws PipelineRuntimeException {
        XMLResultset result = null;
        try {
            SearchPipelineExecuter pipeline = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                    "LuceneLES", "ListIndexes");
            result = pipeline.execute();
        } catch (PipelineRuntimeException e) {
            throw new PipelineRuntimeException("Unable to fetch Lucene index list", e);
        }
        return result;
    }

    public static void updateIndexStatus(final String indexName, final String status)
            throws IndexManagerRuntimeException {
        if (status != null) {
            Map<String, String> statusAttribute = new HashMap<String, String>();
            statusAttribute.put(ConstantsForSales.STATUS_ATTRIBUTE, status);
            updateIndexDetails(indexName, statusAttribute);
        }
    }

    public static String getIndexCurrentStatus(final String indexName) throws IndexManagerRuntimeException {
        String indexStatus = "";
        try {
            XMLResultset indexdetails = getIndexDetails(indexName);
            if (!indexdetails.isEmpty()) {
                indexdetails.moveFirst();
                indexStatus = indexdetails.getString(ConstantsForSales.STATUS_ATTRIBUTE);
            } else {
                LOG.error("Index details not found. indexName = " + indexName);
            }
        } catch (ResultsetException e) {
            throw new IndexManagerRuntimeException("Unable to fetch current index status. indexName = " + indexName, e);
        }

        return indexStatus;
    }

    public static void updateIndexDetails(final String indexName, final Map<String, String> attributes)
            throws IndexManagerRuntimeException {
        try {
            CommitPipelineExecuter pipeline = new CommitPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                    "LuceneLES", "UpdateIndexDetails");
            pipeline.addEntity();
            pipeline.setEntityKey(ConstantsForSales.INDEX_NAME_ATTRIBUTE, indexName);
            Iterator<String> it = attributes.keySet().iterator();
            while (it.hasNext()) {
                String name = it.next();
                String value = attributes.get(name);
                pipeline.setAttribute(name, value);
            }
            pipeline.execute();
        } catch (PipelineRuntimeException e) {
            throw new IndexManagerRuntimeException("Unable to update Lucene index details", e);
        }
    }

}
