/*
 * Created on 22-03-2004
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.Decimal;

/**
 * <p>
 * Calculate the sales price for the ordered quantity.<br>
 * The stage should be placed in a pipeline after getting product prices from
 * Movex (<tt>OIS320MI / GetPriceLine</tt>).
 * </p>
 * <p>
 * The price for the ordered quantities is calculated as:
 * </p>
 * 
 * <pre>
 *     = SalesPrice * QuantitySalesPrice / Quantity
 * </pre>
 * 
 * <p>
 * In Movex terms:
 * </p>
 * 
 * <pre>
 *     = SAPR * ORQS / ORQA
 * </pre>
 * 
 * <p>
 * The calculated price is written back to the result set as SalesPrice. The
 * total price is also set in response
 * </p>
 * 
 * <p>
 * <b>Required input in <code>PipelineContext</code>:</b><br>
 * The <code>PipelineContext</code> must contain a resultset with the three
 * attributes <tt>SalesPrice</tt>, <tt>QuantitySalesPrice</tt>, and
 * <tt>Quantity</tt>
 * </p>
 * 
 * <p>
 * <b>Generated output in <code>PipelineContext</code>:</b><br>
 * The recalculated <tt>SalesPrice</tt>.
 * </p>
 */
public class CalculatePriceFromQty implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(CalculatePriceFromQty.class);

    /**
     * @see com.intentia.iec.pipeline.runtime.PipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
     */
    public void execute(PipelineContext context) throws PipelineRuntimeException {

        XMLResultset result = (XMLResultset) context.getResponse();
        BigDecimal discountAmt = new BigDecimal(0);
        try {
            if ((result == null) || (result.isEmpty())) {
                return;
            }
            LOG.debug("Inside Calculate price from quantity");
            // only handle the first line
            result.moveFirst();
            // removed unused variables
//            BigDecimal discPrice = null;

            BigDecimal salesPrice = parsePriceParameter(result, ConstantsForSales.SALESPRICE);
            BigDecimal totalPrice = parsePriceParameter(result, ConstantsForSales.TOTALPRICE);
            if ((salesPrice == null) || (salesPrice.doubleValue() < 0.0000001)) {
                return;
            }
            BigDecimal quantity = result.getDecimal(ConstantsForSales.QUANTITY);
            if ((quantity == null) || (quantity.doubleValue() < 0.0000001)) {
                return;
            }
            BigDecimal quantitySalesPrice = result.getDecimal(ConstantsForSales.QUANTITYSALESPRICE);
            if ((quantitySalesPrice == null) || (quantitySalesPrice.doubleValue() < 0.0000001)) {
                return;
            }
            // retrieve all the six discounts returned

            BigDecimal discountAmt1 = result.getDecimal(ConstantsForSales.DISCOUNTAMOUNT1);
            if ((discountAmt1 == null) || (discountAmt1.doubleValue() < 0.0000001)) {
                discountAmt1 = new BigDecimal("0");
            } else {
                discountAmt = discountAmt.add(discountAmt1);
            }
            BigDecimal discountAmt2 = result.getDecimal(ConstantsForSales.DISCOUNTAMOUNT2);
            if ((discountAmt2 == null) || (discountAmt2.doubleValue() < 0.0000001)) {
                discountAmt2 = new BigDecimal("0");
            } else {
                discountAmt = discountAmt.add(discountAmt2);
            }

            BigDecimal discountAmt3 = result.getDecimal(ConstantsForSales.DISCOUNTAMOUNT3);
            if ((discountAmt3 == null) || (discountAmt3.doubleValue() < 0.0000001)) {
                discountAmt3 = new BigDecimal("0");
            } else {
                discountAmt = discountAmt.add(discountAmt3);
            }

            BigDecimal discountAmt4 = result.getDecimal(ConstantsForSales.DISCOUNTAMOUNT4);
            if ((discountAmt4 == null) || (discountAmt4.doubleValue() < 0.0000001)) {
                discountAmt4 = new BigDecimal("0");
            } else {
                discountAmt = discountAmt.add(discountAmt4);
            }

            BigDecimal discountAmt5 = result.getDecimal(ConstantsForSales.DISCOUNTAMOUNT5);
            if ((discountAmt5 == null) || (discountAmt5.doubleValue() < 0.0000001)) {
                discountAmt5 = new BigDecimal("0");
            } else {
                discountAmt = discountAmt.add(discountAmt5);
            }

            BigDecimal discountAmt6 = result.getDecimal(ConstantsForSales.DISCOUNTAMOUNT6);
            if ((discountAmt6 == null) || (discountAmt6.doubleValue() < 0.0000001)) {
                discountAmt6 = new BigDecimal("0");
            } else {
                discountAmt = discountAmt.add(discountAmt6);
            }
            // calculate the sales price from the returned unit price
            BigDecimal price = Decimal.divide(salesPrice.multiply(quantitySalesPrice), quantity);
            LOG.debug("price----------------------------" + price);

            // calculate the discounted price

            if (discountAmt.doubleValue() >= 0 && quantity.doubleValue() > 0) {
//                discPrice = price.subtract(discountAmt.divide(quantity, 2, RoundingMode.HALF_UP)); 
                // if(discPrice !=null && price.compareTo(discPrice)>=0)
                // price=discPrice;
            } else {
//                discPrice = price;
            }

            LOG.debug("Final Price----------------------------" + price);

            if (LOG.isDebugEnabled()) {
                String msg = "CalculatePriceFromQty:";
                msg += " SalesPrice = " + salesPrice.toString();
                msg += " QuantitySalesPrice = " + quantitySalesPrice.toString();
                msg += " Quantity = " + quantitySalesPrice.toString();
                msg += " Discount Amount = " + discountAmt.toString();
                msg += " Calculated price = " + price;
                LOG.debug(msg);
            }
            // update the sales price in the result set.
            result.setString(ConstantsForSales.SALESPRICE, Decimal.toString(price));
            result.setString(ConstantsForSales.TOTALPRICE, Decimal.toString(totalPrice));

        } catch (ResultsetException e) {
            String msg = "Could not calculate sales price.";
            LOG.error(msg, e);
        } finally {
            result.beforeFirst();
        }
    }
    
    /**
     * API sometimes returns two values (ex: 100000000.00	1).
     * If there are two values, the first one is used as the price.
     * @param resultSet
     * @param parameter
     * @return
     * @throws ResultsetException
     */
    private BigDecimal parsePriceParameter(XMLResultset resultSet, String parameter) throws ResultsetException {    	
    	try {
    		BigDecimal value = resultSet.getDecimal(parameter);
    		LOG.debug(parameter + "=" + value);
    		return value;
    	}
    	catch (Exception e) {
    		String value = resultSet.getString(parameter);
    		LOG.debug(parameter + "=" + value);
    		if (value != null) {
        		String[] toks = value.split(" ");
        		if (toks != null && toks.length > 0) {
        			return new BigDecimal(toks[0]);
        		}
    		}
    	}
    	
    	return null;
    }
}
