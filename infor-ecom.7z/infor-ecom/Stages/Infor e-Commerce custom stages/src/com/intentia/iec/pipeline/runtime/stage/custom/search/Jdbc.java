package com.intentia.iec.pipeline.runtime.stage.custom.search;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;

/**
 * A JDBC helper class. Shields clients from JDBC issues (primarily safe clean
 * up).
 */
public interface Jdbc {

    /**
     * Used to keep the SQL together with the prepared statement for debugging
     * purposes.
     */
    class StatementHolder {
        public final PreparedStatement stmt;

        public final String sql;

        public StatementHolder(Connection con, String sql) throws SQLException {
            this.stmt = con.prepareStatement(sql);
            this.sql = sql;
        }

        /**
         * Create a statement holder for batch SQL statements.
         * 
         * @param con
         * @param sqls
         * @throws SQLException
         */
        public StatementHolder(Connection con, String[] sqls) throws SQLException {
            this.sql = getSQLStatement(sqls);
            this.stmt = con.prepareStatement(this.sql);
        }

        /**
         * Creates a single string containing all SQL statements, each separated
         * by ';'.
         * 
         * @param sqls
         * @return
         */
        private String getSQLStatement(String[] sqls) {
            StringBuffer buf = new StringBuffer();

            if (sqls != null) {
                for (int i = 0; i < sqls.length; i++) {
                    buf.append(sqls[i]);
                    // do not append ';' if this is the last statement
                    if (i < (sqls.length - 1)) {
                        buf.append(";");
                    }
                }
            }
            return buf.toString();
        }
    }

    interface RowHandler {
        void processRow(ResultSet rs) throws SQLException, PipelineRuntimeException;
    }

    Connection getConnection() throws PipelineRuntimeException;

    void execute(final StatementHolder stmt, final Object[] params, final RowHandler rh)
            throws PipelineRuntimeException;

    /**
     * Executes a batch of SQL statements each statement having its own
     * RowHandler.
     * 
     * @param stmt
     * @param params
     * @param rh
     * @throws PipelineRuntimeException
     */
    void execute(final StatementHolder stmt, final Object[] params, final RowHandler[] rh)
            throws PipelineRuntimeException;

    void close(final Connection con);

    void close(final PreparedStatement[] stmts);

    void close(final PreparedStatement stmt);

    void close(final ResultSet rs);

    void execute(final String sql, final Object[] params, final RowHandler rh) throws PipelineRuntimeException;

}
