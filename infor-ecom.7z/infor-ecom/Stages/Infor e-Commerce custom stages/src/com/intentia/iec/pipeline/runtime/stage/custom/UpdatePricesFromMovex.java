/*
 * Created on 26-03-2004
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.utils.Decimal;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.util.FastStringBuffer;

/**
 * Class encapsulating functionality to get item prices from Movex.
 * <p>
 * Used as base class for two stages:
 * 
 * @see com.intentia.iec.pipeline.runtime.stage.custom.UpdatePricesInRequestFromMovex
 * @see com.intentia.iec.pipeline.runtime.stage.custom.UpdatePricesInResultFromMovex
 *      <p>
 *      All members are static.
 */
public class UpdatePricesFromMovex {

    private static final Logger LOG = Logger.getLogger(UpdatePricesFromMovex.class);

    public UpdatePricesFromMovex() {
    }

    /**
     * Get a parameter value from the pipeline context.
     * 
     * @param params
     *            parameter block in pipeline context
     * @param name
     *            of parameter to get
     * @return the parameter - empty if not found
     */
    protected static String getString(final Parameters params, final String name) {
        try {
            return params.getString(name);
        } catch (final ParametersException e) {
            LOG.info("Parameter: " + name + ", not found. Returning an empty string.");
            return "";
        }
    }

    /**
     * Convert a string to a double.
     * 
     * @param quantity
     *            string to convert
     * @return double - 0.0 in case of invalid string
     */
    protected static double string2double(final String quantity) {
        try {
            if (quantity == null || quantity.length() == 0) {
                return 0.0d;
            }
            return Double.parseDouble(quantity);
        } catch (final NumberFormatException e) {
            return 0.0d;
        }
    }

    /**
     * Convert a string to a double.
     * 
     * @param quantity
     *            string to convert
     * @return double - 0.0 in case of invalid string
     */
    protected static BigDecimal string2decimal(final String quantity) {
        try {
            if (quantity == null || quantity.length() == 0) {
                return Decimal.ZERO;
            }
            // TODO set scale????
            return new BigDecimal(quantity);
        } catch (final NumberFormatException e) {
            return Decimal.ZERO;
        }
    }

    /**
     * Wrapper class for invoking the search method <code>GetSimple</code> on
     * business object <code>Item</code>.
     * <p>
     * It returns information from the local database.
     */
    protected static final class ItemSearch {

        private final PipelineContext context;

        private final String itemID;

        private boolean isInitialized;

        private String unitCode;

        private String listPrice;

        /**
         * @param itemID
         *            for item to get information on
         */
        ItemSearch(final PipelineContext context, final String itemID) {
            this.context = context;
            this.itemID = itemID;
        }

        /**
         * Gets the unit code for the item.
         * <p>
         * Performs the request indirectly if it has not been run before.
         * 
         * @return The unit code as String
         * @throws PipelineRuntimeException
         */
        String getUnitCode() throws PipelineRuntimeException {
            if (!isInitialized) {
                initialize();
            }
            return unitCode;
        }

        /**
         * Gets the list price for the item.
         * <p>
         * Performs the request indirectly if it has not been run before.
         * 
         * @return The resell price as String
         * @throws PipelineRuntimeException
         */
        String getListPrice() throws PipelineRuntimeException {
            if (!isInitialized) {
                initialize();
            }
            return listPrice;
        }

        /**
         * Method performs the actual request of information on the item.
         * Invoked indirectly by requesting a result.
         * 
         * @throws PipelineRuntimeException
         */
        private void initialize() throws PipelineRuntimeException {

            SearchPipelineExecuter search = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "Item",
                    "GetSimple");
            search.setBinding(ConstantsForSales.ITEMID, itemID, "eq");

            final Parameters params = CustomStagesHelper.getRequestParameters(context);
            search.setParam(ConstantsForSales.CURRENCYCODE_PARAM, getString(params,
                    ConstantsForSales.CURRENCYCODE_PARAM));
            search.setParam(ConstantsForSales.LISTPRICEGROUP_PARAM, getString(params,
                    ConstantsForSales.LISTPRICEGROUP_PARAM));

            XMLResultset resultset = search.execute();
            try {
                resultset.moveFirst();
                unitCode = resultset.getString(ConstantsForSales.UNITCODE);
                listPrice = resultset.getString(ConstantsForSales.LISTPRICE);
            } catch (final ResultsetException e) {
                final String msg = "Could not retrieve " + ConstantsForSales.UNITCODE + " and/or "
                        + ConstantsForSales.LISTPRICE + " from Item.GetSimple";
                LOG.error(msg, e);
                throw new PipelineRuntimeException(msg, e);
            }
        }
    } // class ItemSearch

    /**
     * A wrapper class for calculating prices for a item based on a request to
     * Movex.<br>
     * It invokes search method <code>GetItemPricesSimple</code> on business
     * object <code>MvxPrice</code>).
     * <p>
     * If no connection is available, then the prices are calculated from the
     * list price and IsListPrice is true.
     * <p>
     * Prices are set in the class members.
     */
    protected static final class ItemPrices {

        private final PipelineContext context;

        private BigDecimal resellPrice;

        private BigDecimal linePrice;

        private BigDecimal lineTotal;

        private BigDecimal discount;

        private BigDecimal disPercent;

        private boolean isListPrice;

        private SearchPipelineExecuter findPrices = null;

        /**
         * @param context
         *            pipeline context
         * @throws PipelineRuntimeException
         */
        ItemPrices(final PipelineContext context) throws PipelineRuntimeException {
            this.context = context;
            findPrices = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "MvxPrice",
                    "GetItemPricesSimple");
            setParam(this.context, findPrices);
            resetPrices();
        }

        /**
         * Copy parameters from the method context to the findPrices method
         * context.
         * 
         * @param context
         *            pipeline context
         * @param findPrices
         *            pipeline executer for Movex item price request
         * @throws PipelineException
         */
        private static void setParam(final PipelineContext context, final SearchPipelineExecuter findPrices)
                throws PipelineRuntimeException {

            final Parameters params = CustomStagesHelper.getRequestParameters(context);
            findPrices.setParam(ConstantsForSales.MVXCOMPANY_PARAM, getString(params,
                    ConstantsForSales.MVXCOMPANY_PARAM));
            findPrices.setParam(ConstantsForSales.MVXFACILITY_PARAM, getString(params,
                    ConstantsForSales.MVXFACILITY_PARAM));
            findPrices.setParam(ConstantsForSales.MVXWAREHOUSE_PARAM, getString(params,
                    ConstantsForSales.MVXWAREHOUSE_PARAM));
            findPrices.setParam(ConstantsForSales.MVXORDERTYPE_PARAM, getString(params,
                    ConstantsForSales.MVXORDERTYPE_PARAM));
            findPrices.setParam(ConstantsForSales.USERGROUPID, getString(params, ConstantsForSales.USERGROUPID));
        }

        /**
         * Get resulting resell price.
         * 
         * @return resell price as a string
         */
        String getResellPrice() {
            return resellPrice.toString();
        }

        /**
         * Get resulting line price.
         * 
         * @return line price as a string
         */
        String getLinePrice() {
            return linePrice.toString();
        }

        /**
         * Get resulting line total.
         * 
         * @return line total as a string
         */
        String getLineTotal() {
            return lineTotal.toString();
        }

        /**
         * Get resulting discount.
         * 
         * @return discount as a string
         */
        String getDiscount() {
            return discount.toString();
        }

        /**
         * Get resulting discount percent.
         * 
         * @return discount percent as a string
         */
        String getDisPercent() {
            return disPercent.toString();
        }

        /**
         * Are prices acquired from Movex ("N") or locally ("Y" - is list
         * price).
         * 
         * @return "Y" of "N" - see description above
         */
        String getIsListPrice() {
            return isListPrice ? "Y" : "N";
        }

        /**
         * Reset local variables to prepare a new request by calling getPrices.
         */
        void resetPrices() {
            resellPrice = new BigDecimal("0.0000");
            linePrice = new BigDecimal("0.0000");
            lineTotal = new BigDecimal("0.0000");
            discount = new BigDecimal("0.0");
            disPercent = new BigDecimal("0.0");
            isListPrice = false;
        }

        /**
         * Get and calculate prices for a item - prices are set in the class
         * members.
         * 
         * @param itemID
         *            as a string
         * @param mvxConfigNo
         *            The Movex configurable number (from the sequential
         *            configurator).
         * @param quantity
         *            as a string
         * @return true if prices is calculated and filled in
         * @throws PipelineRuntimeException
         */
        boolean getPrices(final String itemID, final String mvxConfigNo, final String quantityStr)
                throws PipelineRuntimeException {

            resetPrices();
            String mvxConfigId = "";
            BigDecimal quantity = string2decimal(quantityStr);
            if (itemID == null) {
                throw new PipelineRuntimeException("Missing " + ConstantsForSales.ITEMID + " in "
                        + ConstantsForSales.ORDERLINE + " subset.");
            }
            final ItemSearch search = new ItemSearch(context, itemID);
            final String unit = search.getUnitCode();
            LOG.debug("mvxConfigNo: " + mvxConfigNo);
            try	{
            	mvxConfigId = getMvxConfigID(mvxConfigNo);
            	mvxConfigId = mvxConfigId == null ? mvxConfigNo : mvxConfigId;
            } catch (final ResultsetException e) {
            	final String msg = "Could not get result from SequentialConfiguration";
            	LOG.error(msg, e);
            	throw new PipelineRuntimeException(msg, e);
            }	
            // get price from Movex using generated stage
            findPrices.setParam("itemID", itemID);
            if (mvxConfigId != null && !mvxConfigId.isEmpty()) {
            	findPrices.setParam("mvxConfigurableNumber", mvxConfigId);
            } else {
            	LOG.debug("mvxConfigurableNumber is null");
            }
            findPrices.setParam("requestedQuantity", quantityStr);
            findPrices.setParam("unitCode", unit != null ? unit : "");
            XMLResultset rs = findPrices.execute();
            if (rs == null) {
                return false;
            }

            try {
                rs.moveFirst();
                if (rs.getString(ConstantsForSales.TOTALPRICE) != null) {
                    calcMovexPrices(quantity, rs.getString(ConstantsForSales.TOTALPRICE), rs
                            .getString(ConstantsForSales.SALESPRICE));
                    if (LOG.isDebugEnabled()) {
                        FastStringBuffer msg = new FastStringBuffer("Prices from Movex: Total price '");
                        msg.append(rs.getString(ConstantsForSales.TOTALPRICE));
                        msg.append("', Sales price '");
                        msg.append(rs.getString(ConstantsForSales.SALESPRICE));
                        msg.append("'");
                        LOG.debug(msg.toString());
                    }
                    isListPrice = false;
                } else {
                    calcStandAlonePrices(quantity, search.getListPrice());
                    if (LOG.isDebugEnabled()) {
                        LOG.debug("No price from Movex using list price instead: ListPrice '" + search.getListPrice()
                                + "'");
                    }
                    isListPrice = true;
                }
            } catch (ResultsetException e) {
                throw new PipelineRuntimeException("Failed to fetch Movex price from result set", e);
            }
            return true;
        }
        
        private String getMvxConfigID(String id) throws PipelineRuntimeException, ResultsetException {
        	SearchPipelineExecuter searchMvxConfig = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
        	"MvxProductConfiguration", "getNumberByConfigurableID");
        	searchMvxConfig.setParam("ID", id);
        	XMLResultset rsInfo = searchMvxConfig.execute();
        	if(rsInfo.isEmpty()){
        		LOG.debug("rsInfo is EMPTY");
        	}
        	
        	if (rsInfo.moveFirst()) {
        		String mvxId = rsInfo.getString("MvxID");
        		LOG.debug("MvxID = " + mvxId);
        		return mvxId;
        	} else {
        		LOG.debug(id + ": MvxID IS null");
        	return null;
        	}
        }

        /**
         * Calculate remaining prices from Movex prices.
         * <p>
         * Not all values are returned from Movex, but the remaining can be
         * calculated.
         * 
         * @param quantity
         *            quantity as double
         * @param totalPriceStr
         *            total price as String
         * @param salesPriceStr
         *            sales price as String
         */
        private void calcMovexPrices(final BigDecimal quantity, final String totalPriceStr, final String salesPriceStr) {
            lineTotal = string2decimal(totalPriceStr);
            if (!(new BigDecimal("0.0").equals(lineTotal))) {
                resellPrice = string2decimal(salesPriceStr);
                linePrice = resellPrice.multiply(quantity);
                discount = linePrice.subtract(lineTotal);
                // disPercent = discount / linePrice * 100
                disPercent = discount.divide(linePrice, 4, BigDecimal.ROUND_HALF_UP).multiply(new BigDecimal("100"));
            }
        }

        /**
         * Calculate local prices because no prices were returned from Movex.
         * 
         * @param quantity
         *            quantity as double
         * @param totalPriceStr
         *            total price as String
         * @param salesPriceStr
         *            sales price as String
         */
        private void calcStandAlonePrices(final BigDecimal quantity, final String listPriceStr) {
            resellPrice = string2decimal(listPriceStr);
            linePrice = resellPrice.multiply(quantity);
            lineTotal = linePrice;
            discount = new BigDecimal("0.0");
            disPercent = new BigDecimal("0.0");
        }
    } // class ItemPrices
}
