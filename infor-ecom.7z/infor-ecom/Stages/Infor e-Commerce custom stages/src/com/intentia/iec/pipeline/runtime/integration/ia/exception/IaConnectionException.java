package com.intentia.iec.pipeline.runtime.integration.ia.exception;

public class IaConnectionException extends Exception {

	private static final long serialVersionUID = 1L;

	public IaConnectionException() {
		super();
	}

	public IaConnectionException(String message) {
		super(message);
	}

	public IaConnectionException(Throwable cause) {
		super(cause);
	}

	public IaConnectionException(String message, Throwable cause) {
		super(message, cause);
	}

}
