package com.intentia.iec.pipeline.runtime.stage.custom.promotion.rules;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

public class BuyItemImpl implements Rules{
	
	private static final Logger LOG = Logger.getLogger(BuyItemImpl.class);
	
	private static BuyItemImpl instance = null;
	
	private PromotionRule promotionRule = null;

	private String promotionId;
	
	private Map<String, List<String>> promotionalItemsMap;
	
	private XMLRequestHelper xmlHelper = null;
	
	private String languageCode = null;
	
	protected BuyItemImpl() {
	      // Exists only to defeat instantiation.
	}
	public static BuyItemImpl getInstance() {
		if(instance == null) {
			instance = new BuyItemImpl();
		}
		return instance;
	}
	
	public PromotionRule getPromotionRule() {
		return promotionRule;
	}
	
	public void setPromotionId(String promotionId) {
		this.promotionId = promotionId;
	}
	
	public void setPromotionRule(PromotionRule promotionRule) {
		this.promotionRule = promotionRule;
	}
	
	public void setPromotionalItemsMap(Map<String, List<String>> promotionalItemsMap) {
		this.promotionalItemsMap = promotionalItemsMap;
	}
	
	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}
	
	public boolean evaluateOrder(XMLResultset resultSet, XMLRequestHelper xmlHelper) throws ResultsetException{
		LOG.debug("Inside BuyItemImpl.evaluateOrder()");
		boolean isValid = false;
		this.xmlHelper = xmlHelper;
		PromotionRule promotionRule = this.promotionRule;		
		String operator = promotionRule.getOperator();

		if(RulesConstant.OPERATOR_CONTAINS.equals(operator)){
			XMLIterator lineIter = null;
			try {
				lineIter = (XMLIterator) resultSet.getResultset(ConstantsForSales.ORDERLINE);
				if (lineIter == null){
					lineIter = (XMLIterator) resultSet.appendResultset(ConstantsForSales.ORDERLINE);					
				}

				List<String> ruleValueList = promotionRule.getValues();
				String ruleField = promotionRule.getField();
				
				int countMatchItems = 0;
				lineIter.beforeFirst();
				while (lineIter.moveNext()) {
					if(RulesConstant.ITEM_NUMBER.equals(ruleField)){
						isValid = this.evaluateItemNumber(lineIter, ruleValueList, operator);
					} else if(RulesConstant.ITEM_Assortment.equals(ruleField)){
						isValid = this.evaluateItemAssortment(lineIter, ruleValueList, operator);
					} else if(RulesConstant.ITEM_CATEGORY.equals(ruleField)){
						isValid = this.evaluateItemCategory(lineIter, ruleValueList, operator);
					}
					if(isValid){
						countMatchItems++;
					} else {
						break;
					}
				}
				//Should match number of matched items in the Items Rule Value List
				if(countMatchItems == ruleValueList.size()){
					isValid = true;
				}
			} catch (ResultsetException e) {
				throw new ResultsetException("Could not get order lines");
			} catch (TransformerException e) {
				e.printStackTrace();
			} catch (PipelineRuntimeException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return isValid;			
	}
	
	public boolean evaluateOrderLine(XMLIterator xmlOrderline, XMLRequestHelper xmlHelper) throws ResultsetException {
		LOG.debug("Inside BuyItemImpl.evaluateOrderLine()");
		boolean isValid = false;
		this.xmlHelper = xmlHelper;
		try {
			
			PromotionRule promotionRule = this.promotionRule;		
			List<String> ruleValueList = promotionRule.getValues();
			String ruleField = promotionRule.getField();
			String operator = promotionRule.getOperator();
			
			if(RulesConstant.ITEM_NUMBER.equals(ruleField)){
				isValid = this.evaluateItemNumber(xmlOrderline, ruleValueList, operator);
			} else if(RulesConstant.ITEM_Assortment.equals(ruleField)){
				isValid = this.evaluateItemAssortment(xmlOrderline, ruleValueList, operator);
			} else if(RulesConstant.ITEM_CATEGORY.equals(ruleField)){
				isValid = this.evaluateItemCategory(xmlOrderline, ruleValueList, operator);
			}
		} catch (TransformerException e) {
			e.printStackTrace();
		} catch (PipelineRuntimeException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return isValid;		
	}
	
	private boolean evaluateItemNumber(XMLIterator xmlIter, List<String> ruleValueList, String operator)
			throws TransformerException, ResultsetException{
		LOG.debug("Inside BuyItemImpl.evaluateItemNumber()");
		boolean isMatch = false;
		String itemIDFromRequest = xmlIter.getString(RulesConstant.REQ_ITEM_ID);
		if(RulesConstant.OPERATOR_EQUAL.equals(operator)){
			if (ruleValueList.contains(itemIDFromRequest)){
				//Item should match value
				isMatch = true;
			}				
		} else if (RulesConstant.OPERATOR_NOT_EQUAL.equals(operator)){
			if (ruleValueList.contains(itemIDFromRequest)){
				//Item should not match value
				isMatch = false;
			}
		} else if (RulesConstant.OPERATOR_CONTAINS.equals(operator)){
			if (ruleValueList.contains(itemIDFromRequest)){
				//Item should match value
				isMatch = true;
			}
		}			
		return isMatch;
	}
	
	private boolean evaluateItemAssortment(XMLIterator xmlIter, List<String> ruleValueList, String operator)
			throws TransformerException, ResultsetException, PipelineRuntimeException, SQLException{
		LOG.debug("Inside BuyItemImpl.evaluateItemAssortment()");
		boolean isMatch = false;
		String itemIDFromRequest = xmlIter.getString(RulesConstant.REQ_ITEM_ID);
		for (String value : ruleValueList) {
			List<String> itemList = getItemsByAssortment(value);
			if(RulesConstant.OPERATOR_EQUAL.equals(operator)){
				if (itemList.contains(itemIDFromRequest)  ){
					//Item should match value
					isMatch = true;
					break;
				}				
			} else if (RulesConstant.OPERATOR_NOT_EQUAL.equals(operator)){
				if (itemList.contains(itemIDFromRequest) ){
					//Item should not match value
					isMatch = false;
					break;
				}
			} else if (RulesConstant.OPERATOR_CONTAINS.equals(operator)){
				if (itemList.contains(itemIDFromRequest) ){
					//Item should match value
					isMatch = true;
					break;
				}
			} else {
				break;
			}
		}
		return isMatch;
	}
	
	private boolean evaluateItemCategory(XMLIterator xmlIter, List<String> ruleValueList, String operator)
			throws TransformerException, ResultsetException, PipelineRuntimeException, SQLException{
		LOG.debug("Inside BuyItemImpl.evaluateItemCategory()");
		boolean isMatch = false;
		String itemIDFromRequest = xmlIter.getString(RulesConstant.REQ_ITEM_ID);
		for (String value : ruleValueList) {
			List<String> itemList = getItemsByCategory(value);
			if(RulesConstant.OPERATOR_EQUAL.equals(operator)){
				//Item should match value
				if (itemList.contains(itemIDFromRequest)){
					isMatch = true;
					break;
				}	
			} else if (RulesConstant.OPERATOR_NOT_EQUAL.equals(operator)){
				if (itemList.contains(itemIDFromRequest)){
					//Item should not match value
					isMatch = false;
					break;
				}
			} else if (RulesConstant.OPERATOR_CONTAINS.equals(operator)){
				if (itemList.contains(itemIDFromRequest)){
					//Item should match value
					isMatch = true;
					break;
				}
			} else {
				break;
			}
		}
		return isMatch;
	}

    private List<String> getItemsByAssortment(String assortmentName) throws PipelineRuntimeException, SQLException {
    	LOG.debug("Inside BuyItemImpl.getItemsByAssortment()");    	
    	List<String> itemList = new ArrayList<String>();
		PreparedStatement pstmt = null;
		Connection conn = null;
		try {
			conn = (Connection) CustomStagesHelper.getConnection("esales.cursor");
			String selectItemByAssortment = "SELECT DISTINCT item.itemNumber "
					+ "FROM Assortment assortment "
					+ "LEFT JOIN AssortmentCategory assortCat ON assortCat.assortmentId = assortment.id "
					+ "LEFT JOIN CategoryExplosion ce ON ce.parentId = assortCat.categoryId "
					+ "LEFT JOIN CategoryItem catItem ON catItem.categoryId = ce.descendantId "
					+ "INNER JOIN Item item ON item.id = catItem.itemId WHERE assortment.name = ?";
			
			pstmt = conn.prepareStatement(selectItemByAssortment);
			pstmt.setString(1, assortmentName);

			ResultSet rs = pstmt.executeQuery();
			while (rs.next()){
				String itemNumber = rs.getString(1);
				if(itemNumber != null && !"".equals(itemNumber) 
						&& !itemList.contains(itemNumber)){
					itemList.add(itemNumber);
				}
			}
			
		} catch (SQLException se) {
			throw new PipelineRuntimeException("Error executing updateOrderHeaderTotalsFromWS function", se);
		} catch (Exception e) {
			throw new PipelineRuntimeException(e);
		} finally {
			pstmt.close();
			conn.close();
		}
    	
    	return itemList;
    }
	
    private List<String> getItemsByCategory(String categoryID) throws PipelineRuntimeException, SQLException{
    	LOG.debug("Inside BuyItemImpl.getItemsByCategory()");    	
    	List<String> itemList = new ArrayList<String>();
		PreparedStatement pstmt = null;
		Connection conn = null;
		try {
			conn = (Connection) CustomStagesHelper.getConnection("esales.cursor");
			String selectItemByCategory = "SELECT DISTINCT item.itemNumber "
					+ "FROM CategoryExplosion ce "
					+ "LEFT JOIN CategoryItem catItem ON catItem.categoryId = ce.descendantId "
					+ "INNER JOIN Item item ON item.id = catItem.itemId "
					+ "WHERE ce.parentId = ?";
			
			pstmt = conn.prepareStatement(selectItemByCategory);
			pstmt.setString(1, categoryID);

			ResultSet rs = pstmt.executeQuery();
			while (rs.next()){
				String itemNumber = rs.getString(1);
				if(itemNumber != null && !"".equals(itemNumber) 
						&& !itemList.contains(itemNumber)){
					itemList.add(itemNumber);
				}
			}
			
		} catch (SQLException se) {
			throw new PipelineRuntimeException("Error executing updateOrderHeaderTotalsFromWS function", se);
		} catch (Exception e) {
			throw new PipelineRuntimeException(e);
		} finally {
			pstmt.close();
			conn.close();
		}
    	
    	
    	return itemList;
    }
    
}
