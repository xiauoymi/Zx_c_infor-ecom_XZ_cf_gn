/*
 * Created on 03-03-2006
 */
package com.intentia.iec.pipeline.runtime.custom.pim;

/**
 * Class representing an XML request &lt;subset&gt; element (and its content).
 * 
 * @author PEDJES0
 * 
 */
public class Subset extends Set {

    private final String name;

    private String key = null;

    public Subset(final String name) {
        this.name = name;
    }

    public Subset(final String name, final String key) {
        this.name = name;
        this.key = key;
    }

    public final void setKey(final String key) {
        this.key = key;
    }

    public final String getKey() {
        return key;
    }

    public final String getName() {
        return name;
    }
}
