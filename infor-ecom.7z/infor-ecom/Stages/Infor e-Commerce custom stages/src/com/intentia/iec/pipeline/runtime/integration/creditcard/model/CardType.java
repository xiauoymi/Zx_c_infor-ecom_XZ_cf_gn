package com.intentia.iec.pipeline.runtime.integration.creditcard.model;

public enum CardType {
	AMEX,
	VISA,
	MC,
	DISC
}
