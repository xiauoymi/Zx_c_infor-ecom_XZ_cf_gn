package com.intentia.iec.pipeline.runtime.integration.erp.model;

/**
 * 
 * @author ejamolod
 * 
 */
public class LinePrice {

	private String itemId;

	private String customerItemId;

	private String warehouseId;

	private String unitCode;

	private String currencyId;

	private double quantity;

	private double unitPriceAmount;

	private double extendedAmount;

	private double distributedChargeAmount;

	private double totalAmount;

	private String configurationNumber;
	
	private double salesPrice;
	
	private double lineAmount;
	
	private double discountAmount;
	
	private double netAmount;

	private boolean hasWSCallError;
	
	private String msgError;
	
	private String msgCodeError;
	
	private String shippingAddressId;

	public double getSalesPrice() {
		return salesPrice;
	}

	public void setSalesPrice(double salesPrice) {
		this.salesPrice = salesPrice;
	}

	public double getLineAmount() {
		return lineAmount;
	}

	public void setLineAmount(double lineAmount) {
		this.lineAmount = lineAmount;
	}

	public double getDiscountAmount() {
		return discountAmount;
	}

	public void setDiscountAmount(double discountAmount) {
		this.discountAmount = discountAmount;
	}

	public double getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public String getCustomerItemId() {
		return customerItemId;
	}

	public void setCustomerItemId(String customerItemId) {
		this.customerItemId = customerItemId;
	}

	public String getWarehouseId() {
		return warehouseId;
	}

	public void setWarehouseId(String warehouseId) {
		this.warehouseId = warehouseId;
	}

	public String getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(String unitCode) {
		this.unitCode = unitCode;
	}

	public String getCurrencyId() {
		return currencyId;
	}

	public void setCurrencyId(String currencyId) {
		this.currencyId = currencyId;
	}

	public double getQuantity() {
		return quantity;
	}

	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}

	public double getUnitPriceAmount() {
		return unitPriceAmount;
	}

	public void setUnitPriceAmount(double unitPriceAmount) {
		this.unitPriceAmount = unitPriceAmount;
	}

	public double getExtendedAmount() {
		return extendedAmount;
	}

	public void setExtendedAmount(double extendedAmount) {
		this.extendedAmount = extendedAmount;
	}

	public double getDistributedChargeAmount() {
		return distributedChargeAmount;
	}

	public void setDistributedChargeAmount(double distributedChargeAmount) {
		this.distributedChargeAmount = distributedChargeAmount;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getConfigurationNumber() {
		return configurationNumber;
	}

	public void setConfigurationNumber(String configurationNumber) {
		this.configurationNumber = configurationNumber;
	}

	public boolean isHasWSCallError() {
		return hasWSCallError;
	}

	public void setHasWSCallError(boolean hasWSCallError) {
		this.hasWSCallError = hasWSCallError;
	}

	public String getMsgError() {
		return msgError;
	}

	public void setMsgError(String msgError) {
		this.msgError = msgError;
	}

	public String getMsgCodeError() {
		return msgCodeError;
	}

	public void setMsgCodeError(String msgCodeError) {
		this.msgCodeError = msgCodeError;
	}
	
	public String getShippingAddressId(){
		return this.shippingAddressId;
	}
	
	public void setShippingAddressId(String shippingAddressId){
		this.shippingAddressId=shippingAddressId;
	}
	
}
