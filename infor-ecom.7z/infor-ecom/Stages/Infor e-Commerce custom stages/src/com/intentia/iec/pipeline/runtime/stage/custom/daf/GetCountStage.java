package com.intentia.iec.pipeline.runtime.stage.custom.daf;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.xml.sax.SAXException;

import com.intentia.icp.common.CMException;
import com.intentia.icp.common.CMItems;
import com.intentia.icp.common.SearchArgument;
import com.intentia.icp.common.SearchQuery;
import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.custom.daf.drawing.DafDrawingConstants;

/**
 * Counts the number of items in a particular DAF entity.
 *
 */
public class GetCountStage extends AbstractDafSearchStage{
	private static final Logger LOG = Logger.getLogger(GetCountStage.class);
	
	private int count = 0;
	
	private static final String TYPE_DRAWINGS = "Drawings";
	
	private static final String TYPE = "type";
	
	private static final String PARAMETER_RET = "ret";

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafStage#getAttributeToDafDatabaseField(java.lang.String)
	 */
	@Override
	public String getAttributeToDafDatabaseField(String attribute) {
		return null;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getQuery(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public String getQuery(PipelineContext context) throws ParametersException, ParserConfigurationException, SAXException, Exception {
		XMLRequest request = (XMLRequest) context.getRequest();
		Parameters param = request.getParameters();
		if (param != null) {
			String type = param.getString(TYPE);
			if (TYPE_DRAWINGS.equals(type)) {
				// for drawing types, exclude empty names and item numbers
				StringBuffer buf = new StringBuffer();
				appendQuerySingleOperand(buf, DafDrawingConstants.COLUMN_NAME, SearchArgument.SEARCH_OP_IS_NOT_NULL);
				appendQuerySingleOperand(buf, DafDrawingConstants.COLUMN_ITEM_NUMBER, SearchArgument.SEARCH_OP_IS_NOT_NULL);
				
				// if Equipment=enabled AND Parts=disabled, count only drawings with serial numbers
				if ("true".equals(CustomStagesHelper.getKeyValue(DafDrawingConstants.ApplicationProperty.EQUIPMENT_PORTAL)) && 
					!"true".equals(CustomStagesHelper.getKeyValue(DafDrawingConstants.ApplicationProperty.SPS_ENABLED))) {
					appendQuerySingleOperand(buf, DafDrawingConstants.COLUMN_SERIAL_NUMBER, SearchArgument.SEARCH_OP_IS_NOT_NULL); 
					buf.append(" " + SearchQuery.SEARCH_TYPE_AND + " " + DafDrawingConstants.COLUMN_SERIAL_NUMBER + " " + SearchArgument.SEARCH_OP_NOT_EQUAL + "\"\"");
		        }
				
				// if Parts=enabled AND Equipment=disabled, count only drawings without serial numbers
				if (!"true".equals(CustomStagesHelper.getKeyValue(DafDrawingConstants.ApplicationProperty.EQUIPMENT_PORTAL)) && 
						"true".equals(CustomStagesHelper.getKeyValue(DafDrawingConstants.ApplicationProperty.SPS_ENABLED))) {
					buf.append(" " + SearchQuery.SEARCH_TYPE_AND + " (" + DafDrawingConstants.COLUMN_SERIAL_NUMBER + " " + SearchArgument.SEARCH_OP_IS_NULL);
					buf.append(" " + SearchQuery.SEARCH_TYPE_OR + " " + DafDrawingConstants.COLUMN_SERIAL_NUMBER + " " + SearchArgument.SEARCH_OP_EQUAL + "\"\"");
					buf.append(")");
				}
				
				return DafDrawingConstants.TABLE + "[" + buf.toString() + "]";
			}
		}
		return null;
	}
	
	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafStage#getEmptyResultSet()
	 */
	@Override
	public XMLResultset getEmptyResultSet() {
        String ret = ("<?xml version='1.0' encoding='UTF-8'?>"
                + "<resultset object='DocumentArchive'/>");
        return new XMLResultset(ret);        
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getResultSize()
	 */
	@Override
	public int getResultSize() {		
		return 0;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getStartIndex()
	 */
	@Override
	public int getStartIndex() {
		return 0;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#processResult(com.intentia.icp.common.CMItems, int[])
	 */
	@Override
	public XMLResultset processResult(CMItems resultItems, int[] dafStatus) throws CMException {
		if (resultItems != null) {
			// just get the item count
			this.count = resultItems.size();
		}
		return getEmptyResultSet();
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#setOutputParameters(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public void setOutputParameters(PipelineContext context) throws PipelineRuntimeException {
		// set the count
		LOG.debug("count="+count);
		CustomStagesHelper.setResponseParameter(context, PARAMETER_RET, String.valueOf(count));
	}
}
