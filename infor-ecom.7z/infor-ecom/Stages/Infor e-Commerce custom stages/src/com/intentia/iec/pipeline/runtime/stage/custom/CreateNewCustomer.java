package com.intentia.iec.pipeline.runtime.stage.custom;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Document;

import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.connection.ConnectorException;
import com.intentia.iec.connection.IMovexApiResultset;
import com.intentia.iec.connection.IMovexConnection;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

/**
 * Stage to modify update request when Create New Customer is true for single
 * users for populating attributes
 * <p>
 * <b>UsergroupKey and ExtID</b><br>
 * <b>with CUNO fetched from M3</b><br>
 * Input parameters: <code>mvxCompany</code>, <code>mvxDivision</code>,
 * <code>mvxCUNO(CUTM)</code>, <code>name</code> and <code>address1</code>
 * </p>
 * Output parameters: <code>CUNO</code> and <code>ERRM</code>
 */

public class CreateNewCustomer implements PipelineStage {

    public synchronized boolean initConfiguration() throws PipelineRuntimeException {
        boolean isInitialized = false;

        String createCustomer = CustomStagesHelper.getKeyValue(Create_NewCustomer); // getting
                                                                                    // value
                                                                                    // of
        // Application Property.
		
		String IONcreateCustomer = CustomStagesHelper.getKeyValue("ION.Process Customer");

        if (createCustomer == null) {
            throw new PipelineRuntimeException("Error in reading " + Create_NewCustomer + " application property");
        }

        if ("true".equalsIgnoreCase(createCustomer) || "true".equals(IONcreateCustomer)) {
            isInitialized = true;
        }

        return isInitialized;
    }

    private static final Logger LOG = Logger.getLogger(CreateNewCustomer.class);

    private static String EXT_ID = "ExtID";

    private static String CUSTOMER_NUMBER = "UserGroupKey";

    private static boolean IsInsert;

    private static String Create_NewCustomer = "Movex Connector.Create New Customer";
    
    private Connection conn;

    private PreparedStatement pstmt;
    
    private XMLRequest xmlRequest = null;

    public CreateNewCustomer() {
        super();
    }

    public void execute(PipelineContext context) throws PipelineRuntimeException {
        /* Check if the Application Property is true for Create New customer */
        if (initConfiguration()) {
            LOG.debug("Inside CreateNewCustomer.execute()");

            if (!(context.getRequest() instanceof XMLRequest)) {
                throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
            }
            
            xmlRequest = (XMLRequest) context.getRequest();          
            
            try {
                XMLRequest.extractRequestParameters(xmlRequest);                
                if ("Y".equals(xmlRequest.getParameters().getString("InsertRequest"))) {
                    IsInsert = true;
                }

                else {
                    IsInsert = XMLRequestHelper.isInsertRequest(xmlRequest);
                }
				
				String isIONEnabled = CustomStagesHelper.getKeyValue("ION.Enabled");
				String processCustomer = CustomStagesHelper.getKeyValue("ION.Process Customer");
				
				if (IsInsert && (!("true".equals(isIONEnabled)) && !("true".equals(processCustomer))))
				    getCUNO(xmlRequest, context, xmlRequest.getParameters().getString("fromSURegister"));
                else if ("true".equals(isIONEnabled) && ("true".equals(processCustomer))) {
					try {
						// Update UserGroup_Key
						String CUNO = xmlRequest.getParameters().getString("CUNO");
						LOG.debug("CUNO: " +CUNO);
						updateUserGroupKey(xmlRequest, CUNO);
						
						XMLResultset result = (XMLResultset) context.getResponse();
						result.beforeFirst();
				        result.moveNext();
						// Update CustomerAddress_CustomerID
						String addressKey = result.getString("AddressID");
						String userGroupId = result.getString("UserGroupID");
						
						updateCustomerAddressCustomerID(userGroupId, addressKey);
					
					} catch (Exception e) {
						LOG.debug("Error extracting XMLResultset!");
					}
				}
				else
                    System.out.println("The request is an Update Request hence it will not be manipulated!");
            } catch (ParametersException e) {
                throw new PipelineRuntimeException("Parameter value cannot be extracted", e);
            } catch (PipelineRuntimeException e) {
                throw new PipelineRuntimeException("Unable to determine the Nature of request!", e);
            } catch (RequestException e) {
                throw new PipelineRuntimeException("Error extracting request parameters!", e);
            }
        }

    }
    
    /*
     * Establish connection with M3 call CRS610MI.Add method to get the CUNO and
     * populate it into ExtID and UserGroupKey attributes in request
     */

    private void getCUNO(XMLRequest xmlRequest, PipelineContext context,
    		String isSURegister) throws PipelineRuntimeException {
        String CUNO = null;

        if ("Y".equals(isSURegister)) {
        	CUNO = getCUNOFromM3SingleUser(xmlRequest, context); // getting SingleUser CUNO from M3
        	
        } else {
        	CUNO = getCUNOFromM3(xmlRequest, context); // getting CUNO from M3
        }
        
        // Server
        if (CUNO != null && CUNO.length() > 0) {           
            LOG.debug("Setting CUNO in ExtID and UserGroupKey: " + CUNO);
            updateUserGroupKey(xmlRequest, CUNO);
			
            try {
                Node node1 = XMLRequestHelper.getRequestNode(xmlRequest,
                        "request/entities/entity/attributes/attribute[@name='" + EXT_ID + "']/text()");
                node1.setNodeValue(CUNO);
                Node node2 = XMLRequestHelper.getRequestNode(xmlRequest,
                        "request/entities/entity/attributes/attribute[@name='" + CUSTOMER_NUMBER + "']/text()");
                node2.setNodeValue(CUNO);
                
                context.setRequest(xmlRequest);
            } catch (Exception e) {
                throw new PipelineRuntimeException("Unable to set ExtID and UserGroupKey in request!", e);
            }

        }
    }
    
    /**
     * Update the key of the single user company
     * 
     * @param request
     * @param CUNO
     * @throws PipelineRuntimeException
     */
    private void updateUserGroupKey(XMLRequest request, String CUNO) throws PipelineRuntimeException {
        try {
            LOG.debug("Entering updateUserGroupKey()");
            conn = (Connection) CustomStagesHelper
                    .getConnection("esales.cursor");
            String sql = "update UserGroup set [key] = ? where [key] = ?";
            pstmt = conn.prepareStatement(sql);

            String origKey = request.getParameters().getString("OrigKey");
            pstmt.setString(1, CUNO);
            pstmt.setString(2, origKey);

            pstmt.executeUpdate();
            pstmt.clearParameters();

            if (XMLRequestHelper.isUpdateRequest(request)) {
                Document xmlDoc = request.getRequestDoc();

                Node nodeEntity = XPathAPI.selectSingleNode(xmlDoc, "/request/entities/entity/keys/key/@value");                
                nodeEntity.getFirstChild().setNodeValue(CUNO);
            }

            LOG.debug("Exiting updateUserGroupKey");
        } catch (SQLException se) {
            throw new PipelineRuntimeException("Error executing updateSubmittedOrderHeader function", se);
        } catch (ParametersException e) {
            throw new PipelineRuntimeException(e);
        } catch (TransformerException te) {
            throw new PipelineRuntimeException(te);
        } catch (RequestException re) {
            throw new PipelineRuntimeException(re);
        } finally {
            try {
                pstmt.close();
                pstmt = null;
            } catch (Exception e) {
                LOG.error("Error when trying to close prepared statement.");
            }
            try {
                conn.close();
                conn = null;
            } catch (Exception e) {
                LOG.error("Error when trying to close connection.");
            }
        }

    }

    /**
     * Update the customerID of the customerAddress table
     * 
     * @param addressKey
     * @param UserGroupID
     * @throws PipelineRuntimeException
     */
    private void updateCustomerAddressCustomerID(String userGroupId, String addressKey) throws PipelineRuntimeException {
        try {
            LOG.debug("Entering updateCustomerAddressCustomerID");
            conn = (Connection) CustomStagesHelper
                    .getConnection("esales.cursor");
            String sql = "update CustomerAddress set customerId = ? where [key] = ?";
            pstmt = conn.prepareStatement(sql);

            pstmt.setString(1, userGroupId);
            pstmt.setString(2, addressKey);

            pstmt.executeUpdate();
            pstmt.clearParameters();
			
            LOG.debug("Exiting updateCustomerAddressCustomerID");
        } catch (SQLException se) {
            throw new PipelineRuntimeException("Error executing  updateCustomerAddressCustomerID function", se);
        } finally {
            try {
                pstmt.close();
                pstmt = null;
            } catch (Exception e) {
                LOG.error("Error when trying to close prepared statement.");
            }
            try {
                conn.close();
                conn = null;
            } catch (Exception e) {
                LOG.error("Error when trying to close connection.");
            }
        }
    }

    /**
     * Retrieve Customer status from M3
     * 
     * @param request
     * @param context
     * @param con
     * @param CUNO
     * @return
     * @throws PipelineRuntimeException
     */
    private boolean isStatusDefinite(XMLRequest request, PipelineContext context, IMovexConnection con, String CUNO)
            throws PipelineRuntimeException {
        boolean isDefinite = false;
        try {
            Map m3Inputs = new HashMap();
            m3Inputs.put(IMovexConnection.TRANSACTION, "GetBasicData");
            m3Inputs.put("CONO", request.getParameters().getString("mvxCompany"));
            m3Inputs.put("CUNO", CUNO);
            IMovexApiResultset m3result = CustomStagesHelper.callMovex(context, con, m3Inputs, "mvxStatus");
            String customerStatus = m3result.getParamAsString("STAT");
            if (customerStatus == null || "".equals(customerStatus)) {
                customerStatus = "NOK";
            }
            CustomStagesHelper.setResponseParameter(context, "customerStatus", customerStatus);
            if ("20".equals(customerStatus)) {                
                isDefinite = true;
            }
        } catch (ParametersException pe) {
            throw new PipelineRuntimeException(pe);
        }
        return isDefinite;
    }
    
    /**
     * Add the OrderPlacement value in the request.
     * 
     * @param request
     * @throws PipelineRuntimeException
     */
    private void setOrderPlacement(XMLRequest request) throws PipelineRuntimeException {
        try {
            Document xmlDoc = request.getRequestDoc();
            // Add/Update orderPlacement attribute
            Node orderPlacementNode = XPathAPI.selectSingleNode(xmlDoc,
                    "request/entities/entity/attributes/attribute[@name='OrderPlacement']");
            if (orderPlacementNode == null) {
                Element attrElem = xmlDoc.createElement("attribute");
                attrElem.setAttribute("name", "OrderPlacement");
                attrElem.appendChild(xmlDoc.createTextNode("N"));
                orderPlacementNode = XPathAPI.selectSingleNode(xmlDoc, "request/entities/entity/attributes");
                orderPlacementNode.appendChild(attrElem);
            } else {
                orderPlacementNode.getFirstChild().setNodeValue("N");
            }
        } catch (RequestException re) {
            throw new PipelineRuntimeException(re);
        } catch (TransformerException te) {
            throw new PipelineRuntimeException(te);
        }
    }

    private String getCUNOFromM3(XMLRequest request, PipelineContext context) 
    		throws PipelineRuntimeException {
        String M3CUNO = null;
        String ERROR = null;
        XMLResultset result = (XMLResultset) context.getResponse();
        try {
            if ((result == null) || (result.isEmpty())) {
                throw new PipelineRuntimeException("Resultset is empty.");
            }
            result.moveFirst();
            
            XMLRequest.extractRequestParameters(request);

            LOG.debug("getCUNOFromM3()");

            // get a connection to movex and execute the movex call
            IMovexConnection con = (IMovexConnection) CustomStagesHelper.getConnection("esales.CRS610MI");

            // Build up movex api request
            Map m3Inputs = new HashMap();
            // transaction name must be included
            m3Inputs.put(IMovexConnection.TRANSACTION, "Copy");
            // transaction input fields
            m3Inputs.put("CONO", request.getParameters().getString("mvxCompany"));
            m3Inputs.put("DIVI", request.getParameters().getString("mvxDivision"));
            m3Inputs.put("CUTM", request.getParameters().getString("mvxCUNO"));
            
            m3Inputs.put("CUNM", result.getString("Name"));
            m3Inputs.put("CUA1", result.getString("Address1"));
            m3Inputs.put("CUA2", result.getString("Address2"));
            m3Inputs.put("PONO", result.getString("Zip"));
            m3Inputs.put("PHNO", result.getString("Phone"));
            m3Inputs.put("TFNO", result.getString("Fax"));
            m3Inputs.put("MAIL", result.getString("Email"));
            m3Inputs.put("ECAR", result.getString("StateID"));            
            m3Inputs.put("CSCD", result.getString("CountryID"));
            m3Inputs.put("CFC1", result.getString("CustomerField1"));
            m3Inputs.put("CFC2", result.getString("CustomerField2"));
            m3Inputs.put("CFC3", result.getString("CustomerField3"));
            m3Inputs.put("CFC4", result.getString("CustomerField4"));
            m3Inputs.put("CFC5", result.getString("CustomerField5"));
            
            
            String cityField = CustomStagesHelper.getKeyValue(ConstantsForSales.MAP_CITY_TO);
            if ((cityField != null) && (cityField.length() > 0)) {
                m3Inputs.put(cityField, result.getString("City"));
            }

            IMovexApiResultset m3result = CustomStagesHelper.callMovex(context, con, m3Inputs, "mvxStatus");

            // Get Customer Number;
            M3CUNO = m3result.getParamAsString("CUNO");
            ERROR = m3result.getParamAsString("ERRM");
            
            if (m3result.getParamAsString("CUNO") != null && !m3result.getParamAsString("CUNO").equalsIgnoreCase("")) {                
                M3CUNO = (m3result.getParamAsString("CUNO")); // setting value
                
                //If the Customer status in M3 is not 20 (definite), then set OrderPlacement value to "No"
                if (!isStatusDefinite(request, context, con, M3CUNO)) {
                    setOrderPlacement(request);
                }   

                attachPromotionM3Customer(request, context, M3CUNO);

            } else {
                throw new PipelineRuntimeException("CUNO returned from M3 is either null or doesnt have a value!:"
                        + ERROR);
            }

            LOG.debug("Inside getCUNOFromM3() closing connection............... ");
			
			// Update CustomerAddress_CustomerID
			String addressKey = result.getString("AddressID");
			String userGroupId = result.getString("UserGroupID");
			
			updateCustomerAddressCustomerID(userGroupId, addressKey);

            con.close(); // close connection

        } catch (RequestException e) {
            throw new PipelineRuntimeException(e);
        } catch (ParametersException e) {
            throw new PipelineRuntimeException(e);
        } catch (ConnectorException e) {
            throw new PipelineRuntimeException(e);
        } catch (ResultsetException e) {
            String msg = "Could not retrieve values.";
            LOG.error(msg, e);
        } finally {
    		result.beforeFirst();
        }

        return M3CUNO;
    }
    
    private String getCUNOFromM3SingleUser(XMLRequest request, PipelineContext context) 
    		throws PipelineRuntimeException {
        String M3CUNO = null;
        String ERROR = null;
        try {
            XMLRequest.extractRequestParameters(request);

            LOG.debug("getCUNOFromM3SingleUser()");

            // get a connection to movex and execute the movex call
            IMovexConnection con = (IMovexConnection) CustomStagesHelper.getConnection("esales.CRS610MI");

            // Build up movex api request
            Map m3Inputs = new HashMap();
            // transaction name must be included
            m3Inputs.put(IMovexConnection.TRANSACTION, "Copy");
            // transaction input fields
            m3Inputs.put("CONO", request.getParameters().getString("mvxCompany"));
            m3Inputs.put("DIVI", request.getParameters().getString("mvxDivision"));
            m3Inputs.put("CUTM", request.getParameters().getString("mvxCUNO"));
            
            m3Inputs.put("CUNM", request.getParameters().getString("name"));
            m3Inputs.put("CUA1", request.getParameters().getString("address1"));
            m3Inputs.put("CUA2", request.getParameters().getString("address2"));            
            m3Inputs.put("PONO", request.getParameters().getString("zip"));
            m3Inputs.put("CSCD", request.getParameters().getString("country"));
            
            if (!"".equals(request.getParameters().getString("state"))) {
                m3Inputs.put("ECAR", request.getParameters().getString("state"));    
            }
            
            String mapCityTo = CustomStagesHelper.getKeyValue(ConstantsForSales.MAP_CITY_TO);
            if ((mapCityTo != null) && (mapCityTo.length() > 0)) {
                m3Inputs.put(mapCityTo, request.getParameters().getString("city"));    
            }

            IMovexApiResultset m3result = CustomStagesHelper.callMovex(context, con, m3Inputs, "mvxStatus");

            // Get Customer Number;
            M3CUNO = m3result.getParamAsString("CUNO");
            ERROR = m3result.getParamAsString("ERRM");
            
            if (m3result.getParamAsString("CUNO") != null && !m3result.getParamAsString("CUNO").equalsIgnoreCase("")) {                
                M3CUNO = (m3result.getParamAsString("CUNO")); // setting value
                
                //If the Customer status in M3 is not 20 (definite), then set OrderPlacement value to "No"
                if (!isStatusDefinite(request, context, con, M3CUNO)) {
                    setOrderPlacement(request);
                }   

                attachPromotionM3Customer(request, context, M3CUNO);

            } else {
                throw new PipelineRuntimeException("CUNO returned from M3 is either null or doesnt have a value!:"
                        + ERROR);
            }

            LOG.debug("Inside getCUNOFromM3SingleUser() closing connection............... ");
			
            con.close(); // close connection

        } catch (RequestException e) {
            throw new PipelineRuntimeException(e);
        } catch (ParametersException e) {
            throw new PipelineRuntimeException(e);
        } catch (ConnectorException e) {
            throw new PipelineRuntimeException(e);
        }

        return M3CUNO;
    }

    /**
     * Attach promotions to the newly created customer in M3
     * 
     * 
     * @param request
     * @param context
     * @param M3CUNO
     * @throws PipelineRuntimeException
     * @throws ParametersException
     */
	private void attachPromotionM3Customer(XMLRequest request,
			PipelineContext context, String M3CUNO)
			throws PipelineRuntimeException, ParametersException {
		if (("true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.PROMOTIONS)))
		        && ("true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.CREATENEWCUSTOMER)))) {
		    SearchPipelineExecuter promotionList = new SearchPipelineExecuter(
		            "com.intentia.iec.runtime.pipeline", "MvxPromotion", "GetCustomerPromotions");
		    promotionList.setParam("UserGroupKey", request.getParameters().getString("mvxCUNO"));
		    XMLResultset promotions = promotionList.execute();

		    try {
		        String promotionKey = null;
		        String company = null;
		        String division = null;
		        while (promotions.moveNext()) {

		            promotionKey = promotions.getString("Key");
		            System.out.println("PromotionKey................" + promotionKey);
		            company = request.getParameters().getString("mvxCompany");
		            division = request.getParameters().getString("mvxDivision");
		            AddCustomerToPromotion(context, request, company, division, promotionKey, M3CUNO);

		        }

		    } catch (ResultsetException e) {
		        // Otherwise throw the exception again.
		        throw new PipelineRuntimeException("Error fetching promotions for template customer");
		    } catch (PipelineRuntimeException e) {
		        // Otherwise throw the exception again.
		        throw new PipelineRuntimeException("Error fetching promotions for template customer");
		    }

		}
	}

    private void AddCustomerToPromotion(PipelineContext context, XMLRequest request, String company, String division,
            String promotionKey, String M3CUNO) throws PipelineRuntimeException {

        try {

            LOG.debug("getCUNOFromM3()");

            // get a connection to movex and execute the movex call
            IMovexConnection con = (IMovexConnection) CustomStagesHelper.getConnection(ConstantsForSales.OIS840MI);
            if (con == null) {
                LOG.debug("Failure connecting to movex");
                return;
            }
            // Build up movex api request
            Map m3Inputs = new HashMap();

            m3Inputs.put(IMovexConnection.TRANSACTION, "AddPromCust");

            m3Inputs.put("CONO", company);
            m3Inputs.put("DIVI", division);
            m3Inputs.put("PIDE", promotionKey);
            m3Inputs.put("CUNO", M3CUNO);

            IMovexApiResultset m3result = CustomStagesHelper.callMovex(context, con, m3Inputs, "mvxStatus");

            if (con.isOk()) {
                LOG.debug("Connection established");
            }
            if (!(con.isOk())) {
                LOG.debug("Failure adding promotion to customer");
            }

            con.close();

        } catch (ConnectorException e) {
            throw new PipelineRuntimeException(e);
        }

    }
}
