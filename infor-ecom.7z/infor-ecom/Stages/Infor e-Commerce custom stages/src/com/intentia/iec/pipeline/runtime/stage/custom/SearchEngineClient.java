/*
 * Created on 22-11-2004
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.utils.ApplicationParameter;

import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.sqlserver.runtime.jdbc.JDBCHelper;
import com.intentia.iec.sqlserver.runtime.jdbc.JDBCReader;

/**
 * This e-Sales custom stage is used to upload all items to the Google Base
 * Server whenever GoogleBase applicationProperty is enabled.
 * 
 * 
 * The stage will insert newly added items to the Google Base Server as well it
 * updates the items to the Google Base Server which are already uploaded to the
 * Google Base Server.
 * 
 * @author xinc0082(Mayur)
 */
public class SearchEngineClient extends AbstractPipelineStage {

    private static final Logger LOG = Logger.getLogger(SearchEngineClient.class);

    public SearchEngineClient() {
        super();
    }

    public final void execute(final PipelineContext context) throws PipelineRuntimeException {

        LOG.debug("Inside SearchEngineClient's execute()");

        String baseCurrency = null;
        String listPriceGroupName = null;
        boolean isAssortment = false;

        XMLResultset resultset = getBaseSystemData(); // getting base data
                                                        // from
                                                        // SearchEngineSystem
        XMLResultset resultmarket = getDefaultMarket();// getting defualt
                                                        // market data for
                                                        // GuestB2C.
        isAssortment = checkAssortments(); // checking for assortments for
                                            // search engine

        try {
            resultmarket.beforeFirst();
            while (resultmarket.hasNext()) {
                resultmarket.moveNext();
                baseCurrency = resultmarket.getString("currencyCode");
                listPriceGroupName = resultmarket.getString("listPriceGroupName");
            }
        } catch (ResultsetException e) {
            LOG.error("Error getting in Market data,", e);
            throw new PipelineRuntimeException("Error getting in Market data", e);

        }

        try {
            resultset.beforeFirst();
            while (resultset.hasNext()) {
                resultset.moveNext();
                // upload newly items to the gooogle base
                LOG.debug("Inside resultset.hasNext() of SearchEngineClient()  uploading items for  "
                        + resultset.getString("name"));
                UploadItemToSearchEngine.uploadItems(resultset.getString("language"), resultset.getString("country"),
                        resultset.getString("currency"), resultset.getInteger("id"), baseCurrency, listPriceGroupName,
                        isAssortment);
                // update the already uploaded items to the googlebase
                UploadItemToSearchEngine.updateItems(resultset.getString("language"), resultset.getString("country"),
                        resultset.getString("currency"), resultset.getInteger("id"), baseCurrency, listPriceGroupName,
                        isAssortment);
            }
        } catch (ResultsetException e) {
            LOG.error("Error reading base system data", e);
            throw new PipelineRuntimeException("Error reading base system data", e);
        }
    }

    private static XMLResultset getBaseSystemData() throws PipelineRuntimeException {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        XMLResultset resultset = null;
        try {
            con = (Connection) CustomStagesHelper.getConnection("esales.cursor");
            // use JDBCHelper to prepare the statement
            // (as standard generated stages are doing)
            stmt = JDBCHelper.prepareStatement(con, SearchEngineHelper.SELECT_SEARCHENGINES);
            rs = stmt.executeQuery();
            // use JDBCReader to convert JDBCResultset to an XMLResultset
            resultset = new JDBCReader(rs).getContent();
        } catch (SQLException e) {
            LOG.error("Error fetching base system data", e);
            throw new PipelineRuntimeException("Error fetching base data", e);
        } finally {
            CustomStagesHelper.close(con, stmt, rs);
        }

        return resultset;
    }

    private static XMLResultset getDefaultMarket() throws PipelineRuntimeException {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        XMLResultset resultset = null;

        try {
            con = (Connection) CustomStagesHelper.getConnection("esales.cursor");
            // use JDBCHelper to prepare the statement
            // (as standard generated stages are doing)
            stmt = JDBCHelper.prepareStatement(con, SearchEngineHelper.DEFAULT_MARKET_DATA);
            rs = stmt.executeQuery();
            // use JDBCReader to convert JDBCResultset to an XMLResultset
            resultset = new JDBCReader(rs).getContent();
        } catch (SQLException e) {
            LOG.error("Error fetching data for default market", e);
            throw new PipelineRuntimeException("Error fetching data for default market", e);
        } finally {
            CustomStagesHelper.close(con, stmt, rs);
        }

        return resultset;
    }

    private static boolean checkAssortments() throws PipelineRuntimeException {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        boolean isAssortment = false;

        try {
            con = (Connection) CustomStagesHelper.getConnection("esales.cursor");
            // use JDBCHelper to prepare the statement
            // (as standard generated stages are doing)
            stmt = JDBCHelper.prepareStatement(con, SearchEngineHelper.CHECK_ASSORTMENT);
            rs = stmt.executeQuery();

            while (rs.next()) {
                LOG.debug("Inside SearchEngineClient.checkAssortments() Assortment is present for the Search Engine");
                isAssortment = true;
            }

        } catch (SQLException e) {
            LOG.error("Error fetching data for assortments for search engine", e);
            throw new PipelineRuntimeException("Error fetching data for assortments for search engine", e);
        } finally {
            CustomStagesHelper.close(con, stmt, rs);
        }

        return isAssortment;
    }

}