package com.intentia.iec.pipeline.runtime.stage.custom.search;

import org.apache.lucene.search.Filter;
import org.apache.lucene.search.IndexSearcher;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;

public interface DataHolder {
    void close() throws PipelineRuntimeException;

    String getCategoryPathByKey(final String categoryKey) throws PipelineRuntimeException;

    boolean isWarehousingUsed();

    IndexSearcher getIndexSearcher() throws PipelineRuntimeException;

    Filter getFilter(final String key);

    void addFilter(final String key, final Filter filter);
}
