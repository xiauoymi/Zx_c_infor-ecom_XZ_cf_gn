/*
 * Created on 17-03-2004
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.Resultset;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.connection.ConnectorException;
import com.intentia.iec.connection.IMovexApiResultset;
import com.intentia.iec.connection.IMovexConnection;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.ApplicationMail;
import com.intentia.iec.pipeline.runtime.stage.utils.ApplicationParameter;
import com.intentia.iec.pipeline.runtime.stage.utils.CommitPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.Decimal;
import com.intentia.iec.pipeline.runtime.stage.utils.DeletePipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.util.FastStringBuffer;
import com.intentia.iec.util.XMLDateFormat;

/**
 * Stage to send order to Movex through API program OIS100MI. It acts on a
 * current order that must exist as a response in the context.
 * <p>
 * The stage will exit immediately if application property
 * <code>Movex Connector / Enable</code> is false.
 * <p>
 * The stage will exit with an error if there is no resultset or if there are no
 * order lines in the resultset.
 * <p>
 * Sends shipping address to Movex through AddBatchAddress if the application
 * property <code>Shipping Address/User Defined</code> is true.
 * <p>
 * The application property "Movex Ordering.Map City to Movex Field" is used to
 * control whether the attribute is sent to Movex field CUA3, CUA4, TOWN, or not
 * at all. If the mapping is set to CUA3 the attribute Address3 is not
 * transferred. The same is true for CUA4 / Address4.
 * <p>
 * The main actions are:
 * 
 * <pre>
 *    Check order - return if there are no lines
 *    Set delivery dates on all order lines
 *    if Not Accept Partial Delivery
 *       set all delivery dates to latest delivery date
 *    AddBatchHead
 *    AddBatchAddress (if shipping address is given)
 *    AddBatchText (if comment is given)
 *    for each order line
 *       AddBatchLine
 *       AddBatchText (if comment is given)
 *    Confirm
 *    Handle NOK - see text below.
 * </pre>
 * 
 * <b>Required input in <code>PipelineContext</code>:</b> <br>
 * Input parameters: <code>orderLineAvailable</code>, and
 * <code>simulate</code>.
 * <p>
 * <b>Generated output in <code>PipelineContext</code>: </b> <br>
 * Output parameters: <code>status</code>,<code>mvxStatus</code> (error if
 * negative), <code>submittedOrderID</code>, and <code>apiErrorMessage</code>.
 * <p>
 * <code>submittedOrderID</code> (string): <br>
 * The new order ID as assigned by OIS100MI/Confirm. <br>
 * If the order is rejected it holds the order ID assigned by
 * OIS100MI/AddBatchHead.
 * <p>
 * <code>status</code> (integer): <br>
 * OK: value is 0 <br>
 * NOK: value is -100
 * <p>
 * <code>mvxStatus</code> (integer): <br>
 * Connection error: -1000 <br>
 * OK: Movex status code STAT as return on OK - a positive value <br>
 * NOK: Status code extracted from the message string - returned as a negative
 * value <br>
 * e.g. -25 for 25 meaning an invalid order line <br>
 * The position of the status code in the return string from OIS100MI/Confirm
 * must be given in the application property:
 * 
 * <pre>
 *    Movex Ordering / Confirm NOK Status Position = 0
 * </pre>
 * 
 * If the string holds a status code the stage can extract it and return it in
 * mvxStatus as the negative value. E.g. 26 in the above example. It returns �1
 * if the value is 0.
 * <p>
 * <code>apiErrorMessage</code> (string) <br>
 * Error message returned from OIS100MI/Confirm extracted from the return
 * string. <br>
 * The position of the error message in the return string from OIS100MI/Confirm
 * must be given in the application property:
 * 
 * <pre>
 *    Movex Ordering / Confirm NOK Message Position = 16
 * </pre>
 * 
 * The stage extracts the rest of the string from the given position and returns
 * it in the apiErrorMessage.
 * <p>
 */
public final class SubmitOrderToMovex implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(SubmitOrderToMovex.class);

    // Internal variables
    private PipelineContext context = null;

    private IMovexConnection movex = null;

    private Parameters requestParameters = null;

    private String mvxCompany = null;

    private String mvxWarehouse = null;

    // private String simulate = null;

    private boolean isRFQ = false;

    private String jointDeliveryCode = null;

    private String submittedOrderID = null;

    // Variables added as a part of Credit Card Payment Feature.

    private IMovexConnection movexCC = null;

    private String termsOfPayment = null;

    private String creditCardNumber = null;

    private String cardExpDate = null;

    private String cardSecurityCode = null;

    private String creditCardAuthStatus = null;

    private String creditCardErrorCode = null;

    private String creditCardCVVCheckResponse = null;

    private String referenceOrderCategoryType = null;

    private String TransactionReferenceNumber = null;

    private String paymentCode = null;

    private XMLRequest xmlRequest = null;

    private Vector<String> vOrderLineNumber = new Vector<String>();

    private Vector<String> vLinesWithError = new Vector<String>();

    // used to store line numbers of errors that are not caught in
    // orderCOnfirm()
    private Vector<String> vOtherErrors = new Vector<String>();

    private List orderItems;

    boolean simulatedOrder = false;
    
    boolean isM3PromotionEnabled = false;
    

    /**
     * The stage entry point.
     * 
     * @see com.intentia.iec.pipeline.runtime.PipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
     */
    public void execute(final PipelineContext pipelineContext) throws PipelineRuntimeException {

        if (!(pipelineContext.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
        xmlRequest = (XMLRequest) pipelineContext.getRequest();
        try {
            XMLRequest.extractRequestParameters(xmlRequest);
        } catch (RequestException e1) {
            e1.printStackTrace();
        }

        // Movex connector not enabled => skip stage
        if (!"true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.CONNECTORENABLED))) {
            return;
        }
        
        

        context = pipelineContext;

        int mvxStatus = -1010;

        try {
            movex = (IMovexConnection) CustomStagesHelper.getConnection(ConstantsForSales.OIS100MI);

            // New movex connection for Credit Card API- CRCCINMI
            // movexCC = (IMovexConnection)
            // CustomStagesHelper.getConnection(ConstantsForSales.CRCCINMI);

            if (movex == null) {
                return;
            }

            // Extract the request parameters.
            CustomStagesHelper.extractRequestParameters(CustomStagesHelper.getRequest(context));
            requestParameters = CustomStagesHelper.getRequestParameters(context);

            XMLResultset resultSet = (XMLResultset) context.getResponse();
            
            if ((resultSet == null) || (!resultSet.moveFirst())) {
                LOG.debug("Aborting send order because there is no order");
                mvxStatus = -1008;
                return;
            }

            String simulate = getRequestParameter(ConstantsForSales.SIMULATE_PARAM);
            if ("1".equals(simulate)) {
                simulatedOrder = true;
            } else {
                simulatedOrder = false;
            }

            // Check number of lines in order
            XMLIterator lines = (XMLIterator) resultSet.getResultset(ConstantsForSales.ORDERLINE);
            
            String orderID = getRequestParameter("orderID");
            if ((lines == null) || (lines.rowCount() == 0)) {
                LOG.debug("Aborting send order because order has no order lines");
                if (simulatedOrder) {
                    deleteShadowOrder(orderID);
                }
                mvxStatus = -1009;
                return;
            }

            // parameter to specify if order lines will be validated.
            // will only be validated if value is "Y".
            // needed to improve performance - currently, only order form needs
            // to have the lines validated
            boolean isValidateOrderLines = "Y".equals(getRequestParameter(ConstantsForSales.VALIDATE_ORDER_LINES));
            isM3PromotionEnabled = Boolean.valueOf(CustomStagesHelper.getKeyValue(ConstantsForSales.M3_PROMOTIONS_ENABLED));
            String executeSubmitParam = getRequestParameter(ConstantsForSales.SIMULATE_EXECUTE_SUBMIT);
            if (executeSubmitParam != null) {
                boolean executeSubmit = Boolean.valueOf(executeSubmitParam).booleanValue();
                if (!executeSubmit) {
                    if (!this.needSimulation(orderID, resultSet.getDate(ConstantsForSales.TIMESTAMP))) {
                        LOG.debug("Simulate Order Skip");
                        mvxStatus = 90;
                        return;
                    } else {
                        if (!isValidateOrderLines) {
                            LOG.debug("Updated order but should not validate");
                            mvxStatus = 90;
                            return;
                        }
                    }
                }
                isValidateOrderLines = true;

            }

            mvxCompany = resultSet.getString(ConstantsForSales.MVXCOMPANY);
            mvxWarehouse = resultSet.getString(ConstantsForSales.MVXWAREHOUSE);
            // Initialize these three variables from request for credit card
            // authorization.
            termsOfPayment = getRequestParameter(ConstantsForSales.TERMS_OF_PAYMENT);
            creditCardNumber = getRequestParameter(ConstantsForSales.CREDIT_CARD_NUMBER);
            cardExpDate = getRequestParameter(ConstantsForSales.CARD_EXPIRY_DATE);
            cardSecurityCode = getRequestParameter(ConstantsForSales.CARD_SECURITY_CODE);
            referenceOrderCategoryType = getRequestParameter(ConstantsForSales.RORC);
            paymentCode = getRequestParameter(ConstantsForSales.PAYCD);

            // New movex connection for Credit Card API- CRCCINMI
            if ("CC".equals(termsOfPayment)) {
                movexCC = (IMovexConnection) CustomStagesHelper.getConnection(ConstantsForSales.CRCCINMI);

                if (movexCC == null) {
                    return;
                }
            }
            // Handle delivery dates
            // Update the requested delivery dates on the lines to ensure they
            // have a value
            String requestedDeliveryDateHead = resultSet.getString(ConstantsForSales.REQUESTEDDELIVERYDATE);
            UpdateDeliveryDatesFromMovex.updateLineDeliveryDates(lines, requestedDeliveryDateHead);
            // Handle delivery dates if partial delivery is not wanted
            // - and there are more than one order line.
            if ((lines.rowCount() >= 2) && !isAcceptPartial(resultSet)) {
                String latestDeliveryDate = findLatestDeliveryDate(lines);
                if (latestDeliveryDate != null) {
                    setSameDeliveryDate(lines, latestDeliveryDate);
                }
                // Set joint delivery code to use on all order lines.
                // If no code is found in the properties file, none is send!
                jointDeliveryCode = CustomStagesHelper.getKeyValue(ConstantsForSales.JOINTDELIVERYCODE);
            }

            // Determine if it is an alternative shipping address ID
            // If the address has a Movex ID then is it not.
            // If the address has no Movex ID it can be the billing
            // address/company address.
            boolean sendAlternativeShipAddr = false;
            String mvxShipAddrID = null;
            if (!"1".equals(simulate)) {
                mvxShipAddrID = getAttribute(ConstantsForSales.MVXSHIPPINGADDRESSID, resultSet);
                sendAlternativeShipAddr = "".equals(mvxShipAddrID);
                if (sendAlternativeShipAddr) {
                    // Check if it is the billing address, i.e.
                    // ShippingAddressID =
                    // "sa#" & CompanyID
                    String billAddrID = "sa#";
                    billAddrID += getAttribute(ConstantsForSales.COMPANYID, resultSet);
                    String shipAddrID = getAttribute(ConstantsForSales.SHIPPINGADDRESSID, resultSet);
                    if (billAddrID.equals(shipAddrID)) {
                        // It was the the billing address, so don't send an
                        // alternative address
                        sendAlternativeShipAddr = false;
                    }
                }
            }

            int[] x = new int[1];
            submittedOrderID = null;
            if (!orderHead(resultSet, mvxShipAddrID, x)) {
                if (x != null) {
                    mvxStatus = x[0];
                }
                return;
            }

            if (sendAlternativeShipAddr
                    && "true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.USERDEFINEDSHIPPINGADDRESS))) {
                if (!orderShippingAddress()) {
                    orderDelete();
                    submittedOrderID = null;
                    return;
                }
            }

            vOtherErrors.clear();
            if (!orderLines()) {
                // remove processing here
            }

            mvxStatus = orderConfirm();
            if ((mvxStatus >= 0) && isUpdatingOrderLines()) {
                if (!"1".equals(simulate)) {
                    updateOrderLineIDs();
                }
            }

            // if errors are caught, treat it as -25
            if (vOtherErrors.isEmpty() == false) {
                mvxStatus = -25;
            }

            // skip validation if not needed.
            if (isValidateOrderLines) {
                validateOrderLines(resultSet, mvxStatus);
            }

            if ("CC".equals(termsOfPayment) && !"1".equals(simulate)) {
                if (!getValidateInfo(resultSet)) {
                    orderDelHead();
                    mvxStatus = -1007;
                    return;
                }

                if (!getOrderValue()) {
                    orderDelHead();
                    mvxStatus = -1006;
                    return;
                }

                if (!addAuth()) {
                    if ("N".equals(creditCardCVVCheckResponse)) {
                        addVoid();
                    }
                    orderDelHead();
                    mvxStatus = -1005;
                    return;
                }

                if (!authCreditCard()) {
                    addVoid();
                    orderDelHead();
                    mvxStatus = -1004;
                    return;
                }
            }
        } catch (PipelineRuntimeException e) {

            if (movex == null || movexCC == null) {
                // Assume that is was not possible to create a connection.
                LOG.error("Failed to connect to Movex", e);
            } else {
                // Otherwise throw the exception again.
                throw e;
            }
        } catch (ResultsetException e) {

            mvxStatus = -1011;
            LOG.error("Failed to open resultset", e);
        } catch (ParametersException e) {
            LOG.error("Error in Parameter Extraction,", e);
        } finally {

            if (movex != null) {
                try {
                    movex.close();
                } catch (ConnectorException e) {
                    LOG.error("Failed to close the movex connection!");
                } catch (NullPointerException e) {
                    LOG.error("Failed to close the movex connection!");
                }
            }
            if (movexCC != null) {
                try {
                    movexCC.close();
                } catch (ConnectorException e) {
                    LOG.error("Failed to close the movexCC connection!");
                } catch (NullPointerException e) {
                    LOG.error("Failed to close the movex connection!");
                }
            }
            try {
                if (submittedOrderID != null) {
                    CustomStagesHelper.setResponseParameter(context, ConstantsForSales.SUBMITTEDORDERID,
                            submittedOrderID);
                    CustomStagesHelper.setResponseParameter(context, ConstantsForSales.GENERATEDORDERNO,
                            submittedOrderID);
                    LOG.debug("Submitted Order ID: " + submittedOrderID);
                }

                if (TransactionReferenceNumber != null) {
                    CustomStagesHelper.setResponseParameter(context, ConstantsForSales.TRANSACTIONREFERENCENUMBER,
                            TransactionReferenceNumber);
                    LOG.debug("Transaction Reference Number: " + TransactionReferenceNumber);
                }

                // set specific return code for Movex - see confirm
                CustomStagesHelper.getResponseParameters(context).setint(ConstantsForSales.MVXSTATUS, mvxStatus);
                LOG.debug("MvxStatus: " + mvxStatus);
                // set common return code for execute
                CustomStagesHelper.getResponseParameters(context).setint(ConstantsForSales.STATUS,
                        mvxStatus >= 0 ? 0 : -100);
            } catch (ParametersException e) {
                LOG.error("Failed to set response parameters!");
            }
        }
    }

    /**
     * Tells whether the AcceptPartial attribute from the resultset (main) is
     * "N" or not. If "N" partial delivery is not accepted.
     * 
     * If not found it defaults to true for accept partial delivery.
     * 
     * @param result
     *            the result set positioned on the current record
     * @return false if the value of the attribute is "N" - otherwise true
     */
    private boolean isAcceptPartial(final XMLResultset result) {

        boolean accept = true;
        try {
            String acceptPartial = result.getString(ConstantsForSales.ACCEPTPARTIAL);
            if ((acceptPartial != null) && ("N".equals(acceptPartial.toUpperCase()))) {
                accept = false;
            }
        } catch (ResultsetException e) {
            LOG.error("Could not get AcceptPartial attribute.", e);
        }
        return accept;
    }

    /**
     * Finds the latest delivery date on the given order lines.
     * <p>
     * The algorithm does not convert to a Date, but uses a String compare as
     * the date format is comparable: yyyymmddTHHMMSS.
     * 
     * @param lines
     *            the order lines to search as XMLIterator
     * @return the latest delivery date as String
     * @throws PipelineRuntimeException
     */
    private String findLatestDeliveryDate(final XMLIterator lines) throws PipelineRuntimeException {

        String latestDeliveryDate = null;
        lines.beforeFirst();
        try {
            while (lines.moveNext()) {
                String lineDeliveryDate = lines.getString(ConstantsForSales.REQUESTEDDELIVERYDATE);
                if (latestDeliveryDate == null) {
                    latestDeliveryDate = lineDeliveryDate;
                } else if (latestDeliveryDate.compareTo(lineDeliveryDate) < 0) {
                    latestDeliveryDate = lineDeliveryDate;
                }
            }
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Failed to get delivery date on order line", e);
        } finally {
            // reset resultset - needed by presentation layer!
            lines.beforeFirst();
        }
        LOG.debug("Found latest delivery date: " + latestDeliveryDate);
        return latestDeliveryDate;
    }

    /**
     * Sets the same requested delivery date on all order lines.
     * 
     * @param lines
     *            the order lines to set date on
     * @param deliveryDate
     *            date to set as requested delivery date
     * @throws PipelineRuntimeException
     */
    private void setSameDeliveryDate(final XMLIterator lines, final String deliveryDate)
            throws PipelineRuntimeException {

        lines.beforeFirst();
        try {
            while (lines.moveNext()) {
                lines.setString(ConstantsForSales.REQUESTEDDELIVERYDATE, deliveryDate);
            }
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Failed to set delivery date on order line", e);
        } finally {
            // reset resultset - needed by presentation layer!
            lines.beforeFirst();
        }
    }

    private boolean getValidateInfo(final XMLResultset main) throws PipelineRuntimeException {

        /*
         * This method Validates a given credit card number against M3. Required
         * inputs are Card Number, Card Exp Date, MvxCompany, MvxDivision.
         */

        Map validate = new HashMap();
        validate.put(IMovexConnection.TRANSACTION, ConstantsForSales.GET_VALIDATE_INFO);
        validate.put(ConstantsForSales.CONO, mvxCompany);
        validate.put(ConstantsForSales.DIVI, getAttribute(ConstantsForSales.MVXDIVISION, main));
        validate.put(ConstantsForSales.CANU, creditCardNumber);
        validate.put(ConstantsForSales.EXP0, cardExpDate);

        IMovexApiResultset res = CustomStagesHelper.callMovex(context, movexCC, validate, ConstantsForSales.MVXSTATUS);
        if (res == null) {
            return false;
        }

        if (movexCC.isOk()) {
            // Get credit card type from API resultset and put it in context
            context.put(ConstantsForSales.CREDITCARDTYPE, res.getParamAsString(ConstantsForSales.CTPY));
            return true;
        } else {
            LOG.error("Failed to validate the Credit Card: " + movexCC.getLastMessage());
            return false;
        }

    }

    private boolean getOrderValue() throws PipelineRuntimeException {

        /*
         * This method gets the Order Value from Movex.
         */

        Map orderValue = new HashMap();
        orderValue.put(IMovexConnection.TRANSACTION, ConstantsForSales.GET_ORDER_VALUE);
        orderValue.put(ConstantsForSales.CONO, mvxCompany);
        orderValue.put(ConstantsForSales.ORNO, submittedOrderID);

        IMovexApiResultset res = CustomStagesHelper.callMovex(context, movex, orderValue, ConstantsForSales.MVXSTATUS);
        if (res == null) {
            return false;
        }

        if (!movex.isOk()) {

            final String msg = "Could not get the Order Value. " + movex.getLastMessage();
            LOG.error(msg);
            return false;

        }
        // Get Order total to pay and currency from API resultset and put it in
        // context
        context.put(ConstantsForSales.ORDERTOTALTOPAY, res.getParamAsString(ConstantsForSales.TOPY));
        context.put(ConstantsForSales.CURRENCY, res.getParamAsString(ConstantsForSales.CUCD));

        return true;

    }

    /**
     * Creates the order in Movex by calling AddBatchHead. Puts the returned
     * order ID in the context. Adds a comment if one is present.
     * 
     * @param main
     *            The resultset to take attributes from.
     * @param adid
     *            The address ID to enter in the order header.
     * @return false in case of an error
     * @throws PipelineRuntimeException
     * @throws ParametersException
     * @throws ResultsetException 
     */

    private boolean orderHead(final XMLResultset main, final String adid, int[] x) throws PipelineRuntimeException,
            ParametersException, ResultsetException {

        // load parameters for header
        Map header = new HashMap();
        header.put(IMovexConnection.TRANSACTION, ConstantsForSales.ADD_BATCH_HEAD);
        header.put(ConstantsForSales.CONO, mvxCompany);
        header.put(ConstantsForSales.FACI, getAttribute(ConstantsForSales.MVXFACILITY, main));
        header.put(ConstantsForSales.WHLO, mvxWarehouse);
        header.put(ConstantsForSales.CUNO, xmlRequest.getParameters().getString("UserGroupID"));
        header.put(ConstantsForSales.ORTP, getAttribute(ConstantsForSales.MVXORDERTYPE, main));
        header.put(ConstantsForSales.CUDT, getMovexDate(new XMLDateFormat().format(new Date())));
        header.put(ConstantsForSales.ORDT, getMovexDate(new XMLDateFormat().format(new Date())));
        header.put(ConstantsForSales.MODL, getAttribute(ConstantsForSales.SHIPPINGMETHODID, main));
        header.put(ConstantsForSales.YREF, getAttribute(ConstantsForSales.YOURREFERENCE, main));
        header.put(ConstantsForSales.CUCD,getResponseParameter(ConstantsForSales.CURRENCY));
        String reqDelDate = getAttribute(ConstantsForSales.REQUESTEDDELIVERYDATE, main);
        if (reqDelDate != null && reqDelDate.trim().length() > 0) {
            header.put(ConstantsForSales.RLDT,
                    getMovexDate(getAttribute(ConstantsForSales.REQUESTEDDELIVERYDATE, main)));
            // header.put(ConstantsForSales.RLDZ,
            // getMovexDate(getAttribute(ConstantsForSales.REQUESTEDDELIVERYDATE,
            // main)));
        } else {
            header.put(ConstantsForSales.RLDT, getMovexDate(new XMLDateFormat().format(new Date())));
            // header.put(ConstantsForSales.RLDZ, getMovexDate(new
            // XMLDateFormat().format(new Date())));
        }
        if (simulatedOrder) {
            // header.put(ConstantsForSales.CUOR,
            // getRandomCustomerOrderNumber());
            header.put(ConstantsForSales.ESOV, getRequestParameter(ConstantsForSales.SIMULATE_PARAM));
            String ortpso = getAttribute(ConstantsForSales.MVXORDERTYPESO, main);
            if (ortpso != null || "".equals(ortpso)) {
                header.put(ConstantsForSales.ORTP, ortpso);
            }
        } else {
            header.put(ConstantsForSales.CUOR, getAttribute(ConstantsForSales.CUSTOMERORDERNO, main));
        }
        if (paymentCode != null) {
            header.put(ConstantsForSales.PYCD, paymentCode);
        }

        if (termsOfPayment != null) {
            header.put(ConstantsForSales.TEPY, termsOfPayment);
        }

        if (adid != null) {
            header.put(ConstantsForSales.ADID, adid);
        }
        
        // handle RFQ
        final String orderStatus = getAttribute(ConstantsForSales.ORDERSTATUS, main);
        isRFQ = "rfq".equals(orderStatus);
        if (isRFQ) {
            header.put(ConstantsForSales.DISY, CustomStagesHelper.getKeyValue(ConstantsForSales.DISCOUNTMODEL));
        }
        
        if(!this.isM3PromotionEnabled){
        	String discountModel = ApplicationParameter.getValue(ConstantsForSales.PROMOTION_DISCOUNT_MODEL);
        	if(discountModel == null){
        		discountModel = CustomStagesHelper.getKeyValue(ConstantsForSales.DISCOUNTMODEL);
        	}
        	header.put(ConstantsForSales.DISY, discountModel);
        	header.put(ConstantsForSales.DICD, ConstantsForSales.DISCOUNT_ORIGIN_MANUAL_8);
        	
        	//GET ORDERHEADERDISCOUNT; COMPUTE PERCENT ASSIGN TO ORDERDISCOUNT PERCENT
        	BigDecimal orderHeaderDiscount = n20(getDecimal(ConstantsForSales.ORDERHEADERDISCOUNT, main));
        	BigDecimal orderTotalPrice = n20(getDecimal(ConstantsForSales.TOTALPRICE, main));
        	if (orderHeaderDiscount.compareTo(Decimal.ZERO) != 0 && orderTotalPrice.compareTo(Decimal.ZERO)!=0) {
                // orderHeaderDiscount = 100 * LineDiscount / LinePrice
                BigDecimal percent = Decimal.divide(Decimal.ONEHUNDRED.multiply(orderHeaderDiscount), orderTotalPrice);
                header.put(ConstantsForSales.OTDP, percent.toString());
            }
        }

        IMovexApiResultset res = CustomStagesHelper.callMovex(context, movex, header, ConstantsForSales.MVXSTATUS);
        if (res == null) {
            return false;
        }

        if (movex.isOk()) {
            // Get order number from API resultset and put it in context
            context.put(ConstantsForSales.TMPORDERID, res.getParamAsString(ConstantsForSales.ORNO));
            // Add order header comment
            final String text = getAttribute(ConstantsForSales.COMMENTTEXT, main);
            if (text != null && !text.equals("")) {
                return orderComment(text, null, ConstantsForSales.POST_TEXT_2);
            }
        } else {
            String errMsg = movex.getLastMessage();
            LOG.error("Failed to add header: " + errMsg);
            if (null != errMsg && errMsg.trim().length() > 0) {
                if (errMsg.contains(ConstantsForSales.EXCEED_CREDIT_LIMIT_ERR_CODE)) {
                    // mvxStatus =
                    // -(Integer.parseInt(ConstantsForSales.EXCEED_CREDIT_LIMIT_STAT));
                    x[0] = -(Integer.parseInt(ConstantsForSales.EXCEED_CREDIT_LIMIT_STAT));
                }
            }
            return false;
        }

        return true;
    }

    /**
     * Adds the order lines from the subset OrderLine to the Movex order by
     * calling the function orderLine - see this.
     * 
     * @return returns false if an error occurred
     * @throws PipelineRuntimeException
     */
    private boolean orderLines() throws PipelineRuntimeException {
        boolean retVal = true;
        this.orderItems = new ArrayList();
        final XMLResultset main = (XMLResultset) context.getResponse();
        try {
            XMLIterator lines = (XMLIterator) main.getResultset(ConstantsForSales.ORDERLINE);
            lines.beforeFirst();
            
            int i = 0;
            while (lines.moveNext()) {
                if (!orderLine(lines, i, isM3PromotionEnabled)) {
                    retVal = false;
                }
                i++;
            }
        } catch (final ResultsetException e) {
            final String msg = "Unable to get the lines from the OrderLine subset.";
            LOG.error(msg, e);
            throw new PipelineRuntimeException(msg, e);
        }

        return retVal;
    }

    /**
     * Adds the order lines from the subset OrderLine to the Movex order by
     * calling the API function AddBatchLine.
     * 
     * @param lines
     *            Sub-result set with order lines, where current position is on
     *            the line to add.
     * @return returns false if an error occurred
     * @throws PipelineRuntimeException
     */
    private boolean orderLine(final Resultset lines, int index, boolean m3Promotions) throws PipelineRuntimeException {

        final Map line = new HashMap();
        line.put(IMovexConnection.TRANSACTION, ConstantsForSales.ADD_BATCH_LINE);
        line.put(ConstantsForSales.CONO, mvxCompany);
        line.put(ConstantsForSales.ORNO, getResponseParameter(ConstantsForSales.TMPORDERID));
        line.put(ConstantsForSales.ORQT, getAttribute(ConstantsForSales.QUANTITY, lines));
        line.put(ConstantsForSales.WHLO, mvxWarehouse);
        line.put(ConstantsForSales.DWDT, getMovexDate(getAttribute(ConstantsForSales.REQUESTEDDELIVERYDATE, lines)));
        line.put(ConstantsForSales.CFIN, getAttribute(ConstantsForSales.MVXCONFIGURABLENUMBER, lines));
        line.put(ConstantsForSales.ADID, getAttribute(ConstantsForSales.MVXSHIPPINGADDRESSID, lines));
        // if (simulatedOrder) {
        // line.put(ConstantsForSales.CUPO,
        // getAttribute(ConstantsForSales.ORDERLINEID, lines));
        line.put(ConstantsForSales.DRDN, getRequestParameter("orderID"));
        line.put(ConstantsForSales.DRDL, getAttribute(ConstantsForSales.ORDERLINEID, lines));
        // }


        String useCID = getAttribute(ConstantsForSales.USECID, lines);
        // this.orderItems.ladd(getAttribute(ConstantsForSales.ITEMID,
        // lines).toUpperCase());
        if ("Y".equals(useCID.trim())) {
            line.put(ConstantsForSales.ITNO, getAttribute(ConstantsForSales.CUSTOMERITEMID, lines).toUpperCase());
        } else {
            line.put(ConstantsForSales.ITNO, getAttribute(ConstantsForSales.ITEMID, lines));
        }

        LOG.debug("ITNO TO USE : " + line.get(ConstantsForSales.ITNO));
        

        if (jointDeliveryCode != null) {
            line.put(ConstantsForSales.JDCD, jointDeliveryCode);
        }
        if (isRFQ || (!m3Promotions)) {
            line.put(ConstantsForSales.SAPR, getAttribute(ConstantsForSales.RESELLPRICE, lines));
            try {
            	
            	if(isRFQ){
	                // Add a discount as DIA1 = (LinePrice - LineTotal) / Quantity
	                BigDecimal dif = getDecimal(ConstantsForSales.LINEPRICE, lines).subtract(
	                        getDecimal(ConstantsForSales.LINETOTAL, lines));
	                BigDecimal discount = Decimal.divide(dif, getDecimal(ConstantsForSales.QUANTITY, lines));
	                line.put(ConstantsForSales.DIA1, discount.toString());
            	}else{
            		// IF STANDALONE PROMOTION GET DISCOUNT FROM COMPUTED PROMOTION
            		BigDecimal dif = getDecimal(ConstantsForSales.LINEDISCOUNT, lines);
            		BigDecimal discount = Decimal.divide(dif, getDecimal(ConstantsForSales.QUANTITY, lines));
            		line.put(ConstantsForSales.DIA1, discount.toString());
            	}
                
            } catch (ArithmeticException e) {
                LOG.error("Failed to compute DIA1");
            }
        }

        final IMovexApiResultset rs = CustomStagesHelper.callMovex(context, movex, line, ConstantsForSales.MVXSTATUS);
        if (rs == null) {
            return false;
        }
        // LOG.debug("Line command: " + con.getCommand(line).toString());
        if (movex.isOk()) {
            final String lineID = (String) rs.getParamAsString(ConstantsForSales.PONR);
            final String text = getAttribute(ConstantsForSales.COMMENT, lines);
            vOrderLineNumber.add(padLeft(lineID, 5));
            if (text != null && !text.equals("")) {
                orderComment(text, lineID, ConstantsForSales.POST_TEXT_2);
            }
            if(!this.isM3PromotionEnabled){
            	final String promotionCode = getAttribute(ConstantsForSales.PROMOTION_CODE, lines);
            	if (promotionCode != null && !promotionCode.equals("")) {
                    orderComment(promotionCode, lineID, ConstantsForSales.PRE_TEXT_1);
                }
            }
            return true;
        } else {
            LOG.error("Failed to add line to Movex order: " + movex.getLastMessage());
            vOtherErrors.add(String.valueOf(index));
            return false;
        }
    }

    /**
     * Delete the incomplete batch order in Movex (calls DelBatchHead). This
     * method should be called in case something went wrong after calling
     * AddBatchHead and before calling Confirm.
     * 
     * @throws PipelineRuntimeException
     */
    private boolean orderDelete() throws PipelineRuntimeException {

        Map delBatchHead = new HashMap();
        String msg = "delBatchOrder is deleting batch order id: " + getResponseParameter(ConstantsForSales.TMPORDERID);
        LOG.info(msg);
        try {
            XMLResultset resultSet = (XMLResultset) context.getResponse();
            resultSet.moveFirst();
            delBatchHead.put(IMovexConnection.TRANSACTION, ConstantsForSales.DEL_BATCH_HEAD);
            delBatchHead.put(ConstantsForSales.CONO, mvxCompany);
            delBatchHead.put(ConstantsForSales.ORNO, getResponseParameter(ConstantsForSales.TMPORDERID));
        } catch (ResultsetException e) {
            msg = "Could not get parameter";
            LOG.error(msg, e);
            throw new PipelineRuntimeException(msg, e);
        }

        if (CustomStagesHelper.callMovex(context, movex, delBatchHead, ConstantsForSales.MVXSTATUS) == null) {
            return false;
        }

        if (!movex.isOk()) {
            msg = "Error deleting batch order id: " + getResponseParameter(ConstantsForSales.TMPORDERID) + " Error: "
                    + movex.getLastMessage();
            LOG.error(msg);
        }

        return true;
    }

    /**
     * Send shipping address to Movex - call AddBatchAddress. The shipping
     * address is extracted from the main resultset.
     * 
     * @throws PipelineRuntimeException
     */
    private boolean orderShippingAddress() throws PipelineRuntimeException {

        Map address = new HashMap();
        try {
            XMLResultset resultSet = (XMLResultset) context.getResponse();
            resultSet.moveFirst();
            address.put(IMovexConnection.TRANSACTION, ConstantsForSales.ADD_BATCH_ADDRESS);
            address.put(ConstantsForSales.CONO, mvxCompany);
            address.put(ConstantsForSales.ORNO, getResponseParameter(ConstantsForSales.TMPORDERID));
            address.put(ConstantsForSales.ADRT, "1");
            address.put(ConstantsForSales.ADID, "");
            address.put(ConstantsForSales.CUNM, resultSet.getString(ConstantsForSales.SHIPPINGCOMPANY));
            address.put(ConstantsForSales.CUA1, resultSet.getString(ConstantsForSales.SHIPPINGADDRESS1));
            address.put(ConstantsForSales.CUA2, resultSet.getString(ConstantsForSales.SHIPPINGADDRESS2));

            // Map city attribute (should be CUA3, CUA4, TOWN, or empty).
            String mapCityTo = CustomStagesHelper.getKeyValue(ConstantsForSales.MAP_CITY_TO);
            if (ConstantsForSales.SHIPPINGADDRESS3.compareTo(mapCityTo) != 0) {
                // Do only transfer CUA3 if not mapped to city field
                address.put(ConstantsForSales.CUA3, resultSet.getString(ConstantsForSales.SHIPPINGADDRESS3));
            }
            if (ConstantsForSales.SHIPPINGADDRESS4.compareTo(mapCityTo) != 0) {
                // Do only transfer CUA4 if not mapped to city field
                address.put(ConstantsForSales.CUA4, resultSet.getString(ConstantsForSales.SHIPPINGADDRESS4));
            }
            if ((mapCityTo != null) && (mapCityTo.length() > 0)) {
                address.put(mapCityTo, resultSet.getString(ConstantsForSales.SHIPPINGCITY));
            }

            address.put(ConstantsForSales.PONO, resultSet.getString(ConstantsForSales.SHIPPINGZIP));
            address.put(ConstantsForSales.ECAR, resultSet.getString(ConstantsForSales.SHIPPINGSTATEID));
            address.put(ConstantsForSales.CSCD, resultSet.getString(ConstantsForSales.SHIPPINGCOUNTRYID));
        } catch (ResultsetException e) {
            String msg = "Could not get parameter";
            LOG.error(msg, e);
            throw new PipelineRuntimeException(msg, e);
        }

        if (CustomStagesHelper.callMovex(context, movex, address, ConstantsForSales.MVXSTATUS) == null) {
            return false;
        }

        if (!movex.isOk()) {
            String msg = "Error adding address: " + movex.getLastMessage();
            LOG.error(msg);
        }

        return true;
    }

    /**
     * Add a comment to the Movex order calling AddBatchText. <br>
     * Header comment: Set lineID to null. <br>
     * Line comment: Set lineID.
     * 
     * @param text
     *            the comment text
     * @param lineID
     *            order line ID - if null it is a header comment
     * @throws PipelineRuntimeException
     */
    private boolean orderComment(final String text, final String lineID, String textType) throws PipelineRuntimeException {

        // load parameters for header comment
        Map comment = new HashMap();
        comment.put(IMovexConnection.TRANSACTION, ConstantsForSales.ADD_BATCH_TEXT);
        comment.put(ConstantsForSales.CONO, mvxCompany);
        comment.put(ConstantsForSales.ORNO, getResponseParameter(ConstantsForSales.TMPORDERID));
        comment.put(ConstantsForSales.TYPE, lineID == null ? "1" : "2");
        comment.put(ConstantsForSales.PONR, lineID == null ? "" : lineID);
        comment.put(ConstantsForSales.TYTR, textType);
        comment.put(ConstantsForSales.TXHE, CustomStagesHelper.getKeyValue(ConstantsForSales.DOCUMENTCLASS));
        comment.put(ConstantsForSales.PARM, text);
        if (CustomStagesHelper.callMovex(context, movex, comment, ConstantsForSales.MVXSTATUS) == null) {
            return false;
        }

        if (!movex.isOk()) {
            final String msg = "Error on adding " + (lineID == null ? "header" : ("line(" + lineID + ")"))
                    + " comment: " + movex.getLastMessage();
            LOG.error(msg);
        }

        return true;
    }
    
    /**
     * Issues the API command confirm against Movex with the temporary order ID
     * from the context. The return code is handled - see the description of the
     * stage.
     * 
     * @see com.intentia.iec.pipeline.runtime.stage.custom.SubmitOrderToMovex
     * 
     * @return OK: Movex status code STAT as return on OK - a positive value
     *         <br>
     *         NOK: Status code extracted from the message string - returned as
     *         a negative value <br>
     *         e.g. -25 for 25 meaning a invalid orderline
     * @throws PipelineRuntimeException
     * @throws ResultsetException
     * @throws ParametersException
     */
    private int orderConfirm() throws PipelineRuntimeException, ResultsetException, ParametersException {
        final String tmpOrderID = getResponseParameter(ConstantsForSales.TMPORDERID);
        String currentOrderID = requestParameters.getString("orderID");

        Map confirm = new HashMap();
        confirm.put(IMovexConnection.TRANSACTION, ConstantsForSales.CONFIRM);
        confirm.put(ConstantsForSales.CONO, mvxCompany);
        confirm.put(ConstantsForSales.ORNO, tmpOrderID);
        int mvxStatus = -1;

        // equivalent to 10 mins waiting time. If transaction goes beyond 10
        // minutes
        // it is better that the performance issue is detected before wait time
        // is increased further.
        movex.setMaxWait(600000);

        IMovexApiResultset rs = CustomStagesHelper.callMovex(context, movex, confirm, ConstantsForSales.MVXSTATUS);
        
        
        if (rs == null) {
            LOG.info("Order confirm failed, ORNO = " + tmpOrderID);
            return mvxStatus;
        } 
        
        mvxStatus = toInteger(rs.getParamAsString(ConstantsForSales.STAT), 0);
        boolean hasErrors = mvxStatus < 90;
                
        if (movex.isOk() && !hasErrors) {
            // return new order ID as output parameter (context
            // response) and status code to outer level
            
            submittedOrderID = rs.getParamAsString(ConstantsForSales.ORNO);
			LOG.info("Order accepted by Movex, ORNO = " + submittedOrderID);
            if (simulatedOrder) {
                try {
                    saveSimulatedOrder(currentOrderID, submittedOrderID);
                } catch (Exception e) {
                    LOG.debug(e.getMessage());
                }
            }
                        
        } else {

            // set the default stat position at 26
            // and status code to outer level
            // Get positions in return string - positions should be starting at
            // 1 for the first character

            // set the default stat position at 26
            int statPos = toInteger(CustomStagesHelper.getKeyValue(ConstantsForSales.CONFIRM_STAT_POSITION), 26);
            int msgPos = toInteger(CustomStagesHelper.getKeyValue(ConstantsForSales.CONFIRM_MESSAGE_POSITION), 0);
            String lastMsg = movex.getLastMessage();
            LOG.info("Movex Message : " + lastMsg);
            String apiError = "";
            if (lastMsg != null) {
                --statPos;
                if ((statPos >= 0) && (lastMsg.length() >= statPos + 2) || (movex.isOk() && hasErrors)) {
                    String stat = movex.isOk() ? String.valueOf(mvxStatus) : lastMsg.substring(statPos, statPos + 2);
                    mvxStatus = movex.isOk() ? -mvxStatus : -toInteger(stat.trim(), -2);

                    IMovexApiResultset rs1 = null;

                    if (stat.equalsIgnoreCase(ConstantsForSales.INVALID_ORDERLINE_STAT)) {
                        LOG.info("Call Get_Order_No ");
                        Map getOrderNo = new HashMap();
                        getOrderNo.put(IMovexConnection.TRANSACTION, ConstantsForSales.GET_ORDER_NO);
                        getOrderNo.put(ConstantsForSales.CONO, mvxCompany);
                        getOrderNo.put(ConstantsForSales.ORNO, tmpOrderID);
                        rs1 = CustomStagesHelper.callMovex(context, movex, getOrderNo, ConstantsForSales.MVXSTATUS);
                    } else if (stat.equalsIgnoreCase(ConstantsForSales.EXCEED_CREDIT_LIMIT_STAT)) {
                        if (simulatedOrder) {
                            deleteShadowOrder(currentOrderID);
                        }
                        submittedOrderID = tmpOrderID;
                    } else {
                        submittedOrderID = tmpOrderID;
                    }

                    if (rs1 != null) {
                        String orderID = rs1.getParamAsString(ConstantsForSales.ORNR).trim();
                        if (orderID == null || "".equals(orderID)) {
                            LOG.info("Get Order No failed, ORNO = " + tmpOrderID);
                            submittedOrderID = tmpOrderID;
                            if (this.simulatedOrder) {
                                mvxStatus = -(Integer.parseInt(ConstantsForSales.INVALID_ORDERLINE_STAT));
                            } else {
                                mvxStatus = -1;
                            }
                        } else {
                            LOG.info("Submitted Mover Order Number = " + orderID);
                            submittedOrderID = orderID;
                            CustomStagesHelper.setResponseParameter(context, ConstantsForSales.GENERATEDORDERNO,
                                    orderID);
                            CustomStagesHelper.setResponseParameter(context, ConstantsForSales.MVXCOMPANY, mvxCompany);

                            LOG.info("Get Order lines from partially submitted order.");

                            if (simulatedOrder) {
                                try {
                                    saveSimulatedOrder(currentOrderID, orderID);
                                } catch (Exception e) {
                                    LOG.debug(e.getMessage());
                                }
                            } else {

                                try {
                                    savePartialOrder(currentOrderID, context);
                                } catch (Exception e) {
                                    LOG.debug(e.getMessage());
                                }
                            }
                        }
                    }
                }
                --msgPos;
                if ((msgPos >= 0) && (lastMsg.length() >= msgPos + 1)) {
                    apiError = lastMsg.substring(msgPos).trim();
                }
            }

            CustomStagesHelper.setResponseParameter(context, ConstantsForSales.APIERRORMESSAGE, apiError);
            FastStringBuffer msg = new FastStringBuffer("Order refused by Movex, ORNO = ");
            msg.append(getResponseParameter(ConstantsForSales.TMPORDERID));
            msg.append("\nReturn string: ");
            msg.append(lastMsg);
            String message = msg.toString();
            LOG.info(message);
            // send mail to customer support
            sendMail(message);
        }

        return mvxStatus;
    }

    /**
     * updateOrderLineIDs updates line IDs in the current order with the order
     * IDs assigned in Movex.
     * <p>
     * In Movex is it possible to set the order line increment to 10 or
     * something else. <br>
     * This increment is first reflected when the order is confirmed. <br>
     * This operation is not needed if the order line increment is 1.<br>
     * Moreover is not necessarily so that the number of order lines match, as a
     * ordering a fashion kit (style) makes Movex propagate the items in the kit
     * into the order, while e-Sales alone shows the original fashion kit.
     * 
     * @throws PipelineRuntimeException
     */
    private void updateOrderLineIDs() throws PipelineRuntimeException {
        /**
         * Update order lines: Get list of order lines from Movex Loop order
         * lines Update order line ID in e-Sales
         */
        final XMLResultset main = (XMLResultset) context.getResponse();
        try {
            Map<String, Map> mvxLinesMap = getMvxOrderLinesAsMap(submittedOrderID, context);
            if (!mvxLinesMap.isEmpty()) {
            	
                XMLIterator lines = (XMLIterator) main.getResultset(ConstantsForSales.ORDERLINE);
                lines.beforeFirst();
                //while (lines.hasNext()) {
                try {
	                while (lines.moveNext()) {
	                    //lines.moveNext();
	                    // Update the OrderLineID to the value it gets after
	                    // replication so that
	                    // the replication does not duplicate order lines
	                    String orderLineID = lines.getString(ConstantsForSales.ORDERLINEID);
	                    String itemNumber = lines.getString(ConstantsForSales.ITEMID);
	                    String mvxLinesMapKey = itemNumber + "_" + orderLineID;
	                    if (mvxLinesMap.containsKey(mvxLinesMapKey)) {
	                        Map<String, String> mvxLine = mvxLinesMap.get(mvxLinesMapKey);
	
	                        String orderLineKey = submittedOrderID + "_" + mvxLine.get(ConstantsForSales.PONR) + "_"
	                                + mvxLine.get(ConstantsForSales.POSX);
	                        
	                        CustomStagesHelper.updateRsAttribute(lines, ConstantsForSales.ORDERLINEID, orderLineKey);
	                        CustomStagesHelper.updateRsAttribute(lines, ConstantsForSales.LINE_NUMBER, mvxLine
	                                .get(ConstantsForSales.PONR));
	                        CustomStagesHelper.updateRsAttribute(lines, ConstantsForSales.LINE_SUFFIX, mvxLine
	                                .get(ConstantsForSales.POSX));
	                        CustomStagesHelper.updateRsAttribute(lines, ConstantsForSales.MVXWAREHOUSE, mvxLine
	                                .get(ConstantsForSales.WHLO));
	                        CustomStagesHelper.updateRsAttribute(lines, ConstantsForSales.CONFIRMEDDELIVERYDATE,
	                                movexDateToXMLDate(mvxLine.get(ConstantsForSales.CODT)));
	                        
	                    }
	                    //lines.moveNext();
	                }
                } catch (ResultsetException e) {
                    throw new PipelineRuntimeException("Failed to set OrderLineIDs", e);
                } finally {
                    // reset resultset - needed by presentation layer!
                    lines.beforeFirst();
                }
                //lines.beforeFirst();
            }

        } catch (final ResultsetException e) {
            final String msg = "Could not get the order lines subset.";
            LOG.error(msg, e);
            throw new PipelineRuntimeException(msg, e);
        } catch (final NumberFormatException e) {
            final String msg = "Could not convert the PONR from Movex API LstLine.";
            LOG.error(msg, e);
            throw new PipelineRuntimeException(msg, e);
        }
    }

    private Map<String, Map> getMvxOrderLinesAsMap(final String orderID, final PipelineContext context)
            throws PipelineRuntimeException {

        Map<String, Map> mvxLineMap = new HashMap<String, Map>();

        Map lstLines = new HashMap();
        lstLines.put(IMovexConnection.TRANSACTION, ConstantsForSales.LST_LINE);
        lstLines.put(ConstantsForSales.CONO, mvxCompany);
        lstLines.put(ConstantsForSales.ORNO, submittedOrderID);
        IMovexApiResultset rs = CustomStagesHelper.callMovex(context, movex, lstLines, ConstantsForSales.MVXSTATUS);
        if (rs == null) {
            return mvxLineMap;
        }

        if (!movex.isOk()) {
            final String msg = "Could not update the order lines with line numbers. " + movex.getLastMessage();
            LOG.debug(msg);
            return mvxLineMap;
        }

        Iterator it = rs.iterator();
        while (it.hasNext()) {
            Map mvxLine = (Map) it.next();
            // Parent product only
            if ("0".equals(mvxLine.get(ConstantsForSales.POSX))) {
                String demandOrderLineID = (String) mvxLine.get(ConstantsForSales.DRDL);
                String itemNumber = (String) mvxLine.get(ConstantsForSales.ITNO);
                if (demandOrderLineID != null) {
                    demandOrderLineID = String.valueOf(Integer.parseInt(demandOrderLineID));
                    String mvxLineMapKey = itemNumber + "_" + demandOrderLineID;
                    if (!mvxLineMap.containsKey(mvxLineMapKey)) {
                    	mvxLineMap.put(mvxLineMapKey, mvxLine);
                    }
                }
            }
        }

        return mvxLineMap;
    }

    public static String movexDateToXMLDate(final String date) {
        String xmlDate = null;
        if (date != null && date.length() > 0) {
            // Date is in the format 20071224
            String sYear = date.substring(0, 4);
            String sMonth = date.substring(4, 6);
            String sDay = date.substring(6, 8);

            xmlDate = sYear + "-" + sMonth + "-" + sDay + "T00:00:00.000";
        }
        return xmlDate;
    }

    /**
     * Following are the Credit Card specific Transactions.
     * 
     */

    private boolean addAuth() throws PipelineRuntimeException {
        final XMLResultset main = (XMLResultset) context.getResponse();

        Map authenticate = new HashMap();
        authenticate.put(IMovexConnection.TRANSACTION, ConstantsForSales.ADD_AUTH);
        authenticate.put(ConstantsForSales.CONO, mvxCompany);
        authenticate.put(ConstantsForSales.DIVI, getAttribute(ConstantsForSales.MVXDIVISION, main));
        authenticate.put(ConstantsForSales.CANU, creditCardNumber);
        authenticate.put(ConstantsForSales.EXP0, cardExpDate);
        authenticate.put(ConstantsForSales.CTPY, getResponseParameter(ConstantsForSales.CREDITCARDTYPE));
        authenticate.put(ConstantsForSales.RORC, referenceOrderCategoryType);
        authenticate.put(ConstantsForSales.CCAA, getResponseParameter(ConstantsForSales.ORDERTOTALTOPAY));
        authenticate.put(ConstantsForSales.CUCD, getResponseParameter(ConstantsForSales.CURRENCY));
        authenticate.put(ConstantsForSales.CSC1, cardSecurityCode);

        IMovexApiResultset res = CustomStagesHelper.callMovex(context, movexCC, authenticate,
                ConstantsForSales.MVXSTATUS);
        if (res == null) {
            return false;
        }

        if (!movexCC.isOk()) {
            final String msg = "Could not Add Authentication: " + movexCC.getLastMessage();
            LOG.error(msg);
            return false;
        }

        creditCardErrorCode = res.getParamAsString(ConstantsForSales.CCEC);
        creditCardAuthStatus = res.getParamAsString(ConstantsForSales.STAT);
        creditCardCVVCheckResponse = res.getParamAsString(ConstantsForSales.CSC2);
        TransactionReferenceNumber = res.getParamAsString(ConstantsForSales.NREF);

        if ("10".equals(creditCardAuthStatus)) {
            final String messg = "Communication error occurred. No transaction attempt. Credit Card Auth Status:"
                    + creditCardAuthStatus;
            LOG.error(messg);
            return false;
        }

        if ("15".equals(creditCardAuthStatus)) {
            final String messg = "Declined or error. Credit Card Auth Status:" + creditCardAuthStatus;
            LOG.error(messg);
            return false;
        }

        if (!"20".equals(creditCardAuthStatus)) {
            final String messg = "Credit card payment status could not be Approved. Credit Card Auth Status:"
                    + creditCardAuthStatus;
            LOG.error(messg);
            return false;
        }

        if ("N".equals(creditCardCVVCheckResponse)) {
            final String messg = "Credit card CVV2 couldnot be verified.Hence rolling back transaction.";
            LOG.error(messg);
            return false;
        }
        context.put(ConstantsForSales.THIRDPARTYPROVIDER, res.getParamAsString(ConstantsForSales.TRDP));

        return true;

    }

    private boolean authCreditCard() throws PipelineRuntimeException {

        Map authCard = new HashMap();
        authCard.put(IMovexConnection.TRANSACTION, ConstantsForSales.AUTH_CREDIT_CARD);
        authCard.put(ConstantsForSales.CONO, mvxCompany);
        authCard.put(ConstantsForSales.ORNO, submittedOrderID);
        authCard.put(ConstantsForSales.NREF, TransactionReferenceNumber);
        authCard.put(ConstantsForSales.TRDP, getResponseParameter(ConstantsForSales.THIRDPARTYPROVIDER));

        IMovexApiResultset res = CustomStagesHelper.callMovex(context, movex, authCard, ConstantsForSales.MVXSTATUS);
        if (res == null) {
            return false;
        }

        if (!movex.isOk()) {
            final String msg = "Could not Authenticate the given Credit Card: " + movex.getLastMessage();
            LOG.error(msg);
            return false;
        }

        return true;

    }

    private boolean addVoid() throws PipelineRuntimeException {
        final XMLResultset main = (XMLResultset) context.getResponse();

        Map addVoid = new HashMap();
        addVoid.put(IMovexConnection.TRANSACTION, ConstantsForSales.ADD_VOID);
        addVoid.put(ConstantsForSales.CONO, mvxCompany);
        addVoid.put(ConstantsForSales.DIVI, getAttribute(ConstantsForSales.MVXDIVISION, main));
        addVoid.put(ConstantsForSales.ORNO, submittedOrderID);
        addVoid.put(ConstantsForSales.NREF, TransactionReferenceNumber);
        addVoid.put(ConstantsForSales.TRDP, getResponseParameter(ConstantsForSales.THIRDPARTYPROVIDER));

        IMovexApiResultset res = CustomStagesHelper.callMovex(context, movexCC, addVoid, ConstantsForSales.MVXSTATUS);
        if (res == null) {
            return false;
        }

        if (!movex.isOk()) {
            final String msg = "Could not Void the given Transaction: " + movex.getLastMessage();
            LOG.error(msg);
            throw new PipelineRuntimeException(msg);
        }

        return true;

    }

    /**
     * These methods will delete OrderHead and OrderLines created in movex, once
     * any transaction after OrderConfirm fails, as the Order has already been
     * created in Movex.
     */
    private boolean orderDelHead() throws PipelineRuntimeException {
        final XMLResultset main = (XMLResultset) context.getResponse();

        Map orderDelHead = new HashMap();
        orderDelHead.put(IMovexConnection.TRANSACTION, ConstantsForSales.DEL_HEAD);
        orderDelHead.put(ConstantsForSales.CONO, mvxCompany);
        orderDelHead.put(ConstantsForSales.ORNO, submittedOrderID);

        IMovexApiResultset res = CustomStagesHelper
                .callMovex(context, movex, orderDelHead, ConstantsForSales.MVXSTATUS);
        if (res == null) {
            return false;
        }

        if (!movex.isOk()) {
            final String msg = "Error deleting order head id: " + submittedOrderID + " Error: "
                    + movex.getLastMessage();
            LOG.error(msg);
            throw new PipelineRuntimeException(msg);
        }

        return true;

    }

    /*
     * Currently this method is never called. Could be deleted in future, If
     * there is never a need to call this method separately.
     */
    /*
     * private boolean orderDelLine() throws PipelineRuntimeException {
     * 
     * final XMLResultset main = (XMLResultset) context.getResponse();
     * 
     * Map listLine = new HashMap(); listLine.put(IMovexConnection.TRANSACTION,
     * ConstantsForSales.LST_LINE); listLine.put(ConstantsForSales.CONO,
     * mvxCompany); listLine.put(ConstantsForSales.ORNO, submittedOrderID);
     * 
     * IMovexApiResultset res = CustomStagesHelper.callMovex(context, movex,
     * listLine, ConstantsForSales.MVXSTATUS); if (res == null) { return false; }
     * 
     * if (!movex.isOk()) { final String msg = "Could not fetch lines from movex
     * for given order id: " + submittedOrderID+ "Error:"+
     * movex.getLastMessage(); LOG.error(msg); throw new
     * PipelineRuntimeException(msg); }
     * 
     * final Iterator lines = res.iterator();
     * 
     * if (lines.hasNext()) { //Determine the step Movex has assigned the line
     * IDs String lineNumber = (String) ((Map)
     * lines.next()).get(ConstantsForSales.PONR); String lineSuffix = (String)
     * ((Map) lines.next()).get(ConstantsForSales.POSX);
     * 
     * Map orderDeleteLine = new HashMap();
     * orderDeleteLine.put(IMovexConnection.TRANSACTION,
     * ConstantsForSales.DEL_LINE); orderDeleteLine.put(ConstantsForSales.CONO,
     * mvxCompany); orderDeleteLine.put(ConstantsForSales.ORNO,
     * submittedOrderID); orderDeleteLine.put(ConstantsForSales.PONR,
     * lineNumber); orderDeleteLine.put(ConstantsForSales.POSX, lineSuffix);
     * 
     * IMovexApiResultset rs = CustomStagesHelper.callMovex(context, movex,
     * orderDeleteLine, ConstantsForSales.MVXSTATUS);
     * 
     * if (rs == null) { return false; }
     * 
     * if (!movex.isOk()) { final String msg = "Could not delete order lines
     * from movex for given order id: " + submittedOrderID+ "Error:"+
     * movex.getLastMessage(); LOG.error(msg); throw new
     * PipelineRuntimeException(msg); } } return true; }
     */
    /**
     * Sends a mail with the given message.
     * <p>
     * The server and user are read from the application data.
     * 
     * @param errMsg
     *            The message to send in the mail
     * @throws PipelineRuntimeException
     */
    private void sendMail(final String errMsg) throws PipelineRuntimeException {

        try {
            String email = ApplicationParameter.getValue(ConstantsForSales.MAIL_RECEIEVER_FOR_ORDER_ERROR);
            if (email == null || (email.length() < 5)) {
                LOG.info("No e-mail address specified.");
                return;
            }

            // subject
            String tmpOrderId = getResponseParameter(ConstantsForSales.TMPORDERID);
            String subject = "Error submitting temporary order " + tmpOrderId + " in Infor e-Commerce";
            // body
            StringBuffer body = new StringBuffer();
            body.append("Temp order id: ");
            body.append(tmpOrderId);
            if (errMsg.length() > 3) {
                body.append("\nStatus: ");
                body.append(errMsg.substring(errMsg.length() - 3));
            }
            body.append("\nError message from Movex API: ");
            body.append(errMsg);

            // Send the mail via the application mail server
            ApplicationMail.send(email, subject, body.toString());
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException(e);
        }
    }

    /**
     * Check the context parameter updatingOrderLines if the order line IDs
     * should be updated with new IDs as assigned by Movex?
     * 
     * @return true if the parameter updatingOrderLines exists and is "true"
     */
    private boolean isUpdatingOrderLines() throws PipelineRuntimeException {
        return "true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.UPDATINGORDERLINES));
    }

    /**
     * Converts a string to an integer - defaultValue if the string is null or
     * invalid.
     * 
     * @param intAsString
     *            integer as a string
     * @param defaultValue
     *            default value for invalid strings
     * @return converted integer
     */
    private int toInteger(final String intAsString, final int defaultValue) {

        int integer = defaultValue;
        if (!"".equals(intAsString)) {
            try {
                integer = Integer.parseInt(intAsString);
            } catch (NumberFormatException e) {
                integer = defaultValue;
            }
        }
        return integer;
    }

    /**
     * Gets the named attribute from the given resultset as a string.
     * 
     * @param name
     *            name of the requested attribute
     * @param rs
     *            resultset including requested attribute
     * @return the parameter value as a string - empty if not found
     */
    private String getAttribute(final String name, final Resultset rs) {

        String attr = null;
        try {
            attr = rs.getString(name);
        } catch (ResultsetException e) {
            String msg = "Missing attribute: " + name;
            LOG.error(msg, e);
        }
        if (attr == null) {
            attr = "";
        }
        return attr;
    }

    /**
     * Gets the named parameter from the given pipeline context as a string.
     * 
     * @param parameterName
     *            name of the requested parameter
     * @param pipeline
     *            context including requested parameter
     * @return the parameter value as a string - empty if not found
     */
    private String getResponseParameter(final String parameterName) {

        String param = (String) context.get(parameterName);
        if (param == null) {
            LOG.error("Missing parameter: " + parameterName);
            param = "";
        }
        return param;
    }

    /**
     * Gets the named parameter from the given parameter block as a string.
     * 
     * @param parameterName
     *            name of the requested parameter
     * @return the parameter value as a string - empty if not found
     */
    private String getRequestParameter(final String parameterName) {

        String param = null;
        try {
            param = requestParameters.getString(parameterName);
        } catch (ParametersException e) {
            LOG.error("Missing parameter: " + parameterName);
        }
        if (param == null) {
            param = "";
        }
        return param;
    }

    /**
     * Gets the named parameter from the given parameter block as a BigDecimal.
     * 
     * @param parameterName
     *            name of the requested paramerer
     * @param rs
     *            resultset including requested parameter
     * @return the parameter value as a string - the value is 0.0 if not found.
     */
    private BigDecimal getDecimal(final String parameterName, final Resultset rs) {

        BigDecimal param = null;
        try {
            param = rs.getDecimal(parameterName);
        } catch (ResultsetException e) {
            LOG.error("Missing parameter: " + parameterName, e);
            param = Decimal.ZERO;
        }
        return param;
    }

    /**
     * Converts a string in XML format to Movex format YYYYMMDD.
     * 
     * @param date
     *            as a string in XML format YYYY-MM-DDTHH:MM:SS:HHH
     * @return date as a string in Movex format YYYYMMDD
     * @throws PipelineRuntimeException
     */
    protected static String getMovexDate(final String date) throws PipelineRuntimeException {

        // Input format: YYYY-MM-DDT....
        FastStringBuffer str = new FastStringBuffer();
        try {
            if ((date != null) && (date.length() > 0)) {
                str.append(date.substring(0, 4)).append(date.substring(5, 7)).append(date.substring(8, 10));
            }
            return str.toString();
        } catch (StringIndexOutOfBoundsException e) {
            throw new PipelineRuntimeException("Invalid date format", e);
        }
    }

    /**
     * Saves the order by calling the method PreviousOrder.SaveAsPreviousOrder.
     * 
     * @param response
     *            The respons to put output in.
     * @param xmlRequest
     *            Yhe request to use.
     * @param rsOrderLines
     *            Resultset with order lines to
     * @param currentOrderID
     *            ID for the current order to execute.
     * @param languageCode
     *            Language code to use for names.
     * @return Returns the resultset returned by the method.
     * @throws PipelineRuntimeException
     */
    private void savePartialOrder(final String currentOrderID, PipelineContext context) throws PipelineRuntimeException {
        try {
            updateOrderLineIDs();

            XMLResultset response = (XMLResultset) context.getResponse();
            response.setString("OrderID", submittedOrderID);
            response.getParameters().set(ConstantsForSales.SUBMITTEDORDERID, submittedOrderID);

            SaveAsPreviousOrder previousPipelineStage = new SaveAsPreviousOrder();
            previousPipelineStage.execute(context);

        } catch (Exception e) {
            LOG.debug(e.getMessage());
        }
    }

    // TODO: No longer used in this class. Should this be removed?
    private void saveOrderM3Enabled(IMovexApiResultset apiRes, PipelineContext context, String movexOrderID,
            Resultset rsOrderLines, CommitPipelineExecuter insertPO, String initOrderStatusCode)
            throws PipelineRuntimeException, ResultsetException {
    	
    	
        Map fieldMapping = ConstantsForSales.getOrderLineAPIMapping();
        // XMLResultset head = (XMLResultset) context.getResponse();

        // Loop through the order lines
        rsOrderLines.beforeFirst();
        rsOrderLines.moveNext();

        List fieldList = rsOrderLines.getNames();
        fieldList.add("MvxConfigurableID");
        Iterator apiIter = apiRes.iterator();

        String cono = ((XMLResultset) context.getResponse()).getString(ConstantsForSales.MVXCOMPANY);
        for (int i = 1; apiIter.hasNext(); ++i) {
            final String orderLineNo = String.valueOf(i);
            String status = initOrderStatusCode;
            insertPO.addSubset("OrderLine");

            Map<String, String> mvxLine = (Map<String, String>) apiIter.next();
            for (int j = 0; j < fieldList.size(); ++j) {
                final String attrName = (String) fieldList.get(j);
                Object fieldValue = fieldMapping.get(attrName);
                String attrValue = null;

                attrValue = (String) mvxLine.get(fieldValue);
                

                // Update OrderLineID in M3 scenario duplicated Order lines
                // after replication
                if ("OrderLineID".equals(attrName)) {
                    insertPO.setSubsetAttribute(attrName, movexOrderID + "_"
                            + (String) mvxLine.get(ConstantsForSales.PONR) + "_"
                            + (String) mvxLine.get(ConstantsForSales.POSX));
                } else {
                    if (attrValue != null) {
                        insertPO.setSubsetAttribute(attrName, attrValue);
                    }
                }

                if ("IsVisible".equals(attrName)) {
                    if ("N".equals(attrValue)) {
                        throw new PipelineRuntimeException("Invisible item in orderline");
                    }
                } else if ("IsActive".equals(attrName)) {
                    if ("N".equals(attrValue)) {
                        throw new PipelineRuntimeException("Inactive item in orderline");
                    }
                } else if ("ShippingCountryName".equals(attrName)) {
                    insertPO.setSubsetAttribute("ShippingCountry", attrValue);
                } else if ("Quantity".equals(attrName)) {
                    insertPO.setSubsetAttribute("RemainingQuantity", attrValue);
                } else if ("MvxConfigurableID".equals(attrName)) {
                    if (!"0".equals(attrValue)) {
                        insertPO.setSubsetAttribute("MvxConfigurableID", getMvxConfigID(attrValue));
                    } else {
                        insertPO.setSubsetAttribute("MvxConfigurableID", null);
                    }
                } else if (ConstantsForSales.ITEMID.equals(attrName)) {
                    orderItems.add(attrValue.trim());
                    LOG.debug("Add " + attrValue);
                }
            }
            insertPO.setSubsetAttribute("DeliveredQuantity", "0");
            insertPO.setSubsetAttribute(ConstantsForSales.UNITCODE, (String) mvxLine.get(ConstantsForSales.SPUN));
            insertPO.setSubsetAttribute(ConstantsForSales.LINESUFFIX, (String) mvxLine.get(ConstantsForSales.POSX));
            updResellPrice(insertPO, mvxLine);
            updLineDiscount(insertPO, mvxLine);

        }
        updateOrderLineStatus(rsOrderLines, orderItems, initOrderStatusCode);
    }

    private void updateOrderLineStatus(Resultset rsOrderLines, List orderItems, String initStatus)
            throws ResultsetException {
        rsOrderLines.beforeFirst();
        LOG.debug("Order Items " + orderItems);
        while (rsOrderLines.moveNext()) {
            String itemid = rsOrderLines.getString(ConstantsForSales.ITEM_ID);

            if (orderItems == null || orderItems.size() == 0) {
                CustomStagesHelper.updateRsAttribute((XMLIterator) rsOrderLines, "OrderLineStatus", "");
            } else {
                LOG.debug("Check " + itemid + " " + orderItems.contains(itemid.trim()));
                if (orderItems.contains(itemid.trim())) {
                    CustomStagesHelper.updateRsAttribute((XMLIterator) rsOrderLines, "OrderLineStatus", initStatus);
                    // break;
                } else {
                    CustomStagesHelper.updateRsAttribute((XMLIterator) rsOrderLines, "OrderLineStatus", "");

                }
            }
        }
    }

    /**
     * Updates SimulateOrderValidated field of orderLines based on the result of
     * Order Confirm. If Order Confirm is successful, set SimulateOrderValidated
     * to 1 else set it to 2
     * 
     * @param context
     *            pipeline context
     * @param lineIter
     *            XMLIterator pointing on line to handle
     * @throws PipelineRuntimeException
     */
    private void updateSimulateOrderFlags(final XMLIterator lineIter, String OrderID, int mvxStatus)
            throws PipelineRuntimeException {
        int simulateFlag;

        if (mvxStatus < 0)
            simulateFlag = 2; // failed
        else
            simulateFlag = 1; // success

        int nLineNo = 0;
        try {
            lineIter.beforeFirst();
            String rsParam = ConstantsForSales.SIMULATE_VALIDATOR_PARAM;
            while (lineIter.moveNext()) {
                // if failed order is due to invalid orderlines, mark only the
                // specific orderlines as failed
                if (mvxStatus == -25
                        && ((!vLinesWithError.isEmpty() && !vOrderLineNumber.isEmpty()) || !vOtherErrors.isEmpty())) {
                    simulateFlag = getSimulateOrderFlag(nLineNo);
                }
                CustomStagesHelper.updateRsAttribute(lineIter, rsParam, String.valueOf(simulateFlag));
                nLineNo++;
            }
            saveSimulateOrderFlagsToDB(lineIter, OrderID);
        } catch (ResultsetException e) {
            final String msg = "Could not update simulate order flags";
            throw new PipelineRuntimeException(msg, e);
        }
    }

    private void saveSimulateOrderFlagsToDB(final XMLIterator lineIter, String OrderID) throws PipelineRuntimeException {

        try { // Call CurrentOrder_UpdateSimulateOrderFlags method
            CommitPipelineExecuter updateCO = new CommitPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                    "CurrentOrder", "UpdateSimulateOrderFlags");

            updateCO.addEntity();
            updateCO.setAttribute("OrderID", OrderID);
            updateCO.setEntityKey("OrderID", OrderID);
            updateCO.setParam("orderId", OrderID);

            lineIter.beforeFirst();
            while (lineIter.moveNext()) {
                updateCO.addSubset("OrderLine");
                updateCO.setSubsetKey("OrderLineID", lineIter.getString("ID"));
                updateCO.setSubsetAttribute(ConstantsForSales.ORDERLINEID, lineIter
                        .getString(ConstantsForSales.ORDERLINEID));
                updateCO.setSubsetAttribute(ConstantsForSales.SIMULATE_VALIDATOR_PARAM, lineIter
                        .getString(ConstantsForSales.SIMULATE_VALIDATOR_PARAM));
            }
            updateCO.execute();

        } catch (Exception e) {
            final String msg = "Could not save simulate order flags to database.";
            throw new PipelineRuntimeException(msg, e);
            // LOG.error(msg, e);
        }
    }

    private void validateOrderLines(final XMLResultset resultSet, int mvxStatus) throws PipelineRuntimeException,
            ResultsetException {
        int simOrderValidator = 0;

        if (mvxStatus == -25)
            getOrderLinesWithError(); // if error occurred in the orderline
        // level, determine the lines that
        // failed

        XMLIterator orderLines = null;
        try {
            orderLines = (XMLIterator) resultSet.getResultset(ConstantsForSales.ORDERLINE);
        } catch (ResultsetException e) {
            String msg = "Could not get order lines";
            LOG.error(msg, e);

            throw new PipelineRuntimeException(msg, e);
        }

        // update SimulateOrderValidated fields for all orderlines
        // Call ValidateSOFlags
        if (simulatedOrder) {
            if (orderLines != null && !orderLines.isEmpty()) {
                LOG.debug("Now calling updateSimulateORderFlags.");
                updateSimulateOrderFlags(orderLines, resultSet.getString(ConstantsForSales.ORDERID), mvxStatus);
            }
        }
    }

    /**
     * Call OIS100MI.LstErrMsgOrder to get the failed orderlines from M3
     * 
     * @throws PipelineRuntimeException
     */
    private void getOrderLinesWithError() throws PipelineRuntimeException {
        // get CONO, ORNO for a Movex call using OIS100MI:LstErrMsgOrder
        Map lines = new HashMap();
        lines.put(IMovexConnection.TRANSACTION, ConstantsForSales.LST_ERR_MSG);
        lines.put(ConstantsForSales.CONO, mvxCompany);
        lines.put(ConstantsForSales.ORNO, getResponseParameter(ConstantsForSales.TMPORDERID));

        // retrieve order lines data from Movex

        IMovexApiResultset apiRes = CustomStagesHelper.callMovex(context, movex, lines, "");
        if (apiRes == null) {
            return;
        }

        vLinesWithError.clear();
        Iterator apiIter = apiRes.iterator();
        while (apiIter.hasNext()) {
            Map mvxLine = (Map) apiIter.next();
            if (disregardOrderLineWarning((String) mvxLine.get(ConstantsForSales.MDTA)) == false) {
                String ponr = getOrderLineNumber((String) mvxLine.get(ConstantsForSales.TX60));
                if (!"".equals(ponr))
                    vLinesWithError.add(ponr); // add the orderline number to
                // the list of failed orderlines
            }
        }
    }

    /**
     * Used to determine if invalid orderline contains warning or error message.
     * If it contains a warning message, the orderline can be considered valid.
     * 
     * @param mdta
     * @return
     */
    private boolean disregardOrderLineWarning(String mdta) {
        if (mdta != null && mdta.startsWith("WARNING")) {
            return true;
        }

        return false;
    }

    /**
     * Parse TX60 returned by M3 to get the 5 character orderline number
     * 
     * @param sErrorText
     *            TX60 taken from m3
     * @return orderline number (PONR)
     */
    private String getOrderLineNumber(String sErrorText) {

        if (sErrorText == null)
            return "";
        String delimeter = "/";
        String[] temp;

        temp = sErrorText.split(delimeter);

        for (int i = 3; i < temp.length; i++) {
            if (temp[i].length() == 5) {
                return (temp[i]);
            }
        }
        return "";
    }

    /**
     * If the orderline number is in the list of failed ones, then set flag to 2
     * 
     * @param lineNo
     *            sequence number of the orderline
     * @return 1 or 2
     */
    private int getSimulateOrderFlag(int lineNo) {
        if (vOtherErrors.contains(String.valueOf(lineNo)) == true) {
            return 2;
        }

        // offset happens when a line number with error is placed between valid
        // and/or invalid lines
        int offset = 0;
        if (vOtherErrors.isEmpty() == false) {
            for (int i = 0; i < lineNo; i++) {
                if (vOtherErrors.contains(String.valueOf(i)) == true) {
                    offset++;
                }
            }
        }

        String ponr;
        if (vOrderLineNumber.size() > (lineNo - offset)) {
            ponr = vOrderLineNumber.get(lineNo - offset);
            if (vLinesWithError.contains(ponr)) {
                return 2;
            }
        }
        return 1;
    }

    /**
     * Append 0's at the beginning until string length is n number of characters
     * 
     * @param source
     *            the original string to be padded
     * @param numChars
     *            the length of the output string
     * @return padded string
     */
    private static String padLeft(String source, int numChars) {
        int length = numChars - source.length();
        StringBuilder sb = new StringBuilder();
        while (sb.length() < length) {
            sb.append("0");
        }
        sb.append(source);
        return sb.toString();
    }

    private void saveSimulatedOrder(String orderID, String submittedOrderID) throws PipelineRuntimeException,
            ResultsetException {
        CommitPipelineExecuter updateSO = new CommitPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "ShadowOrder",
                "UpdateShadowOrder");
        updateSO.addEntity();

        updateSO.setParam(ConstantsForSales.ORDERID_PARAM, orderID);
        updateSO.setAttribute(ConstantsForSales.CURRENT_ORDER_ID, orderID);

        updateSimateOrderHeader(updateSO, submittedOrderID);
        updateOrderLine(updateSO, submittedOrderID, "ShadowOrderLine",
                ConstantsForSales.getShadowOrderLineAPIMapping(), true);

        updateSO.execute();

        CustomStagesHelper.setResponseParameter(context, ConstantsForSales.GENERATEDORDERNO, submittedOrderID);

    }

    private void updateSimateOrderHeader(CommitPipelineExecuter updateSO, String submittedOrderID)
            throws PipelineRuntimeException {
        IMovexApiResultset apiRes = callGetHead(context, submittedOrderID);
        Map soHeaderMap = ConstantsForSales.getShadowOrderHeaderAPIMapping();
        Iterator fieldList = soHeaderMap.keySet().iterator();
        Iterator apiIter = apiRes.iterator();
        for (int i = 1; fieldList.hasNext(); ++i) {
            String field = (String) fieldList.next();
            String apiField = (String) soHeaderMap.get(field);
            updateSO.setAttribute(field, apiRes.getParamAsString(apiField));
        }
        updHeadDiscount(updateSO, apiRes);
    }

    private void updHeadDiscount(CommitPipelineExecuter updateSO, IMovexApiResultset apiRes) {
        BigDecimal grossAmount = new BigDecimal(apiRes.getParamAsString(ConstantsForSales.BRAM));
        BigDecimal netAmount = new BigDecimal(apiRes.getParamAsString(ConstantsForSales.ONET));

        BigDecimal netAmount2 = new BigDecimal(apiRes.getParamAsString(ConstantsForSales.NTAM));
        BigDecimal discountAmount = grossAmount.subtract(netAmount);
        updateSO.setAttribute(ConstantsForSales.ORDER_DISCOUNT_AMOUNT, Decimal.toString(discountAmount));
        updateSO.setAttribute(ConstantsForSales.ORDER_LINE_DISCOUNT_AMOUNT, Decimal.toString(grossAmount
                .subtract(netAmount2)));
        // BigDecimal orderDiscount = new
        // BigDecimal(apiRes.getParamAsString(ConstantsForSales.ODAM));
    }

    private void updateOrderLine(CommitPipelineExecuter updateSO, String submittedOrderID, String subSetName,
            Map lineMap, boolean simulated) throws PipelineRuntimeException, ResultsetException {
        IMovexApiResultset apiRes = callLstLine(context, submittedOrderID);
        Iterator apiIter = apiRes.iterator();
        orderItems = new ArrayList();
        for (int i = 1; apiIter.hasNext(); ++i) {
            Map<String, String> mvxLine = (Map<String, String>) apiIter.next();
            updateSO.addSubset(subSetName);
            // updateSO.setSubsetAttribute(ConstantsForSales.SHADOW_ORDER_ID,
            // orderID);
            Iterator fieldList = lineMap.keySet().iterator();
            for (int j = 1; fieldList.hasNext(); ++j) {
                String field = (String) fieldList.next();
                String apiField = (String) lineMap.get(field);
                String attrValue = (String) mvxLine.get(apiField);
                if (apiField.equals(ConstantsForSales.ITNO)) {
                    orderItems.add(attrValue);
                }
                updateSO.setSubsetAttribute(field, attrValue);
            }
            updLineDiscount(updateSO, mvxLine);
        }
        XMLResultset response = (XMLResultset) context.getResponse();
        XMLIterator rsOrderLines = (XMLIterator) response.getResultset(ConstantsForSales.ORDERLINE);
       
        updateOrderLineStatus(rsOrderLines, orderItems, "22");

    }

    private void updLineDiscount(CommitPipelineExecuter updateSO, final Map<String, String> mvxLine) {
        BigDecimal qty = new BigDecimal(mvxLine.get(ConstantsForSales.ORQT));
        BigDecimal salePrice = new BigDecimal(mvxLine.get(ConstantsForSales.SAPR));
        BigDecimal netPrice = new BigDecimal(mvxLine.get(ConstantsForSales.NEPR));

        BigDecimal linePrice = qty.multiply(salePrice);
        BigDecimal lineDiscounted = qty.multiply(netPrice);
        BigDecimal lineDiscount = linePrice.subtract(lineDiscounted);

        updateSO.setSubsetAttribute(ConstantsForSales.LINEPRICE, Decimal.toString(linePrice));

        if (linePrice.compareTo(Decimal.ZERO) != 0) {
            // LineDisPercent = 100 * LineDiscount / LinePrice
            BigDecimal percent = Decimal.divide(Decimal.ONEHUNDRED.multiply(lineDiscount), linePrice);
            updateSO.setSubsetAttribute(ConstantsForSales.LINEDISPERCENT, Decimal.toString(percent));
        }
    }

    private void updResellPrice(CommitPipelineExecuter insertPO, final Map<String, String> mvxLine) {
        // BigDecimal qty = getParameterAsDecimal(ConstantsForSales.QUANTITY,
        // mvxLine);

        // TODO: Reevaluate formula on deriving the correct value of resell
        // price (if needed).
        BigDecimal qty = new BigDecimal(mvxLine.get(ConstantsForSales.ORQT));
        if (qty.compareTo(Decimal.ZERO) != 0) {
            BigDecimal mvxQty = new BigDecimal(mvxLine.get(ConstantsForSales.ORQT));
            BigDecimal resellPrice = new BigDecimal(mvxLine.get(ConstantsForSales.SAPR));
            resellPrice = Decimal.divide(resellPrice.multiply(mvxQty), qty);
            insertPO.setSubsetAttribute(ConstantsForSales.RESELLPRICE, Decimal.toString(resellPrice));
        }
    }

    protected IMovexApiResultset callGetHead(PipelineContext context, String submittedOrderID)
            throws PipelineRuntimeException {
        XMLResultset order = (XMLResultset) context.getResponse();
        Map header = new HashMap();
        header.put(IMovexConnection.TRANSACTION, ConstantsForSales.GET_HEAD);
        header.put(ConstantsForSales.CONO, mvxCompany);
        header.put(ConstantsForSales.ORNO, submittedOrderID);
        IMovexApiResultset apiRes = CustomStagesHelper.callMovex(context, movex, header, ConstantsForSales.MVXSTATUS);
        return apiRes;
    }

    protected IMovexApiResultset callLstLine(PipelineContext context, String submittedOrderID)
            throws PipelineRuntimeException {
        Map<String, String> lines = new HashMap<String, String>();
        lines.put(IMovexConnection.TRANSACTION, ConstantsForSales.LST_LINE);
        lines.put(ConstantsForSales.CONO, mvxCompany);
        lines.put(ConstantsForSales.ORNO, submittedOrderID);
        IMovexApiResultset apiRes = null;
        try {
            apiRes = CustomStagesHelper.callMovex(context, movex, lines, ConstantsForSales.MVXSTATUS);
        } catch (PipelineRuntimeException e) {
            e.printStackTrace();
        }
        return apiRes;
    }

    private boolean needSimulation(String orderID, Date orderTimeStamp) throws PipelineRuntimeException,
            ResultsetException {
        LOG.debug("Check timestamp CO" + orderTimeStamp);
        SearchPipelineExecuter searchShadow = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                "ShadowOrder", "GetShadowOrderByOrderID");
        searchShadow.setParam("orderID", orderID);
        XMLResultset rsShadowInfo = searchShadow.execute();

        if (rsShadowInfo == null || rsShadowInfo.rowCount() == 0) {
            return false;
        }
        rsShadowInfo.moveFirst();
        Date shadowDate = rsShadowInfo.getDate(ConstantsForSales.TIMESTAMP);
        LOG.debug("Check timestamp CO" + shadowDate);

        if (shadowDate.before(orderTimeStamp))
            return true;

        return false;

    }

    private void deleteShadowOrder(String orderID) throws PipelineRuntimeException, ResultsetException {
        LOG.debug("Delete Shadow for 0 orderlines");

        SearchPipelineExecuter spe = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "ShadowOrder",
                "GetShadowOrderByOrderID");
        spe.setParam("orderID", orderID);
        XMLResultset rsSimInfo = spe.execute();
        String shadowOrderID = null;
        if (rsSimInfo.moveFirst()) {
            shadowOrderID = rsSimInfo.getString(ConstantsForSales.SHADOW_ORDER_ID);
        }
        if (shadowOrderID != null) {
            DeletePipelineExecuter dpe = new DeletePipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "ShadowOrder",
                    "DeleteShadowOrderByCurrentOrder");
            dpe.setMainKey(ConstantsForSales.SHADOW_ORDER_ID, shadowOrderID);
            dpe.setParam("orderID", orderID);
            dpe.execute();
        }
    }

    // private String getRandomCustomerOrderNumber() throws
    // PipelineRuntimeException {
    // int cuorFieldLength = 20;
    // String simcuor = null;
    // try {
    // simcuor =
    // ApplicationParameter.getValue(ConstantsForSales.SIMULATE_ORDER_CUST_ORNO);
    // } catch (ResultsetException e) {
    // simcuor = ConstantsForSales.ESALESSIMULATE;
    // }
    // if (simcuor == null) {
    // simcuor = ConstantsForSales.ESALESSIMULATE;
    // }
    //
    // SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");
    // String date = sdf.format(new Date()).toString();
    //
    // if (simcuor.length() + date.length() > cuorFieldLength) {
    // simcuor = simcuor + date;
    // }
    // int remaining = cuorFieldLength - simcuor.length();
    // System.out.println(remaining);
    // String max = "";
    // for (int i = 0; i < (remaining); i++) {
    // max = max + "9";
    // }
    // Random r = new Random();
    // return (simcuor + Math.abs((r.nextInt(Integer.parseInt(max)))));
    //
    // }

    private String getMvxConfigID(String CFIN) throws PipelineRuntimeException, ResultsetException {
        SearchPipelineExecuter searchMvxConfig = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                "MvxProductConfiguration", "getConfigurableIDByNumber");
        searchMvxConfig.setParam("MvxID", CFIN);
        XMLResultset rsInfo = searchMvxConfig.execute();

        // Set submitter credentials in order
        if (rsInfo.moveFirst()) {
            return (rsInfo.getString("ID"));

        } else {
            return null;
        }

    }
    
    private BigDecimal n20(BigDecimal param){
    	if(param==null){
    		return new BigDecimal("0.00");
    	}
    	else{
    		return param;
    	}
    }

}
