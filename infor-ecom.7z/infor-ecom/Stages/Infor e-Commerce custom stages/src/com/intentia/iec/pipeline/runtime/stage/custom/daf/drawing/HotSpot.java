package com.intentia.iec.pipeline.runtime.stage.custom.daf.drawing;

/**
 * Class that represents a Hot spot in e-Sales and DAF.
 *
 */
class HotSpot {
	private String shapeCode = null;
	
	private String coordinate = null;
	
	private String itemNumber = null;
	
	private String serialNumber = "";
	
	private String hasDrawing = DafDrawingConstants.NO;
	
	/**
	 * Default constructor
	 */
	public HotSpot() {
	}

	/**
	 * Returns the Shape Code
	 * @return
	 */
	public String getShapeCode() {
		return shapeCode;
	}

	/**
	 * Returns the Coordinate
	 * @return
	 */
	public String getCoordinate() {
		return coordinate;
	}

	/**
	 * Returns the Item Number
	 * @return
	 */
	public String getItemNumber() {
		return itemNumber;
	}
	
	/**
	 * Returns the Serial Number
	 * @return
	 */
	public String getSerialNumber() {
		return serialNumber;
	}

	/**
	 * Sets the Shape Code
	 * @param shapeCode
	 */
	public void setShapeCode(String shapeCode) {
		this.shapeCode = shapeCode;
	}

	/**
	 * Sets the Coordinate
	 * @param coordinate
	 */
	public void setCoordinate(String coordinate) {
		this.coordinate = coordinate;
	}

	/**
	 * Sets the Item Number
	 * @param itemNumber
	 */
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}
	
	/**
	 * Sets the Serial Number
	 * @param serialNumber
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	/**
	 * Returns the Has Drawing property
	 * @return
	 */
	public String getHasDrawing() {
		return hasDrawing;
	}

	/**
	 * Sets the Has Drawing property
	 * @param hasDrawing
	 */
	public void setHasDrawing(String hasDrawing) {
		this.hasDrawing = hasDrawing;
	}
}
