package com.intentia.iec.pipeline.runtime.integration.ia.model;

public class IaStatistic {

	private final static String FIELD_DELIM = " : ";

	private float likelihood;
	private float benefit;
	private float expectedBenefit;
	
	public IaStatistic(){
		this.likelihood = 0;
		this.benefit = 0;
		this.expectedBenefit = 0;
	}
	
	public IaStatistic(float likelihood, float benefit, float expectedBenefit){
		this.likelihood = likelihood;
		this.benefit = benefit;
		this.expectedBenefit = expectedBenefit;
	}

	public float getLikelihood() {
		return likelihood;
	}

	public void setLikelihood(float likelihood) {
		this.likelihood = likelihood;
	}

	public float getBenefit() {
		return benefit;
	}

	public void setBenefit(float benefit) {
		this.benefit = benefit;
	}

	public float getExpectedBenefit() {
		return expectedBenefit;
	}

	public void setExpectedBenefit(float expectedBenefit) {
		this.expectedBenefit = expectedBenefit;
	}

	@Override
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append("Score").append(FIELD_DELIM)
				.append(this.getLikelihood());
		return str.toString();
	}

}
