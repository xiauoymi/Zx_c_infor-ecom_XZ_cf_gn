package com.intentia.iec.pipeline.runtime.stage.custom.search;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;

public final class IndexerUtils {

    public static void addIndexedField(Document doc, String name, String value) {
        if (value != null) {
            doc.add(new Field(name, value, Field.Store.YES, Field.Index.UN_TOKENIZED));
        }
    }

    public static void addStoredField(Document doc, String name, String value) {
        if (value != null) {
            doc.add(new Field(name, value, Field.Store.YES, Field.Index.NO));
        }
    }

    public static void addTokenizedField(Document doc, String name, String value) {
        if (value != null) {
            doc.add(new Field(name, value, Field.Store.NO, Field.Index.TOKENIZED));
        }
    }

}
