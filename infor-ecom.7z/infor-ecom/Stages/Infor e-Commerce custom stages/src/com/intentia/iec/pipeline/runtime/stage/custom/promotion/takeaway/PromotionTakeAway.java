/**
 * 
 */
package com.intentia.iec.pipeline.runtime.stage.custom.promotion.takeaway;

import java.math.BigDecimal;
import java.util.List;

import com.intentia.iec.pipeline.runtime.stage.utils.Decimal;

/**
 * @author gsantiago
 * 
 */
public class PromotionTakeAway implements Comparable<PromotionTakeAway>{

	private List<String> values = null;
	private String operator = null;
	private String field = null;
	private String takeawayType = null;
	private String promotionName = null;
	private String extraParams = null;
	private BigDecimal exchangeRate = null;
	private BigDecimal altExchangeRate = null;
	private BigDecimal convertionRate = null;
	private String promotionID = null;
	private Integer priority = 0;

	
	public List<String> getValues() {
		return values;
	}

	public void setValues(List<String> values) {
		this.values = values;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
		if(this.takeawayType != null && !"".equals(takeawayType)){
			this.setTakeAwayPriority();			
		}
	}

	public String getTakeawayType() {
		return takeawayType;
	}

	public void setTakeawayType(String takeawayType) {
		this.takeawayType = takeawayType;
	}

	public String getPromotionName() {
		return promotionName;
	}

	public void setPromotionName(String promotionName) {
		this.promotionName = promotionName;
	}

	public String getExtraParams() {
		return extraParams;
	}

	public void setExtraParams(String extraParams) {
		this.extraParams = extraParams;
	}
	public BigDecimal getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(BigDecimal exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	public void setExchangeRate(String exchangeRate) {
		if (exchangeRate != null && !exchangeRate.isEmpty()) {
			this.setExchangeRate(new BigDecimal(exchangeRate));
		}
	}

	public BigDecimal getAltExchangeRate() {
		return altExchangeRate;
	}

	public void setAltExchangeRate(BigDecimal altExchangeRate) {
		this.altExchangeRate = altExchangeRate;
	}

	public void setAltExchangeRate(String altExchangeRate) {
		if (altExchangeRate != null && !altExchangeRate.isEmpty()) {
			this.setAltExchangeRate(new BigDecimal(altExchangeRate));
		}
	}

	public BigDecimal calculateValueCurrency(String value) {
		if(this.convertionRate==null){
			this.convertionRate = getConversionRate();
		}
		BigDecimal baseAmount = new BigDecimal(value);
		return baseAmount.multiply(convertionRate);
	}

	private BigDecimal getConversionRate() {
		if (exchangeRate.compareTo(Decimal.ZERO) < 1) {
			exchangeRate = new BigDecimal(1);
		}
		if (altExchangeRate.compareTo(Decimal.ZERO) < 0) {
			altExchangeRate = new BigDecimal(1);
		}
		int scale = 20;
		if (altExchangeRate.compareTo(exchangeRate.multiply(new BigDecimal(
				"1000000000"))) == 1) {
			scale = 30;
		} else if (exchangeRate.compareTo(altExchangeRate
				.multiply(new BigDecimal("1000000000"))) == 1) {
			scale = 0;
		}

		return altExchangeRate.divide(exchangeRate, scale,
				BigDecimal.ROUND_HALF_UP);
	}

	public String getPromotionID() {
		return promotionID;
	}

	public void setPromotionID(String promotionID) {
		this.promotionID = promotionID;
	}

	public void setTakeAwayPriority(){
		if(this.takeawayType.equals(TakeAwayConstant.FIX_PRICE)){
			this.priority = 2;
		} else if(this.takeawayType.equals(TakeAwayConstant.FREE_ITEM)){
			this.priority = 3;
		} else if(this.takeawayType.equals(TakeAwayConstant.FREE_SHIPPING)){
			this.priority = 4;
		} else if(this.takeawayType.equals(TakeAwayConstant.PRICE_DISCOUNT)){
			if(this.field.equals(TakeAwayConstant.ORDER_TOTAL)){
				//Set Priority to last
				//Discount per orderheader
				this.priority = 5;
			} else {
				//Set Priority to first
				// Discount per orderline
				this.priority = 1;
			}
		}
	}

	public int compareTo(PromotionTakeAway takeaway) {
		if (this.priority > takeaway.priority){
			return 1;
		} else if (this.priority < takeaway.priority){
				return -1;
		} else {
			return 0;			
		}
	}
	
}
