package com.intentia.iec.pipeline.runtime.stage.custom;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;

/**
 * Inserts a Favorite Category. Used for initializing a Single-User.
 */
public class UpdateFavoriteCategory extends AbstractPipelineStage {
	private static final Logger LOG = Logger.getLogger(UpdateFavoriteCategory.class);
	
	private static final String SQLQUERY = "INSERT INTO FavoriteCategory (userId, categoryId) " 
		+ "SELECT ?, Category.id FROM Category WHERE Category.[key] = ? ";

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.AbstractPipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public void execute(PipelineContext context) throws PipelineRuntimeException {
		if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Request must be of type XMLRequest!");
        }
		
		CustomStagesHelper.extractRequestParameters(CustomStagesHelper.getRequest(context));
		
		XMLRequest request = (XMLRequest) context.getRequest();
		Parameters params = request.getParameters();
		
		Connection conn = null; 
		PreparedStatement stmt = null;
		
		try {
			String userId = params.getString("userID");
			String categoryId = params.getString("categoryId");		

			conn = (Connection) CustomStagesHelper.getConnection("esales.cursor");
			stmt = conn.prepareStatement(SQLQUERY);			

			stmt.setString(1, userId);
			stmt.setString(2, categoryId);
			
			stmt.executeUpdate();
		} catch (Exception e) {
			LOG.error(e);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					LOG.error(e);
				}
				stmt = null;
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					LOG.error(e);
				}
				conn = null;
			}
		}
	}

}
