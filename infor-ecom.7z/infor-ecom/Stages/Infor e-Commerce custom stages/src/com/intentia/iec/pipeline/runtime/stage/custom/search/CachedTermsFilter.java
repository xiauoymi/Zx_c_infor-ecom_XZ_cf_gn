package com.intentia.iec.pipeline.runtime.stage.custom.search;

import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.index.Term;
import org.apache.lucene.search.Filter;
import org.apache.lucene.search.TermsFilter;

/**
 * A wrapper and builder for a Lucene TermsFilter. The wrapping makes the filter
 * cacheable. The filter is build by adding Terms with the addTerm method.
 */
public final class CachedTermsFilter extends FilterBase {
    private List<Term> terms = new ArrayList<Term>();

    /** Construct a new, empty and cacheable filter object. */
    public CachedTermsFilter() {
    }

    /**
     * Construct a new and cacheable filter object initialized with the given
     * term.
     */
    public CachedTermsFilter(Term term) {
        addTerm(term);
    }

    /**
     * Add a Term to the filter.
     * 
     * @param term
     *            the Term to add
     */
    public void addTerm(final Term term) {
        terms.add(term);
    }

    public String createCacheKey() {
        StringBuilder buf = new StringBuilder(100);
        buf.append("TermsFilter{");
        for (int i = 0; i < terms.size(); i++) {
            Term term = terms.get(i);
            buf.append(term.field()).append('=').append(term.text());
            if (i < terms.size() - 1) {
                buf.append(',');
            }
        }
        buf.append('}');
        return buf.toString();
    }

    public Filter createFilter(final DataHolder dataHolder) {
        TermsFilter termsFilter = new TermsFilter();
        for (int i = 0; i < terms.size(); i++) {
            Term term = terms.get(i);
            termsFilter.addTerm(term);
        }
        return termsFilter;
    }
}
