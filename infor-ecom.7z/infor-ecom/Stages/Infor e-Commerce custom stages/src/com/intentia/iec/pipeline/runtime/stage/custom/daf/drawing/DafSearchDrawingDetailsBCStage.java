package com.intentia.iec.pipeline.runtime.stage.custom.daf.drawing;

import com.intentia.icp.common.SearchArgument;
import com.intentia.icp.common.SearchQuery;
import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.pipeline.runtime.PipelineContext;

/**
 * Search for Drawing details. Used in Business Center Drawing Details page.
 *
 */
public class DafSearchDrawingDetailsBCStage extends AbstractDafSearchDrawingStage {
//	private static final Logger LOG = Logger.getLogger(DafSearchDrawingDetailsBCStage.class);
	
	private static final String PARAMETER_ID01 = "@ID01";
	
	private static final String PARAMETER_ID02 = "@ID02";
	
	 /**
	 * Sets the output attributes.
	 */
	public DafSearchDrawingDetailsBCStage() {
		 this.outDrawingNumber = true;
		 this.outItemNumber = true;
		 this.outName = true;
		 this.outID = true;
		 this.outOrgFileName = true;
		 this.outIsDefault = true;
		 this.outStatus = true;
		 this.outIsCheckedOut = true;
		 
		 this.outSerialNumber = true;		 
	 }
	
	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getQuery(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public String getQuery(PipelineContext context) throws ParametersException {
		XMLRequest request = (XMLRequest) context.getRequest();
		StringBuffer buf = new StringBuffer();
		
		Parameters params = request.getParameters();
		String id01 = params.getString(PARAMETER_ID01);
		String id02 = params.getString(PARAMETER_ID02);

		// search for id01 OR id02
		appendQuery(buf, DafDrawingConstants.COLUMN_ITEMID, SearchArgument.SEARCH_OP_EQUAL, id01);
		appendQuery(buf, DafDrawingConstants.COLUMN_ITEMID, SearchArgument.SEARCH_OP_EQUAL, id02, SearchQuery.SEARCH_TYPE_OR);
		
		return DafDrawingConstants.TABLE + "["+ buf.toString() + "]";
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getResultSize()
	 * expect 1
	 */
	@Override
	public int getResultSize() {
		return 1;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getStartIndex()
	 * start from 0
	 */
	@Override
	public int getStartIndex() {
		return 0;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#setOutputParameters(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public void setOutputParameters(PipelineContext context) {
		// intentionally blank
	}
}
