package com.intentia.iec.pipeline.runtime.stage.custom.ia;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.transform.TransformerException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.ia.dao.IaDao;
import com.intentia.iec.pipeline.runtime.integration.ia.dao.impl.IaDaoRpImpl;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaConnectionException;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.ia.model.IaCampaign;
import com.intentia.iec.pipeline.runtime.integration.ia.utils.IaConfig;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

public class GetIaCampaignScoreStage extends AbstractPipelineStage {

	private static final Logger log = Logger
			.getLogger(GetIaCampaignScoreStage.class);

	private static final String DEFAULT_EVENT = "RecommendCampaigns";
	private static final String DEFAULT_USER_ID = "0";
	private static final String DEFAULT_USERGROUP_ID = "0";
	private static final String DEFAULT_MAX_RECORD = "5";

	public static final String CAMPAIGN_SCORE = "IaCampaignScore";

	@SuppressWarnings("unchecked")
	@Override
	public void execute(PipelineContext context)
			throws PipelineRuntimeException {
		log.debug("Executing GetIaCampaignScoreStage.execute()...");
		try {
			CustomStagesHelper.extractRequestParameters(CustomStagesHelper
					.getRequest(context));
			XMLRequest request = (XMLRequest) context.getRequest();
			Parameters requestParams = request.getParameters();

			Set<String> validCampaignIds = getValidCampaignIds(requestParams);

			if (!validCampaignIds.isEmpty()) {
				List<IaCampaign> campaignScores = retrieveCampaignScores(
						validCampaignIds, requestParams);

				if (campaignScores != null && !campaignScores.isEmpty()) {
					request = addCampaignIdBindings(campaignScores, request);
					context.setRequest(request);
					context.put(CAMPAIGN_SCORE, campaignScores);
				} else {
					log.debug("Campaign Scores From IA is NULL.");
				}
			}
		} catch (Exception e) {
			log.error(
					"Error while retrieving IA campaign scores. No IA score will be applied.",
					e);
		}
	}

	private Set<String> getValidCampaignIds(Parameters requestParams)
			throws PipelineRuntimeException {
		Set<String> validCampaignIds = new HashSet<String>();
		try {
			// Execute BO method
			SearchPipelineExecuter pipeline = new SearchPipelineExecuter(
					ConstantsForSales.PIPELINE_PACKAGE, "Campaign",
					"ListValidCampaignIds");

			// Add request parameters
			Set<?> paramNames = requestParams.getParameterNames();
			for (Object param : paramNames) {
				String paramName = (String) param;
				pipeline.setParam(paramName, requestParams.getString(paramName));
			}

			XMLResultset result = pipeline.execute();

			if (result != null && !result.isEmpty()) {
				result.beforeFirst();
				while (result.moveNext()) {
					String id = result.getString("CampaignID");
					if (id != null && !"".equals(id)) {
						validCampaignIds.add(id);
					}
				}
			}

		} catch (PipelineRuntimeException e) {
			throw new PipelineRuntimeException(
					"Error while retrieving valid capaign IDs.", e);
		} catch (ParametersException e) {
			throw new PipelineRuntimeException(
					"Error while retrieving valid capaign IDs.", e);
		} catch (ResultsetException e) {
			throw new PipelineRuntimeException(
					"Error while retrieving valid capaign IDs.", e);
		}

		log.debug("List of valid campaign IDs: " + validCampaignIds);
		return validCampaignIds;
	}

	private List<IaCampaign> retrieveCampaignScores(
			Set<String> validCampaignIds, Parameters requestParams)
			throws PipelineRuntimeException, ParametersException {
		List<IaCampaign> result = new ArrayList<IaCampaign>();
		try {
			Map<String, String> params = new HashMap<String, String>();

			// TODO: Create parameter mapping...

			params.put("CampaignIds", StringUtils.join(validCampaignIds
					.toArray(), IaConfig.getInstance().getDataDelimiter()));
			params.put(
					"SessionId",
					StringUtils.defaultIfEmpty(
							requestParams.getString("SessionId"),
							requestParams
									.getString(ConstantsForSales.USER_ID_PARAM)
									+ "_"
									+ requestParams
											.getString(ConstantsForSales._USERGROUPID_PARAM)));
			params.put("UserId", StringUtils.defaultIfEmpty(
					requestParams.getString(ConstantsForSales.USER_ID_PARAM),
					DEFAULT_USER_ID));
			params.put("GroupId", StringUtils.defaultIfEmpty(requestParams
					.getString(ConstantsForSales._USERGROUPID_PARAM),
					DEFAULT_USERGROUP_ID));
			params.put("RecommendationsCount", StringUtils.defaultIfEmpty(
					requestParams.getString("MaxRecordParam"),
					DEFAULT_MAX_RECORD));
			params.put(
					"CurrentPageId",
					StringUtils.defaultIfEmpty(
							requestParams.getString("CurrentPageId"), ""));
			params.put("ItemCategoryIdsInCart", StringUtils.defaultIfEmpty(
					requestParams.getString("ItemCategoryIdsInCart"), ""));
			params.put("ViewedItemCategoryIds", StringUtils.defaultIfEmpty(
					requestParams.getString("ViewedItemCategoryIds"), ""));
			params.put("SearchedItemCategoryIds", StringUtils.defaultIfEmpty(
					requestParams.getString("SearchedItemCategoryIds"), ""));

			IaDao dao;
			dao = new IaDaoRpImpl();
			result = dao.getCampaigns(
					StringUtils.defaultString(
							requestParams.getString("IaEvent"), DEFAULT_EVENT),
					params);

			if (result != null) {
				log.debug("IA Campaign Scores: " + result.toString());
			} else {
				log.debug("IA Campaign Scores: NULL.");
			}
		} catch (IaConnectionException e) {
			log.error(
					"Error while connecting to IA server. Ignoring IA score.",
					e);
		} catch (IaRuntimeException e) {
			log.error(
					"Error while retrieving campaign scores from the IA server. Ignoring IA score.",
					e);
		}

		return result;
	}

	private XMLRequest addCampaignIdBindings(List<IaCampaign> campaigns,
			XMLRequest request) throws RequestException,
			PipelineRuntimeException {

		try {
			Document requestDoc = request.getRequestDoc();
			Node searchNode = XPathAPI.selectSingleNode(requestDoc,
					"/request/search");

			if (searchNode != null) {
				Element bindingsNode = requestDoc.createElement("bindings");
				bindingsNode.setAttribute("operator", "or");

				for (IaCampaign campaign : campaigns) {
					Element bindingNode = requestDoc.createElement("binding");
					bindingNode.setAttribute("attribute", "CampaignID");
					bindingNode.setAttribute("value", campaign.getId());
					bindingNode.setAttribute("operator", "eq");
					bindingsNode.appendChild(bindingNode);
				}
				searchNode.appendChild(bindingsNode);
			}

		} catch (TransformerException e) {
			throw new PipelineRuntimeException(
					"Error while setting campaign Id bindings.");
		}

		log.debug("XMLRequest with CampaignID bindings:" + request);
		return request;
	}

	private XMLResultset getEmptyResponse() {
		StringBuilder responseStr = new StringBuilder();
		responseStr.append(ConstantsForSales.XML_DATA_HEADER);
		responseStr.append("<resultset object=\"Campaign\">");
		responseStr.append("</resultset>");
		return new XMLResultset(responseStr.toString());
	}

}
