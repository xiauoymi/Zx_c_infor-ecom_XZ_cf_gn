/*
 * Created on 26-04-2006
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.xml.sax.SAXException;

import com.intentia.icp.common.CMException;
import com.intentia.icp.common.CMItem;
import com.intentia.icp.common.CMItems;
import com.intentia.icp.common.CMResource;
import com.intentia.icp.common.CMResources;
import com.intentia.icp.common.Connection;
import com.intentia.icp.common.ConnectionPool;
import com.intentia.icp.common.HelperXML;
import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.util.FastStringBuffer;
import com.intentia.mds.config.Connections;
import com.intentia.pcm.common.Article;
import com.intentia.pcm.common.CatalogException;
import com.intentia.pcm.common.Product;
import com.intentia.pcm.config.Configuration;

/**
 * The <code>PIMDocuments</code> stage handles retrieval of related documents
 * for items and products from a PCM server.
 * 
 * This stage is configured by an application property called
 * PIM.Document.Entities.
 * 
 * The property contains a ;-separated list of business objects that support
 * related docs. Each object is specified as
 * <code>BO:EntityKey,EntityType[,ParentEntityKey,ParentEntityType]</code>,<br />
 * where BO is the name of the object,<br />
 * EntityKey is the name of the attribute containing the ID value for use in
 * PCM, and <br />
 * EntityType is the name of the attribute containing the entity type for use in
 * PCM.
 * 
 * For items the two following fields should also be configured:<br />
 * ParentEntityKey is the name of the attribute containing the ID value of the
 * parent product.<br />
 * ParentEntityType is the name of the attribute containing the entitty type for
 * the parent product
 */

public class PIMDocuments extends AbstractPipelineStage {

    private static final String CONFIG_FILE = "/pim-config.xml";

    private static final String CONNECTIONS_FILE = "/pim-connections.xml";

    private static final String CONFIG_KEY_ENTITIES = "PIM.Document.Entities";

    private static final int ITEM_CFG_SIZE = 4;

    private static final int PRODUCT_CFG_SIZE = 2;

    private static final Logger LOG = Logger.getLogger(PIMDocuments.class);

    private static Configuration config = null;

    private static ConnectionPool pool = null;

    private static Map entityTypes = null;

    /*
     * (non-Javadoc)
     * 
     * @see com.intentia.iec.pipeline.runtime.AbstractPipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
     */
    public final void execute(final PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("Inside PIMDocuments.execute()");

        if (null == entityTypes) {
            initialize();
        }

        if (!(context.getResponse() instanceof XMLResultset)) {
            throw new PipelineRuntimeException("Request must be of type 'XMLResultset'!");
        }
        XMLResultset response = (XMLResultset) context.getResponse();

        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Request must be of type 'XMLRequest'!");
        }
        XMLRequest xmlRequest = (XMLRequest) context.getRequest();
        try {
            XMLRequest.extractRequestParameters(xmlRequest);
        } catch (RequestException e) {
            throw new PipelineRuntimeException("Error parsing request parameters.");
        }

        Parameters params = xmlRequest.getParameters();

        String role = null;
        try {
            role = params.getString("Role");
        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Error reading parameter values", e);
        }
        if (null == role) {
            throw new PipelineRuntimeException("Role must be specified.");
        }

        final String[] attributeNames = (String[]) entityTypes.get(context.getObjectName());
        if (null == attributeNames) {
            throw new PipelineRuntimeException("No mapping defined for entity.");
        }

        getDocuments(response, role, attributeNames);
    }

    /*
     * Synchronized to avoid multiple initializations
     */
    private static synchronized void initialize() throws PipelineRuntimeException {
        LOG.debug("Initialize");

        if (null != entityTypes) {
            return; // already initialized, so just return
        }

        // Read entity key mapping
        String entityMap = CustomStagesHelper.getKeyValue(CONFIG_KEY_ENTITIES);
        if (null == entityMap) {
            FastStringBuffer msg = new FastStringBuffer(100);
            msg.append("Missing application property: ").append(CONFIG_KEY_ENTITIES);
            throw new PipelineRuntimeException(msg.toString());
        }

        String[] entities = entityMap.split(";");
        Map map = new HashMap();
        for (int i = 0; i < entities.length; i++) {
            String[] entity = entities[i].split(":");
            if (2 != entity.length) {
                FastStringBuffer msg = new FastStringBuffer(100);
                msg.append("Illegal entity mapping: ").append(entities[i]);
                throw new PipelineRuntimeException(msg.toString());
            }
            String[] fields = entity[1].split(",");
            if (ITEM_CFG_SIZE != fields.length && PRODUCT_CFG_SIZE != fields.length) {
                FastStringBuffer msg = new FastStringBuffer(100);
                msg.append("Illegal entity definition: ").append(entity[1]);
                throw new PipelineRuntimeException(msg.toString());
            }
            map.put(entity[0], fields);
        }

        // Read server configuration
        URL configURL = PIMDocuments.class.getResource(CONFIG_FILE);
        if (null == configURL) {
            throw new PipelineRuntimeException("Could not find configuration file.");
        }
        try {
            config = new Configuration(HelperXML.parseDocument(HelperXML.getFile(configURL.getFile())));
        } catch (CatalogException e) {
            throw new PipelineRuntimeException("Configuration error.", e);
        } catch (IOException e) {
            throw new PipelineRuntimeException("Unable to read configuration file.", e);
        } catch (CMException e) {
            throw new PipelineRuntimeException("Configuration error.", e);
        } catch (SAXException e) {
            throw new PipelineRuntimeException("Unable to parse configuration file.", e);
        } catch (TransformerException e) {
        	 throw new PipelineRuntimeException("Unable to parse configuration file.", e);
		}

        // Read server connection defintions
        URL connectionsURL = PIMDocuments.class.getResource(CONNECTIONS_FILE);
        if (null == connectionsURL) {
            throw new PipelineRuntimeException("Could not find connections file.");
        }
        try {
            pool = new ConnectionPool(new Connections(connectionsURL.getFile()).getConnections());
        } catch (IOException e) {
            throw new PipelineRuntimeException("Unable to read connections file.", e);
        } catch (CMException e) {
            throw new PipelineRuntimeException("Connection error.", e);
        } catch (SAXException e) {
            throw new PipelineRuntimeException("Unable to parse connections file.", e);
        }

        // Use cp.init(50, 30, 60, 90); to not disable maintenance threads
        pool.init((short) 50, (short) 0, (short) 0, (short) 0);

        // Initialize as last thing, because this variable is used to check
        // wether initialization has completed successfully
        entityTypes = map;
    }

    /*
     * The attributeNames array contains the two or four attribute names in the
     * application property, as discussed in the comment at the head of this
     * file.
     */
    private void getDocuments(final XMLResultset response, final String role, final String[] attributeNames)
            throws PipelineRuntimeException {

        LOG.debug("Getting connection to CM");
        Connection conn = null;
        try {
            conn = pool.checkOut(role, null);
            if (conn.validateConnection() != 0) {
                LOG.debug("Uh oh, lost connection - trying to reconnect");
                conn.disconnectSilent();
                conn.connectNoReturn();
            }
        } catch (CMException e) {
            throw new PipelineRuntimeException("Unable to connect.", e);
        }

        try {
            for (response.beforeFirst(); response.hasNext();) {
                response.moveNext();

                CMItems items;
                final String entityID = response.getString(attributeNames[0]);
                final String entityType = response.getString(attributeNames[1]);
                if (PRODUCT_CFG_SIZE == attributeNames.length) {
                    if (LOG.isDebugEnabled()) {
                        LOG.debug("Searching for documents on product " + entityID);
                    }
                    items = Product.getRelatedDocuments(conn, config, entityType, entityID);
                } else {
                    final String parentID = response.getString(attributeNames[2]);
                    final String parentType = response.getString(attributeNames[3]);
                    if (LOG.isDebugEnabled()) {
                        FastStringBuffer tmp = new FastStringBuffer(100);
                        tmp.append("Searching for documents on item ").append(entityID);
                        tmp.append(", parent product ").append(parentID);
                        LOG.debug(tmp.toString());
                    }
                    items = Article.getRelatedDocuments(conn, config, entityType, entityID, parentType, parentID);
                }

                if (null != items) {
                    LOG.debug("Building response");
                    XMLIterator subset = (XMLIterator) response.appendResultset("RelatedDocument");
                    for (Iterator it = items.iterator(); it.hasNext();) {
                        CMResources resrs = ((CMItem) it.next()).getResources();
                        if (null != resrs && resrs.size() > 0) {
                            CMResource res = resrs.get(0); // We only support
                            // one resource for
                            // a related
                            // document
                            String mimeType = res.getMimeType();
                            URL url = res.getUrl();
                            String fileName = res.getOrgFileName();
                            subset.appendRow();
                            if (null != url) {
                                subset.appendField("URL", url.toString());
                            }
                            if (null != mimeType) {
                                subset.appendField("MimeType", mimeType);
                            }
                            if (null != fileName) {
                                subset.appendField("FileName", fileName);
                            }
                            if (LOG.isDebugEnabled()) {
                                FastStringBuffer log = new FastStringBuffer(200);
                                log.append("Document: ");
                                log.append("URL = ").append(url.toString());
                                log.append(", MimeType = ").append(mimeType);
                                log.append(", FileName = ").append(fileName);
                                LOG.debug(log.toString());
                            }
                        } else {
                            LOG.debug("Empty resource.");
                        }
                    }
                }
            }
        } catch (CMException e) {
            throw new PipelineRuntimeException("Error.", e);
        } catch (CatalogException e) {
            throw new PipelineRuntimeException("Error.", e);
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Error handling response.", e);
        } finally {
            pool.checkIn(role, null, conn);
        }

        response.beforeFirst();
    }
}
