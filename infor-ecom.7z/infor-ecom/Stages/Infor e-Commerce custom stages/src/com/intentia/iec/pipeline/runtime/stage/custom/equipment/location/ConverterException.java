package com.intentia.iec.pipeline.runtime.stage.custom.equipment.location;

/**
 * Exception generated during coordinate system conversion
 *
 */
public class ConverterException extends Exception {
    private static final long serialVersionUID = 7076097884377976161L;

    /**
     * @param message
     */
    public ConverterException(String message) {
        super(message);
    }

    /**
     * @param message
     * @param cause
     */
    public ConverterException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @param cause
     */
    public ConverterException(Throwable cause) {
        super(cause);
    }
}
