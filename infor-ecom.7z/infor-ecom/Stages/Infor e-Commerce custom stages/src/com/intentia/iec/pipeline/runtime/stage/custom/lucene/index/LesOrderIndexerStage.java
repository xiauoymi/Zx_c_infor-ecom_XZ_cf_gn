package com.intentia.iec.pipeline.runtime.stage.custom.lucene.index;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.lucene.document.Document;

import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.lucene.manager.ResultsetDocumentHandler;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

/**
 * 
 * @author 15062
 * 
 */
public final class LesOrderIndexerStage extends AbstractIndexerStage {

    private static final String INDEX_NAME = "LesOrder";

    private static final String BO_NAME = "CurrentOrder";

    private static final String BO_METHOD_NAME = "GetOrdersForLesOrderIndex";

    private static final String KEY_ATTRIBUTE_NAME = ConstantsForSales.ORDERID;

    protected String getIndexName() {
        return INDEX_NAME;
    }

    protected String getKeyAttributeName() {
        return KEY_ATTRIBUTE_NAME;
    }

    protected String getBOName() {
        return BO_NAME;
    }

    protected String getBOMethodName() {
        return BO_METHOD_NAME;
    }

    protected void setAdditionalRequestParameters(SearchPipelineExecuter pipeline) {
        // TODO: Add parameters here (if needed)
    }

    protected void setAdditionalRequestBindings(SearchPipelineExecuter pipeline) {
        pipeline.setBinding(ConstantsForSales.ORDERSTATUS, "dra", "eq");
        pipeline.setBinding(ConstantsForSales.ORDERSTATUS, "sta", "eq");
        pipeline.setBinding(ConstantsForSales.ORDERSTATUS, "ofa", "eq");
        pipeline.setBinding(ConstantsForSales.ORDERSTATUS, "rfq", "eq");
        // TODO: Add more parameters here (if needed)
    }

    protected void addMoreFields(Map<String, Document> docMap) throws PipelineRuntimeException {
        Iterator<String> it = docMap.keySet().iterator();
        while (it.hasNext()) {
            String key = it.next();
            Document doc = docMap.get(key);
            addLocalizedItemNameAndDescription(doc);
            addLocalizedStatus(doc);
            addLocalizedCountryName(doc);
        }
    }

    private void addLocalizedItemNameAndDescription(Document doc) throws PipelineRuntimeException {
        String[] itemIDs = doc.getValues(ConstantsForSales.ITEM_ID_FIELD);
        if (itemIDs != null && itemIDs.length > 0) {
            SearchPipelineExecuter pipeline = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "Item",
                    "GetNameDescriptionForLesOrderIndex", SearchPipelineExecuter.OR);
            for (int i = 0; i < itemIDs.length; i++) {
                pipeline.setBinding(ConstantsForSales.ITEMID, itemIDs[i], "eq");
            }
            XMLResultset itemDetails = pipeline.execute();

            ResultsetDocumentHandler handler = new ResultsetDocumentHandler(doc, _indexManager, KEY_ATTRIBUTE_NAME);
            parseXMLResultset(itemDetails, handler);
        }
    }

    private void addLocalizedStatus(Document doc) throws PipelineRuntimeException {
        Map<String, String> statusMap = new HashMap<String, String>();
        statusMap.put("Ostatus", ConstantsForSales.ORDER_STATUS_FIELD);
        statusMap.put("ApproveStatus", ConstantsForSales.APPROVE_STATUS_FIELD);
        statusMap.put("RFQStatus", ConstantsForSales.RFQ_STATUS_FIELD);

        Iterator<String> it = statusMap.keySet().iterator();
        while (it.hasNext()) {
            String codeType = it.next();
            String fieldName = statusMap.get(codeType);

            String[] orderStatus = doc.getValues(fieldName);
            if (orderStatus != null && orderStatus.length > 0) {
                SearchPipelineExecuter pipeline = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                        "Code", "Details");
                for (int i = 0; i < orderStatus.length; i++) {
                    pipeline.setParam("CodeIDURL", orderStatus[i] + codeType);
                }
                XMLResultset rolesDetails = pipeline.execute();

                ResultsetDocumentHandler handler = new ResultsetDocumentHandler(doc, _indexManager, KEY_ATTRIBUTE_NAME);
                parseXMLResultset(rolesDetails, handler);
            }
        }
    }

    private void addLocalizedCountryName(Document doc) throws PipelineRuntimeException {
        String[] countryIDs = doc.getValues(ConstantsForSales.COUNTRY_ID_FIELD);
        if (countryIDs != null && countryIDs.length > 0) {
            SearchPipelineExecuter pipeline = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "Country",
                    "GetDetailsForIndex", SearchPipelineExecuter.OR);
            for (int i = 0; i < countryIDs.length; i++) {
                pipeline.setBinding(ConstantsForSales.COUNTRY_ID_ATTRIBUTE, countryIDs[i], "eq");
            }
            XMLResultset countryDetails = pipeline.execute();

            ResultsetDocumentHandler handler = new ResultsetDocumentHandler(doc, _indexManager, KEY_ATTRIBUTE_NAME);
            parseXMLResultset(countryDetails, handler);
        }
    }

}