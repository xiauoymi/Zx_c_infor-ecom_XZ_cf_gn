package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.Resultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.custom.validator.ValidatorUtil;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

public class GatewayOrderEntryValidator implements PipelineStage {
    private static final Logger LOG = Logger.getLogger(GatewayOrderEntryValidator.class);

    private static final String PARAM_A_USERGROUPID = "@UserGroupID";

    private static final String PARAM_A_USERID = "@UserID";

    private static final String PARAM_LANGUAGECODE = "@LanguageCode";

    private static final String PARAM_M3WAREHOUSE = "@MvxWarehouse";

    private static final String PARAM_A_CURRENCYCODE = "@CurrencyCode";

    private static final String PARAM_VALIDATESTRING = "ValidateString";

    private static final String PARAM_TRUNCATERULES = "TruncateRules";

    private static final String PARAM_A_LISTPRICEGROUP = "@ListPriceGroup";

    private static final String ATTR_PAYMENTMETHODID = "PaymentMethodID";

    private static final String ATTR_SHIPPINGMETHOD = "ShippingMethodID";

    private static final String ATTR_SHIPPINGCTRYID = "ShippingCountryID";

    // private static final String ATTR_SHIPPINGSTATENAME = "ShippingStateName";
    private static final String ATTR_SHIPPINGSTATEID = "ShippingStateID";

    private static final String ATTR_METHODNAME = "MethodName";

    private static final String ATTR_CATEGORYID = "CategoryID";

    private static final String ATTR_ISACTIVE = "IsActive";

    private static final String ATTR_COUNTRYID = "CountryID";

    private static final String ATTR_STATE = "State";

    private static final String ATTR_STATEID = "StateID";

    // private static final String ATTR_ISVISIBLE = "IsVisible";
    private static final String ATTR_HASSUBITEMS = "HasSubItems";

    private static final String ATTR_NAME = "Name";

    private static final String ATTR_ITEMID = "ItemID";

    public void execute(PipelineContext pipelinecontext) throws PipelineRuntimeException {

        try {
            XMLRequest.extractRequestParameters((XMLRequest) pipelinecontext.getRequest());
            // Validation
            validateRequest(pipelinecontext);
            cleanUpRequest(pipelinecontext);
            validateResolveShippingMethod(pipelinecontext);
            validateResolvePaymentMethod(pipelinecontext);
            validateState(pipelinecontext);
            validateItems(pipelinecontext);
            // TODO: Add other validations needed
        } catch (PipelineRuntimeException e) {
            LOG.debug(e.getMessage());
            throw e;
        } catch (Exception e) {
            LOG.debug(e.getMessage());
            throw new PipelineRuntimeException(e);
        }
    }

    /**
     * Do some basic validation of the request
     * 
     * @param pipelinecontext
     * @throws PipelineRuntimeException
     */
    private void validateRequest(PipelineContext pipelinecontext) throws PipelineRuntimeException {

        XMLRequest request = (XMLRequest) pipelinecontext.getRequest();
        final Parameters params = CustomStagesHelper.getRequestParameters(pipelinecontext);
        try {

            String validateString = params.getString(PARAM_VALIDATESTRING);
            if (null == validateString || "".equals(validateString)) {
                return;
            }
            // Required field validation
            org.w3c.dom.Document xmlDoc = request.getRequestDoc();

            ArrayList<Map<String, String>> rules = ValidatorUtil.parse(validateString);
            for (Map<String, String> rule : rules) {
                String attribute = rule.get(ValidatorUtil.KEY_ATTRIBUTE);
                String subsetName = rule.get(ValidatorUtil.KEY_SUBSETNAME);
                String type = rule.get(ValidatorUtil.KEY_TYPE);
                if (null != subsetName && !"".equals(subsetName)) {
                    // validate subset
                    NodeList subsets = XPathAPI.selectNodeList(xmlDoc,
                            "request/entities/entity/subsets/subset[@name=\"" + subsetName + "\"]");

                    for (int i = 0; i < subsets.getLength(); i++) {
                        Node ndS = subsets.item(i);
                        Node nd = XPathAPI.selectSingleNode(ndS, "attributes/attribute[@name=\"" + attribute + "\"]");
                        String value = nd == null ? null : nd.getChildNodes().item(0) == null ? null : nd
                                .getChildNodes().item(0).getNodeValue().trim();
                        validateValue(rule, type, value);
                    }
                } else {
                    Node nd = XPathAPI.selectSingleNode(xmlDoc, "request/entities/entity/attributes/attribute[@name=\""
                            + attribute + "\"]");
                    String value = nd == null ? null : nd.getChildNodes().item(0) == null ? null : nd.getChildNodes()
                            .item(0).getNodeValue().trim();
                    validateValue(rule, type, value);
                }
            }
        } catch (PipelineRuntimeException e) {
            LOG.debug("BEFORE " + e.getMessage());
            throw e;
        } catch (Exception e) {
            LOG.debug("BEFORE PipelineRuntimeException " + e.getMessage());
            throw new PipelineRuntimeException(e);
        }
    }

    /**
     * do some clean up of the request
     * 
     * @param pipelinecontext
     * @throws PipelineRuntimeException
     */
    private void cleanUpRequest(PipelineContext pipelinecontext) throws PipelineRuntimeException {
        XMLRequest request = (XMLRequest) pipelinecontext.getRequest();
        final Parameters params = CustomStagesHelper.getRequestParameters(pipelinecontext);
        try {
            String validateString = params.getString(PARAM_TRUNCATERULES);
            if (null == validateString || "".equals(validateString)) {
                return;
            }

            org.w3c.dom.Document xmlDoc = request.getRequestDoc();

            ArrayList<Map<String, String>> rules = ValidatorUtil.parse(validateString);
            for (Map<String, String> rule : rules) {
                String attribute = rule.get(ValidatorUtil.KEY_ATTRIBUTE);
                String subsetName = rule.get(ValidatorUtil.KEY_SUBSETNAME);
                String type = rule.get(ValidatorUtil.KEY_TYPE);
                if (null != subsetName && !"".equals(subsetName)) {
                    // validate subset
                    NodeList subsets = XPathAPI.selectNodeList(xmlDoc,
                            "request/entities/entity/subsets/subset[@name=\"" + subsetName + "\"]");

                    for (int i = 0; i < subsets.getLength(); i++) {
                        Node ndS = subsets.item(i);
                        Node nd = XPathAPI.selectSingleNode(ndS, "attributes/attribute[@name=\"" + attribute + "\"]");
                        String value = nd == null ? null : nd.getChildNodes().item(0) == null ? null : nd
                                .getChildNodes().item(0).getNodeValue().trim();

                        truncateValue(rule, type, nd, value);
                    }
                } else {
                    Node nd = XPathAPI.selectSingleNode(xmlDoc, "request/entities/entity/attributes/attribute[@name=\""
                            + attribute + "\"]");
                    String value = nd == null ? null : nd.getChildNodes().item(0) == null ? null : nd.getChildNodes()
                            .item(0).getNodeValue().trim();

                    truncateValue(rule, type, nd, value);
                }
            }
        } catch (Exception e) {
            LOG.debug("BEFORE PipelineRuntimeException " + e.getMessage());
            throw new PipelineRuntimeException(e);
        }
    }

    /**
     * Do truncation of values
     * 
     * @param rule
     * @param type
     * @param nd
     * @param value
     * @throws Exception
     */
    private void truncateValue(Map<String, String> rule, String type, Node nd, String value) throws Exception {
        if (ValidatorUtil.TYPE_STRING.equals(type)) {
            String newVal = ValidatorUtil.truncateRule(rule.get(ValidatorUtil.KEY_VALIDATIONRULE), value, rule
                    .get(ValidatorUtil.KEY_MAX));
            if (null != value) {
                nd.getFirstChild().setNodeValue(newVal);
            }
        }
    }

    /**
     * Do basic validation
     * 
     * @param rule
     * @param type
     * @param value
     * @throws Exception
     */
    private void validateValue(Map<String, String> rule, String type, String value) throws Exception {
        try {
            if (ValidatorUtil.TYPE_STRING.equals(type)) {
                ValidatorUtil.validateString(rule.get(ValidatorUtil.KEY_VALIDATIONRULE), value, rule
                        .get(ValidatorUtil.KEY_MAX));
            }
            if (ValidatorUtil.TYPE_NUMBER.equals(type)) {
                ValidatorUtil.validateNumber(rule.get(ValidatorUtil.KEY_VALIDATIONRULE), value, new BigDecimal(rule
                        .get(ValidatorUtil.KEY_MIN)), new BigDecimal(rule.get(ValidatorUtil.KEY_MAX)));
            }
            if (ValidatorUtil.TYPE_DATE.equals(type)) {
                ValidatorUtil.validateDate(rule.get(ValidatorUtil.KEY_VALIDATIONRULE), value, rule
                        .get(ValidatorUtil.KEY_FORMAT));
            }
        } catch (Exception e) {
            throw new PipelineRuntimeException("Validation failed on: " + rule.get(ValidatorUtil.KEY_ATTRIBUTE) + " "
                    + e.getMessage());
        }
    }

    /**
     * Validate payment method
     * 
     * @param pipelinecontext
     * @throws PipelineRuntimeException
     */
    private void validateResolvePaymentMethod(PipelineContext pipelinecontext) throws PipelineRuntimeException {
        try {
            final Parameters params = CustomStagesHelper.getRequestParameters(pipelinecontext);
            XMLRequest request = (XMLRequest) pipelinecontext.getRequest();
            org.w3c.dom.Document xmlDoc = request.getRequestDoc();
            Node nd = XPathAPI.selectSingleNode(xmlDoc, "request/entities/entity/attributes/attribute[@name='"
                    + ATTR_PAYMENTMETHODID + "']");
            String paymentMethodText = nd.getFirstChild().getNodeValue();
            SearchPipelineExecuter paymentMethodSearch = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                    "PaymentMethod", "List");
            paymentMethodSearch.setParam(PARAM_LANGUAGECODE, paramGetString(params, PARAM_LANGUAGECODE));
            paymentMethodSearch.setBinding(ATTR_METHODNAME, paymentMethodText, "eq");
            Resultset rs = paymentMethodSearch.execute();
            rs.moveFirst();
            if (rs.rowCount() == 0) {
                throw new PipelineRuntimeException("Supplied Payment method does not exists in db");
            }
            String methodID = rs.getString("MethodID");
            LOG.debug("Payment method id: " + methodID);
            nd.getFirstChild().setNodeValue(methodID);
            LOG.debug("Payment method changes: " + request.getRequestString());
        } catch (Exception e) {
            LOG.debug("Before PipelineRuntimeException", e);
            throw new PipelineRuntimeException(e);
        }

    }

    /**
     * Validate shipping method
     * 
     * @param pipelinecontext
     * @throws PipelineRuntimeException
     */
    private void validateResolveShippingMethod(PipelineContext pipelinecontext) throws PipelineRuntimeException {

        try {
            XMLRequest request = (XMLRequest) pipelinecontext.getRequest();
            org.w3c.dom.Document xmlDoc = request.getRequestDoc();
            Node nd = XPathAPI.selectSingleNode(xmlDoc, "request/entities/entity/attributes/attribute[@name='"
                    + ATTR_SHIPPINGMETHOD + "']");
            String deliveryMethodText = nd.getFirstChild().getNodeValue();
            SearchPipelineExecuter shippingSearch = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                    "ShippingMethod", "List");
            // shippingSearch.setBinding(ATTR_NAME, deliveryMethodText, "eq");
            shippingSearch.setBinding(ATTR_SHIPPINGMETHOD, deliveryMethodText, "eq");
            Resultset rs = shippingSearch.execute();
            rs.moveFirst();
            if (rs.rowCount() == 0) {
                throw new PipelineRuntimeException("Supplied shipping method does not exists in db");
            }
            // String methodID = rs.getString(ATTR_SHIPPINGMETHOD);
            // LOG.debug("Shipping method id: " + methodID);
            // nd.getFirstChild().setNodeValue(methodID);
            // LOG.debug("Shipping method changes: " +
            // request.getRequestString());
        } catch (Exception e) {
            LOG.debug("Before PipelineRuntimeException", e);
            throw new PipelineRuntimeException(e);
        }
    }

    /**
     * Validate items
     * 
     * @param pipelinecontext
     * @throws PipelineRuntimeException
     */
    private void validateItems(PipelineContext pipelinecontext) throws PipelineRuntimeException {
        try {
            final Parameters params = CustomStagesHelper.getRequestParameters(pipelinecontext);
            XMLRequest request = (XMLRequest) pipelinecontext.getRequest();
            XMLRequestHelper xmlHelper = new XMLRequestHelper(request);
            org.w3c.dom.Document xmlDoc = request.getRequestDoc();
            NodeList nds = XPathAPI.selectNodeList(xmlDoc, "request/entities/entity/subsets/subset[@name='"
                    + "OrderLine" + "']");
            for (int i = 0; i < nds.getLength(); i++) {
                Node nd = nds.item(i);
                String itemID = xmlHelper.getAttribute(nd, ATTR_ITEMID);
                // TODO: warning on this. find another way.
                // Check item validity
                SearchPipelineExecuter itemSearchSimple = new SearchPipelineExecuter(
                        ConstantsForSales.PIPELINE_PACKAGE, "Item", "GetSimple");
                itemSearchSimple.setBinding(ATTR_ITEMID, itemID, "eq");
                itemSearchSimple.setParam(PARAM_A_CURRENCYCODE, paramGetString(params, PARAM_A_CURRENCYCODE));
                itemSearchSimple.setParam(PARAM_A_LISTPRICEGROUP, paramGetString(params, PARAM_A_LISTPRICEGROUP));
                Resultset rs = itemSearchSimple.execute();
                if (rs.rowCount() == 0) {
                    rs = null;
                    throw new PipelineRuntimeException("This item is invalid: " + itemID);
                }
                rs = null;
                // Check item agaisnt user profile
                SearchPipelineExecuter itemSearch = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                        "Item", "GetItemForCustomer");
                itemSearch.setBinding(ATTR_ITEMID, itemID, "eq");
                String param = paramGetString(params, ATTR_CATEGORYID);
                if (null != param && !"".equals(param)) {
                    itemSearch.setBinding(ATTR_CATEGORYID, param, "eq");
                }
                param = paramGetString(params, ATTR_ISACTIVE);
                if (null != param && !"".equals(param)) {
                    itemSearch.setBinding(ATTR_ISACTIVE, param, "eq");
                }
                // param = paramGetString(params, ATTR_ISVISIBLE);
                // if(null != param && !"".equals(param)){
                // itemSearch.setBinding(ATTR_ISVISIBLE, param, "eq");
                // }
                param = paramGetString(params, ATTR_HASSUBITEMS);
                if (null != param && !"".equals(param)) {
                    itemSearch.setBinding(ATTR_HASSUBITEMS, param, "eq");
                }
                itemSearch.setParam(PARAM_A_CURRENCYCODE, paramGetString(params, PARAM_A_CURRENCYCODE));
                itemSearch.setParam(PARAM_A_LISTPRICEGROUP, paramGetString(params, PARAM_A_LISTPRICEGROUP));
                itemSearch.setParam(PARAM_LANGUAGECODE, paramGetString(params, PARAM_LANGUAGECODE));
                itemSearch.setParam(PARAM_M3WAREHOUSE, paramGetString(params, PARAM_M3WAREHOUSE));
                itemSearch.setParam(PARAM_A_USERGROUPID, paramGetString(params, PARAM_A_USERGROUPID));
                itemSearch.setParam(PARAM_A_USERID, paramGetString(params, PARAM_A_USERID));
                rs = itemSearch.execute();
                if (rs.rowCount() == 0) {
                    rs = null;
                    throw new PipelineRuntimeException("This item is no longer available: " + itemID);
                }
            }

        } catch (Exception e) {
            LOG.debug("Before PipelineRuntimeException", e);
            throw new PipelineRuntimeException(e);
        }
    }

    /**
     * Validate states
     * 
     * @param pipelinecontext
     * @throws PipelineRuntimeException
     */
    private void validateState(PipelineContext pipelinecontext) throws PipelineRuntimeException {
        try {
            final Parameters params = CustomStagesHelper.getRequestParameters(pipelinecontext);
            XMLRequest request = (XMLRequest) pipelinecontext.getRequest();
            org.w3c.dom.Document xmlDoc = request.getRequestDoc();
            Node nd = XPathAPI.selectSingleNode(xmlDoc, "request/entities/entity/attributes/attribute[@name='"
                    + ATTR_SHIPPINGCTRYID + "']");
            String shippingCountryID = nd.getFirstChild().getNodeValue();

            SearchPipelineExecuter countrySearch = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                    "Country", "List");
            countrySearch.setParam(PARAM_LANGUAGECODE, paramGetString(params, PARAM_LANGUAGECODE));
            countrySearch.setBinding(ATTR_COUNTRYID, shippingCountryID, "eq");
            Resultset rs = countrySearch.execute();
            if (rs.rowCount() == 0) {
                throw new PipelineRuntimeException("Shipping country id is not supported: " + shippingCountryID);
            }

            nd = XPathAPI.selectSingleNode(xmlDoc, "request/entities/entity/attributes/attribute[@name='"
                    + ATTR_SHIPPINGSTATEID + "']");
            
            if (nd == null || nd.getFirstChild() == null) {
                return;
            }

            String shippingStateID = nd.getFirstChild().getNodeValue();

            if (null == shippingStateID || "".equals(shippingStateID.trim())) {
                return;
            }

            SearchPipelineExecuter stateSearch = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                    "Country", "StatesLookup");
            stateSearch.setParam(PARAM_LANGUAGECODE, paramGetString(params, PARAM_LANGUAGECODE));
            stateSearch.setParam("countryID", shippingCountryID);
            // stateSearch.setBinding(ATTR_COUNTRYID, shippingCountryID, "eq");

            rs = stateSearch.execute();
            if (rs.hasNext()) {
                rs.moveFirst();

                Resultset rsState = rs.getResultset(ATTR_STATE);
                if (rsState.hasNext()) {
                    rsState.moveNext();
                }
                boolean found = false;
                while (!rsState.isAfterLast()) {
                    if (shippingStateID.equals(rsState.getString(ATTR_STATEID))) {
                        found = true;
                        break;
                    }
                    rsState.moveNext();
                }
                if (!found) {
                    throw new PipelineRuntimeException("The state specified is invalid for the country");
                }
            }
        } catch (Exception e) {
            LOG.debug("Before PipelineRuntimeException", e);
            throw new PipelineRuntimeException(e);
        }
    }

    /**
     * Utility to get parameters
     * 
     * @param params
     * @param key
     * @return
     * @throws PipelineRuntimeException
     */
    private String paramGetString(Parameters params, String key) throws PipelineRuntimeException {
        String ret = null;
        try {
            ret = params.getString(key);
        } catch (Exception e) {
            throw new PipelineRuntimeException(e);
        }
        return ret;
    }
}
