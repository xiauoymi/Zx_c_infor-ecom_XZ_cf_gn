package com.intentia.iec.pipeline.runtime.stage.custom;

import java.text.DateFormat;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.Resultset;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.util.mail.ESalesMail;
import com.intentia.iec.businessobject.output.XMLIterator;

	/**
	 * SendMailOnBODOrderStatus - Sends email notification for BOD order status via gateway exposure.
	 * 
	 * @author gtajonera
	 *
	 */

public class SendMailOnBODOrderStatus implements PipelineStage {

	private static final Logger LOG = Logger.getLogger(SendMailOnBODOrderStatus.class);

	private Parameters parameters = null;
	
	private ESalesMail msgMail = null;

	// PARAMETERS
	
	private static final String PARAM_ORDERID = "OrderID";
	
	private static final String PARAM_STATUS = "Status";
	
	private static final String PARAM_EMAIL = "Email";
	
	private static final String PARAM_LANGUAGEID = "@LanguageCode";
	
	private static final String BOD_ORDER_STATUS_ACCEPTED = "Accepted";

	private String mailServerAddress = null;

	private String mailServerPort = null;

	private String email = null;
	
	private String orderID = null;
	
	private String status = null;
	
	private String merchantEmail = null;
	
	private String username = null;
	
	private String languageCode = null;
	
	private String customerName = null;
	
	private String totalPrice = null;
	
	private String grandTotal = null;
	
	private String lineNumber = null;
	
	private String itemNumber = null;
    
	private String itemName = null;
    
	private String quantity = null;
    
	private String linePrice = null;
    
	private String lineTotal = null;
	
	private String tempOrderID = null;
	
	private String lineSeparator = "<br>";
	
	private String tab = "&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp";

	private static final String ORDERACKNOWLEDGE_PAGE = "/cc/OrderAcknowledge.jsp";

	public void execute(PipelineContext context)
			throws PipelineRuntimeException {
		try {
			// Get Request Parameter
			getRequestParameters(context);
			
			// Get Request Response
			getResponseHeader(context);

			// Compose and Send Email Order Notification
			sendMail(context);
		} catch (Throwable e) {
			LOG.debug("Unable to send email notification", e);
			// catching all throwable exceptions
			// his is to prevent transaction rollback
		}

	}

	private void sendMail(PipelineContext context) throws PipelineRuntimeException {
        try {
            msgMail = null;
            mailServerAddress = getValueFromApplicationData("MailServer");
            mailServerPort = getValueFromApplicationData("MailServerPort");

            // Add submit on Order role
            if (!mailServerAddress.equals("0.0.0.0") && !mailServerAddress.equals("")) {
                msgMail = new ESalesMail(mailServerAddress, mailServerPort);
            } else {
                return;
            }

            // Compose Email
            msgMail.setSender(getValueFromApplicationData("MailSender"));

            // Add Merchant to Mail recipient once MerchantEmail was found
            merchantEmail = getValueFromApplicationData("MerchantEmail");
            if (!merchantEmail.equals("") && merchantEmail != null) {
                msgMail.AddRecipient(merchantEmail);
            }

            // Add Mail Recipient
            msgMail.AddRecipient(email);
            msgMail.setSubject(getPageText(ORDERACKNOWLEDGE_PAGE, "mailsubject", languageCode));

            // Mail Content
            msgMail.AppendText(getPageText(ORDERACKNOWLEDGE_PAGE, "mailopening", languageCode));
            msgMail.AppendText(" " + username);
            msgMail.AppendText(lineSeparator);
            
            msgMail.AppendText(OrderNotificationHeaderBody(context));
            
            OrderNotificationLineBody(context, msgMail);            

            msgMail.AppendText(lineSeparator + lineSeparator);

            msgMail.AppendText(getPageText(ORDERACKNOWLEDGE_PAGE, "mailclosing", languageCode));

            msgMail.sendEmail();
            
            int statusMail = msgMail.getStatus();

            if (statusMail == 0) {
                LOG.debug("EmailSent test was true");
            }
        } catch (Exception e) {
            throw new PipelineRuntimeException(e);
        }
    }

	private String getValueFromApplicationData(String pParamName) {

		String paramValue;

		SearchPipelineExecuter seOrderItems = new SearchPipelineExecuter(
				ConstantsForSales.PIPELINE_PACKAGE, "ApplicationData",
				"Details");

		seOrderItems.setParam("param", pParamName);

		try {
			XMLResultset rs = seOrderItems.execute();
			rs.moveFirst();
			paramValue = rs.getString("ParameterValue");
		} catch (PipelineRuntimeException e) {
			paramValue = "";
		} catch (ResultsetException e) {
			paramValue = "";
		}

		return paramValue;

	}

	private void getRequestParameters(PipelineContext context)
			throws PipelineRuntimeException {

		// Verify type of request
		if (!(context.getRequest() instanceof XMLRequest)) {
			throw new PipelineRuntimeException(
					"Request MUST be of type XMLRequest!");
		}

		XMLRequest request = (XMLRequest) context.getRequest();

		try {

			XMLRequest.extractRequestParameters(request);
			parameters = request.getParameters();

			// Fetch request parameters
		
			orderID = parameters.getString(PARAM_ORDERID);
			status = parameters.getString(PARAM_STATUS);
			languageCode = parameters.getString(PARAM_LANGUAGEID);
			
			if (status.equals("Accepted")) {
				tempOrderID = orderID;
			} else 
				tempOrderID = "PENDING";

			/* TODO Handling of 'null' string in the presentation layer */

		} catch (Exception e) {
			throw new PipelineRuntimeException(e);
		}
		
	}
	
	private void getResponseHeader (PipelineContext context) throws PipelineRuntimeException {
		
		XMLResultset response = (XMLResultset) context.getResponse();
		

		try {
			response.beforeFirst();
			response.moveNext();
			email = response.getString("UserEmail");
			username = response.getString("UserName");
			customerName = response.getString("CompanyName");
			totalPrice = response.getString("TotalPrice");
			grandTotal = response.getString("GrandTotal");

		} catch (Exception e) {
			throw new PipelineRuntimeException(e);
		}
		
	}
	
	private String getPageText(String pPageName, String pName,
			String pLanguageCode) throws PipelineRuntimeException {

		String pageText = "";

		SearchPipelineExecuter seOrderItems = new SearchPipelineExecuter(
				ConstantsForSales.PIPELINE_PACKAGE, "SiteText", "List");

		seOrderItems.setBinding("SitePageName", pPageName, "eq");
		seOrderItems.setBinding("Name", pName, "eq");
		seOrderItems.setParam("@LanguageCode", "en");

		try {
			XMLResultset rs = seOrderItems.execute();
			rs.moveFirst();
			Resultset rsText = rs.getResultset("Text");

			rsText.beforeFirst();

			while (rsText.hasNext()) {
				rsText.moveNext();
				String test = rsText.getString("LanguageID");
				if (test.equals(pLanguageCode)) {
					pageText = rsText.getString("Text");
				}
			}

		} catch (ResultsetException e) {
			LOG.error("Unable to get Page text for Page: " + pPageName
					+ ", text name: " + pName + ", and language: "
					+ pLanguageCode);
			pageText = "";
		}

		return pageText;

	}
	
	private String OrderNotificationHeaderBody(PipelineContext context)
			throws PipelineRuntimeException {
		String msg = null;
		
		try {
			
			String urlOrderAcknowledgePage = getValueFromApplicationData("ApplicationURL")
					+ "/cc/PreviousDetails.jsp" + "?@where.OrderID=" + orderID;
			
			String viewLink =  getPageText("PseudoPage", "viewOrder", languageCode);
			
			String url = "<a href = " + urlOrderAcknowledgePage + ">" + viewLink +"</a>";

			msg = ""					
					+ lineSeparator
					+ lineSeparator
					+ getPageText(ORDERACKNOWLEDGE_PAGE,
							"status", languageCode)
					+ " : "
					+ getPageText("PseudoPage",
							status, languageCode)
					+ lineSeparator
					+ url
					+ lineSeparator
					+ lineSeparator
					+ getPageText("/bc/OrderDetails.jsp", "orderDetails",
							languageCode)
					+ lineSeparator
					+ tab
					+ getPageText(ORDERACKNOWLEDGE_PAGE, "orderid",
							languageCode)
					+ ": "
					+ tempOrderID
					+ lineSeparator
					+ tab
					+ getPageText(ORDERACKNOWLEDGE_PAGE, "ordertotal",
							languageCode)
					+ ": "
					+ totalPrice
					+ lineSeparator
					+ tab
					+ getPageText(ORDERACKNOWLEDGE_PAGE, "grandtotal",
							languageCode)
					+ ": "
					+ grandTotal
					+ lineSeparator
					+ lineSeparator;
					
		
		} catch (Exception e) {
			LOG.debug(e.getMessage());
			throw new PipelineRuntimeException(e);
		}

		return msg;
	}
	
	private String OrderNotificationLineBody(PipelineContext context, ESalesMail msgMail)
			throws PipelineRuntimeException {
		
		String msg = null;
				
		XMLResultset response = (XMLResultset) context.getResponse();
		
		try {
			response.moveFirst();
						
			// Get CurrentOrderLine Resultset response 
    		XMLIterator lines = (XMLIterator) response.getResultset(ConstantsForSales.ORDERLINE);
            if ((lines == null) || lines.isEmpty()) {
                LOG.debug("No OrderLine available!");
            }
            
            msgMail.AppendText(getPageText("PseudoPage", "b_detail",
					languageCode));
            
            boolean go = true;
            while (go && lines.moveNext()) {
            	
            	lineNumber = lines.getString("LineNumber");
                itemNumber = lines.getString("ItemID");
                itemName = lines.getString("ItemName");
                quantity = lines.getString("Quantity");
                linePrice = lines.getString("LinePrice");
                lineTotal = lines.getString("LineTotal");
                
                msg = ""
    					+ lineSeparator
    					+ "     "
    					+ getPageText("/cc/PreviousOrderLineDetails.jsp", "lineNum",
    							languageCode)
    					+ ": "
    					+ lineNumber
    					+ lineSeparator
    					+ tab
    					+ getPageText(ORDERACKNOWLEDGE_PAGE, "sku",
    							languageCode)
    					+ ": "
    					+ itemNumber
    					+ lineSeparator
    					+ tab
    					+ getPageText(ORDERACKNOWLEDGE_PAGE, "item",
    							languageCode)
    					+ ": "
    					+ itemName
    					+ lineSeparator
    					+ tab
    					+ getPageText(ORDERACKNOWLEDGE_PAGE, "qty",
    							languageCode)
    					+ ": "
    					+ quantity
    					+ lineSeparator
    					+ tab
    					+ getPageText(ORDERACKNOWLEDGE_PAGE, "lineprice",
    							languageCode)
    					+ ": "
    					+ linePrice
    					+ lineSeparator
						+ tab
						+ getPageText("/cc/OrderLines.jsp", "lineTotal",
								languageCode)
						+ ": "
						+ lineTotal
						+ lineSeparator;
                
                msgMail.AppendText(msg);
            }

		} catch (Exception e) {
			throw new PipelineRuntimeException(e);
		}
		
		return msg;
	}

}
