package com.intentia.iec.pipeline.runtime.stage.custom.promotion.rules;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

public class QuantityImpl implements Rules {

	private static final Logger LOG = Logger.getLogger(QuantityImpl.class);
	
	private static QuantityImpl instance = null;
	
	private PromotionRule promotionRule = null;

	private String promotionId;
	
	private Map<String, List<String>> promotionalItemsMap;
	
	private XMLRequestHelper xmlHelper = null;
	
	private String languageCode = null;
	
	protected QuantityImpl() {
		// Exists only to defeat instantiation.
	}

	public static QuantityImpl getInstance() {
		if (instance == null) {
			instance = new QuantityImpl();
		}
		return instance;
	}
	
	public PromotionRule getPromotionRule() {
		return promotionRule;
	}
	
	public void setPromotionId(String promotionId) {
		this.promotionId = promotionId;
	}
	
	public void setPromotionRule(PromotionRule promotionRule) {
		this.promotionRule = promotionRule;
	}
	
	public void setPromotionalItemsMap(Map<String, List<String>> promotionalItemsMap) {
		this.promotionalItemsMap = promotionalItemsMap;
	}

	public boolean evaluateOrder(XMLResultset resultSet, XMLRequestHelper xmlHelper) throws ResultsetException {
		LOG.debug("Inside QuantityImpl.evaluateOrder()");
		boolean isValid = false;
		this.xmlHelper = xmlHelper;
		try {
			PromotionRule promotionRule = this.promotionRule;		
			String ruleField = promotionRule.getField().trim();
			String operator = promotionRule.getOperator().trim();
			
			List<String> ruleValueList = promotionRule.getValues();
			if(RulesConstant.TOTAL_NUMBER_OF_ITEMS.equals(ruleField)){
				isValid = this.evaluateTotalNumberOfItems(resultSet, ruleValueList, operator);
			}else if(RulesConstant.ITEMS_IN_PROMO.equals(ruleField)){
					isValid = this.evaluateItemsInPromo(resultSet, ruleValueList, operator);
			} else {
				isValid = false;
			}
		} catch (TransformerException e) {
			e.printStackTrace();
		} catch (ResultsetException e) {
			String msg = "Could not get order lines";
			LOG.error("Error Inside QuantityImpl.evaluateGrandTotal() - "+msg);
		}
		
		return isValid;	
	}
	
	public boolean evaluateOrderLine(XMLIterator xmlOrderline, XMLRequestHelper xmlHelper)
			throws TransformerException, ResultsetException {
		LOG.debug("Inside QuantityImpl.evaluateOrderLine()");
		boolean isValid = false;
		this.xmlHelper = xmlHelper;
		try {
			PromotionRule promotionRule = this.promotionRule;	
			List<String> ruleValueList = promotionRule.getValues();
			String ruleField = promotionRule.getField().trim();
			String operator = promotionRule.getOperator().trim();
			
			if(RulesConstant.ANY_ITEMS_IN_PROMO.equals(ruleField) || RulesConstant.PER_ITEMS_IN_PROMO.equals(ruleField)){
				isValid = this.evaluateItemQuantity(xmlOrderline, ruleValueList, operator);
			} else {
				isValid = false;
			}
		} catch (TransformerException e) {
			e.printStackTrace();
		}
		return isValid;
	}

	private boolean evaluateTotalNumberOfItems(XMLResultset resultSet, List<String> ruleValueList, String operator)
			throws TransformerException, ResultsetException{
		LOG.debug("Inside QuantityImpl.evaluateTotalNumberOfItems()");
		boolean isMatch = false;
		XMLIterator xmlOrderline = null;
		try {
            xmlOrderline = (XMLIterator) resultSet.getResultset(ConstantsForSales.ORDERLINE);
            if (xmlOrderline == null){
            	xmlOrderline = (XMLIterator) resultSet.appendResultset(ConstantsForSales.ORDERLINE);            	
            }
		
            xmlOrderline.beforeFirst();
		 	BigDecimal orderQuantityTotal = new BigDecimal(0);
		 	while (xmlOrderline.moveNext()) {
				//Each Orderline    		
				String quantityFromRequest = this.getStringValue(xmlOrderline, RulesConstant.REQ_QUANTITY); 
				BigDecimal lineQuantity = new BigDecimal(quantityFromRequest);
				orderQuantityTotal = orderQuantityTotal.add(lineQuantity);
				
			}
		 	for (String quantityValue : ruleValueList) {
		 		isMatch = operatorEvaluator(operator, orderQuantityTotal, quantityValue);
		 		//End after one loop
		 		break;
		 	}
		 } catch (ResultsetException e) {
            String msg = "Could not get order lines";
            LOG.error("Error Inside QuantityImpl.evaluateTotalNumberOfItems() - "+msg);
        }
		return isMatch;
	}

	private boolean evaluateItemsInPromo(XMLResultset resultSet, List<String> ruleValueList, String operator)
			throws TransformerException, ResultsetException{
		LOG.debug("Inside QuantityImpl.evaluateItemsInPromo()");
		List<String> promotionalItems = this.promotionalItemsMap.get(this.promotionId);
		boolean isMatch = false;
		XMLIterator xmlOrderline = null;
		
		try {
            xmlOrderline = (XMLIterator) resultSet.getResultset(ConstantsForSales.ORDERLINE);
            xmlOrderline.beforeFirst();
            BigDecimal orderQuantityTotal = new BigDecimal(RulesConstant.ZERO_BIG_DECIMAL_VALUE); 
        	while (xmlOrderline.moveNext()) {
        		String currItemID = this.getStringValue(xmlOrderline, ConstantsForSales.ITEM_ID); 
        		
        		if(promotionalItems.contains(currItemID)){
        			String quantityFromRequest = this.getStringValue(xmlOrderline, RulesConstant.REQ_QUANTITY); 
        			orderQuantityTotal = orderQuantityTotal.add(new BigDecimal(quantityFromRequest));
        		}
        	}
        	for (String amountValue : ruleValueList) {
        		isMatch = operatorEvaluator(operator, orderQuantityTotal, amountValue);
        		//End after one loop
        		break;
        	}
        } catch (ResultsetException e) {
            String msg = "Could not get order lines";
            LOG.error("Error Inside QuantityImpl.evaluateItemsInPromo() - "+msg);
        }
		return isMatch;
	}
	
	private boolean evaluateItemQuantity(XMLIterator xmlOrderline, List<String> ruleValueList, String operator)
			throws TransformerException, ResultsetException{
		LOG.debug("Inside QuantityImpl.evaluateItemQuantity()");
		boolean isMatch = false;
		String quantityFromRequest = this.getStringValue(xmlOrderline, RulesConstant.REQ_QUANTITY); 
		BigDecimal lineQuantityTotal = new BigDecimal(quantityFromRequest);
		for (String quantityValue : ruleValueList) {
			isMatch = operatorEvaluator(operator, lineQuantityTotal, quantityValue);
			//End after one loop
			break;
		}

		return isMatch;
	}
	
	/**
	 * @param operator
	 * @param isMatch
	 * @param lineQuantityTotal
	 * @param quantityValue
	 * @return
	 */
	private boolean operatorEvaluator(String operator, BigDecimal lineQuantityTotal, String quantityValue) {
		boolean isMatch = false;
		BigDecimal amount = new BigDecimal(quantityValue);
		int result = lineQuantityTotal.compareTo(amount);
		if(RulesConstant.OPERATOR_EQUAL.equals(operator)){
			if(result == 0){ // both values are equal
				isMatch = true;					
			}
		} else if(RulesConstant.OPERATOR_LESSTHAN.equals(operator)){
			if(result == -1){ // order quantity total is less than rule vale amount 
				isMatch = true;					
			}
		} else if(RulesConstant.OPERATOR_GREATERTHAN.equals(operator)){
			if(result == 1){ // order quantity total is greater than rule vale amount
				isMatch = true;					
			}
		} else if(RulesConstant.OPERATOR_LESSTHAN_EQUALTO.equals(operator)){
			if(result == -1 || result == 0){ // order quantity total is less than equal to rule vale amount
				isMatch = true;					
			}
		} else if(RulesConstant.OPERATOR_GREATERTHAN_EQUALTO.equals(operator)){
			if(result == 1 || result == 0){ // order quantity total is greater than equal to rule vale amount
				isMatch = true;					
			}
		}
		return isMatch;
	}
	
	private String getStringValue(XMLIterator xmlOrderline, String requestField){
		String stringFromRequest = "";
		try {
			stringFromRequest = xmlOrderline.getString(requestField);
			if("".equals(stringFromRequest) && requestField.equals(RulesConstant.REQ_QUANTITY)){
				stringFromRequest = RulesConstant.ZERO_BIG_DECIMAL_VALUE;
			}
		} catch (ResultsetException e) {
			String msg = "Empty Request Field";
            LOG.error("Error Inside QuantityImpl.getStringValue() - "+msg);
		}
		return stringFromRequest;
	}
	
}
