package com.intentia.iec.pipeline.runtime.stage.custom.lucene.manager;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.log4j.Logger;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.CheckIndex;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.TermEnum;
import org.apache.lucene.search.Filter;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Sort;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.ParserAdapter;

import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.custom.lucene.utils.IndexManagerUtil;
import com.intentia.iec.pipeline.runtime.stage.custom.lucene.utils.IndexMapHandler;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

/**
 * 
 * @author 15062
 * 
 */
public class IndexManager {

    private static final Logger LOG = Logger.getLogger(IndexManager.class);

    private static final int DEFAULT_UNOPTIMIZE_DOC_LIMIT = 100;

    private static final String INDEX_MAP_FOLDER_PATH = "xml/";

    private static final int LOG_ROW_MODULUS = 1000;

    private static Map<String, IndexManager> _managers = new HashMap<String, IndexManager>();

    private Directory _directory = null;

    private Analyzer _analyzer = null;

    private String _indexName = null;

    private String _indexPath = null;

    private String _indexStatus = null;

    private IndexSearcher _searcher = null;

    private int _unoptimizedDocCounter = 0;

    private int _unoptimizedDocLimit = -1;

    private boolean _testIndexHealthAfterUpdate = true;

    private Map<String, Set<String>> _attributeFieldMapping = null;

    private Map<String, String> _fieldTypes = null;

    private Set<String> _sortableFields = null;

    private Set<String> _localizedFields = null;

    private Set<String> _languageCodes = null;

    /**
     * 
     * @param name
     * @throws IOException
     */
    private IndexManager(String name) throws IndexManagerRuntimeException {
        this._indexName = name;
        this.init();
    }

    private void init() throws IndexManagerRuntimeException {
        _directory = createDirectory(getIndexPath());
        processIndexMapFile();
        setLanguageCodes();
    }

    private void processIndexMapFile() throws IndexManagerRuntimeException {
        String mapFilePath = INDEX_MAP_FOLDER_PATH + _indexName + ".map";
        try {
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser parser = factory.newSAXParser();
            ParserAdapter adapter = new ParserAdapter(parser.getParser());
            IndexMapHandler handler = new IndexMapHandler();
            adapter.setContentHandler(handler);
            InputStream xslFile = handler.getClass().getResourceAsStream(mapFilePath);
            adapter.parse(new InputSource(xslFile));

            _attributeFieldMapping = handler.getAttributeFieldMapping();
            _fieldTypes = handler.getFieldTypes();
            _localizedFields = handler.getLocalizedFields();
            _sortableFields = handler.getSortableFields();

            LOG.info("Finished processing index map file '" + mapFilePath + "'");
        } catch (ParserConfigurationException e) {
            throw new IndexManagerRuntimeException("Unable to instantiate new SAX parser", e);
        } catch (SAXException e) {
            throw new IndexManagerRuntimeException("Unable to parse index map file", e);
        } catch (IOException e) {
            throw new IndexManagerRuntimeException("Unable to read index map file", e);
        }
    }

    /**
     * 
     * @param name
     * @return
     * @throws IndexManagerRuntimeException
     */
    public static synchronized IndexManager getInstance(String name) throws IndexManagerRuntimeException {
        if (_managers.get(name) == null) {
            LOG.debug("Creating new instance of the IndexManager for " + name);
            _managers.put(name, new IndexManager(name));
        } else {
            LOG.debug("Returning an existing instance of IndexManager of " + name);
        }

        return _managers.get(name);
    }

    /**
     * 
     * @param indexPath
     * @return
     * @throws IndexManagerRuntimeException
     */
    private Directory createDirectory(final String indexPath) throws IndexManagerRuntimeException {
        Directory dir = null;
        try {
            dir = FSDirectory.getDirectory(indexPath);
        } catch (IOException e) {
            throw new IndexManagerRuntimeException("Error while creating the index directory", e);
        }
        return dir;
    }

    /**
     * 
     * @param docMap
     * @return
     * @throws IndexManagerRuntimeException
     */
    public boolean updateIndex(final Map<String, Document> docMap) throws IndexManagerRuntimeException {
        return doIndexUpdate(docMap, false);
    }

    /**
     * 
     * @param docMap
     * @return
     * @throws IndexManagerRuntimeException
     */
    public boolean rebuildIndex(final Map<String, Document> docMap) throws IndexManagerRuntimeException {
        return doIndexUpdate(docMap, true);
    }

    /**
     * 
     * @param docMap
     * @param rebuildIndex
     * @return
     * @throws IndexManagerRuntimeException
     */
    private boolean doIndexUpdate(final Map<String, Document> docMap, final boolean rebuildIndex)
            throws IndexManagerRuntimeException {
        boolean result = false;
        synchronized (this) {
            IndexWriter writer = null;
            int documentCounter = 0;
            try {
                long startTime = System.nanoTime();
                if (rebuildIndex) {
                    LOG.info("Start rebuilding '" + _indexName + "'...");
                    writer = new IndexWriter(_directory, false, getAnalyzer(), rebuildIndex);
                    _unoptimizedDocCounter = 0;
                } else {
                    LOG.info("Start updating '" + _indexName + "'...");
                    writer = new IndexWriter(_directory, false, getAnalyzer());
                }
                Iterator<String> it = docMap.keySet().iterator();
                while (it.hasNext()) {
                    Object key = it.next();
                    Object value = docMap.get(key);

                    Term term = new Term(ConstantsForSales.KEY_FIELD, (String) key);
                    Document doc = (Document) value;
                    writer.updateDocument(term, doc);
                    _unoptimizedDocCounter++;
                    documentCounter++;
                    if (documentCounter % LOG_ROW_MODULUS == 0) {
                        LOG.info("Indexing document #" + documentCounter + " at " + _indexName + "...");
                    }
                }

                if (_unoptimizedDocCounter > getUnoptimizedDocLimit()) {
                    LOG.info("Optimizing index '" + _indexName + "'...");
                    writer.optimize();
                    _unoptimizedDocCounter = 0;
                }
                long endTime = System.nanoTime();
                LOG.info("Finished adding/updating " + docMap.size() + " document(s) in "
                        + IndexManagerUtil.getTimeInterval(startTime, endTime) + " at '" + _indexName + "'");

                result = true;
            } catch (IOException e) {
                throw new IndexManagerRuntimeException("Error while updating index '" + _indexName, e);
            } catch (OutOfMemoryError oome) {
                throw new IndexManagerRuntimeException("Run of memory while updating index '" + _indexName, oome);
            } finally {
                result = finalizeUpdates(result, writer);
            }
        }
        return result;
    }

    /**
     * 
     * @param writer
     * @throws IOException
     */
    private boolean finalizeUpdates(final boolean updateResult, final IndexWriter writer)
            throws IndexManagerRuntimeException {
        boolean isFinalized = false;

        try {
            LOG.info("Finalizing index updates...");
            if (writer != null) {
                if (updateResult == false) {
                    writer.abort();
                    writer.close();
                } else {
                    if (_testIndexHealthAfterUpdate) {
                        try {
                            if (indexIsHealthy()) {
                                writer.close();
                                LOG.info("Index writer closed.");
                                reloadSearcher();
                            } else {
                                writer.abort();
                                LOG.error("Aborting index modifications due to unhealty index after the updates.");
                            }
                        } catch (IOException e) {
                            writer.abort();
                            LOG.error("Unable to finalize index updates.", e);
                        }
                    } else {
                        writer.close();
                        LOG.info("Index writer closed.");
                        reloadSearcher();
                    }
                }
                isFinalized = true;
                updateIndexDetails();
            } else {
                LOG.error("Unable to finalize index updates. Index writer is 'null'");
            }
        } catch (IOException e) {
            LOG.error("Unable to finalize index updates", e);
        }
        LOG.info("Finished committing all updates to index '" + _indexName + "'");

        return isFinalized;
    }

    private void updateIndexDetails() throws IndexManagerRuntimeException {
        try {

            LOG.info("Updating index details...");
            Map<String, String> attributes = new HashMap<String, String>();
            IndexReader reader = IndexReader.open(_directory);

            // Set 'lastModifiedDate' column
            java.sql.Timestamp modifiedDate = new java.sql.Timestamp(IndexReader.lastModified(_directory));
            attributes.put(ConstantsForSales.LAST_MODIFIED_DATE_ATTRIBUTE, modifiedDate.toString());

            // Set 'numberOfRecords' column
            attributes.put(ConstantsForSales.NUMBER_OF_RECORDS_ATTRIBUTE, String.valueOf(reader.numDocs()));

            // Set 'numberOfFields' column
            Collection<?> fields = reader.getFieldNames(IndexReader.FieldOption.INDEXED);
            attributes.put(ConstantsForSales.NUMBER_OF_FIELDS_ATTRIBUTE, String.valueOf(fields.size()));

            // Set 'numberOfTerms' column
            TermEnum terms = reader.terms();
            int termCount = 0;
            while (terms.next())
                termCount++;
            attributes.put(ConstantsForSales.NUMBER_OF_TERMS_ATTRIBUTE, String.valueOf(termCount));

            // Set 'isOptimized' column
            if (reader.isOptimized())
                attributes.put(ConstantsForSales.IS_OPTIMIZED_ATTRIBUTE, "Y");
            else
                attributes.put(ConstantsForSales.IS_OPTIMIZED_ATTRIBUTE, "N");

            reader.close();
            IndexManagerUtil.updateIndexDetails(_indexName, attributes);
        } catch (CorruptIndexException e) {
            throw new IndexManagerRuntimeException("Fail to update index details. Index '" + _indexName
                    + "' is corrupt.", e);
        } catch (IOException e) {
            throw new IndexManagerRuntimeException("Fail to update index details. Unable to open index '" + _indexName
                    + "'", e);
        }
    }

    public boolean cleanupIndex(Term[] keyTerms) throws IndexManagerRuntimeException {
        boolean result = false;
        synchronized (this) {
            LOG.info("Cleaning up index files...");
            IndexWriter writer = null;
            try {
                if (keyTerms != null && keyTerms.length > 0) {
                    writer = new IndexWriter(_directory, false, getAnalyzer());
                    writer.deleteDocuments(keyTerms);
                } else
                    LOG.info("No document to delete in the index files.");
                result = true;
            } catch (IOException e) {
                throw new IndexManagerRuntimeException("Error while deleting documents from '" + _indexName, e);
            } finally {
                result = finalizeUpdates(result, writer);
            }
            LOG.info("Finished cleaning " + keyTerms.length + " document(s) from '" + _indexName + "'!");
        }
        return result;
    }

    /**
     * 
     * @param query
     * @return
     * @throws IOException
     */
    public Hits search(final Query query) throws IndexManagerRuntimeException {
        return search(query, null, null);
    }

    /**
     * 
     * @param query
     * @param filter
     * @param sort
     * @return
     * @throws IOException
     */
    public Hits search(final Query query, final Filter filter, Sort sort) throws IndexManagerRuntimeException {
        Hits hits = null;
        try {
            LOG.info("Searching \"" + query.toString() + "\" from " + _indexName + "...");
            long startTime = System.nanoTime();

            if (_searcher == null)
                setSearcher();
            if (filter != null && sort != null)
                hits = _searcher.search(query, filter, sort);
            else if (filter != null)
                hits = _searcher.search(query, filter);
            else
                hits = _searcher.search(query);

            long endTime = System.nanoTime();
            LOG.info("Finished searching. Found " + hits.length() + " document(s) in "
                    + IndexManagerUtil.getTimeInterval(startTime, endTime) + " from '" + _indexName + "'");
        } catch (IOException e) {
            throw new IndexManagerRuntimeException("Error while searching index '" + getIndexPath(), e);
        }
        return hits;
    }

    /**
     * 
     * @return
     */
    public Analyzer getAnalyzer() {
        if (_analyzer == null)
            _analyzer = new EsaAnalyzer();
        return _analyzer;
    }

    /**
     * 
     * @return
     */
    public String getIndexPath() {
        if (_indexPath == null) {
            try {
                _indexPath = CustomStagesHelper.getKeyValue(ConstantsForSales.INDEX_FOLDER_APP_PROP);
                if (_indexPath == null) {
                    _indexPath = ConstantsForSales.DEFAULT_INDEX_FOLDER;
                }
                _indexPath += "\\" + _indexName;
            } catch (PipelineRuntimeException e) {
                _indexPath = ConstantsForSales.DEFAULT_INDEX_FOLDER + _indexName;
            }
        }

        return _indexPath;
    }

    /**
     * 
     * @return
     */
    public int getUnoptimizedDocLimit() {
        if (_unoptimizedDocLimit < 0) {
            try {
                _unoptimizedDocLimit = Integer.parseInt(CustomStagesHelper
                        .getKeyValue(ConstantsForSales.UNOPTIMIZED_DOC_LIMIT_APP_PROP));
            } catch (PipelineRuntimeException e) {
                LOG.error("Unable to fectch '" + ConstantsForSales.UNOPTIMIZED_DOC_LIMIT_APP_PROP
                        + "' property, uses the default value instead", e);
                _unoptimizedDocLimit = DEFAULT_UNOPTIMIZE_DOC_LIMIT;
            } catch (NumberFormatException e) {
                LOG.error("Unable to parse the specified value of '" + ConstantsForSales.UNOPTIMIZED_DOC_LIMIT_APP_PROP
                        + "', uses the default value instead", e);
                _unoptimizedDocLimit = DEFAULT_UNOPTIMIZE_DOC_LIMIT;
            }
        }

        return _unoptimizedDocLimit;
    }

    /**
     * 
     * @param test
     */
    public void setTestIndexHealthAfterUpdate(final boolean test) {
        _testIndexHealthAfterUpdate = test;
    }

    /**
     * 
     * @return
     */
    private boolean indexIsHealthy() throws IndexManagerRuntimeException {
        Boolean result = true;
        try {
            long startTime = System.nanoTime();
            LOG.info("Checking index health...");
            result = CheckIndex.check(_directory, false);
            long endTime = System.nanoTime();
            LOG.info("Finished checking index health of '" + _indexName + "' in "
                    + IndexManagerUtil.getTimeInterval(startTime, endTime) + "!");
        } catch (IOException e) {
            throw new IndexManagerRuntimeException("Unable to check index health of '" + _indexName + "'", e);
        }
        return result;
    }

    /**
     * 
     * @throws IOException
     */
    private void reloadSearcher() throws IOException {
        try {
            LOG.info("Reloading index searcher to refresh its snapshot data...");
            // TODO: see if we need thread sleep here?
            if (_searcher != null) {
                _searcher.close();
                _searcher = null;
            }
            setSearcher();
        } catch (IOException e) {
            LOG.error("Unable to reload index search,", e);
            throw e;
        }
    }

    /**
     * 
     * @throws IOException
     */
    private void setSearcher() throws IOException {
        try {
            if (_searcher == null) {
                LOG.info("Initializing index searcher...");
                _searcher = new IndexSearcher(_directory);
            }
        } catch (IOException e) {
            LOG.error("Unable to initialize index searcher,", e);
            throw e;
        }
    }

    private void setLanguageCodes() throws IndexManagerRuntimeException {
        Set<String> laguageCodes = new HashSet<String>();
        try {
            SearchPipelineExecuter pipeline = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                    "Language", "List");
            pipeline.setParam(ConstantsForSales.LANGUAGE_CODE_PARAM, ConstantsForSales.DEFAULT_LANGUAGE_CODE);
            XMLResultset result = pipeline.execute();

            if (!result.isEmpty()) {
                result.beforeFirst();
                while (result.moveNext()) {
                    laguageCodes.add(result.getString(ConstantsForSales.LANGUAGE_ID_ATTRIBUTE));
                }
            }
        } catch (PipelineRuntimeException e) {
            throw new IndexManagerRuntimeException("Unable to fetch list of visible locales", e);
        } catch (ResultsetException e) {
            throw new IndexManagerRuntimeException("Unable to parse list of visible locales", e);
        }
        _languageCodes = laguageCodes;
    }

    public Map<String, Set<String>> getAttributeFieldMapping() {
        return _attributeFieldMapping;
    }

    public Set<String> getIndexFields(final String attributeName) {
        return _attributeFieldMapping.get(attributeName);
    }

    public Map<String, String> getFieldTypes() {
        return _fieldTypes;
    }

    public String getFieldType(String fieldName) {
        return _fieldTypes.get(fieldName);
    }

    public Set<String> getLocalizedFields() {
        return _localizedFields;
    }

    public boolean isLocalizedField(final String fieldName) {
        return _localizedFields.contains(fieldName);
    }

    public Set<String> getSortableFields() {
        return _sortableFields;
    }

    public boolean isSortableField(final String fieldName) {
        return _sortableFields.contains(fieldName);
    }

    public Set<String> getLanguageCodes() {
        return _languageCodes;
    }

    public boolean hasLocalizedFields() {
        return (_localizedFields != null && !_localizedFields.isEmpty());
    }

    public Field.Index getFieldTokenization(final String fieldName) {
        if (ConstantsForSales.TYPE_STRING.equalsIgnoreCase(_fieldTypes.get(fieldName))) {
            return Field.Index.TOKENIZED;
        } else {
            return Field.Index.UN_TOKENIZED;
        }
    }

    public synchronized void setIndexStatus(final String indexStatus) {
        setIndexStatus(indexStatus, false);
    }

    public synchronized void setIndexStatus(final String indexStatus, final boolean memoryOnly) {
        _indexStatus = indexStatus;
        if (!memoryOnly)
            IndexManagerUtil.updateIndexStatus(_indexName, _indexStatus);
    }

    public synchronized String getIndexStatus() {
        return _indexStatus;
    }

}