/*
 * Copyright 2004 by Intentia
 *
 * Created on 14-03-2004
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.log4j.Logger;

import sun.misc.BASE64Encoder;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;

/**
 * This stage http posts the XMLResultset in the pipeline context to an address
 * setup in XMLRequest input parameters.
 * <p>
 * Warning: Experimental feature. This custom stage is not used as standard in
 * any Intentia application and is not thoroughly tested.
 * <p>
 * Instructions for use:<br>
 * Insert the custom stage in the pipeline at the point where the Response in
 * the context is of type XMLResultset and has the contents you want to submit
 * to an external destination.<br>
 * The HTTP address of the destination must be setup in an input parameter of
 * the request named 'ExportAddress'. You can add username and password for
 * Basic Authentication to the HTTP request by supplying values for the optional
 * input parameters named 'ExportUserID' and 'ExportPassword'.
 * <p>
 * There is no error handling beyond logging exceptions.
 * 
 * @author niekar0
 * 
 */
public class HttpPostResponse implements PipelineStage {
    public static final String EXPORT_ADDRESS = "ExportAddress";

    public static final String EXPORT_USERID = "ExportUserID";

    public static final String EXPORT_PASSWORD = "ExportPassword";

    private static final Logger LOG = Logger.getLogger(HttpPostResponse.class);

    public void execute(PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("Inside HttpPostResponse.execute()");

        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
        XMLRequest xmlRequest = (XMLRequest) context.getRequest();

        if (!(context.getResponse() instanceof XMLResultset)) {
            throw new PipelineRuntimeException("Contained response object MUST be of type 'XMLResultset'!");
        }
        XMLResultset response = (XMLResultset) context.getResponse();

        CustomStagesHelper.extractRequestParameters(xmlRequest);
        Parameters params = xmlRequest.getParameters();
        String httpAddress = null;
        String httpUserID = null;
        String httpPassword = null;
        try {
            httpAddress = params.getString(EXPORT_ADDRESS);
            httpUserID = params.getString(EXPORT_USERID);
            httpPassword = params.getString(EXPORT_PASSWORD);
        } catch (ParametersException e) {
            LOG.error(e);
        }

        if (httpAddress == null)
            return;

        LOG.info("Posting XMLResultset to address '" + httpAddress + "'. " + "Basic authentication with UserID '"
                + httpUserID + "' " + "and Password '" + httpPassword + "'");

        try {
            URL url = new URL(httpAddress);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "text/xml");
            if (httpUserID != null) {
                String auth = httpUserID + ":";
                if (httpPassword != null)
                    auth += httpPassword;
                BASE64Encoder encoder = new BASE64Encoder();
                String encoding = encoder.encode(auth.getBytes());
                conn.setRequestProperty("Authorization", "Basic " + encoding);
            }
            conn.connect();
            DataOutputStream out = new DataOutputStream(conn.getOutputStream());
            out.writeBytes(response.toString());

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        } catch (MalformedURLException e) {
            LOG.error(e);
        } catch (IOException e) {
            LOG.error(e);
        }
    }
}
