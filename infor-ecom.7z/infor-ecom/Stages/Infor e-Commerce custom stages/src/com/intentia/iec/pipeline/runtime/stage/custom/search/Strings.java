package com.intentia.iec.pipeline.runtime.stage.custom.search;

/**
 * Having the strings and SQL code here cleans up the main Java code. The reason
 * for why the fields are not declared static is that because then they would be
 * compile-time constants. Compile-time constants are in-lined in the target
 * class files and this could confuse developers who modify the strings here and
 * will have to rebuild (clean and build) the project for the changes to take
 * effect.
 */
public final class Strings {
    public static class Database {
        public static class Indexing {
            static class Setting {
                static class WarehouseItemsCount {
                    static String sql = "select count(*) from WarehouseItem";
                }
            }

            static class BaseData {
                static class CategoryPaths {
                    static String sql = "                                          "
                            + " select                                             "
                            + "     c1.id as part,                                 "
                            + "     c2.id as id,                                   "
                            + "     c2.[key] as [key]                              "
                            + " from Category c1                                   "
                            + "     inner join Category c2                         "
                            + "         on c1.low <= c2.low and c1.high >= c2.high "
                            + " order by c2.id, c1.level                           ";

                    static String part = "part";

                    static String id = "id";

                    static String key = "key";
                }
            }

            public static class Item {
                public static class Items {
                    public static final String sql = "                                                               "
                            + " select                                                                  "
                            + "     i.id,                                                               "
                            + "     i.itemNumber,                                                       "
                            + "     m.[key] as manufacturerId,                                          "
                            + "     m.name as manufacturerName,                                         "
                            + "     i.mainCategoryId,                                                   "
                            + "     b.[key] as brandId, 												" + "     i.supplierId 														"
                            + " from Item i                                                             "
                            + "     left outer join Manufacturer m                                      "
                            + "         on m.id = i.manufacturerId                                      "
                            + "    	left outer join Brand b                           					"
                            + "        	on b.id = i.brandId 											"
                            + " where i.isActive = 'Y' and                                              "
                            + "     i.typeCodeId = (select id from Code where [key] = 'normalItemCode') ";

                    public static final String sqlSpsEnabled = "                                                               "
                            + " select                                                                  "
                            + "     i.id,                                                               "
                            + "     i.itemNumber,                                                       "
                            + "     m.[key] as manufacturerId,                                          "
                            + "     m.name as manufacturerName,                                         "
                            + "     i.mainCategoryId,                                                   "
                            + "     b.[key] as brandId, 												"
                            + "     i.supplierId 														"
                            + " from Item i                                                             "
                            + "     left outer join Manufacturer m                                      "
                            + "         on m.id = i.manufacturerId                                      "
                            + "    	left outer join Brand b                           					"
                            + "        	on b.id = i.brandId 											"
                            + " where i.isActive = 'Y' and                                              "
                            + "		i.id not in (select sparePartID from SparePart) and"
                            + "     i.typeCodeId = (select id from Code where [key] = 'normalItemCode') ";

                    public static final String sqlWithoutStyles = sql
                            + " and i.id not in (select styleItemId from StyleRelation)";

                    public static final String sqlWithoutStylesSpsEnabled = sqlSpsEnabled
                            + " and i.id not in (select styleItemId from StyleRelation)";

                    // + " and i.id not in (select styleId from StyleRelation)";
                    public static final String id = "id";

                    public static final String itemNumber = "itemNumber";

                    public static final String manufacturerId = "manufacturerId";

                    public static final String manufacturerName = "manufacturerName";

                    public static final String mainCategoryId = "mainCategoryId";

                    // Additional field for version 13.1
                    public static final String brandId = "brandId";

                    public static final String supplierId = "supplierId";
                }

                public static class Categories {
                    public static String sql = "select categoryId from CategoryItemExtension" + " where itemId = ?";

                    public static String categoryId = "categoryId";
                }

                public static class MainCategoryNames {
                    public static String sql = "select languageCode, name" + " from CategoryText where categoryId = ?";

                    public static String languageCode = "languageCode";

                    public static String name = "name";
                }

                public static class NamesAndDescriptions {
                    public static String sql = "select languageCode, name, description" + " from ItemText where itemId = ?";

                    public static String languageCode = "languageCode";

                    public static String name = "name";

                    public static String description = "description";
                }

                public static class Assortments {
                	public static String sql = "select assortmentId from ItemVisible"
                            + " where itemId = ? and isVisible = 'Y'";

                	public static String assortmentId = "assortmentId";
                }

                public static class Warehouses {
                	public static String sql = "select w.warehouse as warehouseId from WarehouseItem wi"
                            + " left join Warehouse w on wi.warehouseId = w.id where itemId = ?";

                    public static String warehouseId = "warehouseId";
                }

                public static class CustomerItemID {
                	public static String customerItemId = "customerItemId";

                	public static String usergroupId = "userGroupId";

                    public static String sql = "select " + customerItemId + "," + usergroupId
                            + " from CustomerItem where itemId = ?";
                }

                public static class Price {
                	public static String listPriceGroupId = "listPriceGroupId";

                	public static String currencyCode = "currencyCode";

                	public static String resellPriceGroupId = "resellPriceGroupId";

                	public static String customerId = "customerId";

                	public static String priceListPrice = "priceListPrice";

                	public static String netListPrice = "netListPrice";

                	public static String sql = "select " 
                			+ "lp.priceGroupId as " + listPriceGroupId + ", "
                            + "lp.currencyCode as " + currencyCode + ", " 
                            + "rp.priceGroupId as " + resellPriceGroupId + ", " 
                            + "cid.customerId as "  + customerId  + ", "
                            + "dbo.GetNetListPrice(lp.amount, rp.amount, NULL, NULL) as " + priceListPrice + ", "
                            + "dbo.GetNetListPrice(lp.amount, rp.amount, cid.maxDiscount, cp.amount) as " + netListPrice + "	" 
                            + " from Item i " 
                            + "	left join Price lp " 
                            + "		on i.id = lp.itemId "
                            + "	left join Price rp " 
                            + "		on i.id = rp.itemId "
                            + "		and lp.currencyCode = rp.currencyCode" 
                            + " left join CustomerItemDiscount cid "
                            + "		on i.id = cid.itemId " 
                            + " left join CustomerPrice cp " 
                            + "		on i.id = cp.itemId "
                            + "		and cid.customerId = cp.customerId " 
                            + "		and lp.currencyCode = cp.currencyCode "
                            + "	where i.id=?";
                }

                public static class TaxPrice {
                	public static String listPriceGroupId = "listPriceGroupId";

                	public static String currencyCode = "currencyCode";

                	public static String resellPriceGroupId = "resellPriceGroupId";

                	public static String customerId = "customerId";

                	public static String taxPriceListPrice = "taxPriceListPrice";

                	public static String taxNetListPrice = "taxNetListPrice";

                	public static String countryCode = "countryCode";

                	public static String sql = "select " 
                			+ "lp.priceGroupId as " + listPriceGroupId + ", "
                            + "lp.currencyCode as " + currencyCode + ", "
                            + "rp.priceGroupId as " + resellPriceGroupId + ", "
                            + "cid.customerId as " + customerId + ", "
                            + "c.countryCode as " + countryCode + ", "
                            + "dbo.GetTaxPrice(lp.amount, rp.amount, NULL, NULL, tg.rate) as " + taxPriceListPrice + ", "
                            + "dbo.GetTaxPrice(lp.amount, rp.amount, cid.maxDiscount, cp.amount, tg.rate) as " + taxNetListPrice
                            + "	from Item i "
                            + "	left join Price lp "
                            + "		on i.id = lp.itemId "
                            + "	left join Price rp "
                            + "		on i.id = rp.itemId "
                            + "		and lp.currencyCode = rp.currencyCode"
                            + " left join CustomerItemDiscount cid "
                            + "		on i.id = cid.itemId "
                            + " left join CustomerPrice cp "
                            + "		on i.id = cp.itemId "
                            + "		and cid.customerId = cp.customerId "
                            + "		and lp.currencyCode = cp.currencyCode "
                            + " left join Country c "
                            + " 	on c.countryCode is not null "
                            + " left join ItemTaxGroup itg "
                            + " 	on i.id = itg.itemId "
                            + "	left join TaxGroup tg "
                            + " 	on tg.id = IsNull(itg.taxGroupId, (select defaultTaxGroupId from Country x where x.countryCode = c.countryCode)) "
                            + "	where i.id=? and tg.rate > 0";
                }

                public static class CustomerPrice {
                	public static String customerId = "customerId";

                	public static String amount = "amount";

                	public static String currencyCode = "currencyCode";

                	public static String sql = "select cp.customerId as " + customerId + "," 
                			+ " cp.amount as " + amount + ","
                            + " cp.currencyCode as " + currencyCode 
                            + " from CustomerPrice cp" 
                            + " inner join Item i"
                            + " 	on cp.itemId = i.id" 
                            + " where i.id = ?";
                }

                public static class TaxCustomerPrice {
                	public static String customerId = "customerId";

                	public static String taxPrice = "taxPrice";

                	public static String currencyCode = "currencyCode";

                	public static String countryCode = "countryCode";

                	public static String sql = "select cp.customerId as " + customerId + ", "
                            + " dbo.GetTaxPrice(NULL, NULL, NULL, cp.amount, isnull((select rate from TaxGroup inner join ItemTaxGroup on TaxGroup.id=ItemTaxGroup.taxGroupId where ItemTaxGroup.itemId=i.id),"
                            + "	(select rate from TaxGroup inner join Country on TaxGroup.countryCode=Country.countryCode where Country.defaultTaxGroupId=TaxGroup.id and TaxGroup.countryCode=tg2.countryCode))) as " + taxPrice + ", " 
                            + "	cp.currencyCode as " + currencyCode + ", " 
                            + " tg2.countryCode as " + countryCode 
                            + " from CustomerPrice cp " 
                            + "		inner join Item i " 
                            + " 	on cp.itemId=i.id "
                            + " left join ItemTaxGroup tg " 
                            + "		on i.id = tg.itemId " 
                            + " left join TaxGroup tg2 "
                            + " 	on tg2.countryCode in (select countryCode from Country) " + " where i.id = ?";
                }
            }
        }

        public static class Searching {
            public static class Item {
                static class UserAssortments {
                    static String sql = "select assortmentId from UserAssortment"
                            + " where userId = ? and userGroupId = ?";

                    static String assortmentId = "assortmentId";
                }

                public static class PassiveAttributes {
                    public static final String sqlHead = "                                                		"
                            + " select                                                       		"
                            + "     i.id,                                                    		"
                            + "     i.itemNumber,                                            		"
                            + "     i.hasSubItems,                                           		"
                            + "     i.isEmphasized,                                          		"
                            + "     tg2.rate,                                                 		"
                            + "     isnull(img.thumbImage,(select value from ApplicationData 		"
                            + "             where parameter = 'DefItemImageThumb'))          		"
                            + "         as imageThumb,                                       		"
                            + "     lp.amount as listPrice,                                  		"
                            + "     rp.amount as resellPrice,                                		"
                            + "     m.[key] as manufacturerId,                               		"
                            + "     coalesce(i.minQty, 1) as minQty,                         		"
                            + "     coalesce(i.modularQty, 1) as modularQty,                 		"
                            + "     i.isMvxConfigurable,                                     		"
                            + "     f.styleId,                                               		"
                            + "     i.supplierId,                                            		"
                            + "     b.[key] as brandId,                                  			"
                            + "     b.name as brandName,                                 			"
                            + "     it.description as description,                              	"
                            + "     mc.[key] as mainCategoryId,                              		"
                            + "     mct.name as mainCategoryName,                              		"
                            + "     m.name as manufacturerName,                              		"
                            + "     isnull(img.previewImage,(select value from ApplicationData 		"
                            + "             where parameter = 'DefItemImagePreview'))          		"
                            + "         as imagePreview,                                     		"
                            + " 	case when i.id in (select styleId from StyleRelation) 			"
                            + "			then 'Y' else 'N' end as isStyle, 							"
                            + " 	dbo.GetNetListPrice(lp.amount, rp.amount, 						"
                            + "			cid.maxDiscount, cp.amount) as netListPrice, 				"
                            + " 	dbo.GetTaxPrice(lp.amount, rp.amount, cid.maxDiscount, 			"
                            + " 		cp.amount, tg2.rate) as taxPrice, 							" 
                            + " 	uct.text as unit, 												"
                            + " 	uc.code as unitCode, 											" 
                            + " 	i.rating as itemRating,"
                            + "     citem.customerItemId as customerItemId"
                            + " from Item i                                                  		"
                            + " 	left join ItemTaxGroup tg 										" 
                            + "    		on i.id = tg.itemId 										"
                            + " 	left join TaxGroup tg2 											"
                            + "    		on tg2.id = IsNull(tg.taxGroupId, 							"
                            + "				(select defaultTaxGroupId 								"
                            + "					from Country where countryCode = ?)) 				"
                            + "     left join Price lp                                       		"
                            + "         on i.id = lp.itemId                                  		"
                            + "             and lp.priceGroupId = ? 								" 
                            + "				and lp.currencyCode = ?  								"
                            + "     left join Price rp                                       		"
                            + "         on i.id = rp.itemId                                  		"
                            + "             and rp.priceGroupId = ? 								" 
                            + "				and rp.currencyCode = ?  								"
                            + "     left join Manufacturer m                                 		"
                            + "         on i.manufacturerId = m.id                           		"
                            + "     left join StyleFeatureRelation f                         		"
                            + "         on i.id = f.styleId                                  		"
                            + " 	left join ItemImages img 								 		" 
                            + "			on i.itemNumber = img.itemNumber				 	 		"
                            + "			and not exists (select * from ItemImages img2 	 	 		"
                            + "				where img.id = img2.id and img.defaultImage ='N')		"
                            + " 	left join Brand b on b.id = i.brandId			 				" 
                            + " 	left join ItemText it 											"
                            + "			on it.itemId = i.id 										" 
                            + " 			and it.languageCode = ?									"
                            + "		left join CustomerItemDiscount cid								" 
                            + "    		on	i.id = cid.itemId 										"
                            + "				and cid.customerId = ? 									" 
                            + " 	left join Code uc 												"
                            + "			on i.unitCodeId = uc.id 									" 
                            + " 	left join CodeText uct 											"
                            + "			on uc.id = uct.codeId										" 
                            + "				and uct.languageCode = ? 								"
                            + " 	left join Category mc 											" 
                            + "			on i.mainCategoryId = mc.id 								"
                            + " 	left join CategoryText mct 										" 
                            + "			on mc.id = mct.categoryId 									"
                            + "				and mct.languageCode = ? 								" 
                            + " 	left join CustomerPrice cp 										"
                            + "    		on i.id = cp.itemId 										" 
                            + "       		and cp.customerId = ? 									"
                            + "       		and cp.currencyCode = ? 								" 
                            + "		left join CustomerItem citem"
                            + "			on i.id = citem.itemId" 
                            + "				and citem.userGroupId = ?"
                            + " where i.isActive = 'Y'                                       		"
                            + "     and i.typeCodeId =                                       		"
                            + "         (select id from Code where [key] = 'normalItemCode') 		" 
                            + " and i.id in (";

                    public static final String sqlTail = ")";

                    public static final String id = "id";

                    public static final String itemNumber = "itemNumber";

                    public static final String hasSubItems = "hasSubItems";

                    public static final String isEmphasized = "isEmphasized";

                    public static final String normal = "normal";

                    public static final String rate = "rate";

                    public static final String imageThumb = "imageThumb";

                    public static final String listPrice = "listPrice";

                    public static final String resellPrice = "resellPrice";

                    public static final String manufacturerId = "manufacturerId";

                    public static final String minQty = "minQty";

                    public static final String modularQty = "modularQty";

                    public static final String isMvxConfigurable = "isMvxConfigurable";

                    public static final String styleId = "styleId";

                    public static final String supplierId = "supplierId";

                    // Additional passive attributes for version 13.1
                    public static final String brandId = "brandId";

                    public static final String brandName = "brandName";

                    public static final String description = "description";

                    public static final String imagePreview = "imagePreview";

                    public static final String isStyle = "isStyle";

                    public static final String mainCategoryId = "mainCategoryId";

                    public static final String mainCategoryName = "mainCategoryName";

                    public static final String manufacturerName = "manufacturerName";

                    public static final String netListPrice = "netListPrice";

                    public static final String taxPrice = "taxPrice";

                    public static final String unit = "unit";

                    public static final String unitCode = "unitCode";

                    public static final String itemRating = "itemRating";

                    public static final String customerItemId = "customerItemId";
                }
            }
        }
    }

    public static class Index {
        public static final String entryType = "entryType";

        public static final String item = "item";

        public static final String category = "category";

        public static final String categoryBaseData = "categoryBaseData";

        public static final String settings = "settings";

        public class Item {
            public static final String itemId = "itemId";

            public static final String itemNumber = "itemNumber";

            public static final String manufacturerId = "manufacturerId";

            public static final String manufacturerName = "manufacturerName";

            public static final String categoryPath = "categoryPath";

            public static final String mainCategoryNamePrefix = "mainCategoryName_";

            public static final String namePrefix = "name_";

            public static final String descriptionPrefix = "description_";

            public static final String fullTextPrefix = "fullText_";

            public static final String assortmentId = "assortmentId";

            public static final String warehouseId = "warehouseId";

            public static final String nameTokenizedPrefix = "nameTokenized_";

            // Additional field for version 13.1
            public static final String brandId = "brandId";

            public static final String supplierId = "supplierId";

            public static final String customerItemIdPrefix = "customerItemId_";

            public static final String price = "price";

            public static final String pricePrefix = price + "_";

            public static final String taxPrice = "taxPrice";

            public static final String taxPricePrefix = taxPrice + "_";

            public static final String customerItemIdTokenizedPrefix = "customerItemIdTokenized_";
        }

        static class CategoryBaseData {
            static String categoryPath = "categoryPath";

            static String categoryKey = "categoryKey";

            static String categoryId = "categoryId";
        }

        static class Settings {
            static String warehousing = "warehousing";
        }
    }

    public static class Request {
        public static class Param {
            public static final String param = "param";

            public static final String name = "name";

            public static final String currencyCode = "@CurrencyCode";

            public static final String languageCode = "@LanguageCode";

            public static final String mvxWarehouse = "@MvxWarehouse";

            public static final String shippingCountryCode = "@ShippingCountryCode";

            public static final String userGroupId = "@UserGroupID";

            public static final String userId = "@UserID";

            public static final String listPriceGroup = "@ListPriceGroup";

            public static final String resellPriceGroup = "@ResellPriceGroup";

            public static final String parentCategoryId = "ParentCategoryID";

            public static final String fullText = "@FullText";

            // Added parameters for version 13.1
            public static final String searchRequestOrigin = "@SearchRequestOrigin";

            public static final String quickSearchString = "@QuickSearchString";

            public static final String itemNumber = "@ItemNumber";

            public static final String itemName = "@ItemName";

            public static final String categoryKeySearch = "@categoryKeySearch";

            public static final String manufacturerId = "@ManufacturerID";

            public static final String brandId = "@brandID";

            public static final String supplierId = "@supplierId";

            public static final String customerItemID = "@CustomerItemID";

            public static final String minPrice = "@MinPrice";

            public static final String maxPrice = "@MaxPrice";

            public static final String b2cMinPrice = "@netListPriceGe";

            public static final String b2cMaxPrice = "@netListPriceLe";

            public static final String alternateCurrencyCode = "@AlternateCurrencyID";

            public static final String alternateExchangeRate = "altExchangeRate";

            public static final String exchangeRate = "exchangeRate";

            public static final String executeIncludeTax = "executeIncludeTax";

            public static final String netListPriceNotNull = "@netListPriceNotNull";

            public static final String currencyDecimal = "@CurrencyDecimal";

            public static final String includeCustomerItemID = "@IncludeCustomerItemID";
			
			public static final String wildcardSearch = "@WildCardSearch";
			
			public static final String flagCampaign = "@flagCampaign";
        }

        static class Binding {
            static String binding = "binding";

            static String attribute = "attribute";

            static String value = "value";

            static String fullText = "FullText";

            static String name = "Name";

            static String itemId = "ItemID";

            static String categoryId = "CategoryID";

            static String manufacturerId = "ManufacturerID";
        }

        static class Paging {
            static String paging = "paging";

            static String limit = "limit";

            static String offset = "offset";
        }

        static class Order {
            static String order = "order";

            static String attribute = "attribute";

            static String direction = "direction";
        }

        public static class SearchOrigin {
            public static final String B2C = "b2cSearchWindow";

            public static final String B2B_FILTER = "b2bFilter";

            public static final String B2B_QUICKSEARCH = "b2bQuickSearch";
        }
    }

    public static class Response {
        public static class ItemList {
            public static final String itemId = "ItemID";

            public static final String name = "Name";

            public static final String description = "Description";

            public static final String manufacturerName = "ManufacturerName";

            public static final String mainCategoryName = "MainCategoryName";

            public static final String hasSubItems = "HasSubItems";

            public static final String imageThumb = "ImageThumb";

            public static final String isEmphasized = "IsEmphasized";

            public static final String itemCode = "ItemCode";

            public static final String itemTax = "ItemTax";

            public static final String listPrice = "ListPrice";

            public static final String resellPrice = "ResellPrice";

            public static final String manufacturerId = "ManufacturerID";

            public static final String minimumQty = "MinimumQty";

            public static final String modularQty = "ModularQty";

            public static final String mvxConfigurable = "MvxConfigurable";

            public static final String styleId = "StyleID";

            public static final String supplierId = "SupplierID";

            public static final String mainIdConstraintGenerated = "main_id_ConstraintGenerated";

            // Additional response fields for version 13.1
            public static final String brandId = "BrandID";

            public static final String brandName = "BrandName";

            public static final String imagePreview = "ImagePreview";

            public static final String isStyle = "IsStyle";

            public static final String mainCategoryId = "MainCategoryID";

            public static final String netListPrice = "NetListPrice";

            public static final String taxPrice = "TaxPrice";

            public static final String unit = "Unit";

            public static final String unitCode = "UnitCode";

            public static final String rating = "Rating";

            public static final String customerItemId = "CustomerItemID";
        }   
    }

    public static class Application {
        public static class Type {
            public static final String b2b = "B2B";

            public static final String b2c = "B2C";
        }
    }
}
