/*
 * Created on 24-02-2006
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.DateFormat;
import java.util.Date;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;
import javax.xml.stream.XMLStreamException;
import javax.xml.transform.TransformerException;

import org.apache.commons.transaction.file.FileResourceManager;
import org.apache.commons.transaction.file.ResourceManagerSystemException;
import org.apache.commons.transaction.util.FileHelper;
import org.apache.commons.transaction.util.Log4jLogger;
import org.apache.log4j.Logger;
import org.w3c.dom.Element;

import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntime;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.custom.pim.CatalogImageException;
import com.intentia.iec.pipeline.runtime.custom.pim.CatalogIntegrationException;
import com.intentia.iec.pipeline.runtime.custom.pim.CatalogIntegrator;
import com.intentia.iec.pipeline.runtime.custom.pim.CatalogParserException;
import com.intentia.iec.pipeline.runtime.custom.pim.ImageFileHandler;
import com.intentia.iec.pipeline.runtime.stage.utils.ApplicationMail;
import com.intentia.iec.pipeline.runtime.stage.utils.ApplicationParameter;
import com.intentia.iec.pipeline.runtime.stage.utils.FileUtility;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;
import com.intentia.iec.util.FastStringBuffer;
import com.intentia.iec.util.XMLDateFormat;

/**
 * <code>PIMStage</code> is responsible for the integration of Product Catalog
 * Management (PCM) XML files. The integration of PCM catalogs and the e-Sales
 * application is performed by a 2 stage process:
 * <ol>
 * <li>The PCM catalog is being published for integration with e-Sales by a PCM
 * employee from within the PCM application. The catalog publication changes are
 * written as a delta.xml file.</li>
 * <li>A scheduled job in the e-Sales application searches for new delta.xml
 * files in the PCM 'PublishedData/e-Sales' publication folder. Only delta.xml
 * files newer than the last integrated delta.xml file from
 * 'publishedData/e-Sales' are read when integrating catalog changes to e-Sales.
 * </ol>
 * 
 * <p>
 * The scheduled job PIMCatalog.Integrate contains this custom stage
 * <code>PIMStage</code>, which performs the integration of the delta.xml
 * files. The integration is performed as follows:
 * 
 * <ul>
 * <li><code>PIMStage</code> searches in the PCM publication folder
 * (...publishedData/e-Sales) for delta.xml files newer than latest integrated
 * delta.xml file</li>
 * <li>PIMStage attempts integrating the changes in all new delta.xml file in
 * order of their creation date - older files first. For each delta.xml file it
 * does the following:
 * <ul>
 * <li>Starts a new transaction manually</li>
 * <li>Attempts integrating the changes in the delta.xml file (and images) by
 * calling business object methods to update the e-Sales database.</li>
 * <li>If no problems occure (e.g. no exceptions are caught) then the
 * transaction is committed (and thereby all changes are committed to the
 * e-Sales database), and a row is added to the PIMCatalog table indicating the
 * successfull integration.</li>
 * <li>If problems occure (an exception is caught) then the transaction is
 * rolled back and thereby no changes from delta.xml will be applied to the
 * e-Sales database. Rows are added to the PIMCatalog and PIMCatalogError tables
 * indicating the unsuccessfull integration and the caught exception.
 * </ul>
 * </li>
 * </ul>
 * </p>
 * 
 * 
 * @author PEDJES0
 */
public class PIMStage extends AbstractPipelineStage {
    protected static final Logger LOG = Logger.getLogger(PIMStage.class);

    private String baseFolder = null;

    public static final String STATUS_INTEGRATED = "IntegratedPIMCatalog";

    public static final String STATUS_FAILED = "FailedPIMCatalog";

    public static final String ERR_PARSE = "ParserPIMCatErr";

    public static final String ERR_IMAGE = "ImagePIMCatErr";

    public static final String ERR_INVALID = "InvalidPIMCatErr";

    public static final String ERR_INTERNAL = "InternalPIMCatErr";

    public static final String PIPELINE_ARG = "latestDate";

    public static final String PIM_COPYIMAGES = "PIM.copyImages";

    public static final String IMAGE_WORK_FOLDER = "e-Sales" + File.pathSeparator + "pcm" + File.pathSeparator
            + "images";

    private static final String APP_DETAILS_ROOT_FOLDER = "RootFolder";

    /*
     * (non-Javadoc)
     * 
     * @see com.intentia.iec.pipeline.runtime.AbstractPipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
     */
    // TODO This method should not throw any exceptions
    public final void execute(final PipelineContext context) throws PipelineRuntimeException {
        // Get the imageCatalogPrefix which is expected to be removed from the
        // relative image paths. Currently the application property value is set
        // to file:///files/
        String imageCatalogPrefix = CustomStagesHelper.getKeyValue("PIM.imageCatalogPrefix");
        if (imageCatalogPrefix == null) {
            sendMail("The application property PIM.imageCatalogPrefix was not available!");
            throw new PipelineRuntimeException("The application property PIM.imageCatalogPrefix was not available!");
        }

        // Get the copyImages PIM Application property which decides whether the
        // PIM images are
        // to be copied physically
        String copyImages = CustomStagesHelper.getKeyValue("PIM.copyImages");
        if (copyImages == null) {
            sendMail("The application property PIM.copyImages was not available!");
            throw new PipelineRuntimeException("The application property PIM.copyImages was not available!");
        }

        File baseDir = getBaseDir();
        File imageSrcDir = new File(baseDir, "files");
        String imageDestination = getRootFolderPath();
        // TODO SEND MAIL on exception
        File imageTargetDir = new File(imageDestination);

        // Search for delta.xml files.
        String[] deltaFiles = null;
        Date latest = (Date) context.get(PIPELINE_ARG);
        if (latest != null) {
            deltaFiles = FileUtility.searchFiles(baseDir, "**/delta.xml", latest);
        } else {
            if (LOG.isDebugEnabled()) {
                FastStringBuffer debug = new FastStringBuffer("Pipeline context parameter '");
                debug.append(PIPELINE_ARG);
                debug.append("' is not present. Searching for delta.xml files with no date restriction");
                LOG.debug(debug.toString());
            }
            deltaFiles = FileUtility.searchFiles(baseDir, "**/delta.xml");
        }

        if (deltaFiles == null || deltaFiles.length == 0) {
            // Detailed logging to enable error determination
            if (LOG.isDebugEnabled()) {
                FastStringBuffer logStr = new FastStringBuffer();
                if (latest == null) {
                    logStr.append("No 'delta.xml' file ");
                } else {
                    logStr.append("No 'delta.xml' file newer than '");
                    logStr.append(latest.toString());
                    logStr.append("'");
                }
                logStr.append(" found in folder '");
                logStr.append(baseDir.getAbsolutePath());
                logStr.append("'. Stopping execution.");
                LOG.debug(logStr.toString());
            }
            return;
        }

        String strHandleMultipleCatalogs = null;
        try {
            strHandleMultipleCatalogs = CustomStagesHelper.getKeyValue("PIM.handleMultipleCatalogs");
        } catch (PipelineRuntimeException e) {
            sendMail("Error fetching application property 'PIM.handleMultipleCatalogs': " + e.getMessage());
            throw e;
        }
        if (strHandleMultipleCatalogs == null) {
            sendMail("Application property 'PIM.handleMultipleCatalogs' not existing");
            throw new PipelineRuntimeException("Application property 'PIM.handleMultipleCatalogs' not existing");
        }

        boolean multiCatalogs = Boolean.valueOf(strHandleMultipleCatalogs).booleanValue();
        String genVisCatalogID = null;
        if (multiCatalogs) {
            try {
                genVisCatalogID = ApplicationParameter.getValue("GenVisibilityForCatalogID");
            } catch (PipelineRuntimeException e) {
                sendMail("Error fetching Application Detail when preparing for catalog integrations");
                throw e;
            } catch (ResultsetException e) {
                sendMail("Error fetching Application Detail when preparing for catalog integrations");
                throw new PipelineRuntimeException(e);
            }
        }

        int tranTimeOut = 0;
        try {
            // Read the transaction timeout configured in the
            String strTimeOut = CustomStagesHelper.getKeyValue("PIM.transactionTimeOut");
            tranTimeOut = Integer.parseInt(strTimeOut);
        } catch (PipelineRuntimeException e) {
            String message = "Error fetching Application Property 'PIM.transactionTimeOut'"
                    + " when preparing for catalog integrations";
            sendMail(message);
            throw e;
        } catch (NumberFormatException e) {
            sendMail("Application Property 'PIM.transactionTimeOut' not an whole number value!");
            throw e;
        }

        File deltaFile = null;
        Date modified = null;
        for (int i = 0; i < deltaFiles.length; i++) {
            deltaFile = null;
            modified = null;
            String catalogName = null;
            UserTransaction userTran = getUserTransaction();

            try {
                // Use userTran object to call transaction methods
                beginTransaction(userTran, tranTimeOut);

                deltaFile = new File(baseDir, deltaFiles[i]);
                modified = new Date(deltaFile.lastModified());

                ImageFileHandler imageHandler = null;

                if ("true".equalsIgnoreCase(copyImages)) {
                    imageHandler = new ImageFileHandler(imageSrcDir, imageTargetDir);
                    LOG.debug("PIM.copyImages = " + copyImages);
                } else {
                    LOG.debug("PIM.copyImages = " + copyImages);
                    imageHandler = new ImageFileHandler(null, null) {
                        public final void copyImage(final String path) {
                            // DO NOTHING
                            LOG.debug("Do nothing inside copyImages() method");
                        }
                    };
                }

                CatalogIntegrator integrator = new CatalogIntegrator(imageCatalogPrefix, multiCatalogs,
                        genVisCatalogID, imageHandler);
                catalogName = integrator.integrateCatalogXML(deltaFile);

                // Commit transaction before actually setting the status.
                // This because status must be set in own transaction.
                commitTransaction(userTran);

                setStatus(catalogName, deltaFile.getAbsolutePath(), modified, STATUS_INTEGRATED);
            } catch (CatalogIntegrationException e) {
                rollbackTransaction(userTran);
                sendMail(catalogName, deltaFile.getAbsolutePath());
                setStatus(catalogName, deltaFile.getAbsolutePath(), modified, STATUS_FAILED, ERR_INTERNAL, e);
            } catch (XMLStreamException e) {
                rollbackTransaction(userTran);
                sendMail(catalogName, deltaFile.getAbsolutePath());
                setStatus(catalogName, deltaFile.getAbsolutePath(), modified, STATUS_FAILED, ERR_PARSE, e);
            } catch (CatalogParserException e) {
                rollbackTransaction(userTran);
                sendMail(catalogName, deltaFile.getAbsolutePath());
                setStatus(catalogName, deltaFile.getAbsolutePath(), modified, STATUS_FAILED, ERR_INVALID, e);
            } catch (CatalogImageException e) {
                rollbackTransaction(userTran);
                sendMail(catalogName, deltaFile.getAbsolutePath());
                setStatus(catalogName, deltaFile.getAbsolutePath(), modified, STATUS_FAILED, ERR_IMAGE, e);
            }
        }
    }

    /**
     * Get Root Folder Path from Application Data.
     * @throws PipelineRuntimeException
     */
    private static String getRootFolderPath() throws PipelineRuntimeException {

    	String imageDestination = getValueFromApplicationData(APP_DETAILS_ROOT_FOLDER);

        if (null == imageDestination) {
            FastStringBuffer msg = new FastStringBuffer(100);
            msg.append("Missing application data: ").append(APP_DETAILS_ROOT_FOLDER);
            throw new PipelineRuntimeException(msg.toString());
        }
        LOG.debug("Root Folder Path: " + imageDestination.toString());
        return imageDestination;
    }
    
    private static UserTransaction getUserTransaction() throws PipelineRuntimeException {
        InitialContext initCtx;
        UserTransaction userTran;
        try {
            initCtx = new InitialContext();
            userTran = (UserTransaction) initCtx.lookup("java:comp/UserTransaction");
            return userTran;
        } catch (NamingException e) {
            throw new PipelineRuntimeException("Error when trying to manually initiate a transaction", e);
        }
    }

    private static void beginTransaction(final UserTransaction userTran, final int tranTimeOut)
            throws PipelineRuntimeException {
        try {
            userTran.setTransactionTimeout(tranTimeOut);
            userTran.begin();
        } catch (NotSupportedException e) {
            throw new PipelineRuntimeException("Error initiating transaction", e);
        } catch (SystemException e) {
            throw new PipelineRuntimeException("Error initiating transaction", e);
        }
    }

    private static void beginTransaction(final UserTransaction userTran) throws PipelineRuntimeException {
        try {
            userTran.begin();
        } catch (NotSupportedException e) {
            throw new PipelineRuntimeException("Error initiating transaction", e);
        } catch (SystemException e) {
            throw new PipelineRuntimeException("Error initiating transaction", e);
        }
    }

    private static void commitTransaction(final UserTransaction userTran) throws PipelineRuntimeException {
        try {
            userTran.commit();
        } catch (SecurityException e) {
            sendMail("Fatal error committing the manually initiated transaction");
            throw new PipelineRuntimeException("Error initiating transaction", e);
        } catch (IllegalStateException e) {
            sendMail("Fatal error committing the manually initiated transaction");
            throw new PipelineRuntimeException("Error initiating transaction", e);
        } catch (RollbackException e) {
            sendMail("Fatal error committing the manually initiated transaction");
            throw new PipelineRuntimeException("Error initiating transaction", e);
        } catch (HeuristicMixedException e) {
            sendMail("Fatal error committing the manually initiated transaction");
            throw new PipelineRuntimeException("Error initiating transaction", e);
        } catch (HeuristicRollbackException e) {
            sendMail("Fatal error committing the manually initiated transaction");
            throw new PipelineRuntimeException("Error initiating transaction", e);
        } catch (SystemException e) {
            sendMail("Fatal error committing the manually initiated transaction");
            throw new PipelineRuntimeException("Error initiating transaction", e);
        }
    }

    private static void rollbackTransaction(final UserTransaction userTran) throws PipelineRuntimeException {
        try {
            userTran.rollback();
        } catch (IllegalStateException e) {
            sendMail("Fatal error rolling back the manually initiated transaction");
            throw new PipelineRuntimeException("Error initiating transaction", e);
        } catch (SecurityException e) {
            sendMail("Fatal error rolling back the manually initiated transaction");
            throw new PipelineRuntimeException("Error initiating transaction", e);
        } catch (SystemException e) {
            sendMail("Fatal error rolling back the manually initiated transaction");
            throw new PipelineRuntimeException("Error initiating transaction", e);
        }
    }

    private static FileResourceManager getFileResourceManager() throws PipelineRuntimeException {
        String imageDestination = CustomStagesHelper.getKeyValue("Images.RootFolder");
        File dest = new File(imageDestination);
        File workDir = new File(System.getProperty("java.io.tmpdir"), IMAGE_WORK_FOLDER);
        FileResourceManager frm = new FileResourceManager(dest.getAbsolutePath(), workDir.getAbsolutePath(), false,
                new Log4jLogger(LOG));
        try {
            frm.start();
        } catch (ResourceManagerSystemException e) {
            sendMail("Fatal error ");
            throw new PipelineRuntimeException("Error initiating transaction", e);
        }
        // TODO set default transaction timeout

        return frm;
    }

    private void setStatus(final String catalogName, final String fileName, final Date modified, final String status)
            throws PipelineRuntimeException {
        setStatus(catalogName, fileName, modified, status, null, null);
    }

    private void setStatus(final String catalogName, final String fileName, final Date modified, final String status,
            final String errorCodeID, final Exception ex) throws PipelineRuntimeException {
        XMLRequest request = null;
        try {
            request = new XMLRequest("<request></request>");
            XMLRequestHelper requestHelper = new XMLRequestHelper(request);

            Element entity = requestHelper.addEntity();
            requestHelper.setAttribute(entity, "Name", (catalogName != null ? catalogName : "Unknown"));
            requestHelper.setAttribute(entity, "FilePath", fileName);
            requestHelper.setAttribute(entity, "StatusID", status);
            DateFormat formatter = new XMLDateFormat();
            requestHelper.setAttribute(entity, "FileModified", formatter.format(modified));
            if (errorCodeID != null) {
                requestHelper.setAttribute(entity, "ErrorCodeID", errorCodeID);

                StringWriter strWriter = new StringWriter();
                PrintWriter writer = new PrintWriter(strWriter);
                ex.printStackTrace(writer);
                requestHelper.setAttribute(entity, "ErrorCause", strWriter.toString());
            }
        } catch (TransformerException e) {
            // We expect this to never happen. If the TransformerException
            // is caught then a programming error exists! Even then still
            // send a mail.
            FastStringBuffer buffer = new FastStringBuffer();
            buffer.append("Failed creating request for inserting a ");
            if (errorCodeID != null) {
                buffer.append("successfull");
            } else {
                buffer.append("error");
            }
            buffer.append("status into the Catalog Integration data for the catalog ");
            buffer.append(catalogName);
            sendMail(buffer.toString());
            throw new PipelineRuntimeException(e);
        }

        PipelineContext context = new PipelineContext("PIMCatalog", "Insert");
        context.setRequest(request);

        final String pipelineClass = "com.intentia.iec.runtime.pipeline.PIMCatalog.Insert";
        if (LOG.isDebugEnabled()) {
            LOG.debug("Initiating pipeline '" + pipelineClass + "'");
        }

        Class runtimeClass;
        PipelineRuntime pipeline;
        try {
            runtimeClass = Class.forName(pipelineClass);
            pipeline = (PipelineRuntime) runtimeClass.newInstance();
        } catch (ClassNotFoundException e) {
            throw new PipelineRuntimeException("Could not find class '" + pipelineClass + "'", e);
        } catch (InstantiationException e) {
            throw new PipelineRuntimeException("Could not instantiate class '" + pipelineClass + "'", e);
        } catch (IllegalAccessException e) {
            throw new PipelineRuntimeException("Illegal access to class '" + pipelineClass + "'", e);
        }

        UserTransaction userTran = getUserTransaction();
        beginTransaction(userTran);
        try {
            pipeline.execute(context);
            commitTransaction(userTran);
        } catch (PipelineRuntimeException e) {
            rollbackTransaction(userTran);
            sendMail("Failed updating the Catalog Integration data for catalog " + catalogName);
            throw e;
        }
    }

    /**
     * Method necessary for unit test. This because the 'baseFolder' depends on
     * the folder in which the esa-custom-stages project is checked out into,
     * which mean that it is not configurable as a static application property.
     * 
     * @param baseFolder
     *            Base folder to find PIM delta publications in.
     */
    public final void setBaseFolder(final String baseFolder) {
        this.baseFolder = baseFolder;
    }

    /*
     * Returns the value of the base folder in which delta.xml files are found,
     * e.g. '.../PublishedData/e-Sales'. The base folder is read from
     * application property PIM.publishFolder unless "overwritten" by a call of
     * #setBaseFolder().
     */
    private File getBaseDir() throws PipelineRuntimeException {
        if (baseFolder == null) {
            baseFolder = CustomStagesHelper.getKeyValue("PIM.publishFolder");
        }
        return new File(baseFolder);
    }

    private static void sendMail(final String catalogName, final String fileName) {

        try {
            FastStringBuffer subject = new FastStringBuffer("Integration of Catalog '");
            subject.append(catalogName);
            subject.append("' failed!");

            FastStringBuffer body = new FastStringBuffer("Integration of the catalog '");
            body.append(catalogName);
            body.append("' in the file '");
            body.append(fileName != null ? fileName : "Unknown");
            body.append("' failed!\r\n\r\n");

            String applicationURL = ApplicationParameter.getValue("ApplicationURL");
            if (applicationURL != null) {
                body.append(applicationURL);
                body.append("/esa-bc/PIMCatalogDetails.jsp");
            }

            String receiver = ApplicationParameter.getValue("MailReceiverForCatalogError");
            ApplicationMail.send(receiver, subject.toString(), body.toString());
        } catch (PipelineRuntimeException e) {
            LOG.error("Failed sending error mail uppon failed catalog integration!", e);
        } catch (ResultsetException e) {
            LOG.error("Failed sending error mail uppon failed catalog integration!", e);
        }
    }

    private static void sendMail(final String messagePart) {
        try {
            String subject = "Unexpected error during catalog integration!";

            FastStringBuffer body = new FastStringBuffer("Internal error!\r\n");
            body.append(messagePart);
            body.append("\r\n\r\n");

            String applicationURL = ApplicationParameter.getValue("ApplicationURL");
            if (applicationURL != null) {
                body.append(applicationURL);
                body.append("/esa-bc/PIMCatalogs.jsp");
            }

            String receiver = ApplicationParameter.getValue("MailReceiverForCatalogError");
            ApplicationMail.send(receiver, subject, body.toString());
        } catch (PipelineRuntimeException e) {
            LOG.error("Failed sending error mail uppon failed catalog integration!", e);
        } catch (ResultsetException e) {
            LOG.error("Failed sending error mail uppon failed catalog integration!", e);
        }
    }

    public static void copyImages(File publishFolder) throws CatalogImageException {
        // TODO Add some transactional behaviour
        try {
            File source = new File(publishFolder, "files");
            String imageDestination = getValueFromApplicationData(APP_DETAILS_ROOT_FOLDER);
            File dest = new File(imageDestination);
            FileHelper.copyRec(source, dest);
        } catch (IOException e) {
            throw new CatalogImageException(e);
        }
    }

	private static String getValueFromApplicationData(String pParamName) {

		String paramValue;

		SearchPipelineExecuter spe = new SearchPipelineExecuter(
        		ConstantsForSales.PIPELINE_PACKAGE, ConstantsForSales.APPLICATION_DATA,
        		ConstantsForSales.APPLICATION_DATA_DETAILS);

		spe.setParam("param", pParamName);

		try {
			XMLResultset rs = spe.execute();
			rs.moveFirst();
			paramValue = rs.getString("ParameterValue");
		} catch (PipelineRuntimeException e) {
			paramValue = "";
		} catch (ResultsetException e) {
			paramValue = "";
		}

		return paramValue;

	}

}
