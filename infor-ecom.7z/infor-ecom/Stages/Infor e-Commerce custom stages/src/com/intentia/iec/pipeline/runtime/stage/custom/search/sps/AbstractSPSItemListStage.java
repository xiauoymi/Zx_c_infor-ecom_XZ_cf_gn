package com.intentia.iec.pipeline.runtime.stage.custom.search.sps;

import org.apache.log4j.Logger;
import org.apache.lucene.index.Term;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.search.AbstractItemListStage;
import com.intentia.iec.pipeline.runtime.stage.custom.search.CachedChainedFilter;
import com.intentia.iec.pipeline.runtime.stage.custom.search.CachedTermsFilter;

/**
 * Abstract class for SPSItemListStage. Refactored the class so that some objects will not have to be instantiated.
 *
 */
public abstract class AbstractSPSItemListStage extends AbstractItemListStage{
	
	private static final Logger LOG = Logger.getLogger(AbstractSPSItemListStage.class);
	
	 /**
     * Add filters specific to spare parts search. This may include searching of child spare parts.
     */
    protected void addFilters(final CachedChainedFilter filterChainCached) throws PipelineRuntimeException {

        if (request instanceof SPSRequest) {
            // for now, use item number as search parameter
        	SPSRequest req = (SPSRequest) request;            
            
            if (req.getChildItemSearchString() != null && !"empty".equals(req.getChildItemSearchString())) {
            	String parentItem = req.getChildItemSearchString();
            	
                StringBuilder logInfo = new StringBuilder(100);

                if (parentItem != null) {
                    Term parentItemTerm = new Term(SPSStrings.Index.Item.parentItem, parentItem.toLowerCase());
                    filterChainCached.add(new CachedTermsFilter(parentItemTerm));
                    logInfo.append("\n\t<parentItem><![CDATA[").append(parentItem).append("]]></parentItem>");
                    
                    LOG.info(logInfo.toString());
                }
            }           	
        }
        super.addFilters(filterChainCached);
    }
}
