/*
 * 
 */
package com.intentia.iec.pipeline.runtime.custom.pim;

import java.io.File;
import java.io.IOException;

import org.apache.commons.transaction.util.FileHelper;

/**
 * @author pedjes0
 * 
 */
public class ImageFileHandler {

    private File imageBaseDir;

    private File imageTargetDir;

    /**
     * 
     */
    public ImageFileHandler(final File imageSrcDir, final File imageDestDir) {
        this.imageBaseDir = imageSrcDir;
        this.imageTargetDir = imageDestDir;
    }

    public void copyImage(final String path) throws CatalogImageException {
        File destination = new File(imageTargetDir, path);

        try {
            createParent(destination);
            FileHelper.copy(new File(imageBaseDir, path), destination);
        } catch (IOException e) {
            throw new CatalogImageException(e);
        }
    }

    public void deleteImage(final String path) {
        File destination = new File(imageTargetDir, path);
        FileHelper.removeRec(destination);
    }

    private void createParent(final File destination) throws IOException {
        if (destination.getParentFile() != null) {
            if (destination.getParentFile().exists()) {
                return;
            }
            destination.getParentFile().mkdirs();
        }
    }

}
