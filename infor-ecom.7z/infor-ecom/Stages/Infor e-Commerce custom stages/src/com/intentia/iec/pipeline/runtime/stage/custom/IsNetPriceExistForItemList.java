package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.Decimal;

public class IsNetPriceExistForItemList implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(IsNetPriceExistForItemList.class);

    private static String List_Price = "ListPrice";

    private static String Net_List_Price = "NetListPrice";

    public IsNetPriceExistForItemList() {
        super();
    }

    public void execute(PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("Inside IsNetPriceExistForItemList.execute()......");

        if (!(context.getResponse() instanceof XMLResultset)) {
            throw new PipelineRuntimeException("Contained response object MUST be of type 'XMLResultset'!");
        }

        XMLResultset response = (XMLResultset) context.getResponse();

        try {
            // loop over <item>
            response.beforeFirst();
            while (response.moveNext()) {

                BigDecimal netListPrice = response.getDecimal(Net_List_Price);

                if (netListPrice != null && netListPrice.doubleValue() >= 0) {
                    LOG.debug("Inside IsNetPriceExistForItemList ,  netListPrice = " + netListPrice.toPlainString());
                    response.setString(List_Price, Decimal.toString(netListPrice));
                }

            }// end of while(xmlItem.moveNext())
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Failed to get values from result set!", e);
        }

    }

}
