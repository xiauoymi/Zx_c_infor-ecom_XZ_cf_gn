package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;

import com.ibm.icu.text.NumberFormat;
import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.custom.promotion.takeaway.PromotionTakeAway;
import com.intentia.iec.pipeline.runtime.stage.custom.promotion.takeaway.TakeAway;
import com.intentia.iec.pipeline.runtime.stage.custom.promotion.takeaway.TakeAwayConstant;
import com.intentia.iec.pipeline.runtime.stage.custom.promotion.takeaway.TakeAwayFactory;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;
import com.intentia.iec.util.FastStringBuffer;


public class PromotionTakeAwayEngine implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(PromotionTakeAwayEngine.class);

    private String _languageCodeParam = null;
    private String selectedCCPromotionID = null;
    private Map<String, String> itemDetailsMap = null;
    private String orderLinePromoIdList = null;
    private Map<String, List<String>> promotionalItemsMap = null;
    private List<PromotionTakeAway> lineTakeAwayList = null;
    private List<PromotionTakeAway> headerTakeAwayList = null;
    
    private PipelineContext context;
	private XMLResultset xmlResponse;
	private XMLRequestHelper xmlHelper;
	 
	private XMLRequest xmlRequest;
	private XMLResultset resultSet;
	private BigDecimal exchangeRate;
	//private NodeList orderLineNodeList;
    
	private boolean hasPromotion = false;
	
    public PromotionTakeAwayEngine() {
        super();
    }

    public void execute(PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("Inside PromotionTakeAwayEngine.execute()");

        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
        this.context = context;
        Parameters contextParams = CustomStagesHelper.getRequestParameters(context);
        
        Document request;
        
        try {
            CustomStagesHelper.extractRequestParameters(CustomStagesHelper.getRequest(context));
            this.xmlRequest = (XMLRequest) context.getRequest();
            this.xmlResponse = (XMLResultset) context.getResponse();
            request = this.xmlRequest.getRequestDoc();
            
            this.xmlHelper = new XMLRequestHelper(request);
            this._languageCodeParam = getStringFromParameter(ConstantsForSales.LANGUAGE_CODE_SQL_PARAM, contextParams);
            this.selectedCCPromotionID = getStringFromParameter(TakeAwayConstant.SELECTED_PROMOTIONID_PARAM, contextParams);
            this.exchangeRate = getParameterAsDecimal(getStringFromParameter(ConstantsForSales.EXCHANGE_RATE_PARAM, contextParams));            

            this.itemDetailsMap = new HashMap<String, String>();
            
            this.itemDetailsMap.put(TakeAwayConstant.LANGUAGE_CODE_PARAM, this._languageCodeParam);
            this.itemDetailsMap.put(TakeAwayConstant.CURRENCY_CODE_PARAM,
            		getStringFromParameter(TakeAwayConstant.CURRENCY_CODE_PARAM, contextParams));
            this.itemDetailsMap.put(TakeAwayConstant.USERGROUP_ID_PARAM,
            		getStringFromParameter(TakeAwayConstant.USERGROUP_ID_PARAM, contextParams));
            this.itemDetailsMap.put(TakeAwayConstant.USER_ID_PARAM,
            		getStringFromParameter(TakeAwayConstant.USER_ID_PARAM, contextParams));
            this.itemDetailsMap.put(TakeAwayConstant.MVX_WAREHOUSE_CODE_PARAM,
            		getStringFromParameter(TakeAwayConstant.MVX_WAREHOUSE_CODE_PARAM, contextParams));
            this.itemDetailsMap.put(TakeAwayConstant.ALT_EXCHANGERATE_PARAM,
            		getStringFromParameter(TakeAwayConstant.ALT_EXCHANGERATE_PARAM, contextParams));
            this.itemDetailsMap.put(TakeAwayConstant.EXCHANGE_RATE_PARAM,
            		getStringFromParameter(TakeAwayConstant.EXCHANGE_RATE_PARAM, contextParams));
            this.itemDetailsMap.put(TakeAwayConstant.EXECUTE_INCLUDE_TAX_PARAM,
            		getStringFromParameter(TakeAwayConstant.EXECUTE_INCLUDE_TAX_PARAM, contextParams));
            this.itemDetailsMap.put(TakeAwayConstant.REQ_PAYMENT_METHOD_CODEID,
            		getStringFromParameter(TakeAwayConstant.REQ_PAYMENT_METHOD_CODEID, contextParams));
            this.itemDetailsMap.put(TakeAwayConstant.SELECTED_PROMOTIONID_PARAM,
            		getStringFromParameter(TakeAwayConstant.SELECTED_PROMOTIONID_PARAM, contextParams));
            // Get resultset from previous stage
            this.resultSet =  (XMLResultset) context.getResponse();
            if ((this.resultSet == null) || (this.resultSet.isEmpty())) {
                LOG.debug("The resultset passed to this stage is null or empty: resultset is null = "
                        + (resultSet == null) + " or resultset is empty = " + resultSet.isEmpty());
                return;
            }
            
            List<String> promotionIds = this.getPromotionListIds();
            this.promotionalItemsMap = this.retrievedPromotionalItems(promotionIds);
            this.lineTakeAwayList = this.retrievedPromotionLineTakeAway(promotionIds); 
            
            //Evaluate All Orderlines to Apply Promotions If any
            this.evaluateOrderLines(this.resultSet);
            //Recompute Prices in Orderlines for Orderheader
			this.updateOrderPrices(resultSet);
            //Evaluate Orderheader to Apply Promotions if any
            this.evaluateOrderHeader(this.resultSet);
            
            context.setResponse(xmlResponse);
            LOG.debug("END PromotionTakeAwayEngine.execute()");
        } catch (Exception e) {
        	throw new PipelineRuntimeException("Failed to obtain XML request document from request", e);
        }

    }
    
    /**
     * Evaluate Orderheader to apply Promotion TakeAway
     * 
     * @param resultSet
     */
    private void evaluateOrderHeader(XMLResultset resultSet){
    	LOG.debug("Inside PromotionTakeAwayEngine.evaluateOrderHeader()");
		try {
			List<String> promotionIds = new ArrayList<String>();
			String orderHeaderPromotionId = resultSet.getString(ConstantsForSales.SELECTED_PROMOTIONS);
			if((orderHeaderPromotionId == null || "".equals(orderHeaderPromotionId) ) 
					&&  (this.selectedCCPromotionID != null && !"".equals(this.selectedCCPromotionID))){
				promotionIds.add(this.selectedCCPromotionID);
			} else if ((orderHeaderPromotionId != null && !"".equals(orderHeaderPromotionId))
					&& this.selectedCCPromotionID != null && !"".equals(this.selectedCCPromotionID)) {
				promotionIds = Arrays.asList(orderHeaderPromotionId.split(":"));
				promotionIds.add(this.selectedCCPromotionID);
			}
			
			if(!promotionIds.isEmpty()){
				this.hasPromotion = true;
				this.headerTakeAwayList = this.retrievedPromotionHeaderTakeAway(promotionIds); 
				for (PromotionTakeAway promotakeAway : this.headerTakeAwayList) {
					String takeAwayType = promotakeAway.getTakeawayType();
					TakeAway takeAway = TakeAwayFactory.getTakeAway(takeAwayType);
					takeAway.setPromotionTakeAway(promotakeAway);
					takeAway.setItemParametersMap(this.itemDetailsMap);
					if(TakeAwayConstant.PRICE_DISCOUNT.equals(takeAwayType)){
						//Recompute Prices in Orderlines for Orderheader
						this.updateOrderPrices(resultSet);
						takeAway.applyHeaderTakeaway(resultSet);
					} else if(TakeAwayConstant.FREE_SHIPPING.equals(takeAwayType)){
						takeAway.applyHeaderTakeaway(resultSet);
					} else if(TakeAwayConstant.FREE_ITEM.equals(takeAwayType)){
						takeAway.applyHeaderTakeaway(resultSet);
					} else {
						LOG.debug("evaluateOrderHeader failed - no TakeAwayType set");
					}
				}				
			}
		} catch (ResultsetException e) {
			LOG.error("Error Inside PromotionTakeAwayEngine.retrievedPromotionalItems() - "+e.getMessage());
		}

    	
    }
    
    /**
     * Evaluate Orderline to apply Promotion TakeAway
     * 
     * @param resultSet
     * @throws PipelineRuntimeException
     * @throws TransformerException
     * @throws ResultsetException
     */
    private void evaluateOrderLines(XMLResultset resultSet)  
    		throws PipelineRuntimeException, TransformerException, ResultsetException {
    	LOG.debug("Inside PromotionTakeAwayEngine.evaluateOrderLines()");
    	resultSet.moveFirst();
    	XMLIterator xmlOrderline = (XMLIterator) resultSet.getResultset(ConstantsForSales.ORDERLINE);
        if ((xmlOrderline == null) || xmlOrderline.isEmpty()) {
            LOG.debug("The sub resultset orderlines is null or empty: resultset is null = " + (xmlOrderline == null)
                    + " or resultset is empty = " + xmlOrderline.isEmpty());
        }

        for (PromotionTakeAway promotakeAway : this.lineTakeAwayList) {
        	String takeAwayPromotionID = promotakeAway.getPromotionID();
        	List<String> promoItemsList =  this.promotionalItemsMap.get(takeAwayPromotionID);
        	String takeAwayType = promotakeAway.getTakeawayType();
        	String takeAwayField = promotakeAway.getField();
        	
        	TakeAway takeAway = TakeAwayFactory.getTakeAway(takeAwayType);
			takeAway.setPromotionTakeAway(promotakeAway);
			takeAway.setPromotionalItems(promoItemsList);
			takeAway.setItemParametersMap(this.itemDetailsMap);
			xmlOrderline.beforeFirst();
			while (xmlOrderline.moveNext()) {
				String linePromotionID = xmlOrderline.getString(ConstantsForSales.PROMOTION_ID);
				if(linePromotionID !=null && linePromotionID.equals(takeAwayPromotionID)){
					this.hasPromotion = true;
					if(TakeAwayConstant.FREE_ITEM.equals(takeAwayType)){
						//takeAway.applyHeaderTakeaway(resultSet);
						takeAway.applyLineTakeAway(resultSet, xmlOrderline);
						// apply one free item per Order promotion
						break;
					} else if(TakeAwayConstant.FIX_PRICE.equals(takeAwayType)){
						takeAway.applyHeaderTakeaway(resultSet);
						// apply one fix price per Order promotion
						break;
					} else if(TakeAwayConstant.PRICE_DISCOUNT.equals(takeAwayType)){
						if(TakeAwayConstant.ORDER_TOTAL.equals(takeAwayField)){
							//Recompute Prices in Orderlines for Orderheader
							this.updateOrderPrices(resultSet);
							//Header Level Price Discount
							takeAway.applyHeaderTakeaway(resultSet);
							break;
						} else {
							//Line Level Price Discount
							takeAway.applyLineTakeAway(resultSet, xmlOrderline);	
						}
					}
				}				
			}
			
		}
        
/*        List<String> appliedPromotionList = new ArrayList<String>();
        while (xmlOrderline.moveNext()) {
			String linePromotionID = xmlOrderline.getString(ConstantsForSales.PROMOTION_ID);
			if(linePromotionID != null){
				
				List<String> promoItemsList =  this.promotionalItemsMap.get(linePromotionID);
				PromotionTakeAway promotakeAway = getPromotionTakeaway(linePromotionID);
				String takeAwayType = promotakeAway.getTakeawayType();
				//Set PromotionID
				promotakeAway.setPromotionID(linePromotionID);

				TakeAway takeAway = TakeAwayFactory.getTakeAway(takeAwayType);
				takeAway.setPromotionTakeAway(promotakeAway);
				takeAway.setPromotionalItems(promoItemsList);
				takeAway.setItemParametersMap(this.itemDetailsMap);
				String takeAwayField = promotakeAway.getField();
				if(!appliedPromotionList.contains(linePromotionID)){
					//Same PromotionId should not be applied twice in header level
					if(TakeAwayConstant.FREE_ITEM.equals(takeAwayType)){
						takeAway.applyHeaderTakeaway(resultSet, this.xmlHelper);
						// apply one free item per Order promotion
					} else if(TakeAwayConstant.FIX_PRICE.equals(takeAwayType)){
						takeAway.applyHeaderTakeaway(resultSet, this.xmlHelper);
						// apply one fix price per Order promotion
					} else if(TakeAwayConstant.PRICE_DISCOUNT.equals(takeAwayType)){
						if(TakeAwayConstant.ORDER_TOTAL.equals(takeAwayField)){
							//Header Level Price Discount
							takeAway.applyHeaderTakeaway(resultSet, this.xmlHelper);
							appliedPromotionList.add(linePromotionID);
						}
					}
					appliedPromotionList.add(linePromotionID);
				}
				if(TakeAwayConstant.PRICE_DISCOUNT.equals(takeAwayType)){
					if(!TakeAwayConstant.ORDER_TOTAL.equals(takeAwayField)){
						//Line Level Price Discount
						takeAway.applyLineTakeAway(xmlOrderline, this.xmlHelper);												
					}
				}
				if(appliedPromotionList.isEmpty()){
					appliedPromotionList.add(linePromotionID);
				}
			}
		}*/
    }
    
    private List<String> getPromotionListIds() throws PipelineRuntimeException, TransformerException, ResultsetException {
    	LOG.debug("Inside PromotionTakeAwayEngine.getPromotionListIds()");
    	List<String> promoItemsList = new ArrayList<String>();
    	Map<String, String> promoIdMap = new HashMap<String, String>();
    	this.resultSet.moveFirst();
    	XMLIterator lineIter = (XMLIterator) this.resultSet.getResultset(ConstantsForSales.ORDERLINE);
        if ((lineIter == null) || lineIter.isEmpty()) {
            LOG.debug("The sub resultset orderlines is null or empty: resultset is null = " + (lineIter == null)
                    + " or resultset is empty = " + lineIter.isEmpty());
        }
        lineIter.beforeFirst();
		while (lineIter.moveNext()) {
			String linePromotionID = lineIter.getString(ConstantsForSales.PROMOTION_ID);
			if(linePromotionID!=null && (promoIdMap.isEmpty() || !promoIdMap.containsKey(linePromotionID)) ){
				promoIdMap.put(linePromotionID, linePromotionID);
				promoItemsList.add(linePromotionID);
			}
		}
		return promoItemsList;
    }
    
    
    private void updateLineRSPromotion(Map<String, List<String>> itemsPromo) throws ResultsetException{
    	LOG.debug("\nInside PromotionTakeAwayEngine.updateLineRSPromotion()");
    	XMLIterator iterLine = (XMLIterator) xmlResponse.getResultset(ConstantsForSales.ORDERLINE);
    	StringBuffer strPromotionList = null;
    	
    	iterLine.beforeFirst();
    	
    	while (iterLine.moveNext()) {
    		String currItemID = iterLine.getString(ConstantsForSales.ITEM_ID);
    		strPromotionList = new StringBuffer();
    		for (Map.Entry<String, List<String>> entry : itemsPromo.entrySet()) {
    			String promoId = entry.getKey();
    			List<String> itemList = entry.getValue();
    			if(!itemList.isEmpty() && itemList.contains(currItemID)){
    				if(strPromotionList.length()==0) strPromotionList = strPromotionList.append(promoId);
	                  else strPromotionList = strPromotionList.append(":").append(promoId);
    			}
    		}
    		this.updRsAttr(iterLine, ConstantsForSales.PROMOTIONS_ATTRIBUTE, strPromotionList.toString());
    	}
    }
    
    private PromotionTakeAway getPromotionTakeaway(String promotionId){
    	LOG.debug("Inside PromotionTakeAwayEngine.getPromotionTakeaway()");    	
    	PromotionTakeAway takeAway = null; // from database
    	SearchPipelineExecuter pipeline = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                "Promotion", "RulesListTakeAway");
    	pipeline.setParam("@LanguageCode", _languageCodeParam);
    	pipeline.setParam("promotionID", promotionId);
    	pipeline.setParam("IsM3", "N");
    	 
    	try {
    		XMLResultset promotion = pipeline.execute();
			if (promotion != null && !promotion.isEmpty()) {
				promotion.moveFirst();
                XMLIterator promotionTakeAway = (XMLIterator) promotion.getResultset(ConstantsForSales.RULES);
                if (promotionTakeAway != null && !promotionTakeAway.isEmpty()) {
                	promotionTakeAway.beforeFirst();
                	//PromotionRule promotionRule = null;
                	while (promotionTakeAway.moveNext()) {
                		takeAway = new PromotionTakeAway();
                		takeAway.setPromotionID(promotionId);
                		takeAway.setPromotionName(promotionTakeAway.getString(ConstantsForSales.NAME));
                		takeAway.setTakeawayType(promotionTakeAway.getString(ConstantsForSales.RULE_CODE));
                		takeAway.setField(promotionTakeAway.getString(ConstantsForSales.FIELD_CODE));               
                		takeAway.setOperator(promotionTakeAway.getString(ConstantsForSales.OPERATOR_TEXT));
                		takeAway.setExchangeRate(this.exchangeRate);
                		takeAway.setAltExchangeRate(promotion.getString(ConstantsForSales.CURRENCY_RATE));
                		
                		XMLIterator promotionRuleValues = (XMLIterator)promotionTakeAway.getResultset(ConstantsForSales.VALUE);
                		if (promotionRuleValues != null && !promotionRuleValues.isEmpty()) {
                			List<String> values = new ArrayList<String>();
                			promotionRuleValues.beforeFirst();
                        	while (promotionRuleValues.moveNext()) {
                        		values.add(promotionRuleValues.getString(ConstantsForSales.VALUE));
                        		takeAway.setExtraParams(promotionRuleValues.getString(ConstantsForSales.EXTRA_VALUE));
                        	}
                        	takeAway.setValues(values);
                        	
                		}

                	}
                }
			}
		} catch (PipelineRuntimeException e) {
			LOG.error("Error Inside PromotionTakeAwayEngine.retrievedPromotionalItems() - "+e.getMessage());
		} catch (ResultsetException e) {
			LOG.error("Error Inside PromotionTakeAwayEngine.retrievedPromotionalItems() - "+e.getMessage());
		}
    	
    	return takeAway;
    }
      
    /**
     * Get parameter value by name from parameter block in context.
     * 
     * @param parameterName
     *            name of the requested parameter
     * @param params
     *            pipeline request parameters including requested parameter
     * @return the parameter value as a string
     */
    protected String getStringFromParameter(final String parameterName, final Parameters params) {
        try {
            return params.getString(parameterName);
        } catch (ParametersException e) {
            LOG.error("Try to get parameter: " + parameterName);
            return "";
        }
    }
	
	
    public BigDecimal stringToDecimal(String value) throws ParseException {
        NumberFormat nf = NumberFormat.getNumberInstance();
        //Number n = nf.parse(value);
		Number n = nf.parse(nf.format(new Double(value)));
        if (n instanceof com.ibm.icu.math.BigDecimal) {
            return new BigDecimal(((com.ibm.icu.math.BigDecimal) n).toString());
        } else if (n instanceof BigDecimal) {
            return (BigDecimal) n;
        } else if (n instanceof Long) {
            return new BigDecimal(n.toString());
        } else {
            FastStringBuffer error = new FastStringBuffer();
            error.append("Could not parse as decimal: ");
            error.append(value);
            error.append(". Parser returned unknown decimal type: ");
            error.append(n.getClass());
            throw new ParseException(error.toString(), 0);
        }
    }
    
    private Map<String, List<String>> retrievedPromotionalItems(List<String> promotionIdList){
    	LOG.debug("Inside PromotionTakeAwayEngine.retrievedPromotionalItems() ");
    	Map<String, List<String>> promotionalItemsMap = new HashMap<String, List<String>>();
    	List<String> promoItemsList = null;
    	for (String strPromotionId : promotionIdList) {
        	SearchPipelineExecuter pipeline = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                    "Promotion", "ListPromotionalItems");
        	pipeline.setParam("@LanguageCode", this._languageCodeParam);
        	pipeline.setParam("PromotionID", strPromotionId);
        	pipeline.setParam("IsM3", "N");
        	
        	try {
    			XMLResultset promotion = pipeline.execute();
    			
    			promoItemsList = new ArrayList<String>();
    			if (promotion != null && !promotion.isEmpty()) {
    				promotion.moveFirst();
    				XMLIterator promotionalItems = (XMLIterator) promotion.getResultset(ConstantsForSales.ITEM);
    				if (promotionalItems != null && !promotionalItems.isEmpty()) {
    					promotionalItems.beforeFirst();
    					while (promotionalItems.moveNext()) {
    						promoItemsList.add(promotionalItems.getString(ConstantsForSales.ITEMNUMBER));
    					}
    				}
    			}
    			promotionalItemsMap.put(strPromotionId, promoItemsList);
    			
    		} catch (PipelineRuntimeException e) {
    			LOG.error("Error Inside PromotionTakeAwayEngine.retrievedPromotionalItems() - "+e.getMessage());
    		} catch (ResultsetException e) {
    			LOG.error("Error Inside PromotionTakeAwayEngine.retrievedPromotionalItems() - "+e.getMessage());
    		}
		}
    	return promotionalItemsMap;
    }
    
    private List<PromotionTakeAway> retrievedPromotionLineTakeAway(List<String> promotionIdList){
    	List<PromotionTakeAway> lineTakeAwayList = new ArrayList<PromotionTakeAway>();
    	PromotionTakeAway takeaway = null;
    	for (String promotionId : promotionIdList) {
    		takeaway = this.getPromotionTakeaway(promotionId);
    		lineTakeAwayList.add(takeaway);
		}
    	Collections.sort(lineTakeAwayList);
    	return lineTakeAwayList;
    }
    
    private List<PromotionTakeAway> retrievedPromotionHeaderTakeAway(List<String> promotionIdList){
    	List<PromotionTakeAway> headerTakeAwayList = new ArrayList<PromotionTakeAway>();
    	PromotionTakeAway takeaway = null;
		for (String promotionId : promotionIdList) {
			takeaway = this.getPromotionTakeaway(promotionId);
			headerTakeAwayList.add(takeaway);
		}
		Collections.sort(headerTakeAwayList);    		
		return headerTakeAwayList;
    }
    
    private String updRsAttr(final XMLResultset rs, final String rsPar, final String value) {
        return CustomStagesHelper.updateRsAttribute(rs, rsPar, value);
    }
    
    private String updRsAttr(final XMLIterator rs, final String rsPar, final String value) {
        return CustomStagesHelper.updateRsAttribute(rs, rsPar, value);
    }
    
    private void updateOrderPrices(XMLResultset rs) throws ResultsetException{
    	LOG.debug("Inside PromotionTakeAwayEngine.updateOrderPrices()");
    	if(this.hasPromotion){
    		LOG.debug("Start Updating - PromotionTakeAwayEngine.updateOrderPrices()");
    		//UPDATE THE FOLLOWING ATTRIBUTES : GrandTotal; TotalPrice; TotalQuantity; TotalDiscount
    		BigDecimal orderTotalPrice = new BigDecimal(0);
    		BigDecimal orderTotalDiscount = new BigDecimal(0);
    		BigDecimal orderTotalQuantity = new BigDecimal(0);
    		BigDecimal orderHeaderDiscount = new BigDecimal(0);
    		this.resultSet.moveFirst();
    		
    		XMLIterator lineIter = (XMLIterator) this.resultSet.getResultset(ConstantsForSales.ORDERLINE);
    		if ((lineIter == null) || lineIter.isEmpty()) {
    			LOG.debug("The sub resultset orderlines is null or empty: resultset is null = " + (lineIter == null) +" or resultset is empty = " + lineIter.isEmpty());
    		}
    		lineIter.beforeFirst();
    		while (lineIter.moveNext()) {
    			orderTotalPrice = orderTotalPrice.add(getParameterAsDecimal(lineIter.getString(ConstantsForSales.LINEPRICE)));
    			orderTotalDiscount = orderTotalDiscount.add(getParameterAsDecimal(lineIter.getString(ConstantsForSales.LINEDISCOUNT)));
    			orderTotalQuantity = orderTotalQuantity.add(getParameterAsDecimal(lineIter.getString(ConstantsForSales.QUANTITY)));
    		}
    		
    		String headerDiscountFromRequest = this.resultSet.getString(TakeAwayConstant.REQ_ORDERHEADER_DISCOUNT);
    		if(headerDiscountFromRequest != null && !"".equals(headerDiscountFromRequest)){
    			orderHeaderDiscount = new BigDecimal(headerDiscountFromRequest);
    			orderTotalDiscount = orderTotalDiscount.add(orderHeaderDiscount);
    			//resultSet.setString(ConstantsForSales.TOTALDISCOUNT, orderTotalDiscount.toString());
    			this.updRsAttr(this.resultSet, ConstantsForSales.TOTALDISCOUNT, orderTotalDiscount.toString());
    			
    			
    		} else {
    			//resultSet.setString(ConstantsForSales.TOTALDISCOUNT, orderTotalDiscount.toString());
    			this.updRsAttr(this.resultSet, ConstantsForSales.TOTALDISCOUNT, orderTotalDiscount.toString());
    		}
    		
    		//resultSet.setString(ConstantsForSales.TOTALPRICE, orderTotalPrice.toString());
    		//resultSet.setString(ConstantsForSales.TOTALQUANTITY, orderTotalQuantity.toString());
    		//resultSet.setString(ConstantsForSales.GRANDTOTAL,orderTotalPrice.subtract(orderTotalDiscount).toPlainString());
    		this.updRsAttr(this.resultSet, ConstantsForSales.TOTALPRICE, orderTotalPrice.toString());
    		this.updRsAttr(this.resultSet, ConstantsForSales.TOTALQUANTITY, orderTotalQuantity.toString());
    		this.updRsAttr(this.resultSet, ConstantsForSales.GRANDTOTAL, orderTotalPrice.subtract(orderTotalDiscount).toPlainString());
    		LOG.debug("End Updating - PromotionTakeAwayEngine.updateOrderPrices()");
    	}
    }
    
    private BigDecimal getParameterAsDecimal(final String val) {
        if (val != null) {
            try {
                return new BigDecimal(val);
            } catch (NumberFormatException e) {
                return new BigDecimal("0.0000");
            }
        }
        return new BigDecimal("0.0000");
    }
    
}
