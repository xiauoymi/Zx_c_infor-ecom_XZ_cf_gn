package com.intentia.iec.pipeline.runtime.stage.custom.lucene.manager;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.custom.lucene.utils.IndexManagerUtil;
import com.intentia.iec.pipeline.runtime.stage.utils.CommitPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

public final class IndexUpdater extends AbstractPipelineStage {

    private static final Logger LOG = Logger.getLogger(IndexUpdater.class);

    private static final String LUCENE_INDEX_PACKAGE = "com.intentia.iec.pipeline.runtime.stage.custom.lucene.index.";

    private Parameters parameters;

    private boolean rebuildIndex;

    private boolean runScheduleJobNow;

    private boolean triggerEnabled = false;

    /**
     * 
     * @param context
     * @throws PipelineRuntimeException
     */
    public void execute(final PipelineContext context) throws PipelineRuntimeException {
        try {
            if (!(context.getRequest() instanceof XMLRequest)) {
                throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
            }

            CustomStagesHelper.extractRequestParameters(CustomStagesHelper.getRequest(context));
            XMLRequest request = (XMLRequest) context.getRequest();
            parameters = request.getParameters();

            String indexName = parameters.getString(ConstantsForSales.INDEX_NAME_PARAM);
            rebuildIndex = Boolean.parseBoolean(parameters.getString(ConstantsForSales.REBUILD_INDEX_PARAM));
            runScheduleJobNow = Boolean.parseBoolean(parameters.getString(ConstantsForSales.RUN_SCHEDULE_JOB_NOW));
            triggerEnabled = isTriggerEnabled();

            if (!isDoUpdate()) {
                LOG.info("Nothing to update. Aborting index update...");
                LOG.debug("  rebuildIndex = " + String.valueOf(rebuildIndex));
                LOG.debug("  runScheduleJobNow = " + String.valueOf(runScheduleJobNow));
                LOG.debug("  triggerEnabled = " + String.valueOf(triggerEnabled));
                return;
                // do nothing ...
            }

            // Enable Index Triggers before start indexing
            if (!triggerEnabled && runScheduleJobNow)
                enableIndexTriggers();

            if ("".equals(indexName) || "null".equals(indexName))
                indexName = null;

            if (indexName != null) {
                // Triggered through Lucene Index Manager Page
                try {
                    XMLResultset index = IndexManagerUtil.getIndexDetails(indexName);
                    if (index != null && !index.isEmpty()) {
                        index.moveFirst();
                        doUpdate(index, context);
                    } else {
                        LOG.error("Index details not found. indexName = " + indexName);
                    }
                } catch (ResultsetException e) {
                    throw new PipelineRuntimeException("Unable to fetch details of index '" + indexName + "'", e);
                }
            } else {
                // Triggered through LuceneLES.Index schedule job
                try {
                    XMLResultset indexes = IndexManagerUtil.getIndexList();
                    indexes.beforeFirst();
                    while (indexes.moveNext()) {
                        doUpdate(indexes, context);
                    }
                } catch (ResultsetException e) {
                    throw new PipelineRuntimeException("Unable to fetch Lucene index list", e);
                }
            }

        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Unable to parse request parameters", e);
        }
    }

    private void doUpdate(XMLResultset index, PipelineContext context) throws PipelineRuntimeException {
        try {
            String indexName = index.getString(ConstantsForSales.INDEX_NAME_ATTRIBUTE);
            String className = index.getString(ConstantsForSales.INDEXER_CLASSNAME_ATTRIBUTE);
            int numberOfRecords = index.getint(ConstantsForSales.NUMBER_OF_RECORDS_ATTRIBUTE);

            if (isRebuildIndex(numberOfRecords)) {
                LOG.debug("Rebuilding index " + indexName);
                parameters.set(ConstantsForSales.REBUILD_INDEX_PARAM, String.valueOf(true));
            } else {
                LOG.debug("Updating index " + indexName);
                parameters.set(ConstantsForSales.REBUILD_INDEX_PARAM, String.valueOf(false));
            }

            executeIndexerStageClass(indexName, className, context);
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Unable to fetch index details.", e);
        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Unable to set rebuildIndex parameter.", e);
        }
    }

    private boolean isDoUpdate() {
        return !(!rebuildIndex && !triggerEnabled && !runScheduleJobNow);
    }

    private boolean isRebuildIndex(int numberOfRecords) {
        boolean doRebuild = false;

        if (rebuildIndex)
            doRebuild = true;
        else if (runScheduleJobNow) {
            if (!triggerEnabled) {
                doRebuild = true;
            } else {
                if (!(numberOfRecords > 0)) {
                    doRebuild = true;
                }
            }
        }

        return doRebuild;
    }

    private void executeIndexerStageClass(final String indexName, final String className, PipelineContext context)
            throws PipelineRuntimeException {
        String indexerClass = null;
        try {
            indexerClass = LUCENE_INDEX_PACKAGE + className;
            Class<?> runtimeClass = Class.forName(indexerClass);
            AbstractPipelineStage pipeline = (AbstractPipelineStage) runtimeClass.newInstance();
            pipeline.execute(context);
        } catch (PipelineRuntimeException e) {
            LOG.error("Failed to update index file '" + indexName + "'", e);
            // throw nothing here to avoid database rollback
            // TODO: Rollback LuceneIndexLog table
        } catch (ClassNotFoundException e) {
            throw new PipelineRuntimeException("Unable to find class '" + indexerClass + "'", e);
        } catch (IllegalAccessException e) {
            throw new PipelineRuntimeException("Illegal access to class '" + indexerClass + "'", e);
        } catch (InstantiationException e) {
            throw new PipelineRuntimeException("Unable to instantiate class '" + indexerClass + "'", e);
        }
    }

    private boolean isTriggerEnabled() {
        CommitPipelineExecuter pipeline = new CommitPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                "ApplicationData", "Details");
        pipeline.setParam("param", "EnableLESIndexTriggers");
        XMLResultset result = null;
        boolean isEnabled = false;
        try {
            result = pipeline.execute();
            if (result != null)
                result.moveFirst();
            isEnabled = "Y".equals(result.getString("ParameterValue"));
        } catch (PipelineRuntimeException e) {
            LOG.error("Unable to check if LES triggers are enabled.", e);
            return false;
        } catch (ResultsetException e) {
            LOG.error("Unable to check if LES triggers status.", e);
        }

        return isEnabled;
    }

    private void enableIndexTriggers() throws PipelineRuntimeException {
        SearchPipelineExecuter pipeline = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "LuceneLES",
                "EnableLesIndexTriggers");
        pipeline.setParam("IsEnable", "Y");
        pipeline.execute();
    }
}