package com.intentia.iec.pipeline.runtime.stage.custom.search;

import java.util.Collection;
import java.util.Map;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;

public final class Response {
    private static final Logger LOG = Logger.getLogger(Response.class);

    public void setTooManyClausesResponse(final PipelineContext context) throws PipelineRuntimeException {
        String response = "<?xml version='1.0' encoding='UTF-8'?>" + "<resultset object='DoesNotMatter'></resultset>";
        context.setResponse(new XMLResultset(response));
        CustomStagesHelper.setResponseParameter(context, "tooManyClauses", "true");
    }

    /**
     * Creates the XML response document and installs it in the pipeline
     * context. Filters out null values, thus removing the burden of null
     * checking from the clients. XML encodes the values.
     */
    public void setResponse(final PipelineContext context, final Collection<Map<String, String>> rows)
            throws PipelineRuntimeException {
        StringBuilder buf = new StringBuilder("<?xml version='1.0' encoding='UTF-8'?>"
                + "<resultset object='DoesNotMatter'>");
        if (rows != null) {
            for (Map<String, String> row : rows) {
                buf.append("<row ");
                for (Map.Entry<String, String> attributeToValue : row.entrySet()) {
                    String attribute = attributeToValue.getKey();
                    String value = attributeToValue.getValue();
                    if (value != null) {
                        buf.append(attribute + "='" + encode(value) + "' ");
                    }

                }
                buf.append("/>");
            }
        }

        buf.append("</resultset>");

        String response = buf.toString();
        context.setResponse(new XMLResultset(response));
        LOG.info("Lucene search result: " + response);
    }

    private String encode(final String str) {
        return str.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("'", "&apos;");
    }

    public void setTotalSearchCountParam(PipelineContext context, int count) throws PipelineRuntimeException {
        CustomStagesHelper.setResponseParameter(context, "TotalSearchCount", String.valueOf(count));
    }
}
