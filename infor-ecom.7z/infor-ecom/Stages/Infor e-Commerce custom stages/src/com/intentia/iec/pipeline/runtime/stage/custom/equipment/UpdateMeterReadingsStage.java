package com.intentia.iec.pipeline.runtime.stage.custom.equipment;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.connection.ConnectorException;
import com.intentia.iec.connection.IMovexApiResultset;
import com.intentia.iec.connection.IMovexConnection;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;

/**
 * This class calls MOS160MI-UpdMeterValue.
 *
 */
public class UpdateMeterReadingsStage implements PipelineStage {
	
	 private static final Logger LOG = Logger.getLogger(UpdateMeterReadingsStage.class);

	 private IMovexConnection movex = null; 

	 private static final String MOS160MI = "esales.MOS160MI";
	 
	 private static final String REQUEST_CONO = "CONO";
	 
	 private static final int METER_COUNT = 4;
	 
	 private static final String PARAM_METERVALUE = "mv";
	 
	 private static final String PARAM_METERCODE = "mc";
	 
	 private static final String PARAM_METEROLDVALUE = "mvold";
	 
	 private static final String PARAM_ITEMNUMBER = "itemnumber";
	 
	 private static final String PARAM_SERIALNUMBER = "serialnumber";
	 
	 private static final String PARAM_DECIMALSEPARATOR = "decimalseparator";
	 
	 private static final String PARAM_STATUS = "status";
	 
	 private static final String PROGRAM_UPDATE_METER_VALUE = "UpdMeterValue";
	 
	 private static final String CONO = "CONO";
	 
	 private static final String ITNO = "ITNO";
	 
	 private static final String SERN = "SERN";
	 
	 private static final String MES0 = "MES0";
	 
	 private static final String MVA0 = "MVA0";
	 
	 private static final String TAIL = "TAIL";
	 
	 private static final String CFGL = "CFGL";
	 
	 private static final String MVXSTATUS = "mvxStatus";
	 
	 private static final String RESULT_SKIPPED = "SK";
	 
	 private static final String RESULT_UPDATED = "UP";
	 
	 private static final String RESULT_FAILED = "FA";

	 /* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.PipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@SuppressWarnings("unchecked")
	public void execute(PipelineContext context) throws PipelineRuntimeException {
 
        // Movex connector not enabled => skip stage
        if (!"true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.CONNECTORENABLED))) {
            return;
        }
        
        // Retrieve XML request from context
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }

        try {
        	XMLRequest request = (XMLRequest) context.getRequest();        	
        	Parameters parameters = request.getParameters();        	
        	
        	// check if parameters are present
        	if (parameters != null) {
        		String m3Company = parameters.getString(REQUEST_CONO);
    			String itemNumber = parameters.getString(PARAM_ITEMNUMBER);
    			String serialNumber = parameters.getString(PARAM_SERIALNUMBER);
    			String decimalSeparator = parameters.getString(PARAM_DECIMALSEPARATOR);
    			
    			// this object will hold the status of the updates, passed from the request object 
    			Map<Object, Object> status = (Map<Object, Object>) parameters.get(PARAM_STATUS);
        		
        		for (int i = 1; i <= METER_COUNT; i++) {
        			String meterValue = parameters.getString(PARAM_METERVALUE + i);
        			String meterCode = parameters.getString(PARAM_METERCODE + i);
        			String meterOldValue = parameters.getString(PARAM_METEROLDVALUE + i);
        			
        			// check if the meter has to be updated
        			if (hasToUpdate(meterValue, meterCode, meterOldValue) == true) {
        				LOG.debug("Updating meter value=" + meterValue + " code=" + meterCode);

        				boolean success = updateMeterValue(context, m3Company, itemNumber, serialNumber, meterValue, meterCode, decimalSeparator);
        				
        				// set status code
        				if (success == true) {
        					status.put(meterCode, RESULT_UPDATED);
        				}
        				else {
        					status.put(meterCode, RESULT_FAILED);
        				}
        			}
        			else {
        				LOG.debug("Skipping meter value=" + meterValue + " code=" + meterCode);
        				
        				status.put(meterCode, RESULT_SKIPPED);
        			}
        		}
        	}          
        } catch (ParametersException e) {
			LOG.error(e);
		} finally {            
            if (movex != null) {
            	LOG.debug("UpdateMeterReadingsStage closing connection");

            	try {
                    movex.close();
                } catch (ConnectorException e) {
                    LOG.error("Failed to close connection!");
                }
                movex = null;
            }
        }        
	}
	 
	 /**
	  * Check if the meter has to be updated. Update is needed if the new value is different from the old value 
	 * @param value
	 * @param code
	 * @param oldValue
	 * @return
	 */
	private boolean hasToUpdate(String value, String code, String oldValue) {
		 if (value == null || code == null) {
			 return false;
		 }
		 
		 if ((oldValue == null && value != null) || (oldValue != null && value != null && value.compareTo(oldValue) != 0)) {
			 return true;
		 }
		 
		 return false;
	 }
	 
	 /**
	  * Calls UpdMeterValue
	 * @param context
	 * @param cono
	 * @param itemNumber
	 * @param serialNumber
	 * @param value
	 * @param code
	 * @return
	 * @throws PipelineRuntimeException
	 */
	private boolean updateMeterValue(PipelineContext context, String cono, String itemNumber, String serialNumber, String value, String code, String decimalSeparator) throws PipelineRuntimeException {
		 Map<Object, Object> inputs = new HashMap<Object, Object>();
		 inputs.put(IMovexConnection.TRANSACTION, PROGRAM_UPDATE_METER_VALUE);
		 inputs.put(CONO, cono);
		 inputs.put(ITNO, itemNumber);		 
		 inputs.put(SERN, serialNumber);
		 inputs.put(MES0, code);
		 
		 if (value != null && ".".equals(decimalSeparator) == false) {
			 String replaced = value.replaceAll(decimalSeparator, ".");
			 inputs.put(MVA0, replaced);
		 }
		 else {
			 inputs.put(MVA0, value);
		 }
		 
		 // these are mandatory parameters
		 inputs.put(TAIL, "");		 
		 inputs.put(CFGL, "");
		 
		 if (movex == null) {
			 movex = (IMovexConnection) CustomStagesHelper.getConnection(MOS160MI);	 
		 }
		 
         if (movex == null) {
             return false;
         }  
         
         IMovexApiResultset result = CustomStagesHelper.callMovex(context, movex, inputs, MVXSTATUS);
         if (result != null) {
        	 LOG.debug("UpdMeterValue result=" + movex.getLastMessage());
        	 
        	 if (movex.isOk() == true) {
        		 return true;
        	 }
        	 else {
        		 return false;
        	 }
         }
         else {
        	 return false;
         }
	 }
}
