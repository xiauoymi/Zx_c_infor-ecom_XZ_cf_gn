package com.intentia.iec.pipeline.runtime.stage.custom;

import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.integration.erp.dao.ItemDao;
import com.intentia.iec.pipeline.runtime.integration.erp.dao.factory.DaoFactory;
import com.intentia.iec.pipeline.runtime.integration.erp.dao.factory.WebserviceDaoFactory;
import com.intentia.iec.pipeline.runtime.integration.erp.exception.ErpConnectionException;
import com.intentia.iec.pipeline.runtime.integration.erp.exception.ErpRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.erp.model.AvailabilityDetail;
import com.intentia.iec.pipeline.runtime.integration.erp.model.AvailabilityRequest;
import com.intentia.iec.pipeline.runtime.integration.erp.model.ItemAvailability;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import org.apache.log4j.Logger;
import com.intentia.iec.pipeline.runtime.integration.erp.utils.ErpUtilHelper;
import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
/**
 * ATPWSClient
 * 
 * Developed by: Gerald Tajonera
 * 
 * ATPWSClient is a webservice client for GetOrderPromise service. 
 * 
 * Retrieves ATP...
 * 
 */
public class ATPWSClient implements PipelineStage {	

	private static final Logger LOG = Logger.getLogger(ATPWSClient.class);
	private XMLRequest xmlRequest;
	private String param_WSUserID = "WebServiceUserID";
	private String WSUserID = null;
	private PipelineContext context;
	private String warehouseId;
	private String ShippingAddressId;
	public void execute(PipelineContext context) throws PipelineRuntimeException {

		if (!(context.getRequest() instanceof XMLRequest)) {
			throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
		}			
		try{
			this.context = context;
			xmlRequest = (XMLRequest) context.getRequest();		
			XMLRequest.extractRequestParameters(xmlRequest);
			WSUserID = ErpUtilHelper.getWSRegisteredUser(param_WSUserID);							
			Parameters param=CustomStagesHelper.getRequestParameters(context);
			
			this.ShippingAddressId= param.getString("shippingAddressId")!=null && param.getString("shippingAddressId").trim().equals("")? null:param.getString("shippingAddressId");
			this.warehouseId=param.getString("warehouseId");
			Map<String, String> virtualMap = ErpUtilHelper.getVirtualEnterprise(); 
			String item = xmlRequest.getParameters().getString("itemID");
			//Get ERP DAO implementation 
			ItemDao itemDao = DaoFactory.getDAOFactory().getItemDao(); 
			//Create atp request object
			AvailabilityRequest daoRequest = new AvailabilityRequest();
			daoRequest.setTenantId(virtualMap.get("TenantId"));
			daoRequest.setAccountingEntityId(virtualMap.get("Facility"));
			daoRequest.setWarehouseId("false".equals(xmlRequest.getParameters().getString("allWarehouse")) ? (this.warehouseId!=null && !this.warehouseId.equals(""))? this.warehouseId : virtualMap.get("Warehouse"): "");
			daoRequest.setItemId(item);
			daoRequest.setCustomerItemId(xmlRequest.getParameters().getString("customerItemID"));
			daoRequest.setQuantity(new Double(xmlRequest.getParameters().getString("quantity")));
			daoRequest.setUnitCode(ErpUtilHelper.getItemUnit(item));
			daoRequest.setRequiredDeliveryDate(xmlRequest.getParameters().getDate("requestedDeliveryDate"));
			daoRequest.setUserName(WebserviceDaoFactory.WEBSERVICEUSERID);
			
			if(CustomStagesHelper.getKeyValue("ION.Webservice ShippingAddressID").equals("true")){
			daoRequest.setShippingAddressId(this.ShippingAddressId);
			}
			
			//Call GetOrderPromise WS
			ItemAvailability wsoutAvailItem = itemDao.getAvailability(daoRequest);

			if (wsoutAvailItem.getDetails().size() > 0) {				
				createATPResultSet(wsoutAvailItem, context);
			} else createDummyResponse(context);
		} catch (RequestException e) {
			LOG.error(e.getMessage());
			throw new PipelineRuntimeException("Error extracting request parameters!", e);
		} catch(ErpConnectionException e){
			setErrorFlag();
			LOG.error(e.getMessage());
		} catch(ErpRuntimeException e){
			setErrorFlag();
			LOG.error(e.getMessage());
		} catch (Exception e) {
			if(e.getCause() instanceof java.net.ConnectException || e.getCause() instanceof java.net.SocketTimeoutException){
				LOG.debug("Error Execute Item Availability Data - "+ e.getMessage());
				setErrorFlag();
			} else {				
				LOG.debug("Failed to return a respose XML!", e);
			}
		} 
	}

	private void createATPResultSet(ItemAvailability atpResponse, PipelineContext context){			
		// builds xmlResponse from ATPWSClient response.
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		XMLResultset xmlResponse = new XMLResultset();
		for (AvailabilityDetail detail : atpResponse.getDetails()){
			try {
				xmlResponse.appendRow();
				if (detail.getDate() != null){
					GregorianCalendar convertToGregorianCal = new GregorianCalendar();				
					convertToGregorianCal.setTime(detail.getDate());
					XMLGregorianCalendar date = DatatypeFactory.newInstance().newXMLGregorianCalendar(convertToGregorianCal);
					xmlResponse.appendField("ATPDate", date.toString());
				}
				xmlResponse.appendField("ATPQuantity", Double.toString(detail.getQuantity()));
				xmlResponse.appendField("MvxWarehouse", detail.getWarehouseId());
			} catch (Exception e) {
				LOG.debug("Error creating Resultset From ATPWSClient Response!", e);
			}
		}		
		context.setResponse(xmlResponse);
	}

	private void createDummyResponse(PipelineContext context) {
		// Create XMLResultset dummy response.
		XMLGregorianCalendar date = null;
		try {
			GregorianCalendar gregorianCalendar = new GregorianCalendar();
			gregorianCalendar.setTime(xmlRequest.getParameters().getDate("requestedDeliveryDate"));
			date = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);

			XMLResultset dummyResponse = new XMLResultset();
			dummyResponse.appendRow();
			dummyResponse.appendField("ATPQuantity", Double.toString(0.0));
			dummyResponse.appendField("ATPDate", date.toString());
			dummyResponse.appendField("MvxWarehouse", "");
			context.setResponse(dummyResponse);
		} catch (Exception e) {
			LOG.debug("Error creating Dummy Response!", e);
		}
	}
	
	private void setErrorFlag(){
		try {
			XMLResultset xmlResponse = (XMLResultset) context.getResponse();
			if(xmlResponse == null){
				XMLResultset response = new XMLResultset();
				context.setResponse(response);
			}
			CustomStagesHelper.setResponseParameter(context, "hasWSError", "Y");
		} catch (PipelineRuntimeException e) {
			LOG.error(e.toString());	
		}
	}

}
