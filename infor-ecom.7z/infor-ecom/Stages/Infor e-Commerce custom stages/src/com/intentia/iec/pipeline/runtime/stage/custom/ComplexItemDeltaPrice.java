/*
 * Created on 25-01-2006
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.util.Date;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.sqlserver.common.DatabaseType;
import com.intentia.iec.sqlserver.runtime.procedure.Parameter;
import com.intentia.iec.sqlserver.runtime.procedure.StageCallProcedure;

/**
 * <p>
 * The <code>ComplexItemDeltaPrice</code> stage computes the difference in the
 * price if another combination than the standard is choosen for a complex item.
 * The actual calculation is performed by the stored procedure
 * <code>ComplexItemDeltaPrice</code>.
 * </p>
 * 
 * <p>
 * <b>Required input in <code>PipelineContext</code>:</b><br>
 * The stage requires two parameters from the request in the
 * <code>PipelineContext</code>; the <code>userGroupID</code> and the
 * <code>currencyCode</code>. Additionally the stage assumes that the
 * resultset in the <code>PipelineContext</code> contains the following
 * attributes <code>itemID</code>, <code>AttributeID</code>, and
 * <code>subitemID</code> and that these have values.
 * </p>
 * 
 * <p>
 * <b>Generated output in <code>PipelineContext</code>:</b><br>
 * When done the stage has added a value to the attribute
 * <code>DeltaPrice</code> on the existing resultset in the
 * <code>PipelineContext</code>.
 * </p>
 */

/*
 * Developer Notes: Implementation extracts user ID and currency ID from
 * parameters. Then it runs through the result set and fetches the itemID,
 * Attribute ID, and subitem ID from each of the relevant rows. Finally, the
 * procedure ComplexItemDeltaPrice is called with these five parameter values
 * and the result from the procedure is inserted into the resultset on attribute
 * DeltaPrice.
 */

public class ComplexItemDeltaPrice implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(ComplexItemDeltaPrice.class);

    private StageCallProcedure procedure = null;

    // fieldnames for procedure parameters
    // fields from result set - these are with a leading capital letter
    private static final String ITEM_FIELD = "ItemID";

    private static final String SUBITEM_FIELD = "SubItemID";

    private static final String ATTRIBUTE_FIELD = "AttributeID";

    private static final String DELTA_PRICE_FIELD = "DeltaPrice";

    // fields from parameters - these are with leading lower case letter
    private static final String CUSTOMER_FIELD = "userGroupID";

    private static final String CURRENCY_FIELD = "currencyCode";

    private String ListPriceGroup_ID = "listPriceGroupId";

    private String NetPriceGroup_ID = "netPriceGroupId";

    // containers for procedure parameters
    private String itemID = null;

    private String subItemID = null;

    private Integer attributeID = null;

    private Integer customerID = null;

    private String currencyCode = null;

    private Integer listPriceGroupId = null;

    private Integer netPriceGroupId = null;

    /**
     * <p>
     * Compute the difference in the price of a complex item, when an
     * alternative configuration has been selected. Add this difference to the
     * resultset in the <code>PipelineContext</code>.
     * </p>
     * 
     * @throws PipelineRuntimeException
     *             if {conditions for throwing}
     * @see com.intentia.iec.pipeline.runtime.PipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
     */
    public void execute(PipelineContext context) throws PipelineRuntimeException {

        LOG.debug("Inside the ComplexItemDeltaPrice stage");

        // get user id and currency id from context
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Request MUST be of type XMLRequest!");
        }

        CustomStagesHelper.extractRequestParameters((XMLRequest) context.getRequest());
        Parameters parameters = ((XMLRequest) context.getRequest()).getParameters();

        try {
            customerID = parameters.getInteger(CUSTOMER_FIELD);
            currencyCode = parameters.getString(CURRENCY_FIELD);
            listPriceGroupId = parameters.getInteger(ListPriceGroup_ID);
            netPriceGroupId = parameters.getInteger(NetPriceGroup_ID);
        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Failed obtaining user or currency ID from request", e);
        }

        // get result set
        if (!(context.getResponse() instanceof XMLResultset)) {
            throw new PipelineRuntimeException("Response MUST be of type XMLResultset!");
        }

        XMLResultset xmlItem = (XMLResultset) context.getResponse();
        setupProcedure();
        insertDeltaPrice(xmlItem);
    }

    /**
     * <p>
     * Get the <code>itemId</code>, <code>AttributeID</code>, and
     * <code>subItemId</code> from the resultset rows. Then compute the delta
     * price and insert it into the relevant attribute <code>DeltaPrice</code>.
     * </p>
     * 
     * @param xmlItem
     *            the resultset to insert the delta price in.
     * @throws PipelineRuntimeException
     *             if getting values from or setting values into the resultset
     *             fails
     */
    private void insertDeltaPrice(final XMLResultset xmlItem) throws PipelineRuntimeException {

        try {
            // loop over <item>
            xmlItem.beforeFirst();
            while (xmlItem.moveNext()) {
                itemID = xmlItem.getString(ITEM_FIELD);
                if (itemID == null) {
                    LOG.debug("itemID was not present in this row, thus it is skipped!");
                    continue;
                    // skip this row, since we cannot compute with null values
                }

                // loop over <item> <attributes>
                XMLIterator xmlAttributes = (XMLIterator) xmlItem.getResultset("Attributes");
                xmlAttributes.beforeFirst();
                while (xmlAttributes.moveNext()) {
                    attributeID = xmlAttributes.getInteger(ATTRIBUTE_FIELD);
                    if (attributeID == null) {
                        LOG.debug("attributeID was not present in this row, thus it is skipped!");
                        continue;
                        // skip this row, since we cannot compute with null
                        // values
                    }
                    // loop over <item> <attributes> <attributevalue>
                    XMLIterator xmlAttributeValue = (XMLIterator) xmlAttributes.getResultset("AttributeValue");
                    xmlAttributeValue.beforeFirst();
                    while (xmlAttributeValue.moveNext()) {
                        subItemID = xmlAttributeValue.getString(SUBITEM_FIELD);
                        if (subItemID == null) {
                            LOG.debug("subItemID was not present in this row, thus it is skipped!");
                            continue;
                            // skip this row, since we cannot compute with null
                            // values
                        }
                        String deltaPrice = calcDeltaPrice();
                        // NOTE: if ComplexItemDeltaPrice gives an error => then
                        // deltaPrice will be 'null'
                        if ((deltaPrice != null) && (deltaPrice.length() > 0)) {
                            xmlAttributeValue.appendField(DELTA_PRICE_FIELD, deltaPrice);
                        }
                    }
                }
            }
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Failed to get values from result set!", e);
        }
    }

    /**
     * <p>
     * Compute the delta price by calling the stored procedure
     * <code>ComplexItemDeltaPrice</code>.
     * </p>
     * 
     * @return the delta price computed by the stored procedure
     *         <code>ComplexItemDeltaPrice</code>.
     * @throws PipelineRuntimeException
     */
    private String calcDeltaPrice() throws PipelineRuntimeException {

        LOG.debug("Attempting to call stored procedure ComplexItemDeltaPrice");

        // create separate context for call to procedure
        PipelineContext procedureContext = new PipelineContext();
        addParametersToContext(procedureContext);
        procedure.execute(procedureContext);

        Object deltaPrice = procedureContext.get(DELTA_PRICE_FIELD);
        if (deltaPrice instanceof Date) {
            throw new PipelineRuntimeException("Delta price cannot be of type Date!");
        } else {
            // all other (expected) Objects from procedure.get() have a nice
            // toString() method
            return deltaPrice.toString();
        }
    }

    /**
     * <p>
     * Setup <code>StageCallProcedure</code> object to call the stored
     * procedure <code>ComplexItemDeltaPrice</code>.
     * </p>
     */
    private void setupProcedure() {

        procedure = new StageCallProcedure("EXEC ComplexItemDeltaPrice ?, ?, ?, ?, ?, ?, ?, ?");

        int varcharType = DatabaseType.parseTypeName("varchar");
        int moneyType = DatabaseType.parseTypeName("money");
        int integerType = DatabaseType.parseTypeName("integer");

        procedure.addInputParam("@customerId", 1, integerType, Parameter.PIPELINE_CONTEXT, CUSTOMER_FIELD);
        procedure.addInputParam("@itemNo", 2, varcharType, Parameter.PIPELINE_CONTEXT, ITEM_FIELD);
        procedure.addInputParam("@subItemNo", 3, varcharType, Parameter.PIPELINE_CONTEXT, SUBITEM_FIELD);
        procedure.addInputParam("@attributeId", 4, integerType, Parameter.PIPELINE_CONTEXT, ATTRIBUTE_FIELD);
        procedure.addInputParam("@currencyCode", 5, varcharType, Parameter.PIPELINE_CONTEXT, CURRENCY_FIELD);
        procedure.addInputParam("@listPriceGroupId", 6, integerType, Parameter.PIPELINE_CONTEXT, ListPriceGroup_ID);
        procedure.addInputParam("@netPriceGroupId", 7, integerType, Parameter.PIPELINE_CONTEXT, NetPriceGroup_ID);

        procedure.addOutputParam("@deltaAmount", 8, moneyType, Parameter.PIPELINE_CONTEXT, DELTA_PRICE_FIELD);
    }

    /**
     * <p>
     * Add additional parameters to the <code>PipelineContext</code>. The
     * parameters are require by the stored procedure
     * <code>ComplexItemDeltaPrice</code>.
     * </p>
     * 
     * @param context
     *            the <code>PipelineContext</code>.
     * @throws PipelineRuntimeException
     */
    private void addParametersToContext(final PipelineContext context) throws PipelineRuntimeException {
        context.put(ITEM_FIELD, itemID);
        context.put(SUBITEM_FIELD, subItemID);
        context.put(ATTRIBUTE_FIELD, attributeID);
        context.put(CUSTOMER_FIELD, customerID);
        context.put(CURRENCY_FIELD, currencyCode);
        context.put(ListPriceGroup_ID, listPriceGroupId);
        context.put(NetPriceGroup_ID, netPriceGroupId);
    }
}
