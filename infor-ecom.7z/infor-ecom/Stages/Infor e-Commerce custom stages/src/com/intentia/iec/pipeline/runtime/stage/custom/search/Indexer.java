package com.intentia.iec.pipeline.runtime.stage.custom.search;

import org.apache.lucene.index.IndexWriter;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;

/**
 * An interface to be implemented by indexers. Primarily defined to allow mock
 * object implementations.
 */
public interface Indexer {
    /**
     * The index method.
     * 
     * @param writer
     *            the writer
     * @throws PipelineRuntimeException
     *             the indexing failed
     */
    void index(IndexWriter writer) throws PipelineRuntimeException;
}
