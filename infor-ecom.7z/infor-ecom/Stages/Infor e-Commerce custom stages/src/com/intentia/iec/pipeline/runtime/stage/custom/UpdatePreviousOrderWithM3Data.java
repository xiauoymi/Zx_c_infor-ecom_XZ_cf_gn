package com.intentia.iec.pipeline.runtime.stage.custom;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.Resultset;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.utils.CommitPipelineExecuter;
import com.intentia.iec.sqlserver.runtime.jdbc.LogPreparedStatement;

public class UpdatePreviousOrderWithM3Data extends AbstractPipelineStage {
    private static final Logger LOG = Logger.getLogger(UpdatePreviousOrderWithM3Data.class);

    private static final String DELETED_STATUS = "90";

    private static final String SQL_DELETE = "DELETE FROM SubmittedOrderLine WHERE id IN ("
            + "SELECT sol.id FROM SubmittedOrderLine sol LEFT JOIN SubmittedOrderHeader so ON sol.orderId = so.id "
            + "LEFT JOIN DeliveryNoteLine dnl ON sol.id = dnl.orderLineId WHERE so.[key]= ? "
            + "AND dnl.id IS NULL AND sol.orderLineStatus = ?)";

    public void execute(PipelineContext context) throws PipelineRuntimeException {

        if (!(context.getResponse() instanceof XMLResultset)) {
            throw new PipelineRuntimeException("XML Reponse is invalid.");
        }

        try {
            Resultset response = (Resultset) context.getResponse();
            LOG.debug("Response XML:" + response);
            if (response == null || !response.moveFirst()) {
                LOG.debug("Aborting pipeline stage because there is no order.");
                return;
            }

            int mvxStatus = getMvxStatus(response);
            if (mvxStatus < 0) {
                LOG
                        .debug("Aborting pipeline stage because there is a problem connecting to M3 in the previous stage. mvxStatus = "
                                + mvxStatus);
                return;
            }

            XMLRequest request = (XMLRequest) context.getRequest();

            updatePreviousOrderDetails(response, request);
            cleanupDeletedOrderlines(response);

        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Error while traversing XML response.", e);
        }
    }

    private int getMvxStatus(Resultset response) throws PipelineRuntimeException {
        try {
            return response.getParameters().getint(ConstantsForSales.MVXSTATUS);
        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Unable to extract response parameters", e);
        }
    }

    private void updatePreviousOrderDetails(Resultset response, XMLRequest request) throws PipelineRuntimeException {
        CommitPipelineExecuter pipeline = new CommitPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                "PreviousOrder", "UpdatePreviousOrder");
        pipeline.addEntity();
        setHeaderFields(pipeline, response);
        setLinesFields(pipeline, response);
        setParameters(pipeline, request);
        pipeline.execute();
    }

    private void setHeaderFields(CommitPipelineExecuter pipeline, Resultset response) throws PipelineRuntimeException {
        try {
            List headerFields = response.getNames();
            Iterator itHeaderFields = headerFields.iterator();
            while (itHeaderFields.hasNext()) {
                final String attrName = (String) itHeaderFields.next();
                final String attrValue = response.getString(attrName);
                if (attrName.equals(ConstantsForSales.ORDERID))
                    pipeline.setEntityKey(attrName, attrValue);
                else
                    pipeline.setAttribute(attrName, attrValue);
            }
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException(
                    "Error while setting PreviousOrder.SaveAsPreviousOrder main set input attributes.", e);
        }
    }

    private void setLinesFields(CommitPipelineExecuter pipeline, Resultset response) throws PipelineRuntimeException {
        try {
            Resultset rsOrderLines = response.getResultset(ConstantsForSales.ORDERLINE);
            if (rsOrderLines != null && !rsOrderLines.isEmpty()) {
                rsOrderLines.beforeFirst();
                while (rsOrderLines.moveNext()) {
                    pipeline.addSubset(ConstantsForSales.ORDERLINE);
                    List lineFields = rsOrderLines.getNames();
                    Iterator itLineFields = lineFields.iterator();
                    while (itLineFields.hasNext()) {
                        final String attrName = (String) itLineFields.next();
                        final String attrValue = rsOrderLines.getString(attrName);
                        if (attrName.equals(ConstantsForSales.ORDERLINEID))
                            pipeline.setSubsetKey(attrName, attrValue);
                        else
                            pipeline.setSubsetAttribute(attrName, attrValue);
                    }
                }
            }
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException(
                    "Error while setting PreviousOrder.SaveAsPreviousOrder subset input attributes.", e);
        }
    }

    private void setParameters(CommitPipelineExecuter pipeline, XMLRequest request) throws PipelineRuntimeException {
        try {
            Parameters params = request.getParameters();
            if (params != null) {
                pipeline.setParam(ConstantsForSales.LANGUAGE_CODE_SQL_PARAM, params
                        .getString(ConstantsForSales.LANGUAGE_CODE_SQL_PARAM));
            }
        } catch (ParametersException e) {
            throw new PipelineRuntimeException(
                    "Error while setting PreviousOrder.SaveAsPreviousOrder input parameters.", e);
        }
    }

    private void cleanupDeletedOrderlines(Resultset response) throws PipelineRuntimeException {
        Connection conn = null;
        try {
            String orderID = response.getString(ConstantsForSales.ORDERID);
            LOG.debug("Cleaning up deleted order lines of Order #: " + orderID);

            conn = (Connection) CustomStagesHelper.getConnection("esales.cursor");
            LogPreparedStatement pstmtDelete = new LogPreparedStatement(conn, SQL_DELETE);
            pstmtDelete.setString(1, orderID);
            pstmtDelete.setString(2, DELETED_STATUS);            
            LOG.debug("Executing SQL: " + pstmtDelete.getQuery());
            pstmtDelete.execute();
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Unable to cleanup deleted order lines.", e);
        } catch (SQLException e) {
            throw new PipelineRuntimeException("Unable to cleanup deleted order lines.", e);
        } finally {
            if (conn != null)
                try {
                    conn.close();
                } catch (SQLException e) {
                    throw new PipelineRuntimeException("Unable to close databse connection.", e);
                }
        }
    }
}
