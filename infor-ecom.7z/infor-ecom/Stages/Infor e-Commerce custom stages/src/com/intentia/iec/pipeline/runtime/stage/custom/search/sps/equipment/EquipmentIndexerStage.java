package com.intentia.iec.pipeline.runtime.stage.custom.search.sps.equipment;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.custom.search.BaseDataIndexer;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Database;
import com.intentia.iec.pipeline.runtime.stage.custom.search.DatabaseImpl;
import com.intentia.iec.pipeline.runtime.stage.custom.search.IndexerStageUtils;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc;
import com.intentia.iec.pipeline.runtime.stage.custom.search.JdbcImpl;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Manager;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

/**
 * Stage class that is called by LuceneEquipment.Index.
 * This will index all equipments.
 */
public class EquipmentIndexerStage extends AbstractPipelineStage {
	
	private static final Logger LOG = Logger.getLogger(EquipmentIndexerStage.class);
	
    private static final String APPLICATIONDATA = "ApplicationData";

    private static final String APPLICATIONDATA_DETAILS = "Details";

    private static final String PARAM = "param";

    private static final String PARAMETER_VALUE = "ParameterValue";

    private static final String PARAMETER_USEINDEXSERVER = "UseIndexServer";

    private static final String USEINDEXSERVER = "Y";

    private static final String PARAMETER_INDEXSERVERHOST = "IndexServerHost";

    private static final String PARAMETER_INDEXSERVERPORT = "IndexServerPort";

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.AbstractPipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public void execute(PipelineContext arg0) throws PipelineRuntimeException {
		boolean useIndexServer = isIndexServer();
		
		long startTime = System.currentTimeMillis();

		if (useIndexServer == false) {
			LOG.info("Using single-server set-up");
			Jdbc jdbc = new JdbcImpl();
	        Manager manager = EquipmentManagerImpl.getInstance();
	        Database queries = new DatabaseImpl();
	        Map<String, String> categoryPathById = new HashMap<String, String>();
	        Map<String, String> categoryPathByKey = new HashMap<String, String>();
	        queries.buildCategoryPaths(categoryPathById, categoryPathByKey);
	
	        BaseDataIndexer baseDataIndexer = new BaseDataIndexer(false, categoryPathByKey);
	        EquipmentIndexer equipmentItemIndexer = new EquipmentIndexer(categoryPathById, jdbc, isIncludePrices());
	
	        IndexerStageUtils.doIndexing(manager, baseDataIndexer, equipmentItemIndexer);
		}
		else {
			LOG.info("Using index set-up");
			String url = getValueFromApplicationData(PARAMETER_INDEXSERVERHOST);
            int port = 0;
            try {
                port = Integer.parseInt(getValueFromApplicationData(PARAMETER_INDEXSERVERPORT));
            } catch (Exception e) {
                throw new PipelineRuntimeException(e);
            }
            Manager manager = EquipmentManagerImpl.getInstance();
            boolean isIncludePrices = isIncludePrices();
            EquipmentIndexerRequest request = new EquipmentIndexerRequest(isIncludePrices);
           
            IndexerStageUtils.sendIndexRequest(url, port, manager, request);
		}
		
		long stopTime = System.currentTimeMillis();
        LOG.debug("Total indexing time: " + (stopTime - startTime) + " ms");
	}
	
    /**
     * @return
     * @throws PipelineRuntimeException
     */
    private boolean isIncludePrices() throws PipelineRuntimeException {
        boolean retVal = ((Boolean.valueOf(CustomStagesHelper.getKeyValue("Application.M3 API")).booleanValue() == false) && (Boolean
                .valueOf(CustomStagesHelper.getKeyValue("Application.PriceSearchAndSort")).booleanValue() == true));
        return retVal;
    }
		
    /**
     * @return
     */
    private boolean isIndexServer() {
        boolean retVal = false;
        String s = getValueFromApplicationData(PARAMETER_USEINDEXSERVER);
        if (USEINDEXSERVER.equalsIgnoreCase(s) == true) {
            retVal = true;
        }

        return retVal;
    }    

    /**
     * @param pParamName
     * @return
     */
    private String getValueFromApplicationData(String pParamName) {
        String paramValue = "";

        SearchPipelineExecuter seApplicationData = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                APPLICATIONDATA, APPLICATIONDATA_DETAILS);

        seApplicationData.setParam(PARAM, pParamName);

        try {
            XMLResultset rs = seApplicationData.execute();
            rs.moveFirst();
            paramValue = rs.getString(PARAMETER_VALUE);
        } catch (PipelineRuntimeException e) {
            paramValue = "";
        } catch (ResultsetException e) {
            paramValue = "";
        }

        return paramValue;
    }
}
