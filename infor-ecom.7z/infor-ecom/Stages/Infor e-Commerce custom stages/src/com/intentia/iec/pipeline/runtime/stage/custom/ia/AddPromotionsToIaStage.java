package com.intentia.iec.pipeline.runtime.stage.custom.ia;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.w3c.dom.Node;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.ia.dao.IaDao;
import com.intentia.iec.pipeline.runtime.integration.ia.dao.impl.IaDaoRestImpl;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaConnectionException;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.ia.model.IaPromotion;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.utils.CommitPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

public class AddPromotionsToIaStage extends AbstractPipelineStage {

	private static final Logger log = Logger
			.getLogger(AddPromotionsToIaStage.class);

	private static final String ENTITY_XPATH = "request/entities/entity";

	private IaDao dao = null;

	boolean useDummy = false;

	public AddPromotionsToIaStage() {
		// do nothing...
	}

	public AddPromotionsToIaStage(boolean useDummy) {
		this.useDummy = useDummy;
	}

	@Override
	public void execute(PipelineContext context)
			throws PipelineRuntimeException {
		log.debug("Start AddPromotiontoIaStage . . .");
		CustomStagesHelper.extractRequestParameters(CustomStagesHelper
				.getRequest(context));
		XMLRequest request = (XMLRequest) context.getRequest();
		XMLResultset response = (XMLResultset) context.getResponse();
		boolean hasError = false;

		Parameters params = request.getParameters();
		String isScheduledJob = "";
		
		try {
			isScheduledJob = params.getString("runScheduleJobNow");
		} catch (Exception e) {	
			throw new PipelineRuntimeException(
					"Error getting parameter", e);
		}
		
		try {
			dao = new IaDaoRestImpl();
			Set<IaPromotion> promotions = getPromotions(request, response);
			hasError = addPromotionsToIa(promotions);

			if("true".equals(isScheduledJob) && hasError)
			{
				throw new PipelineRuntimeException(
						"AddPromotionsToIaStage has error:" + hasError);
			}
			else if(hasError)
			{
				log.debug("AddPromotionsToIaStage has error:" + hasError);
			}
		} 
		catch(PipelineRuntimeException e){
			if("true".equals(isScheduledJob))
			{
				throw new PipelineRuntimeException(
						"Error while adding promotion to IA.", e);
			}
			else
			{
				log.debug("Error while adding promotion to IA.");
			}
		}
		catch (IaConnectionException e) {
			if("true".equals(isScheduledJob))
			{
				throw new PipelineRuntimeException(
						"Error while adding promotion to IA.", e);
			}
			else
			{
				log.debug("Error while adding promotion to IA.");
			}
		}
	}

	private Set<IaPromotion> getPromotions(XMLRequest request,
			XMLResultset response) throws PipelineRuntimeException {
		Set<IaPromotion> promos = new HashSet<IaPromotion>();
		try {
			if (response == null || response.isEmpty()) {
				response = getPromotionsNotInIa();
			}

			if (response != null && !response.isEmpty()) {
				response.beforeFirst();
				while (response.moveNext()) {
					if (!"Y".equals((response.getString("IsM3")))) {
						IaPromotion promo = new IaPromotion();
						promo.setId(response.getString("PromotionID"));
						String name = response.getString("InternalName");
						if (name == null && request != null) {
							Node entityNode = XMLRequestHelper.getRequestNode(
									request, ENTITY_XPATH);
							XMLRequestHelper xmlHelper = new XMLRequestHelper(
									request);
							name = xmlHelper.getAttribute(entityNode,
									"InternalName");
						}
						promo.setInternalName(name);
						promos.add(promo);
					}
				}
			} else {
				log.info("No promotions found to add to IA.");
			}
		} catch (ResultsetException e) {
			throw new PipelineRuntimeException(
					"Error while retrieving promotions from Response XML: "
							+ response, e);
		} catch (TransformerException e) {
			throw new PipelineRuntimeException(
					"Error while retrieving promotion from Request XML: "
							+ response, e);
		}

		return promos;
	}

	private boolean addPromotionsToIa(Set<IaPromotion> promotions)
			throws PipelineRuntimeException {
		boolean result = false;
		if (promotions != null && !promotions.isEmpty()) {
			log.debug("Adding the ff promotion to IA: " + promotions);
			Set<String> addedPromos = new HashSet<String>();

			for (IaPromotion promo : promotions) {
				try {
					dao.addPromotion(promo);
					addedPromos.add(promo.getId());
				} catch (IaRuntimeException e) {
					log.error("Error while adding promotion : " + promo, e);
					result = true;
				}
			}
			try {
				dao.deployPackage();
				updatePromotionFlagInDb(addedPromos);
			} catch (IaRuntimeException e) {
				throw new PipelineRuntimeException(
						"Unable to deploy IA package after adding promotions.",
						e);
			}
		}
		return result;
	}

	private XMLResultset getPromotionsNotInIa() throws PipelineRuntimeException {
		if (useDummy) {
			return getDummyPromotionsNotInIa();
		} else {
			try {
				// Execute BO method
				SearchPipelineExecuter pipeline = new SearchPipelineExecuter(
						ConstantsForSales.PIPELINE_PACKAGE, "Promotion",
						"ListSimple", SearchPipelineExecuter.OR);
				pipeline.setBinding("IsReplicatedInIA", "Y", "ne");
				pipeline.setBinding("IsReplicatedInIA", "", "null");
				XMLResultset result = pipeline.execute();

				return result;
			} catch (PipelineRuntimeException e) {
				throw new PipelineRuntimeException(
						"Error while invoking the Promotion.List pipeline.", e);
			}
		}
	}

	private void updatePromotionFlagInDb(Set<String> addedPromotions)
			throws PipelineRuntimeException {
		try {
			// Execute BO method
			CommitPipelineExecuter pipeline = new CommitPipelineExecuter(
					ConstantsForSales.PIPELINE_PACKAGE, "Promotion",
					"UpdateIsReplicatedInIAFlag");
			for (String promoId : addedPromotions) {
				pipeline.addEntity();
				pipeline.setEntityKey("PromotionID", promoId);
				pipeline.setAttribute("IsReplicatedInIA", "Y");
			}
			pipeline.execute();
		} catch (PipelineRuntimeException e) {
			throw new PipelineRuntimeException(
					"Error while setting IsReplicatedInIA flag to 'Y' of promotion IDs: "
							+ addedPromotions, e);
		}
	}

	@SuppressWarnings("unused")
	private Set<IaPromotion> getDummyPromotions(int count) {
		Set<IaPromotion> promos = new HashSet<IaPromotion>();
		for (int i = 0; i < count; i++) {
			IaPromotion promo = new IaPromotion();
			String id = generateRandomId();
			promo.setId(id);
			promo.setInternalName("Test Promotion from IEC Unit Testing (Stage)");
			promos.add(promo);
		}
		return promos;
	}

	private String generateRandomId() {
		Random rand = new Random();
		int randomNum = rand.nextInt((10000 - 100) + 1) + 100;
		return String.valueOf(randomNum);
	}

	private XMLResultset getDummyPromotionsNotInIa() {
		return new XMLResultset(
				"<?xml version=\"1.0\" encoding=\"UTF-8\"?><resultset object=\"Promotion\"><row Code=\"E60EC0C\" CurrencyCode=\"EUR\" CurrencyRate=\"0.6700\" InternalName=\"Test&#x20;Promotion&#x20;for&#x20;IA\" PromotionID=\"61\"/><row Code=\"896DCAB\" CurrencyCode=\"EUR\" CurrencyRate=\"0.6700\" InternalName=\"Buy&#x20;1&#x20;Take&#x20;1&#x20;on&#x20;Jeans!\" PromotionID=\"62\"/><row Code=\"4781B87\" CurrencyCode=\"EUR\" CurrencyRate=\"0.6700\" InternalName=\"MasterCard&#x20;Promotion&#x20;2014!\" PromotionID=\"63\"/><row Code=\"66DCE99\" CurrencyCode=\"EUR\" CurrencyRate=\"0.6700\" InternalName=\"Bulk&#x20;Purchase&#x20;Promo.\" PromotionID=\"64\"/></resultset>");
	}
}
