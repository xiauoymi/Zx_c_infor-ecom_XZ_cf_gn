package com.intentia.iec.pipeline.runtime.stage.custom.ia;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.ia.dao.IaDao;
import com.intentia.iec.pipeline.runtime.integration.ia.dao.impl.IaDaoRpImpl;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaConnectionException;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.ia.model.IaRecommendation;
import com.intentia.iec.pipeline.runtime.integration.ia.utils.IaConstants;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

public class GetIaRecommendedItemsStage extends AbstractPipelineStage {

	private static final Logger log = Logger
			.getLogger(GetIaRecommendedItemsStage.class);

	private static final String DEFAULT_EVENT = "RecommendItemsByPopularity";
	private static final String DEFAULT_USER_ID = "0";
	private static final String DEFAULT_USERGROUP_ID = "0";
	private static final String DEFAULT_MAX_RECORD = "5";
	private static final String DEFAULT_RECOMMENDER_TYPE = "OrderedItems"; // or
																			// ViewedItem

	Map<String, Float> itemScoresMap = new HashMap<String, Float>();
	boolean useDummy = false; // TODO: Set this to false.
	
	@Override
	public void execute(PipelineContext context)
			throws PipelineRuntimeException {
		log.debug("Start GetIaRecommendedItemsStage.execute() . . .");

		CustomStagesHelper.extractRequestParameters(CustomStagesHelper
				.getRequest(context));
		XMLResultset result = null;
		XMLRequest request = (XMLRequest) context.getRequest();
		Parameters requestParams = request.getParameters();
		try {
			List<IaRecommendation> recommendations = retrieveRecommendationsFromIA(requestParams);

			if ((recommendations != null && !recommendations.isEmpty()) && !useDummy) {
				result = getItemdDetails(recommendations, requestParams);
				addScores(result);

				Map<String, Node> responseMap = responseToMap(result);
				result = sortResponseMap(recommendations, responseMap, result);
			} 
			else if(useDummy)
			{
				result = getItemdDetails(recommendations, requestParams);
			}
			else {
				result = getEmptyResponse();
			}
			log.debug(result.toString());
			context.setResponse(result);
		} catch (ParametersException e) {
			throw new PipelineRuntimeException(
					"Error while retrieving IA recommendations.", e);
		}

	}

	private List<IaRecommendation> retrieveRecommendationsFromIA(
			Parameters requestParams) throws ParametersException,
			PipelineRuntimeException {
		List<IaRecommendation> result = null;
		try {
			Map<String, String> params = new HashMap<String, String>();
			String iaEvent = StringUtils.defaultIfEmpty(
					requestParams.getString("IaRecommendationEvent"),
					DEFAULT_EVENT);
			params = getIaParams(requestParams);
			
			if (!iaEvent.equals(DEFAULT_EVENT)) { // not by popularity
				params.put(
						"eCommItemNumbers",
						StringUtils.defaultIfEmpty(
								requestParams.getString("ItemNumbers"), ""));
			}

			IaDao dao;
			dao = new IaDaoRpImpl();
			result = dao.getRecommendations(iaEvent, params);

			log.debug("IA Item Recommendations : " + result);
		} catch (IaConnectionException e) {
			log.error(
					"Error while connecting to the Interaction Advisor server",
					e);
		} catch (IaRuntimeException e) {
			log.error(
					"Error while retrieving campaigns from the Interaction Advisor server",
					e);
		}

		return result;
	}

	private Map<String, String> getIaParams(Parameters requestParams)
			throws ParametersException {
		Map<String, String> params = new HashMap<String, String>();
		Map<String, String[]> paramMapping = getParamMapping();
		for (Map.Entry<String, String[]> entry : paramMapping.entrySet()) {
			params.put(
					entry.getKey(),
					StringUtils.defaultIfEmpty(
							requestParams.getString(entry.getValue()[0]),
							entry.getValue()[1]));
		}
		return params;
	}

	/*
	 * Generates a map with structure: <IA param name> : [<Request param name>,
	 * <default value>]
	 */
	private Map<String, String[]> getParamMapping() {
		Map<String, String[]> map = new HashMap<String, String[]>();
		map.put("SessionId", new String[] { "SessionId",
				IaConstants.DEF_SESSION_ID });
		map.put("UserId", new String[] { ConstantsForSales.USER_ID_PARAM,
				IaConstants.DEF_USER_ID });
		map.put("GroupId", new String[] { ConstantsForSales._USERGROUPID_PARAM,
				IaConstants.DEF_USERGROUP_ID });
		map.put("RecommendationsCount", new String[] { "MaxRecordParam",
				DEFAULT_MAX_RECORD });
		map.put("Recommender", new String[] { "Recommender",
				DEFAULT_RECOMMENDER_TYPE });

		return map;
	}

	
	private XMLResultset getItemdDetails(
			List<IaRecommendation> recommendations, Parameters requestParams)
			throws PipelineRuntimeException {
		try {
			// Execute BO method
			SearchPipelineExecuter pipeline = new SearchPipelineExecuter(
					ConstantsForSales.PIPELINE_PACKAGE, "Item", "Details",
					SearchPipelineExecuter.OR);
			int pageLimit = 0;

			
			if (!useDummy) {
				// Add request bindings

				for (IaRecommendation recommendation : recommendations) {

					pipeline.setBinding("ItemID",
							recommendation.getItemNumber(), "eq");
					itemScoresMap.put(recommendation.getItemNumber(),
							recommendation.getScore());

				}
				pageLimit = recommendations.size();
			} else {
				// Testing only
				List<String> dummyIds = new ArrayList<String>(
						getDummyRecommendations());
				// Add request bindings
				pageLimit = Integer.parseInt(StringUtils.defaultString(
						requestParams.getString("MaxRecord"),
						DEFAULT_MAX_RECORD));
				Random generator = new Random();
				for (int i = 0; i < pageLimit; i++) {
					int random = generator.nextInt(dummyIds.size());
					pipeline.setBinding("ItemID", dummyIds.get(random), "eq");
					itemScoresMap.put(dummyIds.get(random), (float)i);
				}
			}

			// Add request parameters
			Set<?> paramNames = requestParams.getParameterNames();
			for (Object param : paramNames) {
				String paramName = (String) param;
				pipeline.setParam(paramName, requestParams.getString(paramName));
			}
			// Add limit
			pipeline.setPaging(0, pageLimit);
			return pipeline.execute();

		} catch (PipelineRuntimeException e) {
			throw new PipelineRuntimeException(
					"Error while invoking the Item.Details pipeline", e);
		} catch (ParametersException e) {
			throw new PipelineRuntimeException(
					"Error while setting the request params of Item.Details pipeline",
					e);
		}
	}

	private Map<String, Node> responseToMap(XMLResultset result)
			throws PipelineRuntimeException {
		Map<String, Node> rowMap = new HashMap<String, Node>();
		try {
			Document responseDoc = result.getDocument();
			NodeList rows = XPathAPI.selectNodeList(responseDoc,
					"/resultset/row");
			if (rows != null) {
				for (int i = 0; i < rows.getLength(); i++) {
					Element row = (Element) rows.item(i);
					String itemId = row.getAttribute("ItemID");
					rowMap.put(itemId, row);
				}
			}
		} catch (Exception e) {
			throw new PipelineRuntimeException(
					"Error while converting XMLReponse to Node map.", e);
		}

		return rowMap;
	}

	private String nodeToString(Element node) throws Exception {
		StringWriter sw = new StringWriter();
		Transformer t = TransformerFactory.newInstance().newTransformer();
		t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
		t.transform(new DOMSource(node), new StreamResult(sw));
		return sw.toString();
	}


	@SuppressWarnings("unused")
	private XMLResultset sortResponseMap(
			List<IaRecommendation> recommendations,
			Map<String, Node> responseMap, XMLResultset result)

	throws PipelineRuntimeException {
		log.debug("Unsorted XMLResponse: " + result);
		
		StringBuilder responseStr = new StringBuilder();
		responseStr.append(ConstantsForSales.XML_DATA_HEADER);
		responseStr.append("<resultset object=\"Item\">");
		
		XMLResultset response = null;
		
		try {
			Document resultDoc = result.getDocument();	
			Node resultsetNode = XPathAPI.selectSingleNode(resultDoc, "resultset");
			if (resultsetNode != null) {
				
				for (IaRecommendation recom : recommendations) {
					Element row = (Element) responseMap.get(recom
							.getItemNumber());
					
					String str_node = null;
					
					str_node = nodeToString(row);
					
					if (str_node != null) {
						responseStr.append(str_node);
					}
				}
				responseStr.append("</resultset>");
				response = new XMLResultset(responseStr.toString());
			}
		} catch (Exception e) {
			throw new PipelineRuntimeException(
					"Error while creating new sorted XMLResponse.", e);
		}

		log.debug("Sorted XMLResponse: " + response);
		return response;
	}

	private XMLResultset getEmptyResponse() {
		StringBuilder responseStr = new StringBuilder();
		responseStr.append(ConstantsForSales.XML_DATA_HEADER);
		responseStr.append("<resultset object=\"Item\">");
		responseStr.append("</resultset>");
		return new XMLResultset(responseStr.toString());
	}

	private void addScores(XMLResultset result) throws PipelineRuntimeException {
		try {
			if (result != null && !result.isEmpty()) {
				result.beforeFirst();
				while (result.moveNext()) {
					String key = result.getString("ItemID");
					Float score = itemScoresMap.get(key);
					result.appendField("Score", score.toString());
				}
			}
		} catch (ResultsetException e) {
			throw new PipelineRuntimeException(
					"Unable to add computation data to XML result set", e);
		}
	}

	@SuppressWarnings("unused")
	private void createDummyResponse(PipelineContext context) {
		StringBuilder responseStr = new StringBuilder();
		responseStr.append(ConstantsForSales.XML_DATA_HEADER);
		responseStr.append("<resultset object=\"Item\">");
		for (int i = 0; i < 5; i++) {
			Map<String, String> rowAttributes = new HashMap<String, String>();
			rowAttributes.put("ItemID", String.valueOf(i));
			rowAttributes.put("Name", "Name_" + i);
			rowAttributes.put("Description", "Description_" + i);
			rowAttributes.put("ImagePreview", "campaign/preview/" + i + ".jpg");
			responseStr.append(this.toResultsetRow(rowAttributes));
		}
		responseStr.append("</resultset>");
		log.debug("\n\n" + responseStr + "\n\n");
		context.setResponse(new XMLResultset(responseStr.toString()));
	}

	private List<String> getDummyRecommendations() {
		return Arrays.asList("000001SN", "000001SV", "000010", "000010VIOS",
				"000011", "000012", "000013", "000014", "000015", "000025",
				"0000251", "000090", "00010", "000100", "000100CAMS",
				"000100CMPTST", "000100JOD", "000100RHV", "000100SN",
				"000100SN_RHV", "000100SN+", "000100SN136", "000100SN2",
				"000100SNGATEWAY", "000100SNSP3", "000100SNTRI", "000100SNTST",
				"000100SNVG", "000100SNVG1");
	}

	private String toResultsetRow(Map<String, String> attributes) {
		StringBuilder row = new StringBuilder("<row ");
		for (Map.Entry<String, String> attr : attributes.entrySet()) {
			row.append(attr.getKey() + "=\""
					+ StringEscapeUtils.escapeXml(attr.getValue()) + "\" ");
		}
		row.append(" />");
		return row.toString();
	}

}
