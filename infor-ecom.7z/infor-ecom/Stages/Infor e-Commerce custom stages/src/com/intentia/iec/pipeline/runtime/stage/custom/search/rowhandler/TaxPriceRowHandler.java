package com.intentia.iec.pipeline.runtime.stage.custom.search.rowhandler;

import static com.intentia.iec.pipeline.runtime.stage.custom.search.IndexerUtils.addIndexedField;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.lucene.document.Document;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc;
import com.intentia.iec.pipeline.runtime.stage.custom.search.SearchUtils;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Strings;


/**
 * Adds taxed prices.
 *
 */
public class TaxPriceRowHandler implements Jdbc.RowHandler {
    private Document doc = null;

    public TaxPriceRowHandler(Document doc) {
        this.doc = doc;
    }

    public void processRow(ResultSet rs) throws SQLException, PipelineRuntimeException {
        String listPriceGroupId = rs.getString(Strings.Database.Indexing.Item.TaxPrice.listPriceGroupId);
        String resellPriceGroupId = rs.getString(Strings.Database.Indexing.Item.TaxPrice.resellPriceGroupId);
        String customerId = rs.getString(Strings.Database.Indexing.Item.TaxPrice.customerId);
        String taxPriceListPrice = rs.getString(Strings.Database.Indexing.Item.TaxPrice.taxPriceListPrice);
        String taxNetListPrice = rs.getString(Strings.Database.Indexing.Item.TaxPrice.taxNetListPrice);
        String currencyCode = rs.getString(Strings.Database.Indexing.Item.TaxPrice.currencyCode);
        String countryCode = rs.getString(Strings.Database.Indexing.Item.TaxPrice.countryCode);

        if (listPriceGroupId == null && resellPriceGroupId == null) {
            // for prices with customer prices but no list price/net price
            if (customerId != null && currencyCode != null) {
                // field is
                // price_listprice_netprice_customerid_currency_countrycode
                String field = Strings.Index.Item.taxPricePrefix + customerId + "_" + currencyCode + "_"
                        + countryCode;
                String value = SearchUtils.toPaddedString(taxNetListPrice);
                addIndexedField(doc, field.toLowerCase(), value.toLowerCase());
            }
        } else {
            // for prices with list price/net price
            // field is price_listprice_netprice_currency
            String field = Strings.Index.Item.taxPricePrefix + listPriceGroupId + "_" + resellPriceGroupId + "_"
                    + currencyCode + "_" + countryCode;
            String value = SearchUtils.toPaddedString(taxPriceListPrice);
            addIndexedField(doc, field.toLowerCase(), value.toLowerCase());
            if (customerId != null && currencyCode != null) {
                // for prices with list price/net price and customer price
                // field is
                // price_listprice_netprice_customerid_currency_countrycode
                field = Strings.Index.Item.taxPricePrefix + listPriceGroupId + "_" + resellPriceGroupId + "_"
                        + customerId + "_" + currencyCode + "_" + countryCode;
                value = SearchUtils.toPaddedString(taxNetListPrice);
                addIndexedField(doc, field.toLowerCase(), value.toLowerCase());
            }
        }
    }
}
