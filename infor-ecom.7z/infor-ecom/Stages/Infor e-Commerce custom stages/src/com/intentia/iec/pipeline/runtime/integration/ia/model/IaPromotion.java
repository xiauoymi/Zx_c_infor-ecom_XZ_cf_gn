package com.intentia.iec.pipeline.runtime.integration.ia.model;

import java.util.Comparator;

public class IaPromotion {

	private String id;
	private String internalName;
	private float score = 0;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getInternalName() {
		return internalName;
	}

	public void setInternalName(String internalName) {
		this.internalName = internalName;
	}

	public float getScore() {
		return score;
	}

	public void setScore(float score) {
		this.score = score;
	}

	public static Comparator<IaPromotion> Comparator = new Comparator<IaPromotion>() {
		public int compare(IaPromotion c1, IaPromotion c2) {
			// descending order
			return (c1.getScore() > c2.getScore() ? -1 : (c1.getScore() == c2
					.getScore() ? 0 : 1));
		}
	};

	@Override
	public String toString() {
		StringBuilder promoStr = new StringBuilder();
		promoStr.append("{");
		promoStr.append("id :" + this.id);
		promoStr.append(", internalName :" + this.internalName);
		promoStr.append(", score :" + this.score);
		promoStr.append("}");
		return promoStr.toString();
	}

}
