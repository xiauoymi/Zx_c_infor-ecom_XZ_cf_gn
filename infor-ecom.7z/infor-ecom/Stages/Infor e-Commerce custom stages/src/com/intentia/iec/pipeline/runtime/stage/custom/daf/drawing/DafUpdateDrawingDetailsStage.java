package com.intentia.iec.pipeline.runtime.stage.custom.daf.drawing;

import java.io.StringReader;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.log4j.Logger;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.intentia.icp.common.CMException;
import com.intentia.icp.common.CMItem;
import com.intentia.icp.common.CMItems;
import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafUpdateStage;
import com.intentia.iec.pipeline.runtime.stage.custom.daf.DafConstants;

/**
 * Updates the Drawing details.
 *
 */
public class DafUpdateDrawingDetailsStage extends AbstractDafUpdateStage {
	private static final Logger LOG = Logger.getLogger(DafUpdateDrawingDetailsStage.class);
	
	private DafDrawingRequestSaxHandler handler = null;	
	
	private static final String KEY = "key"; 

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafUpdateStage#getResultSize()
	 * expect only 1
	 */
	@Override
	public int getResultSize() {		
		return 1;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafUpdateStage#getStartIndex()
	 */
	@Override
	public int getStartIndex() {
		return 0;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafUpdateStage#updateItems(com.intentia.icp.common.CMItems, int[])
	 */
	@Override
	public XMLResultset updateItems(CMItems resultItems, int[] dafStatus) throws CMException {
		if (resultItems != null && resultItems.size() > 0) {
			
			CMItem item = resultItems.get(0);
			if (item.isCheckedOut() == false) {
				// only update item if it is not checked out
				LOG.debug("Checking out item=" + item.getId());
				item.checkOut(this.connection);

				// overwrite existing values
				if (this.handler.getAttributeName() != null) {
					String name = this.handler.getAttributeName();
					item.setAttributeValue(DafDrawingConstants.ATTRIBUTE_NAME, name);
				}
				if (this.handler.getAttributeItemNumber() != null) {
					String itemNumber = this.handler.getAttributeItemNumber();
					item.setAttributeValue(DafDrawingConstants.ATTRIBUTE_ITEM_NUMBER, itemNumber);
				}
				if (this.handler.getAttributePrintNumber() != null) {
					String printNumber = this.handler.getAttributePrintNumber();
					item.setAttributeValue(DafDrawingConstants.ATTRIBUTE_DRAWING_NUMBER, printNumber);
				}
				if (this.handler.getAttributeSerialNumber() != null) {
					String serialNumber = this.handler.getAttributeSerialNumber();
					item.setAttributeValue(DafDrawingConstants.ATTRIBUTE_SERIAL_NUMBER, serialNumber);
				}				
				
				if (this.handler.getAttributeIsDefault() != null) {
					Short isDefault = DafDrawingUtils.convertDafIsDefault(this.handler.getAttributeIsDefault());
					item.setAttributeValue(DafDrawingConstants.ATTRIBUTE_IS_DEFAULT, isDefault);
				}
				
				if (this.handler.getStatus() != null) {
					Short status = DafDrawingUtils.convertDafStatus(this.handler.getStatus());
					if (status != -1) {
						item.setAttributeValue(DafDrawingConstants.ATTRIBUTE_STATUS, status);
					}					
				}

				LOG.debug("Updating item=" + item.getId());
				item.update(this.connection);
				
				LOG.debug("Checking in item=" + item.getId());
				item.checkIn(this.connection);
			}
			else {
				LOG.debug("Cannot update item is checked out=" + item.getId());
				dafStatus[0] = DafConstants.ErrorCodes.ITEM_CHECKED_OUT;
			}
		}
		else {
			LOG.debug("Item not found");
			dafStatus[0] = DafConstants.ErrorCodes.ITEM_NOT_FOUND;
		}
		return getEmptyResultSet();
	}

	@Override
	public void setOutputParameters(PipelineContext context) throws PipelineRuntimeException {
		// intentionally blank
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafUpdateStage#addNewItem()
	 */
	@Override
	public XMLResultset addNewItem() throws CMException, ResultsetException, ParametersException {
		XMLResultset resultset = getEmptyResultSet();
		CMItem item = new CMItem();
		item.setEntityName(DafDrawingConstants.ENTITY_NAME);
		
		if (this.handler != null) {
			// retrieve parsed attributes
			if (this.handler.getAttributeItemNumber() != null) {
				item.setAttributeValue(DafDrawingConstants.ATTRIBUTE_ITEM_NUMBER, this.handler.getAttributeItemNumber());
			}
			else {
				item.setAttributeValue(DafDrawingConstants.ATTRIBUTE_ITEM_NUMBER, "");
			}
			
			if (this.handler.getAttributeName() != null) {
				item.setAttributeValue(DafDrawingConstants.ATTRIBUTE_NAME, this.handler.getAttributeName());
			}
			else {
				item.setAttributeValue(DafDrawingConstants.ATTRIBUTE_NAME, "");
			}
			
			if (this.handler.getAttributePrintNumber() != null) {
				item.setAttributeValue(DafDrawingConstants.ATTRIBUTE_DRAWING_NUMBER, this.handler.getAttributePrintNumber());
			}
			else {
				item.setAttributeValue(DafDrawingConstants.ATTRIBUTE_DRAWING_NUMBER, "");
			}
			
			if (this.handler.getAttributeSerialNumber() != null) {
				item.setAttributeValue(DafDrawingConstants.ATTRIBUTE_SERIAL_NUMBER, this.handler.getAttributeSerialNumber());
			}
			else {
				item.setAttributeValue(DafDrawingConstants.ATTRIBUTE_SERIAL_NUMBER, "");
			}			
			
			short isDefault = DafDrawingUtils.convertDafIsDefault(this.handler.getAttributeIsDefault());
			item.setAttributeValue(DafDrawingConstants.ATTRIBUTE_IS_DEFAULT, isDefault);
			
			short status = DafDrawingUtils.convertDafStatus(this.handler.getStatus());
			if (status != -1) {
				item.setAttributeValue(DafDrawingConstants.ATTRIBUTE_STATUS, status);
			}
			
			LOG.debug("Adding new item.");
			item.add(this.connection);

			LOG.debug("New item added=" + item.getId());
			
			// add new row to the result set
			resultset.appendRow();
			resultset.appendField(DafDrawingConstants.FIELD_ID, item.getId());
			
			// set the Key value equal to the @ITEMID
			// this is used by the page when updating the added item
			Parameters params = resultset.getParameters();
			params.setString(KEY, item.getId());
		}
		
		return resultset;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafUpdateStage#getQuery()
	 */
	@Override
	public String getQuery() throws ParametersException, ParserConfigurationException, SAXException, Exception {
        if (this.handler.getKey() != null) {
        	// search by @ITEMID
        	return DafDrawingConstants.TABLE + "[" + DafDrawingConstants.COLUMN_ITEMID + " = \"" + this.handler.getKey() + "\"]";	
        }		

        return null;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafUpdateStage#isKeyExists()
	 */
	@Override
	public boolean isKeyExists() {
		if (this.handler != null && this.handler.getKey() != null) {
			return true;
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafUpdateStage#parseRequest(com.intentia.iec.businessobject.input.XMLRequest)
	 */
	@Override
	public void parseRequest(XMLRequest request) throws Exception {
		try {
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser parser = factory.newSAXParser();
			
			this.handler = new DafDrawingRequestSaxHandler();
	        String xml = request.getRequestString();
	        LOG.debug("Parsing request:\n" + xml);
	        parser.parse(new InputSource(new StringReader(xml)), handler);	       
		}
		catch (Exception e) {
			throw e;
		}
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafStage#getAttributeToDafDatabaseField(java.lang.String)
	 */
	@Override
	public String getAttributeToDafDatabaseField(String attribute) {
		return null;
	}
}
