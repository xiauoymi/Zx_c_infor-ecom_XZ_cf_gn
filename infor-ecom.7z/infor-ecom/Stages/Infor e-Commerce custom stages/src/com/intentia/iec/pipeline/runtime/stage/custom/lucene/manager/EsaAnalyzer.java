package com.intentia.iec.pipeline.runtime.stage.custom.lucene.manager;

import java.io.Reader;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.LowerCaseFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.standard.StandardTokenizer;

public class EsaAnalyzer extends Analyzer {

    /**
     * Splits the text from the Reader into tokens. Splits on whitespace and
     * then lower-cases.
     * 
     * @param fieldName
     *            The name of the field. Not used.
     * @param reader
     *            A Reader containing the string to be tokenized.
     * @return A stream of tokens.
     */
    @Override
    public TokenStream tokenStream(final String fieldName, final Reader reader) {
        // TODO: identify if this approach is enough for e-Sales indexing
        // requirements
        return new LowerCaseFilter(new StandardTokenizer(reader));
    }
}
