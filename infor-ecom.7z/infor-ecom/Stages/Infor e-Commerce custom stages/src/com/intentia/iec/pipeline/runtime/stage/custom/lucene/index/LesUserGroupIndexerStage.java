package com.intentia.iec.pipeline.runtime.stage.custom.lucene.index;

import java.util.Map;

import org.apache.lucene.document.Document;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

/**
 * 
 * @author 15062
 * 
 */
public final class LesUserGroupIndexerStage extends AbstractIndexerStage {

    private static final String INDEX_NAME = "LesUserGroup";

    private static final String BO_NAME = "UserGroup";

    private static final String BO_METHOD_NAME = "GetUserGroupsForLesUserGroupIndex";

    private static final String KEY_ATTRIBUTE_NAME = ConstantsForSales.USERGROUPID;

    protected String getIndexName() {
        return INDEX_NAME;
    }

    protected String getBOName() {
        return BO_NAME;
    }

    protected String getBOMethodName() {
        return BO_METHOD_NAME;
    }

    protected String getKeyAttributeName() {
        return KEY_ATTRIBUTE_NAME;
    }

    protected void setAdditionalRequestParameters(SearchPipelineExecuter pipeline) {
        pipeline.setParam(ConstantsForSales.APPROVER_FEATURE_ID_PARAM, "67");
        // TODO: Add parameters here (if needed)
    }

    protected void setAdditionalRequestBindings(SearchPipelineExecuter pipeline) {
        // TODO: Add bindings here (if needed)
    }

    protected void addMoreFields(Map<String, Document> docMap) throws PipelineRuntimeException {
        // TODO: add more field here (if needed)
    }

}