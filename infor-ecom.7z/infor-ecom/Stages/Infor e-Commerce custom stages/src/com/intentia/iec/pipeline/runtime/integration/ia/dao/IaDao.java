package com.intentia.iec.pipeline.runtime.integration.ia.dao;

import java.util.List;
import java.util.Map;

import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.ia.model.IaCampaign;
import com.intentia.iec.pipeline.runtime.integration.ia.model.IaPromotion;
import com.intentia.iec.pipeline.runtime.integration.ia.model.IaRecommendation;
import com.intentia.iec.pipeline.runtime.integration.ia.utils.IaConstants.AcceptanceLevel;


public interface IaDao {
	
	void addCampaign(IaCampaign campaign) throws IaRuntimeException;
	
	void deleteCampaign(IaCampaign campaign) throws IaRuntimeException;
	
	void addPromotion(IaPromotion promotion) throws IaRuntimeException;
	
	void deletePromotion(IaPromotion promotion) throws IaRuntimeException;
	
	List<IaCampaign> getCampaigns(String event, Map<String, String> params) throws IaRuntimeException;
	
	List<IaPromotion> getPromotions(String event, Map<String, String> params) throws IaRuntimeException;
	
	List<IaRecommendation> getRecommendations(String event, Map<String, String> params) throws IaRuntimeException;
	
	void refinePackage() throws IaRuntimeException;
	
	void deployPackage() throws IaRuntimeException;
	
	void extendCampaigns(String ids, Map<String, String> params) throws IaRuntimeException;
	
	void extendPromotions(String ids, Map<String, String> params) throws IaRuntimeException;
	
	void acceptCampaigns(String ids, AcceptanceLevel level, Map<String, String> params) throws IaRuntimeException;
	
	void acceptPromotions(String ids, AcceptanceLevel level, Map<String, String> params) throws IaRuntimeException;
	
	void endSession(String sessionId, String userId, String groupId) throws IaRuntimeException;
	
}
