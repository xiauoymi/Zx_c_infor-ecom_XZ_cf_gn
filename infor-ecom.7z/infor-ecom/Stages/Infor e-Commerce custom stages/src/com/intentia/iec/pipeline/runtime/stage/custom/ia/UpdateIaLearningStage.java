package com.intentia.iec.pipeline.runtime.stage.custom.ia;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.ia.dao.IaDao;
import com.intentia.iec.pipeline.runtime.integration.ia.dao.impl.IaDaoRpImpl;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaConnectionException;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.ia.utils.IaConstants;
import com.intentia.iec.pipeline.runtime.integration.ia.utils.IaConstants.AcceptanceLevel;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;

public class UpdateIaLearningStage extends AbstractPipelineStage {

	private static final Logger log = Logger
			.getLogger(UpdateIaLearningStage.class);

	private enum UserActivity { // Subset of the one in JspBase.java file
		SeenCampaign, ClickCampaign, SeenPromotion, ClickPromotion, AvailedCampaign, AvailedPromotion
	}

	@Override
	public void execute(PipelineContext context)
			throws PipelineRuntimeException {
		log.debug("Executing UpdateIaLearningStage.execute()...");
		try {
			CustomStagesHelper.extractRequestParameters(CustomStagesHelper
					.getRequest(context));
			XMLRequest request = (XMLRequest) context.getRequest();
			Parameters requestParams = request.getParameters();
			UserActivity activity = null;
			try {
				activity = UserActivity.valueOf(requestParams
						.getString("activity"));
			} catch (IllegalArgumentException e) {
				log.error(requestParams.getString("activity")
						+ " activity is not part of IA learning.");
			}

			if (activity != null) {
				updateLearning(activity, requestParams);
			}
		} catch (Exception e) {
			log.error("Error while updating IA communication learning.", e);
		}
	}

	private void updateLearning(UserActivity activity, Parameters requestParams)
			throws PipelineRuntimeException, ParametersException {
		try {
			String id = requestParams.getString("value");
			IaDao dao = new IaDaoRpImpl();

			switch (activity) {
			case SeenCampaign:
				dao.extendCampaigns(id, getIaParams(requestParams));
				break;
			case ClickCampaign:
				dao.acceptCampaigns(id, AcceptanceLevel.Clicked,
						getIaParams(requestParams));
				break;
			case SeenPromotion:
				dao.extendPromotions(id, getIaParams(requestParams));
				break;
			case ClickPromotion:
				dao.acceptPromotions(id, AcceptanceLevel.Clicked,
						getIaParams(requestParams));
				break;
			case AvailedCampaign:
				dao.acceptCampaigns(id, AcceptanceLevel.Accepted,
						getIaParams(requestParams));
				break;
			case AvailedPromotion:
				dao.acceptPromotions(id, AcceptanceLevel.Accepted,
						getIaParams(requestParams));
				break;
			}
		} catch (IaConnectionException e) {
			log.error(
					"Error while connecting to IA server. Unable to update IA learning for activity = "
							+ activity, e);
		} catch (IaRuntimeException e) {
			log.error("Error while updating IA learning for activity = "
					+ activity, e);
		}
	}

	private Map<String, String> getIaParams(Parameters requestParams)
			throws ParametersException {
		Map<String, String> params = new HashMap<String, String>();
		Map<String, String[]> paramMapping = getParamMapping();
		for (Map.Entry<String, String[]> entry : paramMapping.entrySet()) {
			params.put(
					entry.getKey(),
					StringUtils.defaultIfEmpty(
							requestParams.getString(entry.getValue()[0]),
							entry.getValue()[1]));
		}
		return params;
	}

	/*
	 * Generates a map with structure: <IA param name> : [<Request param name>,
	 * <default value>]
	 */
	private Map<String, String[]> getParamMapping() {
		Map<String, String[]> paramMapping = new HashMap<String, String[]>();
		paramMapping.put("SessionId", new String[] { "SessionId",
				IaConstants.DEF_SESSION_ID });
		paramMapping.put("UserId", new String[] {
				ConstantsForSales.USER_ID_PARAM, IaConstants.DEF_USER_ID });
		paramMapping.put("GroupId", new String[] {
				ConstantsForSales._USERGROUPID_PARAM,
				IaConstants.DEF_USERGROUP_ID });
		paramMapping.put("CurrentPageId", new String[] { "CurrentPageId", "" });
		paramMapping.put("ItemCategoryIdsInCart", new String[] {
				"ItemCategoryIdsInCart", "" });
		paramMapping.put("ViewedItemCategoryIds", new String[] {
				"ViewedItemCategoryIds", "" });
		paramMapping.put("SearchedItemCategoryIds", new String[] {
				"SearchedItemCategoryIds", "" });
		return paramMapping;
	}

}
