package com.intentia.iec.pipeline.runtime.stage.custom.daf;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.xml.sax.SAXException;

import com.intentia.icp.common.CMException;
import com.intentia.icp.common.CMItems;
import com.intentia.icp.common.Connection;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;

/**
 * Defines the usual flow of a search stage when connected to DAF.
 * The usual flow is:
 * 	1. Get query.
 * 	2. Create connection to DAF.
 *	3. Perform search.
 *	4. Process search results.
 *	5. Disconnect.
 *
 * The subclass must create the methods for:
 * 	1. Get query.
 * 	2. Process search results.
 *
 */
public abstract class AbstractDafSearchStage extends AbstractDafStage {

	/**
	 * 
	 */
	private static final Logger LOG = Logger.getLogger(AbstractDafSearchStage.class);
	
	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.AbstractPipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	public void execute(final PipelineContext context) throws PipelineRuntimeException {
		
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
        
        CustomStagesHelper.extractRequestParameters(CustomStagesHelper.getRequest(context));
        
        try {
			if (skipStage(context) == true) {
				LOG.debug("Skipping stage");
				return;
			}
		} catch (ParametersException e1) {
			throw new PipelineRuntimeException(e1);
		}
        
        int[] dafStatus = {0};
        XMLResultset result = getEmptyResultSet();
		
		try {
			// Get query string from subclass
			String query = getQuery(context);
			
			// if query does not exist, do not connect to DAF 
			if (query != null) {
				initialize();
				LOG.debug("Creating DAF Connection(datastore=" + this.datastore + ", " +
						"username=" + this.username + ", " +
						"password=" + "<hidden>" + ", " +
						"schema=" + this.schema + ", " +
						"language=" + this.language + ", " +
						"sqluid=" + this.sqluid + ", " +
						"sqlpwd=" + "<hidden>" + ", " +
						"jdbcDriver=" + this.jdbcDriver + ", " +
						"jdbcUrl=" + this.jdbcUrl + ")");
				this.connection = new Connection(this.datastore, this.username, this.password, this.schema, this.language, this.sqluid, this.sqlpwd, this.jdbcDriver, this.jdbcUrl);		

				// connect do DAF
				LOG.debug("Connecting to DAF Server");
				this.connection.connect();								
				
				// perform search using the query string
				LOG.debug("Performing DAF Search(query=" + query +
						" startIndex=" + getStartIndex() +
						" resultSize=" + getResultSize() +
						" retrieveOption=" + this.retrieveOption + ")");
				long startTime = System.currentTimeMillis();
				CMItems resultItems = CMItems.search(connection, query, getStartIndex(), getResultSize(), this.retrieveOption);
				long stopTime = System.currentTimeMillis();
				LOG.debug("Total search time: " + (stopTime - startTime) + " ms");
				
				// subclass will process the results
				startTime = System.currentTimeMillis();
				result = processResult(resultItems, dafStatus);
				stopTime = System.currentTimeMillis();
				LOG.debug("Total processing time: " + (stopTime - startTime) + " ms");
			}		

		}
		catch (CMException e) {
			dafStatus[0] = DafConstants.ErrorCodes.DAF_TRANSACTION_ERROR;
			LOG.error(e);
		}
		catch (ParametersException e) {
			dafStatus[0] = DafConstants.ErrorCodes.DAF_PARSE_ERROR;
			LOG.error(e);
		}
		catch (Exception e) {
			dafStatus[0] = DafConstants.ErrorCodes.DAF_OTHER_ERROR;
			LOG.error(e);
		}
		finally {
			// perform clean-up
			if (this.connection != null) {
				boolean ret = this.connection.disconnectSilent();
				this.connection = null;
				LOG.debug("Disconnected to DAF Server: " + ret);
			}

			// if result was provided by subclass, set to context
			if (result != null) {
				context.setResponse(result);
			}

			// if response object (XMLResultset) is present, set the DAF status output parameter
			if (context.getResponse() != null) {
				setDafStatus(context, dafStatus[0]);	
			}

			// set other output parameters, if required by the subclass
			setOutputParameters(context);
		}		
	}

	
	/**
	 * Helper method for setting the DAF status output parameter.
	 * @param context
	 * @param status
	 * @throws PipelineRuntimeException
	 */
	private void setDafStatus(PipelineContext context, int status) throws PipelineRuntimeException {
		LOG.debug(DafConstants.DAFSTATUS + "=" + status);
		CustomStagesHelper.setResponseParameter(context, DafConstants.DAFSTATUS, String.valueOf(status));
	}
	
	/**
	 * Sets other output parameters, if needed.
	 * @param context
	 * @throws PipelineRuntimeException
	 */
	public abstract void setOutputParameters(PipelineContext context) throws PipelineRuntimeException;
	
	/**
	 * Returns the required start index when searching.
	 * @return
	 */
	public abstract int getStartIndex();
	
	/**
	 * Returns the required result size when searching.
	 * @return
	 */
	public abstract int getResultSize();
	
	/**
	 * Process the search result.
	 * @param resultItems search result from DAF
	 * @param dafStatus contains the DAF status. The subclass may change the value depending on the result.
	 * @return XMLResultset object that will be set to the PipelineContext, if not null
	 * @throws CMException
	 * @throws ParametersException
	 * @throws ResultsetException 
	 */
	public abstract XMLResultset processResult(CMItems resultItems, int[] dafStatus) throws CMException, ParametersException, ResultsetException;
	
	/**
	 * Returns the query string that will be sent to DAF for searching.
	 * @param context
	 * @return
	 * @throws ParametersException
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws Exception
	 */
	public abstract String getQuery(PipelineContext context) throws ParametersException, ParserConfigurationException, SAXException, Exception;
	
	/**
	 * Check if the stage should be executed.
	 * @param context
	 * @return
	 * @throws ParametersException
	 * @throws PipelineRuntimeException
	 */
	public boolean skipStage(PipelineContext context) throws ParametersException, PipelineRuntimeException {
		return false;
	}
}
