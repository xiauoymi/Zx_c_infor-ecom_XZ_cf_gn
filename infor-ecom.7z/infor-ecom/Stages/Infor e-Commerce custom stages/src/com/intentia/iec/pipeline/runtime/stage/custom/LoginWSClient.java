package com.intentia.iec.pipeline.runtime.stage.custom;

import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

import org.apache.log4j.Logger;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
 
//import org.tempuri.ESalesService;
//import org.tempuri.IESalesService;

//import com.infor.LoginRequest;
//import com.infor.ObjectFactory;

public class LoginWSClient implements PipelineStage {

	/**
	 * LoginWSClient
	 * 
	 * Developed by: Gerald Tajonera
	 * 
	 * LoginWSClient is a webservice client for User registration service to SyteLine.
	 * 
	 * 
	 */
	 
	private static final Logger LOG = Logger.getLogger(LoginWSClient.class);
	
	private XMLRequest xmlRequest = null;
	
	private XMLResultset speResult = null;
	
	private Document request = null;
	
	private String[] params = {"WebServiceServer", "WebServiceConfigName", "WebServiceUserID", "WebServiceUserPassword"};
	
	private String[] WSValues = new String[4];
	
	public void execute(PipelineContext context) throws PipelineRuntimeException {
		
		LOG.debug("Inside LoginWSClient.execute()");
		
		// Creates ESalesService instance
		// Creates IESalesService port connection
		//ESalesService service = new ESalesService();
		//IESalesService port = service.getESalesServiceSoap();
				
		//ObjectFactory of = new ObjectFactory();
		
		if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
		
		xmlRequest = (XMLRequest) context.getRequest();
		
		try {
            XMLRequest.extractRequestParameters(xmlRequest);
        } catch (RequestException e) {
            throw new PipelineRuntimeException("Error extracting request parameters!", e);
        }
		
		// Retrieving LogIn credentials in ApplicationData table.
		
		try {
			for (int i = 0; i < params.length; i++) {
				
				SearchPipelineExecuter spe = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "ApplicationData",
		                "Details");
		        
				spe.setParam("param", params[i]);
				speResult = spe.execute();
				/*speResult.beforeFirst();
				speResult.moveNext();*/
				speResult.moveFirst();
				WSValues[i] = speResult.getString("ParameterValue");
			}
		
		} catch (Exception e) {
			LOG.debug("Error Executing SearchPipelineExecuterStage!", e);
		}
		
		
		LOG.debug("LoginRequest parameters from ApplicationData retrieved: ");
		for (int i = 0; i < params.length; i++) {
			LOG.debug("Parameter: " +WSValues[i]);
		}
	
		try {
/*			
			LoginRequest loginRequest = new LoginRequest();
			// *WSValues[0] = WebServiceServer parameter value
			loginRequest.setServer(of.createLoginRequestServer(WSValues[0]));
			// *WSValues[1] = WebServiceConfigName parameter value
			loginRequest.setConfigName(of.createLoginRequestConfigName(WSValues[1]));
			// *WSValues[2] = WebServiceUserID parameter value
			loginRequest.setUserID(of.createLoginRequestUserID(WSValues[2]));
			// *WSValues[3] = WebServicePassword parameter value
	        loginRequest.setPassword(of.createLoginRequestPassword(WSValues[3]));
 
	        String loginResponse = port.login(loginRequest);
	        
	        LOG.debug("LoginResponse: " +loginResponse);
*/	        
		} catch (Exception e) {
			LOG.debug("Error Sending Login Request to SyteLine!", e);
		}
		
		/*
		try {
			nodeList = XPathAPI.selectNodeList(request,
					"request/entities/entity/keys/key[@value=\"WebServiceServer\"]");
			
			if (nodeList.getLength() > 0) {
				Node node = nodeList.item(0);
				LOG.debug("WebServiceServer: " +xmlHelper.getAttribute(node, "ParameterValue"));
			}
			
			nodeList = XPathAPI.selectNodeList(request,
					"request/entities/entity/keys/key[@value=\"WebServiceConfigName\"]");
			
			if (nodeList.getLength() > 0) {
				Node node = nodeList.item(0);
				LOG.debug("WebServiceConfigName: " +xmlHelper.getAttribute(node, "ParameterValue"));
			}
			
			nodeList = XPathAPI.selectNodeList(request,
					"request/entities/entity/keys/key[@value=\"WebServiceUserID\"]");
			
			if (nodeList.getLength() > 0) {
				Node node = nodeList.item(0);
				LOG.debug("WebServiceUserID: " +xmlHelper.getAttribute(node, "ParameterValue"));
			}
			
			nodeList = XPathAPI.selectNodeList(request,
					"request/entities/entity/keys/key[@value=\"WebServicePassword\"]");
			
			if (nodeList.getLength() > 0) {
				Node node = nodeList.item(0);
				LOG.debug("WebServicePassword: " +xmlHelper.getAttribute(node, "ParameterValue"));
			}
			
		} catch (Exception e) {
			LOG.debug("Error Sending Login Request to SyteLine!", e);
		}
		*/
		LOG.debug("Exiting LoginWSClient.execute()");
	}
}
