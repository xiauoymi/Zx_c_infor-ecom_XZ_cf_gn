package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;

import org.apache.log4j.Logger;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.traversal.DocumentTraversal;
import org.w3c.dom.traversal.NodeFilter;
import org.w3c.dom.traversal.NodeIterator;

import com.google.api.gbase.client.FeedURLFactory;
import com.google.api.gbase.client.GoogleBaseEntry;
import com.google.api.gbase.client.GoogleBaseQuery;
import com.google.api.gbase.client.GoogleBaseService;
import com.google.gdata.data.TextConstruct;
import com.google.gdata.util.AuthenticationException;

import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntime;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.custom.pim.CatalogIntegrationException;
import com.intentia.iec.pipeline.runtime.stage.utils.ApplicationParameter;
import com.intentia.iec.pipeline.runtime.stage.utils.Decimal;
import com.intentia.iec.sqlserver.runtime.jdbc.JDBCReader;
import com.intentia.iec.util.FastStringBuffer;

/**
 * This class in real helping into upload the all item data to the Google Base
 * Servers and consecutively it updates the Google Item table to Store the
 * googleItemId into it.
 * 
 * @author xinc0082(Mayur)
 */
public class UploadItemToSearchEngine {

    private static final Logger LOG = Logger.getLogger(UploadItemToSearchEngine.class);

    public static long count = 0;

    public static void uploadItems(String language, String country, String currency, Integer searchEngineSystemId,
            String baseCurrency, String listPriceGroupName, boolean isAssortment) {
        LOG.debug("Inside UploadItemToSearchEngine.uploadItems()");
        try {
            if (country != null && language != null && currency != null && searchEngineSystemId != null) {
                if (!isAssortment) {// If there is not any assortment all items
                                    // would be uploaded
                    UploadItemToSearchEngine.uploadAllNewItem(language, country, currency, searchEngineSystemId,
                            baseCurrency, listPriceGroupName);
                } else { // if any assortment for search engine is there then
                            // only those items would be uploaded
                    UploadItemToSearchEngine.uploadAllNewItemByAssortment(language, country, currency,
                            searchEngineSystemId, baseCurrency, listPriceGroupName);
                }
            }
        } catch (Exception ex) {
            LOG.error("Inside UploadItemToSearchEngine.uploadItems() Exception ", ex);
        }
    }

    public static void updateItems(String language, String country, String currency, Integer searchEngineSystemId,
            String baseCurrency, String listPriceGroupName, boolean isAssortment) {
        LOG.debug("Inside UploadItemToSearchEngine.updateItems()");

        try {
            if (country != null && language != null && currency != null && searchEngineSystemId != null) {
                if (!isAssortment) {// If there is not any assortment for search
                                    // enginer then all uploaded items would be
                                    // update
                    UploadItemToSearchEngine.updateAllItem(language, country, currency, searchEngineSystemId,
                            baseCurrency, listPriceGroupName);
                } else { // If there is any assortment for search engine then
                            // all uploaded items would be updated for these
                            // assortment
                    UploadItemToSearchEngine.updateAllItemByAssortment(language, country, currency,
                            searchEngineSystemId, baseCurrency, listPriceGroupName);
                }
            }
        } catch (Exception ex) {
            LOG.error("Inside UploadItemToSearchEngine.updateItems() Exception ", ex);
        }
    }

    public static void uploadAllNewItem(String language, String country, String currency, Integer searchEngineSystemId,
            String baseCurrency, String listPriceGroupName) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        XMLResultset resultset = null;
        String baseUrl = null;
        int cnt = 0;

        LOG.debug("Inside UploadItemToSearchEngine.uploadAllNewItem()");

        try {

            try {
                baseUrl = ApplicationParameter.getValue("ApplicationURLB2C").trim();
            } catch (PipelineRuntimeException e) {
                throw new PipelineRuntimeException("Failure in getting from Application Details ", e);
            } catch (ResultsetException e) {
                throw new PipelineRuntimeException("ResultsetException ", e);
            }

            con = (Connection) CustomStagesHelper.getConnection("esales.cursor");

            stmt = con.prepareStatement(SearchEngineHelper.INSERT_SQL);

            stmt.setObject(1, language, Types.VARCHAR);
            stmt.setObject(2, baseCurrency, Types.VARCHAR);
            stmt.setObject(3, listPriceGroupName, Types.VARCHAR);
            stmt.setObject(4, baseCurrency, Types.VARCHAR);
            stmt.setObject(5, language, Types.VARCHAR);
            stmt.setObject(6, searchEngineSystemId, Types.INTEGER);

            rs = stmt.executeQuery();

            resultset = new JDBCReader(rs).getContent(); // filling JDBC
                                                            // Resultset into
                                                            // XMLResultset

            convertToAltCurrency(resultset, currency, baseCurrency); // calculate
                                                                        // prices
                                                                        // into
                                                                        // alternate
                                                                        // currency.

            rs.close();
            stmt.close();
            con.close();

            GoogleBaseService service = new GoogleBaseService("esales", ApplicationParameter.getValue(
                    "GoogleBaseAPIKey").trim());

            try {
                service.setUserCredentials(ApplicationParameter.getValue("GoogleAccount").trim(), ApplicationParameter
                        .getValue("GoogleAccountPassword").trim());
            } catch (Exception ex) {
                LOG.debug("Exception occurred inside uploadAllNewItem() Authentication , " + ex);
            }

            GoogleBaseQuery gbq = new GoogleBaseQuery(FeedURLFactory.getDefault().getItemsFeedURL());
            // gbq.setGoogleBaseQuery("products");

            GoogleBaseEntry entry = null;
            String asInserted = null;
            SearchEngineItemBean gbsItemBean = null;

            resultset.beforeFirst();

            while (resultset.hasNext()) {
                LOG.debug("Inside resultset.hasNext() of uploadAllNewItem()");

                resultset.moveNext();
                gbsItemBean = SearchEngineHelper.getSearchEngineBeanForInsert(resultset, baseUrl);

                entry = new GoogleBaseEntry();
                entry.setTitle(TextConstruct.create(TextConstruct.Type.TEXT, gbsItemBean.getTitle(), null));
                entry.setContent(TextConstruct.create(TextConstruct.Type.TEXT, gbsItemBean.getContent(), null));
                entry.getGoogleBaseAttributes().setItemType("products");
                entry.getGoogleBaseAttributes().setPriceUnits(gbsItemBean.getUnit());
                entry.getGoogleBaseAttributes().setPrice(gbsItemBean.getPrice(), currency);
                entry.getGoogleBaseAttributes().addTextAttribute("target_country", country);
                entry.getGoogleBaseAttributes().addTextAttribute("item_language", language);
                entry.addHtmlLink(gbsItemBean.getBaseUrl(), "en", "Lawson E-Sales");
                entry.setSummary(TextConstruct.create(TextConstruct.Type.TEXT, gbsItemBean.getSummary(), null));
                entry.getGoogleBaseAttributes().addImageLink(gbsItemBean.getImageURL()); // actual
                                                                                            // item
                                                                                            // image
                                                                                            // link
                // entry.getGoogleBaseAttributes().addImageLink("http://base.google.com/base_media?q=hand3481826980094929739&dhm=ea555999&hl=en&size=2");

                entry.getGoogleBaseAttributes().addLabel("E-Sales");
                entry.getGoogleBaseAttributes().addUrlAttribute("my site url", baseUrl);
                entry.getGoogleBaseAttributes().addTextAttribute("brand", gbsItemBean.getBrand());

                try {
                    asInserted = (service.insert(gbq.getUrl(), entry)).getId();
                } catch (Exception e) {
                    System.out.println("Inside insert Exception" + e);
                    e.printStackTrace();
                }

                if (asInserted != null) {
                    cnt++;
                    UploadItemToSearchEngine.updateSearchEngineItem(asInserted, gbsItemBean.getId(),
                            searchEngineSystemId);
                }

            }// end of while(resultset.hasNext())

            LOG.debug("Total Item uploaded on GoogleBase : " + cnt);

        } catch (Exception e) {
            LOG.error("Error occurred inside uploadAllNewItem() in rs.next().......", e);
        } finally {
            CustomStagesHelper.close(con, stmt, rs);
        }

    }

    public static void uploadAllNewItemByAssortment(String language, String country, String currency,
            Integer searchEngineSystemId, String baseCurrency, String listPriceGroupName) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        XMLResultset resultset = null;
        String baseUrl = null;
        int cnt = 0;

        LOG.debug("Inside UploadItemToSearchEngine.uploadAllNewItemByAssortment()");

        try {

            try {
                baseUrl = ApplicationParameter.getValue("ApplicationURLB2C").trim();
            } catch (PipelineRuntimeException e) {
                throw new PipelineRuntimeException("Failure in getting from Application Details ", e);
            } catch (ResultsetException e) {
                throw new PipelineRuntimeException("ResultsetException ", e);
            }

            con = (Connection) CustomStagesHelper.getConnection("esales.cursor");

            stmt = con.prepareStatement(SearchEngineHelper.INSERT_ASSORTMENTS);

            stmt.setObject(1, language, Types.VARCHAR);
            stmt.setObject(2, baseCurrency, Types.VARCHAR);
            stmt.setObject(3, listPriceGroupName, Types.VARCHAR);
            stmt.setObject(4, baseCurrency, Types.VARCHAR);
            stmt.setObject(5, language, Types.VARCHAR);
            stmt.setObject(6, searchEngineSystemId, Types.INTEGER);
            stmt.setObject(7, language, Types.VARCHAR);
            stmt.setObject(8, baseCurrency, Types.VARCHAR);
            stmt.setObject(9, listPriceGroupName, Types.VARCHAR);
            stmt.setObject(10, baseCurrency, Types.VARCHAR);
            stmt.setObject(11, language, Types.VARCHAR);
            stmt.setObject(12, searchEngineSystemId, Types.INTEGER);

            rs = stmt.executeQuery();

            resultset = new JDBCReader(rs).getContent(); // filling JDBC
                                                            // Resultset into
                                                            // XMLResultset

            convertToAltCurrency(resultset, currency, baseCurrency); // calculate
                                                                        // prices
                                                                        // into
                                                                        // alternate
                                                                        // currency.

            rs.close();
            stmt.close();
            con.close();

            GoogleBaseService service = new GoogleBaseService("esales", ApplicationParameter.getValue(
                    "GoogleBaseAPIKey").trim());

            try {
                service.setUserCredentials(ApplicationParameter.getValue("GoogleAccount").trim(), ApplicationParameter
                        .getValue("GoogleAccountPassword").trim());
            } catch (Exception ex) {
                LOG.debug("Exception occurred inside uploadAllNewItemByAssortment() Authentication , " + ex);
            }

            GoogleBaseQuery gbq = new GoogleBaseQuery(FeedURLFactory.getDefault().getItemsFeedURL());
            // gbq.setGoogleBaseQuery("products");

            GoogleBaseEntry entry = null;
            String asInserted = null;
            SearchEngineItemBean gbsItemBean = null;

            resultset.beforeFirst();

            while (resultset.hasNext()) {
                LOG.debug("Inside resultset.hasNext() of uploadAllNewItemByAssortment()");

                resultset.moveNext();
                gbsItemBean = SearchEngineHelper.getSearchEngineBeanForInsert(resultset, baseUrl);

                entry = new GoogleBaseEntry();
                entry.setTitle(TextConstruct.create(TextConstruct.Type.TEXT, gbsItemBean.getTitle(), null));
                entry.setContent(TextConstruct.create(TextConstruct.Type.TEXT, gbsItemBean.getContent(), null));
                entry.getGoogleBaseAttributes().setItemType("products");
                entry.getGoogleBaseAttributes().setPriceUnits(gbsItemBean.getUnit());
                entry.getGoogleBaseAttributes().setPrice(gbsItemBean.getPrice(), currency);
                entry.getGoogleBaseAttributes().addTextAttribute("target_country", country);
                entry.getGoogleBaseAttributes().addTextAttribute("item_language", language);
                entry.addHtmlLink(gbsItemBean.getBaseUrl(), "en", "Lawson E-Sales");
                entry.setSummary(TextConstruct.create(TextConstruct.Type.TEXT, gbsItemBean.getSummary(), null));
                entry.getGoogleBaseAttributes().addImageLink(gbsItemBean.getImageURL()); // actual
                                                                                            // item
                                                                                            // image
                                                                                            // link
                // entry.getGoogleBaseAttributes().addImageLink("http://base.google.com/base_media?q=hand3481826980094929739&dhm=ea555999&hl=en&size=2");
                entry.getGoogleBaseAttributes().addLabel("E-Sales");
                entry.getGoogleBaseAttributes().addUrlAttribute("my site url", baseUrl);
                entry.getGoogleBaseAttributes().addTextAttribute("brand", gbsItemBean.getBrand());

                try {
                    asInserted = (service.insert(gbq.getUrl(), entry)).getId();
                } catch (Exception e) {
                    System.out.println("Inside insert Exception" + e);
                    e.printStackTrace();
                }

                if (asInserted != null) {
                    cnt++;
                    UploadItemToSearchEngine.updateSearchEngineItem(asInserted, gbsItemBean.getId(),
                            searchEngineSystemId);
                }

            }// end of while(resultset.hasNext())

            LOG.debug("Total Item uploaded on GoogleBase : " + cnt);

        } catch (Exception e) {
            LOG.error("Exception occurred inside  uploadAllNewItemByAssortment()  inside rs.next().......", e);
        } finally {
            CustomStagesHelper.close(con, stmt, rs);
        }

    }

    public static boolean updateSearchEngineItem(String searchEngineItemId, Long itemId, Integer searchEngineSystemId) {
        boolean result = false;
        Connection con = null;
        PreparedStatement stmt = null;

        LOG.debug("Inside UploadItemToSearchEngine.updateSearchEngineItem()");

        try {

            con = (Connection) CustomStagesHelper.getConnection("esales.cursor");
            stmt = con.prepareStatement(SearchEngineHelper.INSERTSearchEngineItem_SQL);

            stmt.setObject(1, itemId, Types.BIGINT);
            stmt.setObject(2, searchEngineSystemId, Types.INTEGER);
            stmt.setObject(3, searchEngineItemId, Types.VARCHAR);

            result = stmt.execute();

            LOG.debug("Inside UploadItemToSearchEngine.updateSearchEngineItem() status : " + result);

        } catch (Exception e) {
            LOG.error("Inside Update SearchEngineItem Table ", e);

        } finally {
            CustomStagesHelper.close(con, stmt, null);
        }

        return result;
    }

    public static boolean updateAllItem(String language, String country, String currency, Integer searchEngineSystemId,
            String baseCurrency, String listPriceGroupName) {
        boolean result = false;
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        XMLResultset resultset = null;
        String baseUrl = null;

        LOG.debug("Inside UploadItemToSearchEngine.updateAllItem()");

        try {
            try {
                baseUrl = ApplicationParameter.getValue("ApplicationURLB2C").trim();
            } catch (PipelineRuntimeException e) {
                throw new PipelineRuntimeException("Failure in getting from Application Details ", e);
            } catch (ResultsetException e) {
                throw new PipelineRuntimeException("ResultsetException ", e);
            }

            con = (Connection) CustomStagesHelper.getConnection("esales.cursor");
            stmt = con.prepareStatement(SearchEngineHelper.UPDATE_SQL);

            stmt.setObject(1, language, Types.VARCHAR);
            stmt.setObject(2, baseCurrency, Types.VARCHAR);
            stmt.setObject(3, listPriceGroupName, Types.VARCHAR);
            stmt.setObject(4, baseCurrency, Types.VARCHAR);
            stmt.setObject(5, language, Types.VARCHAR);
            stmt.setObject(6, searchEngineSystemId, Types.INTEGER);

            rs = stmt.executeQuery();

            resultset = new JDBCReader(rs).getContent(); // filling JDBC
                                                            // Resultset into
                                                            // XMLResultset

            convertToAltCurrency(resultset, currency, baseCurrency); // calculate
                                                                        // prices
                                                                        // into
                                                                        // alternate
                                                                        // currency.

            rs.close();
            stmt.close();
            con.close();

            GoogleBaseService service = new GoogleBaseService("esales", ApplicationParameter.getValue(
                    "GoogleBaseAPIKey").trim());

            try {
                service.setUserCredentials(ApplicationParameter.getValue("GoogleAccount").trim(), ApplicationParameter
                        .getValue("GoogleAccountPassword").trim());
            } catch (Exception ex) {
                LOG.debug("Inside updateAllItem() authentication", ex);
            }

            SearchEngineItemBean gbsItemBean = null;
            GoogleBaseEntry updateEntry = null;

            resultset.beforeFirst();

            while (resultset.hasNext()) {
                resultset.moveNext();
                gbsItemBean = SearchEngineHelper.getSearchEngineItemBeanForUpdate(resultset, baseUrl);
                try {
                    if (gbsItemBean.getSearchEngineItemId() != null) {
                        updateEntry = service.getEntry(new URL(gbsItemBean.getSearchEngineItemId()));
                        updateEntry.setTitle(TextConstruct
                                .create(TextConstruct.Type.TEXT, gbsItemBean.getTitle(), null));
                        updateEntry.setContent(TextConstruct.create(TextConstruct.Type.TEXT, gbsItemBean.getContent(),
                                null));
                        // updateEntry.getGoogleBaseAttributes().setItemType("products");
                        updateEntry.getGoogleBaseAttributes().setPriceUnits(gbsItemBean.getUnit());
                        updateEntry.getGoogleBaseAttributes().setPrice(gbsItemBean.getPrice(), currency);
                        // updateEntry.getGoogleBaseAttributes().addTextAttribute("target_country",country);
                        // updateEntry.getGoogleBaseAttributes().addTextAttribute("item_language",language);
                        updateEntry.setSummary(TextConstruct.create(TextConstruct.Type.TEXT, gbsItemBean.getSummary(),
                                null));
                        updateEntry.getGoogleBaseAttributes().addImageLink(gbsItemBean.imageURL); // actual
                                                                                                    // item
                                                                                                    // image
                                                                                                    // link

                        try {
                            updateEntry.getGoogleBaseAttributes().getAttribute("label").setValue("e-Sales");
                        } catch (NullPointerException ex) {
                            updateEntry.getGoogleBaseAttributes().addTextAttribute("label", "e-Sales");
                        }

                        try {
                            updateEntry.getGoogleBaseAttributes().getAttribute("my site url").setValue(baseUrl);
                        } catch (NullPointerException ex) {
                            updateEntry.getGoogleBaseAttributes().addTextAttribute("my site url", baseUrl);
                        }
                        try {
                            updateEntry.getGoogleBaseAttributes().getAttribute("brand")
                                    .setValue(gbsItemBean.getBrand());
                        } catch (NullPointerException ex) {
                            updateEntry.getGoogleBaseAttributes().addTextAttribute("brand", gbsItemBean.getBrand());
                        }

                        try {
                            updateEntry.getHtmlLink().setHref(gbsItemBean.getBaseUrl());
                        } catch (NullPointerException ex) {
                            updateEntry.addHtmlLink(gbsItemBean.getBaseUrl(), "en", "Lawson E-Sales");
                        }

                        service.update(new URL(gbsItemBean.getSearchEngineItemId()), updateEntry);
                    }// end of if(gbsItemBean.getSearchEngineItemId()!==null)
                } catch (Exception ex) {
                    LOG.debug("Exception Occurred inside updateAllItem() while updating to Google Base Server, ", ex);
                }

            } // end of while(rs.next())

        } catch (Exception e) {
            LOG.error("Exception Occurred inside updateAllItem()", e);
        } finally {
            CustomStagesHelper.close(con, stmt, rs);
        }
        return result;
    }

    public static boolean updateAllItemByAssortment(String language, String country, String currency,
            Integer searchEngineSystemId, String baseCurrency, String listPriceGroupName) {
        boolean result = false;
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        XMLResultset resultset = null;
        String baseUrl = null;

        LOG.debug("Inside UploadItemToSearchEngine.updateAllItemByAssortment()");

        try {
            try {
                baseUrl = ApplicationParameter.getValue("ApplicationURLB2C").trim();
            } catch (PipelineRuntimeException e) {
                throw new PipelineRuntimeException("Failure in getting from Application Details ", e);
            } catch (ResultsetException e) {
                throw new PipelineRuntimeException("ResultsetException ", e);
            }

            con = (Connection) CustomStagesHelper.getConnection("esales.cursor");
            stmt = con.prepareStatement(SearchEngineHelper.UPDATE_ASSORTMENTS);

            stmt.setObject(1, language, Types.VARCHAR);
            stmt.setObject(2, baseCurrency, Types.VARCHAR);
            stmt.setObject(3, listPriceGroupName, Types.VARCHAR);
            stmt.setObject(4, baseCurrency, Types.VARCHAR);
            stmt.setObject(5, language, Types.VARCHAR);
            stmt.setObject(6, searchEngineSystemId, Types.INTEGER);
            stmt.setObject(7, language, Types.VARCHAR);
            stmt.setObject(8, baseCurrency, Types.VARCHAR);
            stmt.setObject(9, listPriceGroupName, Types.VARCHAR);
            stmt.setObject(10, baseCurrency, Types.VARCHAR);
            stmt.setObject(11, language, Types.VARCHAR);
            stmt.setObject(12, searchEngineSystemId, Types.INTEGER);

            rs = stmt.executeQuery();

            resultset = new JDBCReader(rs).getContent(); // filling JDBC
                                                            // Resultset into
                                                            // XMLResultset

            convertToAltCurrency(resultset, currency, baseCurrency); // calculate
                                                                        // prices
                                                                        // into
                                                                        // alternate
                                                                        // currency.

            rs.close();
            stmt.close();
            con.close();

            GoogleBaseService service = new GoogleBaseService("esales", ApplicationParameter.getValue(
                    "GoogleBaseAPIKey").trim());

            try {
                service.setUserCredentials(ApplicationParameter.getValue("GoogleAccount").trim(), ApplicationParameter
                        .getValue("GoogleAccountPassword").trim());
            } catch (Exception ex) {
                LOG.debug("Exception occurred inside updateAllItemByAssortment() authentication", ex);
            }

            SearchEngineItemBean gbsItemBean = null;
            GoogleBaseEntry updateEntry = null;

            resultset.beforeFirst();

            while (resultset.hasNext()) {
                resultset.moveNext();
                gbsItemBean = SearchEngineHelper.getSearchEngineItemBeanForUpdate(resultset, baseUrl);
                try {
                    if (gbsItemBean.getSearchEngineItemId() != null) {
                        updateEntry = service.getEntry(new URL(gbsItemBean.getSearchEngineItemId()));
                        updateEntry.setTitle(TextConstruct
                                .create(TextConstruct.Type.TEXT, gbsItemBean.getTitle(), null));
                        updateEntry.setContent(TextConstruct.create(TextConstruct.Type.TEXT, gbsItemBean.getContent(),
                                null));
                        // updateEntry.getGoogleBaseAttributes().setItemType("products");
                        updateEntry.getGoogleBaseAttributes().setPriceUnits(gbsItemBean.getUnit());
                        updateEntry.getGoogleBaseAttributes().setPrice(gbsItemBean.getPrice(), currency);
                        // updateEntry.getGoogleBaseAttributes().addTextAttribute("target_country",country);
                        // updateEntry.getGoogleBaseAttributes().addTextAttribute("item_language",language);
                        updateEntry.setSummary(TextConstruct.create(TextConstruct.Type.TEXT, gbsItemBean.getSummary(),
                                null));
                        updateEntry.getGoogleBaseAttributes().addImageLink(gbsItemBean.getImageURL()); // actual
                                                                                                        // item
                                                                                                        // image
                                                                                                        // link

                        try {
                            updateEntry.getGoogleBaseAttributes().getAttribute("label").setValue("e-Sales");
                        } catch (NullPointerException ex) {
                            updateEntry.getGoogleBaseAttributes().addTextAttribute("label", "e-Sales");
                        }

                        try {
                            updateEntry.getGoogleBaseAttributes().getAttribute("my site url").setValue(baseUrl);
                        } catch (NullPointerException ex) {
                            updateEntry.getGoogleBaseAttributes().addTextAttribute("my site url", baseUrl);
                        }
                        try {
                            updateEntry.getGoogleBaseAttributes().getAttribute("brand")
                                    .setValue(gbsItemBean.getBrand());
                        } catch (NullPointerException ex) {
                            updateEntry.getGoogleBaseAttributes().addTextAttribute("brand", gbsItemBean.getBrand());
                        }

                        try {
                            updateEntry.getHtmlLink().setHref(gbsItemBean.getBaseUrl());
                        } catch (NullPointerException ex) {
                            updateEntry.addHtmlLink(gbsItemBean.getBaseUrl(), "en", "Lawson E-Sales");
                        }

                        service.update(new URL(gbsItemBean.getSearchEngineItemId()), updateEntry);
                    }// end of if(gbsItemBean.getSearchEngineItemId()!==null)
                } catch (Exception ex) {
                    LOG
                            .debug(
                                    "Exception occurred inside updateAllItemByAssortment() while updating to the Google Base Server",
                                    ex);
                }

            } // end of while(rs.next())

        } catch (Exception e) {
            LOG.error("Exception occurred inside updateAllItemByAssortment() , ", e);
        } finally {
            CustomStagesHelper.close(con, stmt, rs);
        }
        return result;
    }

    public static void deleteItemFromSearchEngine() {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String searchEngineItemId = null;

        LOG.debug("Inside deleteItemFromSearchEngine()");

        GoogleBaseService service = null;

        try {
            service = new GoogleBaseService("esales", ApplicationParameter.getValue("GoogleBaseAPIKey").trim());
            service.setUserCredentials(ApplicationParameter.getValue("GoogleAccount").trim(), ApplicationParameter
                    .getValue("GoogleAccountPassword").trim());
        } catch (Exception ex) {
            LOG.error("Exception inside deleteItemFromSearchEngine()....", ex);
        }

        try {
            con = (Connection) CustomStagesHelper.getConnection("esales.cursor");
            stmt = con.prepareStatement(SearchEngineHelper.DELETE_SQL);

            rs = stmt.executeQuery();

            while (rs.next()) {
                searchEngineItemId = rs.getString("SearchEngineItemId");

                if (searchEngineItemId != null) {
                    service.delete(new URL(searchEngineItemId)); // delete
                                                                    // item from
                                                                    // Google
                                                                    // Base
                                                                    // Server
                    UploadItemToSearchEngine.deleteItemFromSearchEngineItem(searchEngineItemId); // delete
                                                                                                    // item
                                                                                                    // from
                                                                                                    // SearchEngineItem
                                                                                                    // table
                } // end of (searchEngineItemId!=null)
            } // end of while(rs.next())
        } catch (Exception ex) {
            LOG.error("Error : " + ex);
        } finally {
            CustomStagesHelper.close(con, stmt, rs);
        }
    }

    public static void deleteAllItemOnlyFromSearchEngine() {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String searchEngineItemId = null;

        LOG.debug("Inside deleteAllItemOnlyFromSearchEngine()");

        GoogleBaseService service = null;

        try {
            service = new GoogleBaseService("esales", ApplicationParameter.getValue("GoogleBaseAPIKey").trim());
            service.setUserCredentials(ApplicationParameter.getValue("GoogleAccount").trim(), ApplicationParameter
                    .getValue("GoogleAccountPassword").trim());
        } catch (Exception ex) {
            LOG.error("Error occured inside deleteAllItemOnlyFromSearchEngine()....", ex);
        }

        try {
            con = (Connection) CustomStagesHelper.getConnection("esales.cursor");
            stmt = con.prepareStatement(SearchEngineHelper.DELETEITEM_ONLYFROM_SEARCHENGINE);

            rs = stmt.executeQuery();

            while (rs.next()) {
                searchEngineItemId = rs.getString("SearchEngineItemId");

                if (searchEngineItemId != null) {
                    service.delete(new URL(searchEngineItemId)); // delete
                                                                    // item from
                                                                    // Google
                                                                    // Base
                                                                    // Server
                    UploadItemToSearchEngine.deleteItemFromSearchEngineItem(searchEngineItemId); // delete
                                                                                                    // item
                                                                                                    // from
                                                                                                    // SearchEngineItem
                                                                                                    // table
                } // end of (searchEngineItemId!=null)
            } // end of while(rs.next())
        } catch (Exception ex) {
            LOG.error("Error occured inside deleteAllItemOnlyFromSearchEngine() : " + ex);
        } finally {
            CustomStagesHelper.close(con, stmt, rs);
        }
    }

    public static boolean deleteItemFromSearchEngineItem(String searchEngineItemId) {
        boolean status = false;
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        LOG.debug("Inside deleteItemFromSearchEngineItem()");

        try {
            con = (Connection) CustomStagesHelper.getConnection("esales.cursor");
            stmt = con.prepareStatement(SearchEngineHelper.DELETEITEM_SQL);

            stmt.setObject(1, searchEngineItemId, Types.VARCHAR);

            status = stmt.execute();

        } catch (Exception ex) {
            LOG.error("Error : " + ex);

        } finally {
            CustomStagesHelper.close(con, stmt, rs);
        } // end of finally{}

        return status;
    }

    private static void convertToAltCurrency(XMLResultset resultset, String currency, String baseCurrency)
            throws PipelineRuntimeException {
        BigDecimal exchangeRate = null;
        BigDecimal alternateExchangeRate = null;
        BigDecimal conversionRate = null;

        exchangeRate = getExchangeRate(baseCurrency);// getting exchange rate
                                                        // for base currency
        alternateExchangeRate = getExchangeRate(currency); // getting exchange
                                                            // rate for
                                                            // alternate
                                                            // currency

        if (exchangeRate != null && alternateExchangeRate != null) {
            conversionRate = conversionRate(exchangeRate, alternateExchangeRate);
            if (conversionRate != null) {
                setAltCurrency(conversionRate, resultset);
            }
        }
    }

    private static BigDecimal getExchangeRate(String currency) {
        BigDecimal exchangeRate = null;
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {

            con = (Connection) CustomStagesHelper.getConnection("esales.cursor");
            stmt = con.prepareStatement(SearchEngineHelper.Exchange_Rate_SQL);

            stmt.setObject(1, currency, Types.VARCHAR);

            rs = stmt.executeQuery();

            while (rs.next()) {
                try {
                    exchangeRate = new BigDecimal(rs.getString("exchangeRate"));
                } catch (Exception ex) {
                    LOG.error("Error in getting exchange rate", ex);
                }
            }
            CustomStagesHelper.close(con, stmt, rs);

        } catch (Exception e) {
            LOG.error("Error in getting exchange rate : ", e);
            CustomStagesHelper.close(con, stmt, rs);
        }

        return exchangeRate;
    }

    private static BigDecimal conversionRate(BigDecimal exchangeRate, BigDecimal alternateExchangeRate)
            throws PipelineRuntimeException {
        LOG.debug("inside UploadItemToSearchEngine.conversionRate()");

        // avoid negative, infinite, and NaN conversion rate values
        if (exchangeRate.compareTo(Decimal.ZERO) < 1) {
            throw new PipelineRuntimeException(
                    "The supplied exchange rate was negative or zero, it must a positive number");
        }
        if (alternateExchangeRate.compareTo(Decimal.ZERO) < 0) {
            throw new PipelineRuntimeException(
                    "The supplied alternative currency exchange rate was negative, it must be positive");
        }

        // Trying to set scale depending on the size of the result. But is this
        // necessary?
        int scale = 20;
        if (alternateExchangeRate.compareTo(exchangeRate.multiply(new BigDecimal("1000000000"))) == 1) {
            // if x/y < 10E-10 ==>> y > x*10E10
            // then dealing with small numbers. Set scale to 30
            scale = 30;
        } else if (exchangeRate.compareTo(alternateExchangeRate.multiply(new BigDecimal("1000000000"))) == 1) {
            // if x/y > 10E10 ==>> x > y*10E10
            // then dealing with huge a number. Set scale to 0
            scale = 0;
        }

        return alternateExchangeRate.divide(exchangeRate, scale, BigDecimal.ROUND_HALF_UP);
    }

    private static void setAltCurrency(BigDecimal conversionRate, XMLResultset resultset)
            throws PipelineRuntimeException {

        LOG.debug("inside UploadItemToSearchEngine.setAltCurrency()");

        try {
            resultset.beforeFirst();

            while (resultset.hasNext()) {
                // compute altCurrency value and insert it as value for
                // attribute
                resultset.moveNext();
                BigDecimal altCurrencyValue;
                String price = null;
                try {
                    price = resultset.getString("Amount");
                    if (price == null) {
                        price = "0.00";
                    }
                    BigDecimal currency = new BigDecimal(price);
                    altCurrencyValue = conversionRate.multiply(currency);
                } catch (NumberFormatException e1) {
                    FastStringBuffer msg = new FastStringBuffer();
                    msg.append("Failed to parse the value from the result set attribute ");
                    msg.append(". Ensure that the value can be parsed as a double.");
                    msg.append(". The alternate currency value inserted was 0.0000!");
                    LOG.info(msg.toString());
                    altCurrencyValue = new BigDecimal("0.0000");
                }

                // add atribute to result set row (element)
                resultset.setString("Amount", Decimal.toString(altCurrencyValue));
            }

        } catch (Exception ex) {
            throw new PipelineRuntimeException("cannot set resultset value for alternate currency", ex);

        }

    }

}
