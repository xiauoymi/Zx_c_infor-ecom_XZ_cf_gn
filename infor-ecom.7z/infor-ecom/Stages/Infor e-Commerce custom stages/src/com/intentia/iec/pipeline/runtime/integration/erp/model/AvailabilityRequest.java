package com.intentia.iec.pipeline.runtime.integration.erp.model;

import java.util.Date;

public class AvailabilityRequest {
	
	private String tenantId;
	
	private String accountingEntityId;
	
	private String warehouseId;
	
	private String itemId;
	
	private String customerItemId;
	
	private double quantity;
	
	private String unitCode;
	
	private Date requiredDeliveryDate;
	
	private String userName;
	
	private String shippingAddressId;
	
	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public String getAccountingEntityId() {
		return accountingEntityId;
	}

	public void setAccountingEntityId(String accountingEntityId) {
		this.accountingEntityId = accountingEntityId;
	}

	public String getWarehouseId() {
		return warehouseId;
	}

	public void setWarehouseId(String warehouseId) {
		this.warehouseId = warehouseId;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public String getCustomerItemId() {
		return customerItemId;
	}

	public void setCustomerItemId(String customerItemId) {
		this.customerItemId = customerItemId;
	}

	public double getQuantity() {
		return quantity;
	}

	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}

	public String getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(String unitCode) {
		this.unitCode = unitCode;
	}

	public Date getRequiredDeliveryDate() {
		return requiredDeliveryDate;
	}

	public void setRequiredDeliveryDate(Date requiredDeliveryDate) {
		this.requiredDeliveryDate = requiredDeliveryDate;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getShippingAddressId(){
		return this.shippingAddressId;
	}
	
	public void setShippingAddressId(String shippingAddressId){
		this.shippingAddressId=shippingAddressId;
	}
	
	

}
