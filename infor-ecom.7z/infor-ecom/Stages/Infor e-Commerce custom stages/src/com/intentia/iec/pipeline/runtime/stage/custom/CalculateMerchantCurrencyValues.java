package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.traversal.DocumentTraversal;
import org.w3c.dom.traversal.NodeFilter;
import org.w3c.dom.traversal.NodeIterator;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;

/**
 * Values from the database are saved in Shopper's currency. If the RFQ is being
 * reviewed by the merchant, he/she should be able to see the values in
 * Merchant's currency. The purpose of this class is to convert the
 * prices/values to merchant currency for display purposes only. 
 * This stage is being called from the RFQ_Details method of CurrentOrder BO
 * 
 * @author Kristina Camille Lutz
 * 
 */
public class CalculateMerchantCurrencyValues implements PipelineStage {

    private static Logger LOG = Logger.getLogger(CalculateMerchantCurrencyValues.class);

    private XMLRequest xmlRequest = null;

    private XMLResultset resultset = null;

    private CurrencyConverter converter;

    public void execute(final PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("Entering execute method");

        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
        xmlRequest = (XMLRequest) context.getRequest();
        CustomStagesHelper.extractRequestParameters(xmlRequest);

        if (!(context.getResponse() instanceof XMLResultset)) {
            throw new PipelineRuntimeException("Contained response object MUST be of type 'XMLResultset'!");
        }

        Parameters requestParameters = CustomStagesHelper.getRequestParameters(context);

        // skip conversion to merchant currency if user is not an admin user
        if (shouldNotConvert(requestParameters)) {
            return;
        }

        try {
            resultset = (XMLResultset) context.getResponse();
            if ((resultset == null) || (!resultset.moveFirst())) {
                LOG.debug("There is no order");
                return;
            }

            String shopperCurrency = getShopperCurrency();
            String merchantCurrency = getRequestParameterString(requestParameters, ConstantsForSales.CURRENCYCODE_PARAM);
            BigDecimal merchantExchangeRate = getRequestParameterDecimal(requestParameters,
                    ConstantsForSales.EXCHANGE_RATE_PARAM);
            converter = new CurrencyConverter(shopperCurrency, merchantCurrency, merchantExchangeRate);
            updateOrderValues();
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Failed to get values from result set.", e);
        }
        LOG.debug("Exiting execute method");
    }
    
    protected boolean shouldNotConvert(Parameters requestParameters) {
        return ("true".equalsIgnoreCase(getRequestParameterString(requestParameters, ConstantsForSales.NOT_ADMIN_QUOTE)));
    }

    /**
     * Get the shopper's currency from the resultset
     * @return shopper's currency
     * @throws ResultsetException
     */
    private String getShopperCurrency() throws ResultsetException {
        LOG.debug("Entering getShopperCurrency method");
        String shopperCurrency = "";
        try {
            resultset.beforeFirst();
            if (resultset.moveNext()) {
                shopperCurrency = n2E(resultset.getString(ConstantsForSales.CURRENCYID));
                LOG.debug("Shopper currency = " + shopperCurrency);
            }
        } finally {
            resultset.beforeFirst();
        }
        LOG.debug("Exiting getShopperCurrency method");
        return shopperCurrency;
    }

    /**
     * Update the prices in the order to merchant currency
     * @throws PipelineRuntimeException
     */
    protected void updateOrderValues() throws PipelineRuntimeException {
        LOG.debug("Entering updateOrderValues method");
        Document xmlDoc;
        try {
            resultset.beforeFirst();
            xmlDoc = resultset.getDocument();
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Failed to obtain result set as XML document!", e);
        }
        // create an iterator that runs over all elements in the result set
        NodeIterator iterator = ((DocumentTraversal) xmlDoc).createNodeIterator(xmlDoc, NodeFilter.SHOW_ELEMENT, null,
                true);

        Element nodeElement = (Element) iterator.nextNode();
        while (nodeElement != null) {
            updateHeaderValues(nodeElement);
            updateLineValues(nodeElement);
            nodeElement = (Element) iterator.nextNode();
        }
        LOG.debug("Exiting updateOrderValues method");
    }

    /**
     * Calls method to update values of the order header 
     * @param element - an element in the resultset
     * @throws PipelineRuntimeException
     */
    protected void updateHeaderValues(Element element) throws PipelineRuntimeException {
        LOG.debug("Entering updateHeaderValues method");
        computeValue(element, ConstantsForSales.TOTALPRICE);
        computeValue(element, ConstantsForSales.TOTALDISCOUNT);
        computeValue(element, ConstantsForSales.TOTALSHIP);
        computeValue(element, ConstantsForSales.TOTALDELIVERYFEE);
        computeValue(element, ConstantsForSales.TOTALTAX);
        computeValue(element, ConstantsForSales.GRANDTOTAL);
        LOG.debug("Exiting updateHeaderValues method");
    }

    /**
     * Calls method to update values of the order line
     * @param element - an element in the resultset
     * @throws PipelineRuntimeException
     */
    protected void updateLineValues(Element element) throws PipelineRuntimeException {
        LOG.debug("Entering updateLineValues method");
        computeValue(element, ConstantsForSales.RESELLPRICE);
        computeValue(element, ConstantsForSales.LINEPRICE);
        computeValue(element, ConstantsForSales.LINETAX);
        computeValue(element, ConstantsForSales.LINETOTAL);
        LOG.debug("Exiting updateLineValues method");
    }

    /**
     * Gets the value of the parameter from the resultset, computes the
     * converted value for the new currency, and posts/overwrites the new value
     * back to the resultset
     * 
     * @param element -
     *            an element in the request
     * @param parameter -
     *            the name of the element
     */
    protected void computeValue(final Element element, String parameter) {
        BigDecimal price;
        String paramValue = element.getAttribute(parameter);
        LOG.debug("Value for " + parameter + ": " + paramValue);
        try {
            price = new BigDecimal(paramValue);
        } catch (NumberFormatException e) {
            return;
        }
        String s = converter.getConvertedValue(price);
        LOG.debug("Converted value for " + parameter + ": " + s);
        element.setAttribute(parameter, s);
    }

    /**
     * Gets the named parameter from the given parameter block as a string.
     * 
     * @param requestParam
     *            parameters from the request
     * @param parameterName
     *            name of the requested parameter
     * 
     * @return the parameter value as a string - empty if not found
     */
    public static String getRequestParameterString(final Parameters requestParam, final String parameterName) {
        LOG.debug("Entering getRequestParameterString method");
        String param = null;
        try {
            param = n2E(requestParam.getString(parameterName));
        } catch (ParametersException e) {
            LOG.error("Missing parameter: " + parameterName);
        }
        LOG.debug("Exiting getRequestParameterString method");
        return param;
    }

    /**
     * Gets the named parameter as a BigDecimal
     * 
     * @param requestParam
     *            parameters from the request
     * @param parameterName -
     *            name of the requested parameter
     * 
     * @return the parameter value as BigDecimal - zero if not found
     */
    public static BigDecimal getRequestParameterDecimal(final Parameters requestParam, final String parameterName) {
        LOG.debug("Entering getRequestParameterDecimal method");
        BigDecimal param = null;
        try {
            param = requestParam.getDecimal(parameterName);
        } catch (ParametersException e) {
            LOG.error("Missing parameter: " + parameterName);
        }
        if (param == null) {
            param = new BigDecimal(0);
        }
        LOG.debug("Exiting getRequestParameterDecimal method");
        return param;
    }

    /**
     * Ensure that the string is not null.
     * 
     * @param s - String to check
     * @return returns the string empty if string is null.
     */
    private static String n2E(final String s) {
        if (s == null) {
            return "";
        } else {
            return s;
        }
    }
}
