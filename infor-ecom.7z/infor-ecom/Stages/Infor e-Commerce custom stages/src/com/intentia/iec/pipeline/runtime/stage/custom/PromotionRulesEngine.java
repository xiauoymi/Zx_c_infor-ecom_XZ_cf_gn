package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;

import com.ibm.icu.text.NumberFormat;
import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.custom.promotion.rules.PromotionRule;
import com.intentia.iec.pipeline.runtime.stage.custom.promotion.rules.Rules;
import com.intentia.iec.pipeline.runtime.stage.custom.promotion.rules.RulesConstant;
import com.intentia.iec.pipeline.runtime.stage.custom.promotion.rules.RulesFactory;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;
import com.intentia.iec.util.FastStringBuffer;


public class PromotionRulesEngine implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(PromotionRulesEngine.class);

    private String _languageCodeParam = null;
    private String promotionIdList = null;
    private Map<String, List<String>> promotionalItemsMap = null;
    private PipelineContext context;
	private XMLResultset xmlResponse;
	private XMLRequestHelper xmlHelper;
	 
	private XMLRequest xmlRequest;
	private XMLResultset resultSet;
	private BigDecimal exchangeRate;
	//private NodeList orderLineNodeList;
    
    public PromotionRulesEngine() {
        super();
    }

    public void execute(PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("Inside PromotionRulesEngine.execute()");

        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
        this.context = context;
        Parameters contextParams = CustomStagesHelper.getRequestParameters(context);
        
        Document request;
        
        try {
            CustomStagesHelper.extractRequestParameters(CustomStagesHelper.getRequest(context));
            this.xmlRequest = (XMLRequest) context.getRequest();
            this.xmlResponse = (XMLResultset) context.getResponse();
            request = this.xmlRequest.getRequestDoc();
            
            this.xmlHelper = new XMLRequestHelper(request);
            this._languageCodeParam = getStringFromParameter(ConstantsForSales.LANGUAGE_CODE_SQL_PARAM, contextParams);
            getStringFromParameter("orderID", contextParams);
            this.promotionIdList = getStringFromParameter(ConstantsForSales.PROMOTION_LIST, contextParams);
            this.exchangeRate = getDecimalFromParameter(ConstantsForSales.EXCHANGE_RATE_PARAM, contextParams, "1");
            
            if(this.promotionIdList == null || this.promotionIdList.isEmpty()){
            	LOG.debug("No valid promotions");
            	return;
            }

            // Get resultset from previous stage
            this.resultSet =  (XMLResultset) context.getResponse();
            if ((resultSet == null) || (resultSet.isEmpty())) {
                LOG.debug("The resultset passed to this stage is null or empty: resultset is null = "
                        + (resultSet == null) + " or resultset is empty = " + resultSet.isEmpty());
                return;
            }

            List<String> promotionIds = Arrays.asList(this.promotionIdList.split(":"));
            this.promotionalItemsMap = retrievedPromotionalItems(promotionIds);
            
            //contains all Items that have promotions
        	Map<String, List<String>> itemsPromoMap = new HashMap<String, List<String>>();
        	List<String> orderPromoList = new ArrayList<String>();
        	
        	List<String> itemList = new ArrayList<String>();
            
        	for (String promoId : promotionIds) {
            	List<String> promoItemsList =  this.promotionalItemsMap.get(promoId);
            	if(promoItemsList!=null){
	            	if(!promoItemsList.isEmpty()){
	            		itemList= this.evaluatePromotionalItems(promoId);
	            		if(!itemList.isEmpty()){
	            			itemsPromoMap.put(promoId, itemList);
	            		}
	            	} else {
	            		if(this.evaluateOrder(promoId, this.resultSet)){
	            			orderPromoList.add(promoId);
	            		}
	            	}            	
            	} else {
            		this.evaluateOrder(promoId, this.resultSet);
            	}
            }
        	
        	if(!itemsPromoMap.isEmpty()){
        		updateLineRSPromotion(itemsPromoMap);
        	}
        	
           if(orderPromoList.size()>0){
        	   StringBuffer strPromotionList = new StringBuffer();
              for(String s : orderPromoList){
                  if(strPromotionList.length()==0){ 
                	  strPromotionList = strPromotionList.append(s);
                  }
                  else strPromotionList = strPromotionList.append(":").append(s);
              }
              this.updRsAttr(xmlResponse, ConstantsForSales.PROMOTIONS_ATTRIBUTE, strPromotionList.toString());
           }
           
           context.setResponse(xmlResponse);
           LOG.debug("END PromotionRulesEngine.execute()");
        } catch (Exception e) {
        	throw new PipelineRuntimeException("Failed to obtain XML request document from request", e);
        }

    }
    
    private void updateLineRSPromotion(Map<String, List<String>> itemsPromo) throws ResultsetException{
    	LOG.debug("\nInside PromotionRulesEngine.updateLineRSPromotion()");
    	XMLIterator xmlOrderline = (XMLIterator) xmlResponse.getResultset(ConstantsForSales.ORDERLINE);
    	StringBuffer strPromotionList = null;
    	
    	xmlOrderline.beforeFirst();
    	
    	while (xmlOrderline.moveNext()) {
    		String currItemID = xmlOrderline.getString(ConstantsForSales.ITEM_ID);
    		String promotionID = xmlOrderline.getString(ConstantsForSales.PROMOTION_ID);
    		strPromotionList = new StringBuffer();
    		for (Map.Entry<String, List<String>> entry : itemsPromo.entrySet()) {
    			String promoId = entry.getKey();
    			List<String> itemList = entry.getValue();
    			if(!itemList.isEmpty() && itemList.contains(currItemID)){
    				if(strPromotionList.length()==0) strPromotionList = strPromotionList.append(promoId);
	                  else strPromotionList = strPromotionList.append(":").append(promoId);
    			}
    		}
    		if(!RulesConstant.EMPTY_VALUE.equals(promotionID) && !itemsPromo.containsKey(promotionID)){
    			//Promotion no longer available
    			//Remove PromotionID from Orderline
    			updRsAttr(xmlOrderline, ConstantsForSales.PROMOTION_ID, RulesConstant.EMPTY_VALUE);
    		} else {
    			//Check if Item still exist in the Items Promo Map
    			List<String> itemList = itemsPromo.get(promotionID);
    			if(!itemList.isEmpty() && !itemList.contains(currItemID)){
    				//Remove PromotionID from Orderline
        			updRsAttr(xmlOrderline, ConstantsForSales.PROMOTION_ID, RulesConstant.EMPTY_VALUE);
    			}
    		}
    		this.updRsAttr(xmlOrderline, ConstantsForSales.PROMOTIONS_ATTRIBUTE, strPromotionList.toString());
    	}
    }

    private boolean evaluateOrder(String promotionId, XMLResultset resultSet) throws PipelineRuntimeException, TransformerException, ResultsetException {
    	LOG.debug("\nInside PromotionRulesEngine.evaluateOrder()");
    	List<PromotionRule> promotionRules = getPromotionRules(promotionId);
		boolean hasPassedCondition = false;	
		for (PromotionRule promotionRule : promotionRules) {
			String promotionType = promotionRule.getRuleType();
			Rules ruleType = RulesFactory.getRules(promotionType);
			ruleType.setPromotionId(promotionId);
			ruleType.setPromotionRule(promotionRule);
			ruleType.setPromotionalItemsMap(this.promotionalItemsMap);
			String ruleField = promotionRule.getField();
			if(RulesConstant.BUY_ITEM.equals(promotionType)){
				//Failed this should not have Promotional Item
				hasPassedCondition = false;
			} else if(RulesConstant.AMOUNT.equals(promotionType)){
				if(RulesConstant.ORDER_TOTAL.equals(ruleField)){
					hasPassedCondition = ruleType.evaluateOrder(resultSet, this.xmlHelper);
				} else if(RulesConstant.ITEMS_IN_PROMO.equals(ruleField)){
					//Failed this should not have Promotional Item				
					hasPassedCondition = false;
				} else if(RulesConstant.ANY_ITEMS_IN_PROMO.equals(ruleField)){
					//Failed this should not have Promotional Item
					hasPassedCondition = false;
				}
			} else if(RulesConstant.QUANTITY.equals(promotionType)){
				if(RulesConstant.ORDER_TOTAL.equals(ruleField)){
					hasPassedCondition = ruleType.evaluateOrder(resultSet, this.xmlHelper);
				} else if(RulesConstant.ITEMS_IN_PROMO.equals(ruleField)){
					//Failed this should not have Promotional Item				
					hasPassedCondition = false;
				} else if(RulesConstant.ANY_ITEMS_IN_PROMO.equals(ruleField)){
					//Failed this should not have Promotional Item				
					hasPassedCondition = false;
				}
			} else {
				// PAYMENT AND SHIPPING DETAILS RULE TYPE
				hasPassedCondition = ruleType.evaluateOrder(resultSet, this.xmlHelper);
			}
			if(hasPassedCondition){
				//Passed Condition
				//Add PromotionID in Orderheader
				this.modifyOrderHeaderPromotion(resultSet, promotionId);
			}
		}
    	
    	return hasPassedCondition;
    }
    
    private void modifyOrderHeaderPromotion(XMLResultset resultSet, String promotionID){
    	LOG.debug("Inside PromotionRulesEngine.modifyOrderHeaderPromotion()");
    	try {
    		String promotionIDFromHeader = resultSet.getString(ConstantsForSales.PROMOTION_ID);
    		if(promotionIDFromHeader == null || "".equals(promotionIDFromHeader)){
    			resultSet.appendField(ConstantsForSales.PROMOTION_ID, promotionID);    			
    		} else {
    			StringBuffer strPromotionList = new StringBuffer();
    			strPromotionList.append(promotionIDFromHeader);
    			strPromotionList.append(":").append(promotionID);
    			this.updRsAttr(resultSet, ConstantsForSales.PROMOTION_ID, strPromotionList.toString());
    		}
		} catch (ResultsetException e) {

			e.printStackTrace();
		}
    }
    
    private List<String> evaluatePromotionalItems(String promotionId) throws PipelineRuntimeException, TransformerException, ResultsetException {
    	LOG.debug("Inside PromotionRulesEngine.evaluatePromotionalItems()");
    	List<String> itemList = new ArrayList<String>();

    	this.resultSet.moveFirst();
    	XMLIterator xmlOrderline = (XMLIterator) this.resultSet.getResultset(ConstantsForSales.ORDERLINE);
        if ((xmlOrderline == null) || xmlOrderline.isEmpty()) {
            LOG.debug("The sub resultset orderlines is null or empty: resultset is null = " + (xmlOrderline == null)
                    + " or resultset is empty = " + xmlOrderline.isEmpty());
        }

    	try { 			
			//int promotionId = Integer.valueOf(promoId); // from Available Promotions
			List<PromotionRule> promotionRules = getPromotionRules(promotionId);
			List<String> promoItemsList =  this.promotionalItemsMap.get(promotionId);
			//Satisfied Promotional Orderlines
			List<String> promoBuyItemsOrderLine = new ArrayList<String>();
			List<String> promoQuantityItemsOrderLine = new ArrayList<String>();
			List<String> promoAmountItemsOrderLine = new ArrayList<String>();
			
			boolean hasPassedCondition = false;	
			for (PromotionRule promotionRule : promotionRules) {
				String promotionType = promotionRule.getRuleType();
				Rules ruleType = RulesFactory.getRules(promotionType);
				ruleType.setPromotionId(promotionId);
				ruleType.setPromotionRule(promotionRule);
				ruleType.setPromotionalItemsMap(this.promotionalItemsMap);
				String ruleField = promotionRule.getField();
				if(RulesConstant.BUY_ITEM.equals(promotionType)){
					boolean isSuccess = false;
					String itemIDFromRequest = "";
					if(RulesConstant.BUY_ITEM_CONTAINS.equals(promotionRule.getOperator())){
						hasPassedCondition = ruleType.evaluateOrder(resultSet, this.xmlHelper);
						if(hasPassedCondition){
							for (String item : promoItemsList) {
								promoBuyItemsOrderLine.add(item);
							}
						}
					} else {
						xmlOrderline.beforeFirst();
						while (xmlOrderline.moveNext()) {
							//Each Orderline    		
							// Rules that handle Promotion Order Line evaluation
							isSuccess = ruleType.evaluateOrderLine(xmlOrderline, this.xmlHelper);
							itemIDFromRequest = xmlOrderline.getString("ItemID");
							if(isSuccess){
								promoBuyItemsOrderLine.add(itemIDFromRequest);
							}
						}			
					}
					if(promoBuyItemsOrderLine.size() > 0){
						hasPassedCondition = true;
					} else {
						hasPassedCondition = false;
					}
    					
				} else if(RulesConstant.AMOUNT.equals(promotionType)){
    					
					if(RulesConstant.ORDER_TOTAL.equals(ruleField)){
						promoAmountItemsOrderLine = getPromotionalItemsInCart(promotionId);
						hasPassedCondition = ruleType.evaluateOrder(resultSet, this.xmlHelper);
					
					} else if(RulesConstant.ITEMS_IN_PROMO.equals(ruleField)){
						promoAmountItemsOrderLine = getPromotionalItemsInCart(promotionId);
						hasPassedCondition = ruleType.evaluateOrder(resultSet, this.xmlHelper);
						
					} else if(RulesConstant.ANY_ITEMS_IN_PROMO.equals(ruleField)){
						promoAmountItemsOrderLine = getAnyItemEvaluation(xmlOrderline, promotionId, ruleType);    
						if(promoAmountItemsOrderLine.size() == 0){
    						hasPassedCondition = false;
    					} else {
    						hasPassedCondition = true;
						}
					} else if(RulesConstant.PER_ITEMS_IN_PROMO.equals(ruleField)){
						promoAmountItemsOrderLine = getPerItemsInPromoEvaluation(xmlOrderline, promotionId, ruleType);
						if(promoItemsList.size() == promoAmountItemsOrderLine.size()){
							hasPassedCondition = true;
						} else {
							hasPassedCondition = false;
						}
					}
				} else if(RulesConstant.QUANTITY.equals(promotionType)){
  
					if(RulesConstant.ITEMS_IN_PROMO.equals(ruleField)){
						promoQuantityItemsOrderLine = getPromotionalItemsInCart(promotionId);
						hasPassedCondition = ruleType.evaluateOrder(resultSet, this.xmlHelper);
						
					} else if(RulesConstant.ANY_ITEMS_IN_PROMO.equals(ruleField)){
    					promoQuantityItemsOrderLine = getAnyItemEvaluation(xmlOrderline, promotionId, ruleType);        					
    					if(promoQuantityItemsOrderLine.size() == 0){
    						hasPassedCondition = false;
    					} else {
    						hasPassedCondition = true;
						}
					
					} else if(RulesConstant.PER_ITEMS_IN_PROMO.equals(ruleField)){
						promoQuantityItemsOrderLine = getPerItemsInPromoEvaluation(xmlOrderline, promotionId, ruleType);
						if(promoItemsList.size() == promoQuantityItemsOrderLine.size()){
							hasPassedCondition = true;
						} else {
							hasPassedCondition = false;
						}
					}
    					
				} else {
					hasPassedCondition = ruleType.evaluateOrder(resultSet, this.xmlHelper);
				}
					
				if(!hasPassedCondition){
					//Condition Fails - exit evaluation
					break;
				}
			}
			if(hasPassedCondition){
				itemList = validatePromotionalItems(promotionId, promoBuyItemsOrderLine, promoQuantityItemsOrderLine, promoAmountItemsOrderLine);
			}
    	} catch (TransformerException e) {
			e.printStackTrace();
		}
    	
    	return itemList;
    }
    
    private List<String> getAnyItemEvaluation(XMLIterator xmlOrderline, String promoId, Rules ruleType) throws ResultsetException{
    	List<String> promoItemsOrderLine = new ArrayList<String>();
    	List<String> promoItemsList =  this.promotionalItemsMap.get(promoId);
    	if(promoItemsList != null && !promoItemsList.isEmpty()){
    		try {
		    	// Atleast one Promo Items should pass criteria
				// Monitor item that meets criteria
				boolean isSuccess = false;
				String itemIDFromRequest = "";
				xmlOrderline.beforeFirst();
	            while (xmlOrderline.moveNext()) {
					itemIDFromRequest = xmlOrderline.getString("ItemID");
					if(promoItemsList.contains(itemIDFromRequest)){
						//Item exist - evaluate for Quantity
						isSuccess = ruleType.evaluateOrderLine(xmlOrderline, this.xmlHelper);
					}
					if(isSuccess){
						promoItemsOrderLine.add(itemIDFromRequest);
					}
				}
	    	} catch (TransformerException e) {
	 			e.printStackTrace();
	 		}
    	}
    	return promoItemsOrderLine;
    }
    
    private List<String> getPerItemsInPromoEvaluation(XMLIterator xmlOrderline, String promoId, Rules ruleType) throws ResultsetException{
    	List<String> promoItemsOrderLine = new ArrayList<String>();
    	List<String> promoItemsList =  this.promotionalItemsMap.get(promoId);
    	if(promoItemsList != null && !promoItemsList.isEmpty()){
    		try {
    			// All Promo Items should pass criteria
    			// Consider all items
    			String itemIDFromRequest = "";
				xmlOrderline.beforeFirst();
				while (xmlOrderline.moveNext()) {
					boolean isSuccess = false;
					itemIDFromRequest = xmlOrderline.getString("ItemID");
					if(promoItemsList.contains(itemIDFromRequest)){
						//Item exist - evaluate for Quantity
						isSuccess = ruleType.evaluateOrderLine(xmlOrderline, this.xmlHelper);
					}
					if(isSuccess){
						promoItemsOrderLine.add(itemIDFromRequest);
					}
				}

    		} catch (TransformerException e) {
    			e.printStackTrace();
    		}    		
    	}
	    return promoItemsOrderLine;
    }
    
    private List<String> validatePromotionalItems(String promoId, List<String> buyItemsList, List<String> quantityItemsList, List<String> amountItemsList){
    	List<String> promotionList = new ArrayList<String>();
    	boolean hasBuyItem = !buyItemsList.isEmpty();
    	boolean hasQuantityItem = !quantityItemsList.isEmpty();
    	boolean hasAmountItem = !amountItemsList.isEmpty();
    	if(hasBuyItem && !hasQuantityItem && !hasAmountItem){
    		//item only
    		for(String item : buyItemsList){
    			promotionList.add(item);
    		}
    		
    	} else if(hasBuyItem && hasQuantityItem && hasAmountItem){
    		// 3 list have value
    		for(String item : buyItemsList){
    			if(quantityItemsList.contains(item) && amountItemsList.contains(item)){
    				promotionList.add(item);
    			}
    		}
    		
    	} else if(hasBuyItem && !hasQuantityItem && hasAmountItem){
			// amount and item
    		for(String item : buyItemsList){
    			if(amountItemsList.contains(item)){
    				promotionList.add(item);
    			}
    		}
    		
    	} else if(hasBuyItem && hasQuantityItem && !hasAmountItem){
			// quantity and item
    		for(String item : buyItemsList){
    			if(quantityItemsList.contains(item)){
    				promotionList.add(item);
    			}
    		}
		}    	

    	return promotionList;
    }
    
     /**
     * Retrieve List<String> of Promotion Rule Type Codes
     *
     * @param promotionId - Promotion Id of Item
     * @return List<String> of PromotionRuleTypeCodes
     */
    private List<PromotionRule> getPromotionRules(String promotionId){
    	List<PromotionRule> ruleType = new ArrayList<PromotionRule>(); // from database
    	
    	SearchPipelineExecuter pipeline = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                "Promotion", "RulesList");
    	 pipeline.setParam("@LanguageCode", _languageCodeParam);
    	 pipeline.setParam("promotionID", promotionId);
    	 pipeline.setParam("IsM3", "N");
    	 
    	 try {
			XMLResultset promotion = pipeline.execute();
			if (promotion != null && !promotion.isEmpty()) {
				promotion.moveFirst();
                XMLIterator promotionRules = (XMLIterator) promotion.getResultset(ConstantsForSales.RULES);
                if (promotionRules != null && !promotionRules.isEmpty()) {
                	promotionRules.beforeFirst();
                	PromotionRule promotionRule = null;
                	while (promotionRules.moveNext()) {
                		promotionRule = new PromotionRule();
                		promotionRule.setPromotionName(promotionRules.getString(ConstantsForSales.NAME));
                		promotionRule.setRuleType(promotionRules.getString(ConstantsForSales.RULE_CODE));
                		promotionRule.setField(promotionRules.getString(ConstantsForSales.FIELD_CODE));               
                		promotionRule.setOperator(promotionRules.getString(ConstantsForSales.OPERATOR_TEXT));
                		promotionRule.setExchangeRate(this.exchangeRate);
                		promotionRule.setAltExchangeRate(promotion.getString(ConstantsForSales.CURRENCY_RATE));
                		
                		XMLIterator promotionRuleValues = (XMLIterator)promotionRules.getResultset(ConstantsForSales.VALUE);
                		if (promotionRuleValues != null && !promotionRuleValues.isEmpty()) {
                			List<String> values = new ArrayList<String>();
                			promotionRuleValues.beforeFirst();
                        	while (promotionRuleValues.moveNext()) {
                        		values.add(promotionRuleValues.getString(ConstantsForSales.VALUE));
                        	}
                        	promotionRule.setValues(values);
                		}
                		
                		ruleType.add(promotionRule);
                	}
                }
			}
		} catch (PipelineRuntimeException e) {
			e.printStackTrace();
		} catch (ResultsetException e) {
			e.printStackTrace();
		}
    	
    	return ruleType;
    }

    
    private List<String> getPromotionalItemsInCart(String promotionId){
    	List<String> promotionalItemsInCart = new ArrayList<String>();
    	List<String> promoItemsList =  this.promotionalItemsMap.get(promotionId);
    	try {
			this.resultSet.moveFirst();
			XMLIterator xmlOrderline = (XMLIterator) this.resultSet.getResultset(ConstantsForSales.ORDERLINE);
			if ((xmlOrderline == null) || xmlOrderline.isEmpty()) {
				LOG.debug("The sub resultset orderlines is null or empty: resultset is null = " + (xmlOrderline == null)
						+ " or resultset is empty = " + xmlOrderline.isEmpty());
			}
			xmlOrderline.beforeFirst();
			while (xmlOrderline.moveNext()) {
				String itemIDFromRequest = xmlOrderline.getString("ItemID");
				if(promoItemsList.contains(itemIDFromRequest)){
					promotionalItemsInCart.add(itemIDFromRequest);
				}
			}	
		} catch (ResultsetException e) {
			e.printStackTrace();
		}
    	
    	return promotionalItemsInCart;
    }
    
    /**
     * Get parameter value by name from parameter block in context.
     * 
     * @param parameterName
     *            name of the requested parameter
     * @param params
     *            pipeline request parameters including requested parameter
     * @return the parameter value as a string
     */
    protected String getStringFromParameter(final String parameterName, final Parameters params) {
        try {
            return params.getString(parameterName);
        } catch (ParametersException e) {
            LOG.error("Try to get parameter: " + parameterName);
            return "";
        }
    }
    
    public BigDecimal getDecimalFromParameter(final String parameterName, final Parameters params, final String defaulValue){
    	try {
            return new BigDecimal(params.getString(parameterName));
        } catch (ParametersException e) {
            LOG.error("Try to get parameter: " + parameterName);
            return new BigDecimal(defaulValue);
        }
    }

    public BigDecimal stringToDecimal(String value) throws ParseException {
        NumberFormat nf = NumberFormat.getNumberInstance();
        //Number n = nf.parse(value);
		Number n = nf.parse(nf.format(new Double(value)));
        if (n instanceof com.ibm.icu.math.BigDecimal) {
            return new BigDecimal(((com.ibm.icu.math.BigDecimal) n).toString());
        } else if (n instanceof BigDecimal) {
            return (BigDecimal) n;
        } else if (n instanceof Long) {
            return new BigDecimal(n.toString());
        } else {
            FastStringBuffer error = new FastStringBuffer();
            error.append("Could not parse as decimal: ");
            error.append(value);
            error.append(". Parser returned unknown decimal type: ");
            error.append(n.getClass());
            throw new ParseException(error.toString(), 0);
        }
    }
    
    public Document getExistingOrder(String orderID){
		XMLResultset res;
		SearchPipelineExecuter spe;
		Document resultSet = null;
		try {
			spe = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "CurrentOrder","GetExistingOrder");
			spe.setBinding(ConstantsForSales.ORDERID, orderID, "eq");
			res = spe.execute();
			res.beforeFirst();
			res.moveNext();
			resultSet = res.getDocument();
			
			/*// Get OrderLine node in the response document
			orderlineList = XPathAPI.selectNodeList(resultSet, "//row/OrderLine");*/
		} catch (PipelineRuntimeException e) {
			e.printStackTrace();
		} catch (ResultsetException e) {
			e.printStackTrace();
		}
		return resultSet;
    }
    
    private Map<String, List<String>> retrievedPromotionalItems(List<String> promotionIdList){
    	LOG.debug("Inside PromotionRulesEngine.retrievedPromotionalItems() ");
    	Map<String, List<String>> promotionalItemsMap = new HashMap<String, List<String>>();
    	List<String> promoItemsList = null;
    	for (String strPromotionId : promotionIdList) {
        	SearchPipelineExecuter pipeline = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                    "Promotion", "ListPromotionalItems");
        	pipeline.setParam("@LanguageCode", this._languageCodeParam);
        	pipeline.setParam("PromotionID", strPromotionId);
        	pipeline.setParam("IsM3", "N");
        	
        	try {
    			XMLResultset promotion = pipeline.execute();
    			
    			promoItemsList = new ArrayList<String>();
    			if (promotion != null && !promotion.isEmpty()) {
    				promotion.moveFirst();
    				XMLIterator promotionalItems = (XMLIterator) promotion.getResultset(ConstantsForSales.ITEM);
    				if (promotionalItems != null && !promotionalItems.isEmpty()) {
    					promotionalItems.beforeFirst();
    					while (promotionalItems.moveNext()) {
    						promoItemsList.add(promotionalItems.getString(ConstantsForSales.ITEMNUMBER));
    					}
    				}
    			}
    			promotionalItemsMap.put(strPromotionId, promoItemsList);
    			
    		} catch (PipelineRuntimeException e) {
    			e.printStackTrace();
    		} catch (ResultsetException e) {
    			e.printStackTrace();
    		}
		}
    	return promotionalItemsMap;
    }
    
    private String updRsAttr(final XMLResultset rs, final String rsPar, final String value) {
        return CustomStagesHelper.updateRsAttribute(rs, rsPar, value);
    }
    
    private String updRsAttr(final XMLIterator rs, final String rsPar, final String value) {
        return CustomStagesHelper.updateRsAttribute(rs, rsPar, value);
    }
    
}
