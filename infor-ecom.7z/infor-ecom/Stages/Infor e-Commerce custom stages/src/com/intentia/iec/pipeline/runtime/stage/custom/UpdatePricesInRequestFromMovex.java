/*
 * Created on 13-04-2004
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;

import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

/**
 * Stage to get the latest prices for the current user / user group from Movex
 * for the items in the current request.
 * <p>
 * <b>Required input in <code>PipelineContext</code>:</b><br>
 * Input parameters: <code>mvxCompany</code>, <code>mvxFacility</code>,
 * <code>mvxOrderType</code>, <code>mvxWareHouse</code>,
 * <code>&#64;CurrencyCode</code>, <code>&#64;ListPriceGroup</code>, and
 * <code>UserGroupID</code>
 * <p>
 * <b>Generated output in <code>PipelineContext</code>:</b><br>
 * Output parameters: <code>mvxStatus</code> (error if negative)
 */
/*
 * The text uses the character code &#64; for @ to avoid to confuse the Java
 * auto formatter.
 */
public final class UpdatePricesInRequestFromMovex extends UpdatePricesFromMovex implements PipelineStage {

    static final Logger LOG = Logger.getLogger(UpdatePricesInRequestFromMovex.class);

    /**
     * The stage entry point.
     * 
     * @see com.intentia.iec.pipeline.runtime.PipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
     */
    public void execute(final PipelineContext context) throws PipelineRuntimeException {

        // Movex connector not enabled => skip stage
        if (!"true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.CONNECTORENABLED))) {
            return;
        }
        CustomStagesHelper.extractRequestParameters(CustomStagesHelper.getRequest(context));

        // Call the actual update function in the derived class
        update(context);
    }

    /**
     * Updates prices for all items in the request.
     * <p>
     * 
     * @param context
     *            PipelineContext
     * @throws PipelineRuntimeException
     */
    protected static void update(final PipelineContext context) throws PipelineRuntimeException {

        // Verify the context
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }

        try {
            // Retreive XML request from context
            XMLRequest xmlRequest = (XMLRequest) context.getRequest();
            Document request = xmlRequest.getRequestDoc();
            // Get the itemIDs that are in the request
            NodeList nodeList = XPathAPI.selectNodeList(request,
                    "request/entities/entity/subsets/subset[@name=\"OrderLine\"]");

            XMLRequestHelper xmlHelper = new XMLRequestHelper(request);

            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                if (!updateLine(context, xmlHelper, node)) {
                    break;
                }
            }
        } catch (final RequestException e) {
            final String msg = "Could not read/traverse the request.";
            LOG.error(msg, e);
            throw new PipelineRuntimeException("Could not read/traverse the request.", e);
        } catch (final TransformerException e) {
            final String msg = "Could not read/traverse the request.";
            LOG.error(msg, e);
            throw new PipelineRuntimeException(msg, e);
        }
    }

    /**
     * @param context
     *            PipelineContext
     * @param xmlHelper
     *            Helper class for manipulating the XML document/node
     * @param item
     *            XML node in request with information for a item
     * @return true if prices were updated (OK)
     * @throws Exception
     */
    public static boolean updateLine(final PipelineContext context, final XMLRequestHelper xmlHelper, final Node item)
            throws PipelineRuntimeException {

        String itemID = null;
        try {
            itemID = xmlHelper.getAttribute(item, ConstantsForSales.ITEMID);
            final String mvxConfigNo1 = xmlHelper.getAttribute(item, ConstantsForSales.MVXCONFIGURABLENUMBER);
            final String mvxConfigNo = xmlHelper.getAttribute(item, ConstantsForSales.MVX_CONFIGURABLE_ID);
            final String quantity = xmlHelper.getAttribute(item, ConstantsForSales.QUANTITY);
            ItemPrices itemPrices = new ItemPrices(context);
            if (itemPrices.getPrices(itemID, mvxConfigNo, quantity)) {
                xmlHelper.setAttribute(item, ConstantsForSales.RESELLPRICE, itemPrices.getResellPrice());
                xmlHelper.setAttribute(item, ConstantsForSales.LINEPRICE, itemPrices.getLinePrice());
                xmlHelper.setAttribute(item, ConstantsForSales.LINEDISCOUNT, itemPrices.getDiscount());
                xmlHelper.setAttribute(item, ConstantsForSales.LINEDISPERCENT, itemPrices.getDisPercent());
                xmlHelper.setAttribute(item, ConstantsForSales.LINETOTAL, itemPrices.getLineTotal());
                xmlHelper.setAttribute(item, ConstantsForSales.ISLISTPRICE, itemPrices.getIsListPrice());
                return true;
            } else {
                return false;
            }
        } catch (final TransformerException e) {
            final String msg = "Failed in updating line with prices for " + itemID;
            LOG.error(msg, e);
            throw new PipelineRuntimeException(msg, e);
        }
    }

}
