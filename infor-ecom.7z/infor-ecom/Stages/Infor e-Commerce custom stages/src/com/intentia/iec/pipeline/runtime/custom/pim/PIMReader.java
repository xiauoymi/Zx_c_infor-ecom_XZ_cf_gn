/*
 * Created on 24-02-2006
 */
package com.intentia.iec.pipeline.runtime.custom.pim;

import java.util.LinkedList;

import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.apache.log4j.Logger;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.util.FastStringBuffer;

/**
 * A <code>PIMReader</code> instance can be used to read a PCM delta.xml file
 * as a sequence of XML request documents. The XML request documents can then be
 * executed against e-Sales business object methods to update the e-Sales
 * database with the PCM catalog changes.
 * 
 * A PCM catalog delta.xml files contains the logical elements:
 * <dl>
 * <dt>A catalog root.</dt>
 * <dd>The catalog root can contain one or more structural elements - in the
 * delta.xml files just called 'structures'. The catalog root itself is
 * translated to be a category in e-Sales - the category root node in an e-Sales
 * category tree.</dd>
 * <dt>A structure</dt>
 * <dd>A structure has a number of attributes as well as language specific
 * attributes. It can also contain: images, one or more child structure or one
 * or more child products. Structures are translated to be e-Sales categories,
 * i.e. every structure in a delta.xml document is a category in e-Sales.</dd>
 * <dt>A product</dt>
 * <dd>A product also has a number attributes and language specific attributes.
 * A product contains images, related products and one or more articles as
 * children. A product in PCM is also a product in e-Sales.</dd>
 * <dt>Related products</dt>
 * <dd>A product can be related to other products as either cross sale, upsale
 * replacement or an accessory. This types are also used in e-Sales.</dd>
 * <dt>An article</dt>
 * <dd>An article has a number of attributes and language specific attributes.
 * It also contains images. An article is translated to what is called an Item
 * in both M3 and in e-Sales. Article attributes are in general not integrated
 * with e-Sales item attributes except for the language specific attribute
 * 'Market Text'. The catalog location (the parent product) is read from the
 * delta.xml and applied to e-Sales. file. The e-Sales item attribute values are
 * integrated with M3 instead of with PCM. </dd>
 * <dt>Images</dt>
 * <dd>Both structures, products and articles can contain images. PCM can
 * publish 3 image file for each image: A thumb, a normal size and a big image.
 * These three image files types are translated as thumbs, previews and master
 * images in e-Sales (see attributes ImagePreview, ImageMaster and ImageThumb in
 * Category, Product and Item business objects). An e-Sales business object can
 * integrate from 1 to all 3 image types. (Category business object only
 * integrates preview images).</dd>
 * </dl>
 * 
 * <p>
 * Each of these logical elements have a {@link PIMStatus status}, which is
 * used to determine if the logical element should be inserted, updated, deleted
 * in the e-Sales database. Depending on the status a suitable insert, update or
 * delete XML request can be returned when reading the delta.xml file.
 * </p>
 * 
 * <p>
 * As seen from the above description a catalog is a tree. An example could be
 * 
 * <pre>
 *             catalog root
 *                   �|- Tools (structure)
 *                    |    |- Hammers (structure)
 *                    |    |     |- Steel hammer (Product)
 *                    |    |     |      |- Blue steel hammer(Article)
 *                    |    |     |      |- Red steel hammer (Article)
 *                    |    |     |
 *                    |    |     |- Wooden hammer (Product)
 *                    |    |            |- Black wooden hammer (Article)
 *                    |    |            |- Grey wooden hammer (Article)
 *                    |    |
 *                    |    |- Screw drivers (structure)
 *                    |            |- Star screw driver (Product)
 *                    |                        |- Red star screw driver (Article)
 *                    |                        |- Yellow star screw driver (Article)
 *                    |
 *                    |- Books(structure)
 *                            |-
 *                              ...          
 * </pre>
 * 
 * </p>
 * <p>
 * PIMReader will read the delta.xml by <a href="http://www.xmlpull.org/">XML
 * pull parsing</a>. Considering the above tree written as a delta.xml file the
 * tree will be read/traversed in the following order: catalog root, Tools,
 * Hammers, Steel hammer, Blue steel hammer, Red steel hammer, Wooden hammer,
 * Black wooden hammer, Grey wooden hammer, Screw drivers, Star screw driver,
 * Red star screw driver, Yellow star screw driver, Books, ...
 * </p>
 * 
 * @author PEDJES0
 */
public class PIMReader {

    protected static final Logger LOG = Logger.getLogger(PIMReader.class);

    private class Status {
        private boolean isValid = false;

        private boolean hasProduct = false;

        private boolean hasItem = false;

        private boolean hasSection = false;

        private boolean hasCatalog = false;

        private boolean hasImage = false;

        private boolean hasProductRelation = false;
    }

    private Status readStatus = new Status();

    public static final String PROP_PIM_CATEGORY_ID = "PIM.Category.id";

    public static final String PROP_PIM_CATEGORY_MARKETTEXTL = "PIM.Category.PCM_MarketTextL";

    public static final String PROP_PIM_PRODUCT_ID = "PIM.Product.id";

    public static final String PROP_PIM_ITEM_ID = "PIM.Item.id";

    public static final String ACCESSORIES_TYPE = "AccessoryProductRelation";

    public static final String UPSALE_TYPE = "UpsaleProductRelation";

    public static final String REPLACEMENT_TYPE = "ReplacementProductRelation";

    public static final String CROSSSALE_TYPE = "CrosssaleProductRelation";

    private final XMLStreamReader parser;

    private String productRelationTypeID = null;

    private String catalogName = null;

    private String catalogID = null;

    private short status = -1;

    private String collsName = null;

    private String collsValue = null;

    private String name = null;

    private String language = null;

    private String value = null;

    private String attrName = null;

    private String entityName = null;

    private String imageType = null;

    private String url = null;

    private boolean readingColls = false;

    private boolean readingColl = false;

    private boolean readingAttrs = false;

    private boolean readingRes = false;

    private String productID = null;

    private String itemID = null;

    private String buffer = null;

    private boolean readText = false;

    private FastStringBuffer workingBuffer = new FastStringBuffer();

    private boolean readUpdate = false;

    private final String imageCatalogPrefix;

    private final LinkedList parentIDStack = new LinkedList();

    private boolean isMain = false;

    private ImageFileHandler imageHandler;

    private short sectionLevel = 0;

    /**
     * This constructor takes a ImageFileHandler instance as parameter, which is
     * responsible for copying image files from PCM folder
     * (...PublishedData/e-Sales/files) to e-Sales image folder.
     * 
     * @param parser
     *            XML pull parser (allready initialized) for reading a delta.xml
     *            document
     * @param imageCatalogPrefix
     *            The image path prefix in delta.xml, which should be removed
     *            before updating the e-Sales database with the image path.
     * @param imageHandler
     *            ImageFileHandler responsible for copying image files from PCM
     *            folder to e-Sales image folder.
     */
    public PIMReader(final XMLStreamReader parser, final String imageCatalogPrefix, final ImageFileHandler imageHandler) {
        this.parser = parser;
        this.imageCatalogPrefix = imageCatalogPrefix;
        this.imageHandler = imageHandler;
    }

    /**
     * This constructur is useable for unit tests. Use this constructor when
     * image files should not be copyed.
     * 
     * @param parser
     *            XML pull parser (allready initialized) for reading a delta.xml
     *            document
     * @param imageCatalogPrefix
     *            The image path prefix in delta.xml, which should be removed
     *            before updating the e-Sales database with the image path.
     */
    public PIMReader(final XMLStreamReader parser, final String imageCatalogPrefix) {
        this.parser = parser;
        this.imageCatalogPrefix = imageCatalogPrefix;
        // create an ImageFileHandler with an empty copyImage method...this way
        // image files are not tried copied.
        this.imageHandler = new ImageFileHandler(null, null) {
            public final void copyImage(final String path) {
                // DO NOTHING
            }
        };
    }

    public final boolean hasCatalog() throws CatalogParserException, XMLStreamException {
        if (readStatus.isValid) {
            return readStatus.hasCatalog;
        }

        while (parser.hasNext()) {
            int event = parser.next();
            if (event == XMLStreamConstants.START_ELEMENT) {
                if ("catalog".equals(parser.getLocalName())) {
                    status = PIMStatus.parseStatus(parser.getAttributeValue(null, "PCM_delta"));
                    readStatus.isValid = true;
                    readStatus.hasCatalog = true;
                    break;
                } else {
                    throw new CatalogParserException("Wrong root element of PIM XML catalog. "
                            + "Root element must be 'catalog'.");
                }
            }
        }

        return readStatus.hasCatalog;
    }

    public final short readCatalogStatus() throws CatalogParserException, XMLStreamException {
        if (!hasCatalog()) {
            throw new CatalogParserException("Wrong position of reader. 'structure' element not available.");
        }

        return status;
    }

    public final String getCatalogName() {
        return catalogName;
    }

    public final String getCatalogID() {
        return catalogID;
    }

    /**
     * This method skips the catalog element without skipping the children.
     * 
     * @throws CatalogIntegrationException
     */
    public final void skipCatalog() throws XMLStreamException, CatalogIntegrationException {
        try {
            while (parser.hasNext()) {
                int event = parser.next();
                if (event == XMLStreamConstants.START_ELEMENT && "id".equals(parser.getLocalName())) {
                    // The PIM id field is only read, if the application
                    // properties
                    // contains a mapping.
                    if (!readingColl) {
                        String id = CustomStagesHelper.getKeyValue(PROP_PIM_CATEGORY_ID);
                        readText = (id != null);
                    }
                } else if (event == XMLStreamConstants.END_ELEMENT && readText && "id".equals(parser.getLocalName())) {
                    // by including readText in the above criteria, then the id
                    // field is only read if it is mapped to an e-Sales BO
                    // attribute.
                    readText = false;
                    if (!readingColl) {
                        catalogID = buffer;
                        // Catalog/Sections are always read in 'pre-order
                        // traversal'
                        // when parsing, then ParentCategoryID's can be
                        // maintained
                        // in a stack.
                        parentIDStack.addLast(buffer);
                    }
                } else if (event == XMLStreamConstants.CHARACTERS && readText) {
                    buffer = parser.getText();
                } else if (event == XMLStreamConstants.START_ELEMENT && "colls".equals(parser.getLocalName())) {
                    skipColls();
                } else if (event == XMLStreamConstants.START_ELEMENT && "dataItems".equals(parser.getLocalName())) {
                    // We have reached the catalog images.
                    readStatus.isValid = false;
                    readStatus.hasSection = false;
                    break;
                } else if (event == XMLStreamConstants.START_ELEMENT && "childs".equals(parser.getLocalName())) {
                    // We have reached the end of a product relation.
                    readStatus.isValid = false;
                    readStatus.hasCatalog = false;
                    break;
                } else if (event == XMLStreamConstants.END_ELEMENT && "category".equals(parser.getLocalName())) {
                    // We have reached the end of a product relation.
                    readStatus.isValid = false;
                    readStatus.hasCatalog = false;
                    break;
                }
            }
        } catch (PipelineRuntimeException e) {
            throw new CatalogIntegrationException(e);
        }
    }

    /**
     * This method skips the sectoin element without skipping the children.
     * 
     * @throws CatalogIntegrationException
     */
    public final void skipSection() throws XMLStreamException, CatalogIntegrationException {
        try {

            while (parser.hasNext()) {
                int event = parser.next();
                if (event == XMLStreamConstants.START_ELEMENT && "id".equals(parser.getLocalName())) {
                    // The PIM id field is only read, if the application
                    // properties
                    // contains a mapping.
                    if (!readingColl) {
                        String id = CustomStagesHelper.getKeyValue(PROP_PIM_CATEGORY_ID);
                        readText = (id != null);
                    }
                } else if (event == XMLStreamConstants.END_ELEMENT && readText && "id".equals(parser.getLocalName())) {
                    // by including readText in the above criteria, then the id
                    // field is only read if it is mapped to an e-Sales BO
                    // attribute.
                    readText = false;
                    if (!readingColl) {
                        // Catalog/Sections are always read in 'pre-order
                        // traversal'
                        // when parsing, then ParentCategoryID's can be
                        // maintained
                        // in a stack.
                        parentIDStack.addLast(buffer);
                    }
                } else if (event == XMLStreamConstants.CHARACTERS && readText) {
                    buffer = parser.getText();
                } else if (event == XMLStreamConstants.START_ELEMENT && "dataItems".equals(parser.getLocalName())) {
                    // We have reached the section images.
                    readStatus.isValid = false;
                    readStatus.hasSection = false;
                    break;
                } else if (event == XMLStreamConstants.START_ELEMENT && "childs".equals(parser.getLocalName())) {
                    // We have reached the end of a product relation.
                    readStatus.isValid = false;
                    readStatus.hasSection = false;
                    break;
                } else if (event == XMLStreamConstants.END_ELEMENT && "structure".equals(parser.getLocalName())) {
                    // We have reached the end of a product relation.
                    readStatus.isValid = false;
                    readStatus.hasSection = false;
                    break;
                }
            }
        } catch (PipelineRuntimeException e) {
            throw new CatalogIntegrationException(e);
        }
    }

    /**
     * This method skips a product element without skipping the product
     * relations or childs articles.
     * 
     * @throws CatalogIntegrationException
     */
    public final void skipProduct() throws XMLStreamException, CatalogIntegrationException {
        try {
            while (parser.hasNext()) {
                int event = parser.next();
                if (event == XMLStreamConstants.START_ELEMENT && "id".equals(parser.getLocalName())) {
                    // The PIM id field is only read, if the application
                    // properties
                    // contains a mapping.
                    if (!readingColl) {
                        String id = CustomStagesHelper.getKeyValue(PROP_PIM_PRODUCT_ID);
                        readText = (id != null);
                    }
                } else if (event == XMLStreamConstants.END_ELEMENT && readText && "id".equals(parser.getLocalName())) {
                    // by including readText in the above criteria, then the id
                    // field is only read if it is mapped to an e-Sales BO
                    // attribute.
                    readText = false;
                    if (!readingColl) {
                        // Catalog/Sections are always read in 'pre-order
                        // traversal'
                        // when parsing, then ParentCategoryID's can be
                        // maintained
                        // in a stack.
                        productID = buffer;
                    }
                } else if (event == XMLStreamConstants.CHARACTERS && readText) {
                    buffer = parser.getText();
                } else if (event == XMLStreamConstants.START_ELEMENT && "dataItems".equals(parser.getLocalName())) {
                    // We have reached the product images.
                    readStatus.isValid = false;
                    readStatus.hasProduct = false;
                    break;
                } else if (event == XMLStreamConstants.START_ELEMENT && "relatedItems".equals(parser.getLocalName())) {
                    // We have reached the end of a product relation.
                    readStatus.isValid = false;
                    readStatus.hasProduct = false;
                    break;
                } else if (event == XMLStreamConstants.START_ELEMENT && "childs".equals(parser.getLocalName())) {
                    // We have reached the end of a product relation.
                    readStatus.isValid = false;
                    readStatus.hasProduct = false;
                    break;
                } else if (event == XMLStreamConstants.END_ELEMENT && "product".equals(parser.getLocalName())) {
                    // We have reached the end of a product relation.
                    readStatus.isValid = false;
                    readStatus.hasProduct = false;
                    break;
                }
            }
        } catch (PipelineRuntimeException e) {
            throw new CatalogIntegrationException(e);
        }
    }

    /**
     * This method skips a product element without skipping the product
     * relations or childs articles.
     */
    public final void skipItem() throws XMLStreamException {
        while (parser.hasNext()) {
            int event = parser.next();
            if (event == XMLStreamConstants.START_ELEMENT && "attrs".equals(parser.getLocalName())) {
                // This construction will also skip the <attrs> within the
                // <coll> elements.
                skipArticleAttrs();
            } else if (event == XMLStreamConstants.START_ELEMENT && "dataItems".equals(parser.getLocalName())) {
                // We have reached the product images.
                readStatus.isValid = false;
                readStatus.hasProduct = false;
                break;
            } else if (event == XMLStreamConstants.END_ELEMENT && "article".equals(parser.getLocalName())) {
                // We have reached the end of a product relation.
                readStatus.isValid = false;
                readStatus.hasProduct = false;
                break;
            }
        }
    }

    private void skipArticleAttrs() throws XMLStreamException {
        // readingAttrs is only set when reading <attrs> and </attrs>.
        // Will this improve performance ? (less assignments to
        // readingAttrs than to an equivalent readingAttr parameter, but
        // yet another string comparison "attrs.equals(...)")
        while (parser.hasNext()) {
            int event = parser.next();
            if (event == XMLStreamConstants.CHARACTERS && readText) {
                buffer = parser.getText();
            } else if (event == XMLStreamConstants.START_ELEMENT && "attr".equals(parser.getLocalName())) {
                name = null;
                value = null;
            } else if (event == XMLStreamConstants.START_ELEMENT && "name".equals(parser.getLocalName())) {
                readText = true;
            } else if (event == XMLStreamConstants.END_ELEMENT && "name".equals(parser.getLocalName())) {
                name = buffer;
                readText = false;
            } else if (event == XMLStreamConstants.START_ELEMENT && "value".equals(parser.getLocalName())) {
                readText = true;
            } else if (event == XMLStreamConstants.END_ELEMENT && "value".equals(parser.getLocalName())) {
                value = buffer;
                readText = false;
            } else if (event == XMLStreamConstants.END_ELEMENT && "attrs".equals(parser.getLocalName())) {
                break;
            } else if (event == XMLStreamConstants.END_ELEMENT && "attr".equals(parser.getLocalName())) {
                if (readStatus.hasItem) {
                    if ("MVX_ITNO".equals(name)) {
                        // TODO should MVX_ITNO be mapped? - yes
                        itemID = value;
                    }
                }
            }
        }
    }

    /*
     * This method reads the base content of the catalog. The base content is
     * considered all the child element different from <attrs/>, <colls/>,
     * <dataItems/> and <childs/>. At the current moment these are the elements
     * <createdBy/>, <createdTS/>, <lastChangedBy/>, <lastChangedTS/>,
     * <sortOrder/>, <pid/>, <id/>, <compId/>, <version/>, <entityName/> and
     * <type/>. Only the elements that are needed are read. The others are
     * ignored.
     */
    public final DeleteSet readSectionDelete() throws XMLStreamException, CatalogIntegrationException {
        readText = false;

        DeleteSet set = null;
        try {
            while (parser.hasNext()) {
                int event = parser.next();
                if (event == XMLStreamConstants.START_ELEMENT && "id".equals(parser.getLocalName())) {
                    String id = CustomStagesHelper.getKeyValue(PROP_PIM_CATEGORY_ID);
                    readText = "CategoryID".equals(id);
                } else if (event == XMLStreamConstants.END_ELEMENT && readText && "id".equals(parser.getLocalName())) {
                    readText = false;
                    set = new DeleteSet(buffer);
                    parentIDStack.addLast(buffer);
                } else if (event == XMLStreamConstants.CHARACTERS && readText) {
                    buffer = parser.getText();
                } else if (event == XMLStreamConstants.START_ELEMENT
                        && ("attrs".equals(parser.getLocalName()) || "colls".equals(parser.getLocalName())
                                || "dataItems".equals(parser.getLocalName()) || "childs".equals(parser.getLocalName()))) {
                    // We have reached one of the elements attrs, colls,
                    // dataItems
                    // or childs, which means that the base content of the
                    // catalog
                    // have been read.
                    break;
                } else if (event == XMLStreamConstants.START_ELEMENT && ("childs".equals(parser.getLocalName()))) {
                    readStatus.isValid = false;
                    readStatus.hasSection = false;
                } else if (event == XMLStreamConstants.END_ELEMENT && ("structure".equals(parser.getLocalName()))) {
                    readStatus.isValid = false;
                    readStatus.hasSection = false;
                    parentIDStack.removeLast();
                    break;
                }
            }
            return set;
        } catch (PipelineRuntimeException e) {
            throw new CatalogIntegrationException(e);
        }
    }

    /**
     * This method reads an item disconnect. That is a delete request for the
     * Item/Product og Item/Category subset is created.
     * 
     * @return An Item/Product or Item/Category delete request.
     * @throws XMLStreamException
     * @throws PipelineRuntimeException
     */
    public final DeleteSet readItemDisconnect() throws XMLStreamException {
        readText = false;
        DeleteSet set = null;
        while (parser.hasNext()) {
            int event = parser.next();
            if (event == XMLStreamConstants.CHARACTERS && readText) {
                buffer = parser.getText();
            } else if (event == XMLStreamConstants.START_ELEMENT && "attrs".equals(parser.getLocalName())) {
                if (!readingColls) {
                    readingAttrs = true;
                }
            } else if (event == XMLStreamConstants.START_ELEMENT && "attr".equals(parser.getLocalName())) {
                name = null;
                value = null;
            } else if (event == XMLStreamConstants.START_ELEMENT && "name".equals(parser.getLocalName())) {
                // These are the language specific attributes, that must be
                // added to the Category 'Text' subset.
                if (readingAttrs) {
                    readText = true;
                }
            } else if (event == XMLStreamConstants.END_ELEMENT && "name".equals(parser.getLocalName())) {
                // These are the language specific attributes, that must be
                // added to the Category 'Text' subset.
                if (readingAttrs) {
                    name = buffer;
                    readText = false;
                }
            } else if (event == XMLStreamConstants.START_ELEMENT && "value".equals(parser.getLocalName())) {
                // These are the language specific attributes, that must be
                // added to the Category 'Text' subset.
                if (readingAttrs) {
                    readText = true;
                }
            } else if (event == XMLStreamConstants.END_ELEMENT && "value".equals(parser.getLocalName())) {
                // These are the language specific attributes, that must be
                // added to the Category 'Text' subset.
                if (readingAttrs) {
                    value = buffer;
                    readText = false;
                }
            } else if (event == XMLStreamConstants.END_ELEMENT && "attrs".equals(parser.getLocalName())) {
                // readingAttrs is only set on <attrs> and </attrs>
                readingAttrs = false;
            } else if (event == XMLStreamConstants.END_ELEMENT && "attr".equals(parser.getLocalName())) {
                if (readingAttrs) {
                    if ("MVX_ITNO".equals(name)) {
                        // TODO should MVX_ITNO be mapped? - yes
                        set = new DeleteSet(value);
                        // An item is never tried deleted from the e-Sales
                        // database through the PIM integration. This because
                        // items are controlled from Movex. Items are instead
                        // just disconnected from their parent product/category
                        // by an XML delete request on the Item/Product subset
                        // or Item/Category/Subset.
                        if (productID == null) {
                            set.addChildSet("Category", (String) parentIDStack.getLast());
                        } else {
                            set.addChildSet("Product", productID);
                        }
                    }
                }
            } else if (event == XMLStreamConstants.START_ELEMENT && "colls".equals(parser.getLocalName())) {
                readingColls = true;
            } else if (event == XMLStreamConstants.END_ELEMENT && "colls".equals(parser.getLocalName())) {
                readingColls = false;
            } else if (event == XMLStreamConstants.START_ELEMENT && "dataItems".equals(parser.getLocalName())) {
                skipImages();
                readStatus.isValid = false;
                readStatus.hasItem = false;
                break;
            } else if (event == XMLStreamConstants.END_ELEMENT && ("article".equals(parser.getLocalName()))) {
                // We have reached the end of the product.
                readStatus.isValid = false;
                readStatus.hasItem = false;
                break;
            }
        }
        return set;
    }

    /**
     * This method reads a product category delete.
     * 
     * @return A Product/Category delete request.
     * @throws XMLStreamException
     * @throws CatalogIntegrationException
     * @throws PipelineRuntimeException
     */
    public final DeleteSet readProductDisconnect() throws XMLStreamException, CatalogIntegrationException {
        try {
            readText = false;
            DeleteSet set = null;
            while (parser.hasNext()) {
                int event = parser.next();
                if (event == XMLStreamConstants.START_ELEMENT && "id".equals(parser.getLocalName())) {
                    if (!readingColls) {
                        String id = CustomStagesHelper.getKeyValue(PROP_PIM_PRODUCT_ID);
                        readText = "ProductID".equals(id);
                    }
                } else if (event == XMLStreamConstants.END_ELEMENT && readText && "id".equals(parser.getLocalName())) {
                    readText = false;
                    set = new DeleteSet(buffer);
                    set.addChildSet("Category", (String) parentIDStack.getLast());
                } else if (event == XMLStreamConstants.START_ELEMENT && "colls".equals(parser.getLocalName())) {
                    readingColls = true;
                } else if (event == XMLStreamConstants.END_ELEMENT && "colls".equals(parser.getLocalName())) {
                    readingColls = false;
                } else if (event == XMLStreamConstants.START_ELEMENT && "dataItems".equals(parser.getLocalName())) {
                    skipImages();
                } else if (event == XMLStreamConstants.CHARACTERS && readText) {
                    buffer = parser.getText();
                } else if (event == XMLStreamConstants.START_ELEMENT && "relatedItems".equals(parser.getLocalName())) {
                    skipRelatedProducts();
                } else if (event == XMLStreamConstants.START_ELEMENT && "childs".equals(parser.getLocalName())) {
                    skipChildren();
                } else if (event == XMLStreamConstants.END_ELEMENT && ("product".equals(parser.getLocalName()))) {
                    // We have reached the end of the product.
                    readStatus.isValid = false;
                    readStatus.hasProduct = false;
                    break;
                }
            }
            return set;
        } catch (PipelineRuntimeException e) {
            throw new CatalogIntegrationException(e);
        }
    }

    private void skipRelatedProducts() throws XMLStreamException {
        while (parser.hasNext()) {
            int event = parser.next();
            if (event == XMLStreamConstants.END_ELEMENT && "relatedItems".equals(parser.getLocalName())) {
                break;
            }
        }
    }

    private void skipChildren() throws XMLStreamException {
        short count = 0;
        while (parser.hasNext()) {
            int event = parser.next();
            if (event == XMLStreamConstants.START_ELEMENT && "childs".equals(parser.getLocalName())) {
                count++;
            } else if (event == XMLStreamConstants.END_ELEMENT && "childs".equals(parser.getLocalName())) {
                if (count == 0) {
                    // We have reached the child level we started at.
                    break;
                } else {
                    count--;
                }
            }
        }
    }

    public final Entity readSectionDisconnect() throws XMLStreamException, CatalogParserException,
            CatalogIntegrationException {
        try {

            readText = false;
            Entity entity = new Entity();
            while (parser.hasNext()) {
                int event = parser.next();
                if (event == XMLStreamConstants.START_ELEMENT && "id".equals(parser.getLocalName())) {
                    if (!readingColls) {
                        String id = CustomStagesHelper.getKeyValue(PROP_PIM_CATEGORY_ID);
                        readText = "CategoryID".equals(id);
                    }
                } else if (event == XMLStreamConstants.END_ELEMENT && readText && "id".equals(parser.getLocalName())) {
                    readText = false;
                    entity.setKey(buffer);
                    entity.addAttribute("ParentCategoryID", null);
                } else if (event == XMLStreamConstants.START_ELEMENT && "colls".equals(parser.getLocalName())) {
                    readingColls = true;
                } else if (event == XMLStreamConstants.END_ELEMENT && "colls".equals(parser.getLocalName())) {
                    readingColls = false;
                } else if (event == XMLStreamConstants.START_ELEMENT && "dataItems".equals(parser.getLocalName())) {
                    skipImages();
                } else if (event == XMLStreamConstants.CHARACTERS && readText) {
                    buffer = parser.getText();
                } else if (event == XMLStreamConstants.START_ELEMENT && "childs".equals(parser.getLocalName())) {
                    skipChildren();
                } else if (event == XMLStreamConstants.END_ELEMENT && ("structure".equals(parser.getLocalName()))) {
                    // We have reached the end of the product.
                    readStatus.isValid = false;
                    readStatus.hasSection = false;
                    break;
                }
            }
            return entity;
        } catch (PipelineRuntimeException e) {
            throw new CatalogIntegrationException(e);
        }
    }

    public final Entity readUpdate() throws XMLStreamException, CatalogIntegrationException {
        readUpdate = true;
        return readCommit();
    }

    public final Entity readInsert() throws XMLStreamException, CatalogIntegrationException {
        readUpdate = false;
        return readCommit();
    }

    /*
     * This method reads the base content of the catalog. The base content is
     * considered all the child element different from <attrs/>, <colls/>,
     * <dataItems/> and <childs/>. At the current moment these are the elements
     * <createdBy/>, <createdTS/>, <lastChangedBy/>, <lastChangedTS/>,
     * <sortOrder/>, <pid/>, <id/>, <compId/>, <version/>, <entityName/> and
     * <type/>. Only the elements that are needed are read. The others are
     * ignored.
     */
    private Entity readCommit() throws XMLStreamException, CatalogIntegrationException {
        try {
            readText = false;
            // TODO remove the creation of an Entity instance, when no update is
            // present.
            Entity entity = new Entity();
            while (parser.hasNext()) {
                int event = parser.next();
                if (event == XMLStreamConstants.START_ELEMENT && "id".equals(parser.getLocalName())) {
                    // The PIM id field is only read, if the application
                    // properties
                    // contains a mapping.
                    if (!readingColl && (readStatus.hasSection || readStatus.hasCatalog)) {
                        String id = CustomStagesHelper.getKeyValue(PROP_PIM_CATEGORY_ID);
                        readText = (id != null);
                    } else if (!readingColl && readStatus.hasProduct) {
                        String id = CustomStagesHelper.getKeyValue(PROP_PIM_PRODUCT_ID);
                        readText = (id != null);
                    } else if (!readingColl && readStatus.hasItem) {
                        String id = CustomStagesHelper.getKeyValue(PROP_PIM_ITEM_ID);
                        readText = (id != null);
                    }
                } else if (event == XMLStreamConstants.END_ELEMENT && readText && "id".equals(parser.getLocalName())) {
                    // by including readText in the above criteria, then the id
                    // field is only read if it is mapped to an e-Sales BO
                    // attribute.
                    readText = false;
                    if (!readingColl && (readStatus.hasSection || readStatus.hasCatalog)) {
                        String id = CustomStagesHelper.getKeyValue(PROP_PIM_CATEGORY_ID);
                        if (readUpdate && "CategoryID".equals(id)) {
                            entity.setKey(buffer);
                        } else {
                            entity.addAttribute(id, buffer);
                            // Also set the visibility of the category
                            entity.addAttribute("IsVisible", "Y");
                            entity.addAttribute("CategoryTypeID", "Normal");
                        }
                        // The ParentCategoryID is not an existing attribute in
                        // PIM, but deducted from the Catalog/Section structure.
                        // As
                        // Catalog/Sections are always read in 'pre-order
                        // traversal'
                        // when parsing, then ParentCategoryID's can be
                        // maintained
                        // in a stack.
                        if (readStatus.hasSection) {
                            entity.addAttribute("ParentCategoryID", (String) parentIDStack.getLast());
                        } else {
                            catalogID = buffer;
                            // Set the ParentCategoryID explicitly to NULL
                            entity.addAttribute("ParentCategoryID", null);
                        }
                        parentIDStack.addLast(buffer);
                    } else if (!readingColl && (readStatus.hasProduct)) {
                        // A product can belong to one of several
                        // catalogs/category
                        // trees. The status 'ADDED' in one catalog does
                        // therefore
                        // not necessarily mean that the product is added in the
                        // database, but that it is added to the current
                        // catalog/category. A product is therefore always tried
                        // updated, because an update will fall through to an
                        // insert
                        // if not the product is existing in the database.
                        productID = buffer;
                        // TODO should key value be mapped?
                        entity.setKey(buffer);

                        // Connecting the product to the parent Category is on
                        // the other hand a 'unique operation'. If added to the
                        // parent PIM Catalog/section then the product must be
                        // added to the parent e-Sales category. If the product
                        // is on the other hand 'UPDATED' then we do not know,
                        // if it has moved location in the catalog or some
                        // product attributes have been updated. We therefore
                        // create a subset update.
                        Subset catSubset = new Subset("Category");
                        if (readUpdate) {
                            catSubset.setKey((String) parentIDStack.getLast());
                        } else {
                            catSubset.addAttribute("CategoryID", (String) parentIDStack.getLast());
                        }
                        entity.addChildSet(catSubset);

                        // The <product> element has an PCM_Main attribute. If
                        // this
                        // has the value of '1', then isMain=true. This means
                        // that
                        // the product is the main product with in the catelog,
                        // and
                        // that a path to the product should be shown using the
                        // parent section/category.
                        if (isMain) {
                            entity.addAttribute("MainCategoryID", (String) parentIDStack.getLast());
                        }
                    } else if (!readingColl && (readStatus.hasItem)) {
                        String id = CustomStagesHelper.getKeyValue(PROP_PIM_ITEM_ID);
                        if (id != null) {
                            entity.addAttribute(id, buffer);
                        }
                    } else if (!readingColl && (readStatus.hasProduct)) {
                        // A product can belong to one of several
                        // catalogs/category
                        // trees. The status 'ADDED' in one catalog does
                        // therefore
                        // not necessarily mean that the product is added in the
                        // database, but that it is added to the current
                        // catalog/category. A product is therefore always tried
                        // updated, because an update will fall through to an
                        // insert
                        // if not the product is existing in the database.
                        productID = buffer;
                        // TODO should key value be mapped?
                        entity.setKey(buffer);

                        // Connecting the product to the parent Category is on
                        // the other hand a 'unique operation'. If added to the
                        // parent PIM Catalog/section then the product must be
                        // added to the parent e-Sales category. If the product
                        // is on the other hand 'UPDATED' then we do not know,
                        // if it has moved location in the catalog or some
                        // product attributes have been updated. We therefore
                        // create a subset update.
                        Subset catSubset = new Subset("Category");
                        if (readUpdate) {
                            catSubset.setKey((String) parentIDStack.getLast());
                        } else {
                            catSubset.addAttribute("CategoryID", (String) parentIDStack.getLast());
                        }
                        entity.addChildSet(catSubset);

                        // The <product> element has an PCM_Main attribute. If
                        // this
                        // has the value of '1', then isMain=true. This means
                        // that
                        // the product is the main product with in the catelog,
                        // and
                        // that a path to the product should be shown using the
                        // parent section/category.
                        if (isMain) {
                            entity.addAttribute("MainCategoryID", (String) parentIDStack.getLast());
                        }
                    } else if (!readingColl && (readStatus.hasItem)) {
                        String id = CustomStagesHelper.getKeyValue(PROP_PIM_ITEM_ID);
                        if (id != null) {
                            entity.addAttribute(id, buffer);
                        }
                    }
                } else if (event == XMLStreamConstants.CHARACTERS && readText) {
                    buffer = parser.getText();
                } else if (event == XMLStreamConstants.START_ELEMENT && "colls".equals(parser.getLocalName())) {
                    readColls(entity);
                } else if (event == XMLStreamConstants.START_ELEMENT && "attrs".equals(parser.getLocalName())) {
                    readAttrs(entity);
                } else if (event == XMLStreamConstants.START_ELEMENT && "relatedItems".equals(parser.getLocalName())) {
                    // We have reached the related products section, which means
                    // that the product content have been read.
                    readStatus.isValid = false;
                    readStatus.hasProduct = false;
                    break;
                } else if (event == XMLStreamConstants.START_ELEMENT && "dataItems".equals(parser.getLocalName())) {
                    // We have reached one of the images. As these have their
                    // own
                    // status element, we are forced to read updates separately.
                    readStatus.isValid = false;
                    readStatus.hasCatalog = false;
                    readStatus.hasSection = false;
                    readStatus.hasProduct = false;
                    readStatus.hasItem = false;
                    break;
                } else if (event == XMLStreamConstants.START_ELEMENT && "childs".equals(parser.getLocalName())) {
                    // We have reached one of the element childs which means
                    // that the catalog content have been read
                    readStatus.isValid = false;
                    readStatus.hasCatalog = false;
                    readStatus.hasSection = false;
                    readStatus.hasProduct = false;
                    readStatus.hasItem = false;
                    break;
                } else if (event == XMLStreamConstants.END_ELEMENT && "structure".equals(parser.getLocalName())) {
                    // We have reached the end of the section. Set the status
                    readStatus.isValid = false;
                    readStatus.hasSection = false;
                    parentIDStack.removeLast();
                    break;
                } else if (event == XMLStreamConstants.END_ELEMENT && "article".equals(parser.getLocalName())) {
                    // We have reached the end of the article. Set the status
                    readStatus.isValid = false;
                    readStatus.hasItem = false;
                    break;
                } else if (event == XMLStreamConstants.END_ELEMENT && "product".equals(parser.getLocalName())) {
                    // We have reached the end of the product. Set the status
                    readStatus.isValid = false;
                    readStatus.hasProduct = false;
                    productID = null;
                    break;
                } else if (event == XMLStreamConstants.END_ELEMENT && "catalog".equals(parser.getLocalName())) {
                    // We have reached the end of the catalog.
                    parentIDStack.removeLast();
                    break;
                } else if (event == XMLStreamConstants.START_ELEMENT) {
                    if (!readingColls) {
                        if (readStatus.hasCatalog || readStatus.hasSection) {
                            attrName = CustomStagesHelper.getKeyValue("PIM.Category." + parser.getLocalName());
                        } else if (readStatus.hasProduct) {
                            attrName = CustomStagesHelper.getKeyValue("PIM.Product." + parser.getLocalName());
                        } else if (readStatus.hasItem) {
                            attrName = CustomStagesHelper.getKeyValue("PIM.Item." + parser.getLocalName());
                        }

                        if (attrName != null) {
                            readText = true;
                        }
                    }
                } else if (event == XMLStreamConstants.END_ELEMENT && readText) {
                    // readText is only true, if a mapping exists from the PIM
                    // element to an e-Sales attribute
                    entity.addAttribute(attrName, buffer);
                    readText = false;
                }
            }
            return entity;
        } catch (PipelineRuntimeException e) {
            throw new CatalogIntegrationException(e);
        }
    }

    public final Entity readImageUpdate(String elementType) throws XMLStreamException, CatalogIntegrationException,
            CatalogImageException {
        Entity entity = new Entity();

        try {
            if (elementType.equalsIgnoreCase(ConstantsForSales.PCM_CATALOG)
                    || elementType.equalsIgnoreCase(ConstantsForSales.PCM_STRUCTURE)) {
                entity.setKey((String) parentIDStack.getLast());
            } else if (elementType.equalsIgnoreCase(ConstantsForSales.PCM_PRODUCT)) {
                entity.setKey(productID);
            } else if (elementType.equalsIgnoreCase(ConstantsForSales.PCM_ARTICLE)) {
                entity.setKey(itemID);
            }
        } catch (Exception ex) {
            LOG.error("Error occurs while calling readImageUpdate() : ", ex);
            // throw new CatalogIntegrationException(ex);
        }

        /*
         * if (itemID != null) { entity.setKey(itemID); } else if (productID !=
         * null) { entity.setKey(productID); } else { entity.setKey((String)
         * parentIDStack.getLast()); }
         */

        readImageUpdate(entity);

        return entity;
    }

    public final void readImageUpdate(final Entity entity) throws XMLStreamException, CatalogIntegrationException,
            CatalogImageException {

        // readingAttrs is only set when reading <attrs> and </attrs>.
        // Will this improve performance ? (less assignments to
        // readingAttrs than to an equivalent readingAttr parameter, but
        // yet another string comparison "attrs.equals(...)")
        while (parser.hasNext()) {
            int event = parser.next();
            if (event == XMLStreamConstants.CHARACTERS && readText) {
                buffer = parser.getText();
            } else if (event == XMLStreamConstants.END_ELEMENT && "item".equals(parser.getLocalName())) {
                readStatus.isValid = false;
                readStatus.hasImage = false;
                break;
            } else if (event == XMLStreamConstants.START_ELEMENT && readingRes
                    && "entityName".equals(parser.getLocalName())) {
                readText = true;
            } else if (event == XMLStreamConstants.END_ELEMENT && readingRes
                    && "entityName".equals(parser.getLocalName())) {
                entityName = buffer;
                readText = false;
            } else if (event == XMLStreamConstants.START_ELEMENT && "res".equals(parser.getLocalName())) {
                readingRes = true;
            } else if (event == XMLStreamConstants.END_ELEMENT && "res".equals(parser.getLocalName())) {
                if ("MDS_ImagePart".equals(entityName)) {
                    if ("eSalesThumbnail".equals(imageType)) {
                        String imagePath = url.replaceFirst(imageCatalogPrefix, "");
                        imageHandler.copyImage(imagePath);
                        entity.addAttribute("ImageThumb", imagePath);
                    } else if ("eSalesPreview".equals(imageType)) {
                        String imagePath = url.replaceFirst(imageCatalogPrefix, "");
                        imageHandler.copyImage(imagePath);
                        entity.addAttribute("ImagePreview", imagePath);
                    } else if ("eSalesMaster".equals(imageType)) {
                        String imagePath = url.replaceFirst(imageCatalogPrefix, "");
                        imageHandler.copyImage(imagePath);
                        entity.addAttribute("ImageMaster", imagePath);
                    }
                }
                readingRes = false;
            } else if (event == XMLStreamConstants.START_ELEMENT && "attrs".equals(parser.getLocalName())) {
                readAttrs(entity);
            } else if (event == XMLStreamConstants.START_ELEMENT && "url".equals(parser.getLocalName())) {
                if (readingRes) {
                    readText = true;
                }
            } else if (event == XMLStreamConstants.END_ELEMENT && "url".equals(parser.getLocalName())) {
                if (readingRes) {
                    readText = false;
                    url = buffer;
                }
            }
        }
    }

    public final Entity readImageDisconnect(String elementType) throws XMLStreamException, CatalogIntegrationException {
        Entity entity = new Entity();

        try {
            if (elementType.equalsIgnoreCase(ConstantsForSales.PCM_CATALOG)
                    || elementType.equalsIgnoreCase(ConstantsForSales.PCM_STRUCTURE)) {
                entity.setKey((String) parentIDStack.getLast());
            } else if (elementType.equalsIgnoreCase(ConstantsForSales.PCM_PRODUCT)) {
                entity.setKey(productID);
            } else if (elementType.equalsIgnoreCase(ConstantsForSales.PCM_ARTICLE)) {
                entity.setKey(itemID);
            }
        } catch (Exception ex) {
            LOG.error("Error occurs while calling readImageDisconnect() : ", ex);
            // throw new CatalogIntegrationException(ex);
        }

        /*
         * if (itemID != null) { entity.setKey(itemID); } else if (productID !=
         * null) { entity.setKey(productID); } else { entity.setKey((String)
         * parentIDStack.getLast()); }
         */

        readImageDisconnect(entity);

        return entity;
    }

    public final void readImageDisconnect(final Entity entity) throws XMLStreamException, CatalogIntegrationException {
        readImageRemove(entity, false);
    }

    public final Entity readImageDelete(String elementType) throws XMLStreamException, CatalogIntegrationException {
        Entity entity = new Entity();

        try {
            if (elementType.equalsIgnoreCase(ConstantsForSales.PCM_CATALOG)
                    || elementType.equalsIgnoreCase(ConstantsForSales.PCM_STRUCTURE)) {
                entity.setKey((String) parentIDStack.getLast());
            } else if (elementType.equalsIgnoreCase(ConstantsForSales.PCM_PRODUCT)) {
                entity.setKey(productID);
            } else if (elementType.equalsIgnoreCase(ConstantsForSales.PCM_ARTICLE)) {
                entity.setKey(itemID);
            }
        } catch (Exception ex) {
            LOG.error("Error occurs while calling readImageDelete() : ", ex);
            // throw new CatalogIntegrationException(ex);
        }

        /*
         * if (itemID != null) { entity.setKey(itemID); } else if (productID !=
         * null) { entity.setKey(productID); } else { entity.setKey((String)
         * parentIDStack.getLast()); }
         */

        readImageDelete(entity);

        return entity;
    }

    public final void readImageDelete(final Entity entity) throws XMLStreamException, CatalogIntegrationException {
        readImageRemove(entity, true);
    }

    private void readImageRemove(final Entity entity, boolean delete) throws XMLStreamException,
            CatalogIntegrationException {

        // readingAttrs is only set when reading <attrs> and </attrs>.
        // Will this improve performance ? (less assignments to
        // readingAttrs than to an equivalent readingAttr parameter, but
        // yet another string comparison "attrs.equals(...)")
        readingAttrs = true;
        while (parser.hasNext()) {
            int event = parser.next();
            if (event == XMLStreamConstants.CHARACTERS && readText) {
                buffer = parser.getText();
            } else if (event == XMLStreamConstants.END_ELEMENT && "item".equals(parser.getLocalName())) {
                readStatus.isValid = false;
                readStatus.hasImage = false;
                break;
            } else if (event == XMLStreamConstants.START_ELEMENT && "res".equals(parser.getLocalName())) {
                readingRes = true;
            } else if (event == XMLStreamConstants.END_ELEMENT && "res".equals(parser.getLocalName())) {
                if ("MDS_ImagePart".equals(entityName)) {
                    if ("eSalesThumbnail".equals(imageType)) {
                        if (delete) {
                            imageHandler.deleteImage(url.replaceFirst(imageCatalogPrefix, ""));
                        }
                        entity.addAttribute("ImageThumb", null);
                    } else if ("eSalesPreview".equals(imageType)) {
                        if (delete) {
                            imageHandler.deleteImage(url.replaceFirst(imageCatalogPrefix, ""));
                        }
                        entity.addAttribute("ImagePreview", null);
                    } else if ("eSalesMaster".equals(imageType)) {
                        if (delete) {
                            imageHandler.deleteImage(url.replaceFirst(imageCatalogPrefix, ""));
                        }
                        entity.addAttribute("ImageMaster", null);
                    }
                }
                readingRes = false;
            } else if (event == XMLStreamConstants.START_ELEMENT && readingRes
                    && "entityName".equals(parser.getLocalName())) {
                readText = true;
            } else if (event == XMLStreamConstants.END_ELEMENT && readingRes
                    && "entityName".equals(parser.getLocalName())) {
                entityName = buffer;
                readText = false;
            } else if (event == XMLStreamConstants.START_ELEMENT && "attrs".equals(parser.getLocalName())) {
                readAttrs(entity);
            } else if (event == XMLStreamConstants.START_ELEMENT && "url".equals(parser.getLocalName())) {
                if (readingRes) {
                    readText = true;
                }
            } else if (event == XMLStreamConstants.END_ELEMENT && "url".equals(parser.getLocalName())) {
                if (readingRes) {
                    readText = false;
                    url = buffer;
                }
            }

        }
    }

    private void readColls(final Entity entity) throws XMLStreamException, PipelineRuntimeException,
            CatalogIntegrationException {
        // Set the boolean.... this is used to avoid reading the
        // //colls/entityName element.
        readingColls = true;
        while (parser.hasNext()) {
            int event = parser.next();
            if (event == XMLStreamConstants.CHARACTERS && readText) {
                buffer = parser.getText();
            } else if (event == XMLStreamConstants.END_ELEMENT && "colls".equals(parser.getLocalName())) {
                readingColls = false;
                break;
            } else if (event == XMLStreamConstants.START_ELEMENT && "coll".equals(parser.getLocalName())) {
                // These are the language specific attributes, that must be
                // added to the Category 'Text' subset.
                language = null;
                collsName = null;
                collsValue = null;
                name = null;
                value = null;
                readingColl = true;
            } else if (event == XMLStreamConstants.END_ELEMENT && "coll".equals(parser.getLocalName())) {
                if (language != null && collsName != null) {
                    Subset subset = entity.findChildTextSubSet(language);

                    if (subset == null) {
                        subset = new Subset("Text");
                        subset.setKey(language);
                        entity.addChildTextSubSet(language, subset);
                    }
                    subset.addAttribute(collsName, collsValue);
                }
                readingColl = false;

            } else if (event == XMLStreamConstants.START_ELEMENT && "attrs".equals(parser.getLocalName())) {
                readAttrs(entity);
            }
        }
    }

    private void readAttrs(final Entity entity) throws XMLStreamException, CatalogIntegrationException {
        try {
            // readingAttrs is only set when reading <attrs> and </attrs>.
            // Will this improve performance ? (less assignments to
            // readingAttrs than to an equivalent readingAttr parameter, but
            // yet another string comparison "attrs.equals(...)")
            readingAttrs = true;
            while (parser.hasNext()) {
                int event = parser.next();
                if (event == XMLStreamConstants.CHARACTERS && readText) {
                    buffer = parser.getText();
                } else if (event == XMLStreamConstants.START_ELEMENT && "attr".equals(parser.getLocalName())) {
                    name = null;
                    value = null;
                } else if (event == XMLStreamConstants.START_ELEMENT && "name".equals(parser.getLocalName())) {
                    // These are the language specific attributes, that must be
                    // added to the Category 'Text' subset.
                    if (readingAttrs) {
                        readText = true;
                    }
                } else if (event == XMLStreamConstants.END_ELEMENT && "name".equals(parser.getLocalName())) {
                    // These are the language specific attributes, that must be
                    // added to the Category 'Text' subset.
                    if (readingAttrs) {
                        name = buffer;
                        readText = false;
                    }
                } else if (event == XMLStreamConstants.START_ELEMENT && "value".equals(parser.getLocalName())) {
                    // These are the language specific attributes, that must be
                    // added to the Category 'Text' subset.
                    if (readingAttrs) {
                        readText = true;
                    }
                } else if (event == XMLStreamConstants.END_ELEMENT && "value".equals(parser.getLocalName())) {
                    // These are the language specific attributes, that must be
                    // added to the Category 'Text' subset.
                    if (readingAttrs) {
                        value = buffer;
                        readText = false;
                    }
                } else if (event == XMLStreamConstants.END_ELEMENT && "attrs".equals(parser.getLocalName())) {
                    // readingAttrs is only set on <attrs> and </attrs>
                    readingAttrs = false;
                    break;
                } else if (event == XMLStreamConstants.END_ELEMENT && "attr".equals(parser.getLocalName())) {
                    // These are the language specific attributes, that must be
                    // added to the Category 'Text' subset.
                    if (readingColl) {
                        if ("ICP_Lang".equals(name)) {
                            language = value;
                        } else {
                            if (readStatus.hasCatalog || readStatus.hasSection) {
                                // TODO reimplement this to avoid string +
                                collsName = CustomStagesHelper.getKeyValue("PIM.Category.Text." + name);
                                if (readStatus.hasCatalog && "MDS_Name".equals(name)) {
                                    catalogName = value;
                                }
                            } else if (readStatus.hasProduct) {
                                collsName = CustomStagesHelper.getKeyValue("PIM.Product.Text." + name);
                            } else if (readStatus.hasItem) {
                                collsName = CustomStagesHelper.getKeyValue("PIM.Item.Text." + name);
                            }
                            collsValue = value;
                        }
                    } else if (readingRes) {
                        if ("MDS_ImageType".equals(name)) {
                            imageType = value;
                        }
                    } else if (readStatus.hasProduct) {
                        String esaAttr = CustomStagesHelper.getKeyValue("PIM.Product." + name);
                        if (esaAttr != null) {
                            entity.addAttribute(esaAttr, value);
                        }
                    } else if (readStatus.hasItem) {
                        // An article/item can belong to one of several
                        // catalogs/category trees. The status 'ADDED' in one
                        // catalog does therefore not necessarily mean that the
                        // article/item is added in the ESA database, but that
                        // it is added to the current catalog/category. An
                        // article/item is therefore always tried updated,
                        // because an update will fall through to an insert
                        // if not existing in the database.
                        if ("MVX_ITNO".equals(name)) {
                            // TODO should MVX_ITNO be mapped? - yes
                            entity.setKey(value);

                            // Connecting the item/article to the parent
                            // Category/Product is on the other hand a 'unique
                            // operation'. If added to the parent PIM
                            // Catalog/Section/Product then the product must
                            // be added to the parent e-Sales Category/Product.
                            // If the item/article is on the other hand
                            // 'UPDATED' then we do not know, if it has moved
                            // location in the catalog or some item/article
                            // attributes have been updated. We therefore create
                            // a subset update.
                            if (productID == null) {
                                Subset catSubset = new Subset("Category");
                                if (readUpdate) {
                                    catSubset.setKey((String) parentIDStack.getLast());
                                } else {
                                    // TODO fetch attribute id from
                                    // application.properties
                                    catSubset.addAttribute("CategoryID", (String) parentIDStack.getLast());
                                }
                                entity.addChildSet(catSubset);
                            } else {
                                Subset prodSubset = new Subset("Product");
                                if (readUpdate) {
                                    prodSubset.setKey(productID);
                                } else {
                                    // TODO fetch attribute id from
                                    // application.properties
                                    prodSubset.addAttribute("ProductID", productID);
                                }
                                entity.addChildSet(prodSubset);
                            }

                            // The <article> element has an PCM_Main attribute.
                            // If
                            // this has the value of '1', then isMain=true. This
                            // means that the article/item is the main article
                            // within the catalog, and that a path to the
                            // article/item should be shown using the parent
                            // section(/category)/product.
                            if (isMain) {
                                if (productID != null) {
                                    entity.addAttribute("MainProductID", productID);
                                } else {
                                    entity.addAttribute("MainCategoryID", (String) parentIDStack.getLast());
                                }
                            }
                        } else {
                            String esaAttr = CustomStagesHelper.getKeyValue("PIM.Item." + name);
                            if (esaAttr != null) {
                                entity.addAttribute(esaAttr, value);
                            }
                        }
                    } else if (readStatus.hasCatalog || readStatus.hasSection) {
                        String esaAttr = CustomStagesHelper.getKeyValue("PIM.Category." + name);
                        if (esaAttr != null) {
                            entity.addAttribute(esaAttr, value);
                        }
                    }
                }
            }
        } catch (PipelineRuntimeException e) {
            throw new CatalogIntegrationException(e);
        }
    }

    private void skipColls() throws XMLStreamException, PipelineRuntimeException {
        // readingAttrs is only set when reading <attrs> and </attrs>.
        // Will this improve performance ? (less assignments to
        // readingAttrs than to an equivalent readingAttr parameter, but
        // yet another string comparison "attrs.equals(...)")
        readingColls = true;
        while (parser.hasNext()) {
            int event = parser.next();
            if (event == XMLStreamConstants.CHARACTERS && readText) {
                buffer = parser.getText();
            } else if (event == XMLStreamConstants.END_ELEMENT && "colls".equals(parser.getLocalName())) {
                // readingAttrs is only set on <attrs> and </attrs>
                readingColls = false;
                break;
            } else if (event == XMLStreamConstants.START_ELEMENT && "attrs".equals(parser.getLocalName())) {
                // readingAttrs is only set on <attrs> and </attrs>
                readingAttrs = true;
            } else if (event == XMLStreamConstants.END_ELEMENT && "attrs".equals(parser.getLocalName())) {
                // readingAttrs is only set on <attrs> and </attrs>
                readingAttrs = false;
            } else if (event == XMLStreamConstants.START_ELEMENT && "attr".equals(parser.getLocalName())) {
                name = null;
                value = null;
            } else if (event == XMLStreamConstants.END_ELEMENT && "attr".equals(parser.getLocalName())) {
                // These are the language specific attributes
                if (readStatus.hasCatalog && "MDS_Name".equals(name)) {
                    // ID has been set already, just add the
                    // catalog name.
                    catalogName = value;
                }
            } else if (event == XMLStreamConstants.START_ELEMENT && "name".equals(parser.getLocalName())) {
                if (readingAttrs) {
                    readText = true;
                }
            } else if (event == XMLStreamConstants.END_ELEMENT && "name".equals(parser.getLocalName())) {
                if (readingAttrs) {
                    name = buffer;
                    readText = false;
                }
            } else if (event == XMLStreamConstants.START_ELEMENT && "value".equals(parser.getLocalName())) {
                if (readingAttrs) {
                    readText = true;
                }
            } else if (event == XMLStreamConstants.END_ELEMENT && "value".equals(parser.getLocalName())) {
                if (readingAttrs) {
                    value = buffer;
                    readText = false;
                }
            }
        }
    }

    private void skipImages() throws XMLStreamException {
        while (parser.hasNext()) {
            int event = parser.next();
            if (event == XMLStreamConstants.END_ELEMENT && "dataItems".equals(parser.getLocalName())) {
                break;
            }
        }
    }

    public final void skipImage() throws XMLStreamException {
        while (parser.hasNext()) {
            int event = parser.next();
            if (event == XMLStreamConstants.END_ELEMENT && "item".equals(parser.getLocalName())) {
                readStatus.isValid = false;
                readStatus.hasImage = false;
                break;
            }
        }
    }

    /**
     * This method reads a product relation update. It is a requirement when
     * calling the method, that the StaX reader is positioned at a
     * &lt;product&gt; element being descendant of an &lt;accessories&gt;,
     * &lt;replacements&gt;, &lt;upsales&gt; or &lt;crossales&gt; element. Only
     * the &lt;id&gt; child element id read. The others are ignored.
     * 
     * @throws CatalogIntegrationException
     */
    public final Entity readProductRelationUpdate() throws XMLStreamException, CatalogIntegrationException {
        try {
            Entity entity = null;
            while (parser.hasNext()) {
                int event = parser.next();
                if (event == XMLStreamConstants.START_ELEMENT && "id".equals(parser.getLocalName())) {
                    String id = CustomStagesHelper.getKeyValue(PROP_PIM_PRODUCT_ID);
                    readText = (id != null);
                } else if (event == XMLStreamConstants.END_ELEMENT && readText && "id".equals(parser.getLocalName())) {
                    // by including readText in the above criteria, then the id
                    // field is only read if it is mapped to an e-Sales BO
                    // attribute.
                    entity = new Entity();
                    entity.addAttribute("ProductID", productID);
                    entity.addAttribute("RelatedProductID", buffer);
                    entity.addAttribute("RelationTypeID", productRelationTypeID);

                    // building primary key field
                    workingBuffer.clear();
                    workingBuffer.append(productID);
                    workingBuffer.append("#");
                    workingBuffer.append(buffer);
                    workingBuffer.append("#");
                    workingBuffer.append(productRelationTypeID);
                    entity.setKey(workingBuffer.toString());

                    readText = false;
                } else if (event == XMLStreamConstants.CHARACTERS && readText) {
                    buffer = parser.getText();
                } else if (event == XMLStreamConstants.END_ELEMENT && "product".equals(parser.getLocalName())) {
                    // We have reached the end of a product relation.
                    readStatus.isValid = false;
                    readStatus.hasProductRelation = false;
                    break;
                }
            }
            return entity;
        } catch (PipelineRuntimeException e) {
            throw new CatalogIntegrationException(e);
        }
    }

    /**
     * This method reads a product relation delete. It is a requirement when
     * calling the method, that the StaX reader is positioned at a
     * &lt;product&gt; element being descendant of an &lt;accessories&gt;,
     * &lt;replacements&gt;, &lt;upsales&gt; or &lt;crossales&gt; element. Only
     * the &lt;id&gt; child element id read. The others are ignored.
     * 
     * @throws CatalogIntegrationException
     */
    public final DeleteSet readProductRelationDelete() throws XMLStreamException, CatalogIntegrationException {
        try {
            readText = false;
            DeleteSet delete = null;
            while (parser.hasNext()) {
                int event = parser.next();
                if (event == XMLStreamConstants.START_ELEMENT && "id".equals(parser.getLocalName())) {
                    String id = CustomStagesHelper.getKeyValue(PROP_PIM_PRODUCT_ID);
                    readText = (id != null);
                } else if (event == XMLStreamConstants.END_ELEMENT && readText && "id".equals(parser.getLocalName())) {
                    // building primary key field
                    workingBuffer.clear();
                    workingBuffer.append(productID);
                    workingBuffer.append("#");
                    workingBuffer.append(buffer);
                    workingBuffer.append("#");
                    workingBuffer.append(productRelationTypeID);
                    delete = new DeleteSet(workingBuffer.toString());

                    readText = false;
                } else if (event == XMLStreamConstants.CHARACTERS && readText) {
                    buffer = parser.getText();
                } else if (event == XMLStreamConstants.END_ELEMENT && "product".equals(parser.getLocalName())) {
                    // We have reached the end of a product relation.
                    readStatus.isValid = false;
                    readStatus.hasProductRelation = false;
                    break;
                }
            }
            return delete;
        } catch (PipelineRuntimeException e) {
            throw new CatalogIntegrationException(e);
        }

    }

    /**
     * This method reads a product relation insert. It is a requirement when
     * calling the method, that the StaX reader is positioned at a
     * &lt;product&gt; element being descendant of an &lt;accessories&gt;,
     * &lt;replacements&gt;, &lt;upsales&gt; or &lt;crossales&gt; element. Only
     * the &lt;id&gt; child element id read. The others are ignored.
     */
    public final void skipProductRelation() throws XMLStreamException {
        while (parser.hasNext()) {
            int event = parser.next();
            if (event == XMLStreamConstants.END_ELEMENT && "product".equals(parser.getLocalName())) {
                // We have reached the end of a product relation.
                readStatus.isValid = false;
                readStatus.hasProductRelation = false;
                break;
            }
        }
    }

    public final boolean hasChildSections() throws CatalogParserException, XMLStreamException {
        short level = sectionLevel;
        if (!hasSection()) {
            return false;
        }
        // The next section has been reached. It is a child section if the
        // section level has been increased.
        return level != sectionLevel;
    }

    public final boolean hasSection() throws CatalogParserException, XMLStreamException {
        if (readStatus.isValid) {
            return readStatus.hasSection;
        }

        readNext();

        return readStatus.hasSection;
    }

    public final short readSectionStatus() throws CatalogParserException, XMLStreamException {
        if (!hasSection()) {
            throw new CatalogParserException("Wrong position of reader. 'structure' element not available.");
        }

        return status;
    }

    public final boolean hasProduct() throws CatalogParserException, XMLStreamException {
        if (readStatus.isValid) {
            return readStatus.hasProduct;
        }

        readNext();

        return readStatus.hasProduct;
    }

    public final short readProductStatus() throws CatalogParserException, XMLStreamException {
        if (!hasProduct()) {
            throw new CatalogParserException("Wrong position of reader. 'product' element not available.");
        }

        return status;
    }

    public final boolean hasProductRelation() throws CatalogParserException, XMLStreamException {
        if (readStatus.isValid) {
            return readStatus.hasProductRelation;
        }

        readNext();

        return readStatus.hasProductRelation;
    }

    public final short readProductRelationStatus() throws CatalogParserException, XMLStreamException {
        if (!hasProductRelation()) {
            throw new CatalogParserException("Wrong position of reader. 'product' element not available.");
        }

        return status;
    }

    public final boolean hasItem() throws CatalogParserException, XMLStreamException {
        if (readStatus.isValid) {
            return readStatus.hasItem;
        }

        readNext();

        return readStatus.hasItem;
    }

    public final short readItemStatus() throws CatalogParserException, XMLStreamException {
        if (!hasItem()) {
            throw new CatalogParserException("Wrong position of reader. 'article' element not available.");
        }

        return status;
    }

    public final boolean hasImage() throws CatalogParserException, XMLStreamException {
        if (readStatus.isValid) {
            return readStatus.hasImage;
        }

        readNext();

        return readStatus.hasImage;
    }

    public final short readImageStatus() throws CatalogParserException, XMLStreamException {
        if (!hasImage()) {
            throw new CatalogParserException("Wrong position of reader. 'item' element not available.");
        }

        return status;
    }

    private void readNext() throws CatalogParserException, XMLStreamException {
        while (parser.hasNext()) {
            int event = parser.next();
            if (event == XMLStreamConstants.START_ELEMENT) {
                if ("structure".equals(parser.getLocalName())) {
                    status = PIMStatus.parseStatus(parser.getAttributeValue(null, "PCM_delta"));
                    readStatus.isValid = true;
                    readStatus.hasSection = true;
                    break;
                } else if ("structures".equals(parser.getLocalName())) {
                    sectionLevel++;
                } else if ("product".equals(parser.getLocalName())) {
                    isMain = "1".equals(parser.getAttributeValue(null, "PCM_Main"));
                    status = PIMStatus.parseStatus(parser.getAttributeValue(null, "PCM_delta"));
                    readStatus.isValid = true;
                    if (productRelationTypeID != null) {
                        // The <product> element is a descendant of an
                        // <accessories>, <replacements>, <upsales> or
                        // <crossales> element and therefore represents a
                        // product relation.
                        readStatus.hasProductRelation = true;
                    } else {
                        readStatus.hasProduct = true;
                    }
                    break;
                } else if ("article".equals(parser.getLocalName())) {
                    isMain = "1".equals(parser.getAttributeValue(null, "PCM_Main"));
                    status = PIMStatus.parseStatus(parser.getAttributeValue(null, "PCM_delta"));
                    readStatus.isValid = true;
                    readStatus.hasItem = true;
                    break;
                } else if ("item".equals(parser.getLocalName())) {
                    status = PIMStatus.parseStatus(parser.getAttributeValue(null, "PCM_delta"));
                    readStatus.isValid = true;
                    readStatus.hasImage = true;
                    break;
                } else if ("accessories".equals(parser.getLocalName())) {
                    // We have reached one of the element childs which means
                    // that the catalog content have been read
                    productRelationTypeID = ACCESSORIES_TYPE;
                } else if ("replacements".equals(parser.getLocalName())) {
                    // We have reached one of the element childs which means
                    // that the catalog content have been read
                    productRelationTypeID = REPLACEMENT_TYPE;
                } else if ("upsales".equals(parser.getLocalName())) {
                    // We have reached one of the element childs which means
                    // that the catalog content have been read
                    productRelationTypeID = UPSALE_TYPE;
                } else if ("crossales".equals(parser.getLocalName())) {
                    // We have reached one of the element childs which means
                    // that the catalog content have been read
                    productRelationTypeID = CROSSSALE_TYPE;
                }
            } else if (event == XMLStreamConstants.END_ELEMENT && "structure".equals(parser.getLocalName())) {
                // If we read the end </structure> element here then the
                // section had children and readStatus.isValid and
                // readStatus.hasSection has already been set to false. Just
                // pop parentIDStack
                parentIDStack.removeLast();
            } else if (event == XMLStreamConstants.END_ELEMENT && "structures".equals(parser.getLocalName())) {
                // Maintain the structure level
                sectionLevel--;
            } else if (event == XMLStreamConstants.END_ELEMENT && "product".equals(parser.getLocalName())) {
                // If we read the end </product> element here then this end
                // tag belongs to a product update/delete and not a product
                // relation, and the product had children and
                // readStatus.isValid and readStatus.hasProduct has already
                // been set to false. Just reset productID
                productID = null;
            } else if (event == XMLStreamConstants.END_ELEMENT
                    && ("structures".equals(parser.getLocalName()) || "products".equals(parser.getLocalName()) || "articles"
                            .equals(parser.getLocalName()))) {
                // We have reached a childs end tag which means that no more
                // sections/product or items exists.
                readStatus.isValid = false;
                readStatus.hasSection = false;
                readStatus.hasProduct = false;
                readStatus.hasItem = false;
            } else if (event == XMLStreamConstants.END_ELEMENT
                    && ("accessories".equals(parser.getLocalName()) || "replacements".equals(parser.getLocalName())
                            || "upsales".equals(parser.getLocalName()) || "crossales".equals(parser.getLocalName()))) {
                // We have reached an end tag for a product relation type.
                // It should only be necessary to reset the product relation
                // type id as readStatus.hasProductRelation is set when
                // reading the </product> tag.
                productRelationTypeID = null;
            }
        }
    }

    public String getItemID() {
        return this.itemID;
    }

    public String getProductID() {
        return this.productID;
    }

    public LinkedList getParentIDStack() {
        return this.parentIDStack;
    }
}
