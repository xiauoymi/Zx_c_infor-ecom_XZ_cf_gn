package com.intentia.iec.pipeline.runtime.stage.custom.search;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;

import org.apache.log4j.Logger;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;

/**
 * Abstract class that can be inherited by other classes with specific
 * connection behavior.
 */
public abstract class JdbcBase implements Jdbc {
    private static final Logger LOG = Logger.getLogger(JdbcBase.class);

    public abstract Connection getConnection() throws PipelineRuntimeException;

    public void execute(final StatementHolder holder, final Object[] params, final RowHandler rh)
            throws PipelineRuntimeException {
        ResultSet rs = null;
        try {
            for (int i = 0; i < params.length; i++) {
                holder.stmt.setObject(i + 1, params[i]);
            }

            rs = holder.stmt.executeQuery();
            while (rs.next()) {
                rh.processRow(rs);
            }
        } catch (SQLException e) {
            LOG.error("Sql statement code: " + holder.sql);
            LOG.error("Sql statement parameters: " + Arrays.toString(params));
            LOG.error("Error executing sql statement", e);
            throw new PipelineRuntimeException(e);
        } finally {
            close(rs);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc#execute(com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc.StatementHolder,
     *      java.lang.Object[],
     *      com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc.RowHandler[])
     */
    public void execute(final StatementHolder holder, final Object[] params, final RowHandler[] rh)
            throws PipelineRuntimeException {
        ResultSet rs = null;
        int j = 1;
        try {
            for (int i = 0; i < params.length; i++) {
                holder.stmt.setObject(i + 1, params[i]);
            }

            // execute first query
            j = 0;
            rs = holder.stmt.executeQuery();
            while (rs.next() == true) {
                rh[0].processRow(rs);
            }

            // if there are more queries, execute using their own RowHandlers
            j = 1;
            while (holder.stmt.getMoreResults() == true && j < rh.length) {
                rs = holder.stmt.getResultSet();
                while (rs.next() == true) {
                    rh[j].processRow(rs);
                }
                j++;
            }
        } catch (SQLException e) {
            LOG.error("Sql statement code: " + holder.sql);
            LOG.error("Sql statement parameters: " + Arrays.toString(params));
            LOG.error("Error executing sql statement", e);
            throw new PipelineRuntimeException(e);
        } finally {
            close(rs);
        }

    }

    public void close(final Connection con) {
        if (con != null) {
            try {
                con.close();
            } catch (SQLException e) {
                LOG.error("Failed closing database connection", e);
                // No re-throw.
            }
        }
    }

    public void close(final PreparedStatement[] stmts) {
        for (int i = 0; i < stmts.length; i++) {
            PreparedStatement stmt = stmts[i];
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    LOG.error("Failed closing prepared sql statement", e);
                    // No re-throw.
                }
            }
        }
    }

    public void close(final PreparedStatement stmt) {
        close(new PreparedStatement[] {stmt});
    }

    public void close(final ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                LOG.error("Failed closing result set", e);
                // No re-throw.
            }
        }
    }

    public void execute(final String sql, final Object[] params, final RowHandler rh) throws PipelineRuntimeException {
        Connection con = null;
        PreparedStatement stmt = null;
        try {
            con = getConnection();
            stmt = con.prepareStatement(sql);
            execute(new StatementHolder(con, sql), params, rh);
        } catch (SQLException e) {
            LOG.error("Problem preparing sql statement: " + sql, e);
            throw new PipelineRuntimeException();
        } finally {
            close(stmt);
            close(con);
        }
    }
}
