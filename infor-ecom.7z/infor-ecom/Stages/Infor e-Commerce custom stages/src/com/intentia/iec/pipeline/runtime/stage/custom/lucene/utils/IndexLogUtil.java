package com.intentia.iec.pipeline.runtime.stage.custom.lucene.utils;

import java.util.HashSet;
import java.util.Set;

import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.lucene.manager.IndexManagerRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.utils.DeletePipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

/**
 * 
 * @author 15062
 * 
 */
public final class IndexLogUtil {

    public static final String ADD_UPDATE_ACTION = "AddUpdate";

    public static final String DELETE_ACTION = "Delete";
    
    /**
     * 
     * @param indexName
     * @param action
     * @return
     * @throws IndexManagerRuntimeException
     */
    public static XMLResultset getLogs(final String indexName, final String action) throws PipelineRuntimeException {
        return getLogs(indexName, action, -1, -1);
    }

    /**
     * 
     * @param indexName
     * @param action
     * @param offset
     * @param limit
     * @return
     * @throws IndexManagerRuntimeException
     */
    public static XMLResultset getLogs(final String indexName, final String action, final int offset, final int limit) throws PipelineRuntimeException {
        XMLResultset result = null;
        
        try {
            SearchPipelineExecuter pipeline = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                    "LuceneIndexLog", "GetLogs");
            pipeline.setBinding(ConstantsForSales.INDEX_NAME_ATTRIBUTE, indexName, "eq");
            if (action != null) // if null means all type of actions
                pipeline.setBinding(ConstantsForSales.ACTION_ATTRIBUTE, action, "eq");
            //Set batch limit
            pipeline.setPaging(offset, limit);                        
            
            result = pipeline.execute();

        } catch (PipelineRuntimeException e) {
            throw new PipelineRuntimeException("Unable to get record keys for updates", e);
        }
        return result;
    }

    /**
     * 
     * @param logKeys
     * @throws PipelineRuntimeException
     */
    public static void deleteLogsByID(final Set<String> logIDs) throws PipelineRuntimeException {
        try {
            if (logIDs != null) {
                for (String id : logIDs) {
                    DeletePipelineExecuter pipeline = new DeletePipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                            "LuceneIndexLog", "DeleteLogs");
                    pipeline.setMainKey(ConstantsForSales.LOG_ID_ATTRIBUTE, id);
                    pipeline.execute();
                }
            }
        } catch (PipelineRuntimeException e) {
            throw new PipelineRuntimeException("Unable to cleanup LuceneIndexLog table", e);
        }
    }

    /**
     * 
     * @param indexName
     * @throws PipelineRuntimeException
     */
    public static void deleteLogsByIndexName(final String indexName) throws PipelineRuntimeException {
        try {
            Set<String> logIDs = new HashSet<String>();
            // set action parameter to 'null' to get all types of logs
            // regardless of their action type
            XMLResultset logs = getLogs(indexName, null);
            if (!logs.isEmpty()) {
                logs.beforeFirst();
                while (logs.moveNext()) {
                    logIDs.add(logs.getString(ConstantsForSales.LOG_ID_ATTRIBUTE));
                }
                deleteLogsByID(logIDs);
            }
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Unable to cleanup LuceneIndexLog table", e);
        }
    }
}