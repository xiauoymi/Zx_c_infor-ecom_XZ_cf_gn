/*
 * 
 */
package com.intentia.iec.pipeline.runtime.custom.pim;

/**
 * @author PEDJES0
 * 
 */
public class CatalogParserException extends Exception {

    /**
     * 
     */
    public CatalogParserException() {
        super();
    }

    /**
     * @param arg0
     * @param arg1
     */
    public CatalogParserException(String arg0, Throwable arg1) {
        super(arg0, arg1);
    }

    /**
     * @param arg0
     */
    public CatalogParserException(String arg0) {
        super(arg0);
    }

    /**
     * @param arg0
     */
    public CatalogParserException(Throwable arg0) {
        super(arg0);
    }

}
