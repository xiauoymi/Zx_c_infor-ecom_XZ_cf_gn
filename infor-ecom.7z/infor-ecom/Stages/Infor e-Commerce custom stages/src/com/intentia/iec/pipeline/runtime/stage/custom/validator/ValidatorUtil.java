package com.intentia.iec.pipeline.runtime.stage.custom.validator;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class ValidatorUtil {
    public static final String KEY_ATTRIBUTE = "attribute";

    public static final String KEY_SUBSETNAME = "subset_name";

    public static final String KEY_TYPE = "type";

    public static final String KEY_VALIDATIONRULE = "validationrule";

    public static final String KEY_MIN = "min";

    public static final String KEY_MAX = "max";

    public static final String KEY_FORMAT = "format";

    public static final String TYPE_STRING = "string";

    public static final String TYPE_NUMBER = "numeric";

    public static final String TYPE_DATE = "date";

    /**
     * Parse the validation string and return a list of hashmap representing the
     * validation rules
     * 
     * @param s -
     *            the validation string
     * @return
     */
    public static ArrayList<Map<String, String>> parse(String s) {

        String[] ss = s.replaceAll("\\\\:", "##").split("\\[");
        ArrayList<Map<String, String>> al = new ArrayList<Map<String, String>>();
        for (String sx : ss) {
            String news = sx.replaceAll("]", "");
            String[] elems = news.split(",");
            Map<String, String> m = new HashMap<String, String>();
            for (String el : elems) {
                String[] e = el.trim().split(":");
                if (e.length == 2) {
                    m.put(e[0].replaceAll("##", ":").trim().toLowerCase(), e[1].replaceAll("##", ":").trim());
                }
            }
            if (!m.isEmpty()) {
                al.add(m);
            }
        }
        return al;
    }

    /**
     * Simple validation for a string
     * 
     * @param validationrule
     * @param value
     * @throws Exception
     */
    public static void validateString(String validationrule, String value, String max) throws Exception {
        if ("required".equals(validationrule)) {
            if (null == value || "".equals(value)) {
                throw new Exception("Required field is missing.");
            }
        }
        if ("range".equals(validationrule)) {
            if (null != value) {
                int mx = Integer.parseInt(max);
                if (value.length() > mx) {
                    throw new Exception("Value exceeds the maximum: " + max);
                }
            }
        }
        if ("limit".equals(validationrule)) {
            if (null != value && null != max) {
                if (max.toLowerCase().indexOf(value.toLowerCase()) < 0) {
                    throw new Exception("Value should be one of the following characters:" + max);
                }
            }
        }
    }

    /**
     * simple validation of a number
     * 
     * @param validationrule
     * @param value
     * @param min
     * @param max
     * @throws Exception
     */
    public static void validateNumber(String validationrule, String value, BigDecimal min, BigDecimal max)
            throws Exception {
        if (null == value || "".equals(value.trim())) {
            throw new Exception("Value is not a number.");
        }
        try {
            BigDecimal testVal = new BigDecimal(value);
            if ("range".equals(validationrule)) {
                if (min.compareTo(testVal) > 0) {
                    throw new Exception("Value is under minimum value of " + min);
                }
                if (max.compareTo(testVal) < 0) {
                    throw new Exception("Value is above maximum value of " + max);
                }
            }
        } catch (NumberFormatException e) {
            throw new Exception("Value should be numeric.");
        }
    }

    /**
     * simple validation of date
     * 
     * @param validationrule
     * @param value
     * @param format
     * @throws Exception
     */
    public static void validateDate(String validationrule, String value, String format) throws Exception {
        Date dateValue = null;
        SimpleDateFormat f = new SimpleDateFormat(format);
        if ("format".equals(validationrule) || "notpastdate".equals(validationrule)) {
            try {
                dateValue = f.parse(value);
                // f.parse(value);
            } catch (ParseException e) {
                throw new Exception(e.getMessage() + " Date format should be " + format + " ex. "
                        + f.format(new Date()));
            }
        }
        if ("notpastdate".equals(validationrule)) {
            Calendar cal = Calendar.getInstance();
            Calendar val = Calendar.getInstance();
            val.setTime(dateValue);
            if (cal.after(val)) {
                throw new Exception("The value should not be a past date. Today is: " + f.format(cal.getTime())
                        + " but the value is: " + f.format(val.getTime()));
            }
        }
    }

    /**
     * truncate the value up to max length
     * 
     * @param validationrule
     * @param value
     * @param max
     * @return
     * @throws Exception
     */
    public static String truncateRule(String validationrule, String value, String max) throws Exception {
        String ret = value;
        if ("truncate".equals(validationrule) && null != value && null != max) {
            int mx = Integer.parseInt(max);
            if (value.length() > mx) {
                ret = value.substring(0, mx);
            }
        }
        return ret;
    }

}
