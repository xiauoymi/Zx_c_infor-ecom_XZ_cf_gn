package com.intentia.iec.pipeline.runtime.stage.custom.daf.item;

public final class DafItemRelatedDocumentConstants {
	
	/**
	 * Root
	 */
	public static final String TABLE = "/ESA_RelatedDocument";
	
	/**
	 * Related Document attributes
	 *
	 */
	public interface Attribute {
		public static final String STATUS = "MDS_Status";
		
		/**
		 * References used when searching
		 *
		 */
		public interface Column {
			public static final String STATUS = "@" + Attribute.STATUS;	
		}
	}
	
	/**
	 * The Related Document contains a collection of item numbers.
	 *
	 */
	public interface Collection {
		public static final String ITEM_NUMBERS = "ESA_ItemsNumber";
		
		public static final String DOCUMENT_NAME = "ESA_RelatedDocumentName";
		
		/**
		 * Item Numbers collection attributes
		 *
		 */
		public interface ItemNumbers {
			public static final String ITEM_NUMBER = "ESA_ItemNumber";
			
			public interface Column {
				public static final String ITEM_NUMBER = "@" + ItemNumbers.ITEM_NUMBER;
			}
		}
		
		/**
		 * Document name attributes
		 *
		 */
		public interface DocumentName {
			public static final String DOCUMENT_NAME = "ESA_DocumentName";
			
			public interface Column {
				public static final String DOCUMENT_NAME = "@" + DocumentName.DOCUMENT_NAME;
			}
		}
	}
	
	/**
	 * Resource attributes. These are currently not used.
	 *
	 */
	public interface Resource {
		public interface Attribute {
			public static final String IMAGE_TYPE = "MDS_ImageType";
			
			public static final String IMAGE_WIDTH = "MDS_ImageWidth";
			
			public static final String IMAGE_HEIGHT = "MDS_ImageHeight";			
		}
	}
	
	/**
	 * Document status definitions.
	 *
	 */
	public interface Status {
		public static final short DRAFT = 5;
		
		public static final short APPROVED = 20;
		
		public static final short INVALID = 80;
	}
	
	/**
	 * Generated images. Some documents have images generated from the actual document.
	 *
	 */
	public interface ImageType {
		public static final String THUMBNAIL = "Thumbnail";
		
		public static final String PREVIEW = "Preview";
	}	
}
