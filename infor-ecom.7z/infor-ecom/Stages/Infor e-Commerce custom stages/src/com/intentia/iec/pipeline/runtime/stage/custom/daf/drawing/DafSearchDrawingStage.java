package com.intentia.iec.pipeline.runtime.stage.custom.daf.drawing;

import java.io.StringReader;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.log4j.Logger;
import org.xml.sax.InputSource;

import com.intentia.icp.common.SearchArgument;
import com.intentia.icp.common.SearchQuery;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;

/**
 * Searches for all Drawings in DAF.
 *
 */
public class DafSearchDrawingStage extends AbstractDafSearchDrawingStage {	
	 private static final Logger LOG = Logger.getLogger(DafSearchDrawingStage.class);
	 
	 private DafDrawingRequestSaxHandler handler = null;
	 
	 /**
	 * Sets the output attributes.
	 */
	public DafSearchDrawingStage() {
		 this.outDrawingNumber = true;		 
		 this.outItemNumber = true;
		 this.outName = true;
		 this.outID = true;

		 // if Equipment=enabled, output serial number
		 try {
			if ("true".equals(CustomStagesHelper.getKeyValue(DafDrawingConstants.ApplicationProperty.EQUIPMENT_PORTAL))) {
				 this.outSerialNumber = true;		 
			}
		} catch (PipelineRuntimeException e) {
			LOG.error(e);
		}
	 }

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getQuery(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public String getQuery(PipelineContext context) throws ParametersException, Exception {
		XMLRequest request = (XMLRequest) context.getRequest();
		StringBuffer buf = new StringBuffer();
		
		try {
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser parser = factory.newSAXParser();
			
			this.handler = new DafDrawingRequestSaxHandler();
	        String xml = request.getRequestString();
	        LOG.debug("Parsing request:\n" + xml);
	        parser.parse(new InputSource(new StringReader(xml)), handler);
	        
	        // search by Name, Item Number or Drawing Number
			appendQuery(buf, DafDrawingConstants.COLUMN_NAME, this.handler.getNameOp(), this.handler.getName(), false);
			appendQuery(buf, DafDrawingConstants.COLUMN_ITEM_NUMBER, this.handler.getItemNumberOp(), this.handler.getItemNumber(), false);
			appendQuery(buf, DafDrawingConstants.COLUMN_DRAWING_NUMBER, this.handler.getPrintNumberOp(), this.handler.getPrintNumber(), false);
			
			// if Equipment=enabled, add search by serial number
			if ("true".equals(CustomStagesHelper.getKeyValue(DafDrawingConstants.ApplicationProperty.EQUIPMENT_PORTAL))) {
				appendQuery(buf, DafDrawingConstants.COLUMN_SERIAL_NUMBER, this.handler.getSerialNumberOp(), this.handler.getSerialNumber(), false);	            
	        }
			
			// exclude blank Names and Item Numbers
			appendQuerySingleOperand(buf, DafDrawingConstants.COLUMN_NAME, SearchArgument.SEARCH_OP_IS_NOT_NULL);
			appendQuerySingleOperand(buf, DafDrawingConstants.COLUMN_ITEM_NUMBER, SearchArgument.SEARCH_OP_IS_NOT_NULL);
			
			// if Equipment=enabled AND Parts=disabled, show only drawings with serial numbers
			if ("true".equals(CustomStagesHelper.getKeyValue(DafDrawingConstants.ApplicationProperty.EQUIPMENT_PORTAL)) && 
				!"true".equals(CustomStagesHelper.getKeyValue(DafDrawingConstants.ApplicationProperty.SPS_ENABLED))) {
				LOG.debug("Search drawings with Serial Numbers");				
				appendQuerySingleOperand(buf, DafDrawingConstants.COLUMN_SERIAL_NUMBER, SearchArgument.SEARCH_OP_IS_NOT_NULL);
				buf.append(" " + SearchQuery.SEARCH_TYPE_AND + " " + DafDrawingConstants.COLUMN_SERIAL_NUMBER + " " + SearchArgument.SEARCH_OP_NOT_EQUAL + "\"\"");
	        }			
			
			// if Parts=enabled AND Equipment=disabled, show only drawings without serial numbers
			if (!"true".equals(CustomStagesHelper.getKeyValue(DafDrawingConstants.ApplicationProperty.EQUIPMENT_PORTAL)) && 
					"true".equals(CustomStagesHelper.getKeyValue(DafDrawingConstants.ApplicationProperty.SPS_ENABLED))) {
				LOG.debug("Search drawings withOUT Serial Numbers");
				buf.append(" " + SearchQuery.SEARCH_TYPE_AND + " (" + DafDrawingConstants.COLUMN_SERIAL_NUMBER + " " + SearchArgument.SEARCH_OP_IS_NULL);
				buf.append(" " + SearchQuery.SEARCH_TYPE_OR + " " + DafDrawingConstants.COLUMN_SERIAL_NUMBER + " " + SearchArgument.SEARCH_OP_EQUAL + "\"\"");
				buf.append(")");
			}			
		}
		catch (Exception e) {
			throw e;
		}
		
		// apply sorting if present
		String sorting = getSorting(this.handler.getSortingField(), this.handler.getSortingDirection());

		if ("".equals(buf.toString()) == true) {
			return DafDrawingConstants.TABLE + sorting;
		}
		else {
			return DafDrawingConstants.TABLE + "["+ buf.toString() + "] " + sorting;			
		}
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getResultSize()
	 */
	@Override
	public int getResultSize() {
		// the result size depends on the items per page
		if (this.handler != null) {
			return this.handler.getResultSize();
		}
		return 0;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getStartIndex()
	 */
	@Override
	public int getStartIndex() {
		// start index depends on what page of the search result is displayed
		if (this.handler != null) {
			return this.handler.getStartIndex();
		}
		return 0;
	}

	@Override
	public void setOutputParameters(PipelineContext context) {
		// intentionally blank
	}
}
