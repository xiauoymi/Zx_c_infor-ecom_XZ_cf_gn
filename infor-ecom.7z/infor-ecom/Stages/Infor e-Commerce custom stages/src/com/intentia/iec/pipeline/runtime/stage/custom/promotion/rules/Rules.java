/**
 * 
 */
package com.intentia.iec.pipeline.runtime.stage.custom.promotion.rules;

import java.util.List;
import java.util.Map;

import javax.xml.transform.TransformerException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;

/**
 * @author gsantiago /mgumali
 * 
 */
public interface Rules {

	boolean evaluateOrder(XMLResultset resultSet, XMLRequestHelper xmlHelper) throws ResultsetException;

	boolean evaluateOrderLine(XMLIterator xmlOrderline,
			XMLRequestHelper xmlHelper) throws TransformerException,
			ResultsetException;

	void setPromotionId(String promotionId);

	void setPromotionRule(PromotionRule promotionRule);

	void setPromotionalItemsMap(Map<String, List<String>> promotionalItemsMap);

}
