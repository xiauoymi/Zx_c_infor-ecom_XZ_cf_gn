package com.intentia.iec.pipeline.runtime.stage.custom;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntime;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

public class ATPDatesAllWarehouses implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(ATPDatesAllWarehouses.class);

    public void execute(PipelineContext context) throws PipelineRuntimeException {

        String itemID = null;
        String mvxCompany = null;
        String requestedQuantity = null;

        String warehouseName = null;
        String warehouseId = null;

        String languageCode = null;
        String listPriceGroup = null;
        String currencyCode = null;
        String mvxWarehouse = null;
        String userGroupID = null;
        String userID = null;
        String mvxCUNO = null;

        Parameters parameters = null;
        // Parse Request itemID, mvxCompany, requestDeileryDate, requestQuantity
        // Verify type of request
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Request MUST be of type XMLRequest!");
        }

        XMLRequest request = (XMLRequest) context.getRequest();

        try {

            LOG.debug(request.toString());
            XMLRequest.extractRequestParameters(request);
            parameters = request.getParameters();

            itemID = parameters.getString("itemID");
            mvxCompany = parameters.getString("mvxCompany");
            requestedQuantity = parameters.getString("requestedQuantity");
            languageCode = parameters.getString("@LanguageCode");
            listPriceGroup = parameters.getString("@ListPriceGroup");
            mvxWarehouse = parameters.getString("@MvxWarehouse");
            userGroupID = parameters.getString("@UserGroupID");
            userID = parameters.getString("@UserID");
            mvxCUNO = parameters.getString("mvxCUNO");

            SearchPipelineExecuter findItem = new SearchPipelineExecuter("com.intentia.iec.runtime.pipeline", "Item",
                    "GetSimple");

            findItem.setBinding("ItemID", itemID, "eq");

            XMLResultset rsitem = findItem.execute();

            if (rsitem.isEmpty()) {
                throw new PipelineRuntimeException("Invalid Item: " + itemID);
            }

            SearchPipelineExecuter findCustomerItem = new SearchPipelineExecuter("com.intentia.iec.runtime.pipeline",
                    "Item", "GetItemForCustomer");

            findCustomerItem.setParam("@ListPriceGroup", listPriceGroup);
            findCustomerItem.setParam("mvxCompany", mvxCompany);
            findCustomerItem.setParam("@CurrencyCode", currencyCode);
            findCustomerItem.setParam("@ListPriceGroup", listPriceGroup);
            findCustomerItem.setParam("@MvxWarehouse", mvxWarehouse);
            findCustomerItem.setParam("@UserGroupID", userGroupID);
            findCustomerItem.setParam("@UserID", userID);
            findCustomerItem.setParam("mvxCUNO", mvxCUNO);

            findCustomerItem.setBinding("ItemID", itemID, "eq");

            XMLResultset customerItem = findCustomerItem.execute();

            customerItem.moveNext();

            // Check User Assortments
            String isCustomerItem = null;
            try {
                isCustomerItem = customerItem.getString("ItemID");
                LOG.debug("isCustomeritem: " + isCustomerItem);
                if (isCustomerItem == null || "".equals(isCustomerItem)) {
                    throw new PipelineRuntimeException("Item is not available:: " + itemID);
                }
            } catch (ResultsetException e) {
                throw new PipelineRuntimeException("Item is not available: " + itemID);
            }

            // Check Item visibility
            String isItemVisible = null;
            try {
                isItemVisible = customerItem.getString("IsActive");
                LOG.debug("isItemVisible: " + isItemVisible);
                if (isItemVisible.equalsIgnoreCase("N")) {
                    throw new PipelineRuntimeException("Item is not available: " + itemID);
                }
            } catch (ResultsetException e) {
                LOG.debug("Unable to distinguish if item " + itemID + " is visible");
            }

            // Check if Items is Configurable
            String isMvxConfigurable = null;
            try {
                isMvxConfigurable = customerItem.getString("MvxConfigurable");
                LOG.debug("isMvxConfigurable: " + isMvxConfigurable);
                if (isMvxConfigurable.equalsIgnoreCase("Y")) {
                    throw new PipelineRuntimeException("Item is not orderable: " + itemID);
                }
            } catch (ResultsetException e1) {
                LOG.debug("Unable to distinguish if item " + itemID + " is MvxConfigurable");
            }

            // Check if Item Style
            String styleforitem = null;
            try {
                styleforitem = customerItem.getString("StyleID");
                LOG.debug("StyleID: " + styleforitem);
                if (styleforitem != null) {
                    throw new PipelineRuntimeException("Item is not orderable: " + itemID);
                }
            } catch (ResultsetException e) {
                LOG.debug("Unable to distinguish if item " + itemID + " is stylelable");
            }

            if (!isDecimal(requestedQuantity)) {
                throw new PipelineRuntimeException("Invalid Supplied Quantity!");
            }

            LOG.debug("itemID: " + itemID);
            LOG.debug("requestedDeliveryDate: " + getCurrentDateAsString());
            LOG.debug("requestedQuantity: " + requestedQuantity);

            SearchPipelineExecuter findWarehouses = new SearchPipelineExecuter("com.intentia.iec.runtime.pipeline",
                    "Warehouse", "Lookup");
            findWarehouses.setParam("@LanguageCode", languageCode);
            findWarehouses.setParam("isVisible", "Y");

            XMLResultset warehouses = findWarehouses.execute();
            XMLResultset atpDateAndQuantity;
            XMLResultset atpDatesAndQuantitiesForAllWarehouses = new XMLResultset();

            if (warehouses.isEmpty()) {
                LOG.debug("Warehouse is Empty");
            } else {
                LOG.debug(warehouses.toString());
            }

            while (warehouses.hasNext()) {

                warehouses.moveNext();

                warehouseName = warehouses.getString("Name");
                warehouseId = warehouses.getString("WarehouseID");

                LOG.debug("WarehouseID: " + warehouses.getString("WarehouseID"));

                SearchPipelineExecuter getATPDateAndQuantites = new SearchPipelineExecuter(
                        "com.intentia.iec.runtime.pipeline", "MvxOrderPromise", "GetOrderPromise");

                getATPDateAndQuantites.setParam("mvxCompany", mvxCompany);
                getATPDateAndQuantites.setParam("mvxWareHouse", warehouseId);
                getATPDateAndQuantites.setParam(ConstantsForSales.ITEMID_PARAM, itemID);
                getATPDateAndQuantites.setParam(ConstantsForSales.REQUESTEDQUANTITY, requestedQuantity);
                getATPDateAndQuantites
                        .setParam(ConstantsForSales.REQUESTEDDELIVERYDATE_PARAM, getCurrentDateAsString());

                atpDateAndQuantity = getATPDateAndQuantites.execute();

                LOG.debug("atpDateAndQuantity: " + atpDateAndQuantity.toString());

                while (atpDateAndQuantity.hasNext()) {

                    atpDateAndQuantity.moveNext();

                    atpDatesAndQuantitiesForAllWarehouses.appendRow();
                    atpDatesAndQuantitiesForAllWarehouses.appendField("WarehouseName", warehouseName);
                    atpDatesAndQuantitiesForAllWarehouses.appendField("ATPQuantity", atpDateAndQuantity
                            .getString("ATPQuantity"));
                    atpDatesAndQuantitiesForAllWarehouses.appendField("Unit", atpDateAndQuantity.getString("Unit"));
                    atpDatesAndQuantitiesForAllWarehouses.appendField("ATPDate", atpDateAndQuantity
                            .getString("ATPDate"));

                }

            }

            context.setResponse(atpDatesAndQuantitiesForAllWarehouses);

        } catch (Exception e) {
            throw new PipelineRuntimeException(e);
        }

    }

    public boolean isValidDate(String date) {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date testDate = null;

        try {
            testDate = sdf.parse(date);
        }

        catch (ParseException e) {
            return false;
        }

        if (!sdf.format(testDate).equals(date)) {
            return false;
        }

        return true;

    }

    public String getCurrentDateAsString() {

        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date date = new java.util.Date();

        return dateFormat.format(date);

    }

    public boolean isDecimal(String number) {

        double testValue = 0;

        try {
            testValue = (Double.parseDouble(number));
        } catch (NumberFormatException e) {
            return false;
        }

        if (testValue > 0) {
            return true;
        } else {
            return false;
        }
    }

    public String getString(String columnName) {

        return "";
    }

    /**
     * 
     * @param pipelinecontext
     * @param pipelineClass
     * @throws PipelineRuntimeException
     */
    private void executePipeline(PipelineContext pipelinecontext, String pipelineClass) throws PipelineRuntimeException {
        try {

            Class runtimeClass = Class.forName(pipelineClass);
            PipelineRuntime pipeline = (PipelineRuntime) runtimeClass.newInstance();
            pipeline.execute(pipelinecontext);
        } catch (ClassNotFoundException e1) {
            LOG.fatal((new StringBuilder()).append("Could not find class '").append(pipelineClass).append("'")
                    .toString(), e1);
            throw new PipelineRuntimeException(e1);
        } catch (IllegalAccessException e2) {
            LOG.fatal((new StringBuilder()).append("Illegal access to class '").append(pipelineClass).append("'")
                    .toString(), e2);
            throw new PipelineRuntimeException(e2);
        } catch (InstantiationException e3) {
            LOG.fatal((new StringBuilder()).append("Could not instantiate class '").append(pipelineClass).append("'")
                    .toString(), e3);
            throw new PipelineRuntimeException(e3);
        }
    }
}
