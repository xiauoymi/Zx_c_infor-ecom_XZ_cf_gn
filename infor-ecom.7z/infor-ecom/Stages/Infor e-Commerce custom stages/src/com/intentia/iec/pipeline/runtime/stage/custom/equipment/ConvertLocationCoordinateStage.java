package com.intentia.iec.pipeline.runtime.stage.custom.equipment;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.custom.equipment.location.CartesianCoordinate;
import com.intentia.iec.pipeline.runtime.stage.custom.equipment.location.CoordinateConverter;
import com.intentia.iec.pipeline.runtime.stage.custom.equipment.location.GeodeticCoordinate;
import com.intentia.iec.pipeline.runtime.stage.custom.equipment.location.WorldGeodeticSystem1984Converter;

/**
 * Stage for converting the coordinates from cartesian coordinates (M3) to geodetic coordinates (Google Maps API).
 *
 */
public class ConvertLocationCoordinateStage implements PipelineStage {
	private static final Logger LOG = Logger.getLogger(ConvertLocationCoordinateStage.class);	
	
	private static final String MAINSET_EQUIPMENT = "resultset/row";
	
	private static final String ATTR_COORDINATEX = "CoordinateX";
	
	private static final String ATTR_COORDINATEY = "CoordinateY";
	
	private static final String ATTR_COORDINATEZ = "CoordinateZ";
	
	private static final String ATTR_LATITUDE = "Latitude";
	
	private static final String ATTR_LONGITUDE = "Longitude";
	
	private static final String ATTR_HEIGHT = "Height";
	
	private static final String ATTR_ISCURRENT = "IsCurrent";
	
	private static final String ISCURRENT_Y = "Y";	

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.PipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	public void execute(PipelineContext context) throws PipelineRuntimeException {
        if (!(context.getResponse() instanceof XMLResultset)) {
            throw new PipelineRuntimeException("XML Request is invalid");
        }
        
		XMLResultset resultset = (XMLResultset) context.getResponse();
		if (resultset != null) {
			try {
				resultset.moveFirst();
				
				Document xmlDoc = resultset.getDocument();
				try {
					// get all equipment in the mainset
					NodeList parentNodeList = XPathAPI.selectNodeList(xmlDoc, MAINSET_EQUIPMENT);
					
					for (int i = 0; i < parentNodeList.getLength(); i++) {
						Element parentElement = (Element) parentNodeList.item(i);
						NodeList childNodeList = parentElement.getChildNodes();

						// get the location subset
						for (int j = 0; j < childNodeList.getLength(); j++) {
							Element childElement = (Element) childNodeList.item(j);
							
							// set the first location as the current
							if (j == 0) {
								childElement.setAttribute(ATTR_ISCURRENT, ISCURRENT_Y);
							}
							
							// attributes from M3
							String x = childElement.getAttribute(ATTR_COORDINATEX);
							String y = childElement.getAttribute(ATTR_COORDINATEY);
							String z = childElement.getAttribute(ATTR_COORDINATEZ);
							
							// only convert of cartesian is desired
							boolean doConvert = Boolean.valueOf(CustomStagesHelper.getKeyValue("Application.Equipment Location Cartesian Coordinates"));
							
							if (doConvert == true) {
								LOG.debug("Using Cartesian coordinates, converting to Geodetic");
								try {
									// convert to double
									double coordinateX = Double.parseDouble(x);
									double coordinateY = Double.parseDouble(y);
									double coordinateZ = Double.parseDouble(z);
									
									// convert cartesian to geodetic coordinate
									CartesianCoordinate cartesian = new CartesianCoordinate(coordinateX, coordinateY, coordinateZ);
									CoordinateConverter converter = getConverter();
									GeodeticCoordinate geodetic = converter.convert(cartesian);
									
									// set the resultset attributes
									childElement.setAttribute(ATTR_LATITUDE, String.valueOf(geodetic.getLatitude()));
									childElement.setAttribute(ATTR_LONGITUDE, String.valueOf(geodetic.getLongitude()));
									childElement.setAttribute(ATTR_HEIGHT, String.valueOf(geodetic.getHeight()));
								}
								catch (Exception f) {
									LOG.debug("Skipping conversion due to error=" + f.getMessage());
								}
							}
							else {
								LOG.debug("Using Geodetic coordinates");
								try {
									// convert to double
									double coordinateX = Double.parseDouble(x);
									double coordinateY = Double.parseDouble(y);
									
									// set the resultset attributes
									childElement.setAttribute(ATTR_LATITUDE, String.valueOf(coordinateX));
									childElement.setAttribute(ATTR_LONGITUDE, String.valueOf(coordinateY));
									childElement.setAttribute(ATTR_HEIGHT, "0");
								}
								catch (Exception f) {
									LOG.debug("Skipping conversion due to error=" + f.getMessage());
								}
							}

						}
					}
				} catch (TransformerException e) {
					LOG.error(e);
				}
			} catch (ResultsetException e) {
				throw new PipelineRuntimeException(e);
			}					
		}		
	}
	
	/**
	 * Returns the CoordinateConverter. Currently, only the WorldGeodeticSystem1984 is supported.
	 * @return
	 */
	private CoordinateConverter getConverter() {
		return new WorldGeodeticSystem1984Converter();
	}
	
}
