package com.intentia.iec.pipeline.runtime.stage.custom.daf;

import com.intentia.icp.common.CMItem;
import com.intentia.icp.common.Connection;
import com.intentia.icp.common.SearchArgument;
import com.intentia.icp.common.SearchQuery;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

/**
 * The most basic class for a custom stage that uses DAF.
 *
 */
public abstract class AbstractDafStage extends AbstractPipelineStage {	
	
	/**
	 * Datastore value used to connect to DAF.
	 */
	protected String datastore = null;
	
	/**
	 * Username used to connect to DAF.
	 */
	protected String username = null;
	
	/**
	 * Password used to connect to DAF.
	 */
	protected String password = null;
	
	/**
	 * Schema used to connect to DAF.
	 */
	protected String schema = null;
	
	/**
	 * Language used to connect to DAF.
	 */
	protected String language = null;
	
	/**
	 * SQL uid used to connect to DAF.
	 */
	protected String sqluid = null;
	
	/**
	 * SQL password used to connect to DAF.
	 */
	protected String sqlpwd = null;
	
	/**
	 * JDBC driver class used to connect to DAF.
	 */
	protected String jdbcDriver = null;
	
	/**
	 * JDBC URL used to connect to DAF.
	 */
	protected String jdbcUrl = null;
	
	/**
	 * Connection object created to communicate to DAF.
	 */
	protected Connection connection = null;

	/**
	 * The retrieve option used when searching.
	 */
	protected int retrieveOption = CMItem.ITEM_SEARCH_DEFAULT_OPTION;	
	
	private static final String SORT_DESCENDING = "DESCENDING";
	
	private static final String SORT_ASCENDING = "ASCENDING";
	
	private static final String DESCENDING = "descending";
	
	private static final String DATASTORE = "DataStore";

	private static final String USERNAME = "UserName";

	private static final String PASSWORD = "Password";
	
	private static final String SCHEMA = "Schema";
	
	private static final String LANGUAGE = "Language";
	
	private static final String SQLUSERID = "SQLUserID";
	
	private static final String SQLPASSWORD = "SQLPassword";
	
	private static final String JDBCDRIVER = "JDBCDriver";
	
	private static final String JDBCURL = "JDBCURL";
	
	private static final String PIPELINE_PACKAGE = "com.intentia.iec.runtime.pipeline";
	
	private static final String APPLICATION_DATA = "ApplicationData";
	
	private static final String APPLICATION_DATA_DETAILS = "Details";
	
	private static final String PARAM = "param";
	
	private static final String PARAM_VALUE = "ParameterValue";
	
	/**
	 * Initializes the connection parameters. The values are from the Application Details table from e-Sales.
	 */
	public void initialize() {
		this.datastore = getValueFromApplicationData(DATASTORE);
		this.username = getValueFromApplicationData(USERNAME);
		this.password = getValueFromApplicationData(PASSWORD);
		this.schema = getValueFromApplicationData(SCHEMA);
		this.language = getValueFromApplicationData(LANGUAGE);		
		this.sqluid = getValueFromApplicationData(SQLUSERID);
		this.sqlpwd = getValueFromApplicationData(SQLPASSWORD);
		this.jdbcDriver = getValueFromApplicationData(JDBCDRIVER);
		this.jdbcUrl = getValueFromApplicationData(JDBCURL);
	}
	
    /**
     * Helper method for getting the connection parameters.
     * @param paramName
     * @return
     */
    private String getValueFromApplicationData(String paramName) {

        String paramValue = null;

        SearchPipelineExecuter spe = new SearchPipelineExecuter(PIPELINE_PACKAGE, APPLICATION_DATA, APPLICATION_DATA_DETAILS);

        spe.setParam(PARAM, paramName);

        try {
            XMLResultset rs = spe.execute();
            rs.moveFirst();
            paramValue = rs.getString(PARAM_VALUE);
        } catch (PipelineRuntimeException e) {
            paramValue = "";
        } catch (ResultsetException e) {
            paramValue = "";
        }

        return paramValue;
    }
	
	/**
	 * Returns an XMLResultset with no rows. Used if the search result contains no item. 
	 * @return
	 */
	public XMLResultset getEmptyResultSet() {
        String ret = ("<?xml version='1.0' encoding='UTF-8'?>"
                + "<resultset object='BlowUpPrint'/>");
        return new XMLResultset(ret);        
	}
	
	/**
	 * Escapes the query string used for searching. The character(s) escaped is/are - "
	 * @param query the escaped query string
	 * @return
	 */
	public String escapeXQuery(String query) {
		String ret = null;
		if (query != null) {			
			ret = query.replaceAll("\"", "\"\"");
		}
		
		return ret;
	}

	/**
	 * Encodes the string used as value in the XML result set.
	 * @param str
	 * @return
	 */
	public String encodeXML(String str) {
		if (str == null) {
			return "";
		}
        return str.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("'", "&apos;");
    }
	

	/**
	 * Helper method for creating the query string that is case-sensitive.
	 * @param buf StringBuffer containing the query
	 * @param attributeName DAF attribute name that will be checked
	 * @param operator operator used for searching
	 * @param filter the criteria used for searching
	 */
	public void appendQuery(StringBuffer buf, String attributeName, String operator, String filter) {
		appendQuery(buf, attributeName, operator, filter, true);
	}
	
	/**
	 * Helper method for creating the query string.
	 * @param buf
	 * @param attributeName
	 * @param operator
	 * @param filter
	 * @param isCaseSensitive
	 */
	public void appendQuery(StringBuffer buf, String attributeName, String operator, String filter, boolean isCaseSensitive) {
		appendQuery(buf, attributeName, operator, filter, SearchQuery.SEARCH_TYPE_AND, isCaseSensitive);
	}
	
	/**
	 * Helper method for creating the query string that is case-sensitive.
	 * @param buf
	 * @param attributeName
	 * @param operator
	 * @param filter
	 * @param type
	 */
	public void appendQuery(StringBuffer buf, String attributeName, String operator, String filter, String type) {
		appendQuery(buf, attributeName, operator, filter, type, true);
	}
	
	/**
	 * Helper method for creating the query string.
	 * @param buf StringBuffer containing the query
	 * @param attributeName DAF attribute name that will be checked
	 * @param operator operator used for searching
	 * @param filter the criteria used for searching
	 * @param type the search type (AND, OR, etc)
	 */
	public void appendQuery(StringBuffer buf, String attributeName, String operator, String filter, String type, boolean isCaseSensitive) {
		if (buf != null && attributeName != null && filter != null && "".equals(filter) == false && "null".equals(filter) == false && type != null) {
			if ("".equals(buf.toString()) == false) {
				buf.append(" " + type + " ");
			}
			
			if (isCaseSensitive == true) {
				if (SearchArgument.SEARCH_OP_LIKE.equals(operator)) {
					buf.append(attributeName + " " + operator + " \"%" + escapeXQuery(filter) + "%\"");
				}
				else {
					buf.append(attributeName + " " + operator + " \"" + escapeXQuery(filter) + "\"");	
				}				
			}
			else {
				// for case-insensitive, use UPPER()
				if (SearchArgument.SEARCH_OP_LIKE.equals(operator)) {
					buf.append("UPPER(" + attributeName + ") " + operator + " UPPER(\"%" + escapeXQuery(filter) + "%\")");
				}
				else {
					buf.append("UPPER(" + attributeName + ") " + operator + " UPPER(\"" + escapeXQuery(filter) + "\")");	
				}
			}
		}
	}
	
	/**
	 * Helper method for creating the query string using a unary operator.
	 * @param buf StringBuffer containing the query
	 * @param attributeName DAF attribute name that will be checked
	 * @param operator operator used for searching
	 */
	public void appendQuerySingleOperand(StringBuffer buf, String attributeName, String operator) {
		appendQuerySingleOperand(buf, attributeName, operator, SearchQuery.SEARCH_TYPE_AND);
	}
	
	/**
	 * Helper method for creating the query string using a unary operator.
	 * @param buf StringBuffer containing the query
	 * @param attributeName DAF attribute name that will be checked
	 * @param operator operator used for searching
	 * @param type the search type (AND, OR, etc)
	 */
	public void appendQuerySingleOperand(StringBuffer buf, String attributeName, String operator, String type) {
		if (buf != null && attributeName != null && operator != null && type != null) {
			if ("".equals(buf.toString()) == false) {
				buf.append(" " + type + " ");
			}			
			buf.append(attributeName + " " + operator);
		}
	}
	

	/**
	 * Returns the DAF database field for the attribute.
	 * @param attribute
	 * @return
	 */
	public abstract String getAttributeToDafDatabaseField(String attribute);
	
	/**
	 * Creates a string used for sorting the search results.
	 * @param sortingField the field that will be sorted
	 * @param sortingDirection the sorting direction
	 * @return
	 */
	public String getSorting(String sortingField, String sortingDirection) {
		String dafField = getAttributeToDafDatabaseField(sortingField);
		if (dafField != null) {
			String direction = DESCENDING.equals(sortingDirection) ? SORT_DESCENDING : SORT_ASCENDING;
			return (" SORTBY(@" + dafField + " " + direction + ")");
		}
		
		return "";
	}
}
