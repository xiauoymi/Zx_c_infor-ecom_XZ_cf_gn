package com.intentia.iec.pipeline.runtime.stage.custom.promotion.rules;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

public class AmountImpl implements Rules{

	private static final Logger LOG = Logger.getLogger(AmountImpl.class);
	
	private static AmountImpl instance = null;
	
	private PromotionRule promotionRule = null;
	
	private String promotionId;
	
	private Map<String, List<String>> promotionalItemsMap;
	
	private XMLRequestHelper xmlHelper = null;
	
	private String languageCode = null;
	
	protected AmountImpl() {
	      // Exists only to defeat instantiation.
	}
	public static AmountImpl getInstance() {
		if(instance == null) {
			instance = new AmountImpl();
		}
	return instance;
	}
	
	public PromotionRule getPromotionRule() {
		return promotionRule;
	}
	
	public void setPromotionId(String promotionId) {
		this.promotionId = promotionId;
	}
	
	public void setPromotionRule(PromotionRule promotionRule) {
		this.promotionRule = promotionRule;
	}
	
	public void setPromotionalItemsMap(Map<String, List<String>> promotionalItemsMap) {
		this.promotionalItemsMap = promotionalItemsMap;
	}
	
	public boolean evaluateOrder(XMLResultset resultSet, XMLRequestHelper xmlHelper) throws ResultsetException{
		LOG.debug("Inside AmountImpl.evaluateOrder()");
		
		boolean isValid = false;
		this.xmlHelper = xmlHelper;
		try {
			// Get OrderHeader node in the request document
			PromotionRule promotionRule = this.promotionRule;		
			String ruleField = promotionRule.getField().trim();
			String operator = promotionRule.getOperator().trim();
			
			List<String> ruleValueList = promotionRule.getValues();
			if(RulesConstant.ORDER_TOTAL.equals(ruleField)){
				isValid = this.evaluateGrandTotal(resultSet, ruleValueList, operator);
			} else if(RulesConstant.ITEMS_IN_PROMO.equals(ruleField)){
				isValid = this.evaluateItemsInPromo(resultSet, ruleValueList, operator);
			} else {
				isValid = false;
			}
		} catch (TransformerException e) {
			e.printStackTrace();
		}
		
		return isValid;	
	}
	
	public boolean evaluateOrderLine(XMLIterator xmlOrderline, XMLRequestHelper xmlHelper)
			throws TransformerException, ResultsetException {
		LOG.debug("Inside AmountImpl.evaluateOrderLine()");
		boolean isValid = false;
		this.xmlHelper = xmlHelper;

		PromotionRule promotionRule = this.promotionRule;		
		List<String> ruleValueList = promotionRule.getValues();
		String ruleField = promotionRule.getField().trim();
		String operator = promotionRule.getOperator().trim();
		try {
			if(RulesConstant.ANY_ITEMS_IN_PROMO.equals(ruleField) || RulesConstant.PER_ITEMS_IN_PROMO.equals(ruleField)){
				isValid = this.evaluateItemAmount(xmlOrderline, ruleValueList, operator);
			} else {
				isValid = false;
			}
		} catch (TransformerException e) {
			e.printStackTrace();
		}
		return isValid;
	}
	
	private boolean evaluateGrandTotal(XMLResultset resultset, List<String> ruleValueList, String operator)
			throws TransformerException, ResultsetException{
		LOG.debug("Inside AmountImpl.evaluateGrandTotal()");
		boolean isMatch = false;
		String grandTotalFromRequest = resultset.getString(RulesConstant.REQ_GRAND_TOTAL);
		BigDecimal orderAmountTotal = new BigDecimal(grandTotalFromRequest);
		for (String amountValue : ruleValueList) {
			isMatch = operatorEvaluator(operator, orderAmountTotal, amountValue);
			//End after one loop
			break;
		}
		return isMatch;
	}

	private boolean evaluateItemsInPromo(XMLResultset resultset, List<String> ruleValueList, String operator)
			throws TransformerException, ResultsetException{
		LOG.debug("Inside AmountImpl.evaluatePerItem()");
		List<String> promotionalItems = this.promotionalItemsMap.get(this.promotionId);
		boolean isMatch = false;
		XMLIterator xmlOrderline = null;
        try {
            xmlOrderline = (XMLIterator) resultset.getResultset(ConstantsForSales.ORDERLINE);
            xmlOrderline.beforeFirst();
            BigDecimal orderAmountTotal = new BigDecimal(0); 
        	while (xmlOrderline.moveNext()) {
        		String currItemID = this.getStringValue(xmlOrderline, ConstantsForSales.ITEM_ID); 
        		if(promotionalItems.contains(currItemID)){
        			String strLineTotal = this.getStringValue(xmlOrderline, ConstantsForSales.LINETOTAL);
        			orderAmountTotal = orderAmountTotal.add(new BigDecimal(strLineTotal));
        		}
        	}
        	for (String amountValue : ruleValueList) {
        		isMatch = operatorEvaluator(operator, orderAmountTotal, amountValue);
        		//End after one loop
        		break;
        	}
        } catch (ResultsetException e) {
            String msg = "Could not get order lines";
            LOG.error("Error Inside AmountImpl.evaluateGrandTotal() - "+msg);
        }
		
		return isMatch;
	}
	
	/**
	 * Evaluate 
	 * 
	 * @param orderlineList
	 * @param ruleValueList
	 * @param operator
	 * @return
	 * @throws TransformerException
	 * @throws ResultsetException 
	 */
	private boolean evaluateItemAmount(XMLIterator xmlOrderline, List<String> ruleValueList, String operator)
			throws TransformerException, ResultsetException{
		LOG.debug("Inside AmountImpl.evaluateAnyItem()");
		boolean isMatch = false;
		String strResellPrice = this.getStringValue(xmlOrderline, ConstantsForSales.RESELLPRICE); 
		BigDecimal resellPrice = new BigDecimal(strResellPrice);
		
		for (String amountValue : ruleValueList) {
			isMatch = operatorEvaluator(operator, resellPrice, amountValue);
			//End after one loop
			break;
		}
		return isMatch;
	}

	/**
	 * @param operator
	 * @param isMatch
	 * @param orderAmountTotal
	 * @param amountValue
	 * @return
	 */
	private boolean operatorEvaluator(String operator, BigDecimal orderAmountTotal, String amountValue) {
		boolean isMatch = false;
//		BigDecimal amount = new BigDecimal(amountValue);
		BigDecimal amount = this.promotionRule.calculateValueCurrency(amountValue);
		int result = orderAmountTotal.compareTo(amount);
		if(RulesConstant.OPERATOR_EQUAL.equals(operator)){
			if(result == 0){ // both values are equal
				isMatch = true;					
			}
		} else if(RulesConstant.OPERATOR_LESSTHAN.equals(operator)){
			if(result == -1){ // order amount total is less than rule vale amount 
				isMatch = true;					
			}
		} else if(RulesConstant.OPERATOR_GREATERTHAN.equals(operator)){
			if(result == 1){ // order amount total is greater than rule vale amount
				isMatch = true;					
			}
		} else if(RulesConstant.OPERATOR_LESSTHAN_EQUALTO.equals(operator)){
			if(result == -1 || result == 0){ // order amount total is less than equal to rule vale amount
				isMatch = true;					
			}
		} else if(RulesConstant.OPERATOR_GREATERTHAN_EQUALTO.equals(operator)){
			if(result == 1 || result == 0){ // order amount total is greater than equal to rule vale amount
				isMatch = true;					
			}
		}
		return isMatch;
	}
	
	private String getStringValue(XMLIterator xmlOrderline, String requestField){
		String stringFromRequest = "";
		try {
			stringFromRequest = xmlOrderline.getString(requestField);
			if("".equals(stringFromRequest) && (requestField.equals(ConstantsForSales.RESELLPRICE) 
					|| requestField.equals(ConstantsForSales.LINETOTAL) || requestField.equals(RulesConstant.REQ_GRAND_TOTAL))){
				stringFromRequest = RulesConstant.ZERO_BIG_DECIMAL_VALUE;
			}
		} catch (ResultsetException e) {
			String msg = "Empty Request Field";
            LOG.error("Error Inside QuantityImpl.getStringValue() - "+msg);
		}
		return stringFromRequest;
	}
}
