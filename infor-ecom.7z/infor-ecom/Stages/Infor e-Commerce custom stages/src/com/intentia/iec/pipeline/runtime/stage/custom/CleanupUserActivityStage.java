package com.intentia.iec.pipeline.runtime.stage.custom;

import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.google.gdata.data.DateTime;
import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.integration.ia.utils.IaRestApiClient;
import com.intentia.iec.pipeline.runtime.stage.utils.CommitPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;
import com.intentia.iec.sqlserver.common.DatabaseType;
import com.intentia.iec.sqlserver.runtime.procedure.StageCallProcedure;

public class CleanupUserActivityStage implements PipelineStage {

	private static final Logger log = Logger.getLogger(CleanupUserActivityStage.class);
	private static final String EXECUTE_PROCEDURE = "EXEC CleanupUserActivity ?";
    private static final String VALUE = "value";
    private static final String SOURCE = "pipeline";
    private static final String PARAM_NAME = "@Threshold";
    private static final String PARAM_FIELD = "Threshold";
	String threshold = getConfig(ConstantsForSales.APPLICATION_USER_ACTIVITY_THRESHOLD, ConstantsForSales.APPLICATION_USER_ACTIVITY_THRESHOLD_DEF);
	
	@Override
	public void execute(PipelineContext context) throws PipelineRuntimeException {
		
		log.debug("Start CleanupUserActivityStage . . .");
		
		try {

			callProcedure();
			
		} catch (PipelineRuntimeException e) {
			throw new PipelineRuntimeException(
					"Error in cleaning user activity log: Threshold = " + threshold + " days", e);
		}
	}
    private void callProcedure() throws PipelineRuntimeException {

        StageCallProcedure procedure = new StageCallProcedure(EXECUTE_PROCEDURE);
        PipelineContext context = new PipelineContext();

        // setup procedure parameters
        int intType = DatabaseType.INTEGER;
        procedure.addInputParam(PARAM_NAME, 1, intType, SOURCE, PARAM_FIELD);

        // add parameters to context
        context.put(PARAM_FIELD, threshold);

        // run procedure
        procedure.execute(context);
    }
	private static String getConfig(String name, String defaultValue) {
		try {
			String value = StageUtilityHelper.getValueFromApplicationData(name);
			return StringUtils.defaultIfEmpty(value, defaultValue);
		} catch (Exception e) {
			log.error("Error while fetching the value of config param '" + name
					+ "'. Setting value to default = " + defaultValue, e);
			return defaultValue;
		} catch (NoClassDefFoundError e) { // Not recommended! For testing only.
			log.error("Error while fetching the value of config param '" + name
					+ "'. Setting value to default = " + defaultValue, e);
			return defaultValue;
		}
	}
}
