package com.intentia.iec.pipeline.runtime.stage.custom.search;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.misc.ChainedFilter;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.queryParser.QueryParser.Operator;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.FieldCache;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.ScoreDocComparator;
import org.apache.lucene.search.Sort;
import org.apache.lucene.search.SortComparatorSource;
import org.apache.lucene.search.SortField;

import com.ibm.icu.text.NumberFormat;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.custom.search.sps.equipment.EquipmentRequest;
import com.intentia.iec.pipeline.runtime.stage.custom.search.sps.equipment.EquipmentStrings;
import com.intentia.iec.pipeline.runtime.stage.utils.Decimal;
import com.intentia.iec.util.FastStringBuffer;

/**
 * Abstract class for ItemListStage. Refactored the class so that some objects will not have to be instantiated.
 *
 */
public abstract class AbstractItemListStage extends AbstractPipelineStage {
	
	private static final Logger LOG = Logger.getLogger(AbstractItemListStage.class);
	
    public static final int DEFAULT_PAGING_LIMIT = 11;

    public static final CachedTermsFilter ITEM_ENTRY_FILTER = new CachedTermsFilter(new Term(Strings.Index.entryType,
            Strings.Index.item));

    protected Request request;

    protected Response response;

    protected SearchUtils helper;

    protected Database queries;

    protected DataHolder dataholder;

    private String lang = null;

    private static final String WILDCARD = "*";

    private static final String SEPARATOR = ":";

    private static final String PRICEEXISTS = SEPARATOR + SearchUtils.PRICE_PREFIX + WILDCARD;

    private static final String OR = " OR ";

    private static final String NOT = " NOT ";

    private static final String GROUP_START = "(";

    private static final String GROUP_END = ")";        
    
    private static final String SPACE = " ";
    
    private static final String AND = " AND ";
    
    /* (non-Javadoc)
     * @see com.intentia.iec.pipeline.runtime.AbstractPipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
     */
    public void execute(final PipelineContext context) throws PipelineRuntimeException {
        try {
            request.parseRequest(CustomStagesHelper.getRequest(context));
            lang = request.getLanguageCode();
            CachedChainedFilter filterChainCached = getDefaultFilters();
            if (filterChainCached != null) {
                addFilters(filterChainCached);

                try {
                    // if price search is included, search string is in Query
                    Query query = getQuery();
                    Hits hits = helper.search(dataholder, query, filterChainCached, getSort());
                    Map<String, Map<String, String>> rows = getPageOfRowDataFromLucene(hits);
                    if (!rows.isEmpty()) {
                        queries.mergeItemAttributesFromDatabase(rows, request);
                    }
                    response.setResponse(context, rows.values());
                    response.setTotalSearchCountParam(context, hits.length());
                } catch (BooleanQuery.TooManyClauses e) {
                    response.setTooManyClausesResponse(context);
                }
            } else {
                response.setResponse(context, null);
                response.setTotalSearchCountParam(context, 0);
            }
        } catch (PipelineRuntimeException e) {
            LOG.error("Item List Lucene search failed", e);
            throw e;
        } catch (ParseException e) {
            LOG.error("Parse exception", e);
            throw new PipelineRuntimeException(e);
        } catch (Exception e) {
            LOG.error("Other exception", e);
            throw new PipelineRuntimeException(e);
        }
    }

    /**
     * 
     * @param filterChainCached
     * @throws PipelineRuntimeException
     */
    protected void addFilters(final CachedChainedFilter filterChainCached) throws PipelineRuntimeException {
        filterChainCached.add(ITEM_ENTRY_FILTER);

        String searchRequestOrigin = request.getSearchRequestOrigin();
        String wildcardSearch = request.getWildcardSearch();
        boolean useWildcardSearch = false;
        if (searchRequestOrigin != null && wildcardSearch != null && wildcardSearch.equals(searchRequestOrigin) == true) {
        	useWildcardSearch = true;
        }		

        if (request.getSearchRequestOrigin().equals(Strings.Request.SearchOrigin.B2B_QUICKSEARCH)
                || request.getSearchRequestOrigin().equals(Strings.Request.SearchOrigin.B2C)) {

            StringBuilder logInfo = new StringBuilder(100);

            if (request.getSearchRequestOrigin().equals(Strings.Request.SearchOrigin.B2C)) {
                String searchCategory = request.getCategoryKeySearch();
                String searchBrandId = request.getBrandId();

                if (searchCategory != null && !"empty".equals(searchCategory)) { // TODO
                    // means
                    // you
                    // can't
                    // search
                    // an
                    // "empty"
                    // word
                    String path = dataholder.getCategoryPathByKey(searchCategory);
                    if (path != null) {
                        Term categoryTerm = new Term(Strings.Index.Item.categoryPath, path);
                        filterChainCached.add(new CachedPrefixFilter(categoryTerm));
                    } else {
                        LOG.error("Category key not found");
                    }
                    logInfo.append("\n\t<categoryid><![CDATA[").append(searchCategory).append("]]></categoryid>");
                }

                if (searchBrandId != null && !"empty".equals(searchBrandId)) { // TODO
                    // means
                    // you
                    // can't
                    // search
                    // an
                    // "empty"
                    // word
                    Term brandIdTerm = new Term(Strings.Index.Item.brandId, searchBrandId);
                    filterChainCached.add(new CachedPrefixFilter(brandIdTerm));
                    logInfo.append("\n\t<brandid><![CDATA[").append(searchBrandId).append("]]></brandid>");
                }
            }

            if (useWildcardSearch == false && request.getQuickSearchString() != null && !"empty".equals(request.getQuickSearchString())) {
                String searchText = request.getQuickSearchString().toLowerCase();
                String[] words = searchText.split(" or "); // TODO: search
                // string delimiter
                // is misleading
                // where in fact the
                // search operation
                // is "AND"

                // quicksearch w/o customer item role, do not include customer
                // item id in search
                if (request.getIncludeCustomerItemID() == false) {
                	CachedChainedFilter fullTextFilter = new CachedChainedFilter();
                    for (String word : words) {
                        word = word.substring(1, word.length() - 1); // Remove
                        // the
                        // quotes
                        Term fulltextTerm = new Term(Strings.Index.Item.fullTextPrefix + lang, word);
                        fullTextFilter.add(new CachedPrefixFilter(fulltextTerm), ChainedFilter.OR);
                    }
                    
                    filterChainCached.add(fullTextFilter);

                    logInfo.append("\n\t<fulltext><![CDATA[").append(searchText).append("]]></fulltext>");
                } else {
                    // quickSearchFilter = (Standard filters) AND ((FullText) OR
                    // (CustomerItemID))
                    CachedChainedFilter fullTextFilter = new CachedChainedFilter();
                    for (String word : words) {
                        word = word.substring(1, word.length() - 1); // Remove
                        // the
                        // quotes
                        Term fulltextTerm = new Term(Strings.Index.Item.fullTextPrefix + lang, word);
                        fullTextFilter.add(new CachedPrefixFilter(fulltextTerm));
                    }

                    // customerItemIDFilter = OR'ed customer item IDs
                    CachedChainedFilter customerItemIDFilter = new CachedChainedFilter();
                    for (String word : words) {
                        word = word.substring(1, word.length() - 1); // Remove
                        // the
                        // quotes
                        Term customerItemIdTerm = new Term(Strings.Index.Item.customerItemIdTokenizedPrefix
                                + request.getUserGroupId(), word);
                        customerItemIDFilter.add(new CachedPrefixFilter(customerItemIdTerm), ChainedFilter.OR);
                    }

                    CachedChainedFilter quickSearchFilter = new CachedChainedFilter();
                    quickSearchFilter.add(fullTextFilter);
                    quickSearchFilter.add(customerItemIDFilter, ChainedFilter.OR);

                    filterChainCached.add(quickSearchFilter);

                    logInfo.append("\n\t<fulltext><![CDATA[").append(searchText).append("]]></fulltext>");
                    logInfo.append("\n\t<customeritemid><![CDATA[").append(searchText).append("]]></customeritemid>");
                }
            }

            if (logInfo.length() > 0)
                LOG.info(logInfo.toString());
            else
                LOG.info("\n\t<default />");

        } else if (request.getSearchRequestOrigin().equals(Strings.Request.SearchOrigin.B2B_FILTER)) {
            String searchNumber = request.getItemNumber();
            String searchCustomerItemID = request.getCustomerItemID();
            String searchName = request.getItemName();
            String searchCategory = request.getCategoryKeySearch();
            String searchManufacturer = request.getManufacturerId();
            String searchSupplier = request.getSupplierId();
			String flagCampaign = request.getFlagCampaign();
            StringBuilder logInfo = new StringBuilder(100);

            if (useWildcardSearch == false && searchNumber != null && !"empty".equals(searchNumber)) { // TODO
                // means
                // you
                // can't
                // search
                // an
                // "empty"
                // word
                Term numberTerm = new Term(Strings.Index.Item.itemNumber, searchNumber.toLowerCase());
				if ("true".equals(flagCampaign)) {
					filterChainCached.add(new CachedTermsFilter(numberTerm));
				} else {
					filterChainCached.add(new CachedPrefixFilter(numberTerm));
				}			
                logInfo.append("\n\t<itemnumber><![CDATA[").append(searchNumber).append("]]></itemnumber>");
            }

            // TODO means you can't search an "empty" word
            if (useWildcardSearch == false && searchCustomerItemID != null && !"empty".equals(searchCustomerItemID)) {
                Term customerItemIDTerm = new Term(Strings.Index.Item.customerItemIdPrefix + request.getUserGroupId(),
                        searchCustomerItemID.toLowerCase());
                filterChainCached.add(new CachedPrefixFilter(customerItemIDTerm));
                logInfo.append("\n\t<customerItemID><![CDATA[").append(searchCustomerItemID).append(
                        "]]></customerItemID>");
            }

            if (useWildcardSearch == false && searchName != null && !"empty".equals(searchName)) { // TODO
                // means
                // you
                // can't
                // search
                // an
                // "empty"
                // word
                String[] words = searchName.split(" ");
                for (String word : words) {
                    Term nameTerm = new Term(Strings.Index.Item.nameTokenizedPrefix + lang, word.toLowerCase());
                    filterChainCached.add(new CachedPrefixFilter(nameTerm));
                }

                logInfo.append("\n\t<itemname><![CDATA[").append(searchName).append("]]></itemname>");
            }

            if (searchCategory != null && !"empty".equals(searchCategory)) { // TODO
                // means
                // you
                // can't
                // search
                // an
                // "empty"
                // word
                String path = dataholder.getCategoryPathByKey(searchCategory);
                if (path != null) {
                    Term categoryTerm = new Term(Strings.Index.Item.categoryPath, path);
                    filterChainCached.add(new CachedPrefixFilter(categoryTerm));
                } else {
                    LOG.error("Category key not found");
                }
                logInfo.append("\n\t<categoryid><![CDATA[").append(searchCategory).append("]]></categoryid>");
            }

            if (searchManufacturer != null && !"empty".equals(searchManufacturer)) { // TODO
                // means
                // you
                // can't
                // search
                // an
                // "empty"
                // word
                Term manufacturerTerm = new Term(Strings.Index.Item.manufacturerId, searchManufacturer);
                CachedTermsFilter tfw = new CachedTermsFilter();
                tfw.addTerm(manufacturerTerm);
                filterChainCached.add(tfw);
                logInfo.append("\n\t<manufacturerid><![CDATA[").append(searchManufacturer).append(
                        "]]></manufacturerid>");
            }

            if (useWildcardSearch == false && searchSupplier != null && !"empty".equals(searchSupplier)) { // TODO
                // means
                // you
                // can't
                // search
                // an
                // "empty"
                // word
                Term supplierTerm = new Term(Strings.Index.Item.supplierId, searchSupplier.toLowerCase());
                filterChainCached.add(new CachedPrefixFilter(supplierTerm));
                logInfo.append("\n\t<supplierid><![CDATA[").append(searchSupplier.toLowerCase()).append(
                        "]]></supplierid>");
            }

            if (logInfo.length() > 0) {
                LOG.info(logInfo.toString());
            } else {
                LOG.info("\n\t<default />");
            }

        } else {
            LOG.info("\n\t<default />");
        }
    }

    /**
     * Custom comparator for price used for sorting the search results.
     * 
     */
    private class PriceComparator implements SortComparatorSource {
        /**
         * 
         */
        private static final long serialVersionUID = 4507822808640286466L;

        private boolean executeIncludeTax = Boolean.valueOf(request.getExecuteIncludeTax());

        private String listPriceGroupId = request.getListPriceGroupId();

        private String netPriceGroupId = request.getResellPriceGroupId();

        private String userGroupId = request.getUserGroupId();

        private String currencyCode = request.getCurrencyCode();

        private String countryCode = request.getShippingCountryCode();

        private String taxPriceFieldListNetUser = getTaxPriceField(listPriceGroupId, netPriceGroupId, userGroupId,
                currencyCode, countryCode);

        private String taxPriceFieldNetNetUser = getTaxPriceField(netPriceGroupId, netPriceGroupId, userGroupId,
                currencyCode, countryCode);

        private String taxPriceFieldListNet = getTaxPriceField(listPriceGroupId, netPriceGroupId, currencyCode,
                countryCode);

        private String taxPriceFieldNetNet = getTaxPriceField(netPriceGroupId, netPriceGroupId, currencyCode,
                countryCode);

        private String taxPriceFieldUser = getTaxPriceField(userGroupId, currencyCode, countryCode);

        private String priceFieldListNetUser = getPriceField(listPriceGroupId, netPriceGroupId, userGroupId,
                currencyCode);

        private String priceFieldNetNetUser = getPriceField(netPriceGroupId, netPriceGroupId, userGroupId, currencyCode);

        private String priceFieldListNet = getPriceField(listPriceGroupId, netPriceGroupId, currencyCode);

        private String priceFieldNetNet = getPriceField(netPriceGroupId, netPriceGroupId, currencyCode);

        private String priceFieldUser = getPriceField(userGroupId, currencyCode);

        private String getMatchDocumentPrice(IndexReader reader, int scoreDoc, List<String> fieldNames)
                throws IOException {
            String ret = null;

            Iterator<String> it = fieldNames.iterator();
            while (ret == null && it.hasNext() == true) {
                String fieldName = it.next();
                // if there is a tax price based on list/net price for user
                String[] rets = FieldCache.DEFAULT.getStrings(reader, fieldName);
                if (rets != null && scoreDoc < rets.length) {
                    ret = rets[scoreDoc];
                }
            }

            return ret;
        }

        /**
         * Returns the price that will be used for sorting.
         * 
         * @param reader
         * @param scoreDoc
         * @return
         * @throws IOException
         */
        private String getDocumentPrice(IndexReader reader, int scoreDoc) throws IOException {
            String ret = null;
            List<String> fieldNames = new ArrayList<String>();

            if (executeIncludeTax == true) {
                fieldNames.add(taxPriceFieldListNetUser);
                fieldNames.add(taxPriceFieldNetNetUser);
                fieldNames.add(taxPriceFieldListNet);
                fieldNames.add(taxPriceFieldNetNet);
                fieldNames.add(taxPriceFieldUser);
                fieldNames.add(Strings.Index.Item.taxPrice);
            }
            fieldNames.add(priceFieldListNetUser);
            fieldNames.add(priceFieldNetNetUser);
            fieldNames.add(priceFieldListNet);
            fieldNames.add(priceFieldNetNet);
            fieldNames.add(priceFieldUser);
            fieldNames.add(Strings.Index.Item.price);

            ret = getMatchDocumentPrice(reader, scoreDoc, fieldNames);

            return ret;
        }

        /*
         * (non-Javadoc)
         * 
         * @see org.apache.lucene.search.SortComparatorSource#newComparator(org.apache.lucene.index.IndexReader,
         *      java.lang.String)
         */
        public ScoreDocComparator newComparator(final IndexReader indexReader, final String str) throws IOException {
            return new ScoreDocComparator() {
                /*
                 * (non-Javadoc)
                 * 
                 * @see org.apache.lucene.search.ScoreDocComparator#compare(org.apache.lucene.search.ScoreDoc,
                 *      org.apache.lucene.search.ScoreDoc)
                 */
                public int compare(ScoreDoc scoreDoc1, ScoreDoc scoreDoc2) {
                    try {
                        // compare prices of ScoreDocs
                        String price1 = getDocumentPrice(indexReader, scoreDoc1.doc);
                        String price2 = getDocumentPrice(indexReader, scoreDoc2.doc);

                        return price1.compareTo(price2);
                    } catch (IOException e) {
                        LOG.error("Cannot read doc", e);
                    }
                    return 0;
                }

                /*
                 * (non-Javadoc)
                 * 
                 * @see org.apache.lucene.search.ScoreDocComparator#sortValue(org.apache.lucene.search.ScoreDoc)
                 */
                public Comparable<?> sortValue(ScoreDoc scoreDoc) {
                    return new Float(scoreDoc.doc);
                }

                /*
                 * (non-Javadoc)
                 * 
                 * @see org.apache.lucene.search.ScoreDocComparator#sortType()
                 */
                public int sortType() {
                    return SortField.CUSTOM;
                }
            };
        }
    }

    /**
     * 
     * @return
     */
    protected Sort getSort() {
        String SORTING_FIELD_CUSTOMERITEMID = "CustomerItemID";
        String SORTING_FIELD_NETLISTPRICE = "NetListPrice";
        boolean sortByPrice = false;

        String sortingField = Strings.Index.Item.namePrefix + lang;
        if (request.getSortingField() != null) {
            if (request.getSortingField().equals("ItemID")) {
                sortingField = Strings.Index.Item.itemNumber;
            } else if (request.getSortingField().equals("Name")) {
                sortingField = Strings.Index.Item.namePrefix + lang;
            } else if (request.getSortingField().equals("MainCategoryName")) {
                sortingField = Strings.Index.Item.mainCategoryNamePrefix + lang;
            } else if (request.getSortingField().equals("ManufacturerName")) {
                sortingField = Strings.Index.Item.manufacturerName;
            } else if (request.getSortingField().equals("SupplierID")) {
                sortingField = Strings.Index.Item.supplierId;
            } else if (request.getSortingField().equals(SORTING_FIELD_CUSTOMERITEMID)) {
                sortingField = Strings.Index.Item.customerItemIdPrefix + request.getUserGroupId();
            } else if (request.getSortingField().equals(SORTING_FIELD_NETLISTPRICE)) {
                sortByPrice = true;
                sortingField = Strings.Index.Item.price;
            }
        }

        boolean sortReverse = "descending".equals(request.getSortingDirection());
        if (sortByPrice == true) {
            // for prices, use custom price comparator
            return new Sort(new SortField(sortingField, new PriceComparator(), sortReverse));
        } else {
            return new Sort(new SortField[] {new SortField(sortingField, SortField.STRING, sortReverse)});
        }
    }

    /**
     * 
     * @param hits
     * @return
     * @throws PipelineRuntimeException
     */
    protected Map<String, Map<String, String>> getPageOfRowDataFromLucene(final Hits hits)
            throws PipelineRuntimeException {
        final Map<String, Map<String, String>> rows = new LinkedHashMap<String, Map<String, String>>();

        int pagingLimit = DEFAULT_PAGING_LIMIT;
        if (request.getPagingLimit() != null) {
            pagingLimit = Integer.parseInt(request.getPagingLimit());
        }

        int pagingOffset = 0;
        if (request.getPagingOffset() != null) {
            pagingOffset = Integer.parseInt(request.getPagingOffset());
        }

        try {
            for (int i = 0; i < pagingLimit && i < hits.length() - pagingOffset; i++) {
                Document doc = hits.doc(i + pagingOffset);
                Map<String, String> row = new HashMap<String, String>();
                // row.put("Score", String.valueOf(hits.score(i +
                // pagingOffset)));
                row.put(Strings.Response.ItemList.name, doc.get(Strings.Index.Item.namePrefix + lang));
                row.put(Strings.Response.ItemList.description, doc.get(Strings.Index.Item.descriptionPrefix + lang));
                row.put(Strings.Response.ItemList.manufacturerName, doc.get(Strings.Index.Item.manufacturerName));
                row.put(Strings.Response.ItemList.mainCategoryName, doc.get(Strings.Index.Item.mainCategoryNamePrefix
                        + lang));
                rows.put(doc.get(Strings.Index.Item.itemId), row);
            }
        } catch (IOException e) {
            LOG.error("Error during hits retrieval", e);
            throw new PipelineRuntimeException(e);
        }
        return rows;
    }

    /**
     * Creates a QueryParser object for parsing price query.
     * 
     * @return
     */
    private QueryParser createQueryParser() {
        // Strings.Index.Item.price is the default field, but the field is
        // always specified in the queries
        QueryParser qp = new QueryParser(Strings.Index.Item.price, new IndexerStage.MyAnalyzer());
        return qp;
    }

    /**
     * Creates a range query.
     * 
     * @param min
     * @param max
     * @return
     */
    private String getQueryMinToMax(String min, String max) {
        // [min TO max]
        // [] - inclusive search
        return "[" + min + " TO " + max + "]";
    }

    /**
     * Creates a price field of format price_customerid_currencycode.
     * 
     * @param userGroupId
     * @param currencyCode
     * @return
     */
    private String getPriceField(String userGroupId, String currencyCode) {
        String ret = Strings.Index.Item.pricePrefix + userGroupId + "_" + currencyCode;
        return ret.toLowerCase();
    }

    /**
     * Creates a price field of format price_listprice_netprice_currencycode.
     * 
     * @param listPriceGroupId
     * @param netPriceGroupId
     * @param currencyCode
     * @return
     */
    private String getPriceField(String listPriceGroupId, String netPriceGroupId, String currencyCode) {
        String ret = Strings.Index.Item.pricePrefix + listPriceGroupId + "_" + netPriceGroupId + "_" + currencyCode;
        return ret.toLowerCase();
    }

    /**
     * Creates a price field of format
     * price_listprice_netprice_customerid_currencycode.
     * 
     * @param listPriceGroupId
     * @param netPriceGroupId
     * @param userGroupId
     * @param currencyCode
     * @return
     */
    private String getPriceField(String listPriceGroupId, String netPriceGroupId, String userGroupId,
            String currencyCode) {
        String ret = Strings.Index.Item.pricePrefix + listPriceGroupId + "_" + netPriceGroupId + "_" + userGroupId
                + "_" + currencyCode;
        return ret.toLowerCase();
    }

    /**
     * Creates the tax price field
     * 
     * @param userGroupId
     * @param currencyCode
     * @param countryCode
     * @return
     */
    private String getTaxPriceField(String userGroupId, String currencyCode, String countryCode) {
        String ret = Strings.Index.Item.taxPricePrefix + userGroupId + "_" + currencyCode + "_" + countryCode;
        return ret.toLowerCase();
    }

    /**
     * Creates the tax price field
     * 
     * @param listPriceGroupId
     * @param netPriceGroupId
     * @param currencyCode
     * @param countryCode
     * @return
     */
    private String getTaxPriceField(String listPriceGroupId, String netPriceGroupId, String currencyCode,
            String countryCode) {
        String ret = Strings.Index.Item.taxPricePrefix + listPriceGroupId + "_" + netPriceGroupId + "_" + currencyCode
                + "_" + countryCode;
        return ret.toLowerCase();
    }

    /**
     * Creates the tax price field
     * 
     * @param listPriceGroupId
     * @param netPriceGroupId
     * @param userGroupId
     * @param currencyCode
     * @param countryCode
     * @return
     */
    private String getTaxPriceField(String listPriceGroupId, String netPriceGroupId, String userGroupId,
            String currencyCode, String countryCode) {
        String ret = Strings.Index.Item.taxPricePrefix + listPriceGroupId + "_" + netPriceGroupId + "_" + userGroupId
                + "_" + currencyCode + "_" + countryCode;
        return ret.toLowerCase();
    }

    /**
     * Returns the conversion rate. Conversion rate = alternate exchange
     * rate/exchange rate.
     * 
     * @return
     */
    private BigDecimal getConversionRate() {
        BigDecimal alternateExchangeRate = new BigDecimal(request.getAlternateExchangeRate());
        BigDecimal exchangeRate = new BigDecimal(request.getExchangeRate());

        if (exchangeRate.compareTo(Decimal.ZERO) < 1) {
            throw new IllegalArgumentException(
                    "The supplied exchange rate was negative or zero, it must a positive number");
        }

        if (alternateExchangeRate.compareTo(Decimal.ZERO) < 0) {
            throw new IllegalArgumentException(
                    "The supplied alternative exchange rate was negative or zero, it must a positive number");
        }

        int scale = getScale(alternateExchangeRate, exchangeRate);
        return alternateExchangeRate.divide(exchangeRate, scale, BigDecimal.ROUND_HALF_UP);
    }

    /**
     * Returns the scale for BigDecimal division.
     * 
     * @param val1
     * @param val2
     * @return
     */
    private int getScale(BigDecimal val1, BigDecimal val2) {
        // Based on CalcuateAltCurrency
        // Trying to set scale depending on the size of the result. But is this
        // necessary?
        int scale = 20;
        if (val1.compareTo(val2.multiply(new BigDecimal("1000000000"))) == 1) {
            // if x/y < 10E-10 ==>> y > x*10E10
            // then dealing with small numbers. Set scale to 30
            scale = 30;
        } else if (val2.compareTo(val1.multiply(new BigDecimal("1000000000"))) == 1) {
            // if x/y > 10E10 ==>> x > y*10E10
            // then dealing with huge a number. Set scale to 0
            scale = 0;
        }

        return scale;
    }

    /**
     * Creates a query for price search with display currency different from
     * currency.
     * 
     * @param listPriceGroupId
     * @param netPriceGroupId
     * @param userGroupId
     * @param minPrice
     * @param maxPrice
     * @param currencyCode
     * @param alternateCurrencyCode
     * @return
     */
    private String createQueryDifferentCurrency(String listPriceGroupId, String netPriceGroupId, String userGroupId,
            BigDecimal minPrice, BigDecimal maxPrice, String currencyCode, String alternateCurrencyCode) {

        // query = (alternate currency query) OR (currency query)

        // create a query for the alternate currency.
        // no conversion is done because when user searches, the display
        // currency is being used.
        StringBuffer buf = new StringBuffer();
        String query = createPriceQuery(listPriceGroupId, netPriceGroupId, userGroupId, minPrice, maxPrice,
                alternateCurrencyCode, false);

        buf.append(GROUP_START);
        buf.append(query);
        buf.append(GROUP_END);

        buf.append(OR);

        buf.append(GROUP_START);
        // converted value = price/conversion rate
        BigDecimal conversionRate = getConversionRate();
        BigDecimal convertedMinPrice = minPrice.divide(conversionRate, getScale(minPrice, conversionRate),
                BigDecimal.ROUND_HALF_DOWN);
        BigDecimal convertedMaxPrice = maxPrice.divide(conversionRate, getScale(maxPrice, conversionRate),
                BigDecimal.ROUND_HALF_UP);
        // create a query for the default currency
        query = createPriceQuery(listPriceGroupId, netPriceGroupId, userGroupId, convertedMinPrice, convertedMaxPrice,
                currencyCode, true);
        buf.append(query);
        buf.append(GROUP_END);

        return buf.toString();
    }

    /**
     * Creates a query for tax price search with display currency different from
     * currency.
     * 
     * @param listPriceGroupId
     * @param netPriceGroupId
     * @param userGroupId
     * @param minPrice
     * @param maxPrice
     * @param countryCode
     * @param currencyCode
     * @param alternateCurrencyCode
     * @return
     */
    private String createTaxQueryDifferentCurrency(String listPriceGroupId, String netPriceGroupId, String userGroupId,
            BigDecimal minPrice, BigDecimal maxPrice, String countryCode, String currencyCode,
            String alternateCurrencyCode) {

        // query = (alternate currency query) OR (currency query)

        // create a query for the alternate currency.
        // no conversion is done because when user searches, the display
        // currency is being used.
        StringBuffer buf = new StringBuffer();
        String query = createTaxPriceQuery(listPriceGroupId, netPriceGroupId, userGroupId, minPrice, maxPrice,
                countryCode, alternateCurrencyCode, false);

        buf.append(GROUP_START);
        buf.append(query);
        buf.append(GROUP_END);

        buf.append(OR);

        buf.append(GROUP_START);
        // converted value = price/conversion rate
        BigDecimal conversionRate = getConversionRate();
        BigDecimal convertedMinPrice = minPrice.divide(conversionRate, getScale(minPrice, conversionRate),
                BigDecimal.ROUND_HALF_DOWN);
        BigDecimal convertedMaxPrice = maxPrice.divide(conversionRate, getScale(maxPrice, conversionRate),
                BigDecimal.ROUND_HALF_UP);
        // create a query for the default currency
        query = createTaxPriceQuery(listPriceGroupId, netPriceGroupId, userGroupId, convertedMinPrice,
                convertedMaxPrice, countryCode, currencyCode, true);
        buf.append(query);
        buf.append(GROUP_END);

        return buf.toString();

    }

    /**
     * Creates a price query. Checks if the default currency is different from
     * the display currency.
     * 
     * @param minPrice
     * @param maxPrice
     * @return
     */
    private String createPriceQuery(BigDecimal minPrice, BigDecimal maxPrice) {
        boolean executeIncludeTax = Boolean.valueOf(request.getExecuteIncludeTax());
        String currencyCode = request.getCurrencyCode();
        String alternateCurrencyCode = request.getAlternateCurrencyCode();
        String listPriceGroupId = request.getListPriceGroupId();
        String netPriceGroupId = request.getResellPriceGroupId();
        String userGroupId = request.getUserGroupId();
        if (executeIncludeTax == true) {
            String countryCode = request.getShippingCountryCode();
            if (currencyCode.equalsIgnoreCase(alternateCurrencyCode) == false) {
                // create a query with search prices converted to default
                // currency
                return createTaxQueryDifferentCurrency(listPriceGroupId, netPriceGroupId, userGroupId, minPrice,
                        maxPrice, countryCode, currencyCode, alternateCurrencyCode);
            } else {
                // create a price query using default currency
                return createTaxPriceQuery(listPriceGroupId, netPriceGroupId, userGroupId, minPrice, maxPrice,
                        countryCode, currencyCode, true);
            }
        } else {
            if (currencyCode.equalsIgnoreCase(alternateCurrencyCode) == false) {
                // create a query with search prices converted to default
                // currency
                return createQueryDifferentCurrency(listPriceGroupId, netPriceGroupId, userGroupId, minPrice, maxPrice,
                        currencyCode, alternateCurrencyCode);
            } else {
                // create a price query using default currency
                return createPriceQuery(listPriceGroupId, netPriceGroupId, userGroupId, minPrice, maxPrice,
                        currencyCode, true);
            }
        }
    }

    private void appendPriceQuery(StringBuffer buf, String fieldName, String queryMinToMax, List<String> previousFields) {
        if (previousFields.isEmpty() == false) {
            buf.append(OR);
        }

        buf.append(GROUP_START);
        buf.append(fieldName + SEPARATOR + queryMinToMax);

        if (previousFields.isEmpty() == false) {
            Iterator<String> it = previousFields.iterator();
            while (it.hasNext() == true) {
                buf.append(NOT);

                String prevField = it.next();
                buf.append(prevField + PRICEEXISTS);
            }
        }

        buf.append(GROUP_END);
    }

    /**
     * Creates a price query.
     * 
     * @param listPriceGroupId
     * @param netPriceGroupId
     * @param userGroupId
     * @param bdMinPrice
     * @param bdMaxPrice
     * @param currencyCode
     * @param includeDefaultPrice
     * @return
     */
    private String createPriceQuery(String listPriceGroupId, String netPriceGroupId, String userGroupId,
            BigDecimal bdMinPrice, BigDecimal bdMaxPrice, String currencyCode, boolean includeDefaultPrice) {

        // A = price list with customer price (ex.
        // price_listprice_netprice_customerid)
        // A2 = price list with customer price (ex.
        // price_netprice_netprice_customerid)
        // B = price list and no customer price (ex. price_listprice_netprice)
        // B2 = price list and no customer price (ex. price_netprice_netprice)
        // C = customer price only (ex. price_customerid)
        // D = default price (0.0) (ie. price)
        // Query = A OR (B NOT A) OR (B2 NOT A NOT B) OR (C NOT A NOT B NOT B2)
        // OR (D NOT A NOT B NOT B2 NOT C)
        String priceFieldListNetUser = getPriceField(listPriceGroupId, netPriceGroupId, userGroupId, currencyCode);
        String priceFieldNetNetUser = getPriceField(netPriceGroupId, netPriceGroupId, userGroupId, currencyCode);
        String priceFieldListNet = getPriceField(listPriceGroupId, netPriceGroupId, currencyCode);
        String priceFieldNetNet = getPriceField(netPriceGroupId, netPriceGroupId, currencyCode);
        String priceFieldUser = getPriceField(userGroupId, currencyCode);
        String minPrice = SearchUtils.toPaddedString(bdMinPrice);
        String maxPrice = SearchUtils.toPaddedString(bdMaxPrice);
        String queryMinToMax = getQueryMinToMax(minPrice.toLowerCase(), maxPrice.toLowerCase());

        List<String> previousFields = new ArrayList<String>();
        StringBuffer buf = new StringBuffer();

        // Create query A
        appendPriceQuery(buf, priceFieldListNetUser, queryMinToMax, previousFields);
        previousFields.add(priceFieldListNetUser);

        // Create query A2
        appendPriceQuery(buf, priceFieldNetNetUser, queryMinToMax, previousFields);
        previousFields.add(priceFieldNetNetUser);

        // Create query B
        appendPriceQuery(buf, priceFieldListNet, queryMinToMax, previousFields);
        previousFields.add(priceFieldListNet);

        // Create query B2
        appendPriceQuery(buf, priceFieldNetNet, queryMinToMax, previousFields);
        previousFields.add(priceFieldNetNet);

        // Create query C
        appendPriceQuery(buf, priceFieldUser, queryMinToMax, previousFields);
        previousFields.add(priceFieldUser);

        // Create query D
        // default price is not included if this query is for the display
        // currency
        // because the "price" field is for the default currency only
        if (includeDefaultPrice == true) {
            appendPriceQuery(buf, Strings.Index.Item.price, queryMinToMax, previousFields);
        }

        return buf.toString();
    }

    /**
     * Creates a price query.
     * 
     * @param listPriceGroupId
     * @param netPriceGroupId
     * @param userGroupId
     * @param bdMinPrice
     * @param bdMaxPrice
     * @param currencyCode
     * @param includeDefaultPrice
     * @return
     */
    private String createTaxPriceQuery(String listPriceGroupId, String netPriceGroupId, String userGroupId,
            BigDecimal bdMinPrice, BigDecimal bdMaxPrice, String countryCode, String currencyCode,
            boolean includeDefaultPrice) {

        // A = tax price list with customer price
        // B = tax price list and no customer price
        // B2 = tax price list and no customer price (net price only)
        // C = tax customer price only
        // D = price list with customer price
        // E = price list and no customer price
        // E2 = price list and no customer price (net price only)
        // F = customer price only
        // G = customer price only
        // Query = A OR (B NOT A) OR (C NOT A NOT B) OR (D NOT A NOT B NOT C)
        // OR E (NOT A NOT B NOT C NOT D) OR F (NOT A NOT B NOT C NOT D NOT E)
        // OR G (NOT A NOT B NOT C NOT D NOT E NOT F)
        String taxPriceFieldListNetUser = getTaxPriceField(listPriceGroupId, netPriceGroupId, userGroupId,
                currencyCode, countryCode);
        String taxPriceFieldNetNetUser = getTaxPriceField(netPriceGroupId, netPriceGroupId, userGroupId, currencyCode,
                countryCode);
        String taxPriceFieldListNet = getTaxPriceField(listPriceGroupId, netPriceGroupId, currencyCode, countryCode);
        String taxPriceFieldNetNet = getTaxPriceField(netPriceGroupId, netPriceGroupId, currencyCode, countryCode);
        String taxPriceFieldUser = getTaxPriceField(userGroupId, currencyCode, countryCode);
        String minPrice = SearchUtils.toPaddedString(bdMinPrice);
        String maxPrice = SearchUtils.toPaddedString(bdMaxPrice);
        String queryMinToMax = getQueryMinToMax(minPrice.toLowerCase(), maxPrice.toLowerCase());

        StringBuffer buf = new StringBuffer();
        List<String> previousFields = new ArrayList<String>();

        // Create query A
        appendPriceQuery(buf, taxPriceFieldListNetUser, queryMinToMax, previousFields);
        previousFields.add(taxPriceFieldListNetUser);

        // Create query A2
        appendPriceQuery(buf, taxPriceFieldNetNetUser, queryMinToMax, previousFields);
        previousFields.add(taxPriceFieldNetNetUser);

        // Create query B
        appendPriceQuery(buf, taxPriceFieldListNet, queryMinToMax, previousFields);
        previousFields.add(taxPriceFieldListNet);

        // B2
        appendPriceQuery(buf, taxPriceFieldNetNet, queryMinToMax, previousFields);
        previousFields.add(taxPriceFieldNetNet);

        // Create query C
        appendPriceQuery(buf, taxPriceFieldUser, queryMinToMax, previousFields);
        previousFields.add(taxPriceFieldUser);

        String priceFieldListNetUser = getPriceField(listPriceGroupId, netPriceGroupId, userGroupId, currencyCode);
        String priceFieldNetNetUser = getPriceField(netPriceGroupId, netPriceGroupId, userGroupId, currencyCode);
        String priceFieldListNet = getPriceField(listPriceGroupId, netPriceGroupId, currencyCode);
        String priceFieldNetNet = getPriceField(netPriceGroupId, netPriceGroupId, currencyCode);
        String priceFieldUser = getPriceField(userGroupId, currencyCode);

        // Create query D
        appendPriceQuery(buf, priceFieldListNetUser, queryMinToMax, previousFields);
        previousFields.add(priceFieldListNetUser);

        // D2
        appendPriceQuery(buf, priceFieldNetNetUser, queryMinToMax, previousFields);
        previousFields.add(priceFieldNetNetUser);

        // Create query E
        appendPriceQuery(buf, priceFieldListNet, queryMinToMax, previousFields);
        previousFields.add(priceFieldListNet);

        // E2
        appendPriceQuery(buf, priceFieldNetNet, queryMinToMax, previousFields);
        previousFields.add(priceFieldNetNet);

        // Create query F
        appendPriceQuery(buf, priceFieldUser, queryMinToMax, previousFields);
        previousFields.add(priceFieldUser);

        if (includeDefaultPrice == true) {
            // Create query G
            appendPriceQuery(buf, Strings.Index.Item.price, queryMinToMax, previousFields);
        }

        return buf.toString();
    }

    /**
     * Returns the maximum value that can be rounded down as the input.
     * 
     * @param input
     * @param decimalPlaces
     * @return
     */
    private String getMaxNumberRoundAs(String input, int decimalPlaces) {
        // this is how the database is defined
        int numberOfPlaces = 4;
        int decimalIndex = input.indexOf(".");
        String ret = "";
        if (decimalIndex != -1) {
            ret = input.substring(0, decimalIndex + 1);
        } else {
            ret = input + ".";
            decimalIndex = input.length();
        }

        int valAtIndex = 0;
        for (int i = 0; i < numberOfPlaces; i++) {
            int idx = decimalIndex + 1 + i;
            char c = '0';
            if (idx < input.length()) {
                c = input.charAt(idx);
            }
            if (i == (decimalPlaces - 1)) {
                valAtIndex = Integer.parseInt(c + "");
            }
            if (i < decimalPlaces) {
                ret += c;
            } else if (i == decimalPlaces) {
                // if odd, append 49--
                // if even, append 50--
                if (valAtIndex % 2 == 1) {
                    ret += "4";
                } else {
                    ret += "5";
                }
            } else {
                if (valAtIndex % 2 == 1) {
                    ret += "9";
                } else {
                    ret += "0";
                }
            }
        }

        return ret;
    }

    /**
     * Returns the minimum value that can be rounded up as the input.
     * 
     * @param input
     * @param decimalPlaces
     * @return
     */
    private String getMinNumberRoundAs(String input, int decimalPlaces) {
        BigDecimal bdInput = new BigDecimal(input);
        String ret = "0.0";

        // for non-zero inputs
        if (BigDecimal.ZERO.compareTo(bdInput) != 0) {
            // subtract 0.1^decimalPlaces from input.
            // append 50- to the difference

            // get 0.1^decimalPlaces
            BigDecimal subtrahend = new BigDecimal("1");
            for (int i = 0; i < decimalPlaces; i++) {
                subtrahend = subtrahend.multiply(new BigDecimal("0.1"));
            }

            // retrieve difference
            BigDecimal minVal = bdInput.subtract(subtrahend);

            // if minVal >= 0
            if (minVal.compareTo(BigDecimal.ZERO) >= 0) {
                String difference = minVal.toString();

                // this is how the database is defined
                int numberOfPlaces = 4;
                int decimalIndex = difference.indexOf(".");

                if (decimalIndex != -1) {
                    ret = difference.substring(0, decimalIndex + 1);
                } else {
                    ret = difference + ".";
                    decimalIndex = difference.length();
                }

                for (int i = 0; i < numberOfPlaces; i++) {
                    int idx = decimalIndex + 1 + i;
                    char c = '0';
                    if (idx < difference.length()) {
                        c = difference.charAt(idx);
                    }

                    if (i < decimalPlaces) {
                        ret += c;
                    } else if (i == decimalPlaces) {
                        ret += "5";
                    } else {
                        ret += "0";
                    }
                }
            }
        }

        return ret;
    }

    private Locale getLocale(String languageCode) {
        return new Locale(languageCode);
    }

    private String unformatDecimal(String value, String languageCode) throws ParseException, java.text.ParseException {
        NumberFormat nf = NumberFormat.getNumberInstance(getLocale(languageCode));
        Number n = nf.parse(value);

        if (n instanceof com.ibm.icu.math.BigDecimal) {
            return ((com.ibm.icu.math.BigDecimal) n).toString();
        }
        if (n instanceof BigDecimal) {
            return ((BigDecimal) n).toString();
        } else if (n instanceof java.lang.Double) {
            return (new BigDecimal(n.doubleValue())).toString();
        } else if (n instanceof java.lang.Long) {
            return (new BigDecimal(n.doubleValue())).toString();
        } else {
            FastStringBuffer error = new FastStringBuffer();
            error.append("Could not parse as decimal: ");
            error.append(value);
            error.append(". Parser returned unknown decimal type: ");
            error.append(n.getClass());
            throw new ParseException(error.toString());
        }
    }

    /**
     * Returns a Query for prices. Returns null if no price search is needed.
     * 
     * @return
     * @throws ParseException
     * @throws PipelineRuntimeException
     * @throws java.text.ParseException
     */
    private Query getQuery() throws ParseException, PipelineRuntimeException, java.text.ParseException {
        Query q = null;
		String queryString = "";


        if (Boolean.valueOf(CustomStagesHelper.getKeyValue("Application.M3 API")).booleanValue() == false) {
            String searchMinPrice = null;
            String searchMaxPrice = null;

            // B2B and B2C have different input fields for min and max prices
            if (Strings.Request.SearchOrigin.B2B_FILTER.equals(request.getSearchRequestOrigin()) == true) {
                searchMinPrice = request.getMinPrice();
                searchMaxPrice = request.getMaxPrice();
            } else if ((Strings.Request.SearchOrigin.B2C.equals(request.getSearchRequestOrigin()) == true)
                    && (Boolean.valueOf(request.getNetListPriceNotNull()).booleanValue() == true)) {
                searchMinPrice = request.getMinNetListPrice();
                searchMaxPrice = request.getMaxNetListPrice();
            }

            if ((searchMinPrice != null && !"empty".equals(searchMinPrice))
                    || (searchMaxPrice != null && !"empty".equals(searchMaxPrice))) {
                BigDecimal minPrice = null;
                BigDecimal maxPrice = null;
                int currencyDecimal = Integer.parseInt(request.getCurrencyDecimal());

                if (searchMinPrice == null || "empty".equals(searchMinPrice) == true) {
                    // set minimum price to minimum possible
                    minPrice = SearchUtils.MIN_SEARCH_PRICE;
                } else {
                    String unformattedString = unformatDecimal(searchMinPrice, request.getLanguageCode());
                    minPrice = new BigDecimal(getMinNumberRoundAs(unformattedString, currencyDecimal));
                }

                if (searchMaxPrice == null || "empty".equals(searchMaxPrice) == true) {
                    // set maximum price to maximum possible
                    maxPrice = SearchUtils.MAX_SEARCH_PRICE;
                } else {
                    String unformattedString = unformatDecimal(searchMaxPrice, request.getLanguageCode());
                    maxPrice = new BigDecimal(getMaxNumberRoundAs(unformattedString, currencyDecimal));
                }

                QueryParser qp = createQueryParser();
                queryString = createPriceQuery(minPrice, maxPrice);
                LOG.debug("Query string: " + queryString);
                q = qp.parse(queryString);
            }
        }

    	String searchRequestOrigin = request.getSearchRequestOrigin();
    	String wildcardSearch = request.getWildcardSearch();
    	boolean useWildcardSearch = false;
    	if (searchRequestOrigin != null && wildcardSearch != null &&
    		wildcardSearch.equals(searchRequestOrigin) == true) {
    		useWildcardSearch = true;
    	}
    	if (useWildcardSearch == false) {
    		return q;
    	}
    	
    	if (request.getSearchRequestOrigin().equals(Strings.Request.SearchOrigin.B2B_QUICKSEARCH) || request.getSearchRequestOrigin().equals(Strings.Request.SearchOrigin.B2C)) {
    		if (request.getQuickSearchString() != null && !"empty".equals(request.getQuickSearchString())) {
    			String searchText = request.getQuickSearchString().toLowerCase();
    			String[] words = searchText.split(" or "); // TODO: search string delimiter is misleading where in fact the search operation is "AND"
    			String fieldName = Strings.Index.Item.fullTextPrefix + lang;
    			queryString = queryString + fieldName + SEPARATOR + GROUP_START;
    			int i = 0;
    			for (String word : words) {
    				word = word.substring(1, word.length() - 1); // Remove the quotes
    				word = WILDCARD + QueryParser.escape(word) + WILDCARD;
    				if (i > 0) {
    					queryString = queryString + AND + SPACE;
    				}
    				queryString = queryString + word + SPACE;
    				i++;
    			}
    			queryString = queryString + GROUP_END + SPACE + OR + SPACE;
    			
    			String[] words1 = searchText.split(" or "); // TODO: search string delimiter is misleading where in fact the search operation is "AND"
    			String fieldName1 = Strings.Index.Item.customerItemIdTokenizedPrefix + request.getUserGroupId();
    			queryString = queryString + fieldName1 + SEPARATOR + GROUP_START;
    			int i1 = 0;
    			for (String word : words1) {
    				word = word.substring(1, word.length() - 1); // Remove the quotes
    				word = WILDCARD + QueryParser.escape(word) + WILDCARD;
    				if (i1 > 0) {
    					queryString = queryString + AND + SPACE;
    				}
    				queryString = queryString + word + SPACE;
    				i1++;
    			}
    			queryString = queryString + GROUP_END + SPACE;    			    			
    			
    		}
    		
    	} else if (request.getSearchRequestOrigin().equals(Strings.Request.SearchOrigin.B2B_FILTER)) {
    		String searchNumber = request.getItemNumber();    		
    		String searchCustomerID = request.getCustomerItemID();
    		String searchName = request.getItemName();
    		String searchSupplier = request.getSupplierId();
    		String searchSerial = null;
    		
    		if (request instanceof EquipmentRequest) {
    			EquipmentRequest req = (EquipmentRequest) request;
    			searchSerial = req.getSerialNumber();
    			String fieldName = EquipmentStrings.Index.Equipment.serialNumber;
    			
    			if (searchSerial != null && !"empty".equals(searchSerial)) {
        			queryString = queryString + fieldName + SEPARATOR + GROUP_START;
        			String[] words = searchSerial.split(" ");
        			int i = 0;
        			for (String word : words) {
        				word = WILDCARD + QueryParser.escape(word.toLowerCase()) + WILDCARD;
        				if (i > 0) {
        					queryString = queryString + AND + SPACE;
        				}
        				queryString = queryString + word + SPACE;
        				i++;
        			}
        			queryString = queryString + GROUP_END + SPACE;    				
    			}   
    		}
    		
    		if (searchNumber != null && !"empty".equals(searchNumber)){ // TODO means you can search an "empty" word
    			String fieldName = Strings.Index.Item.itemNumber ;
    			queryString = queryString + fieldName + SEPARATOR + GROUP_START;
    			String[] words = searchNumber.split(" ");
    			int i = 0;
    			for (String word : words) {
    				word = WILDCARD + QueryParser.escape(word.toLowerCase()) + WILDCARD;
    				if (i > 0) {
    					queryString = queryString + AND + SPACE;
    				}
    				queryString = queryString + word + SPACE;
    				i++;
    			}
    			queryString = queryString + GROUP_END + SPACE;				
    		}
    		
    		if (searchCustomerID != null && !"empty".equals(searchCustomerID)) { 
    			String fieldName = Strings.Index.Item.customerItemIdPrefix + request.getUserGroupId();
    			queryString = queryString + fieldName + SEPARATOR + GROUP_START;
    			String[] words = searchCustomerID.split(" ");
    			int i = 0;
    			for (String word : words) {
    				word = WILDCARD + QueryParser.escape(word.toLowerCase()) + WILDCARD;
    				if (i > 0) {
    					queryString = queryString + AND + SPACE;
    				}
    				queryString = queryString + word + SPACE;
    				i++;
    			}
    			queryString = queryString + GROUP_END + SPACE;
    		}
    		
    		if (searchName != null && !"empty".equals(searchName)) { // TODO means you can't search an "empty" word
    			String fieldName = Strings.Index.Item.nameTokenizedPrefix + lang;
    			queryString = queryString + fieldName + SEPARATOR + GROUP_START;
    			String[] words = searchName.split(" ");
    			int i = 0;
    			for (String word : words) {
    				word = WILDCARD + QueryParser.escape(word.toLowerCase()) + WILDCARD;
    				if (i > 0) {
    					queryString = queryString + AND + SPACE;
    				}
    				queryString = queryString + word + SPACE;
    				i++;
    			}
    			queryString = queryString + GROUP_END + SPACE;
    		}
    		if (searchSupplier != null && !"empty".equals(searchSupplier)) { // TODO means you can't search an "empty" word
    			queryString = queryString + Strings.Index.Item.supplierId + SEPARATOR + GROUP_START;
    			queryString = queryString + WILDCARD +
    			QueryParser.escape(searchSupplier.toLowerCase()) + WILDCARD;
    			queryString = queryString + GROUP_END + SPACE;
    		}
    	}

    	if (queryString != "") {
    		try {
    			BooleanQuery.setMaxClauseCount(Integer.MAX_VALUE);
    			QueryParser qp = createQueryParser();
    			qp.setDefaultOperator(Operator.AND);
    			qp.setAllowLeadingWildcard(true);
    			q = qp.parse(queryString);
    		} catch (ParseException e) {
    			throw new PipelineRuntimeException("Parse exception", e);
    		}
    	}            
		
        return q;
    }
    
    protected CachedChainedFilter getDefaultFilters() throws PipelineRuntimeException {
    	return helper.getStandardFilters(queries, request, dataholder);
    }    
}
