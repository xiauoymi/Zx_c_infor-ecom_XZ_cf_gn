package com.intentia.iec.pipeline.runtime.stage.custom.search.sps;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.search.DataHolder;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Database;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Response;
import com.intentia.iec.pipeline.runtime.stage.custom.search.SearchUtils;

/**
 * Class for searching spare parts. This is called when the SpareParts List is accessed.
 */
public class SPSItemListStage extends AbstractSPSItemListStage {

    /**
     * Default constructor. Creates objects that are specific to indexing spare parts.
     * @throws PipelineRuntimeException
     */
    public SPSItemListStage() throws PipelineRuntimeException {
        request = new SPSRequest();
        response = new Response();
        helper = new SearchUtils();
        queries = new SPSDatabaseImpl();
        dataholder = SPSManagerImpl.getInstance().getDataHolder();
    }

    /**
     * Copies the parameters.
     * @param queries
     * @param dataholder
     * @throws PipelineRuntimeException
     */
    public SPSItemListStage(Database queries, DataHolder dataholder) throws PipelineRuntimeException {
        request = new SPSRequest();
        response = new Response();
        helper = new SearchUtils();
        this.queries = queries;
        this.dataholder = dataholder;
    } 
}
