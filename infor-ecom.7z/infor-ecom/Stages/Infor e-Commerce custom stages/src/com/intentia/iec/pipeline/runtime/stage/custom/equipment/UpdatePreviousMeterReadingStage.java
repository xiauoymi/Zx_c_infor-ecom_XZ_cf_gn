package com.intentia.iec.pipeline.runtime.stage.custom.equipment;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;

/**
 * This class copies the previous meter reading values into the next meter reading line.
 * This is done so that the Google Chart can display the current reading for all meters for a particular day.  
 *
 */
public class UpdatePreviousMeterReadingStage implements PipelineStage {
	private static final Logger LOG = Logger.getLogger(UpdatePreviousMeterReadingStage.class);
	
	private static final String MAINSET_METERS = "resultset/row";
	
	private static final String ATTRIBUTE_METER1 = "SinceNew";
	
	private static final String ATTRIBUTE_METER2 = "SinceNew2";
	
	private static final String ATTRIBUTE_METER3 = "SinceNew3";
	
	private static final String ATTRIBUTE_METER4 = "SinceNew4";

	public void execute(PipelineContext context) throws PipelineRuntimeException {
        // Retrieve XML request from context
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
        
        if (context.getResponse() instanceof XMLResultset) {
        	try {
        		updatePreviousMeters((XMLResultset)context.getResponse());
			} catch (Exception e) {
				LOG.error(e);
			}
        }		
	}
	
	/**
	 * Replaces the meter reading with the previous value. The previous value is then returned.
	 * @param e
	 * @param attributeName
	 * @param previous
	 * @return
	 */
	private double replace(Element e, String attributeName, double previous) {
		// if no attribute exist, set to the previous value
		if (e.getAttribute(attributeName) == null || "".equals(e.getAttribute(attributeName))) {
			e.setAttribute(attributeName, Double.toString(previous));
			
			return previous;
		}
		else {
			// if the attribute is set, get the attribute value and return as previous
			try {
				return Double.parseDouble(e.getAttribute(attributeName));	
			}
			catch (Exception x) {				
				// disregard
			}			
		}
		return previous;
	}
	
	/**
	 * Iterates through all meter readings, copying the previous readings to the next.
	 * @param response
	 * @throws ResultsetException
	 * @throws TransformerException
	 */
	private void updatePreviousMeters(XMLResultset response) throws ResultsetException, TransformerException {
		if (response != null) {
			Document xmlDoc = response.getDocument();
			NodeList nodeList = XPathAPI.selectNodeList(xmlDoc, MAINSET_METERS);
			double previous1 = 0.0;
			double previous2 = 0.0;
			double previous3 = 0.0;
			double previous4 = 0.0;
			
			for (int i = 0; i < nodeList.getLength(); i++) {
				Element e = (Element) nodeList.item(i);
				
				previous1 = replace(e, ATTRIBUTE_METER1, previous1);
				previous2 = replace(e, ATTRIBUTE_METER2, previous2);
				previous3 = replace(e, ATTRIBUTE_METER3, previous3);
				previous4 = replace(e, ATTRIBUTE_METER4, previous4);
			}
		}
	}

}
