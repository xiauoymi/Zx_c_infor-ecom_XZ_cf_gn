/*
 * Created on 21-06-2006
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.util.FastStringBuffer;

/**
 * <p>
 * The <code>ReplaceCategoryIdBinding</code> stage replace all bindings made
 * on the CategoryID attribute in a Category subset. The binding is replaced by
 * two bindings on the High and Low attributes in the Category subset. The
 * bindings are created such that High&le;<tt>catHighValue</tt> and
 * <tt>Low&ge;catLowValue</tt>, where ;<tt>catHighValue</tt> and
 * <tt>Low&lt;catLowValue</tt> has the High and Low values of the Category for
 * which CategoryID=<tt>bindingvalue</tt>.
 * </p>
 * 
 * <p>
 * Inserting <code>ReplaceCategoryIdBinding</code> in a find method on for
 * example the Item business object has the value, that one can have all items
 * returned that are descendant of a category with a specific CategoryID
 * </p>
 * 
 * <pre>
 *          &lt;b&gt;Example:&lt;/b&gt;
 *          The category &quot;parentCat&quot; has the following category hierarchy
 *          
 *          parentCat 
 *               childCat1    
 *                   grandChildCat11 
 *                   grandChildCat12 
 *                       greatGrandChildCat111
 *               childCat2
 *                   grandChildCat21
 *                    
 *          and the request has the following binding
 *          &lt;binding name=&quot;CategoryID&quot; value=&quot;parentCat&quot; operator=&quot;eq&quot;&gt;
 *          the stage then changes this to
 *          &lt;bindings operator=&quot;or&quot;&gt;
 *          &lt;binding name=&quot;High&quot; value=&quot;parentCatHigh&quot; operator=&quot;le&quot;&gt;
 *          &lt;binding name=&quot;Low&quot; value=&quot;parentCatLow&quot; operator=&quot;ge&quot;&gt;
 *          &lt;/bindings&gt;
 * </pre>
 * 
 * and the find stage being after <code>ReplaceCategoryIdBinding</code> in the
 * find method will return all items being attached to any of the categories in
 * the above tree.
 * 
 * <p>
 * <b>Required input in <code>PipelineContext</code>:</b><br>
 * XML request with a binding on the CategoryID attribute in the Category
 * subset.
 * </p>
 * 
 * <p>
 * <b>Generated output in <code>PipelineContext</code>:</b><br>
 * Modified XML request where bindings on the High and Low attributes replaces
 * the binding on the CategoryID attribute in the Category subset.
 * </p>
 */

public final class ReplaceCategoryIdBinding extends AbstractPipelineStage {
    private static final Logger LOG = Logger.getLogger(ReplaceCategoryIdBinding.class);

    // fieldnames for procedure parameters
    private static final String CATEGORY_ID = "CategoryID";

    // strings for getting and setting attributes
    private static final String NAME_ATTR = "name";

    private static final String ATTRIBUTE_ATTR = "attribute";

    private static final String VALUE_ATTR = "value";

    private static final String OPERATOR_ATTR = "operator";

    // string for element tag names
    private static final String BINDING_TAG = "binding";

    // strings for High Attribute
    private static final String HIGH = "High";

    // strings for Low Attribute
    private static final String LOW = "Low";

    // strings for operators
    private static final String LESS_THAN_OR_EQUAL = "le";

    // strings for operators
    private static final String GREATER_THAN_OR_EQUAL = "ge";

    /**
     * <p>
     * Replace bindings on the CategoryID with two bindings on the High and Low
     * attributes.
     * </p>
     * 
     * @throws PipelineRuntimeException
     *             if the request in <code>PipelineContext</code> is not of
     *             type <code>XMLRequest</code> or obtaining the request as a
     *             <code>Document</code> object fails.
     * @see com.intentia.iec.pipeline.runtime.PipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
     */
    public void execute(final PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("inside ProductAddCategoryHierarchy.execute()!");

        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Request must be of type XMLRequest!");
        }

        Document xmlRequest;
        try {
            xmlRequest = getRequest(context).getRequestDoc();
        } catch (RequestException e) {
            throw new PipelineRuntimeException("Failed to obtain request as XMLDocument", e);
        }

        replaceCategoryBindings(xmlRequest);
    }

    /**
     * <p>
     * Get all subsets from the request as a <code>NodeList</code> an loop
     * through to find the any with categories. Then loop over all bindings for
     * each category subset, if a binding on CategoryID is found then fetch the
     * High and Low values for the category and replace the CategoryID binding
     * with two bindings on High and Low.
     * </p>
     * 
     * @param xmlRequest
     *            the request from the <code>PipelineContext</code>
     * @throws PipelineRuntimeException
     */
    private void replaceCategoryBindings(final Document xmlRequest) throws PipelineRuntimeException {
        // loop over all subsets to find the category subset
        NodeList subsets = xmlRequest.getElementsByTagName("subset");
        for (int i = 0; i < subsets.getLength(); i++) {
            Element subset = (Element) subsets.item(i);

            if (subset.getAttribute(NAME_ATTR).compareToIgnoreCase("Category") == 0) {
                NodeList bindings = subset.getElementsByTagName(BINDING_TAG);
                // loop over all bindings
                int bindingCounter = 0;
                while (bindingCounter < bindings.getLength()) {
                    Element binding = (Element) bindings.item(bindingCounter);
                    String bindingName = binding.getAttribute(ATTRIBUTE_ATTR);

                    // increase counter by 1, i.e. step to next binding
                    bindingCounter++;

                    if (CATEGORY_ID.equals(bindingName)) {
                        // A binding on the CategoryID should be replaced by
                        // bindings on the categorys High Low values. This
                        // ensures that we binding on the categories
                        // containing items

                        // Get the High Low values
                        String object = "Category";
                        String method = "CategoryHighLow";
                        SearchPipelineExecuter search = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                                object, method);

                        search.setParam(CATEGORY_ID, binding.getAttribute(VALUE_ATTR));
                        search.setParam("CategoryIDSupplied", "true");
                        search.setParam("Level", "0");
                        search.setParam("NoCategoryID", "false");

                        XMLResultset result = search.execute();

                        String high = null;
                        String low = null;
                        try {
                            // We expect exactly one row. Quit execution if no
                            // rows are present
                            if (result.rowCount() == 0) {
                                FastStringBuffer debug = new FastStringBuffer();
                                debug.append("No rows returned for the CategoryID '");
                                debug.append(binding.getAttribute(VALUE_ATTR));
                                debug.append("'. Replacement of binding on CategoryID ");
                                debug.append("with bindings on High and Low not perfomed.");
                                LOG.debug(debug);
                                continue;
                            }

                            result.moveFirst();
                            high = result.getString(HIGH);
                            low = result.getString(LOW);
                        } catch (ResultsetException e) {
                            throw new PipelineRuntimeException(e);
                        }

                        // Remove the binding on the CategoryID and replace
                        // it by bindings on found High/Low values.
                        // The replacement is carried out by reusing the
                        // CategoryID binding and just renaming it to High.
                        // A new binding is created for Low.
                        binding.getAttributeNode(ATTRIBUTE_ATTR).setValue(HIGH);
                        binding.getAttributeNode(VALUE_ATTR).setValue(high);
                        binding.getAttributeNode(OPERATOR_ATTR).setValue(LESS_THAN_OR_EQUAL);

                        Element newBinding = xmlRequest.createElement(BINDING_TAG);
                        newBinding.setAttribute(ATTRIBUTE_ATTR, LOW);
                        newBinding.setAttribute(VALUE_ATTR, low);
                        newBinding.setAttribute(OPERATOR_ATTR, GREATER_THAN_OR_EQUAL);

                        Node bindingParent = binding.getParentNode();
                        bindingParent.appendChild(newBinding);
                        // Increase bindingCounter once more for the extra added
                        // binding.
                        bindingCounter++;
                    }
                }
            }
        }
    }
}
