package com.intentia.iec.pipeline.runtime.stage.custom.daf;

import java.io.InputStream;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.xml.sax.SAXException;

import com.intentia.icp.common.CMException;
import com.intentia.icp.common.CMItem;
import com.intentia.icp.common.CMItems;
import com.intentia.icp.common.CMResource;
import com.intentia.icp.common.CMResources;
import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.daf.drawing.DafDrawingConstants;

/**
 * Uploads an image to the DAF server.
 *
 */
public class DafUploadImageStage extends AbstractDafSearchStage {
	private static final Logger LOG = Logger.getLogger(DafUploadImageStage.class);
	
	private InputStream inputStream = null;
	
	private String mimeType = null;

	private Long fileSize = null;	
	
	private String fileName = null;
	
	private static final String ID = "ID";
	
	private static final String FILE_TYPE = "FileType";
	
	private static final String FILE_SIZE = "FileSize";
	
	private static final String FILE_NAME = "FileName";
	
	private static final String UPLOAD_TYPE = "UploadType";
	
	private static final String UPLOAD_TYPE_DRAWING = "Drawing";

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafStage#getAttributeToDafDatabaseField(java.lang.String)
	 */
	@Override
	public String getAttributeToDafDatabaseField(String attribute) {
		return null;
	}
	
	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafStage#getEmptyResultSet()
	 */
	@Override
	public XMLResultset getEmptyResultSet() {
        String ret = ("<?xml version='1.0' encoding='UTF-8'?>"
                + "<resultset object='DocumentArchive'/>");
        return new XMLResultset(ret);        
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getQuery(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public String getQuery(PipelineContext context) throws ParametersException,	ParserConfigurationException, SAXException, Exception {
		XMLRequest request = (XMLRequest) context.getRequest();
		this.inputStream = request.getInputStream();
		Parameters param = request.getParameters();
		if (param != null) {
			// If uploading a drawing, the image will be uploaded to ESA_ActingDrawing.
			if (UPLOAD_TYPE_DRAWING.equals(param.getString(UPLOAD_TYPE)) == true) {
				// ID refers to the Item ID (@ITEMID)
				String id = param.getString(ID);

				// mime type
				this.mimeType = param.getString(FILE_TYPE);
				
				// file size is required when setting the resource
				if (param.getString(FILE_SIZE) != null) {
					this.fileSize  = Long.parseLong(param.getString(FILE_SIZE)); 
				}

				// file name will be used for setting the original file name
				this.fileName  = param.getString(FILE_NAME);
				
				// return a query string if the ID was provided (or should all parameters be provided?)
				if (id != null) {
					return DafDrawingConstants.TABLE + "[" + DafDrawingConstants.COLUMN_ITEMID + " = \"" + id + "\"]";
				}
			}
		}
		
		return null;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getResultSize()
	 * expect only 1 search result
	 */
	@Override
	public int getResultSize() {
		return 1;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getStartIndex()
	 * always start from 0
	 */
	@Override
	public int getStartIndex() {
		return 0;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#processResult(com.intentia.icp.common.CMItems, int[])
	 */
	@Override
	public XMLResultset processResult(CMItems resultItems, int[] dafStatus) throws CMException {
		if (resultItems != null && resultItems.size() > 0) {
			CMItem item = resultItems.get(0);
			if (item.isCheckedOut() == false) {
				// add resource only if item is not checked out
				LOG.debug("Checking out item=" + item.getId());
				item.checkOut(this.connection);

				LOG.debug("Getting resource for item=" + item.getId());
				CMResources resources = item.getResources();
				if (resources != null) {
					// remove all other resources
					if (resources.size() > 0) {
						LOG.debug("Clearing resources for item=" + item.getId());
						item.getResources().clear();
					}

					// create a new resource
					CMResource resource = new CMResource();
					resource.setEntityName(DafDrawingConstants.RESOURCE_ENTITY_NAME);
					resource.setMimeType(this.mimeType);
					resource.setInputStream(this.inputStream);
					resource.setSize(this.fileSize);
					resource.setOrgFileName(this.fileName);

					// add to item's resources
					LOG.debug("Adding resource for item=" + item.getId());
					resources.add(resource);

					// upload the image
					LOG.debug("Uploading image item=" + item.getId());
					item.update(this.connection);
				}

				// check-in the item
				LOG.debug("Checking in item=" + item.getId());
				item.checkIn(this.connection);
			}
			else {
				// item is checked-out and cannot be updated
				LOG.debug("Cannot update item is checked out=" + item.getId());
				dafStatus[0] = DafConstants.ErrorCodes.ITEM_CHECKED_OUT;
			}
		}
		else {
			// item is not found, may have been deleted
			LOG.debug("Item not found");
			dafStatus[0] = DafConstants.ErrorCodes.ITEM_NOT_FOUND;
		}
		return getEmptyResultSet();
	}

	@Override
	public void setOutputParameters(PipelineContext context) throws PipelineRuntimeException {
		// intentionally blank
	}
}
