package com.intentia.iec.pipeline.runtime.stage.custom.search;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;

/**
 * A database access helper class. Shields clients from SQL and JDBC issues.
 */
// removed final so that SPS can inherit from this
public class DatabaseImpl implements Database {
    // changed to protected so that SPS can access
    protected static final String[] EMPTY_STRING_ARRAY = new String[0];

    protected static final Object[] EMPTY_OBJECT_ARRAY = new Object[0];

    protected Jdbc jdbc;

    public DatabaseImpl() {
        this(new JdbcImpl());
    }

    /**
     * Constructor with specified Jdbc object.
     * 
     * @param jdbc
     */
    public DatabaseImpl(Jdbc jdbc) {
        this.jdbc = jdbc;
    }

    public String[] getAssortmentIdsForUser(final String userId, final String userGroupId)
            throws PipelineRuntimeException {
        final List<String> assortments = new ArrayList<String>();
        jdbc.execute(Strings.Database.Searching.Item.UserAssortments.sql, new Object[] {userId, userGroupId},
                new Jdbc.RowHandler() {
                    public void processRow(final ResultSet rs) throws SQLException {
                        String assortmentId = rs
                                .getString(Strings.Database.Searching.Item.UserAssortments.assortmentId);
                        assortments.add(assortmentId);
                    }
                });
        return assortments.toArray(EMPTY_STRING_ARRAY);
    }

    public boolean useWarehousing() throws PipelineRuntimeException {
        final int[] count = new int[1];
        jdbc.execute(Strings.Database.Indexing.Setting.WarehouseItemsCount.sql, EMPTY_OBJECT_ARRAY,
                new Jdbc.RowHandler() {
                    public void processRow(final ResultSet rs) throws SQLException {
                        count[0] = rs.getInt(1);
                    }
                });
        return count[0] > 0 ? true : false;
    }

    public void buildCategoryPaths(final Map<String, String> categoryPathById,
            final Map<String, String> categoryPathByKey) throws PipelineRuntimeException {
        jdbc.execute(Strings.Database.Indexing.BaseData.CategoryPaths.sql, EMPTY_OBJECT_ARRAY, new Jdbc.RowHandler() {
            public void processRow(final ResultSet rs) throws SQLException {
                String part = rs.getString(Strings.Database.Indexing.BaseData.CategoryPaths.part);
                String id = rs.getString(Strings.Database.Indexing.BaseData.CategoryPaths.id);
                String key = rs.getString(Strings.Database.Indexing.BaseData.CategoryPaths.key);
                if (!categoryPathById.containsKey(id)) {
                    categoryPathById.put(id, "/");
                    categoryPathByKey.put(key, "/");
                }
                String path = (String) categoryPathById.get(id);
                categoryPathById.put(id, path + part + "/");
                categoryPathByKey.put(key, path + part + "/");
            }
        });
    }

    public void mergeItemAttributesFromDatabase(final Map<String, Map<String, String>> rows, final Request request)
            throws PipelineRuntimeException {

        // Build a comma separated list of item IDs
        StringBuilder idList = new StringBuilder(100);
        String[] arr = rows.keySet().toArray(EMPTY_STRING_ARRAY);
        for (int i = 0, n = arr.length; i < n; i++) {
            idList.append(arr[i]);
            if (i < n - 1) {
                idList.append(", ");
            }
        }

        String sql = Strings.Database.Searching.Item.PassiveAttributes.sqlHead + idList
                + Strings.Database.Searching.Item.PassiveAttributes.sqlTail;
        jdbc.execute(sql, new Object[] {request.getShippingCountryCode(), request.getListPriceGroupId(),
                request.getCurrencyCode(), request.getResellPriceGroupId(), request.getCurrencyCode(),
                request.getLanguageCode(), request.getUserGroupId(), request.getLanguageCode(),
                request.getLanguageCode(), request.getUserGroupId(), request.getCurrencyCode(),
                request.getUserGroupId()}, new Jdbc.RowHandler() {
            public void processRow(final ResultSet rs) throws SQLException, PipelineRuntimeException {

                String id = rs.getString(Strings.Database.Searching.Item.PassiveAttributes.id);
                Map<String, String> row = rows.get(id);

                row.put(Strings.Response.ItemList.itemId, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.itemNumber));
                row.put(Strings.Response.ItemList.hasSubItems, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.hasSubItems));
                row.put(Strings.Response.ItemList.imageThumb, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.imageThumb));
                row.put(Strings.Response.ItemList.isEmphasized, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.isEmphasized));
                row.put(Strings.Response.ItemList.itemCode,
                // N.B. Hard-coded value
                        Strings.Database.Searching.Item.PassiveAttributes.normal);
                row.put(Strings.Response.ItemList.itemTax, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.rate));
                row.put(Strings.Response.ItemList.listPrice, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.listPrice));
                row.put(Strings.Response.ItemList.resellPrice, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.resellPrice));
                row.put(Strings.Response.ItemList.manufacturerId, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.manufacturerId));
                row.put(Strings.Response.ItemList.minimumQty, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.minQty));
                row.put(Strings.Response.ItemList.modularQty, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.modularQty));
                row.put(Strings.Response.ItemList.mvxConfigurable, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.isMvxConfigurable));
                row.put(Strings.Response.ItemList.styleId, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.styleId));
                row.put(Strings.Response.ItemList.supplierId, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.supplierId));
                row.put(Strings.Response.ItemList.mainIdConstraintGenerated, id);

                // Additional passive attributes for version 13.1
                row.put(Strings.Response.ItemList.brandId, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.brandId));
                row.put(Strings.Response.ItemList.brandName, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.brandName));
                row.put(Strings.Response.ItemList.description, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.description));
                row.put(Strings.Response.ItemList.imagePreview, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.imagePreview));
                row.put(Strings.Response.ItemList.isStyle, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.isStyle));
                row.put(Strings.Response.ItemList.mainCategoryId, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.mainCategoryId));
                row.put(Strings.Response.ItemList.mainCategoryName, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.mainCategoryName));
                row.put(Strings.Response.ItemList.manufacturerName, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.manufacturerName));
                row.put(Strings.Response.ItemList.netListPrice, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.netListPrice));
                row.put(Strings.Response.ItemList.taxPrice, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.taxPrice));
                row.put(Strings.Response.ItemList.unit, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.unit));
                row.put(Strings.Response.ItemList.unitCode, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.unitCode));
                row.put(Strings.Response.ItemList.rating, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.itemRating));

                row.put(Strings.Response.ItemList.customerItemId, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.customerItemId));

            }
        });
    }
}
