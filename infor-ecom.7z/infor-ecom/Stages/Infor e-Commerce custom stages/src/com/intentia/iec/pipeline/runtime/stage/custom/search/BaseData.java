package com.intentia.iec.pipeline.runtime.stage.custom.search;

/**
 * Global information, like settings and lookup data. The interface is defined
 * mainly to allow mock implementations for unit testing.
 */
public interface BaseData {

    /**
     * Tells if e-Sales is using warehouse filtering. Is detected during
     * indexing by querying the WarehouseItem table and seeing if it contains
     * any entries.
     * 
     * @return true if warehousing is used, false otherwise
     */
    boolean isWarehousingUsed();

    /**
     * Look up the path to a category. The path is encoded as a string of
     * ancestor id's delimited by slashes; e.g. the path to the category with id
     * 3 could be "/1/2/3/".
     * 
     * @param categoryKey
     *            the key of category to look up
     * @return the path encoded in a string
     */
    String getCategoryPathByKey(String categoryKey);

}
