package com.intentia.iec.pipeline.runtime.stage.custom;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.integration.erp.dao.ItemDao;
import com.intentia.iec.pipeline.runtime.integration.erp.dao.factory.DaoFactory;
import com.intentia.iec.pipeline.runtime.integration.erp.dao.factory.WebserviceDaoFactory;
import com.intentia.iec.pipeline.runtime.integration.erp.exception.ErpConnectionException;
import com.intentia.iec.pipeline.runtime.integration.erp.exception.ErpRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.erp.model.CatalogPrice;
import com.intentia.iec.pipeline.runtime.integration.erp.model.CatalogPriceRequest;
import com.intentia.iec.pipeline.runtime.integration.erp.model.Item;
import com.intentia.iec.pipeline.runtime.integration.erp.utils.ErpUtilHelper;
import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;

/**
 * CatalogDataWSClient
 * 
 * Developed by: Gerald Tajonera
 * 
 * CatalogDataWSClient is a webservice client for GetCatalogData service in SyteLine.
 * 
 * Updates: ItemListStage.NetListPrice for ItemList page price.
 * Updates: Item.ListPrice and Item.ResellPrice for ItemDetails page price.
 * 
 */
public class CatalogDataWSClient implements PipelineStage {	

	private static final Logger LOG = Logger.getLogger(CatalogDataWSClient.class);
	private String WSUserID = null;
	private String param_WSUserID = "WebServiceUserID";
	private XMLRequest xmlRequest;
	private XMLResultset xmlResultset;
	private PipelineContext context;
	private String warehouseId;
	private String shippingAddressId;

	public void execute(PipelineContext context) throws PipelineRuntimeException {

		try{
			if (!(context.getRequest() instanceof XMLRequest)) {
				throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
			}
			this.context = context;
			xmlRequest = (XMLRequest) context.getRequest();		
			XMLRequest.extractRequestParameters(xmlRequest);
			Parameters param=CustomStagesHelper.getRequestParameters(context);
			this.shippingAddressId= param.getString("shippingAddressId")!=null && param.getString("shippingAddressId").trim().equals("")? null:param.getString("shippingAddressId");
			this.warehouseId=param.getString("warehouseId");
			xmlResultset = (XMLResultset) context.getResponse();

			// Retrieving LogIn credentials in ApplicationData table.
			WSUserID = ErpUtilHelper.getWSRegisteredUser(param_WSUserID);

			callWSCatalogData();

		} catch(ErpConnectionException e){
			setErrorFlag();
			LOG.error(e.getMessage());
		} catch(ErpRuntimeException e){
			setErrorFlag();
			LOG.error(e.getMessage());
		} catch (Exception e) {
			if(e.getCause() instanceof java.net.ConnectException || e.getCause() instanceof java.net.SocketTimeoutException){
				LOG.debug("Error Execute Catalog Data - "+ e.getMessage());
				setErrorFlag();
			} else {				
				LOG.debug("Error Extracting Request parameters!", e);
			}
		}
	}

	private void callWSCatalogData() throws ErpConnectionException, ErpRuntimeException, Exception{
		//Create CatalogPriceRequest object
		Map<String, String> virtualMap = ErpUtilHelper.getVirtualEnterprise(); 
		CatalogPriceRequest request = new CatalogPriceRequest();
		request.setTenantId(virtualMap.get("TenantId"));
		request.setAccountingEntityId(virtualMap.get("Facility"));
		request.setCurrencyId(xmlRequest.getParameters().getString("@CurrencyCode"));
		request.setCustomerPartyId(xmlRequest.getParameters().getString("mvxCUNO"));
		request.setWarehouseId((this.warehouseId!=null && !this.warehouseId.equals(""))?this.warehouseId : virtualMap.get("Warehouse"));
		request.setPriceGroup(xmlRequest.getParameters().getString("priceGroup"));
		request.setUserName(WebserviceDaoFactory.WEBSERVICEUSERID);
		
		// Create array request parameter 
		List<Item> daoItems = new ArrayList<Item>();
		xmlResultset.beforeFirst();
		while(xmlResultset.moveNext()) {
			Item item = new Item();
			item.setItemId(xmlResultset.getString("ItemID"));
			item.setUnitCode(ErpUtilHelper.getItemUnit(item.getItemId()));
			item.setCustomerItemID(xmlResultset.getString("CustomerItemId"));
			
			if(CustomStagesHelper.getKeyValue("ION.Webservice ShippingAddressID").equals("true")){
				item.setShippingId(this.shippingAddressId);
			}
			daoItems.add(item);								
		}			
		request.setItems(daoItems);
		//Get ERP DAO implementation 
		ItemDao itemDao = DaoFactory.getDAOFactory().getItemDao() ;
		CatalogPrice wsoutItems;
		HashMap<String, String> items = new HashMap<String, String>();
		try {
			wsoutItems = itemDao.getCatalogPrice(request);
			if(wsoutItems != null){
				//Update node with WS result 
				for (Item item : wsoutItems.getItems()){
					//Iterate over node item
					String itemID = item.getItemId();
					xmlResultset.beforeFirst();
					while (xmlResultset.moveNext()) {
						String currItemID = xmlResultset.getString("ItemID");
						if (itemID.equals(currItemID)){
							// set OrderLine response attributes for Prices...						
							// For ItemList page price
							xmlResultset.setString("NetListPrice", Double.toString(item.getUnitPriceAmount()));
							// For ItemDetails page prices
							xmlResultset.setString("ListPrice", Double.toString(item.getUnitPriceAmount()));
							xmlResultset.setString("ResellPrice", Double.toString(item.getUnitPriceAmount()));
							items.put(currItemID, currItemID);
							break;
						}
					}
				}
				xmlResultset.moveFirst();		
				while (xmlResultset.moveNext()) {
					String currItemID = xmlResultset.getString("ItemID");
					if (currItemID != null) {
						String key = items.get(currItemID);
						if (key == null) {
							xmlResultset.setString("NetListPrice", "-1.00");
							// For ItemDetails page prices
							xmlResultset.setString("ListPrice", "-1.00");
							xmlResultset.setString("ResellPrice", "-1.00");					
						}				
					}
				}					
				if (wsoutItems.isHasWSCallError()){
					throw new ErpRuntimeException(wsoutItems.getMsgCodeError(), wsoutItems.getMsgError());
				}			
			}
		} catch (Exception e){
			xmlResultset.beforeFirst();		
			while (xmlResultset.moveNext()) {
				String currItemID = xmlResultset.getString("ItemID");
				if (currItemID != null) {
					String key = items.get(currItemID);
					if (key == null) {
						xmlResultset.setString("NetListPrice", "-1.00");
						// For ItemDetails page prices
						xmlResultset.setString("ListPrice", "-1.00");
						xmlResultset.setString("ResellPrice", "-1.00");					
					}				
				}
			}					
			throw new ErpConnectionException(e.toString());
		}		
	}

	private void setErrorFlag(){
		try {
			XMLResultset xmlResponse = (XMLResultset) context.getResponse();
			if(xmlResponse == null){
				XMLResultset response = new XMLResultset();
				context.setResponse(response);
			}
			CustomStagesHelper.setResponseParameter(context, "hasWSError", "Y");
		} catch (PipelineRuntimeException e) {
			LOG.error(e.toString());	
		}
	}

}	
