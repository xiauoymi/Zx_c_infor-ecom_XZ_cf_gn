package com.intentia.iec.pipeline.runtime.stage.custom;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import au.com.bytecode.opencsv.CSVReader;

import com.ibm.icu.text.DecimalFormat;
import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.utils.CommitPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.util.FastStringBuffer;
import com.sun.jms.util.Log;

public class RetrieveOrderFileItems extends AbstractPipelineStage {

    /**
     * 14555 April 04, 2008
     * 
     * This custom stage is intended to be used in Order File Upload feature for
     * eSales
     * 
     * RetrieveOrderFileItems.java -- Fetches the file information from the
     * Request, Parses each row and save it to e-Sales database
     * 
     * 1.Request Parameter: a. FileType b. FileName c. ItemColumnNumber d.
     * QuantityColumnNumber e. LanguageCode f. ColumnHeader g. WorkSheet h.
     * WorkSheetType
     * 
     * 2.Application Property Key: Ordering.OrderFileFolder
     */

    private static final Logger LOG = Logger.getLogger(RetrieveOrderFileItems.class);

    private Parameters parameters = null;

    private static final String FILE_ID_PARAMETER = "FileID";

    private static final String FILE_TYPE_PARAMETER = "FileType";

    private static final String SEPERATOR_PARAMETER = "Seperator";

    private static final String ENCAPSULATOR_PARAMETER = "Encapsulator";

    private static final String FILE_NAME_PARAMETER = "FileName";

    private static final String SEPERATOR_THOUSAND_PARAMETER = "ThousandSeparator";

    private static final String SEPERATOR_DECIMAL_PARAMETER = "DecimalSeparator";

    private static final String EMAIL_PARAMETER = "Email";

    private static final String LANGUAGE_CODE_PARAMETER = "LanguageCode";

    private static final String COUNTRY_CODE_PARAMETER = "CountryCode";

    private static final String ITEMID_COLUMN_NUMBER_PARAMETER = "ItemColumnNumber";

    private static final String QUANTITY_COLUMN_NUMBER_PARAMETER = "QuantityColumnNumber";

    /**
     * Key use to retrieved Ordering.OrderFileFolder from the Database.
     */
    private static final String APP_DETAILS_ORDERING_FILE_FOLDER = "OrderFileFolder";

    private static final String ORDER_FILE_STATUS_AFTER_RETRIEVE = "retrieved";

    private static final String FILE_TYPE_XLS = "XLS";

    private static final String FILE_TYPE_TXT = "TXT";

    private static final String COL_ITEMNUMBER = "itemNumber";

    private static final String COL_QTY = "qty";

    // ATTRIBUTES
    // 1.) ORDERFILEITEM.ORDERFILE_UPDATE
    private static final String ORDERFILE_UPDATE_FILEID_ATTRIB = "FileID";

    private static final String ORDERFILE_UPDATE_STATUS_ATTRIB = "Status";

    private static final String NO_TEXT_ENCAPSULATOR = "none";

    private static final String TAB_SEPERATOR = "tab";

    private int fileID = 0;

    private String fileType = null;

    private String fileName = null;

    private String filePath = null;

    private String file;

    private String seperator;

    private String encapsulator;

    private String thousand_char;

    private String decimal_char;

    private String email = null;

    private String languageCode;

    private String countryCode;

    private String itemIDColumnNumber = null;

    private int itemIDColumnNumberValue = 0;

    private String quantityColumnNumber = null;

    private int quantityColumnNumberValue = 0;

    private int defaultWorkSheet = 0;

    private int missingRequiredRequestParams = 0;

    private Locale locale;

    private StringBuffer ErrorMessage = new StringBuffer("Missing Required Parameters: ");

    @Override
    public void execute(PipelineContext context) throws PipelineRuntimeException {
    	LOG.debug("Entering RetrieveOrderFileItems execute()");
        try {
            // Get Request Parameters
            getRequestParameters(context);
            // Get Order File Upload File Path from application properties
            getOrderFileUploadPath();
            // Process file according to type
            processFile();
            // Set Order File status
            setOrderFileStatus(String.valueOf(fileID), ORDER_FILE_STATUS_AFTER_RETRIEVE);
        } catch (RuntimeException e) {
            throw new PipelineRuntimeException();
        } finally {
            // Delete Order File
            deleteFile();
        }
        LOG.debug("Exiting RetrieveOrderFileItems execute()");
    }

    public BigDecimal unformatDecimal(String value) throws ParseException {
        NumberFormat nf = NumberFormat.getNumberInstance(getLocale());

        Number n = nf.parse(value);

        if (n instanceof BigDecimal) {
            return (BigDecimal) n;
        } else if (n instanceof java.lang.Double) {
            return new BigDecimal(n.doubleValue());
        } else if (n instanceof java.lang.Long) {
            return new BigDecimal(n.doubleValue());
        } else {
            FastStringBuffer error = new FastStringBuffer();
            error.append("Could not parse as decimal: ");
            error.append(value);
            error.append(". Parser returned unknown decimal type: ");
            error.append(n.getClass());
            throw new ParseException(error.toString(), 0);
        }
    }

    private void processFile() throws PipelineRuntimeException {
        // Get Absolute path for the specified file
        file = filePath + fileName;

        setLocale("EN");

        // Validate Uploaded File According to its File Type
        if (fileType.equalsIgnoreCase(FILE_TYPE_XLS)) {
            processXLSFile();
        } else if (fileType.equalsIgnoreCase(FILE_TYPE_TXT)) {
            processTxtFile();
        } else {
            LOG.error("Unsupported File Type.");
            throw new PipelineRuntimeException();
        }
    }

    private void getRequestParameters(PipelineContext context) throws PipelineRuntimeException {

        // Verify type of request
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Request MUST be of type XMLRequest!");
        }

        XMLRequest request = (XMLRequest) context.getRequest();

        try {

            XMLRequest.extractRequestParameters(request);
            parameters = request.getParameters();

            // Fetch request parameters
            fileID = parameters.getint(FILE_ID_PARAMETER);
            fileType = parameters.getString(FILE_TYPE_PARAMETER);
            fileName = parameters.getString(FILE_NAME_PARAMETER);
            email = parameters.getString(EMAIL_PARAMETER);
            languageCode = parameters.getString(LANGUAGE_CODE_PARAMETER);
            countryCode = parameters.getString(COUNTRY_CODE_PARAMETER);
            seperator = parameters.getString(SEPERATOR_PARAMETER);
            encapsulator = parameters.getString(ENCAPSULATOR_PARAMETER);
            itemIDColumnNumber = parameters.getString(ITEMID_COLUMN_NUMBER_PARAMETER);
            quantityColumnNumber = parameters.getString(QUANTITY_COLUMN_NUMBER_PARAMETER);
            thousand_char = parameters.getString(SEPERATOR_THOUSAND_PARAMETER);
            decimal_char = parameters.getString(SEPERATOR_DECIMAL_PARAMETER);

            // Validate each required request parameter
            validateRequiredRequestParameters(String.valueOf(fileID), FILE_ID_PARAMETER);
            validateRequiredRequestParameters(fileType, FILE_TYPE_PARAMETER);
            validateRequiredRequestParameters(fileName, FILE_NAME_PARAMETER);
            validateRequiredRequestParameters(email, EMAIL_PARAMETER);
            validateRequiredRequestParameters(languageCode, LANGUAGE_CODE_PARAMETER);
            validateRequiredRequestParameters(countryCode, COUNTRY_CODE_PARAMETER);
            validateRequiredRequestParameters(itemIDColumnNumber, ITEMID_COLUMN_NUMBER_PARAMETER);
            validateRequiredRequestParameters(quantityColumnNumber, QUANTITY_COLUMN_NUMBER_PARAMETER);
            validateRequiredRequestParameters(thousand_char, SEPERATOR_THOUSAND_PARAMETER);
            validateRequiredRequestParameters(decimal_char, SEPERATOR_DECIMAL_PARAMETER);

            if (missingRequiredRequestParams > 0) {
                final String msg = ErrorMessage.toString();
                LOG.error(msg);
                throw new PipelineRuntimeException(msg);
            }

            // Check if the supplied column mapping is a valid integer value
            try {
                itemIDColumnNumberValue = Integer.valueOf(itemIDColumnNumber);
                quantityColumnNumberValue = Integer.valueOf(quantityColumnNumber);
            } catch (NumberFormatException e) {
                final String msg = "Invalid integer value supplied for column mapping";
                LOG.error(msg);
                throw new PipelineRuntimeException(msg);
            }

        } catch (RequestException e) {
            throw new PipelineRuntimeException(e);
        } catch (ParametersException e) {
            throw new PipelineRuntimeException(e);
        }
    }

    private void validateRequiredRequestParameters(String paramVariable, String param) {
        if (paramVariable == null) {
            ErrorMessage.append(param);
            missingRequiredRequestParams++;
        }
    }

    // Parse and validate TXT files
    private void processTxtFile() throws PipelineRuntimeException {

        LOG.debug("Processing text file (.csv or .txt)....");

        CSVReader reader = null;

        char defaultEncapsulator = (char) 27; // '27' is the ASCII code for
                                                // ESC (escape) character
        // or may use any other non-graphical/non-printable character
        try {
            if (fileType.equalsIgnoreCase(FILE_TYPE_TXT)) {
                if (encapsulator.equalsIgnoreCase(NO_TEXT_ENCAPSULATOR)) {
                    {
                        if (seperator.equalsIgnoreCase(TAB_SEPERATOR)) {
                            reader = new CSVReader(new FileReader(file), '\t', defaultEncapsulator);
                        } else {
                            reader = new CSVReader(new FileReader(file), seperator.charAt(0), defaultEncapsulator);
                        }
                    }
                } else {
                    if (seperator.equalsIgnoreCase(TAB_SEPERATOR)) {
                        reader = new CSVReader(new FileReader(file), '\t', encapsulator.charAt(0));
                    } else {
                        reader = new CSVReader(new FileReader(file), seperator.charAt(0), encapsulator.charAt(0));
                    }
                }
            } else {
                LOG.error("Unsupported File Extension");
                throw new PipelineRuntimeException();
            }
        } catch (FileNotFoundException e) {
            throw new PipelineRuntimeException("File not found ...");
        }

        int numberOfRows = 0;

        OrderFileItemBatchUpdate orderfileitembatchupdate = new OrderFileItemBatchUpdate("Insert");

        try {
            List orderEntries = reader.readAll();
            String xItemId = null;
            String xOrderQuantity = null;
            if (orderEntries.isEmpty()) {
                LOG.debug("Order file '" + fileName + "' is empty.");
                throw new IOException();
            }

            for (Iterator it = orderEntries.iterator(); it.hasNext();) {
                String[] entryDetails = (String[]) it.next();
                for (int i = 0; i < entryDetails.length; i++) {
                    if (i == itemIDColumnNumberValue - 1) {
                        xItemId = entryDetails[i];
                    }
                    if (i == quantityColumnNumberValue - 1) {
                        xOrderQuantity = entryDetails[i].toString();
                    }
                }

                orderfileitembatchupdate.addToBatchInsert(fileID, ++numberOfRows, xItemId, xOrderQuantity);

                // reset values
                xItemId = "";
                xOrderQuantity = "";
            }

            int i = orderfileitembatchupdate.executeBatchInsert();

            LOG.debug("Inserted order file items: " + i);

            LOG.debug("Done processing text file.");

        } catch (IOException e) {
            throw new PipelineRuntimeException();
        } finally {
            try {

                reader.close();
            } catch (IOException e) {
                final String msg = "Error on closing File reader";
                LOG.error(msg, e);
                throw new PipelineRuntimeException(msg, e);
            }
        }
    }

    // Parse and validate XLS files
    private void processXLSFile() throws PipelineRuntimeException {

        InputStream input = null;

        try {
            // Uses POI API to retrieve cell values from XLS
            input = new FileInputStream(file);
            HSSFWorkbook wb = new HSSFWorkbook(input);
            HSSFSheet sheet = null;

            try {
                sheet = wb.getSheetAt(defaultWorkSheet);
            } catch (NumberFormatException e) {
                final String msg = "The supplied Worksheet index is not valid numeric value";
                LOG.error(msg);
                throw new PipelineRuntimeException(msg);
            }

            if (sheet == null) {
                final String msg = "Cannot find worksheet for the specified worksheet name/index";
                LOG.error(msg);
                throw new PipelineRuntimeException(msg);
            }

            int numberOfRows = 0;

            LOG.debug("Processing excel file....");

            // Iterate over each row in the sheet
            Iterator rows = sheet.rowIterator();

            OrderFileItemBatchUpdate orderfileitembatchupdate = new OrderFileItemBatchUpdate("Insert");

            while (rows.hasNext()) {

                HSSFRow row = (HSSFRow) rows.next();

                String xOrderQuantity = null;

                try {
                    xOrderQuantity = getCellStringValue(row.getCell((short) (quantityColumnNumberValue - 1)), COL_QTY);
                    LOG.debug("Excel xOrderQuantity=" + xOrderQuantity);
                } catch (Exception e) {
                    // Get the Default value for Order Quantity
                    LOG.debug("Excel - Invalid Numeric Value!");
                }

                String xItemId = getCellStringValue(row.getCell((short) (itemIDColumnNumberValue - 1)), COL_ITEMNUMBER);

                orderfileitembatchupdate.addToBatchInsert(fileID, ++numberOfRows, xItemId, xOrderQuantity);
            }

            int i = orderfileitembatchupdate.executeBatchInsert();

            LOG.debug("Inserted order file items: " + i);

            LOG.debug("Done processing excel file.");

        } catch (FileNotFoundException e) {
            final String msg = "Cannot find the supplied file";
            LOG.error(msg, e);
            throw new PipelineRuntimeException(msg, e);
        } catch (IOException e) {
            final String msg = "Error on reading line from the supplied file";
            LOG.error(msg, e);
            throw new PipelineRuntimeException(msg, e);
        } finally {
            try {
                input.close();
            } catch (IOException e) {
                final String msg = "Error on closing File reader";
                LOG.error(msg, e);
                throw new PipelineRuntimeException(msg, e);

            }
        }

    }

    // This method accepts POI's HSSFCell parameter and return its String value
    private String getCellStringValue(HSSFCell cell, String fromColumn) {

        String stringValue = null;

        try {
            switch (cell.getCellType()) {

            case HSSFCell.CELL_TYPE_NUMERIC:
                java.math.BigDecimal d1 = new BigDecimal(cell.getNumericCellValue());
                if (COL_QTY.equals(fromColumn)) {
                    stringValue = NumberFormat.getInstance().format((Object) d1);
                } else {
                    NumberFormat formatter = NumberFormat.getInstance();
                    formatter.setGroupingUsed(false);
                    stringValue = formatter.format((Object) d1);
                }
                break;
            case HSSFCell.CELL_TYPE_STRING:
                stringValue = cell.getStringCellValue();
                break;
            case HSSFCell.CELL_TYPE_BOOLEAN:
                stringValue = String.valueOf(cell.getBooleanCellValue());
                break;
            case HSSFCell.CELL_TYPE_FORMULA:
                stringValue = cell.getCellFormula().toString();
                break;
            case HSSFCell.CELL_TYPE_BLANK:
                stringValue = "";
                // LOG.debug("CELL_TYPE_BLANK: " + stringValue);
                break;
            case HSSFCell.CELL_TYPE_ERROR:
                stringValue = "";
                // LOG.debug("CELL_TYPE_ERROR: " + stringValue);
                break;
            default:
                stringValue = cell.getStringCellValue();
                cell.getDateCellValue().toString();
                break;
            }
        } catch (NullPointerException e) {
            stringValue = "";
        }

        if (stringValue != null)
            stringValue = stringValue.trim();

        return stringValue;

    }

    /**
     * Get Order File Upload Path from Application Data.
     * @throws PipelineRuntimeException
     */
    private void getOrderFileUploadPath() throws PipelineRuntimeException {

        filePath = getValueFromApplicationData(APP_DETAILS_ORDERING_FILE_FOLDER);

        if (null == filePath) {
            FastStringBuffer msg = new FastStringBuffer(100);
            msg.append("Missing application data: ").append(APP_DETAILS_ORDERING_FILE_FOLDER);
            throw new PipelineRuntimeException(msg.toString());
        }
        
        if (filePath.endsWith(File.separator) == false) {
        	filePath = filePath + File.separator;
        }
        
        filePath = filePath.replace(File.separatorChar, '/');
        
        LOG.debug("Order File Upload Path: " + filePath.toString());
    }

    private void deleteFile() {

        File f = new File(file);

        // Make sure the file or directory exists and isn't write protected
        if (!f.exists())
            throw new IllegalArgumentException("Delete: no such file or directory: " + f.getPath());

        if (!f.canWrite())
            throw new IllegalArgumentException("Delete: write protected: " + fileName);

        // If it is a directory, make sure it is empty
        if (f.isDirectory()) {
            String[] files = f.list();
            if (files.length > 0)
                throw new IllegalArgumentException("Delete: directory not empty: " + fileName);
        }

        // Attempt to delete it
        boolean success = f.delete();

        if (!success)
            throw new IllegalArgumentException("Delete: deletion failed");
    }

    // Set order file status to "processed"
    private void setOrderFileStatus(String pKey, String pStatus) throws PipelineRuntimeException {

        CommitPipelineExecuter coe = new CommitPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "OrderFile",
                "Update");

        coe.addEntity();
        coe.setEntityKey(ORDERFILE_UPDATE_FILEID_ATTRIB, pKey);
        coe.setAttribute(ORDERFILE_UPDATE_STATUS_ATTRIB, pStatus);

        coe.execute();

    }

    public void setLocale(String languageCode) {
        this.locale = new Locale(languageCode);
    }

    private Locale getLocale() {
        return locale;
    }

	private String getValueFromApplicationData(String pParamName) {

		String paramValue;

		SearchPipelineExecuter spe = new SearchPipelineExecuter(
        		ConstantsForSales.PIPELINE_PACKAGE, ConstantsForSales.APPLICATION_DATA,
        		ConstantsForSales.APPLICATION_DATA_DETAILS);

		spe.setParam("param", pParamName);

		try {
			XMLResultset rs = spe.execute();
			rs.moveFirst();
			paramValue = rs.getString("ParameterValue");
		} catch (PipelineRuntimeException e) {
			paramValue = "";
		} catch (ResultsetException e) {
			paramValue = "";
		}

		return paramValue;

	}

}
