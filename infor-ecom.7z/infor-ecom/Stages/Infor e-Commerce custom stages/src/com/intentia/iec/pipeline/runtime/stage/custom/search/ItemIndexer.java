package com.intentia.iec.pipeline.runtime.stage.custom.search;

import static com.intentia.iec.pipeline.runtime.stage.custom.search.IndexerUtils.addIndexedField;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc.RowHandler;
import com.intentia.iec.pipeline.runtime.stage.custom.search.rowhandler.AssortmentsRowHandler;
import com.intentia.iec.pipeline.runtime.stage.custom.search.rowhandler.CategoryRowHandler;
import com.intentia.iec.pipeline.runtime.stage.custom.search.rowhandler.CustomerItemNamesRowHandler;
import com.intentia.iec.pipeline.runtime.stage.custom.search.rowhandler.CustomerPriceRowHandler;
import com.intentia.iec.pipeline.runtime.stage.custom.search.rowhandler.NamesAndDescriptionsRowHandler;
import com.intentia.iec.pipeline.runtime.stage.custom.search.rowhandler.PriceRowHandler;
import com.intentia.iec.pipeline.runtime.stage.custom.search.rowhandler.TaxCustomerPriceRowHandler;
import com.intentia.iec.pipeline.runtime.stage.custom.search.rowhandler.TaxPriceRowHandler;
import com.intentia.iec.pipeline.runtime.stage.custom.search.rowhandler.WarehousesRowHandler;

/* If new data needs to be indexed (if it will be included in batch query):
 * 1.) Add new SQL statement(s) to getItemDetailsSql()
 * 2.) Create new RowHandler implementation
 * 3.) Add parameter for SQL statement(s) to getParameters().
 * 4.) Add the new RowHandler to getRowHandlers().
 * 
 */
// removed final so that SPS can inherit from this class
public class ItemIndexer implements Indexer {
    protected static final Logger LOG = Logger.getLogger(ItemIndexer.class);

    protected static final int LOG_ROW_MODULUS = 1000;

    protected final Map<String, String> categoryPathById;

    protected final Jdbc jdbc;

    protected Jdbc.StatementHolder stmtItems;

    protected Jdbc.StatementHolder stmtMainCategoryNames;

    protected boolean isSpsEnabled = false;

    protected boolean isStyleItemEnabled = false;

    protected boolean includePrices = false;

    /**
     * Contains batch SQL statements
     */
    // MainCategoryNames is separate from this because MainCategoryNames is
    // conditional.
    protected Jdbc.StatementHolder stmtItemDetails;

    public ItemIndexer(Map<String, String> categoryPathById, final Jdbc jdbc) {
        // this is called by e-Sales
        this.categoryPathById = categoryPathById;
        this.jdbc = jdbc;
        // extract values from application properties
        try {
            this.isSpsEnabled = Boolean.valueOf(CustomStagesHelper.getKeyValue("Application.SPS Enabled"))
                    .booleanValue();
            this.isStyleItemEnabled = Boolean.valueOf(CustomStagesHelper.getKeyValue("Application.ItemListStyleItem"))
                    .booleanValue();
            // prices will be indexed if M3 API = false and PriceSearchAndSort =
            // true
            this.includePrices = ((Boolean.valueOf(CustomStagesHelper.getKeyValue("Application.M3 API")).booleanValue() == false) && (Boolean
                    .valueOf(CustomStagesHelper.getKeyValue("Application.PriceSearchAndSort")).booleanValue() == true));
        } catch (PipelineRuntimeException e) {
            LOG.error(e);
        }
    }

    /**
     * Constructor
     * 
     * @param categoryPathById
     * @param jdbc
     * @param isSpsEnabled
     * @param isStyleItemEnabled
     */
    public ItemIndexer(Map<String, String> categoryPathById, final Jdbc jdbc, boolean isSpsEnabled,
            boolean isStyleItemEnabled, boolean includePrices) {
        // this is called by index server

        this.categoryPathById = categoryPathById;
        this.jdbc = jdbc;
        this.isSpsEnabled = isSpsEnabled;
        this.isStyleItemEnabled = isStyleItemEnabled;
        this.includePrices = includePrices;
    }

    public void index(final IndexWriter writer) throws PipelineRuntimeException {
        Connection con = null;
        try {
            con = jdbc.getConnection();
            prepareStatements(con);
            indexItems(writer);
        } finally {
            PreparedStatement[] stmts = new PreparedStatement[] {stmtItems.stmt, stmtMainCategoryNames.stmt,
                    stmtItemDetails.stmt};
            jdbc.close(stmts);
            jdbc.close(con);
        }
    }

    /**
     * Returns all SQL statements that will retrieve the item details. This is
     * used for batch processing.
     * 
     * @return
     */
    protected List<String> getItemDetailsSql() {
        // Created this function so that SPSItemIndexer can override this and
        // add
        // additional SQL statements, if needed.

        List<String> list = Collections.synchronizedList(new ArrayList<String>());
        list.add(Strings.Database.Indexing.Item.NamesAndDescriptions.sql);
        list.add(Strings.Database.Indexing.Item.Categories.sql);
        list.add(Strings.Database.Indexing.Item.Assortments.sql);
        list.add(Strings.Database.Indexing.Item.Warehouses.sql);
        list.add(Strings.Database.Indexing.Item.CustomerItemID.sql);

        if (this.includePrices == true) {
            list.add(Strings.Database.Indexing.Item.Price.sql);
            list.add(Strings.Database.Indexing.Item.TaxPrice.sql);
            list.add(Strings.Database.Indexing.Item.CustomerPrice.sql);
            list.add(Strings.Database.Indexing.Item.TaxCustomerPrice.sql);
        }

        return list;
    }

    /**
     * Creates statements that will be used for indexing
     * 
     * @param con
     * @throws PipelineRuntimeException
     */
    protected void prepareStatements(final Connection con) throws PipelineRuntimeException {
        // Created this function so that SPSItemIndexer can override this and
        // specify its own sql statements

        String sqlItems = Strings.Database.Indexing.Item.Items.sql;
        String sqlWithoutStyles = Strings.Database.Indexing.Item.Items.sqlWithoutStyles;

        // if sps enabled, exclude spare parts
        if (this.isSpsEnabled == true) {
            sqlItems = Strings.Database.Indexing.Item.Items.sqlSpsEnabled;
            sqlWithoutStyles = Strings.Database.Indexing.Item.Items.sqlWithoutStylesSpsEnabled;
        }

        // if style item is false, exclude style items
        if (this.isStyleItemEnabled == false) {
            LOG
                    .debug("Application.ItemListStyleItem set to False - will exclude all style items from Indexing operation");
            sqlItems = sqlWithoutStyles;
        }

        prepareStatements(con, sqlItems, getItemDetailsSql());
    }

    /**
     * Helper function for creating statements.
     * 
     * @param con
     * @param sqlItems
     * @param sqlItemDetails
     * @throws PipelineRuntimeException
     */
    protected void prepareStatements(Connection con, String sqlItems, List<String> sqlItemDetails)
            throws PipelineRuntimeException {
        // provided this function that SPSItemIndexer can override or invoke if
        // needed.

        // pass MainCategoryNames.sql as default sql statement for category
        // names
        prepareStatements(con, sqlItems, Strings.Database.Indexing.Item.MainCategoryNames.sql, sqlItemDetails);
    }

    /**
     * Does the actual creation of PreparedStatements.
     * 
     * @param con
     * @param sqlItems
     * @param sqlMainCategoryNames
     * @param sqlItemDetails
     * @throws PipelineRuntimeException
     */
    private void prepareStatements(Connection con, String sqlItems, String sqlMainCategoryNames,
            List<String> sqlItemDetails) throws PipelineRuntimeException {
        try {
            stmtItems = new Jdbc.StatementHolder(con, sqlItems);
            stmtMainCategoryNames = new Jdbc.StatementHolder(con, sqlMainCategoryNames);
            stmtItemDetails = new Jdbc.StatementHolder(con, (String[]) sqlItemDetails.toArray(new String[0]));
        } catch (SQLException e) {
            LOG.error("Problem preparing sql statements", e);
            throw new PipelineRuntimeException();
        }
    }

    protected void indexItems(final IndexWriter writer) throws PipelineRuntimeException {
        LOG.info("Beginning indexing items");
        int startCount = writer.docCount();

        /*
         * Look up the items and the properties that have a single value per
         * item. Iterate all the items.
         */
        jdbc.execute(stmtItems, new Object[0], new Jdbc.RowHandler() {
            public void processRow(final ResultSet rs) throws SQLException, PipelineRuntimeException {
                if (rs.getRow() % LOG_ROW_MODULUS == 0) {
                    LOG.info("Indexing item #" + rs.getRow());
                }

                String itemId = rs.getString(Strings.Database.Indexing.Item.Items.id);
                String itemNumber = rs.getString(Strings.Database.Indexing.Item.Items.itemNumber);
                String manufacturerId = rs.getString(Strings.Database.Indexing.Item.Items.manufacturerId);
                String manufacturerName = rs.getString(Strings.Database.Indexing.Item.Items.manufacturerName);
                String mainCategoryId = rs.getString(Strings.Database.Indexing.Item.Items.mainCategoryId);
                String brandId = rs.getString(Strings.Database.Indexing.Item.Items.brandId);
                String supplierId = rs.getString(Strings.Database.Indexing.Item.Items.supplierId);

                Document doc = new Document();
                addIndexedField(doc, Strings.Index.entryType, Strings.Index.item);
                addIndexedField(doc, Strings.Index.Item.itemId, itemId);
                // lower-casing means we can't use it for display later
                addIndexedField(doc, Strings.Index.Item.itemNumber, itemNumber.toLowerCase());
                addIndexedField(doc, Strings.Index.Item.manufacturerId, manufacturerId);
                addIndexedField(doc, Strings.Index.Item.manufacturerName, manufacturerName);
                addIndexedField(doc, Strings.Index.Item.brandId, brandId);
                if (supplierId != null) {
                    addIndexedField(doc, Strings.Index.Item.supplierId, supplierId.toLowerCase());
                }

                // write a default price of 0.0
                if (includePrices == true) {
                    addIndexedField(doc, Strings.Index.Item.price.toLowerCase(), SearchUtils.toPaddedString(0.0));
                    addIndexedField(doc, Strings.Index.Item.taxPrice.toLowerCase(), SearchUtils.toPaddedString(0.0));
                }

                addOtherItemDetails(doc, itemId, mainCategoryId, itemNumber);

                try {
                    writer.addDocument(doc);
                } catch (IOException e) {
                    LOG.error("Problem adding item to index", e);
                    throw new PipelineRuntimeException(e);
                }
            }
        });

        int stopCount = writer.docCount();
        // LOG.debug("Joseph's Comment Itemliststyleitem is " +
        // CustomStagesHelper.getKeyValue("Application.ItemListStyleItem"));
        LOG.info("Finished indexing " + (stopCount - startCount) + " items");
    }

    /**
     * Add item details
     * 
     * @param doc
     * @param itemId
     * @param mainCategoryId
     * @param itemNumber
     * @throws PipelineRuntimeException
     */
    protected void addOtherItemDetails(Document doc, String itemId, String mainCategoryId, String itemNumber)
            throws PipelineRuntimeException {
        addItemDetails(doc, itemId, itemNumber);
        addMainCategoryNames(doc, mainCategoryId);
    }

    /**
     * Returns the list of parameters that will be used for batch SQL
     * processing. This must be aligned with getRowHandlers() and
     * getItemDetailsSql().
     * 
     * @param itemId
     * @return
     */
    protected List<Object> getParameters(String itemId) {
        List<Object> list = Collections.synchronizedList(new ArrayList<Object>());
        // names and descriptions
        list.add(itemId);

        // category
        list.add(itemId);

        // assortment
        list.add(itemId);

        // warehouse
        list.add(itemId);

        // customer item name
        list.add(itemId);

        // price related fields
        if (this.includePrices == true) {
            // price
            list.add(itemId);

            // tax price
            list.add(itemId);

            // customer price
            list.add(itemId);

            // tax customer price
            list.add(itemId);
        }

        return list;
    }

    /**
     * Returns a list of RowHandlers that will process the result of batch SQL
     * processing. This must be aligned with getParameters() and
     * getItemDetailsSql().
     * 
     * @param doc
     * @param itemNumber
     * @return
     */
    protected List<RowHandler> getRowHandlers(Document doc, String itemNumber) {
        List<Jdbc.RowHandler> list = Collections.synchronizedList(new ArrayList<Jdbc.RowHandler>());

        // names and descriptions
        list.add(new NamesAndDescriptionsRowHandler(doc, itemNumber));

        // category
        list.add(new CategoryRowHandler(doc, this.categoryPathById));

        // assortment
        list.add(new AssortmentsRowHandler(doc));

        // warehouse
        list.add(new WarehousesRowHandler(doc));

        // customer item name
        list.add(new CustomerItemNamesRowHandler(doc));

        // price related fields
        if (this.includePrices == true) {
            // price
            list.add(new PriceRowHandler(doc));

            // price
            list.add(new TaxPriceRowHandler(doc));

            // customer price
            list.add(new CustomerPriceRowHandler(doc));

            // tax customer price
            list.add(new TaxCustomerPriceRowHandler(doc));
        }

        return list;
    }

    /**
     * Batch execute the SQL statements to query the item details.
     * 
     * @param doc
     * @param itemId
     * @param itemNumber
     * @throws PipelineRuntimeException
     */
    private void addItemDetails(Document doc, String itemId, String itemNumber) throws PipelineRuntimeException {
        Object[] params = (Object[]) getParameters(itemId).toArray(new Object[0]);
        Jdbc.RowHandler[] rowHandlers = (Jdbc.RowHandler[]) getRowHandlers(doc, itemNumber).toArray(
                new Jdbc.RowHandler[0]);
        jdbc.execute(stmtItemDetails, params, rowHandlers);
    }

    /* Lookup the name in all languages for the main category of the item. */
    private void addMainCategoryNames(final Document doc, final String mainCategoryId) throws PipelineRuntimeException {
        if (mainCategoryId != null) {
            jdbc.execute(stmtMainCategoryNames, new Object[] {mainCategoryId}, new Jdbc.RowHandler() {
                public void processRow(final ResultSet rs) throws SQLException {
                    String languageCode = rs.getString(Strings.Database.Indexing.Item.MainCategoryNames.languageCode);
                    String name = rs.getString(Strings.Database.Indexing.Item.MainCategoryNames.name);
                    addIndexedField(doc, Strings.Index.Item.mainCategoryNamePrefix + languageCode, name);
                }
            });
        }
    }
}
