package com.intentia.iec.pipeline.runtime.integration.erp.dao.impl;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Service;

import org.apache.log4j.Logger;

import com.infor.iec.ion.webservice.itemprice.InputOrderLines;
import com.infor.iec.ion.webservice.itemprice.ItemPrices;
import com.infor.iec.ion.webservice.itemprice.LinePriceRequestParams;
import com.infor.iec.ion.webservice.itemprice.LinePriceResponseParams;
import com.infor.iec.ion.webservice.itemprice.OutputOrderLines;
import com.infor.iec.ion.webservice.ordertotal.DistributedCharges;
import com.infor.iec.ion.webservice.ordertotal.DistributedTaxes;
import com.infor.iec.ion.webservice.ordertotal.OrderLines;
import com.infor.iec.ion.webservice.ordertotal.OrderTotalRequestParams;
import com.infor.iec.ion.webservice.ordertotal.OrderTotalResponseParams;
import com.infor.iec.ion.webservice.ordertotal.OrderTotals;
import com.intentia.iec.pipeline.runtime.integration.erp.dao.OrderDao;
import com.intentia.iec.pipeline.runtime.integration.erp.dao.factory.WebserviceDaoFactory;
import com.intentia.iec.pipeline.runtime.integration.erp.exception.ErpConnectionException;
import com.intentia.iec.pipeline.runtime.integration.erp.exception.ErpRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.erp.model.Charge;
import com.intentia.iec.pipeline.runtime.integration.erp.model.LinePrice;
import com.intentia.iec.pipeline.runtime.integration.erp.model.OrderLinePriceRequest;
import com.intentia.iec.pipeline.runtime.integration.erp.model.OrderTotal;
import com.intentia.iec.pipeline.runtime.integration.erp.model.OrderTotalRequest;
import com.intentia.iec.pipeline.runtime.integration.erp.model.Tax;
import com.intentia.iec.pipeline.runtime.integration.erp.utils.ErpUtilHelper;
import com.intentia.iec.pipeline.runtime.integration.erp.model.OrderLinesPrice;

public class OrderDaoWSGenericImpl implements OrderDao {
	
	private static final Logger LOG = Logger.getLogger(OrderDaoWSGenericImpl.class);
		
	public OrderTotal getOrderTotal(OrderTotalRequest request) throws ErpRuntimeException, ErpConnectionException {
		OrderTotals orderTotalPort;
		try {
			orderTotalPort = getOrderTotalPort();
		} catch (MalformedURLException e) {
			throw new ErpConnectionException(e.toString());
		}
		OrderTotal orderTotal = new OrderTotal();
		OrderTotalRequestParams wsRequest = createOrderTotalRequestParams(request);		
		
		//Invoke webservice method
		ErpUtilHelper.debugInOrderTotalPrice(wsRequest);
		//Set BindingProvider Endpoint
		try {
			ErpUtilHelper.setBindingProvider((BindingProvider)orderTotalPort, new URL(WebserviceDaoFactory.WSDL_ENDPOINT_ORDERTOTAL));
		} catch(MalformedURLException e){
			throw new ErpConnectionException(e.toString()); 
		}
		OrderTotalResponseParams wsResponse = orderTotalPort.getOrderTotal(wsRequest);  
		ErpUtilHelper.debutOutOrderTotalPrice(wsResponse);
		if (wsResponse != null ) {
			orderTotal = createOrderTotalResponseParams(wsResponse);
			if (wsResponse.getErrorReasonCode() != null && !wsResponse.getErrorReasonCode().trim().isEmpty()) {
				flagErrorOrderTotal(orderTotal, wsResponse.getErrorReasonCode(), wsResponse.getErrorReasonDescription());				
			}
		} else {
			flagErrorOrderTotal(orderTotal, "Code error null", "WSResponse is null");	
		}

		return orderTotal;
	}

	
	public OrderLinesPrice getOrderLinePrice(OrderLinePriceRequest request) throws ErpRuntimeException, ErpConnectionException {
		ItemPrices itemPricePort;
		try {
			itemPricePort = getItemPricePort();
		} catch (MalformedURLException e) {
			throw new ErpConnectionException(e.toString());
		}
		OrderLinesPrice orderLines = new OrderLinesPrice();
		List<LinePrice> linePrices = new ArrayList<LinePrice>();
		LinePriceRequestParams wsRequest = createLinePriceRequestParams(request);
		
		//Invoke webservice method
		ErpUtilHelper.debugInOrderLinePrice(wsRequest);
		//Set BindingProvider
		try {
			ErpUtilHelper.setBindingProvider((BindingProvider)itemPricePort, new URL(WebserviceDaoFactory.WSDL_ENDPOINT_ITEMPRICE));
		} catch(MalformedURLException e){
			throw new ErpConnectionException(e.toString()); 
		}
		LinePriceResponseParams wsResponse = itemPricePort.getOrderLinePrice(wsRequest);
		ErpUtilHelper.debutOutOrderLinePrice(wsResponse);
		// create return values
		if (wsResponse != null) {
			linePrices = creatLinePriceResponseParam(wsResponse);
			orderLines.setOrderline(linePrices);
			if (wsResponse.getErrorReasonCode() != null && !wsResponse.getErrorReasonCode().trim().isEmpty()) {
				flagErrorOrderLines(orderLines,wsResponse.getErrorReasonCode(), wsResponse.getErrorReasonDescription());
			} 
		} else {
			flagErrorOrderLines(orderLines, "Code error null", "WSResponse is null");	
		}

		return orderLines;
	}
	

	private OrderTotalRequestParams createOrderTotalRequestParams(OrderTotalRequest request){
		OrderTotalRequestParams wsRequest = new OrderTotalRequestParams();
		wsRequest.setTenantID(request.getTenantId());
		wsRequest.setAccountingEntityID(request.getAccountingEntityId());
		wsRequest.setCustomerPartyID(request.getCustomerPartyId());
		wsRequest.setOrderTypeCode(request.getOrderType());
		wsRequest.setCurrencyID(request.getCurrencyId());
		wsRequest.setUserName(WebserviceDaoFactory.WEBSERVICEUSERID);
		
		List<OrderLines> orderLines = wsRequest.getArrayOfOrderLines();
		for (LinePrice orderLine : request.getOrderLines()) {
			OrderLines wsInputOrderLines = new OrderLines();
			wsInputOrderLines.setItemID(orderLine.getItemId());
			wsInputOrderLines.setCustomerItemID(orderLine.getCustomerItemId());
			wsInputOrderLines.setQuantity(orderLine.getQuantity());
			wsInputOrderLines.setUnitCode(orderLine.getUnitCode());
			wsInputOrderLines.setWarehouseLocationID(orderLine.getWarehouseId());
			wsInputOrderLines.setConfigurationID(orderLine.getConfigurationNumber());
			wsInputOrderLines.setShippingAddressID(orderLine.getShippingAddressId());
			orderLines.add(wsInputOrderLines);
		}
		return wsRequest;
	}
	
	private LinePriceRequestParams createLinePriceRequestParams(OrderLinePriceRequest request){
		LinePriceRequestParams wsRequest = new LinePriceRequestParams();
		wsRequest.setTenantID(request.getTenantId());
		wsRequest.setAccountingEntityID(request.getAccountingEntityId());
		wsRequest.setCurrencyID(request.getCurrencyId());
		wsRequest.setCustomerPartyID(request.getCustomerPartyId());
		wsRequest.setOrderTypeCode(request.getOrderType());
		wsRequest.setUserName(WebserviceDaoFactory.WEBSERVICEUSERID);

		// Add input orderLines
		List<InputOrderLines> wsInputOrderLines = wsRequest
				.getArrayOfInputOrderLines();
		for (LinePrice line : request.getOrderlines()) {
			InputOrderLines wsInputLine = new InputOrderLines();
			wsInputLine.setItemID(line.getItemId());
			wsInputLine.setConfigurationID(line.getConfigurationNumber());
			wsInputLine.setCustomerItemID(line.getCustomerItemId());
			wsInputLine.setQuantity(line.getQuantity());
			wsInputLine.setUnitCode(line.getUnitCode());
			wsInputLine.setWarehouseLocationID(line.getWarehouseId());
			wsInputLine.setShippingAddressID(line.getShippingAddressId());
			wsInputOrderLines.add(wsInputLine);
		}		
		return wsRequest;
	}
	
	private List<LinePrice> creatLinePriceResponseParam(LinePriceResponseParams wsResponse){
		List<LinePrice> orderLinePrices = new ArrayList<LinePrice>();
		for(OutputOrderLines wsOutoutLine : wsResponse.getArrayOfOutputOrderLines()) {
			LinePrice orderLinePrice = new LinePrice();
			orderLinePrice.setCurrencyId(wsOutoutLine.getCurrencyID());
			orderLinePrice.setItemId(wsOutoutLine.getItemID());
			orderLinePrice.setQuantity(wsOutoutLine.getQuantity());
			orderLinePrice.setTotalAmount(wsOutoutLine.getUnitPriceAmount() != null? wsOutoutLine.getTotalAmount() : new Double(-1) );
			orderLinePrice.setExtendedAmount(wsOutoutLine.getExtendedAmount());
			orderLinePrice.setLineAmount(wsOutoutLine.getExtendedAmount());
			if(wsOutoutLine.getUnitPriceAmount() != null){
				orderLinePrice.setSalesPrice(wsOutoutLine.getUnitPriceAmount());
			}
			else{
				orderLinePrice.setSalesPrice(new Double(-1));
			}
			if(wsOutoutLine.getDistributedChargeAmount() != null){
				orderLinePrice.setDistributedChargeAmount(wsOutoutLine.getDistributedChargeAmount());
			}
			//Add to list of orderLine prices
			orderLinePrices.add(orderLinePrice);
		}
		
		return orderLinePrices;
	}
	
	private OrderTotal createOrderTotalResponseParams(OrderTotalResponseParams wsResponse){
		OrderTotal orderTotal = new OrderTotal();
		List<Charge> charges = new ArrayList<Charge>();
		List<Tax> taxes = new ArrayList<Tax>();
		
		//Get Distributed Charges data
		for(DistributedCharges wsoutDistributedCharge : wsResponse.getArrayOfDistributedCharges()) {
			Charge charge =  new Charge();
			charge.setAmount(wsoutDistributedCharge.getDistributedChargeAmount());
			charge.setLanguageCode(wsoutDistributedCharge.getDescriptionLanguageCode());
			charge.setDescription(wsoutDistributedCharge.getDistributedChargeDescription());
			//Add to list of charge
			charges.add(charge);
		}
		orderTotal.setDistributedCharges(charges);
		
		//Get Distributed tax data
		for(DistributedTaxes wsoutDistributedTax : wsResponse.getArrayOfDistributedTaxes()) {
			Tax tax = new Tax();
			tax.setAmount(wsoutDistributedTax.getDistributedTaxAmount());
			tax.setLanguageCode(wsoutDistributedTax.getDescriptionLanguageCode());
			tax.setDescription(wsoutDistributedTax.getDistributedTaxDescription());					
			//Add to list of charge
			taxes.add(tax);
		}			
		orderTotal.setDistributedTaxes(taxes);
		
		orderTotal.setCurrencyId(wsResponse.getCurrencyID());
		orderTotal.setDistributedCharges(charges);
		orderTotal.setDistributedTaxes(taxes);
		orderTotal.setExtendedAmount(wsResponse.getExtendedAmount());
		orderTotal.setRoundingOff(wsResponse.getRoundingOff() == null ? new Double(0) : wsResponse.getRoundingOff());
		orderTotal.setTotalAmount(wsResponse.getTotalAmount());		
		orderTotal.setGrandTotal(wsResponse.getTotalAmount());
		orderTotal.setTotalPrice(wsResponse.getExtendedAmount());
		
		return orderTotal;		
	}
	
	private void flagErrorOrderTotal(OrderTotal orderTotal, String code, String msgError){
		orderTotal.setHasWSCallError(true);
		orderTotal.setMsgCodeError(code);
		orderTotal.setMsgError(msgError);
	}
	
	private void flagErrorOrderLines(OrderLinesPrice orderLines, String code, String msgError ){
		orderLines.setHasWSCallError(true);
		orderLines.setMsgCodeError(code);
		orderLines.setMsgError(msgError);
	}
	

	private OrderTotals getOrderTotalPort() throws MalformedURLException{
		//initialize OrderTotalsService
		LOG.debug("OrderTotal initialize service: "+WebserviceDaoFactory.WSDL_URL_ORDERTOTAL);
		URL url_wsdl = new URL(WebserviceDaoFactory.WSDL_URL_ORDERTOTAL);
		Service service = Service.create(url_wsdl, new QName("http://infor.com", "OrderTotalService"));
		ErpUtilHelper.setSOAPLoggingHandler(service);
		OrderTotals orderTotals =  service.getPort(OrderTotals.class);
		return orderTotals;
	}
	
	private ItemPrices getItemPricePort() throws MalformedURLException{
		//initialize ItemPriceService
		LOG.debug("ItemPrice initialize service: "+WebserviceDaoFactory.WSDL_URL_ITEMPRICE);
		URL url_wsdl = new URL(WebserviceDaoFactory.WSDL_URL_ITEMPRICE);
		Service service = Service.create(url_wsdl, new QName("http://infor.com", "ItemPricesService"));
		ErpUtilHelper.setSOAPLoggingHandler(service);
		ItemPrices itemPrice =  service.getPort(ItemPrices.class);
		return itemPrice;
	}
	

}
