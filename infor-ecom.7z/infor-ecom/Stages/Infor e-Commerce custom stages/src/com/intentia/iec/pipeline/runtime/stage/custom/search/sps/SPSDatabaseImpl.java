package com.intentia.iec.pipeline.runtime.stage.custom.search.sps;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.search.DatabaseImpl;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Request;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Strings;

/**
 * Helper class for generating attributes of spare parts.
 *
 */
public class SPSDatabaseImpl extends DatabaseImpl {

    /* (non-Javadoc)
     * @see com.intentia.iec.pipeline.runtime.stage.custom.search.DatabaseImpl#mergeItemAttributesFromDatabase(java.util.Map, com.intentia.iec.pipeline.runtime.stage.custom.search.Request)
     */
    public void mergeItemAttributesFromDatabase(final Map<String, Map<String, String>> rows, final Request request)
            throws PipelineRuntimeException {

        // Build a comma separated list of item IDs
        StringBuilder idList = new StringBuilder(100);
        String[] arr = rows.keySet().toArray(EMPTY_STRING_ARRAY);
        for (int i = 0, n = arr.length; i < n; i++) {
            idList.append(arr[i]);
            if (i < n - 1) {
                idList.append(", ");
            }
        }

        String sql = SPSStrings.Database.Searching.Item.PassiveAttributes.sqlHead + idList
                + Strings.Database.Searching.Item.PassiveAttributes.sqlTail;

        jdbc.execute(sql, new Object[] {request.getUserId(), request.getUserGroupId(), request.getWarehouseId(),
        		request.getUserId(), request.getUserGroupId(), request.getWarehouseId(),
                request.getShippingCountryCode(), request.getListPriceGroupId(), request.getCurrencyCode(),
                request.getResellPriceGroupId(), request.getCurrencyCode(), request.getLanguageCode(),
                request.getUserGroupId(), request.getLanguageCode(), request.getLanguageCode(),
                request.getUserGroupId(), request.getCurrencyCode(), request.getUserGroupId() }, new Jdbc.RowHandler() {

        	/* (non-Javadoc)
        	 * @see com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc.RowHandler#processRow(java.sql.ResultSet)
        	 */
        	public void processRow(final ResultSet rs) throws SQLException, PipelineRuntimeException {

                String id = rs.getString(Strings.Database.Searching.Item.PassiveAttributes.id);
                Map<String, String> row = rows.get(id);

                row.put(Strings.Response.ItemList.itemId, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.itemNumber));
                row.put(Strings.Response.ItemList.hasSubItems, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.hasSubItems));
                row.put(Strings.Response.ItemList.imageThumb, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.imageThumb));
                row.put(Strings.Response.ItemList.isEmphasized, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.isEmphasized));
                row.put(Strings.Response.ItemList.itemCode,
                // N.B. Hard-coded value
                        Strings.Database.Searching.Item.PassiveAttributes.normal);
                row.put(Strings.Response.ItemList.itemTax, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.rate));
                row.put(Strings.Response.ItemList.listPrice, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.listPrice));
                row.put(Strings.Response.ItemList.resellPrice, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.resellPrice));
                row.put(Strings.Response.ItemList.manufacturerId, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.manufacturerId));
                row.put(Strings.Response.ItemList.minimumQty, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.minQty));
                row.put(Strings.Response.ItemList.modularQty, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.modularQty));
                row.put(Strings.Response.ItemList.mvxConfigurable, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.isMvxConfigurable));
                row.put(Strings.Response.ItemList.styleId, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.styleId));
                row.put(Strings.Response.ItemList.supplierId, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.supplierId));
                row.put(Strings.Response.ItemList.mainIdConstraintGenerated, id);

                // Additional passive attributes for version 13.1
                row.put(Strings.Response.ItemList.brandId, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.brandId));
                row.put(Strings.Response.ItemList.brandName, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.brandName));
                row.put(Strings.Response.ItemList.description, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.description));
                row.put(Strings.Response.ItemList.imagePreview, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.imagePreview));
                row.put(Strings.Response.ItemList.isStyle, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.isStyle));
                row.put(Strings.Response.ItemList.mainCategoryId, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.mainCategoryId));
                row.put(Strings.Response.ItemList.mainCategoryName, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.mainCategoryName));
                row.put(Strings.Response.ItemList.manufacturerName, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.manufacturerName));
                row.put(Strings.Response.ItemList.netListPrice, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.netListPrice));
                row.put(Strings.Response.ItemList.taxPrice, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.taxPrice));
                row.put(Strings.Response.ItemList.unit, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.unit));
                row.put(Strings.Response.ItemList.unitCode, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.unitCode));
                row.put(Strings.Response.ItemList.rating, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.itemRating));

                row.put(Strings.Response.ItemList.customerItemId, rs
                        .getString(Strings.Database.Searching.Item.PassiveAttributes.customerItemId));

                row.put(SPSStrings.Response.ItemList.hasDrawing, rs
                        .getString(SPSStrings.Database.Searching.Item.PassiveAttributes.hasDrawing));

                row.put(SPSStrings.Response.ItemList.hasChildItems, rs
                        .getString(SPSStrings.Database.Searching.Item.PassiveAttributes.hasChildItems));

                row.put(SPSStrings.Response.ItemList.systemID, id);
            }
        });
    }

}
