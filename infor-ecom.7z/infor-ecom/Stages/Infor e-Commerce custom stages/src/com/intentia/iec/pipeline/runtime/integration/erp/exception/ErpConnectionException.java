package com.intentia.iec.pipeline.runtime.integration.erp.exception;

public class ErpConnectionException extends Exception {

	private static final long serialVersionUID = 1L;

	public ErpConnectionException() {
		super();
	}

	public ErpConnectionException(String message) {
		super(message);
	}

	public ErpConnectionException(Throwable cause) {
		super(cause);
	}

	public ErpConnectionException(String message, Throwable cause) {
		super(message, cause);
	}

}
