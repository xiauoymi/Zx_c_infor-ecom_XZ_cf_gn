package com.intentia.iec.pipeline.runtime.stage.custom;

import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.businessobject.Parameters;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


public class HandleOrderFormDiscountColumn implements PipelineStage {

	/**
	 * HandleOrderFormDiscountColumn
	 * 
	 * Developed by: Gerald Tajonera
	 * 
	 * HandleOrderFormDiscountColumn is determines showDiscount column in OrderForm.
	 * 
	 *
	 * 
	 */
	 
	private static final Logger LOG = Logger.getLogger(HandleOrderFormDiscountColumn.class);
	
	private XMLResultset xmlResulset = null;
	
	private Parameters param = null;
	
	private Document request = null;
	
	private Double LineDisPercent = null;
	
	private Double LineDiscount = null;
	
	public void execute(PipelineContext context) throws PipelineRuntimeException {
		
		LOG.debug("Inside HandleOrderFormDiscountColumn.execute()");
		
		if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
		
		xmlResulset = (XMLResultset) context.getResponse();
		
        try {
        	xmlResulset.beforeFirst();
            request = xmlResulset.getDocument();
            param = xmlResulset.getParameters();
            param.set("showDiscount", false);
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Failed to obtain result set as XML document!", e);
        } catch (Exception e) {
            throw new PipelineRuntimeException("Failed to set showDiscount in params!", e);
        } 
        
        try {	        
	        // Get OrderLine node in the request document
	        NodeList nodeList = XPathAPI.selectNodeList(request, "//row/OrderLine");
	        
	        if (nodeList.getLength() > 0) {
		        for (int i = 0; i < nodeList.getLength(); i++) {
		        	Node node = nodeList.item(i);
		        			        	
		        	LineDisPercent = Double.parseDouble(node.getAttributes().getNamedItem("LineDisPercent").getNodeValue());
		        	LineDiscount = Double.parseDouble(node.getAttributes().getNamedItem("LineDiscount").getNodeValue());
		    		
		    		if ((LineDisPercent > 0.0 || LineDiscount > 0.0) && (Double.parseDouble(node.getAttributes().getNamedItem(ConstantsForSales.RESELLPRICE).getNodeValue()) > 0.0)) {
		    			param.set("showDiscount", true);
		    			LOG.debug("showDiscount: TRUE");
		    			break;
		    		}
		        }
		        
	        }
			
        } catch (Exception e) {
        	LOG.debug("Error Extracting Orderline subset");
        }
		
		LOG.debug("Exiting HandleOrderFormDiscountColumn.execute()");
	}
}
