package com.intentia.iec.pipeline.runtime.integration.ia.model;

import java.util.Comparator;

public class IaRecommendation {

	private String itemNumber;
	private float score;

	public String getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	public float getScore() {
		return score;
	}

	public void setScore(float score) {
		this.score = score;
	}

	public static Comparator<IaRecommendation> Comparator = new Comparator<IaRecommendation>() {
		public int compare(IaRecommendation r1, IaRecommendation r2) {
			// descending order
			return (r1.getScore() > r2.getScore() ? -1 : (r1.getScore() == r2
					.getScore() ? 0 : 1));

		}
	};

	@Override
	public String toString() {
		StringBuilder campaignStr = new StringBuilder();
		campaignStr.append("{");
		campaignStr.append("itemNumber:" + this.itemNumber + ", ");
		campaignStr.append("score:" + this.score);
		campaignStr.append("}");
		return campaignStr.toString();
	}

}
