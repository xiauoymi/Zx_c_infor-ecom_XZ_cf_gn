/*
 * Created on 26-03-2004 
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.Request;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.Resultset;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.connection.ConnectorException;
import com.intentia.iec.connection.IMovexApiResultset;
import com.intentia.iec.connection.IMovexConnection;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.CommitPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.Decimal;
import com.intentia.iec.pipeline.runtime.stage.utils.DeletePipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.sqlserver.common.DatabaseType;
import com.intentia.iec.sqlserver.runtime.procedure.Parameter;
import com.intentia.iec.sqlserver.runtime.procedure.StageCallProcedure;
import com.intentia.iec.util.XMLDateFormat;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

/**
 * Copy the order information in the response of the pipeline context to the
 * previous order tables of the e-Sales database. The stage leaves it to a
 * stored procedure to handle configured items and bill of material.
 * <p>
 * This stage contains some very specific functionality for the order handling
 * pipelines of the e-Sales application. It has no use elsewhere.
 * <p>
 * The stage executes a number of business object methods in the e-Sales
 * application using hardcoded class names:
 * <ul>
 * <li><tt>com.intentia.iec.runtime.pipeline.PreviousOrder.SaveAsPreviousOrder</tt></li>
 * <li><tt>com.intentia.iec.runtime.pipeline.User.GetUserInfoForPreviousOrder</tt></li>
 * <li><tt>com.intentia.iec.runtime.pipeline.CurrentOrder.Delete</tt></li>
 * <li>Stored procedure: <tt>OrderExecuteAddConfigItems</tt></li>
 * </ul>
 * Here is an outline of what is going on inside this stage:
 * <p>
 * The execution of the stage is guarded by the value of the
 * <tt>Save Order Locally</tt> element of the application property group
 * <tt>Order</tt> being <tt>true</tt>.
 * <p>
 * Status is communicated between the order pipeline stages in the output
 * parameter named <tt>status</tt> of the response. If there is no order
 * information in the response when this stage is initiated then the status
 * parameter is set to the value <tt>-10</tt> and the execution is aborted. If
 * the <tt>OrderLine</tt> subset of the response is empty then the status is
 * set to <tt>-11</tt> and the execution is aborted. If the status parameter
 * already holds a negative value from a previous order stage the execution is
 * also aborted.
 * <p>
 * The stage executes the <tt>SaveAsPreviousOrder</tt> method on the
 * <tt>PreviousOrder</tt> business object with a request built up from copying
 * order header fields and order lines from the response in the pipeline
 * context.
 * <p>
 * All order header fields are copied one-to-one with these exceptions:
 * <ol>
 * <li> The order header field named <tt>ShippingCountryName</tt> in the
 * response is also copied to a order header field in the request named
 * <tt>ShippingCountry</tt>. </li>
 * <li>The request order header fields with names <tt>OrderID</tt> and
 * <tt>ApprovedOrderID</tt> gets a value taken from the input parameter named
 * <tt>submittedOrderID</tt>. </li>
 * <li> The <tt>GetUserInfoForPreviousOrder</tt> method on the <tt>User</tt>
 * business object is called to get information about the user to fill into the
 * order header. The method is called with an input parameter named
 * <tt>UserID</tt> which gets its value from the request order header field
 * <tt>UserID</tt>. </li>
 * <li> The request order header fields named <tt>UserPhone</tt>,
 * <tt>UserEmail</tt>, <tt>UserNumber</tt> and <tt>UserName</tt> are
 * taken from the fields in the <tt>User.GetUserInfoForPreviousOrder</tt>
 * method result named <tt>Phone</tt>, <tt>Email</tt>, <tt>ExtID</tt>
 * and <tt>UserName</tt>. </li>
 * <li> The request order header fields named <tt>OrderStatus</tt>,
 * <tt>OrderLineLoStatusID</tt> and <tt>OrderLineHiStatusID</tt> are set
 * from one of these sources with falling priority:
 * <ul>
 * <li> The response field <tt>InitOrderStatus</tt> from the
 * <tt>User.GetUserInfoForPreviousOrder</tt> method call. </li>
 * <li> The value of the property group element <tt>Initial Order Status</tt>
 * from the application property group <tt>Ordering</tt>. </li>
 * <li> The value <tt>'22'</tt> if the application is Movex enabled
 * (application property <tt>Movex Connector.Enable == true</tt>) or the
 * value <tt>'inc'</tt> (incoming) if the application is standalone (<tt>Movex Connector.Enable != true</tt>).
 * </li>
 * </ul>
 * </li>
 * <li> The request order header field named <tt>OrderDate</tt> gets the value
 * of the current system time. </li>
 * </ol>
 * All order lines are processed and all order line fields are copied one-to-one
 * with these exceptions:
 * <ol>
 * <li> It is checked that the <tt>IsVisible</tt> and <tt>IsActive</tt>
 * attributes are not <tt>'N'</tt>. Otherwise an exception is thrown. </li>
 * <li> The <tt>ShippingCountryName</tt> attribute is also copied to the
 * <tt>ShippingCountry</tt> attribute. The <tt>Quantity</tt> attribute is
 * also copied to the <tt>RemainingQuantity</tt> attribute. </li>
 * <li> The <tt>OrderLineStatusID</tt> attribute is set to same value as
 * described above for the <tt>OrderStatus</tt> attribute in the order header.
 * </li>
 * <li> The <tt>DeliveredQuantity</tt> attribute is set to <tt>0</tt>.
 * </li>
 * </ol>
 * Now the <tt>PreviousOrder.SaveAsPreviousOrder</tt> method is executed with
 * the built request. The auto-generated key for the submitted order is saved
 * for use in the next steps.
 * <p>
 * Then the stored procedure <tt>OrderExecuteAddConfigItems</tt> is executed
 * to handle the special cases of items that are either complex or contains bill
 * of material subitems.
 * <p>
 * To cleanup the order just saved are removed from the users shopping basket.
 * This is performed by executing the <tt>Delete</tt> method of the
 * <tt>CurrentOrder</tt> business object with the main key attribute
 * &lt;OrderID&gt; set to the value of the <tt>OrderID</tt> attribute of the
 * request.
 * <p>
 * At last the successful completion of the stage is communicated to the rest of
 * the pipeline by setting the <tt>status</tt> output parameter to <tt>0</tt>.
 */
public class SaveAsPreviousOrder implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(SaveAsPreviousOrder.class);

    private static final Map<String, String> fieldMapping = new HashMap<String, String>();

    private List orderItems;

    static {
        initMap();
    };

    private static void initMap() {
        fieldMapping.put(ConstantsForSales.ITEMID, ConstantsForSales.ITNO);
        fieldMapping.put(ConstantsForSales.ITEMNAME, ConstantsForSales.ITDS);
        fieldMapping.put(ConstantsForSales.LINENUMBER, ConstantsForSales.PONR);
        fieldMapping.put(ConstantsForSales.LINESUFFIX, ConstantsForSales.POSX);
        fieldMapping.put(ConstantsForSales.CONFIRMEDDELIVERYDATE, ConstantsForSales.CODT);
        fieldMapping.put(ConstantsForSales.LINEPRICE, ConstantsForSales.NLAM);
        fieldMapping.put(ConstantsForSales.QUANTITY, ConstantsForSales.ORQT);
        fieldMapping.put(ConstantsForSales.REQUESTEDDELIVERYDATE, ConstantsForSales.DWDT);
        fieldMapping.put(ConstantsForSales.ORDERLINECOMMENT, ConstantsForSales.PONR);
        fieldMapping.put(ConstantsForSales.UNITCODE, ConstantsForSales.SPUN);
        fieldMapping.put(ConstantsForSales.MVX_CONFIGURABLE_ID, ConstantsForSales.CFIN);
        fieldMapping.put(ConstantsForSales.CUSTOMERITEMID, ConstantsForSales.POPN);
        
    }

    public void execute(PipelineContext context) throws PipelineRuntimeException {

        try {
            if (!CustomStagesHelper.getKeyValue("Ordering.Save Order Locally").equals("true")) {
                return;
            }

            Request request = (Request) context.getRequest();
            if (request == null) {
                return;
            }
            if (!(request instanceof XMLRequest)) {
                throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
            }
            XMLRequest xmlRequest = (XMLRequest) request;

            Resultset response = (Resultset) context.getResponse();
            LOG.debug("Inside SaveAsPreviousOrder.execute: " + response.toString());
            if ((response == null) || (!response.moveFirst())) {
                LOG.debug("Aborting save because there is no order");
                // Set return code for execute
                CustomStagesHelper.getResponseParameters(context).setint(ConstantsForSales.STATUS, -10);
                return;
            }

            // Check number of lines in order
            Resultset rsOrderLines = response.getResultset("OrderLine");
            if ((rsOrderLines == null) || (rsOrderLines.rowCount() == 0)) {
                LOG.debug("Aborting save because order has no order lines");
                // Set return code for execute
                CustomStagesHelper.getResponseParameters(context).setint(ConstantsForSales.STATUS, -11);
                return;
            }

            CustomStagesHelper.extractRequestParameters(xmlRequest);
            Integer status = response.getParameters().getInteger(ConstantsForSales.STATUS);
            if ((status != null) && (status.intValue() < 0)) {
                // A previous stage has failed - this order should not be saved
                // then
                LOG.debug("Aborting save because status = " + status);
                return;
            }

            String languageCode = xmlRequest.getParameters().getString("@LanguageCode");
            String currentOrderID = response.getString("OrderID");

            try {
                // Save the order
                XMLResultset res = saveOrder(response, xmlRequest, rsOrderLines, currentOrderID, languageCode, context);

                String newPrevOrderID = res.getParameters().getString("key");
                response.getParameters().setString("submittedOrderID", newPrevOrderID);
     
                // Add configurated items
                addConfiguratedItems(currentOrderID, newPrevOrderID, languageCode);

                // Delete current order
                deleteOrder(currentOrderID);
            } catch (PipelineRuntimeException e) {
                LOG.debug("Error while saving previous order...\n" + e.toString());
                CustomStagesHelper.getResponseParameters(context).
                setint(ConstantsForSales.STATUS, -12);
                return;
            } catch (ParametersException e) {
                LOG.debug("Error while saving previous order...\n" + e.toString());
                CustomStagesHelper.getResponseParameters(context).
                setint(ConstantsForSales.STATUS, -12);
                return;
            }
            // Set common return code for execute
            CustomStagesHelper.getResponseParameters(context).setint(ConstantsForSales.STATUS, 0);

        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Error in SaveAsPreviousOrder stage", e);
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Error in SaveAsPreviousOrder stage", e);
        }
    }

	private void saveOrderStandAlone(Resultset rsOrderLines, CommitPipelineExecuter insertPO, String initOrderStatusCode,
			String submittedOrderKey)
            throws ResultsetException, PipelineRuntimeException {
        // Loop through the order lines
        rsOrderLines.beforeFirst();
        for (int i = 1; rsOrderLines.moveNext(); ++i) {
            String lineSuffix = "0"; //Store lineSuffix value; Fix for 9889 - OrderId format should be <OrderId>_<LineNumber>_<LineSuffix>
            final String orderLineNo = String.valueOf(i);
            insertPO.addSubset("OrderLine");
            final Iterator itLineFields = rsOrderLines.getNames().iterator();
			boolean hasLineNumber=false;
            while (itLineFields.hasNext()) {
				
                final String attrName = (String) itLineFields.next();
                final String attrValue = rsOrderLines.getString(attrName);
                // Update OrderLineID in M3 scenario duplicated Order lines
                // after replication
                
                //Fix for 9889 - OrderLineID format should be <OrderId>_<LineNumber>_<LineSuffix>
                if ("LineNumber".equals(attrName)) {
                	// Standalone - reset Order IDs
                    insertPO.setSubsetAttribute(attrName, orderLineNo);
					hasLineNumber=true;
                } else if ("OrderLineID".equals(attrName)) {
                		String submittedOrderLineKey = submittedOrderKey + "_" + orderLineNo + "_" + lineSuffix;
                		insertPO.setSubsetAttribute(attrName, submittedOrderLineKey);
                } else {
                    insertPO.setSubsetAttribute(attrName, attrValue);
                }

                if ("IsVisible".equals(attrName)) {
                    if ("N".equals(attrValue)) {
                        throw new PipelineRuntimeException("Invisible item in orderline");
                    }
                } else if ("IsActive".equals(attrName)) {
                    if ("N".equals(attrValue)) {
                        throw new PipelineRuntimeException("Inactive item in orderline");
                    }
                } else if ("ShippingCountryName".equals(attrName)) {
                    insertPO.setSubsetAttribute("ShippingCountry", attrValue);
                } else if ("Quantity".equals(attrName)) {
                    insertPO.setSubsetAttribute("RemainingQuantity", attrValue);
                }
            }

			//check if the OrderLine has no lineNumber 
			if(!hasLineNumber){
				insertPO.setSubsetAttribute("LineNumber", orderLineNo);
			}
            
            insertPO.setSubsetAttribute("OrderLineStatusID", initOrderStatusCode);
            insertPO.setSubsetAttribute("DeliveredQuantity", "0");
        }
    }
	
	private void saveDistributedCharges(final Resultset response, CommitPipelineExecuter insertPO) 
    	throws ResultsetException {
    	Resultset rsDistCharges = response.getResultset("DistributedCharges");
    	
    	rsDistCharges.beforeFirst();
        for (int i = 1; rsDistCharges.moveNext(); ++i) {
        	insertPO.addSubset("DistributedCharges");
            insertPO.setSubsetAttribute("ReasonCode", rsDistCharges.getString("ReasonCode"));
            insertPO.setSubsetAttribute("Value", rsDistCharges.getString("Value"));
        }
    	
    }
    
    private void saveDistributedTaxes(final Resultset response, CommitPipelineExecuter insertPO) 
    	throws ResultsetException {
    	Resultset rsDistTaxes = response.getResultset("DistributedTaxes");
    	
    	rsDistTaxes.beforeFirst();
        for (int i = 1; rsDistTaxes.moveNext(); ++i) {
        	insertPO.addSubset("DistributedCharges");
            insertPO.setSubsetAttribute("ReasonCode", rsDistTaxes.getString("ReasonCode"));
            insertPO.setSubsetAttribute("Value", rsDistTaxes.getString("Value"));
        }
        	
    }

    private void saveOrderM3Enabled(PipelineContext context, String movexOrderID, IMovexConnection con,
            Resultset rsOrderLines, CommitPipelineExecuter insertPO, String initOrderStatusCode)
            throws PipelineRuntimeException, ResultsetException {

        this.orderItems = new ArrayList();
        XMLResultset head = (XMLResultset) context.getResponse();
        Map<String, String> lines = new HashMap<String, String>();
        lines.put(IMovexConnection.TRANSACTION, ConstantsForSales.LST_LINE);
        lines.put(ConstantsForSales.CONO, head.getString(ConstantsForSales.MVXCOMPANY));
        // Use order ID from parameter or form header in response to merge.
        lines.put(ConstantsForSales.ORNO, movexOrderID);

        // retrieve order lines data from Movex
        IMovexApiResultset apiRes = CustomStagesHelper.callMovex(context, con, lines, ConstantsForSales.MVXSTATUS);
        if (apiRes == null) {
            throw new PipelineRuntimeException("Unable to retrieve order lines from Movex");
        }

        Iterator apiIter = apiRes.iterator();
        Map<String, Map> orderLinesMap = getOrderLinesAsMap(rsOrderLines);
        boolean orderlineCommentFlag = hasOrderLineComment(((XMLResultset) context.getResponse()).getDocument());
        String cono = ((XMLResultset) context.getResponse()).getString(ConstantsForSales.MVXCOMPANY);

        for (int i = 1; apiIter.hasNext(); ++i) {            
            Map mvxLine = (Map) apiIter.next();
            String orderLineID = movexOrderID + "_" + (String) mvxLine.get(ConstantsForSales.PONR) + "_"
                    + (String) mvxLine.get(ConstantsForSales.POSX);
            Map<String, String> orderLine = orderLinesMap.get(orderLineID);
            List<String> fieldList = null;
            if (orderLine != null) {
                fieldList = new ArrayList<String>(orderLine.keySet());
            } else {
                fieldList = new ArrayList<String>(fieldMapping.keySet());
            }            
            fieldList.add(ConstantsForSales.MVX_CONFIGURABLE_ID);
            fieldList.add(ConstantsForSales.CUSTOMERITEMID);
            fieldList.add(ConstantsForSales.PROMOTION_CODE);
            Iterator<String> it = fieldList.iterator();
            
            insertPO.addSubset(ConstantsForSales.ORDERLINE);
            insertPO.setSubsetAttribute(ConstantsForSales.ORDERLINEID, orderLineID);            
            while (it.hasNext()) {
                final String attrName = it.next();
                String attrValue = null;

                if (fieldMapping.containsKey(attrName)) {
                    Object fieldValue = fieldMapping.get(attrName);
                    attrValue = (String) mvxLine.get(fieldValue);
                } else if (orderLine != null && "0".equals(mvxLine.get(ConstantsForSales.POSX))) {
                    attrValue = orderLine.get(attrName);
                }

                if (ConstantsForSales.ORDERLINEID.equals(attrName)) {
                    ; // ignore
                } else if (ConstantsForSales.MVX_CONFIGURABLE_ID.equals(attrName)) {
                    if (attrValue != null && (!"0".equals(attrValue))) {
                        insertPO.setSubsetAttribute("MvxConfigurableID", getMvxConfigID(attrValue));
                    } else {
                        insertPO.setSubsetAttribute("MvxConfigurableID", null);
                    }
                } else if (ConstantsForSales.IS_VISIBLE.equals(attrName)) {
                    if ("N".equals(attrValue)) {
                        throw new PipelineRuntimeException("Invisible item in orderline");
                    }
                } else if (ConstantsForSales.IS_ACTIVE.equals(attrName)) {
                    if ("N".equals(attrValue)) {
                        throw new PipelineRuntimeException("Inactive item in orderline");
                    }
                } else if (ConstantsForSales.COMMENT.equals(attrName) && orderlineCommentFlag
                        && "0".equals(mvxLine.get(ConstantsForSales.POSX))) {
                    // Insert LineComment
                    String orderlineComment = getOrderLineComment(context, con, cono, movexOrderID, (String) mvxLine
                            .get("PONR"), ConstantsForSales.POST_TEXT_2);
                    insertPO.setSubsetAttribute(attrName, orderlineComment);
                } else if (ConstantsForSales.RESELLPRICE.equals(attrName)) {
                    updResellPrice(insertPO, mvxLine);
                } else if (ConstantsForSales.LINEDISPERCENT.equals(attrName)) {
                    updLineDiscount(insertPO, mvxLine);
                } else if (attrValue != null) {
                    insertPO.setSubsetAttribute(attrName, attrValue);
                } else if(ConstantsForSales.PROMOTION_CODE.equals(attrName)){
                	String orderlineComment = getOrderLineComment(context, con, cono, movexOrderID, (String) mvxLine
                            .get("PONR"), ConstantsForSales.PRE_TEXT_1);
                    insertPO.setSubsetAttribute(attrName, orderlineComment);
                }

                if (ConstantsForSales.ITEMID.equals(attrName)) {
                    orderItems.add(attrValue.trim());
                }
                
                
            }

            insertPO.setSubsetAttribute("OrderLineStatusID", initOrderStatusCode);
            insertPO.setSubsetAttribute("DeliveredQuantity", "0");
            insertPO.setSubsetAttribute(ConstantsForSales.UNITCODE, (String) mvxLine.get(ConstantsForSales.SPUN));
            insertPO.setSubsetAttribute(ConstantsForSales.LINESUFFIX, (String) mvxLine.get(ConstantsForSales.POSX));
	    insertPO.setSubsetAttribute(ConstantsForSales.CUSTOMERITEMID, (String) mvxLine.get(ConstantsForSales.POPN));
        }
        updateOrderLineStatus(rsOrderLines, orderItems, initOrderStatusCode);
    }

    private Map<String, Map> getOrderLinesAsMap(Resultset rsOrderLines) throws PipelineRuntimeException,
            ResultsetException {
        Map<String, Map> orderLines = new HashMap<String, Map>();

        rsOrderLines.beforeFirst();
        while (rsOrderLines.moveNext()) {
            Map<String, String> line = new HashMap<String, String>();
            List attribNames = rsOrderLines.getNames();
            Iterator it = attribNames.iterator();
            while (it.hasNext()) {
                String name = (String) it.next();
                String value = rsOrderLines.getString(name);
                line.put(name, value);
            }
            orderLines.put(rsOrderLines.getString(ConstantsForSales.ORDERLINEID), line);
        }
        return orderLines;
    }

    private void updateOrderLineStatus(Resultset rsOrderLines, List orderItems, String initStatus)
            throws ResultsetException {
        rsOrderLines.beforeFirst();
        while (rsOrderLines.moveNext()) {
            String itemid = rsOrderLines.getString(ConstantsForSales.ITEM_ID);
            if (orderItems.contains(itemid.trim())) {
                CustomStagesHelper.updateRsAttribute((XMLIterator) rsOrderLines, "OrderLineStatus", initStatus);
            } else {
                CustomStagesHelper.updateRsAttribute((XMLIterator) rsOrderLines, "OrderLineStatus", "");
            }

        }
    }

    /**
     * Saves the order by calling the method PreviousOrder.SaveAsPreviousOrder.
     * 
     * @param response
     *            The respons to put output in.
     * @param xmlRequest
     *            Yhe request to use.
     * @param rsOrderLines
     *            Resultset with order lines to
     * @param currentOrderID
     *            ID for the current order to execute.
     * @param languageCode
     *            Language code to use for names.
     * @return Returns the resultset returned by the method.
     * @throws PipelineRuntimeException
     */
    private XMLResultset saveOrder(final Resultset response, final XMLRequest xmlRequest, final Resultset rsOrderLines,
            final String currentOrderID, final String languageCode, PipelineContext context)
            throws PipelineRuntimeException {
    	
        String submittedOrderKey = currentOrderID;
        IMovexConnection con = null;
        boolean isM3Enabled = "true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.CONNECTORENABLED));
        try {
            String userID = null;

            CommitPipelineExecuter insertPO = new CommitPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                    "PreviousOrder", "SaveAsPreviousOrder");
            insertPO.addEntity();

            // Copy all order header fields from response to new request
            List headerFields = response.getNames();
            Iterator itHeaderFields = headerFields.iterator();
            while (itHeaderFields.hasNext()) {
                final String attrName = (String) itHeaderFields.next();
                final String attrValue = response.getString(attrName);

                if (!attrName.equals("OrderID")) {
                    insertPO.setAttribute(attrName, attrValue);
                }
                if (attrName.equals("AgreementID")) {
                    insertPO.setAttribute("AgreementID", attrValue);
                }
                if (attrName.equals("ShippingCountryName")) {
                    insertPO.setAttribute("ShippingCountry", attrValue);
                } else if (attrName.equals("UserID")) {
                    userID = attrValue;
                }
                
            }

            final String movexOrderID = response.getParameters().getString(ConstantsForSales.SUBMITTEDORDERID);
            if (null != movexOrderID) {
                insertPO.setAttribute("OrderID", movexOrderID);
                // the below line is commented for avoiding sql exception for
                // the alpha numeric order number
                // insertPO.setAttribute("ApprovedOrderID", movexOrderID);
            } else {
            	insertPO.setAttribute("OrderID", submittedOrderKey);
            }

            final String transactionRef = response.getParameters().getString(
                    ConstantsForSales.TRANSACTIONREFERENCENUMBER);
            LOG.debug("Save as Previous Order Transaction reference number:" + transactionRef);
            if (null != transactionRef) {
                insertPO.setAttribute("TransactionReferenceNumber", transactionRef);
            }

            // Get information on user
            SearchPipelineExecuter searchUser = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "User",
                    "GetUserInfoForPreviousOrder");
            searchUser.setParam("UserID", userID);
            XMLResultset rsUserInfo = searchUser.execute();
            String initOrderStatusCode = null;
            // Set submitter credentials in order
            if (rsUserInfo.moveFirst()) {
                insertPO.setAttribute("UserPhone", rsUserInfo.getString("Phone"));
                insertPO.setAttribute("UserEmail", rsUserInfo.getString("Email"));
                insertPO.setAttribute("UserName", rsUserInfo.getString("UserName"));
                insertPO.setAttribute("UserNumber", rsUserInfo.getString("UserNumber"));

                initOrderStatusCode = rsUserInfo.getString("InitOrderStatus");
            }

            // Set order status - determine the initial status code for header
            // and lines
            if (initOrderStatusCode == null || initOrderStatusCode.length() == 0) {
                initOrderStatusCode = CustomStagesHelper.getKeyValue(ConstantsForSales.INITIAL_ORDER_STATUS);
            }
            if (initOrderStatusCode == null || initOrderStatusCode.length() == 0) {
                if (isM3Enabled == true) {
                    // Movex: Status is 22
                    initOrderStatusCode = "22";
                } else {
                    // Standalone: Status is Incoming
                    initOrderStatusCode = "inc";
                }
            }
            
            //Changes for ION Enabled Ordering
            String isIONEnabled = CustomStagesHelper.getKeyValue("ION.Enabled");
            if ("true".equalsIgnoreCase(isIONEnabled)) {
            	String ION_ENABLED_ORDER_ID = "PENDING_"+currentOrderID;
            	LOG.debug("ION Enabled Ordering ID - "+ION_ENABLED_ORDER_ID);
            	insertPO.setAttribute("OrderID", ION_ENABLED_ORDER_ID);
            	Resultset rsRoundOff= response.getResultset("RoundingOff");
            	Double roundOffValue= new Double(0.0);
            	if(rsRoundOff!=null){
            		rsRoundOff.beforeFirst();
            		while(rsRoundOff.moveNext()){
            			roundOffValue=rsRoundOff.getString("RoundingOff")==null? new Double(0): Double.valueOf(rsRoundOff.getString("RoundingOff"));
            		}
            	}
            	LOG.debug("RoundOff Value="+roundOffValue);
            	insertPO.setAttribute("RoundingOff", roundOffValue.toString());
            	submittedOrderKey = ION_ENABLED_ORDER_ID;
            }
            insertPO.setAttribute("CurrentOrderId", currentOrderID);
            
            insertPO.setAttribute("OrderStatus", initOrderStatusCode);
            insertPO.setAttribute("OrderLineLoStatusID", initOrderStatusCode);
            insertPO.setAttribute("OrderLineHiStatusID", initOrderStatusCode);
            // Set order date
            String dateNow = new XMLDateFormat().format(new Date());
            insertPO.setAttribute("OrderDate", dateNow);

            if (isM3Enabled == true) {
                // moved creation of connection here since object reference is
                // not pass-by-reference
                con = (IMovexConnection) CustomStagesHelper.getConnection(ConstantsForSales.OIS100MI);
                if (con == null) {
                    throw new PipelineRuntimeException("Failed to connect to Movex");
                }
                saveOrderM3Enabled(context, movexOrderID, con, rsOrderLines, insertPO, initOrderStatusCode);
            } else {
                saveOrderStandAlone(rsOrderLines, insertPO, initOrderStatusCode, submittedOrderKey);
                if ("true".equalsIgnoreCase(isIONEnabled)) {
                	saveDistributedCharges(response, insertPO);
                	saveDistributedTaxes(response, insertPO);
                }
            }

            // Run the method and return the resultset
            return insertPO.execute();

        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Failed to access parameter in saveOrder", e);
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Failed to operate on resultset in saveOrder", e);
        } finally {
            if (con != null) {
                try {
                    con.close();
                } catch (ConnectorException e) {
                    LOG.error("Failed to close the movex connection!");
                }
                con = null;
            }
        }
    }
    

    private String getOrderLineComment(PipelineContext context, IMovexConnection con, String cono, String orderId,
            String orderLine, String textType) throws PipelineRuntimeException {
        Map lineComment = new HashMap();
        lineComment.put(IMovexConnection.TRANSACTION, ConstantsForSales.GET_LINE_TEXT);
        lineComment.put(ConstantsForSales.CONO, cono);
        lineComment.put(ConstantsForSales.ORNO, orderId);
        lineComment.put(ConstantsForSales.PONR, orderLine);
        lineComment.put(ConstantsForSales.TYTR, textType);

        // retrieve order lines data from Movex
        IMovexApiResultset apiRes = CustomStagesHelper
                .callMovex(context, con, lineComment, ConstantsForSales.MVXSTATUS);
        if (apiRes == null) {
            throw new PipelineRuntimeException("Unable to retrieve order lines from Movex");
        }

        Iterator apiIter = apiRes.iterator();
        if (apiIter.hasNext()) {
            Map mvxLineComment = (HashMap) apiIter.next();
            return ((String) mvxLineComment.get(ConstantsForSales.TX60));
        } else {
            return null;
        }
    }

    private boolean hasOrderLineComment(final Document response) throws PipelineRuntimeException {
        final String ORDERLINE_COMMENT_XPATH = "/resultset/row/OrderLine/@Comment";
        Node node;
        try {
            node = XPathAPI.selectSingleNode(response, ORDERLINE_COMMENT_XPATH);
            if (node == null) {
                LOG.info("No OrderLine comments found");
                return false;
            } else {
                LOG.info("Found presence of Orderline comments - need to fire getLineText API calls");
                return true;
            }
        } catch (Exception e) {
            throw new PipelineRuntimeException(e);
        }
    }

    private void updResellPrice(CommitPipelineExecuter insertPO, final Map<String, String> mvxLine) {
        // BigDecimal qty = getParameterAsDecimal(ConstantsForSales.QUANTITY,
        // mvxLine);
        BigDecimal qty = getParameterAsDecimal(ConstantsForSales.ORQT, mvxLine);
        if (qty.compareTo(Decimal.ZERO) != 0) {
            BigDecimal mvxQty = getParameterAsDecimal(ConstantsForSales.ORQT, mvxLine);
            BigDecimal resellPrice = getParameterAsDecimal(ConstantsForSales.SAPR, mvxLine);
            // resellPrice = resellPrice * mvxQty / qty;
            resellPrice = Decimal.divide(resellPrice.multiply(mvxQty), qty);
            insertPO.setSubsetAttribute(ConstantsForSales.RESELLPRICE, Decimal.toString(resellPrice));
        }
    }

    private void updLineDiscount(CommitPipelineExecuter insertPO, final Map<String, String> mvxLine) {
        BigDecimal lineTotal = getParameterAsDecimal(ConstantsForSales.NLAM, mvxLine);

        BigDecimal qty = new BigDecimal(mvxLine.get(ConstantsForSales.ORQT));
        BigDecimal salePrice = new BigDecimal(mvxLine.get(ConstantsForSales.SAPR));
        BigDecimal netPrice = new BigDecimal(mvxLine.get(ConstantsForSales.NEPR));

        BigDecimal linePrice = qty.multiply(salePrice);
        BigDecimal lineDiscounted = qty.multiply(netPrice);
        BigDecimal lineDiscount = linePrice.subtract(lineDiscounted);

        insertPO.setSubsetAttribute(ConstantsForSales.LINEPRICE, Decimal.toString(linePrice));
        insertPO.setSubsetAttribute(ConstantsForSales.LINETOTAL, Decimal.toString(lineTotal));

        if (linePrice.compareTo(Decimal.ZERO) != 0) {
            // LineDisPercent = 100 * LineDiscount / LinePrice
            BigDecimal percent = Decimal.divide(Decimal.ONEHUNDRED.multiply(lineDiscount), linePrice);
            insertPO.setSubsetAttribute(ConstantsForSales.LINEDISPERCENT, Decimal.toString(percent));
        }
    }

    private BigDecimal getParameterAsDecimal(final String apiPar, final Map<String, String> mvxLine) {
        String val = (String) mvxLine.get(apiPar);
        if (val != null) {
            try {
                return new BigDecimal(val);
            } catch (NumberFormatException e) {
                return new BigDecimal("0.0000");
            }
        }
        return new BigDecimal("0.0000");
    }

    /**
     * Calls stored procedure OrderExecuteAddConfigItems to handle (add)
     * configured items to the order. configured items to the order.
     * 
     * @param currentOrderID
     *            ID for the current order to execute.
     * @param newOrderID
     *            ID for the saved order to which the items should be added.
     * @param languageCode
     *            Language code to use for names.
     * @throws PipelineRuntimeException
     */
    private void addConfiguratedItems(final String currentOrderID, final String newOrderID, final String languageCode)
            throws PipelineRuntimeException {

        try {
            StageCallProcedure procedure = new StageCallProcedure("EXEC OrderExecuteAddConfigItems ?, ?, ?",
                    ConstantsForSales.DATABASE_CONNECTION_KEY);

            procedure.addInputParam("@OrderID", 1, DatabaseType.INTEGER, Parameter.CONSTANT, currentOrderID);
            procedure.addInputParam("@SubmittedOrderID", 2, DatabaseType.VARCHAR, Parameter.CONSTANT, newOrderID);
            procedure.addInputParam("@languageCode", 3, DatabaseType.VARCHAR, Parameter.CONSTANT, languageCode);

            // create separate context for call to procedure
            PipelineContext procedureContext = new PipelineContext();
            procedure.execute(procedureContext);
        } catch (PipelineRuntimeException e) {
            throw new PipelineRuntimeException("Error adding configurated items for current order ID = "
                    + currentOrderID + ", saved order ID = " + newOrderID, e);
        }
    }

    /**
     * Delete current order.
     * 
     * @param currentOrderID
     * @throws PipelineRuntimeException
     */
    private void deleteOrder(final String currentOrderID) throws PipelineRuntimeException {

        try {
            DeletePipelineExecuter deleteCurrentOrder = new DeletePipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                    "CurrentOrder", "Delete");
            deleteCurrentOrder.setMainKey("OrderID", currentOrderID);
            deleteCurrentOrder.execute();
        } catch (PipelineRuntimeException e) {
            throw new PipelineRuntimeException("Error deleting current order, order ID = " + currentOrderID, e);
        }
    }

    private String getMvxConfigID(String CFIN) throws PipelineRuntimeException, ResultsetException {
        SearchPipelineExecuter searchMvxConfig = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                "MvxProductConfiguration", "getConfigurableIDByNumber");
        searchMvxConfig.setParam("MvxID", CFIN);
        XMLResultset rsInfo = searchMvxConfig.execute();

        // Set submitter credentials in order
        if (rsInfo.moveFirst()) {
            return (rsInfo.getString("ID"));
        } else {
            return null;
        }

    }
}
