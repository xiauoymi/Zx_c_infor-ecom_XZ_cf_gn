package com.intentia.iec.pipeline.runtime.integration.erp.model;

import java.util.List;

public class OrderTotal {

	private String currencyId;

	private double totalLines;

	private double extendedAmount;

	private double roundingOff;

	private double totalAmount;
	
	private double grandTotal;
	
	private double totalDiscount;
	
	private double totalPrice;

	private boolean hasWSCallError;
	
	private String msgError;
	
	private String msgCodeError;

	public double getGrandTotal() {
		return grandTotal;
	}

	public void setGrandTotal(double grandTotal) {
		this.grandTotal = grandTotal;
	}

	public double getTotalDiscount() {
		return totalDiscount;
	}

	public void setTotalDiscount(double totalDiscount) {
		this.totalDiscount = totalDiscount;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	private List<Charge> distributedCharges;

	private List<Tax> distributedTaxes;	

	public String getCurrencyId() {
		return currencyId;
	}

	public void setCurrencyId(String currencyId) {
		this.currencyId = currencyId;
	}

	public double getTotalLines() {
		return totalLines;
	}

	public void setTotalLines(double totalLines) {
		this.totalLines = totalLines;
	}

	public double getExtendedAmount() {
		return extendedAmount;
	}

	public void setExtendedAmount(double extendedAmount) {
		this.extendedAmount = extendedAmount;
	}

	public double getRoundingOff() {
		return roundingOff;
	}

	public void setRoundingOff(double roundingOff) {
		this.roundingOff = roundingOff;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public List<Charge> getDistributedCharges() {
		return distributedCharges;
	}

	public void setDistributedCharges(List<Charge> distributedCharges) {
		this.distributedCharges = distributedCharges;
	}

	public List<Tax> getDistributedTaxes() {
		return distributedTaxes;
	}

	public void setDistributedTaxes(List<Tax> distributedTaxes) {
		this.distributedTaxes = distributedTaxes;
	}

	public boolean isHasWSCallError() {
		return hasWSCallError;
	}

	public void setHasWSCallError(boolean hasWSCallError) {
		this.hasWSCallError = hasWSCallError;
	}

	public String getMsgError() {
		return msgError;
	}

	public void setMsgError(String msgError) {
		this.msgError = msgError;
	}

	public String getMsgCodeError() {
		return msgCodeError;
	}

	public void setMsgCodeError(String msgCodeError) {
		this.msgCodeError = msgCodeError;
	}

}
