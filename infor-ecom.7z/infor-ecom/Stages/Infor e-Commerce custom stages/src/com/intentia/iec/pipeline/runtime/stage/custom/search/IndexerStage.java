package com.intentia.iec.pipeline.runtime.stage.custom.search;

import java.io.Reader;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.LowerCaseFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.WhitespaceTokenizer;

import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

/**
 * Lucene (re)indexing of items and categories. Called from a scheduled job in
 * e-Sales.
 * 
 * The code in ItemIndexer, CategoryIndexer and this class looks a bit ugly, but
 * it is optimized for speed and tries to put minimal strain on the garbage
 * collector. Indexing makes no use of concurrency (multiple CPUs) - maybe it
 * should? Also there is no attempt to synchronize Lucene indexes across a
 * cluster of WebSphere machines.
 */
// removed final so that SPS can inherit from this class
public class IndexerStage extends AbstractPipelineStage {
    private static final Logger LOG = Logger.getLogger(IndexerStage.class);

    // ================================ index server codes

    private static final String APPLICATIONDATA = "ApplicationData";

    private static final String APPLICATIONDATA_DETAILS = "Details";

    private static final String APP_DETAILS_SEARCH_ENGINE_INDEX_FOLDER = "IndexFolder";

    private static final String PARAM = "param";

    private static final String PARAMETER_VALUE = "ParameterValue";

    private static final String PARAMETER_USEINDEXSERVER = "UseIndexServer";

    private static final String USEINDEXSERVER = "Y";

    private static final String PARAMETER_INDEXSERVERHOST = "IndexServerHost";

    private static final String PARAMETER_INDEXSERVERPORT = "IndexServerPort";

    /** The text parser used for tokenized fields. */
    static class MyAnalyzer extends Analyzer {
        /**
         * Splits the text from the Reader into tokens. Splits on whitespace and
         * then lower-cases.
         * 
         * @param fieldName
         *            The name of the field. Not used.
         * @param reader
         *            A Reader containing the string to be tokenized.
         * @return A stream of tokens.
         */
        @Override
        public TokenStream tokenStream(final String fieldName, final Reader reader) {
            return new LowerCaseFilter(new WhitespaceTokenizer(reader));
        }
    }

    /**
     * The entry point for the custom stage. Handles object wiring,
     * initialization and cleanup.
     * 
     * @param context
     *            the pipeline context (not used)
     * @throws PipelineRuntimeException
     *             if error during indexing
     */
    @Override
    public void execute(final PipelineContext context) throws PipelineRuntimeException {

        long startTime = System.currentTimeMillis();

        boolean useIndexServer = isIndexServer();

        if (useIndexServer == false) {
            LOG.info("Using single-server set-up");

            Jdbc jdbc = new JdbcImpl();
            Manager manager = getManager();

            String indexFolder = manager.getParentFolder();
            LOG.info("Index folder: = " + indexFolder);
            Database queries = new DatabaseImpl();
            Map<String, String> categoryPathById = new HashMap<String, String>();
            Map<String, String> categoryPathByKey = new HashMap<String, String>();
            queries.buildCategoryPaths(categoryPathById, categoryPathByKey);
            boolean useWarehousing = queries.useWarehousing();

            BaseDataIndexer baseDataIndexer = new BaseDataIndexer(useWarehousing, categoryPathByKey);
            ItemIndexer itemIndexer = createItemIndexer(categoryPathById, jdbc);

            IndexerStageUtils.doIndexing(manager, baseDataIndexer, itemIndexer);
        } else {
            LOG.info("Using index server");

            String url = getValueFromApplicationData(PARAMETER_INDEXSERVERHOST);
            int port = 0;
            try {
                port = Integer.parseInt(getValueFromApplicationData(PARAMETER_INDEXSERVERPORT));
            } catch (Exception e) {
                throw new PipelineRuntimeException(e);
            }

            boolean indexNormalItems = isIndexNormalItems();
            boolean isSpsEnabled = isSpsEnabled();
            boolean includeStyleItem = isStyleItemEnabled();
            boolean includePrices = isIncludePrices();
            Manager manager = getManager();
            sendIndexRequest(url, port, manager, indexNormalItems, isSpsEnabled, includeStyleItem, includePrices);
        }

        long stopTime = System.currentTimeMillis();
        LOG.debug("Total indexing time: " + (stopTime - startTime) + " ms");
    }

    /**
     * Returns the Manager instance that the IndexerStage will use.
     * 
     * @return
     */
    protected Manager getManager() {
        // Made this into a function so that SPSIndexerStage will just have to
        // override
        // this function to use the SPSManager and not have to rewrite the
        // execute() function.
        return ManagerImpl.INSTANCE;
    }

    /**
     * @param categoryPathById
     * @param jdbc
     * @return
     */
    protected ItemIndexer createItemIndexer(Map<String, String> categoryPathById, Jdbc jdbc) {
        // Made this into a function so that SPSIndexerStage will just have to
        // override
        // this function to use the SPSItemIndexer and not have to rewrite the
        // execute() function.
        return new ItemIndexer(categoryPathById, jdbc);
    }

    // ================================ index server codes

    private String getValueFromApplicationData(String pParamName) {
        String paramValue = "";

        SearchPipelineExecuter seOrderItems = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                APPLICATIONDATA, APPLICATIONDATA_DETAILS);

        seOrderItems.setParam(PARAM, pParamName);

        try {
            XMLResultset rs = seOrderItems.execute();
            rs.moveFirst();
            paramValue = rs.getString(PARAMETER_VALUE);
        } catch (PipelineRuntimeException e) {
            paramValue = "";
        } catch (ResultsetException e) {
            paramValue = "";
        }

        return paramValue;
    }

    private boolean isIndexServer() {
        boolean retVal = false;
        String s = getValueFromApplicationData(PARAMETER_USEINDEXSERVER);
        if (USEINDEXSERVER.equalsIgnoreCase(s) == true) {
            retVal = true;
        }

        return retVal;
    }

    /**
     * Returns true if normal items will be indexed.
     * 
     * @return
     */
    protected boolean isIndexNormalItems() {
        // Created a function that SPSIndexerStage can override.
        return true;
    }

    /**
     * Returns true if SPS is enabled.
     * 
     * @return
     * @throws PipelineRuntimeException
     */
    protected boolean isSpsEnabled() throws PipelineRuntimeException {
        // Created a function that SPSIndexerStage can override.
        boolean retVal = Boolean.valueOf(CustomStagesHelper.getKeyValue("Application.SPS Enabled")).booleanValue();
        return retVal;
    }

    /**
     * Returns true if ItemListStyleItem is set to true.
     * 
     * @return
     * @throws PipelineRuntimeException
     */
    protected boolean isStyleItemEnabled() throws PipelineRuntimeException {
        boolean retVal = Boolean.valueOf(CustomStagesHelper.getKeyValue("Application.ItemListStyleItem"))
                .booleanValue();
        return retVal;
    }

    /**
     * If M3 API is set to false and Price Search and Sort is true, prices will
     * be indexed.
     * 
     * @return
     * @throws PipelineRuntimeException
     */
    protected boolean isIncludePrices() throws PipelineRuntimeException {
        boolean retVal = ((Boolean.valueOf(CustomStagesHelper.getKeyValue("Application.M3 API")).booleanValue() == false) && (Boolean
                .valueOf(CustomStagesHelper.getKeyValue("Application.PriceSearchAndSort")).booleanValue() == true));
        return retVal;
    }

    /**
     * Creates an indexing request and sends it to the index server. This will
     * also wait for the reply.
     * 
     * @param url
     * @param port
     * @param manager
     * @param indexNormalItems
     * @param isSpsEnabled
     * @param includeStyleItem
     * @throws PipelineRuntimeException
     */
    private void sendIndexRequest(String url, int port, Manager manager, boolean indexNormalItems,
            boolean isSpsEnabled, boolean includeStyleItem, boolean includePrices) throws PipelineRuntimeException {
        IndexerStageUtils.sendIndexRequest(url, port, manager, new ItemIndexerServerRequest(indexNormalItems,
                isSpsEnabled, includeStyleItem, includePrices));
    }

}
