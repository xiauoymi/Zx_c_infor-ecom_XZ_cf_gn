/*
 * Created on 03-04-2006
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.w3c.dom.Node;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

/**
 * <p>
 * Inserts the key for a user with the given e-mail in the request. The stage is
 * used in a pipeline for updating a user from request received from SalesTool /
 * SMS.
 * </p>
 * <p>
 * <b>Input in <code>PipelineContext</code>:</b><br>
 * Parameters:
 * <ul>
 * <li><code>&#64;email</code> (mandatory)</li>
 * </ul>
 * </p>
 * <p>
 * <b>Generated output in <code>PipelineContext</code>:</b><br>
 * <ul>
 * <li>The found key and language code for the user.</li>
 * </ul>
 * </p>
 * <p>
 * The parameter <code>&#64;email</code> tells what user to modify. The stage
 * finds the ID for the user and inserts the ID as key in the request, so the
 * request can be used in a following update stage.
 * </p>
 */
/*
 * The text uses the character code &#64; for @ to avoid to confuse the Java
 * auto formatter.
 */
public class AddUserIdFromEmail implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(AddUserIdFromEmail.class);

    private static final String ENTITY_XPATH = "/request/entities/entity";

    // Input parameter to this stage.
    private static final String EMAIL_PARAMETER = "@email";

    // Output parameters from this stage
    private static final String LANGUAGE_PARAMETER = "@LanguageCode";

    private static final String SEND_MAIL_PARAMETER = "@sendMail";

    // Attributes on User business object
    private static final String USER_ID_ATTRIBUTE = "UserID";

    private static final String LANGUAGE_ATTRIBUTE = "LanguageID";

    // Local variables
    private XMLRequest request = null;

    private XMLRequestHelper requestHelper = null;

    private Parameters parameters = null;

    private Node entityNode = null;

    // From User search
    private String userID = null;

    private String languageCode = null;

    /*
     * (non-Javadoc) Pipeline entry point.
     */
    public void execute(final PipelineContext context) throws PipelineRuntimeException {

        // Verify type of request
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Request MUST be of type XMLRequest!");
        }

        request = (XMLRequest) context.getRequest();

        try {
            XMLRequest.extractRequestParameters(request);
            entityNode = XMLRequestHelper.getRequestNode(request, ENTITY_XPATH);
            if (entityNode == null) {
                LOG.debug("The request does not hold an entity node!");
                return;
            }
            parameters = request.getParameters();
            requestHelper = new XMLRequestHelper(request);

            boolean userFound = findUser();
            if (userFound) {
                // Add the user ID as key to the request, so it becomes an
                // update request
                requestHelper.setKey(entityNode, userID);
                parameters.setString(LANGUAGE_PARAMETER, languageCode);
                parameters.setboolean(SEND_MAIL_PARAMETER, true);
            }

        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Failed to set parameter in request", e);
        } catch (TransformerException e) {
            throw new PipelineRuntimeException("Failed to get/set attribute in request", e);
        } catch (RequestException e) {
            throw new PipelineRuntimeException("Failed to operate on request", e);
        }
    }

    /**
     * Searches for the user given by the e-mail parameter. Sets two class
     * variables for user ID and language code if the user is found.
     * 
     * @return Returns true if the user is found.
     * @throws PipelineRuntimeException
     */
    private boolean findUser() throws PipelineRuntimeException {

        // Business object
        final String userObject = "User";

        // Method to call to get the user ID.
        final String userMethod = "GetIdFromEmail";

        // Input parameter to user search method.
        final String emailParameter = "email";

        boolean userFound = false;

        try {
            String email = parameters.getString(EMAIL_PARAMETER);
            if ((email == null) || (email.length() == 0)) {
                LOG.debug("Parameter '" + EMAIL_PARAMETER + "' not found - do not find UserID!");
            } else {
                // Get ID for the user with the given e-mail.
                SearchPipelineExecuter searchUser = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                        userObject, userMethod);
                searchUser.setParam(emailParameter, email);
                XMLResultset rsUser = searchUser.execute();
                if (!rsUser.moveFirst()) {
                    LOG.info("Could not find user with e-mail '" + email + "'");
                } else {
                    userID = rsUser.getString(USER_ID_ATTRIBUTE);
                    languageCode = rsUser.getString(LANGUAGE_ATTRIBUTE);
                    userFound = true;
                }
            }
        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Failed to obtain a parameter from request", e);
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Failed to operate on resultset", e);
        }
        return userFound;
    }
}
