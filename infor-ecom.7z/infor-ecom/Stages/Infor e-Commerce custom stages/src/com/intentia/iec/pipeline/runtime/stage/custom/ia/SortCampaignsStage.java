package com.intentia.iec.pipeline.runtime.stage.custom.ia;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.ia.model.IaCampaign;

public class SortCampaignsStage extends AbstractPipelineStage {

	private static final Logger log = Logger
			.getLogger(SortCampaignsStage.class);

	@SuppressWarnings("unchecked")
	@Override
	public void execute(PipelineContext context)
			throws PipelineRuntimeException {
		log.debug("Executing SortCampaignsStage.execute()...");
		try {
			List<IaCampaign> campaignScores = (List<IaCampaign>) context
					.get(GetIaCampaignScoreStage.CAMPAIGN_SCORE);
			log.debug(GetIaCampaignScoreStage.CAMPAIGN_SCORE + " : "
					+ campaignScores);

			if (campaignScores != null && !campaignScores.isEmpty()) {
				XMLResultset response = (XMLResultset) context.getResponse();
				log.debug("Unsorted XMLResponse: " + response);

				Map<String, Node> responseMap = responseToMap(response);
				response = sortResponseMap(campaignScores, responseMap,
						response);
				context.setRequest(response);
			} else {
				log.debug("No campaign scores to sort. Exiting this stage...");
			}
		} catch (Exception e) {
			throw new PipelineRuntimeException(
					"Error while sorting campaigns based on IA score.", e);
		}
	}

	private Map<String, Node> responseToMap(XMLResultset response)
			throws PipelineRuntimeException {
		Map<String, Node> rowMap = new HashMap<String, Node>();
		try {
			Document responseDoc = response.getDocument();
			NodeList rows = XPathAPI.selectNodeList(responseDoc,
					"/resultset/row");
			if (rows != null) {
				for (int i = 0; i < rows.getLength(); i++) {
					Element row = (Element) rows.item(i);
					String campaignId = row.getAttribute("CampaignID");
					rowMap.put(campaignId, row);
				}
			}
		} catch (Exception e) {
			throw new PipelineRuntimeException(
					"Error while converting XMLReponse to Node map.", e);
		}

		return rowMap;
	}

	private XMLResultset sortResponseMap(List<IaCampaign> campaignScores,
			Map<String, Node> responseMap, XMLResultset response)
			throws PipelineRuntimeException {
		try {
			Document responseDoc = response.getDocument();
			Node resultsetNode = XPathAPI.selectSingleNode(responseDoc,
					"resultset");
			if (resultsetNode != null) {
				for (IaCampaign campaign : campaignScores) {
					Element row = (Element) responseMap.get(campaign.getId());
					if (row != null) {
						row.setAttribute("Score",
								String.valueOf(campaign.getScore()));
						resultsetNode.appendChild(row);
					}
				}
			}
		} catch (Exception e) {
			throw new PipelineRuntimeException(
					"Error while creating new sorted XMLResponse.", e);
		}

		log.debug("Sorted XMLResponse: " + response);
		return response;
	}

}
