package com.intentia.iec.pipeline.runtime.integration.ia.utils;

import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaConnectionException;
import com.intentia.iec.pipeline.runtime.stage.custom.StageUtilityHelper;

public class IaConfig {

	private static final Logger log = Logger.getLogger(IaConfig.class);
	private static final int REFRESH_RATE = 1; // in minutes

	private String serverAddress;
	private int portNumber;
	private String username;
	private String password;
	private String packageName;
	private float loginTimeout;
	private float pollingInterval;
	private float requestTimeout;
	private String dataDelimiter;
	private long creationTime = 0;

	private static IaConfig instance;

	private IaConfig() {
		// do nothing. This is a singleton object
	}

	public static IaConfig getInstance() throws IaConnectionException {
		if (instance == null) {
			log.debug("Creating new instance of IaConfig...");
			synchronized (IaRPManagerClient.class) {
				instance = new IaConfig();
				initialize();
			}
		} else if (needToRefresh(instance.creationTime)) {
			log.debug("Refreshing IaConfig...");
			initialize();
		}

		return instance;
	}

	private static void initialize() throws IaConnectionException {
		try {
			instance.serverAddress = getConfig(IaConstants.CONF_SERVER_NAME,
					IaConstants.DEF_SERVER_NAME);
			instance.portNumber = Integer.parseInt(getConfig(
					IaConstants.CONF_PORT_NUMBER, IaConstants.DEF_PORT_NUMBER));
			instance.username = getConfig(IaConstants.CONF_USERNAME,
					IaConstants.DEF_USERNAME);
			instance.password = getConfig(IaConstants.CONF_PASSWORD,
					IaConstants.DEF_PASSWORD);
			instance.packageName = getConfig(IaConstants.CONF_PACKAGE_NAME,
					IaConstants.DEF_PACKAGE_NAME);
			instance.loginTimeout = Float.parseFloat(getConfig(
					IaConstants.CONF_LOGIN_TIMEOUT,
					IaConstants.DEF_LOGIN_TIMEOUT));
			instance.pollingInterval = Float.parseFloat(getConfig(
					IaConstants.CONF_POLLING_INTERVAL,
					IaConstants.DEF_POLLING_INTERVAL));
			instance.requestTimeout = Float.parseFloat(getConfig(
					IaConstants.CONF_REQUEST_TIMEOUT,
					IaConstants.DEF_REQUEST_TIMEOUT));
			instance.dataDelimiter = getConfig(IaConstants.CONF_DATA_DELIMITER,
					IaConstants.DEF_DATA_DELIMITER);
			instance.creationTime = System.currentTimeMillis();
			
			log.debug("IaConfig : \n" + instance);
		} catch (Exception e) {
			throw new IaConnectionException(
					"Error while getting IA configuration.", e);
		}
	}

	public String getServerAddress() {
		return serverAddress;
	}

	public int getPortNumber() {
		return portNumber;
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	public String getPackageName() {
		return packageName;
	}

	public float getLoginTimeout() {
		return loginTimeout;
	}

	public float getPollingInterval() {
		return pollingInterval;
	}

	public float getRequestTimeout() {
		return requestTimeout;
	}

	public String getDataDelimiter() {
		return dataDelimiter;
	}

	private static String getConfig(String name, String defaultValue) {
		try {
			return StringUtils.defaultString(
					StageUtilityHelper.getValueFromApplicationData(name),
					defaultValue);
		} catch (Exception e) {
			log.error("Unable to fetch config '" + name
					+ "'. Setting default value = " + defaultValue);
			return defaultValue;
		} catch (NoClassDefFoundError e) { // not recommended. for testing only
			log.error("Unable to fetch config '" + name
					+ "'. Setting default value = " + defaultValue);
			return defaultValue;
		}
	}

	private static boolean needToRefresh(long creationTime) {
		long currentTime = System.currentTimeMillis();
		return TimeUnit.MILLISECONDS.toMinutes(currentTime - creationTime) >= REFRESH_RATE;
	}

	@Override
	public String toString() {
		if (instance == null) {
			return "null";
		}

		StringBuilder objStr = new StringBuilder();
		objStr.append(IaConstants.CONF_SERVER_NAME).append(" : ")
				.append(instance.getServerAddress()).append("\n");
		objStr.append(IaConstants.CONF_PORT_NUMBER).append(" : ")
				.append(instance.getPortNumber()).append("\n");
		objStr.append(IaConstants.CONF_USERNAME).append(" : ")
				.append(instance.getUsername()).append("\n");
		objStr.append(IaConstants.CONF_PASSWORD).append(" : ")
				.append(instance.getPassword()).append("\n");
		objStr.append(IaConstants.CONF_PACKAGE_NAME).append(" : ")
				.append(instance.getPackageName()).append("\n");
		objStr.append(IaConstants.CONF_POLLING_INTERVAL).append(" : ")
				.append(instance.getPollingInterval()).append("\n");
		objStr.append(IaConstants.CONF_LOGIN_TIMEOUT).append(" : ")
				.append(instance.getLoginTimeout()).append("\n");
		objStr.append(IaConstants.CONF_REQUEST_TIMEOUT).append(" : ")
				.append(instance.getRequestTimeout()).append("\n");
		objStr.append(IaConstants.CONF_DATA_DELIMITER).append(" : ")
				.append(instance.getDataDelimiter()).append("\n");

		return objStr.toString();
	}

}
