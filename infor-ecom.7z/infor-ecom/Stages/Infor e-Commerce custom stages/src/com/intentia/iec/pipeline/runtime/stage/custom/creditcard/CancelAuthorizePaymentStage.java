package com.intentia.iec.pipeline.runtime.stage.custom.creditcard;

import java.math.BigDecimal;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.creditcard.dao.CreditCardDao;
import com.intentia.iec.pipeline.runtime.integration.creditcard.dao.factory.DaoFactory;
import com.intentia.iec.pipeline.runtime.integration.creditcard.exception.CreditCardConnectionException;
import com.intentia.iec.pipeline.runtime.integration.creditcard.model.CreditCard;
import com.intentia.iec.pipeline.runtime.integration.creditcard.model.Payment;
import com.intentia.iec.pipeline.runtime.integration.creditcard.model.TransactionResult;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;

public class CancelAuthorizePaymentStage extends AbstractPipelineStage {
	
	private static final Logger log = Logger
			.getLogger(AuthorizeCreditCardPaymentStage.class);
	
	@Override
	public void execute(PipelineContext context) throws PipelineRuntimeException {
		log.debug("Start CancelAuthorizePaymentStage.execute() . . .");

		CustomStagesHelper.extractRequestParameters(CustomStagesHelper
				.getRequest(context));

		XMLRequest request = (XMLRequest) context.getRequest();
		Parameters requestParams = request.getParameters();
		TransactionResult transactionResult = getTransactionResult(requestParams);
		XMLResultset resultset = getResponse(context);
		
		log.debug("AuthorizeCreditCardPaymentStage.java ================ Is transactionResult null? " + (transactionResult == null));
		log.debug("AuthorizeCreditCardPaymentStage.java ================ is successful: " + transactionResult.isSuccessful());
		
		CustomStagesHelper.setResponseParameter(context, "isCancelSuccessful", String.valueOf(transactionResult.isSuccessful()));
		CustomStagesHelper.setResponseParameter(context, "authAmount", transactionResult.getActualAuthorizedAmount().toString());
		CustomStagesHelper.setResponseParameter(context, "responseCode", transactionResult.getResponseCode().toString());
		CustomStagesHelper.setResponseParameter(context, "responseMessage", transactionResult.getResponseMessage().toString());
	}
	
	private TransactionResult getTransactionResult(Parameters requestParams) {
		TransactionResult transaction = new TransactionResult();
		CreditCard creditCard = new CreditCard();
		TransactionResult result = new TransactionResult();
		
		try {
			transaction.setAuthorizationNumber(requestParams.getString("authNumber"));
			transaction.setReferenceNumber(requestParams.getString("refNumber"));
			transaction.setAmount(new BigDecimal(requestParams.getString("orderAmount")));
			
			String lastDigits = StringUtils.remove(requestParams.getString("lastDigits"), "*");
			creditCard.setLastDigits(lastDigits);
			
			CreditCardDao dao = DaoFactory.getDAOFactory().getCreditCardDao();
			result = dao.cancelAuthorize(transaction, creditCard);

			log.debug("Credit Card Authorization : " + result);
		} catch (CreditCardConnectionException e) {
			log.error(
					"Error while connecting to Credit Card Web Service",
					e);
		} catch (ParametersException e) {
			log.error(
					"Error getting parameter",
					e);
		} 
		return result;
	}

}
