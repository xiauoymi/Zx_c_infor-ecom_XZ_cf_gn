package com.intentia.iec.pipeline.runtime.stage.custom.search;

import java.util.Map;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;

public interface Database {

    String[] getAssortmentIdsForUser(final String userId, final String userGroupId) throws PipelineRuntimeException;

    boolean useWarehousing() throws PipelineRuntimeException;

    void buildCategoryPaths(final Map<String, String> categoryPathById, final Map<String, String> categoryPathByKey)
            throws PipelineRuntimeException;

    void mergeItemAttributesFromDatabase(final Map<String, Map<String, String>> rows, final Request request)
            throws PipelineRuntimeException;

}
