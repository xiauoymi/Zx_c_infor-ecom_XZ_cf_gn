package com.intentia.iec.pipeline.runtime.stage.custom;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import java.io.File;

/*
**	This custom stage checks the Logo ID parameter from the request and validate it in the Logo repository path
**	This will return
		isLogoExists = "Y" : if logo is valid and existing. 
		otherwise
		isLogoExists = "N"
**/

public class CheckLogoID implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(CheckLogoID.class);

    private XMLRequest xmlRequest = null;

    public void execute(PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("Entering CheckLogoID.execute()");
		
	XMLResultset response = new XMLResultset();

	context.setResponse(response);

        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
        xmlRequest = (XMLRequest) context.getRequest();

        try {
            XMLRequest.extractRequestParameters(xmlRequest);
        } catch (RequestException e) {
            throw new PipelineRuntimeException("Error extracting request parameters!", e);
        }

        // Movex connector not enabled => skip stage
        if (!"true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.CONNECTORENABLED))) {
            return;
        }

        String logo = getlogoParam();
        
		// Accessing Logo Repository path
		// Path: "C:\EsaImages\logo\"
		File myLogoRepoPath = new File ("C:" +File.separator +"EsaImages" +File.separator +"logo" +File.separator);
		LOG.debug ("Accessing path: " +myLogoRepoPath.getAbsolutePath());
		
		// Accessing logo id in the Logo repository path
		// this assumes all images are in .jpg format
		File myLogoPath = new File ("C:" +File.separator +"EsaImages" +File.separator +"logo" +File.separator +logo +".jpg");
		LOG.debug ("Accessing logo path: " +myLogoPath.getAbsolutePath());
				
		String AbsPath = myLogoPath.getAbsolutePath();
		
		LOG.debug("Checking for logo file..." +logo);
		LOG.debug("Checking path " +AbsPath + " if existing");
						
		if (myLogoPath.exists()) {
			LOG.debug("Logo file..." +AbsPath + " exists");
			CustomStagesHelper.setResponseParameter(context, "isLogoExists", "Y");
		} else {
			LOG.debug("Logo file..." +AbsPath + " does not exists");
	        CustomStagesHelper.setResponseParameter(context, "isLogoExists", "N");
	    }
        LOG.debug("Exiting CheckLogoID.execute()");
    }

    private String getlogoParam() {
        LOG.debug("Entering CheckLogoID.getlogoParam");
        String logo = "";
        try {
            logo = xmlRequest.getParameters().getString("LogoID");
			LOG.debug("LogoID :" + logo);
        } catch (ParametersException e) {
            LOG.debug("LogoID is not in the request parameters.");
        }
        LOG.debug("Exiting CheckLogoID.getlogoParam");
        return logo;
    }
}