package com.intentia.iec.pipeline.runtime.integration.creditcard.model;

public class CreditCard {
	
	private String token;
	
	private String maskedCcNumber;
	
	private String nameOnCard;
	
	private String cvvNumber;
	
	private String lastDigits;
	
	/**
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * @param token the token to set
	 */
	public void setToken(String token) {
		this.token = token;
	}

	/**
	 * @return the maskedCcNumber
	 */
	public String getMaskedCcNumber() {
		return maskedCcNumber;
	}

	/**
	 * @param maskedCcNumber the maskedCcNumber to set
	 */
	public void setMaskedCcNumber(String maskedCcNumber) {
		this.maskedCcNumber = maskedCcNumber;
	}

	public String getCvvNumber() {
		return cvvNumber;
	}

	public void setCvvNumber(String cvvNumber) {
		this.cvvNumber = cvvNumber;
	}

	/**
	 * @return the nameOnCard
	 */
	public String getNameOnCard() {
		return nameOnCard;
	}

	/**
	 * @param nameOnCard the nameOnCard to set
	 */
	public void setNameOnCard(String nameOnCard) {
		this.nameOnCard = nameOnCard;
	}

	/**
	 * @return the lastDigits
	 */
	public String getLastDigits() {
		return lastDigits;
	}

	/**
	 * @param lastDigits the lastDigits to set
	 */
	public void setLastDigits(String lastDigits) {
		this.lastDigits = lastDigits;
	}

}
