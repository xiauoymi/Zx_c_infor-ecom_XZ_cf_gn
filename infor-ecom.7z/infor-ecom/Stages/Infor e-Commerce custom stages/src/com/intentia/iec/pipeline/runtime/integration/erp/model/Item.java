package com.intentia.iec.pipeline.runtime.integration.erp.model;

/**
 * 
 * @author ejamolod
 * 
 */
public class Item {

	private String itemId;

	private String unitCode;

	private String currencyId;

	private String warehouseId;

	private double unitPriceAmount;
	
	private String shippingId;
	//Additional
	private String customerItemID;

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public String getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(String unitCode) {
		this.unitCode = unitCode;
	}

	public String getCustomerItemID() {
		return customerItemID;
	}

	public void setCustomerItemID(String customerItemID) {
		this.customerItemID = customerItemID;
	}

	public String getCurrencyId() {
		return currencyId;
	}

	public void setCurrencyId(String currencyId) {
		this.currencyId = currencyId;
	}

	public String getWarehouseId() {
		return warehouseId;
	}

	public void setWarehouseId(String warehouseId) {
		this.warehouseId = warehouseId;
	}

	public double getUnitPriceAmount() {
		return unitPriceAmount;
	}

	public void setUnitPriceAmount(double unitPriceAmount) {
		this.unitPriceAmount = unitPriceAmount;
	}
	
	public String getShippingId(){
		return this.shippingId;
	}
	
	public void setShippingId(String shippingId){
		this.shippingId=shippingId;
	}
	

	
}
