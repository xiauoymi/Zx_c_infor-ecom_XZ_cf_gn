package com.intentia.iec.pipeline.runtime.stage.custom.equipment.location;

/**
 * Represents the cartesian coordinate system (x, y, z). This is the coordinate system supported by M3.
 *
 */
public class CartesianCoordinate {
	private double coordinateX = 0;
	
	private double coordinateY = 0;
	
	private double coordinateZ = 0;
	
	/**
	 * Constructor.
	 * @param x
	 * @param y
	 * @param z
	 */
	public CartesianCoordinate(double x, double y, double z) {
		coordinateX = x;
		coordinateY = y;
		coordinateZ = z;
	}

	/**
	 * Returns x
	 * @return
	 */
	public double getCoordinateX() {
		return coordinateX;
	}

	/**
	 * Sets x
	 * @param coordinateX
	 */
	public void setCoordinateX(double coordinateX) {
		this.coordinateX = coordinateX;
	}

	/**
	 * Returns y
	 * @return
	 */
	public double getCoordinateY() {
		return coordinateY;
	}

	/**
	 * Sets y
	 * @param coordinateY
	 */
	public void setCoordinateY(double coordinateY) {
		this.coordinateY = coordinateY;
	}

	/**
	 * Gets z
	 * @return
	 */
	public double getCoordinateZ() {
		return coordinateZ;
	}

	/**
	 * Returns z
	 * @param coordinateZ
	 */
	public void setCoordinateZ(double coordinateZ) {
		this.coordinateZ = coordinateZ;
	}

}
