/*
 * Created on 03-03-2006
 */
package com.intentia.iec.pipeline.runtime.custom.pim;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * Class representing an XML request &lt;entity&gt; element (and its content).
 * 
 * @author PEDJES0
 * 
 */
public class Entity extends Set {
    private String key = null;

    private List children = null;

    private Map textSubSet = null;

    public final String getKey() {
        return key;
    }

    public final void setKey(final String key) {
        this.key = key;
    }

    public final void addChildSet(final Subset subset) {
        if (children == null) {
            children = new LinkedList();
        }
        children.add(subset);
    }

    public final void addChildTextSubSet(final String languageId, final Subset subset) {
        if (textSubSet == null) {
            textSubSet = new HashMap();
        }
        textSubSet.put(languageId, subset);
    }

    public final Subset findChildTextSubSet(final String languageId) {
        if (textSubSet == null) {
            return null;
        }

        return (Subset) textSubSet.get(languageId);
    }

    public final Collection getTextSubsets() {
        if (textSubSet == null) {
            return null;
        }
        return textSubSet.values();
    }

    public final List getChildren() {
        return children;
    }
}
