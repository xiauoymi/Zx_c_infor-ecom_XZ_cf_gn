package com.intentia.iec.pipeline.runtime.stage.custom.daf.drawing;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.intentia.icp.common.CMCollection;
import com.intentia.icp.common.CMCollections;
import com.intentia.icp.common.CMException;
import com.intentia.icp.common.CMItem;
import com.intentia.icp.common.CMItems;
import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage;

/**
 * Sets the Has Drawing attribute of items displayed in the Spare Parts List.
 *
 */
public class MarkHasDrawingStage extends AbstractDafSearchStage {
	private static final Logger LOG = Logger.getLogger(MarkHasDrawingStage.class);
	
	private static final String MAINSET_ITEMS = "resultset/row";
	
	private static final String ITEM_ID = "ItemID";
	
	private static final String HAS_DRAWING = "HasDrawing";
	
	/**
	 * Query to search for all Drawings of all items displayed in the Spare Parts List page
	 */
	private static final String SELECT_ITEMNUMBERS = DafDrawingConstants.TABLE + "[" + DafDrawingConstants.COLUMN_ITEM_NUMBER + " IN (";
	
	/**
	 * Must have hot spots and unsorted.
	 * This is different from DafSearchDrawingDetailsCCStage.WITH_HOTSPOTS
	 * Must have no serial number.
	 */
	private static final String WITH_HOTSPOTS = ") AND (" + DafDrawingConstants.COLUMN_SERIAL_NUMBER + " IS NULL OR " + DafDrawingConstants.COLUMN_SERIAL_NUMBER + "=\"\") AND " + DafDrawingConstants.COLUMN_NAME + " IS NOT NULL AND " + DafDrawingConstants.COLUMN_DRAWING_NUMBER + " IS NOT NULL AND (ESA_DrawingHotspots/@ESA_SerialNumber=\"\" OR ESA_DrawingHotspots/@ESA_SerialNumber IS NULL) AND ESA_DrawingHotspots/@ESA_Coordinates IS NOT NULL AND ESA_DrawingHotspots/@ESA_ShapeCode IS NOT NULL AND ESA_DrawingHotspots/@ESA_ItemNumber IS NOT NULL AND " + DafDrawingConstants.COLUMN_STATUS + " = " + DafDrawingConstants.DAFStatusCodes.APPROVED + "]";
	
	private XMLResultset resultset = null;
	
	private String userId = null;
	
	private String userGroupId = null;
	
	private String warehouseId = null;
	
	private static final String PARENT = "Parent";
	
	private static final String CHILD = "Child";
	
	private static final String PARAM_USER_ID = "@UserID";
	
	private static final String PARAM_USERGROUP_ID = "@UserGroupID";
	
	private static final String PARAM_WAREHOUSE_ID = "@MvxWarehouse";
	
	/**
	 * SQL statement that retrieves all valid product-child values from e-Sales database.
	 */
	private static final String SQL = 
		"select distinct i.itemNumber as Parent, i2.itemNumber as Child from SparePart sp " +
		"inner join Item i on sp.productID = i.id " +
		"inner join Item i2 on sp.sparePartID = i2.id " +
		"inner join ItemVisible iv on iv.itemId = sp.sparePartID or iv.itemId = sp.productID " +
		"inner join UserAssortment ua ON ua.assortmentId = iv.assortmentId " +
		"where ua.userId = ? AND ua.userGroupId = ? AND (0 = (SELECT COUNT(*) FROM WarehouseItem) OR 0 < (SELECT COUNT(*) FROM WarehouseItem wi INNER JOIN Warehouse w ON w.[id] = wi.warehouseId WHERE iv.itemId = wi.itemId AND w.warehouse = ?)) " +
		"and i.isActive = 'Y' and i2.isActive='Y'" +
		"union " +
		"select distinct i.itemNumber as Parent, i2.itemNumber as Child from AlternativeItem ai " +
		"inner join Item i on ai.productId = i.id " +
		"inner join Item i2 on ai.alternativeItemId = i2.id " +
		"inner join ItemVisible iv on iv.itemId = ai.alternativeItemId or iv.itemId = ai.productID " +
		"inner join UserAssortment ua ON ua.assortmentId = iv.assortmentId " +
		"where ua.userId = ? AND ua.userGroupId = ? AND (0 = (SELECT COUNT(*) FROM WarehouseItem) OR 0 < (SELECT COUNT(*) FROM WarehouseItem wi INNER JOIN Warehouse w ON w.[id] = wi.warehouseId WHERE iv.itemId = wi.itemId AND w.warehouse = ?)) " +
		"and i.isActive = 'Y' and i2.isActive='Y'";

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getQuery(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public String getQuery(PipelineContext context) throws ParametersException, ParserConfigurationException, SAXException, Exception {
		
		// skip stage if Image Mapper property = false?
		if (Boolean.valueOf(CustomStagesHelper.getKeyValue("Application.Image Mapper")).booleanValue() == false) {
			return null;
		}		
		
		if (context.getRequest() instanceof XMLRequest) {
			XMLRequest request = (XMLRequest)context.getRequest();
			Parameters params = request.getParameters();
			this.userId = params.getString(PARAM_USER_ID);
			this.userGroupId = params.getString(PARAM_USERGROUP_ID);
			this.warehouseId = params.getString(PARAM_WAREHOUSE_ID);
		}
		
		if (context.getResponse() instanceof XMLResultset) {
			// get all Item Numbers in the Spare Parts List page
			Set<String> set = getSparePartsListItemNumbers(context);
			
			if (set.isEmpty() == false) {
				// get query string for all Item Numbers 
				return getXQuery(set);
			}
		}
		return null;
	}
	
	/**
	 * Returns a Set containing all Item Numbers displayed in the page
	 * @param context
	 * @return
	 * @throws ResultsetException
	 * @throws TransformerException
	 */
	private Set<String> getSparePartsListItemNumbers(PipelineContext context) throws ResultsetException, TransformerException {
		Set<String> itemNumbers = new HashSet<String>();
		this.resultset = (XMLResultset) context.getResponse();
		this.resultset.moveFirst();
		
		Document xmlDoc = this.resultset.getDocument();
		NodeList nodeList = XPathAPI.selectNodeList(xmlDoc, MAINSET_ITEMS);
		
		// iterate through the main set
		for (int i = 0; i < nodeList.getLength(); i++) {
			Element e = (Element) nodeList.item(i);
			if (e.getAttribute(ITEM_ID) != null) {
				// add item number to the Set
				itemNumbers.add(e.getAttribute(ITEM_ID));
			}
		}		
		
		return itemNumbers;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getResultSize()
	 */
	@Override
	public int getResultSize() {
		return 0;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getStartIndex()
	 */
	@Override
	public int getStartIndex() {
		return 0;
	}
	
	/**
	 * Returns all valid product-child in the e-Sales database.
	 * @return
	 */
	private Map<String, Set<String>> getVisibleProductChild() {
		Map<String, Set<String>> ret = new HashMap<String, Set<String>>();
		
		Connection conn = null; 
		PreparedStatement stmt = null;
		try {
			conn = (Connection) CustomStagesHelper.getConnection("esales.cursor");
			stmt = conn.prepareStatement(SQL);			
			
			stmt.setString(1, this.userId);
			stmt.setString(2, this.userGroupId);
			stmt.setString(3, this.warehouseId);
			stmt.setString(4, this.userId);
			stmt.setString(5, this.userGroupId);
			stmt.setString(6, this.warehouseId);
			
			LOG.debug("Executing SQL statement=" + SQL);

			long startTime = System.currentTimeMillis();
			ResultSet sqlResultSet = stmt.executeQuery();
			long stopTime = System.currentTimeMillis();
			LOG.debug("Total execution time: " + (stopTime - startTime) + " ms");			

			if (sqlResultSet != null) {
				while (sqlResultSet.next() == true) {
					// get parent, child
					String parent = sqlResultSet.getString(PARENT);
					String child = sqlResultSet.getString(CHILD);

					// store product-child in Map
					if (parent != null && child != null) {
						if (ret.get(parent) == null) {
							ret.put(parent, new HashSet<String>());
						}
						// add child to parent
						Set<String> parentSet = ret.get(parent);
						parentSet.add(child);
					}
				}
			}
			
		} catch (PipelineRuntimeException e) {
			LOG.error(e);
		} catch (SQLException e) {
			LOG.error(e);
		}
		finally {
			LOG.debug("Closing statement object.");
			if (stmt != null) {
				try {
					stmt.close();
				}
				catch (SQLException e) {
					LOG.error(e);
				}
				stmt = null;
			}
			
			LOG.debug("Closing connection object.");
			if (conn != null) {
				try {
					conn.close();
				}
				catch (SQLException e) {
					LOG.error(e);
				}
				conn = null;
			}
		}
		
		LOG.debug("Visible product-child for this user=" + ret.size());
		return ret;
	}
	
	/**
	 * Returns a Set of Item Numbers with valid Drawings
	 * @param resultItems from DAF
	 * @param visibleProductChild from e-Sales database
	 * @return
	 */
	private Set<String> getItemNumbersWithValidDrawings(CMItems resultItems, Map<String, Set<String>> visibleProductChild) {
		Set<String> ret = new HashSet<String>();
		
		if (resultItems != null && resultItems.size() > 0 && visibleProductChild != null && visibleProductChild.size() > 0) {
			for (int i = 0; i < resultItems.size(); i++) {
				CMItem item = resultItems.get(i);
				CMCollections collections = item.getCollections(DafDrawingConstants.ATTRIBUTE_HOTSPOTS);
				
				// check if there is a valid hot spot in the drawing
				if (collections != null && collections.size() > 0) {
					String itemNumber = (String) item.getAttributeValue(DafDrawingConstants.ATTRIBUTE_ITEM_NUMBER);
					Iterator<?> it = collections.iterator();

					while (it.hasNext() == true) {
						CMCollection collection = (CMCollection) it.next();
						// check if valid hot spot
						boolean valid = DafDrawingUtils.isValidHotSpot(collection);

						if (valid == true) {
							// check if any hot spot item number is in product-child
							String hotspotItemNumber = (String) collection.getAttributeValue(DafDrawingConstants.ATTRIBUTE_ITEM_NUMBER);
							Set<String> children = visibleProductChild.get(itemNumber);

							if (children != null && children.contains(hotspotItemNumber) == true) {	
								// add to Set
								ret.add(itemNumber);
								break;
							}
						}
					}
				}
			}
		}
		
		LOG.debug("Item numbers with valid drawings in this page=" + ret.size());
		return ret;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#processResult(com.intentia.icp.common.CMItems, int[])
	 */
	@Override
	public XMLResultset processResult(CMItems resultItems, int[] dafStatus) throws CMException, ParametersException {
		if (resultItems != null && resultItems.size() > 0) {
			LOG.debug("Drawings found=" + resultItems.size());
			
			// get product-child defined in e-Sales
			Map<String, Set<String>> visibleProductChild = getVisibleProductChild();
			
			// get Item Numbers with valid Drawings from DAF
			Set<String> itemNumbers = getItemNumbersWithValidDrawings(resultItems, visibleProductChild);
			
			try {				
				markDrawing(itemNumbers);
			}
			catch (Exception e) {
				LOG.error(e);
			}
		}
		return null;
	}
	
	/**
	 * Sets the Has Drawing attribute on the XMLResultset.
	 * @param itemNumbers
	 * @throws ResultsetException
	 * @throws TransformerException
	 */
	private void markDrawing(Set<String> itemNumbers) throws ResultsetException, TransformerException {
		if (this.resultset != null && itemNumbers != null && itemNumbers.isEmpty() == false) {
			Document xmlDoc = this.resultset.getDocument();
			NodeList nodeList = XPathAPI.selectNodeList(xmlDoc, MAINSET_ITEMS);

			// iterate through the main set
			for (int i = 0; i < nodeList.getLength(); i++) {
				Element e = (Element) nodeList.item(i);
				
				// check if ItemID attribute exists
				if (e.getAttribute(ITEM_ID) != null) {
					
					// check if ItemID is in Set of valid Drawings 
					if (itemNumbers.contains(e.getAttribute(ITEM_ID)) == true) {
						e.setAttribute(HAS_DRAWING, DafDrawingConstants.YES);
					}
					else {
						e.setAttribute(HAS_DRAWING, DafDrawingConstants.NO);
					}
				}
			}
		}
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#setOutputParameters(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public void setOutputParameters(PipelineContext context) throws PipelineRuntimeException {
		// intentionally blank
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafStage#getEmptyResultSet()
	 */
	@Override
	public XMLResultset getEmptyResultSet() {
		return null; 
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafStage#getAttributeToDafDatabaseField(java.lang.String)
	 */
	@Override
	public String getAttributeToDafDatabaseField(String attribute) {
		return null;
	}
	
	/**
	 * Returns query string to get Drawings of items displayed in the page
	 * @param set
	 * @return
	 */
	private String getXQuery(Set<String> set) {
		StringBuffer buf = new StringBuffer(SELECT_ITEMNUMBERS);		
		boolean first = true;
		
		if (set != null) {
			Iterator<String> it = set.iterator();
			while (it.hasNext() == true) {
				String itemNumber = it.next();
				if (first == false) {
					buf.append(",");
				}
				buf.append("\"" + encodeXML(itemNumber) + "\"");
				first = false;
			}
			buf.append(WITH_HOTSPOTS);
		}
		
		return buf.toString();
	}
}
