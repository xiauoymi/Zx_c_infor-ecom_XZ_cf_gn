package com.intentia.iec.pipeline.runtime.stage.custom;

import java.text.DateFormat;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.Resultset;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.util.mail.ESalesMail;

public class SendMailOnOrder implements PipelineStage {

	private static final Logger LOG = Logger.getLogger(SendMailOnOrder.class);

	private Parameters parameters = null;

	// PARAMETERS
	private static final String PARAM_LANGUAGECODE = "@LanguageCode";

	private static final String PARAM_EMAIL = "Email";

	private static final String PARAM_SENDMAILONORDER = "SendMailOnOrder";

	private static final String PARAM_USERNAME = "Username";

	private static final String PARAM_ALTEXCHANGERATE = "altExchangeRate";

	private static final String PARAM_EXCHANGERATE = "exchangeRate";

	private static final String PARAM_EXECUTEINCLUDETAX = "executeIncludeTax";

	private static final String PARAM_CURRENCYCODE = "@CurrencyCode";

	private static final String PARAM_ORDERFILESTATUS = "orderFileStatus";

	private static final String PARAM_FILEID = "FileID";

	private static final String PARAM_YOURREFERENCE = "YourReference";

	private static final String PARAM_CUSTOMER_ORDERNUMBER = "CustomerOrderNo";

	private static final String ORDERFILE_STATUS_FAILED = "failed";
	
	public static final String ECP_ENABLED = "Application.Equipment Portal";

	private String mailServerAddress = null;

	private String mailServerPort = null;

	private String sendMailOnOrder = null;

	private String languageCode = null;

	private String email = null;

	private String username = null;

	private String merchantEmail = null;

	private String altExchangeRate = null;

	private String exchangeRate = null;

	private String executeIncludeTax = null;

	private String currenyCode = null;

	private String orderFileStatus = null;

	private String fileID = null;

	private String yourReference = null;

	private String customerOrderNumber = null;

	private static final String ORDERACKNOWLEDGE_PAGE = "/cc/OrderAcknowledge.jsp";

	public void execute(PipelineContext context)
			throws PipelineRuntimeException {
		try {
			// Get Request Parameter
			getRequestParameters(context);

			// Compose and Send Email Order Notification
			sendMail(context);
		} catch (Throwable e) {
			LOG.debug("Unable to send email notification", e);
			// catching all throwable exceptions
			// his is to prevent transaction rollback
		}

	}

	private void sendMail(PipelineContext context) throws PipelineRuntimeException {
        try {
            ESalesMail msgMail = null;
            mailServerAddress = getValueFromApplicationData("MailServer");
            mailServerPort = getValueFromApplicationData("MailServerPort");

            // Add submit on Order role
            if (!mailServerAddress.equals("0.0.0.0") && !mailServerAddress.equals("") && sendMailOnOrder.equals("true")) {
                msgMail = new ESalesMail(mailServerAddress, mailServerPort);
            } else {
                return;
            }

            // Compose Email
            msgMail.setSender(getValueFromApplicationData("MailSender"));

            // Add Merchant to Mail recipient once MerchantEmail was found
            merchantEmail = getValueFromApplicationData("MerchantEmail");
            if (!merchantEmail.equals("") && merchantEmail != null) {
                msgMail.AddRecipient(merchantEmail);
            }

            // Add Mail Recipient
            msgMail.AddRecipient(email);
            msgMail.setSubject(getPageText(ORDERACKNOWLEDGE_PAGE, "mailsubject", languageCode));

            // Mail Content
            msgMail.AppendText(getPageText(ORDERACKNOWLEDGE_PAGE, "mailopening", languageCode));
            msgMail.AppendText(" " + username);
            msgMail.AppendText(System.getProperty("line.separator") + System.getProperty("line.separator"));

            if (ORDERFILE_STATUS_FAILED.equals(orderFileStatus)) {
                msgMail.AppendText(failedOrderNotification(context));
            } else {
                msgMail.AppendText(succesfulOrderNotification(context));
            }

            msgMail.AppendText(System.getProperty("line.separator") + System.getProperty("line.separator"));

            if ("true".equals(CustomStagesHelper.getKeyValue(ECP_ENABLED))) {
            	msgMail.AppendText(getPageText(ORDERACKNOWLEDGE_PAGE, "mailclosing_ecp", languageCode));
            }
            else {
            	msgMail.AppendText(getPageText(ORDERACKNOWLEDGE_PAGE, "mailclosing", languageCode));
            }

            msgMail.send();
            int statusMail = msgMail.getStatus();

            if (statusMail == 0) {
                LOG.debug("EmailSent test was true");
            }
        } catch (Exception e) {
            throw new PipelineRuntimeException(e);
        }
    }

	private String succesfulOrderNotification(PipelineContext context)
			throws PipelineRuntimeException {
		StringBuffer msg = new StringBuffer("");
		try {
			String param = null;
			XMLResultset rsOrderHeader = null;
			Resultset rsOrderLines = null;
			String xOrderid = null;
			int xMvxStatus = 0;

			msg.append(getPageText(ORDERACKNOWLEDGE_PAGE, "mailreceived",
					languageCode));

			XMLResultset rs = (XMLResultset) context.getResponse();
			Parameters statusParams = rs.getParameters();

			boolean mxvEnabled = ("true".equals(CustomStagesHelper
					.getKeyValue(ConstantsForSales.CONNECTORENABLED)));

			if (mxvEnabled) {
				xMvxStatus = statusParams.getint(ConstantsForSales.MVXSTATUS);

				if (xMvxStatus > -1000 && xMvxStatus == -25) {
					xOrderid = statusParams
							.getString(ConstantsForSales.GENERATEDORDERNO);
				} else {
					xOrderid = statusParams
							.getString(ConstantsForSales.SUBMITTEDORDERID);
				}
			} else {
				xOrderid = statusParams
						.getString(ConstantsForSales.SUBMITTEDORDERID);
			}

			msg.append(xOrderid);
			msg.append(System.getProperty("line.separator"));

			param = getValueFromApplicationData("ApplicationURL")
					+ "/cc/PreviousDetails.jsp?@where.OrderID=" + xOrderid;
			msg.append(param);

			msg.append(System.getProperty("line.separator")
					+ System.getProperty("line.separator"));

			rs.moveFirst();

			rsOrderLines = rs.getResultset("OrderLine");

			rsOrderLines.moveFirst();

			String itemNumber = null;

			for (int i = 0; i < rsOrderLines.rowCount(); i++) {

				if (rsOrderLines.getString(ConstantsForSales.USECID) != null
						&& "Y".equals(rsOrderLines.getString(
								ConstantsForSales.USECID).trim())) {
					itemNumber = rsOrderLines
							.getString(ConstantsForSales.CUSTOMERITEMID);
				} else {
					itemNumber = rsOrderLines
							.getString(ConstantsForSales.ITEMID);
				}

				param = " "
						+ getPageText(ORDERACKNOWLEDGE_PAGE, "status",
								languageCode)
						+ ": "
						+ (!("".equals(rsOrderLines
								.getString("OrderLineStatus"))) ? getPageText(
								ORDERACKNOWLEDGE_PAGE, "orderlinesuccess",
								languageCode) : getPageText(
								ORDERACKNOWLEDGE_PAGE, "orderlinefailed",
								languageCode))
						+ System.getProperty("line.separator")
						+ " "
						+ getPageText(ORDERACKNOWLEDGE_PAGE, "sku",
								languageCode)
						+ ": "
						+ itemNumber
						+ " "
						+ getPageText(ORDERACKNOWLEDGE_PAGE, "item",
								languageCode)
						+ ": "
						+ rsOrderLines.getString(ConstantsForSales.ITEMNAME)
						+ " "
						+ getPageText(ORDERACKNOWLEDGE_PAGE, "qty",
								languageCode) + ": "
						+ rsOrderLines.getDecimal(ConstantsForSales.QUANTITY)
						+ " (" + rsOrderLines.getString(ConstantsForSales.UNIT)
						+ ") " + System.getProperty("line.separator");
				msg.append(param);

				param = " "
						+ getPageText(ORDERACKNOWLEDGE_PAGE, "yourprice",
								languageCode)
						+ "("
						+ currenyCode
						+ ") : "
						+ rsOrderLines
								.getDecimal(ConstantsForSales.RESELLPRICE)
						+ " "
						+ getPageText(ORDERACKNOWLEDGE_PAGE, "lineprice",
								languageCode)
						+ "("
						+ currenyCode
						+ ") : "
						+ rsOrderLines.getDecimal(ConstantsForSales.LINEPRICE)
						+ " "
						+ getPageText(ORDERACKNOWLEDGE_PAGE, "sum",
								languageCode) + "(" + currenyCode + ") : "
						+ rsOrderLines.getDecimal(ConstantsForSales.LINETOTAL)
						+ System.getProperty("line.separator")
						+ System.getProperty("line.separator");
				msg.append(param);

				rsOrderLines.moveNext();

			}

		} catch (Exception e) {
			LOG.debug(e.getMessage());
			throw new PipelineRuntimeException(e);
		}
		return msg.toString();
	}

	private String failedOrderNotification(PipelineContext context)
			throws PipelineRuntimeException {
		String msg = null;
		try {
			XMLResultset rsOrderFile = getOrderFileDetails(fileID);
			rsOrderFile.moveFirst();

			String urlOrderFilePage = getValueFromApplicationData("ApplicationURL")
					+ "/cc/OrderFileUpload.jsp";
			String lineSeparator = System.getProperty("line.separator");

			msg = ""
					+ getPageText(ORDERACKNOWLEDGE_PAGE,
							"errorProcessingOrderFile", languageCode)
					+ System.getProperty("line.separator")
					+ System.getProperty("line.separator")
					+ "Order Staus: "
					+ orderFileStatus.toUpperCase()
					+ lineSeparator
					+ urlOrderFilePage
					+ lineSeparator
					+ lineSeparator
					+ "Order Details : "
					+ lineSeparator
					+ "     "
					+ getPageText(ORDERACKNOWLEDGE_PAGE, "yourReference",
							languageCode)
					+ ": "
					+ yourReference
					+ lineSeparator
					+ "     "
					+ getPageText(ORDERACKNOWLEDGE_PAGE, "customerOrderNo",
							languageCode)
					+ ": "
					+ customerOrderNumber
					+ lineSeparator
					+ lineSeparator
					+ "Order File Details : "
					+ lineSeparator
					+ "     "
					+ "Filename : "
					+ rsOrderFile.getString("UserFileName")
					+ lineSeparator
					+ "     "
					+ "File type : "
					+ rsOrderFile.getString("FileType").toUpperCase()
					+ lineSeparator
					+ "     "
					+ "Date Uploaded : "
					+ DateFormat.getDateInstance(DateFormat.FULL).format(
							rsOrderFile.getDate("UploadDate")) + lineSeparator
					+ lineSeparator + lineSeparator;

		} catch (Exception e) {
			LOG.debug(e.getMessage());
			throw new PipelineRuntimeException(e);
		}

		return msg;
	}

	private String getValueFromApplicationData(String pParamName) {

		String paramValue;

		SearchPipelineExecuter seOrderItems = new SearchPipelineExecuter(
				ConstantsForSales.PIPELINE_PACKAGE, "ApplicationData",
				"Details");

		seOrderItems.setParam("param", pParamName);

		try {
			XMLResultset rs = seOrderItems.execute();
			rs.moveFirst();
			paramValue = rs.getString("ParameterValue");
		} catch (PipelineRuntimeException e) {
			paramValue = "";
		} catch (ResultsetException e) {
			paramValue = "";
		}

		return paramValue;

	}

	private String getPageText(String pPageName, String pName,
			String pLanguageCode) throws PipelineRuntimeException {

		String pageText = "";

		SearchPipelineExecuter seOrderItems = new SearchPipelineExecuter(
				ConstantsForSales.PIPELINE_PACKAGE, "SiteText", "List");

		seOrderItems.setBinding("SitePageName", pPageName, "eq");
		seOrderItems.setBinding("Name", pName, "eq");
		seOrderItems.setParam("@LanguageCode", "en");

		try {
			XMLResultset rs = seOrderItems.execute();
			rs.moveFirst();
			Resultset rsText = rs.getResultset("Text");

			rsText.beforeFirst();

			while (rsText.hasNext()) {
				rsText.moveNext();
				String test = rsText.getString("LanguageID");
				if (test.equals(pLanguageCode)) {
					pageText = rsText.getString("Text");
				}
			}

		} catch (ResultsetException e) {
			LOG.error("Unable to get Page text for Page: " + pPageName
					+ ", text name: " + pName + ", and language: "
					+ pLanguageCode);
			pageText = "";
		}

		return pageText;

	}

	private XMLResultset getOrderLines(String pOrderID, String pLanguageCode,
			String pAltExchangeRate, String pExchangeRate,
			String pExecuteIncludeTax) throws PipelineRuntimeException {

		SearchPipelineExecuter seOrderLines = new SearchPipelineExecuter(
				ConstantsForSales.PIPELINE_PACKAGE, "PreviousOrder",
				"GetDataForDetailsP");

		seOrderLines.setParam("orderID", pOrderID);
		seOrderLines.setParam("@LanguageCode", pLanguageCode);
		seOrderLines.setParam("altExchangeRate", pAltExchangeRate);
		seOrderLines.setParam("exchangeRate", pExchangeRate);
		seOrderLines.setParam("executeIncludeTax", pExecuteIncludeTax);

		XMLResultset rs = seOrderLines.execute();

		return rs;

	}

	private XMLResultset getOrderFileDetails(String pFileID)
			throws PipelineRuntimeException {

		SearchPipelineExecuter seOrderFile = new SearchPipelineExecuter(
				ConstantsForSales.PIPELINE_PACKAGE, "OrderFile",
				"Details");

		seOrderFile.setParam("FileId", pFileID);

		XMLResultset rs = seOrderFile.execute();

		return rs;
	}

	private void getRequestParameters(PipelineContext context)
			throws PipelineRuntimeException {

		// Verify type of request
		if (!(context.getRequest() instanceof XMLRequest)) {
			throw new PipelineRuntimeException(
					"Request MUST be of type XMLRequest!");
		}

		XMLRequest request = (XMLRequest) context.getRequest();

		try {

			XMLRequest.extractRequestParameters(request);
			parameters = request.getParameters();

			// Fetch request parameters
			sendMailOnOrder = parameters.getString(PARAM_SENDMAILONORDER);
			languageCode = parameters.getString(PARAM_LANGUAGECODE);
			email = parameters.getString(PARAM_EMAIL);
			username = parameters.getString(PARAM_USERNAME);
			altExchangeRate = parameters.getString(PARAM_ALTEXCHANGERATE);
			exchangeRate = parameters.getString(PARAM_EXCHANGERATE);
			executeIncludeTax = parameters.getString(PARAM_EXECUTEINCLUDETAX);
			currenyCode = parameters.getString(PARAM_CURRENCYCODE);
			orderFileStatus = parameters.getString(PARAM_ORDERFILESTATUS);
			fileID = parameters.getString(PARAM_FILEID);

			yourReference = parameters.getString(PARAM_YOURREFERENCE);
			if (yourReference == null || "null".equals(yourReference))
				yourReference = "";

			customerOrderNumber = parameters
					.getString(PARAM_CUSTOMER_ORDERNUMBER);
			if (customerOrderNumber == null
					|| "null".equals(customerOrderNumber))
				customerOrderNumber = "";

			/* TODO Handling of 'null' string in the presentation layer */

		} catch (Exception e) {
			throw new PipelineRuntimeException(e);
		}
	}

}
