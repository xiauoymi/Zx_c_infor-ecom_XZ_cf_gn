package com.intentia.iec.pipeline.runtime.integration.creditcard.exception;

public class CreditCardConnectionException extends Exception {

	private static final long serialVersionUID = 1L;

	public CreditCardConnectionException() {
		super();
	}

	public CreditCardConnectionException(String message) {
		super(message);
	}

	public CreditCardConnectionException(Throwable cause) {
		super(cause);
	}

	public CreditCardConnectionException(String message, Throwable cause) {
		super(message, cause);
	}
	
}
