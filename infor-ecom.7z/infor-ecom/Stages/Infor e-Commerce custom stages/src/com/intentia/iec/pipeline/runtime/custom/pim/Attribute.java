/*
 * Created on 06-03-2006
 */
package com.intentia.iec.pipeline.runtime.custom.pim;

/**
 * Class representing an XML request &lt;attribute&gt; element (and its
 * content).
 * 
 * @author PEDJES0
 */
public class Attribute {
    private final String name;

    private final String value;

    public Attribute(final String name, final String value) {
        this.name = name;
        this.value = value;
    }

    public final String getName() {
        return name;
    }

    public final String getValue() {
        return value;
    }
}
