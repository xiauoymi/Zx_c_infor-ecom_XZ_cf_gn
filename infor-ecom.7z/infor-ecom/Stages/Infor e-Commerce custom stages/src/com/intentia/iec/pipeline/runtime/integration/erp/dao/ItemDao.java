package com.intentia.iec.pipeline.runtime.integration.erp.dao;

import com.intentia.iec.pipeline.runtime.integration.erp.exception.ErpConnectionException;
import com.intentia.iec.pipeline.runtime.integration.erp.exception.ErpRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.erp.model.AvailabilityRequest;
import com.intentia.iec.pipeline.runtime.integration.erp.model.CatalogPrice;
import com.intentia.iec.pipeline.runtime.integration.erp.model.CatalogPriceRequest;
import com.intentia.iec.pipeline.runtime.integration.erp.model.ItemAvailability;

public interface ItemDao {
		
	CatalogPrice getCatalogPrice(CatalogPriceRequest request) throws ErpRuntimeException, ErpConnectionException;
	
	ItemAvailability getAvailability(AvailabilityRequest request) throws ErpRuntimeException, ErpConnectionException;
	
}
