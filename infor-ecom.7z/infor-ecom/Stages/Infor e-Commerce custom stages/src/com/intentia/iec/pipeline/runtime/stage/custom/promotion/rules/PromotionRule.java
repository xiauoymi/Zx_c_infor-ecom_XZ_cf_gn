/**
 * 
 */
package com.intentia.iec.pipeline.runtime.stage.custom.promotion.rules;

import java.math.BigDecimal;
import java.util.List;

import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.utils.Decimal;

/**
 * @author mumali
 * 
 */
public class PromotionRule {

	private List<String> values = null;
	private String operator = null;
	private String field = null;
	private String ruleType = null;
	private String promotionName = null;
	private BigDecimal exchangeRate = null;
	private BigDecimal altExchangeRate = null;
	private BigDecimal convertionRate = null;

	public List<String> getValues() {
		return values;
	}

	public void setValues(List<String> values) {
		this.values = values;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public String getRuleType() {
		return ruleType;
	}

	public void setRuleType(String ruleType) {
		this.ruleType = ruleType;
	}

	public String getPromotionName() {
		return promotionName;
	}

	public void setPromotionName(String promotionName) {
		this.promotionName = promotionName;
	}

	public BigDecimal getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(BigDecimal exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	public void setExchangeRate(String exchangeRate) {
		if (exchangeRate != null && !exchangeRate.isEmpty()) {
			this.setExchangeRate(new BigDecimal(exchangeRate));
		}
	}

	public BigDecimal getAltExchangeRate() {
		return altExchangeRate;
	}

	public void setAltExchangeRate(BigDecimal altExchangeRate) {
		this.altExchangeRate = altExchangeRate;
	}

	public void setAltExchangeRate(String altExchangeRate) {
		if (altExchangeRate != null && !altExchangeRate.isEmpty()) {
			this.setAltExchangeRate(new BigDecimal(altExchangeRate));
		}
	}

	public BigDecimal calculateValueCurrency(String value) {
		if(this.convertionRate==null){
			this.convertionRate = getConversionRate();
		}
		BigDecimal baseAmount = new BigDecimal(value);
		return baseAmount.multiply(convertionRate);
	}

	private BigDecimal getConversionRate() {
		if (exchangeRate.compareTo(Decimal.ZERO) < 1) {
			exchangeRate = new BigDecimal(1);
		}
		if (altExchangeRate.compareTo(Decimal.ZERO) < 0) {
			altExchangeRate = new BigDecimal(1);
		}
		int scale = 20;
		if (altExchangeRate.compareTo(exchangeRate.multiply(new BigDecimal(
				"1000000000"))) == 1) {
			scale = 30;
		} else if (exchangeRate.compareTo(altExchangeRate
				.multiply(new BigDecimal("1000000000"))) == 1) {
			scale = 0;
		}

		return altExchangeRate.divide(exchangeRate, scale,
				BigDecimal.ROUND_HALF_UP);
	}

}
