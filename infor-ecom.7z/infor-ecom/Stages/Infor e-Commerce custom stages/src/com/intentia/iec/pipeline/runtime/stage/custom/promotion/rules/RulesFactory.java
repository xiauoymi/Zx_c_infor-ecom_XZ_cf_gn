/**
 * 
 */
package com.intentia.iec.pipeline.runtime.stage.custom.promotion.rules;

/**
 * @author gsantiago /mgumali
 * 
 */
public abstract class RulesFactory {
	
	public static Rules getRules(String promotionType){
		Rules rules = null;
		if(RulesConstant.AMOUNT.equals(promotionType)){
			rules = AmountImpl.getInstance();
		} else if(RulesConstant.BUY_ITEM.equals(promotionType)){
			rules = BuyItemImpl.getInstance();
		} else if(RulesConstant.PAYMENT.equals(promotionType)){
			rules = PaymentImpl.getInstance();
		} else if(RulesConstant.QUANTITY.equals(promotionType)){
			rules = QuantityImpl.getInstance();
		} else if(RulesConstant.SHIPPING_DETAILS.equals(promotionType)){
			rules = ShippingDetailsImpl.getInstance();
		}
		return rules;
	}

}
