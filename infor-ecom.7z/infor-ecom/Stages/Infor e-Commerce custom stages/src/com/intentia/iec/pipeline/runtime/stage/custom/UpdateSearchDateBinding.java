/*
 * Created on 21-08-2007
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;

/**
 * <p>
 * The <code>UpdateSearchDateBinding</code> stage updates the date binding to
 * add time to the "TO" search date attribute value of the binding, so that the
 * query matches dates inclusive of the "TO" date search.
 * </p>
 * 
 * <p>
 * <b>Generated output in <code>PipelineContext</code>:</b><br>
 * Modified XML request where bindings for the TO date are added by adding 23:59
 * hrs
 * </p>
 */

public final class UpdateSearchDateBinding extends AbstractPipelineStage {
    private static final Logger LOG = Logger.getLogger(UpdateSearchDateBinding.class);

    private static final String ATTRIBUTE_ATTR = "attribute";

    private static final String VALUE_ATTR = "value";

    private static final String OPERATOR_ATTR = "operator";

    // string for element tag names
    private static final String BINDING_TAG = "binding";

    /**
     * <p>
     * Update the TO date binding attribute time value by adding 23.59 hrs
     * </p>
     * 
     * @throws PipelineRuntimeException
     *             if the request in <code>PipelineContext</code> is not of
     *             type <code>XMLRequest</code> or obtaining the request as a
     *             <code>Document</code> object fails.
     * @see com.intentia.iec.pipeline.runtime.PipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
     */
    public void execute(final PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("inside UpdateSearchDateBinding.execute()!");

        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Request must be of type XMLRequest!");
        }

        Document xmlRequest;
        try {
            xmlRequest = getRequest(context).getRequestDoc();
        } catch (RequestException e) {
            throw new PipelineRuntimeException("Failed to obtain request as XMLDocument", e);
        }

        updateDateBindings(xmlRequest);
    }

    /**
     * <p>
     * Get all main set bindings from the request as a <code>NodeList</code>
     * and loop through to find any Date bindings and update the TO date
     * attribute by adding 23.59 hrs to its value.
     * </p>
     * 
     * @param xmlRequest
     *            the request from the <code>PipelineContext</code>
     * @throws PipelineRuntimeException
     */
    private void updateDateBindings(final Document xmlRequest) throws PipelineRuntimeException {

        NodeList bindings = xmlRequest.getElementsByTagName(BINDING_TAG);

        // loop over all bindings
        int bindingCounter = 0;
        while (bindingCounter < bindings.getLength()) {
            Element binding = (Element) bindings.item(bindingCounter);
            String bindingName = binding.getAttribute(ATTRIBUTE_ATTR);
            String operator = "";
            String bindingValue = "";

            // increase counter by 1, i.e. step to next binding
            bindingCounter++;

            // Update bindings of only date attributes
            if (bindingName.toLowerCase().contains("date")) {

                operator = binding.getAttribute(OPERATOR_ATTR);

                // Change binding attribute value only of the TO search date
                if ("LE".equalsIgnoreCase(operator) || "LT".equalsIgnoreCase(operator)) {
                    bindingValue = binding.getAttribute(VALUE_ATTR);
                    bindingValue = bindingValue.replaceFirst("T00:00:00", "T23:59:59");
                    binding.setAttribute(VALUE_ATTR, bindingValue);
                }
            }
        }
    }
}
