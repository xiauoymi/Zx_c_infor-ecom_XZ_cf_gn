package com.intentia.iec.pipeline.runtime.stage.custom;

import org.apache.log4j.Logger;
//import org.jmock.core.constraint.IsNull;

import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLConnection;
import java.io.*;

public class ValidatePersonalText implements PipelineStage {

	private static final Logger LOG = Logger.getLogger(ValidatePersonalText.class);

	private static final String SEQUENTIAL_CONFIG_ENABLED = "Items.Sequential configurator";

	private XMLRequest xmlRequest = null;

	public void execute(final PipelineContext context) throws PipelineRuntimeException {
		LOG.debug("Entering ValidatePersonalText.execute()");

		if (!(context.getRequest() instanceof XMLRequest)) {
			throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
		}
		xmlRequest = (XMLRequest) context.getRequest();

		try {
			XMLRequest.extractRequestParameters(xmlRequest);
		} catch (RequestException e) {
			throw new PipelineRuntimeException("Error extracting request parameters!", e);
		}

		// Movex connector not enabled => skip stage
		if (!"true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.CONNECTORENABLED))) {
			return;
		}

		if (!"true".equals(CustomStagesHelper.getKeyValue(SEQUENTIAL_CONFIG_ENABLED))) {
			return;
		}

		//Replace the following lines with the actual validation logic
		//Start of lines to be replaced
		StringBuffer buf = new StringBuffer("");
		buf.append("<?xml version='1.0' encoding='UTF-8'?>");
		buf.append("<resultset object='DoesNotMatter'>");
		buf.append("</resultset>"); 

		String response = buf.toString();
		context.setResponse(new XMLResultset(response));

		String personalText = getPersonalText();
		String url = "";
		try{
			url = xmlRequest.getParameters().getString("URL") + personalText;
		} catch (ParametersException e) {
			LOG.debug("PersonalText is not in the request parameters.");
		}
		personalText = (personalText != null)?personalText:"";

		/*if (personalText.contains("foul") || personalText.contains("wrong") || personalText.contains("invalid") || personalText.contains("Nike")) {
            CustomStagesHelper.setResponseParameter(context, "isValidText", "N");
        } else {
            CustomStagesHelper.setResponseParameter(context, "isValidText", "Y");
        }*/

		//Hook Connect Personal Text Validation
		BufferedReader rd = null;
		String resp = "";
		try {
			URLConnection conn = new URL(url).openConnection();
			HttpURLConnection connection = (HttpURLConnection) conn;

			connection.setRequestMethod("GET");
			connection.setDoOutput(true);				

			// read response
			rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String line = "";

			// iterate thru the response, creating a single String object
			LOG.debug("Setting ArtWorks response");
			while ((line = rd.readLine()) != null) {
				resp += line;
			}
		}catch (Exception e){
			e.printStackTrace();
			LOG.error(e);
		}finally {
			if (rd != null) {
				try {
					rd.close();
				} catch (IOException e) {						
					LOG.error(e);
				}
				rd = null;
			}
		}
		if (resp.equals("Valid")) {
			CustomStagesHelper.setResponseParameter(context, "isValidText", "Y");
		}else if (resp.equals("InValid")) {
			CustomStagesHelper.setResponseParameter(context, "isValidText", "N");
		}else CustomStagesHelper.setResponseParameter(context, "isValidText", "Y");

		//End of lines to be replaced

		LOG.debug("Exiting ValidatePersonalText.execute()");
	}

	private String getPersonalText() {
		LOG.debug("Entering ValidatePersonalText.getPersonalText");
		String personalText = "";
		try {
			personalText = java.net.URLEncoder.encode(xmlRequest.getParameters().getString("PersonalText"));
			LOG.debug("PersonalText :" + personalText);
		} catch (ParametersException e) {
			LOG.debug("PersonalText is not in the request parameters.");
		}
		LOG.debug("Exiting ValidatePersonalText.getPersonalText");
		return personalText;
	}

}
