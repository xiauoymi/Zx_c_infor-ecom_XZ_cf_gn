package com.intentia.iec.pipeline.runtime.stage.custom.search;

import static com.intentia.iec.pipeline.runtime.stage.custom.search.IndexerUtils.addIndexedField;

import java.io.IOException;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;

public final class BaseDataIndexer implements Indexer {
    private static final Logger LOG = Logger.getLogger(BaseDataIndexer.class);

    private final boolean useWarehousing;

    private final Map<String, String> keyToPath;

    public BaseDataIndexer(boolean useWarehousing, Map<String, String> keyToPath) {
        this.useWarehousing = useWarehousing;
        this.keyToPath = keyToPath;
    }

    public void index(IndexWriter writer) throws PipelineRuntimeException {
        Document doc = new Document();
        addIndexedField(doc, Strings.Index.entryType, Strings.Index.settings);
        addIndexedField(doc, Strings.Index.Settings.warehousing, String.valueOf(useWarehousing));
        try {
            writer.addDocument(doc);
        } catch (IOException e) {
            LOG.error("Problem adding warehousing setting to index", e);
            throw new PipelineRuntimeException();
        }

        for (Map.Entry<String, String> pair : keyToPath.entrySet()) {
            doc = new Document();
            addIndexedField(doc, Strings.Index.entryType, Strings.Index.categoryBaseData);
            addIndexedField(doc, Strings.Index.CategoryBaseData.categoryKey, pair.getKey());
            addIndexedField(doc, Strings.Index.CategoryBaseData.categoryPath, pair.getValue());
            try {
                writer.addDocument(doc);
            } catch (IOException e) {
                LOG.error("Error adding category lookup entry to index", e);
                throw new PipelineRuntimeException();
            }
        }
    }

}
