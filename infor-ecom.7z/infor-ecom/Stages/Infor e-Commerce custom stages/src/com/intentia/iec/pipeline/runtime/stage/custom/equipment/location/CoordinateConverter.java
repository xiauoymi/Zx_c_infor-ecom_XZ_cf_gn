package com.intentia.iec.pipeline.runtime.stage.custom.equipment.location;

/**
 * This is the class that converts a cartesian coordinate to geodetic coordinate.
 * 
 * The following are the resources used for the computation:
 * http://en.wikipedia.org/wiki/Geodetic_system
 * http://en.wikipedia.org/wiki/WGS_84
 * http://www.ebs.ogi.edu/~waldemer/SShmwk2.htm
 * 
 * The following are the pages used for testing the converted values:
 * http://www.apsalin.com/convert-cartesian-to-geodetic.aspx
 * http://www.apsalin.com/convert-geodetic-to-cartesian.aspx
 *
 * This class must be subclassed to set the values for semimajor axis a, b and the inverse flattening.
 * These values are dependent on the Ellipsoid reference.
 */
public abstract class CoordinateConverter {
	
	/**
	 * Returns the semimajor axis a. This dependent on the Ellipsoid datum reference.
	 * @return
	 */
	public abstract double getSemiMajorAxisA();
	
	/**
	 * Returns the semimajor axis b. This dependent on the Ellipsoid datum reference.
	 * @return
	 */
	public abstract double getSemiMajorAxisB();
	
	/**
	 * Returns the inverse flattening (f). This dependent on the Ellipsoid datum reference.
	 * @return
	 */
	public abstract double getInverseFlattening();
	
	/**
	 * Converts a cartesian coordinate to geodetic coordinate.
	 * @param cartesian
	 * @return
	 * @throws ConverterException
	 */
	public GeodeticCoordinate convert(CartesianCoordinate cartesian) throws ConverterException{
		if (cartesian == null) {
			throw new ConverterException("Cartesian coordinate is not defined");
		}
		
		// get latitude
		double latitude = getLatitude(cartesian.getCoordinateX(), cartesian.getCoordinateY(), cartesian.getCoordinateZ());
		
		// get longitude
		double longitude = getLongitude(cartesian.getCoordinateX(), cartesian.getCoordinateY());
		
		// get height
		double height = getHeight(cartesian.getCoordinateX(), cartesian.getCoordinateY(), latitude);
		
		// create a geodetic coordinate object for the result
		return new GeodeticCoordinate(latitude, longitude, height);
	}
	
	/**
	 * Computes the latitude. See http://www.ebs.ogi.edu/~waldemer/SShmwk2.htm for the computation details.
	 * @param coordinateX
	 * @param coordinateY
	 * @param coordinateZ
	 * @return
	 */
	private double getLatitude(double coordinateX, double coordinateY, double coordinateZ) {
		// the result
		double latitude = 0;
		
		// get e2, E, p and u
		double e2 = getE2();
		double E = getE(e2);
		double p = getP(coordinateX, coordinateY);
		double u = getU(coordinateZ, p);
		
		// temporary computation storage
		double workA = (coordinateZ + (E * getSemiMajorAxisB() * Math.pow(Math.sin(u),3)));
		double workB = (p - (e2 * getSemiMajorAxisA() * Math.pow(Math.cos(u), 3)));
		
		// return with the values converted to degrees
		latitude = Math.toDegrees(Math.atan(workA/workB));
		
		return latitude;
	}	
	
	/**
	 * Computes the longitude. See http://www.ebs.ogi.edu/~waldemer/SShmwk2.htm for the computation details.
	 * @param coordinateX
	 * @param coordinateY
	 * @return
	 * @throws ConverterException
	 */
	private double getLongitude(double coordinateX, double coordinateY) throws ConverterException {		
		// based on http://www.apsalin.com/convert-cartesian-to-geodetic.aspx, x cannot be zero.
		if (coordinateX == 0) {
			throw new ConverterException("Invalid cartesian coordinate. X cannot be 0.");
		}
		
		// convert the value to degrees
		double longitude = Math.toDegrees(Math.atan(coordinateY/coordinateX));
		
		// if longitude is negative, add 180
		if (longitude < 0) {
			longitude += 180;
		}
		
		// if the input is negative, subtract 180
		if (coordinateY < 0) {
			longitude -= 180;
		}
		
		return longitude;
	}	
	
	/**
	 * Computes the height. See http://www.ebs.ogi.edu/~waldemer/SShmwk2.htm for the computation details.
	 * @param coordinateX
	 * @param coordinateY
	 * @param latitude
	 * @return
	 */
	private double getHeight(double coordinateX, double coordinateY, double latitude) {
		// the result
		double height = 0;
		
		// get p and v
		double p = getP(coordinateX, coordinateY);
		double v = getV(latitude);
		
		// convert latitude to radians 
		double rad = Math.toRadians(latitude);		
	
		height = p * (1 / Math.cos(rad)) - v;
		
		return height;
	}
	
	/**
	 * Returns f
	 * @return
	 */
	private double getF() {
		return (1/getInverseFlattening());
	}
	
	/**
	 * Returns e2
	 * @return
	 */
	private double getE2() {
		double f = getF();
		
		return (2 * f) - Math.pow(f, 2);
	}
	
	/**
	 * Returns e
	 * @param e2
	 * @return
	 */
	private double getE(double e2) {
		return (e2/(1-e2));
	}
	
	/**
	 * Returns p
	 * @param coordinateX
	 * @param coordinateY
	 * @return
	 */
	private double getP(double coordinateX, double coordinateY) {
		return Math.sqrt(Math.pow(coordinateX, 2) + Math.pow(coordinateY, 2));
	}
	
	/**
	 * Returns u
	 * @param coordinateZ
	 * @param p
	 * @return
	 */
	private double getU(double coordinateZ, double p) {
		return Math.atan((coordinateZ * getSemiMajorAxisA()) / (p*getSemiMajorAxisB()));
	}
	
	/**
	 * Returns v
	 * @param latitude
	 * @return
	 */
	private double getV(double latitude /*in degrees*/) {
		double a = getSemiMajorAxisA();
		double e2 = getE2();		
		double rad = Math.toRadians(latitude);		
		
		return (a / Math.sqrt(1 - e2 * Math.pow(Math.sin(rad), 2)));
	}	
}
