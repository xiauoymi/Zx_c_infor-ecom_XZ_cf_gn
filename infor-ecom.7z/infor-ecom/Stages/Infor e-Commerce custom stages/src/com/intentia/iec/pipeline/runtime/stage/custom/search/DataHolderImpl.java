package com.intentia.iec.pipeline.runtime.stage.custom.search;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.apache.lucene.search.Filter;
import org.apache.lucene.search.IndexSearcher;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;

/**
 * Values returned by methods in this class must not be cached by the client. It
 * is already cached by Manager and Manager will also handle the publication of
 * new index data after a indexing job has run.
 */
public final class DataHolderImpl implements DataHolder {
    private static final Logger LOG = Logger.getLogger(DataHolderImpl.class);

    protected IndexSearcher indexSearcher; // Thread-safe

    protected BaseData baseData; // Thread-safe

    protected FilterCache filterCache; // Thread-safe
    
    /**
     * Creates a DataHolder using the default ManagerImpl.
     * @throws PipelineRuntimeException
     */
    public DataHolderImpl() throws PipelineRuntimeException {
    	this(ManagerImpl.INSTANCE);
    }

    /**
     * Creates a DataHolder using the specified ManagerImpl.
     * @param manager
     * @throws PipelineRuntimeException
     */
    public DataHolderImpl(Manager manager) throws PipelineRuntimeException {
        LOG.info("Preparing data holder");
        String indexFolder = manager.getParentFolder() + "/" + manager.getCurrentFolder();
        try {
            indexSearcher = new IndexSearcher(indexFolder);
        } catch (Exception e) {
            LOG.error("Error creating index searcher", e);
            throw new PipelineRuntimeException();
        }
        baseData = new BaseDataImpl(indexSearcher);
        filterCache = new FilterCache(manager.getFilterCacheCapacity());
    }

    public void close() throws PipelineRuntimeException {
        LOG.info("Closing data holder");
        try {
            // The instance variable indexSearcher is null if indexing is the
            // first operation after WebSphere start.
            if (indexSearcher != null) {
                indexSearcher.close();
            }
        } catch (IOException e) {
            LOG.error("Problem closing IndexSearcher", e);
            throw new PipelineRuntimeException();
        }
    }

    public String getCategoryPathByKey(final String categoryKey) throws PipelineRuntimeException {
        return baseData.getCategoryPathByKey(categoryKey);
    }

    public boolean isWarehousingUsed() {
        return baseData.isWarehousingUsed();
    }

    public IndexSearcher getIndexSearcher() throws PipelineRuntimeException {
        return indexSearcher;
    }

    public Filter getFilter(final String key) {
        return filterCache.getFilter(key);
    }

    public void addFilter(final String key, final Filter filter) {
        filterCache.addFilter(key, filter);
    }
}
