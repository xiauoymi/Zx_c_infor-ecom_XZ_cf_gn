/*
 * Created on 25-03-2004
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.intentia.iec.util.FastStringBuffer;
import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.connection.ConnectorException;
import com.intentia.iec.connection.IMovexApiResultset;
import com.intentia.iec.connection.IMovexConnection;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.utils.Decimal;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

/**
 * Stage to merge order information from Movex into a single order.<br>
 * Get status codes and prices for header and lines plus re-calculates the order
 * totals.
 * <p>
 * <b>Generated output in <code>PipelineContext</code>:</b><br>
 * Output parameter: <code>mvxStatus</code> (error if negative)
 * <p>
 */
public final class MergeMovexOrderDetails extends MergeMovexOrderList implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(MergeMovexOrderDetails.class);

    private Map<String, String> _itemUnitCodes = null;

    private String _languageCodeParam = null;

    /**
     * The stage entry point.
     * 
     * @see com.intentia.iec.pipeline.runtime.PipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
     */
    public void execute(final PipelineContext context) throws PipelineRuntimeException {

        // Movex connector not enabled => skip stage
        if (!"true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.CONNECTORENABLED))) {
            return;
        }

        // check if used for resolving invalid orderlines during Order Simulate
        CustomStagesHelper.extractRequestParameters(CustomStagesHelper.getRequest(context));
        Parameters contextParams = CustomStagesHelper.getRequestParameters(context);
        String resolveBasket = getString(ConstantsForSales.RESOLVE_BASKET, contextParams);

        if (resolveBasket != null && !"null".equals(resolveBasket) && !"true".equals(resolveBasket)) {
            return;
        }

        _languageCodeParam = getString(ConstantsForSales.LANGUAGE_CODE_SQL_PARAM, contextParams);

        // String executeMergeParam =
        // getString(ConstantsForSales.SIMULATE_EXECUTE_MERGE, contextParams);
        // if (executeMergeParam != null) {
        // boolean executeMerge =
        // Boolean.valueOf(executeMergeParam).booleanValue();
        //
        // if (!executeMerge) {
        // LOG.debug("Simulate Order Skip");
        // return;
        // }
        // }

        XMLResultset prevOrder;
        int rows = 0;
        List headAttributes = null;

        try {
            prevOrder = (XMLResultset) context.getResponse();
            if ((prevOrder == null) || prevOrder.isEmpty()) {
                return;
            }
            rows = prevOrder.rowCount();
            prevOrder.moveFirst();
            headAttributes = prevOrder.getNames();
        } catch (ResultsetException e) {
            String msg = "Could not manipulate order result set.";
            LOG.error(msg, e);
            throw new PipelineRuntimeException(msg, e);
        }

        if (rows != 1) {
            return;
        }

        // Code below can only merge Movex data on a single row
        // and if one of 'TotalPrice', 'TotalShip' or 'OrderStatus' exists
        if (headAttributes == null
                || headAttributes.isEmpty()
                || !(headAttributes.contains(ConstantsForSales.TOTALPRICE)
                        || headAttributes.contains(ConstantsForSales.TOTALSHIP) || headAttributes
                        .contains(ConstantsForSales.ORDERSTATUS))) {
            return;
        }

        mergeSingleOrder(context);

        if (LOG.isDebugEnabled()) {
            FastStringBuffer msg = new FastStringBuffer("Response XML as merged from Movex:\n");
            msg.append(context.getResponse().toString());
            LOG.debug(msg.toString());
        }
    }

    /**
     * Merge order information from Movex into the local resultset. Works only
     * on the first record in the resultset in the context.
     * 
     * @param context
     *            pipeline context
     * @throws PipelineRuntimeException
     */
    private void mergeSingleOrder(final PipelineContext context) throws PipelineRuntimeException {

        // Get a connection to Movex - if it fails we return from the stage
        // setting mvxStatus to -1010.
        IMovexConnection con = null;
        try {
            con = (IMovexConnection) CustomStagesHelper.getConnection(ConstantsForSales.OIS100MI);
        } catch (PipelineRuntimeException e) {
            con = null;
        }
        if (con == null) {
            LOG.error("Failed to connect to Movex");
            try {
                CustomStagesHelper.getResponseParameters(context).setint(ConstantsForSales.MVXSTATUS, -1010);
            } catch (ParametersException e) {
                LOG.error("Failed to set response parameters!");
            }
            return;
        }

        try {
            CustomStagesHelper.extractRequestParameters(CustomStagesHelper.getRequest(context));
            Parameters parms = CustomStagesHelper.getRequestParameters(context);

            // Get order ID in Movex from request - to use instead of the one in
            // the response to merge.
            String orderID = getString(ConstantsForSales.SUBMITTEDORDERID, parms);

            XMLResultset prevOrder = (XMLResultset) context.getResponse();
            IMovexApiResultset apiRes = mergeHeader(context, con, orderID);
            if (apiRes == null) {
                return;
            }

            // added as fix to defect 4674
            // Get the API resultset from a call to OIS100MI -> GetOrderValue as
            // the
            // order values returned by GetHead will be 0 when an order is
            // Invoiced.
            IMovexApiResultset apiResForPriceUpdate = getOrderForTotalsUpdate(context, con, orderID);
            if (apiResForPriceUpdate == null) {
                return;
            }

            updateHeaderTotals(prevOrder, apiResForPriceUpdate, null);

            IMovexApiResultset apiResForCharges = getOrderCharges(context, con, orderID);
            if (apiResForCharges == null) {
                return;
            }
            updateHeaderCharges(prevOrder, apiResForCharges, null);

            if (LOG.isDebugEnabled()) {

                LOG.debug("MERGESHIPPINGADDRESS = "
                        + CustomStagesHelper.getKeyValue(ConstantsForSales.MERGESHIPPINGADDRESS));
            }

            // Get and merge shipping address from Movex? true or false...
            if ("true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.MERGESHIPPINGADDRESS))) {
                mergeShippingAddress(context, parms, con, orderID);
            }

            // merge order lines
            mergeOrderLines(context, parms, con, orderID);

        } finally {

            if (con != null) {
                try {
                    con.close();
                } catch (ConnectorException e) {
                    LOG.error("Failed to close connection!");
                }
            }
        }
    }

    /**
     * Merge order header information from Movex into local resultset.
     * <p>
     * Calls Movex API OIS100MI/GetOrderValue.<br>
     * 
     * @param context
     *            pipeline context
     * @param con
     *            Movex connection
     * @return Movex API resultset created for merge from GetOrderValue
     *         transaction
     * @throws PipelineRuntimeException
     */
    protected IMovexApiResultset getOrderForTotalsUpdate(PipelineContext context, IMovexConnection con,
            final String orderID) throws PipelineRuntimeException {

        if (LOG.isDebugEnabled()) {
            LOG.debug("Inside new method getOrderForPriceUpdate");
        }
        XMLResultset order = (XMLResultset) context.getResponse();

        // get CONO, ORNO for a Movex call using OIS100MI:GetHead
        Map header = new HashMap();
        // header.put(IMovexConnection.TRANSACTION,
        // ConstantsForSales.GET_ORDER_VALUE);
        header.put(IMovexConnection.TRANSACTION, ConstantsForSales.GET_ORDER_VALUE);
        header.put(ConstantsForSales.CONO, getString(ConstantsForSales.MVXCOMPANY, order));
        header.put(ConstantsForSales.ORNO, (orderID != null) ? orderID : getString(ConstantsForSales.ORDERID, order));

        // retrieve order header data from Movex
        IMovexApiResultset apiRes = CustomStagesHelper.callMovex(context, con, header, ConstantsForSales.MVXSTATUS);

        return apiRes;
    }

    /**
     * Merge order header information from Movex into local resultset.
     * <p>
     * Calls Movex API OIS100MI/GetHead.<br>
     * 
     * @param context
     *            pipeline context
     * @param con
     *            Movex connection
     * @return Movex API resultset created for merge from GetHead transaction
     * @throws PipelineRuntimeException
     */
    protected IMovexApiResultset getOrderCharges(PipelineContext context, IMovexConnection con, final String orderID)
            throws PipelineRuntimeException {

        if (LOG.isDebugEnabled()) {
            LOG.debug("Inside new method getOrderCharges");
        }
        XMLResultset order = (XMLResultset) context.getResponse();

        // get CONO, ORNO for a Movex call using OIS100MI:GetHead
        Map header = new HashMap();
        // header.put(IMovexConnection.TRANSACTION,
        // ConstantsForSales.GET_ORDER_VALUE);
        header.put(IMovexConnection.TRANSACTION, ConstantsForSales.GET_HEAD);
        header.put(ConstantsForSales.CONO, getString(ConstantsForSales.MVXCOMPANY, order));
        header.put(ConstantsForSales.ORNO, (orderID != null) ? orderID : getString(ConstantsForSales.ORDERID, order));

        // retrieve order header data from Movex
        IMovexApiResultset apiRes = CustomStagesHelper.callMovex(context, con, header, ConstantsForSales.MVXSTATUS);

        return apiRes;
    }

    /**
     * Updates the order lines in e-Sales with latest status and prices from
     * Movex.
     * <p>
     * Calls Movex API OIS100MI/LstLine.<br>
     * <p>
     * Note that the number of order lines may not match, as ordering a fashion
     * kit (style) makes Movex probagate the items in the kit into the order
     * while e-Sales alone shows the original fashion kit.
     * 
     * @param context
     *            pipeline context
     * @param params
     *            parameter block from context
     * @param lineIter
     *            XMLIterator pointing on line to handle
     * @param con
     *            Movex connection to use
     * @throws PipelineRuntimeException
     */
    private void mergeOrderLines(final PipelineContext context, final Parameters params, final IMovexConnection con,
            final String orderIDParam) throws PipelineRuntimeException {

        XMLResultset head = (XMLResultset) context.getResponse();
        XMLIterator lineIter = null;
        try {
            lineIter = (XMLIterator) head.getResultset(ConstantsForSales.ORDERLINE);
            if (lineIter == null)
                lineIter = (XMLIterator) head.appendResultset(ConstantsForSales.ORDERLINE);
        } catch (ResultsetException e) {
            String msg = "Could not get order lines";
            LOG.error(msg, e);
            throw new PipelineRuntimeException(msg, e);
        }

        // Use order ID from parameter or form header in response to merge.
        String orderID = (orderIDParam != null) ? orderIDParam : getString(ConstantsForSales.ORDERID, head);

        Map<String, Map> mvxLineMap = getMvxOrderLinesAsMap(orderID, context, con);
        if (mvxLineMap == null)
            return;
        List<String> mvxLineIDs = new ArrayList<String>(mvxLineMap.keySet());
        List<String> existingMvxLines = new ArrayList<String>();

        // update order lines
        try {
            lineIter.beforeFirst();
            while (lineIter.moveNext()) {
                String orderLineID = lineIter.getString(ConstantsForSales.ORDERLINEID);

                if (mvxLineIDs.contains(orderLineID)) {
                    LOG.debug("Updating order line with ID = " + orderLineID);
                    Map mvxLine = (Map) mvxLineMap.get(orderLineID);
                    updateOrderLineAttributes(lineIter, mvxLine);
                    existingMvxLines.add(orderLineID);
                } else {
                    LOG.debug("Deleting order line with ID = " + orderLineID + " (NOT found in M3)");
                    updRsAttr(lineIter, ConstantsForSales.ORDERLINESTATUSID, "90");
                    updRsAttr(lineIter, ConstantsForSales.ORDERLINESTATUS, "Deleted");
                }
            }

            if (existingMvxLines.size() != mvxLineIDs.size())
                addNonExistingMvxLines(lineIter, mvxLineMap, existingMvxLines, mvxLineIDs);            

            boolean doMergeCurrentOrdersDetails = false;
            try {
                doMergeCurrentOrdersDetails = "true".equals(params.getString("mergeCurrentOrder"));
            } catch (ParametersException e) {
                throw new PipelineRuntimeException("Unable to extract request parameters.", e);
            }

            /*
             * This will serve as a workaround for the OIS100:AddBatchLineEnt
             * API Defect. See ChangeOrderDetails.addOrderLines() method
             * definition for more details.
             */
            if (doMergeCurrentOrdersDetails) {
                mergeCurrentOrdersDetails(lineIter, params);
                LOG.debug("XML Reponse after mergeCurrentOrdersDetails(): " + context.getResponse().toString());
            }

        } catch (ResultsetException e) {
            final String msg = "Could not loop order lines when updating IDs. Order: " + orderID;
            throw new PipelineRuntimeException(msg, e);
        }
    }

    private Map<String, Map> getMvxOrderLinesAsMap(final String orderID, final PipelineContext context,
            final IMovexConnection con) throws PipelineRuntimeException {

        XMLResultset head = (XMLResultset) context.getResponse();

        // get CONO, ORNO for a Movex call using OIS100MI:GetLines
        Map lines = new HashMap();
        lines.put(IMovexConnection.TRANSACTION, ConstantsForSales.LST_LINE);
        lines.put(ConstantsForSales.CONO, getString(ConstantsForSales.MVXCOMPANY, head));
        lines.put(ConstantsForSales.ORNO, orderID);

        // retrieve order lines data from Movex
        IMovexApiResultset apiRes = CustomStagesHelper.callMovex(context, con, lines, ConstantsForSales.MVXSTATUS);
        if (apiRes == null) {
            return null;
        }

        Map<String, Map> mvxLineMap = new HashMap<String, Map>();
        Iterator it = apiRes.iterator();
        while (it.hasNext()) {
            Map mvxLine = (Map) it.next();
            String ponr = (String) mvxLine.get(ConstantsForSales.PONR);
            String posx = (String) mvxLine.get(ConstantsForSales.POSX);
            String key = orderID + "_" + ponr + "_" + posx;
            mvxLineMap.put(key, mvxLine);
        }

        return mvxLineMap;
    }

    private void addNonExistingMvxLines(XMLIterator lineIter, final Map<String, Map> mvxLineMap,
            final List<String> existingMvxLines, List<String> mvxLineIDs) throws PipelineRuntimeException {
        try {
            try {
                // Sort order lines based on its line number and line suffix
                Collections.sort(mvxLineIDs, getOrderLineIDComparator());
            } catch (ClassCastException e) {
                throw new PipelineRuntimeException("Unable to sort Mvx line IDs.", e);
            }
            Iterator it = mvxLineIDs.iterator();
            while (it.hasNext()) {
                String orderLineID = (String) it.next();
                if (!existingMvxLines.contains(orderLineID)) {
                    LOG.debug("Adding new order line with ID = " + orderLineID);
                    Map mvxLine = (Map) mvxLineMap.get(orderLineID);
                    lineIter.appendRow();
                    lineIter.setString(ConstantsForSales.ORDERLINEID, orderLineID);
                    updRsAttr(lineIter, ConstantsForSales.LINENUMBER, mvxLine, ConstantsForSales.PONR, null);
                    updRsAttr(lineIter, ConstantsForSales.LINESUFFIX, mvxLine, ConstantsForSales.POSX, "0");
                    updateOrderLineAttributes(lineIter, mvxLine);
                }
            }
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Unable to add non-existing Mvx order lines.", e);
        }
    }

    private Comparator<String> getOrderLineIDComparator() {
        return new Comparator<String>() {
            public int compare(String key1, String key2) {
                if (key1.equals(key2))
                    return 0;
                else {
                    String[] key1Tokens = key1.split("_");
                    String[] key2Tokens = key2.split("_");
                    if (!(key1Tokens.length == 3 && key2Tokens.length == 3))
                        throw new ClassCastException("Invalid format of OrderLineID. Key1 = " + key1 + "; Key2 = "
                                + key2);
                    int lineNumer1 = Integer.parseInt(key1Tokens[1]);
                    int lineSuffix1 = Integer.parseInt(key1Tokens[2]);
                    int lineNumer2 = Integer.parseInt(key2Tokens[1]);
                    int lineSuffix2 = Integer.parseInt(key2Tokens[2]);

                    if (lineNumer1 < lineNumer2)
                        return -1;
                    else if (lineNumer1 > lineNumer2)
                        return 1;
                    else {
                        if (lineSuffix1 < lineSuffix2)
                            return -1;
                        else if (lineSuffix1 > lineSuffix2)
                            return 1;
                        else
                            return 0;
                    }
                }
            }
        };
    }    

    private void updateOrderLineAttributes(XMLIterator lineIter, Map mvxLine) throws PipelineRuntimeException {
        updRsAttr(lineIter, ConstantsForSales.ITEMID, mvxLine, ConstantsForSales.ITNO, ConstantsForSales.ITNO);
        updRsAttr(lineIter, ConstantsForSales.ITEMNAME, mvxLine, ConstantsForSales.ITDS, ConstantsForSales.ITDS);
        updRsAttr(lineIter, ConstantsForSales.MVXWAREHOUSE, mvxLine, ConstantsForSales.WHLO, " ");
        updRsAttr(lineIter, ConstantsForSales.ORDERLINEHISTATUSID, mvxLine, ConstantsForSales.ORST, null);
        updRsAttr(lineIter, ConstantsForSales.ORDERLINESTATUSID, mvxLine, ConstantsForSales.ORST, " ");
        updRsAttr(lineIter, ConstantsForSales.UNITCODE, mvxLine, ConstantsForSales.SPUN, null);
        updRsAttr(lineIter, ConstantsForSales.QUANTITY, mvxLine, ConstantsForSales.ORQT, "0");
        updRsAttr(lineIter, ConstantsForSales.RESELLPRICE, mvxLine, ConstantsForSales.SAPR, "0");

        updLineDiscount(lineIter, ConstantsForSales.LINEDISCOUNT, mvxLine);
        updDeliveredQuantity(lineIter, ConstantsForSales.DELIVEREDQUANTITY, mvxLine);
        updRemainingQuantity(lineIter, ConstantsForSales.REMAININGQUANTITY, mvxLine);
        updItemUnit(lineIter, ConstantsForSales.UNIT, mvxLine);

        updRsAttr(lineIter, ConstantsForSales.REQUESTEDDELIVERYDATE, SubmitOrderToMovex
                .movexDateToXMLDate((String) mvxLine.get(ConstantsForSales.DWDT)));
        updRsAttr(lineIter, ConstantsForSales.CONFIRMED_DELIVERY_DATE, SubmitOrderToMovex
                .movexDateToXMLDate((String) mvxLine.get(ConstantsForSales.CODT)));

        // updRsAttr(lineIter, "DemandOrderNumber", mvxLine,
        // ConstantsForSales.DRDN, "");
        updRsAttr(lineIter, "DemandOrderLine", mvxLine, ConstantsForSales.DRDL, "");
        
        // copy CustomerItemID from M3
        updRsAttr(lineIter, ConstantsForSales.CUSTOMERITEMID, mvxLine, ConstantsForSales.POPN, null);
    }

    private void mergeCurrentOrdersDetails(XMLIterator lineIter, final Parameters params)
            throws PipelineRuntimeException {
        try {
            Map<String, Map> currentOrderLineMap = getCurrentOrderLinesAsMap(params);
            if (!currentOrderLineMap.isEmpty()) {
                lineIter.beforeFirst();
                while (lineIter.moveNext()) {
                    // for parent order line only
                    if (lineIter.getint(ConstantsForSales.LINESUFFIX) == 0) {
                        String demandOrderLineID = lineIter.getString("DemandOrderLine");
                        if (demandOrderLineID != null && !"".equals(demandOrderLineID)) {
                            demandOrderLineID = String.valueOf(Integer.parseInt(demandOrderLineID));
                            if (currentOrderLineMap.containsKey(demandOrderLineID)) {
                                Map currentLine = currentOrderLineMap.get(demandOrderLineID);
                                Iterator it = currentLine.keySet().iterator();
                                while (it.hasNext()) {
                                    String name = (String) it.next();
                                    String value = (String) currentLine.get(name);
                                    updRsAttr(lineIter, name, value);
                                }
                            }
                        }
                    }
                }
            }
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Unable to merge current order line detials", e);
        }

    }

    private Map<String, Map> getCurrentOrderLinesAsMap(final Parameters params) throws PipelineRuntimeException {
        Map<String, Map> currentOrderLineMap = new HashMap<String, Map>();
        try {
            String currentOrderID = params.getString(ConstantsForSales.CURRENT_ORDERID_PARAM);

            SearchPipelineExecuter pipeline = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                    "CurrentOrder", "LineDetails");
            pipeline.setParam("@LanguageCode", _languageCodeParam);
            pipeline.setParam("orderID", currentOrderID);
            pipeline.setParam("orderStatusID", "tmp");
            pipeline.setParam("restrict", "true");
            XMLResultset currentOrder = pipeline.execute();

            if (currentOrder != null && !currentOrder.isEmpty()) {
                currentOrder.moveFirst();
                XMLIterator currentOrderLines = (XMLIterator) currentOrder.getResultset(ConstantsForSales.ORDERLINE);
                if (currentOrderLines != null && !currentOrderLines.isEmpty()) {
                    currentOrderLines.beforeFirst();

                    Set<String> excludedAttributes = new HashSet<String>();
                    excludedAttributes.add(ConstantsForSales.ORDERLINEID);
                    excludedAttributes.add(ConstantsForSales.COMMENT);
                    excludedAttributes.add(ConstantsForSales.ITEMID);
                    excludedAttributes.add(ConstantsForSales.ITEMNAME);
                    excludedAttributes.add(ConstantsForSales.QUANTITY);
                    excludedAttributes.add(ConstantsForSales.REQUESTEDDELIVERYDATE);
                    excludedAttributes.add(ConstantsForSales.UNITCODE);
                    // TODO: Add more attributes in the set if needed.

                    while (currentOrderLines.moveNext()) {
                        String orderLineID = currentOrderLines.getString(ConstantsForSales.ORDERLINEID);
                        Map<String, String> line = new HashMap<String, String>();
                        List attribNames = currentOrderLines.getNames();
                        Iterator it = attribNames.iterator();
                        while (it.hasNext()) {
                            String name = (String) it.next();
                            if (excludedAttributes.contains(name))
                                ; // Ignore this attributes
                            else if (ConstantsForSales.SHIPPINGCOUNTRYNAME.equals(name))
                                line.put(ConstantsForSales.SHIPPINGCOUNTRY, currentOrderLines.getString(name));
                            else
                                line.put(name, currentOrderLines.getString(name));
                        }
                        currentOrderLineMap.put(orderLineID, line);
                    }
                }
            }
        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Unable to get current order lines.", e);
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Unable to get current order lines.", e);
        }
        return currentOrderLineMap;
    }

    /**
     * Update the item unit base on the unitCode provided by M3
     * 
     * @param lineIter
     *            XMLIterator pointing on line to handle
     * @param attrName
     *            Name of attribute to update
     * @param mvxLine
     *            Movex API resultset map
     */
    private void updItemUnit(final XMLIterator lineIter, final String attrName, final Map mvxLine)
            throws PipelineRuntimeException {
        if (_itemUnitCodes == null)
            _itemUnitCodes = getItemUnitCodes();
        if (_itemUnitCodes.containsKey(mvxLine.get(ConstantsForSales.SPUN))) {
            String itemUnit = _itemUnitCodes.get((String) mvxLine.get(ConstantsForSales.SPUN));
            updRsAttr(lineIter, attrName, itemUnit);
        }
    }
    
    private Map<String, String> getItemUnitCodes() throws PipelineRuntimeException {
        Map<String, String> codes = new HashMap<String, String>();
        SearchPipelineExecuter pipeline = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "Code",
                "Lookup");
        pipeline.setParam("@LanguageCode", _languageCodeParam);
        pipeline.setParam("codeType", "ItemUnit");
        XMLResultset rsCodes = pipeline.execute();

        try {
            if (rsCodes != null && !rsCodes.isEmpty()) {
                rsCodes.beforeFirst();
                while (rsCodes.moveNext()) {
                    codes.put(rsCodes.getString(ConstantsForSales.CODE_ATTRIBUTE), rsCodes
                            .getString(ConstantsForSales.TEXT_ATTRIBUTE));
                }
            }
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Unable to fetch item unit codes", e);
        }

        return codes;
    }

    /**
     * Calculate and update the resell price in an order line.
     * 
     * @param lineIter
     *            XMLIterator pointing on line to handle
     * @param attrName
     *            Name of attribute to update
     * @param mvxLine
     *            Movex API resultset map
     */
    private void updResellPrice(final XMLIterator lineIter, final String attrName, final Map mvxLine) {

        // TODO: Reevaluate formula on deriving the correct value of resell
        // price (if needed).
        BigDecimal mvxQty = getParameterAsDecimal(ConstantsForSales.ORQT, mvxLine);
        BigDecimal resellPrice = getParameterAsDecimal(ConstantsForSales.SAPR, mvxLine);
        // resellPrice = resellPrice * mvxQty / qty;
        resellPrice = resellPrice.multiply(mvxQty);
        updRsAttr(lineIter, attrName, resellPrice.toString());
    }

    /**
     * Update the delivered quantity based on the delivered quantity plus the
     * invoiced quantity as described in the mapping document
     * 
     * @param lineIter
     *            XMLIterator pointing on line to handle
     * @param attrName
     *            Name of attribute to update
     * @param mvxLine
     *            Movex API resultset map
     */
    private void updDeliveredQuantity(final XMLIterator lineIter, final String attrName, final Map mvxLine) {
        BigDecimal invoicedQty = getParameterAsDecimal(ConstantsForSales.IVQT, mvxLine);
        BigDecimal deliveredQty = getParameterAsDecimal(ConstantsForSales.DLQT, mvxLine);
        BigDecimal totalDelivQuantity = getParamAsDecimal(ConstantsForSales.DELIVEREDQUANTITY, lineIter);
        // totalDelivQuantity = invoicedQty + deliveredQty;
        totalDelivQuantity = invoicedQty.add(deliveredQty);
        updRsAttr(lineIter, attrName, totalDelivQuantity.toString());
    }

    /**
     * Update the remaining quantity based on the order quantity less the
     * delivered quantity
     * 
     * @param lineIter
     *            XMLIterator pointing on line to handle
     * @param attrName
     *            Name of attribute to update
     * @param mvxLine
     *            Movex API resultset map
     */
    private void updRemainingQuantity(final XMLIterator lineIter, final String attrName, final Map mvxLine) {
        BigDecimal orderQty = getParamAsDecimal(ConstantsForSales.QUANTITY, lineIter);
        BigDecimal deliveredQty = getParamAsDecimal(ConstantsForSales.DELIVEREDQUANTITY, lineIter);
        BigDecimal remainingQuantity = getParamAsDecimal(ConstantsForSales.REMAININGQUANTITY, lineIter);
        // remainingQuantity = orderQty - deliveredQty;
        remainingQuantity = orderQty.subtract(deliveredQty);
        updRsAttr(lineIter, attrName, remainingQuantity.toString());
    }

    /**
     * Convert attribute to a decimal.
     * 
     * @param rsPar
     *            Name on attribute to get
     * @param lineIter
     *            XMLIterator pointing on record with attribute to get
     * @return attribute value as decimal - 0.0000 in case of conversion error
     */
    private BigDecimal getParamAsDecimal(final String rsPar, final XMLIterator lineIter) {

        try {
            return lineIter.getDecimal(rsPar);
        } catch (ResultsetException e) {
            return new BigDecimal("0.0000");
        }
    }

    /**
     * Calculate on update discount for an order line.
     * 
     * @param lineIter
     *            XMLIterator pointing on record with attribute to get
     * @param rsPar
     *            Name on parameter to update (not used)
     * @param mvxLine
     *            Movex API resultset map
     */
    private void updLineDiscount(final XMLIterator lineIter, final String rsPar, final Map mvxLine) {

        BigDecimal lineDiscount = getParameterAsDecimal(ConstantsForSales.DIA1, mvxLine);
        lineDiscount = lineDiscount.add(getParameterAsDecimal(ConstantsForSales.DIA2, mvxLine));
        lineDiscount = lineDiscount.add(getParameterAsDecimal(ConstantsForSales.DIA3, mvxLine));
        lineDiscount = lineDiscount.add(getParameterAsDecimal(ConstantsForSales.DIA4, mvxLine));
        lineDiscount = lineDiscount.add(getParameterAsDecimal(ConstantsForSales.DIA5, mvxLine));
        lineDiscount = lineDiscount.add(getParameterAsDecimal(ConstantsForSales.DIA6, mvxLine));
        BigDecimal lineTotal = getParameterAsDecimal(ConstantsForSales.NLAM, mvxLine);

        // LinePrice = LineTotal + LineDiscount
        BigDecimal linePrice = lineTotal.add(lineDiscount);
        updRsAttr(lineIter, ConstantsForSales.LINEPRICE, Decimal.toString(linePrice));
        updRsAttr(lineIter, ConstantsForSales.LINETOTAL, Decimal.toString(lineTotal));

        if (linePrice.compareTo(Decimal.ZERO) != 0) {
            // LineDisPercent = 100 * LineDiscount / LinePrice
            BigDecimal percent = Decimal.divide(Decimal.ONEHUNDRED.multiply(lineDiscount), linePrice);
            updRsAttr(lineIter, ConstantsForSales.LINEDISPERCENT, Decimal.toString(percent));
        }
    }

    /**
     * Get field value from Movex API resultset map as double.
     * 
     * @param apiPar
     *            Name on field to get double for
     * @param mvxLine
     *            Movex API resultset map
     * @return Field value as double - 0.0 if not found or error
     */
    private BigDecimal getParameterAsDecimal(final String apiPar, final Map mvxLine) {
        String val = (String) mvxLine.get(apiPar);
        if (val != null) {
            try {
                return new BigDecimal(val);
            } catch (NumberFormatException e) {
                return new BigDecimal("0.0000");
            }
        }
        return new BigDecimal("0.0000");
    }

    /**
     * <p>
     * Gets M3 result parameter value as decimal.
     * </p>
     * 
     * @param parameters
     *            the parameters to fetch a decimal value from
     * @param paramName
     *            the name of the parameter holding the decimal value
     * @return parameter value (decimal)
     * @throws PipelineRuntimeException -
     *             if failed to obtain parameter from Parameters or if parameter
     *             does not exist.
     */
    private static BigDecimal getParamAsDecimal(final IMovexApiResultset result, final String paramName) {
        String strValue = result.getParamAsString(paramName);
        if (strValue == null) {
            return null;
        }

        BigDecimal value;
        try {
            // TODO set scale
            value = new BigDecimal(strValue);
        } catch (NumberFormatException e) {
            return Decimal.ZERO;
        }
        return value;
    }

    /**
     * Update attribute in resultset with a value from a Movex API resultset.
     * <p>
     * Uses current position in both resultsets.<br>
     * If the field is not there the default value is used.
     * 
     * @param lineIter
     *            XMLIterator pointing on line to handle
     * @param rsPar
     *            Name on parameter to update
     * @param mvxLine
     *            Movex API resultset map
     * @param apiPar
     *            name on field in Movex API resultset
     * @param defaultVal
     *            default value to use if field is missing
     */
    private void updRsAttr(final XMLIterator lineIter, final String rsPar, final Map mvxLine, final String apiPar,
            final String defaultVal) {

        String value = (String) mvxLine.get(apiPar);
        if (value == null) {
            value = defaultVal;
        }
        updRsAttr(lineIter, rsPar, value);
    }

    /**
     * Update attribute in resultset with a given value.
     * <p>
     * Uses current position in resultset.
     * 
     * @param rs
     *            XMLIterator pointing on record to handle
     * @param rsPar
     *            Name on attribute to update
     * @param value
     *            value to update the resultset with
     * @return the new value as returned
     */
    private String updRsAttr(final XMLIterator rs, final String rsPar, final String value) {

        return CustomStagesHelper.updateRsAttribute(rs, rsPar, value);
    }

    /**
     * Update attribute in resultset with a given value.
     * <p>
     * Uses current position in resultset.
     * 
     * @param rs
     *            XMLResultset pointing on record to handle
     * @param rsPar
     *            Name on attribute to update
     * @param value
     *            value to update the resultset with
     * @return the new value as returned
     */
    private String updRsAttr(final XMLResultset rs, final String rsPar, final String value) {

        return CustomStagesHelper.updateRsAttribute(rs, rsPar, value);
    }

    /**
     * Update the record with shipping address information from Movex.
     * <p>
     * Calls Movex API OIS100MI/GetAddress.
     * 
     * @param context
     *            pipeline context
     * @param parms
     *            parameter block from context
     * @param con
     *            Movex connection to use
     * @return false if the call to Movex failed, otherwise true
     * @throws PipelineRuntimeException
     */
    private boolean mergeShippingAddress(final PipelineContext context, final Parameters parms,
            final IMovexConnection con, final String orderID) throws PipelineRuntimeException {

        XMLResultset order = (XMLResultset) context.getResponse();

        // get CONO, ORNO for a Movex call using OIS100MI:GetAddress
        Map address = new HashMap();
        address.put(IMovexConnection.TRANSACTION, ConstantsForSales.GET_ADDRESS);
        address.put(ConstantsForSales.CONO, getString(ConstantsForSales.MVXCOMPANY, order));
        // Use order ID from parameter or form header in response to merge.
        address.put(ConstantsForSales.ORNO, (orderID != null) ? orderID : getString(ConstantsForSales.ORDERID, order));

        // Address type: Delivery address
        address.put(ConstantsForSales.ADRT, "1");

        // retrieve address data from Movex
        IMovexApiResultset apiRes = CustomStagesHelper.callMovex(context, con, address, ConstantsForSales.MVXSTATUS);
        if ((apiRes == null) || (!con.isOk())) {
            return false;
        }

        // Update address. If parameter does not exist or is empty, and empty
        // string is used.
        final String defaultVal = "";

        // Handle country - get the proper name as it not filled correctly in
        // the previous search stage
        String countryID = apiRes.getParamAsString(ConstantsForSales.CSCD);
        if (!"".equals(countryID.trim())) {
            String country = getCountryName(countryID);
            CustomStagesHelper.updateRsAttribute(order, ConstantsForSales.SHIPPINGCOUNTRY, country);
            CustomStagesHelper.updateRsAttribute(order, ConstantsForSales.SHIPPINGCOUNTRYID, countryID);
        } else {
            CustomStagesHelper.updateRsAttribute(order, ConstantsForSales.SHIPPINGCOUNTRY, defaultVal);
        }

        updRsAttr(order, ConstantsForSales.SHIPPINGCOMPANY, apiRes, ConstantsForSales.CUNM, defaultVal);
        updRsAttr(order, ConstantsForSales.SHIPPINGADDRESS1, apiRes, ConstantsForSales.CUA1, defaultVal);
        updRsAttr(order, ConstantsForSales.SHIPPINGADDRESS2, apiRes, ConstantsForSales.CUA2, defaultVal);
        updRsAttr(order, ConstantsForSales.SHIPPINGADDRESS3, apiRes, ConstantsForSales.CUA3, defaultVal);
        updRsAttr(order, ConstantsForSales.SHIPPINGADDRESS4, apiRes, ConstantsForSales.CUA4, defaultVal);
        // Map city attribute (should be CUA3, CUA4, TOWN, or empty).
        String mapCityTo = CustomStagesHelper.getKeyValue(ConstantsForSales.MAP_CITY_TO);
        updRsAttr(order, ConstantsForSales.SHIPPINGCITY, apiRes, mapCityTo, defaultVal);
        updRsAttr(order, ConstantsForSales.SHIPPINGZIP, apiRes, ConstantsForSales.PONO, defaultVal);

        return true;
    }

    /**
     * Calculate and update the header totals (total prices for the order).
     * 
     * @param order
     *            resultset with the order.
     * @param apiRes
     *            Movex API resultset as returned from GetOrderValue.
     * @param defaultVal
     *            default value to use
     */
    private void updateHeaderTotals(final XMLResultset order, final IMovexApiResultset apiRes, final String defaultVal) {

        BigDecimal grandTotalHeader = getParamAsDecimal(apiRes, ConstantsForSales.TOPY);
        BigDecimal grandTotalInvoice = getParamAsDecimal(apiRes, ConstantsForSales.ITOP);
        updRsAttr(order, ConstantsForSales.GRANDTOTAL, Decimal.toString(grandTotalHeader.add(grandTotalInvoice)));

        BigDecimal roundingOffHeader = getParamAsDecimal(apiRes, ConstantsForSales.ROAM);
        BigDecimal roundingOffInvoice = getParamAsDecimal(apiRes, ConstantsForSales.IROA);
        updRsAttr(order, ConstantsForSales.ROUNDINGOFF, Decimal.toString(roundingOffHeader.add(roundingOffInvoice)));
        /*
         * 6787 Service Charge fix BigDecimal totalShipHeader =
         * getParamAsDecimal(apiRes, ConstantsForSales.EFAM); BigDecimal
         * totalShipInvoice = getParamAsDecimal(apiRes, ConstantsForSales.IFAM);
         * updRsAttr(order, ConstantsForSales.TOTALSHIP,
         * Decimal.toString(totalShipHeader.add(totalShipInvoice))); BigDecimal
         * totalDeliveryFeeHeader = getParamAsDecimal(apiRes,
         * ConstantsForSales.EXAM); BigDecimal totalDeliveryFeeInvoice =
         * getParamAsDecimal(apiRes, ConstantsForSales.IXAM); updRsAttr(order,
         * ConstantsForSales.TOTALDELIVERYFEE,
         * Decimal.toString(totalDeliveryFeeHeader.add(totalDeliveryFeeInvoice)));
         */

        BigDecimal totalTaxHeader = getParamAsDecimal(apiRes, ConstantsForSales.VTAM);
        BigDecimal totalTaxInvoice = getParamAsDecimal(apiRes, ConstantsForSales.IVTA);
        updRsAttr(order, ConstantsForSales.TOTALTAX, Decimal.toString(totalTaxHeader.add(totalTaxInvoice)));

        BigDecimal orderHeaderDiscountHeader = getParamAsDecimal(apiRes, ConstantsForSales.ODAM);
        BigDecimal orderHeaderDiscountInvoice = getParamAsDecimal(apiRes, ConstantsForSales.IDAM);
        updRsAttr(order, ConstantsForSales.ORDERHEADERDISCOUNT, Decimal.toString(orderHeaderDiscountHeader
                .add(orderHeaderDiscountInvoice)));

        /*
         * updRsAttr(order, ConstantsForSales.GRANDTOTAL, apiRes,
         * ConstantsForSales.TOPY, defaultVal); updRsAttr(order,
         * ConstantsForSales.ROUNDINGOFF, apiRes, ConstantsForSales.ROAM,
         * defaultVal); updRsAttr(order, ConstantsForSales.TOTALSHIP, apiRes,
         * ConstantsForSales.EFAM, defaultVal); updRsAttr(order,
         * ConstantsForSales.TOTALDELIVERYFEE, apiRes, ConstantsForSales.EXAM,
         * defaultVal); updRsAttr(order, ConstantsForSales.TOTALTAX, apiRes,
         * ConstantsForSales.VTAM, defaultVal); updRsAttr(order,
         * ConstantsForSales.ORDERHEADERDISCOUNT, apiRes,
         * ConstantsForSales.ODAM, defaultVal);
         */

        // BigDecimal orderNet = getParamAsDecimal(apiRes,
        // ConstantsForSales.ONET);
        BigDecimal orderNetHeader = getParamAsDecimal(apiRes, ConstantsForSales.ONET);
        BigDecimal orderNetInvoice = getParamAsDecimal(apiRes, ConstantsForSales.INET);
        // Get the order net total
        BigDecimal totalOrderNet = orderNetHeader.add(orderNetInvoice);

        BigDecimal totalPriceHeader = getParamAsDecimal(apiRes, ConstantsForSales.BRAM);
        BigDecimal totalPriceInvoice = getParamAsDecimal(apiRes, ConstantsForSales.IRAM);
        updRsAttr(order, ConstantsForSales.TOTALPRICE, Decimal.toString(totalPriceHeader.add(totalPriceInvoice)));
        // String fieldBRAM = updRsAttr(order, ConstantsForSales.TOTALPRICE,
        // apiRes, ConstantsForSales.BRAM, defaultVal);
        // Get the gross order total
        BigDecimal totalPrice = totalPriceHeader.add(totalPriceInvoice);

        /*
         * if ((fieldBRAM != null) && !"".equals(fieldBRAM)) { totalPrice = new
         * BigDecimal(fieldBRAM); } else { totalPrice = Decimal.ZERO; }
         */

        // Get the total discount
        BigDecimal totalDiscount = totalPrice.subtract(totalOrderNet);
        updRsAttr(order, ConstantsForSales.TOTALDISCOUNT, Decimal.toString(totalDiscount));

        if (LOG.isDebugEnabled()) {
            FastStringBuffer msg = new FastStringBuffer("Values fetched from GetOrderValue:\n");
            msg.append("GRANDTOTAL: " + grandTotalHeader + " " + grandTotalInvoice + "\n");
            msg.append("ROUNDINGOFF: " + roundingOffHeader + " " + roundingOffInvoice + "\n");
            msg.append("TOTALTAX: " + totalTaxHeader + " " + totalTaxInvoice + "\n");
            msg.append("ORDERHEADERDISCOUNT: " + orderHeaderDiscountHeader + " " + orderHeaderDiscountInvoice + "\n");
            msg.append("TOTALPRICE: " + totalPriceHeader + " " + totalPriceInvoice + "\n");
            msg.append("OrderNet: " + orderNetHeader + " " + orderNetInvoice + "\n");
            msg.append("TOTALDISCOUNT:*** " + totalDiscount + " ***\n");
            LOG.debug(msg.toString());
        }

    }

    /**
     * Calculate and update the header totals (total prices for the order).
     * 
     * @param order
     *            resultset with the order.
     * @param apiRes
     *            Movex API resultset as returned from GetHead.
     * @param defaultVal
     *            default value to use
     */
    private void updateHeaderCharges(final XMLResultset order, final IMovexApiResultset apiRes, final String defaultVal) {

        BigDecimal totalShipHeader = getParamAsDecimal(apiRes, ConstantsForSales.EFAM);
        updRsAttr(order, ConstantsForSales.TOTALSHIP, Decimal.toString(totalShipHeader));

        BigDecimal totalDeliveryFeeHeader = getParamAsDecimal(apiRes, ConstantsForSales.EXAM);
        updRsAttr(order, ConstantsForSales.TOTALDELIVERYFEE, Decimal.toString(totalDeliveryFeeHeader));

        /* 6787 Service Charge fix */

        String totalChargeDesc = apiRes.getParamAsString(ConstantsForSales.EXTX);
        updRsAttr(order, ConstantsForSales.TOTALCHARGEDESC, totalChargeDesc);

        if (LOG.isDebugEnabled()) {
            FastStringBuffer msg = new FastStringBuffer("Values fetched from GetOrderValue:\n");
            msg.append("TOTALSHIP: " + totalShipHeader + "\n");
            msg.append("TOTALDELIVERYFEE: " + totalDeliveryFeeHeader + "\n");
            msg.append("TOTALCHARGEDESC: " + totalChargeDesc + "\n");
            LOG.debug(msg.toString());
        }

    }

    /**
     * Get country name for given country ID.
     * 
     * @param country
     *            ID
     * @return country name
     */
    private String getCountryName(final String countryID) {
        String country = null;
        // TODO Get proper country name
        return country;
    }
}
