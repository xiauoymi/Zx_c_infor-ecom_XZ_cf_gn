package com.intentia.iec.pipeline.runtime.stage.custom.search.rowhandler;

import static com.intentia.iec.pipeline.runtime.stage.custom.search.IndexerUtils.addIndexedField;
import static com.intentia.iec.pipeline.runtime.stage.custom.search.IndexerUtils.addTokenizedField;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.lucene.document.Document;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Strings;

/**
 * Adds the names and descriptions to the index. This is used for quicksearch.
 *
 */
public class NamesAndDescriptionsRowHandler implements Jdbc.RowHandler {
    private Document doc = null;

    private String itemNumber = null;

    public NamesAndDescriptionsRowHandler(Document doc, String itemNumber) {
        this.doc = doc;
        this.itemNumber = itemNumber;
    }

    public void processRow(ResultSet rs) throws SQLException, PipelineRuntimeException {
        StringBuilder fulltext = new StringBuilder(100);
        fulltext.append(this.itemNumber);
        String languageCode = rs.getString(Strings.Database.Indexing.Item.NamesAndDescriptions.languageCode);
        String name = rs.getString(Strings.Database.Indexing.Item.NamesAndDescriptions.name);
        String description = rs.getString(Strings.Database.Indexing.Item.NamesAndDescriptions.description);

        if (name != null) {
            addIndexedField(doc, Strings.Index.Item.namePrefix + languageCode, name);
            addTokenizedField(doc, Strings.Index.Item.nameTokenizedPrefix + languageCode, name);
            fulltext.append(' ').append(name);
        }

        if (description != null) {
            addTokenizedField(doc, Strings.Index.Item.descriptionPrefix + languageCode, description);
            fulltext.append(' ').append(description);
        }
        addTokenizedField(doc, Strings.Index.Item.fullTextPrefix + languageCode, fulltext.toString());
    }
}
