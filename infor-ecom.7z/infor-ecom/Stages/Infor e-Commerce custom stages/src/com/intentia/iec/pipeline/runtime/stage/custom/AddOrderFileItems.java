package com.intentia.iec.pipeline.runtime.stage.custom;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

public class AddOrderFileItems implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(AddOrderFileItems.class);

    private Parameters parameters = null;

    private static final String ORDERFILEITEMLIST_FILEID_ATTRIB = "FileID";

    private static final String ORDERFILEITEMS_STANDARD_ITEMID_ATTRIB = "StandardItemID";

    private static final String ORDERFILEITEMS_ITEMID_ATTRIB = "ItemID";

    private static final String ORDERFILEITEMS_VAlID_QUANTITY_ATTRIB = "ValidQuantity";

    private static final String ORDERFILEITEMS_IS_CID_ATTRIB = "IsCID";

    private static final String FILE_ID_PARAM = "FileID";

    private static final String ORDER_ID_PARAM = "orderID";

    private static final String INCLUDE_INVALID_ENTRIES_PARAM = "includeInvalidEntries";

    private static final String INCLUDE_AMBIGUOUS_ENTRIES_PARAM = "includeAmbiguousEntries";

    private static final String INCLUDE_NULL_STAUS_PARAM = "includeNullStatus";

    private static final String ADD_TO_CART_ONLY_PARAM = "addToCartOnly";

    private static final String USER_GROUP_ID_PARAM = "@UserGroupID";

    private static final String CID_ENABLED_PARAM = "CIDEnabled";

    private static final String LANGUAGE_CODE_PARAM = "LanguageCode";

    private int fileID = 0;

    private String isCIDEnabled = null;

    public void execute(PipelineContext context) throws PipelineRuntimeException {

        // Retreive XML request from context
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
        Document xmlDoc;
        XMLRequest xmlRequest;

        try {
            CustomStagesHelper.extractRequestParameters(CustomStagesHelper.getRequest(context));
            xmlRequest = (XMLRequest) context.getRequest();

            parameters = xmlRequest.getParameters();

            // Fetch request parameters
            fileID = parameters.getint(FILE_ID_PARAM);
            isCIDEnabled = parameters.getString(CID_ENABLED_PARAM);

            xmlDoc = xmlRequest.getRequestDoc();

            XMLRequestHelper xmlHelper = new XMLRequestHelper(xmlDoc);

            XMLResultset orderFileItems = getOrderFileitems(fileID);

            xmlHelper.addEntity();

            Node entity = XPathAPI.selectSingleNode(xmlDoc, "request/entities/entity");

            if (xmlHelper.getKey(entity) == null)
                xmlHelper.setKey(entity, parameters.getString(ORDER_ID_PARAM));

            LOG.debug("OrderFileItems Count: " + orderFileItems.rowCount());

            for (int i = 0; i < orderFileItems.rowCount(); ++i) {
                xmlHelper.addSubset(entity, "OrderLine");
            }

            NodeList nodeList2 = XPathAPI.selectNodeList(xmlDoc,
                    "request/entities/entity/subsets/subset[@name=\"OrderLine\"]");

            orderFileItems.beforeFirst();

            String isCID = null;

            for (int i = 0; i < nodeList2.getLength() && orderFileItems.moveNext(); i++) {
                Node node = nodeList2.item(i);
                xmlHelper.setAttribute(node, "ItemID", orderFileItems.getString(ORDERFILEITEMS_STANDARD_ITEMID_ATTRIB));
                xmlHelper
                        .setAttribute(node, "Quantity", orderFileItems.getString(ORDERFILEITEMS_VAlID_QUANTITY_ATTRIB));

                if ("Y".equals(isCIDEnabled)) {
                    isCID = orderFileItems.getString(ORDERFILEITEMS_IS_CID_ATTRIB);
                    xmlHelper.setAttribute(node, "UseCID", isCID);
                    if ("Y".equals(isCID))
                        xmlHelper.setAttribute(node, "CustomerItemID", orderFileItems
                                .getString(ORDERFILEITEMS_ITEMID_ATTRIB));
                }
            }

            xmlHelper.logRequest();

        } catch (Exception e) {
            throw new PipelineRuntimeException("Failed to obtain XML request document from request", e);
        }

    }

    // Save the process file to response
    private XMLResultset getOrderFileitems(int pFileID) throws PipelineRuntimeException {
        try {
            SearchPipelineExecuter seOrderItems = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                    "OrderFileItem", "List");

            seOrderItems.setParam(ORDERFILEITEMLIST_FILEID_ATTRIB, String.valueOf(pFileID));
            seOrderItems.setParam(LANGUAGE_CODE_PARAM, parameters.getString(LANGUAGE_CODE_PARAM));
            seOrderItems.setParam(ADD_TO_CART_ONLY_PARAM, "Y");
            seOrderItems.setParam(INCLUDE_INVALID_ENTRIES_PARAM, "N");
            seOrderItems.setParam(INCLUDE_AMBIGUOUS_ENTRIES_PARAM, "N");
            seOrderItems.setParam(INCLUDE_NULL_STAUS_PARAM, "N");
            seOrderItems.setParam(USER_GROUP_ID_PARAM, parameters.getString(USER_GROUP_ID_PARAM));
            seOrderItems.setParam(CID_ENABLED_PARAM, isCIDEnabled);

            XMLResultset rs = seOrderItems.execute();

            LOG.debug("OrderFileItem_List returns " + rs.rowCount() + " number of Order File Items.");

            return rs;

        } catch (Exception e) {
            throw new PipelineRuntimeException("Failed to get Order File Items", e);
        }
    }

}
