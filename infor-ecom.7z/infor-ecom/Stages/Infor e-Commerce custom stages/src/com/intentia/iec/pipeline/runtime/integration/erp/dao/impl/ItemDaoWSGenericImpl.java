package com.intentia.iec.pipeline.runtime.integration.erp.dao.impl;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Service;
import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.PortInfo;

import com.infor.iec.ion.webservice.itemprice.CatalogPriceResponseParams;
import com.infor.iec.ion.webservice.itemprice.InputCatalogItems;
import com.infor.iec.ion.webservice.itemprice.ItemPrices;
import com.infor.iec.ion.webservice.itemprice.OutputCatalogItems;
import com.infor.iec.ion.webservice.itemprice.CatalogPriceRequestParams;

import com.infor.iec.ion.webservice.atp.ATPInfo;
import com.infor.iec.ion.webservice.atp.AvailableToPromiseService;
import com.infor.iec.ion.webservice.atp.OrderPromiseRequestParams;
import com.infor.iec.ion.webservice.atp.OrderPromiseResponseParams;

import com.intentia.iec.pipeline.runtime.integration.erp.dao.ItemDao;
import com.intentia.iec.pipeline.runtime.integration.erp.dao.factory.WebserviceDaoFactory;
import com.intentia.iec.pipeline.runtime.integration.erp.exception.ErpConnectionException;
import com.intentia.iec.pipeline.runtime.integration.erp.exception.ErpRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.erp.model.AvailabilityDetail;
import com.intentia.iec.pipeline.runtime.integration.erp.model.AvailabilityRequest;
import com.intentia.iec.pipeline.runtime.integration.erp.model.CatalogPrice;
import com.intentia.iec.pipeline.runtime.integration.erp.model.CatalogPriceRequest;
import com.intentia.iec.pipeline.runtime.integration.erp.model.ItemAvailability;
import com.intentia.iec.pipeline.runtime.integration.erp.model.Item;
import com.intentia.iec.pipeline.runtime.integration.erp.utils.ErpUtilHelper;
import com.intentia.iec.pipeline.runtime.integration.erp.utils.SOAPLoggingHandler;

public class ItemDaoWSGenericImpl implements ItemDao {


	private static final Logger LOG = Logger.getLogger(ItemDaoWSGenericImpl.class);


	public CatalogPrice getCatalogPrice(CatalogPriceRequest request) throws ErpRuntimeException, ErpConnectionException  {		
		ItemPrices itemPricePort;
		try {
			itemPricePort = getItemPricePort();
		} catch (MalformedURLException e) {
			throw new ErpConnectionException(e.toString());
		}
		CatalogPrice outCatalogPrice = new CatalogPrice();
		List<Item> lstItems = new ArrayList<Item>();

		CatalogPriceRequestParams wsRequest =  createCatalogPriceRequestParams(request);		

		//Invoke webservice method
		ErpUtilHelper.debugInCatalogPrice(wsRequest);
		//Set BindingProvider
		try {
			ErpUtilHelper.setBindingProvider((BindingProvider)itemPricePort, new URL(WebserviceDaoFactory.WSDL_ENDPOINT_ITEMPRICE));
		} catch(MalformedURLException e){
			throw new ErpConnectionException(e.toString()); 
		}
		CatalogPriceResponseParams wsResponse = itemPricePort.getCatalogPrice(wsRequest);
		ErpUtilHelper.debugOutCatalogPrice(wsResponse);

		if (wsResponse != null && wsResponse.getArrayOfOutputCatalogItems() !=null) {
			for(OutputCatalogItems wsoutCatalogItem : wsResponse.getArrayOfOutputCatalogItems()) {
				Item item = new Item();
				item.setItemId(wsoutCatalogItem.getItemID());
				item.setUnitCode(wsoutCatalogItem.getUnitCode());
				item.setUnitPriceAmount(wsoutCatalogItem.getUnitPriceAmount() != null ? wsoutCatalogItem.getUnitPriceAmount() : wsoutCatalogItem.getUnitBaseAmount() !=null ? wsoutCatalogItem.getUnitBaseAmount() : -1 );
				item.setWarehouseId(wsoutCatalogItem.getWarehouseLocationID());
				
				//Add to list of item
				lstItems.add(item);
			}
			outCatalogPrice.setItems(lstItems);
			if (wsResponse.getErrorReasonCode() != null && !wsResponse.getErrorReasonCode().trim().isEmpty()) {
				outCatalogPrice.setHasWSCallError(true);
				outCatalogPrice.setMsgCodeError(wsResponse.getErrorReasonCode());
				outCatalogPrice.setMsgError(wsResponse.getErrorReasonDescription());				
			} 
		} else {
			outCatalogPrice.setHasWSCallError(true);
			outCatalogPrice.setMsgCodeError("Code error null");
			outCatalogPrice.setMsgError("WSResponse is null");		
		}
		return outCatalogPrice;
	}



	public ItemAvailability getAvailability(AvailabilityRequest request) throws ErpRuntimeException,ErpConnectionException {
		AvailableToPromiseService atpPort;
		OrderPromiseResponseParams wsResponse;
		try {
			atpPort = getATPPort();
		} catch (MalformedURLException e) {
			throw new ErpConnectionException(e.toString());
		}
		ItemAvailability available = new ItemAvailability();
		OrderPromiseRequestParams wsRequest =  createOrderPromiseRequestParams(request);

		//Get response
		ErpUtilHelper.debugInOrderPromise(wsRequest);
		//Set BindingProvider
		try {
			ErpUtilHelper.setBindingProvider((BindingProvider)atpPort, new URL(WebserviceDaoFactory.WSDL_ENDPOINT_ATP));
			wsResponse = atpPort.getOrderPromise(wsRequest);
			
			if (wsResponse != null) {
				ErpUtilHelper.debugOutOrderPromise(wsResponse);
				if (!hasWsResponseError(wsResponse)) {
					List<ATPInfo> wsoutATPInfo = wsResponse.getArrayOfATPInfo();
					List<AvailabilityDetail> listAvailable =  new ArrayList<AvailabilityDetail>();
					for (ATPInfo info: wsoutATPInfo){
						AvailabilityDetail details = new AvailabilityDetail();
						try {
							//Convert from String to XMLGregorian to java.util.Date
							if (info.getATPDate() != null && !info.getATPDate().trim().isEmpty()){
								String tempDate = info.getATPDate();
								boolean hasTimeZone = tempDate.contains("T");
								String [] dateToken = tempDate.split("T");
								int dateFieldLength = dateToken.length;
								if(hasTimeZone && (dateFieldLength == 2)){
									String dateWOTimeZone = dateToken[0];
									details.setDate(ErpUtilHelper.toDate(DatatypeFactory.newInstance().newXMLGregorianCalendar(dateWOTimeZone)));
								} else {
									details.setDate(ErpUtilHelper.toDate(DatatypeFactory.newInstance().newXMLGregorianCalendar(info.getATPDate())));									
								}
							}
							details.setWarehouseId(info.getWarehouseLocationID());
							details.setQuantity(info.getATPQuantity());
							details.setUnitCode(info.getUnitCode());	
							listAvailable.add(details);
						} catch (DatatypeConfigurationException e) {
							LOG.error(e.toString());
						}
					}
					available.setDetails(listAvailable);
				} else {
					String errorReasonCode = "";
					String errorReasonDesc = "";
					if(wsResponse.getErrorReasonCode() != null && !wsResponse.getErrorReasonCode().trim().isEmpty()){
						errorReasonCode = wsResponse.getErrorReasonCode();
					}
					if(wsResponse.getErrorReasonDescription() != null && !wsResponse.getErrorReasonDescription().trim().isEmpty()){
						errorReasonDesc = wsResponse.getErrorReasonDescription();
					}
					throw new ErpRuntimeException(errorReasonCode,errorReasonDesc);
				}
			} else {
				throw new ErpRuntimeException("Gereric Code Here","Gereric Message Here");
			}

		} catch(MalformedURLException e){
			throw new ErpConnectionException(e.toString()); 
		} catch (Exception e){
			LOG.error(e.toString());
			if(e instanceof RuntimeException){
				throw new ErpRuntimeException(e.toString());
			} else {
				throw new ErpConnectionException(e.toString());
			}
		}

		return available;
	}

	/**
	 * Check for Error Code and/or Error Description
	 * If Error Code and/or Description are not empty, hasWsResponseError should be set to True 
	 * @param wsResponse
	 * @return
	 */
	private boolean hasWsResponseError(OrderPromiseResponseParams wsResponse){
		boolean hasWsResponseError = false;
		if (wsResponse.getErrorReasonCode() != null && !wsResponse.getErrorReasonCode().trim().isEmpty()) {
			hasWsResponseError = true;
		} else if (wsResponse.getErrorReasonDescription() != null && !wsResponse.getErrorReasonDescription().trim().isEmpty()){
			hasWsResponseError = true;
		}
		return hasWsResponseError;
	}
	
	private CatalogPriceRequestParams createCatalogPriceRequestParams(CatalogPriceRequest request){
		CatalogPriceRequestParams wsRequest =  new CatalogPriceRequestParams();
		wsRequest.setTenantID(request.getTenantId());
		wsRequest.setAccountingEntityID(request.getAccountingEntityId());
		wsRequest.setCurrencyID(request.getCurrencyId());
		wsRequest.setCustomerPartyID(request.getCustomerPartyId());
		wsRequest.setWarehouseLocationID(request.getWarehouseId());
		wsRequest.setPriceGroup(request.getPriceGroup());
		wsRequest.setUserName(WebserviceDaoFactory.WEBSERVICEUSERID);
		
		// Create array request parameter 
		List<InputCatalogItems> wsInputCatalogItems = wsRequest.getArrayOfInputCatalogItems();	

		for (Item item : request.getItems()) {
			InputCatalogItems wsInputCatalogItem = new InputCatalogItems();
			wsInputCatalogItem.setCustomerItemID(item.getCustomerItemID());
			wsInputCatalogItem.setItemID(item.getItemId());
			wsInputCatalogItem.setUnitCode(item.getUnitCode());
			wsInputCatalogItem.setShippingAddressID(item.getShippingId());
			wsInputCatalogItems.add(wsInputCatalogItem);
			
		}
		return wsRequest;		
	} 

	private OrderPromiseRequestParams createOrderPromiseRequestParams(AvailabilityRequest request){
		OrderPromiseRequestParams wsRequest =  new OrderPromiseRequestParams();
		wsRequest.setTenantID(request.getTenantId());
		wsRequest.setAccountingEntityID(request.getAccountingEntityId());
		wsRequest.setWarehouseLocationID(request.getWarehouseId());
		wsRequest.setItemID(request.getItemId());
		wsRequest.setCustomerItemID(request.getCustomerItemId());
		wsRequest.setQuantity(request.getQuantity());
		wsRequest.setUnitCode(request.getUnitCode());
		wsRequest.setUserName(WebserviceDaoFactory.WEBSERVICEUSERID);
		wsRequest.setShippingAddressID(request.getShippingAddressId());
		
		//Convert Date to XMLGregorianCalendar
		XMLGregorianCalendar calendar = ErpUtilHelper.toXMLGregorianCalendar(request.getRequiredDeliveryDate());
		wsRequest.setRequiredDeliveryDate(calendar);

		return wsRequest;
	}

	private ItemPrices getItemPricePort() throws MalformedURLException{
		//initialize ItemPriceService
		LOG.debug("ItemPrices initialize service: "+WebserviceDaoFactory.WSDL_URL_ITEMPRICE);
		URL url_wsdl = new URL(WebserviceDaoFactory.WSDL_URL_ITEMPRICE);
		Service service = Service.create(url_wsdl, new QName("http://infor.com", "ItemPricesService"));
		setSOAPLoggingHandler(service);
		ItemPrices itemPricePort =  service.getPort(ItemPrices.class);
		return itemPricePort;
	}

	private AvailableToPromiseService getATPPort() throws MalformedURLException{
		//initialize ATPService
		LOG.debug("ATP initialize service: "+WebserviceDaoFactory.WSDL_URL_ATP);
		URL url_wsdl = new URL(WebserviceDaoFactory.WSDL_URL_ATP);
		Service service = Service.create(url_wsdl, new QName("http://infor.com", "AvailableToPromiseService"));
		setSOAPLoggingHandler(service);
		AvailableToPromiseService atpPort =  service.getPort(AvailableToPromiseService.class);
		return atpPort;
	}

	private void setSOAPLoggingHandler(Service service){
		service.setHandlerResolver(new HandlerResolver(){
			@Override
			public List<Handler> getHandlerChain(PortInfo portInfo) {
				List<Handler> handlerChain = new ArrayList<Handler>();
				handlerChain.add(new SOAPLoggingHandler());
				return handlerChain;
			}

		});
	}

}
