package com.intentia.iec.pipeline.runtime.stage.custom.equipment.location;

/**
 * Represents the cartesian coordinate system latitude, longitude and height. 
 * This is the coordinate system supported by Google Map.
 *
 */
public class GeodeticCoordinate {
	private double latitude = 0;
	
	private double longitude = 0;
	
	private double height = 0;
	
	/**
	 * Constructor
	 * @param latitude
	 * @param longitude
	 * @param height
	 */
	public GeodeticCoordinate(double latitude, double longitude, double height) {
		this.latitude = latitude;
		this.longitude = longitude;
		this.height = height;
	}

	/**
	 * Returns the latitude
	 * @return
	 */
	public double getLatitude() {
		return latitude;
	}

	/**
	 * Sets the latitude
	 * @param latitude
	 */
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	/**
	 * Returns the longitude
	 * @return
	 */
	public double getLongitude() {
		return longitude;
	}

	/**
	 * Sets the longitude
	 * @param longitude
	 */
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	/**
	 * Returns the height
	 * @return
	 */
	public double getHeight() {
		return height;
	}

	/**
	 * Sets the height
	 * @param height
	 */
	public void setHeight(double height) {
		this.height = height;
	}
}
