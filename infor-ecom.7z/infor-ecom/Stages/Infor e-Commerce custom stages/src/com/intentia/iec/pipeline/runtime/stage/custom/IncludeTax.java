/*
 * Copyright 2004 by Intentia
 *
 * Created on 03-03-2004
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.Decimal;

/**
 * Calculates tax on the resultset.
 * <p>
 * Which attributes are to be calculated are defined as application properties
 * in the Design Center under the group <tt>IncludeTax</tt>. Each business
 * object that the stage is to be used upon must contain a definition of how the
 * tax calculation must be executed. Each attribute that must be calculated must
 * be defined as:
 * <p>
 * <tt>[Attribute](+|*)[Attribute1];</tt>
 * <p>
 * This implies that the returned value will be either
 * <tt>(Attribute + Attribute1)</tt> or
 * <tt>(Attribute + (Attribute * Attribute1))</tt>
 * <p>
 * The attributes must be separated by semi colons. An example of such a
 * parameter could be:
 * <p>
 * <code>ListPrice*ItemTax;ListPriceAltCurrency*ItemTax;ResellPrice*ItemTax</code>
 * <p>
 * The parameter <tt>executeIncludeTax</tt> must be set to the boolean value
 * <code>TRUE</code> if the stage is to execute the business logic. This
 * parameter could typically be set to <code>"A AND B"</code>, where
 * <code>A</code> is true if the current user has the feature element
 * <tt>"IncludeTax.IncludeTaxFeature"</tt> and <code>B</code> is true if the
 * session contains the attribute <tt>"IsTaxable"</tt> and the value is set to
 * <code>"Y"</code>.
 * <p>
 * <b>Required input in <code>PipelineContext</code>:</b><br>
 * The stage requires that the <code>PipelineContext</code> contains a
 * resultset on which the tax attributes are to be calculated.
 * <p>
 * <b>Generated output in <code>PipelineContext</code>:</b><br>
 * When done the stage has modified the resultset in the
 * <code>PipelineContext</code> to contain the calculated tax attributes.
 * </p>
 */

public class IncludeTax implements PipelineStage {

    public static final String EXECUTE_STAGE = "executeIncludeTax";

    public static final String BUSINESSOBJECT = "BUSINESSOBJECT";

    private static final Logger LOG = Logger.getLogger(IncludeTax.class);

    /**
     * This method executes the stage.
     * 
     * @see com.intentia.iec.pipeline.runtime.PipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
     */
    public void execute(PipelineContext context) throws PipelineRuntimeException {

        LOG.debug("Inside IncludeTax.execute()");

        // Retreive XML request from context
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
        XMLRequest xmlRequest = (XMLRequest) context.getRequest();

        // TODO. We do not get a boolean value when using getboolean... we temp
        // use a string
        // Only execute stage if parameter EXECUTE_STAGE is TRUE
        String executeStageString = null;
        try {
            XMLRequest.extractRequestParameters(xmlRequest);
        } catch (RequestException e) {
            throw new PipelineRuntimeException("Failed to extract parameters from request, " + e.getMessage(), e);
        }
        Parameters parameters = xmlRequest.getParameters();
        try {
            // executeStage = parameters.getboolean(IncludeTax.EXECUTE_STAGE);
            executeStageString = parameters.getString(IncludeTax.EXECUTE_STAGE);
        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Failed to obtain tax config parameter from request, " + e.getMessage(),
                    e);
        }

        // if (executeStage) {
        if (executeStageString != null && executeStageString.matches("true")) {

            // Retreive XML resultset from context
            if (!(context.getResponse() instanceof XMLResultset)) {
                throw new PipelineRuntimeException("Contained response object MUST be of type 'XMLResultset'!");
            }
            XMLResultset response = (XMLResultset) context.getResponse();

            Document xmlDoc;
            try {
                response.moveFirst();
                xmlDoc = response.getDocument();
            } catch (ResultsetException e) {
                throw new PipelineRuntimeException("Failed to obtain result set as XML document!", e);
            }

            // Read tax configuration for current business object from
            // Key/Values properties file
            String taxConfig = CustomStagesHelper.getKeyValue("IncludeTax." + context.getObjectName());

            // Perform the tax calculation
            if (taxConfig != null)
                calculateTax(xmlDoc, taxConfig);
        }
    }

    /**
     * Calculate tax on the resultset. Which attributes are to be calculated is
     * determined by the taxConfig parameter.
     * 
     * @param resultset
     *            is the result on which tax is to be calculated.
     * @param taxConfig
     *            is the tax calculation configuration string on which the
     *            calculations are based.
     * @throws PipelineRuntimeException
     */
    private void calculateTax(Document resultset, String taxConfig) throws PipelineRuntimeException {

        // Separate tax config clauses
        String[] clauses = taxConfig.split(";");

        // Iterate over config clauses
        for (int j = 0; j < clauses.length; j++) {

            // Parse config clause
            boolean operatorIsMultiplication = true;
            String strPath;
            String strAttr;
            String strRate;

            // Determine tax calculation method
            if (clauses[j].indexOf("*") > 0) {
                operatorIsMultiplication = true;
                String[] tmp = clauses[j].split("\\*");
                strPath = tmp[0];
                strRate = tmp[1];
            } else {
                operatorIsMultiplication = false;
                String[] tmp = clauses[j].split("\\+");
                strPath = tmp[0];
                strRate = tmp[1];
            }

            // Build xpath string to select elements to calculate tax on.
            // We build our xpath so that only the elements containing both
            // attributes that are needed
            // for tax calculation are selected. In the previous VB stage we
            // didn't do anything if the
            // first attribute was not present and we used a rate of zero if the
            // second attribute was
            // not present (which has no effect).
            StringBuffer xpath = new StringBuffer();
            String[] tags = strPath.split(":");

            if (tags.length == 1) {

                strAttr = strPath;
                xpath.append("//*[@");
                xpath.append(strAttr);
                xpath.append(" and @");
                xpath.append(strRate);
                xpath.append("]");

            } else {

                strAttr = tags[tags.length - 1];
                xpath.append("/");

                for (int k = 0; k < tags.length - 1; k++) {
                    xpath.append("/");
                    xpath.append(tags[k]);
                }

                xpath.append("[@");
                xpath.append(strAttr);
                xpath.append(" and @");
                xpath.append(strRate);
                xpath.append("]");
            }

            try {

                // TODO. select caseinsensitive?

                // Select elements using the xpath string
                NodeList nodelist = XPathAPI.selectNodeList(resultset, xpath.toString());
                // assert(nodelist != null);

                // Iterate over all elements selected
                for (int i = 0; i < nodelist.getLength(); i++) {

                    // Calculate tax for each element
                    NamedNodeMap attributes = nodelist.item(i).getAttributes();
                    Node nodeAttr = attributes.getNamedItem(strAttr);
                    Node nodeRate = attributes.getNamedItem(strRate);

                    // Assert(nodeAttr != null); //We have insured this in our
                    // xpath selection
                    // Assert(nodeRate != null); //We have insured this in our
                    // xpath selection

                    // Get the amount to tax
                    Attr attrAttr = (Attr) nodeAttr;
                    String attrValue = attrAttr.getNodeValue();
                    BigDecimal amount = new BigDecimal(attrValue);

                    // Get the rate
                    Attr attrRate = (Attr) nodeRate;
                    String rateValue = attrRate.getNodeValue();
                    BigDecimal rate = new BigDecimal(rateValue);

                    // Add or multiply the taxRate
                    if (operatorIsMultiplication) {
                        // amount = amount + (amount * rate)
                        amount = amount.add(amount.multiply(rate));
                    } else {
                        // amount = amount + rate
                        amount = amount.add(rate);
                    }

                    // Update the amount in the XML
                    nodeAttr.setNodeValue(Decimal.toString(amount));
                }
            } catch (Exception e) {
                throw new PipelineRuntimeException("Error in IncludeTax stage", e);
            }
        }
    }
}
