package com.intentia.iec.pipeline.runtime.integration.erp.dao.factory;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.integration.erp.dao.ItemDao;
import com.intentia.iec.pipeline.runtime.integration.erp.dao.OrderDao;
import com.intentia.iec.pipeline.runtime.integration.erp.dao.impl.ItemDaoWSGenericImpl;
import com.intentia.iec.pipeline.runtime.integration.erp.dao.impl.OrderDaoWSGenericImpl;
import com.intentia.iec.pipeline.runtime.integration.erp.exception.ErpConnectionException;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

public class WebserviceDaoFactory extends DaoFactory{	
	
	private static final Logger LOG = Logger.getLogger(WebserviceDaoFactory.class);
	public static String WSDL_ENDPOINT_ITEMPRICE;
	public static String WSDL_ENDPOINT_ORDERTOTAL;
	public static String WSDL_ENDPOINT_ATP;
	public static String WSDL_URL_ITEMPRICE;
	public static String WSDL_URL_ORDERTOTAL;
	public static String WSDL_URL_ATP;
	public static String WEBSERVICEUSERID;
	
	public WebserviceDaoFactory(){
		initWSDL();
	}

	public ItemDao getItemDao() throws ErpConnectionException {
		return new ItemDaoWSGenericImpl();
	}

	public OrderDao getOrderDao() throws ErpConnectionException{
		return new OrderDaoWSGenericImpl();
	}
	
	private void initWSDL(){
		try{
			SearchPipelineExecuter spe = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "ApplicationData",	"Details");
			spe.setParam("param", "WSDL URL (ItemPrice)");
			XMLResultset speResult = spe.execute();
			speResult.beforeFirst();
			while(speResult.moveNext())
				WSDL_URL_ITEMPRICE = speResult.getString("ParameterValue");					
			
			spe.setParam("param", "WSDL URL (OrderTotal)");
			speResult = spe.execute();
			speResult.beforeFirst();
			while(speResult.moveNext())
				WSDL_URL_ORDERTOTAL = speResult.getString("ParameterValue");
			
			spe.setParam("param", "WSDL URL (ATP)");
			speResult = spe.execute();
			speResult.beforeFirst();
			while(speResult.moveNext())
				WSDL_URL_ATP = speResult.getString("ParameterValue");
			
			spe.setParam("param", "WSDL URL Endpoint (ItemPrice)");
			speResult = spe.execute();
			speResult.beforeFirst();
			while(speResult.moveNext())
				WSDL_ENDPOINT_ITEMPRICE = speResult.getString("ParameterValue");
			
			spe.setParam("param", "WSDL URL Endpoint (OrderTotal)");
			speResult = spe.execute();
			speResult.beforeFirst();
			while(speResult.moveNext())
				WSDL_ENDPOINT_ORDERTOTAL = speResult.getString("ParameterValue");
			
			spe.setParam("param", "WSDL URL Endpoint (ATP)");
			speResult = spe.execute();
			speResult.beforeFirst();
			while(speResult.moveNext())
				WSDL_ENDPOINT_ATP = speResult.getString("ParameterValue");
			
			spe.setParam("param", "WebServiceUserID");
			speResult = spe.execute();
			speResult.beforeFirst();
			while(speResult.moveNext())
				WEBSERVICEUSERID = speResult.getString("ParameterValue");
		
		} catch (Exception e) {
			LOG.debug("Error initWSDL", e);
		}	
	}

}
