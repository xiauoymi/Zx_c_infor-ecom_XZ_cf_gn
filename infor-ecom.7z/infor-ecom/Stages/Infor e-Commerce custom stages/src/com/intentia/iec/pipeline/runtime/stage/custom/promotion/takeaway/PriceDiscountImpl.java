package com.intentia.iec.pipeline.runtime.stage.custom.promotion.takeaway;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;

public class PriceDiscountImpl implements TakeAway {

	private static final Logger LOG = Logger.getLogger(PriceDiscountImpl.class);
	
	private static PriceDiscountImpl instance = null;
	
	private PromotionTakeAway promotionTakeAway = null;
	
	private List<String> promotionalItems = null;
	
	private Map<String, String> itemDetailsMap = null;

	protected PriceDiscountImpl() {
	      // Exists only to defeat instantiation.
	}
	public static PriceDiscountImpl getInstance() {
		if(instance == null) {
			instance = new PriceDiscountImpl();
		}
	return instance;
	}
	
	public void setPromotionalItems(List<String> promotionalItems) {
		this.promotionalItems = promotionalItems;
	}

	public void setItemParametersMap(Map<String, String> itemDetailsMap) {
		this.itemDetailsMap = itemDetailsMap;
	}

	/**
	 * @return the promotionTakeAway
	 */
	public PromotionTakeAway getPromotionTakeAway() {
		return promotionTakeAway;
	}
	/**
	 * @param promotionTakeAway the promotionTakeAway to set
	 */
	public void setPromotionTakeAway(PromotionTakeAway promotionTakeAway) {
		this.promotionTakeAway = promotionTakeAway;
	}

	/**
	 * Apply Header Level Promotion Take Away
	 */
	public void applyHeaderTakeaway(XMLResultset resultSet) {
		LOG.debug("Inside PriceDiscountImpl.applyHeaderTakeaway()");
		PromotionTakeAway takeAway = this.promotionTakeAway;
		String takeAwayField = takeAway.getField();
		String takeAwayOperator = takeAway.getOperator();
		List<String> takeAwayValueList = takeAway.getValues();
		try {
			if(TakeAwayConstant.ORDER_TOTAL.equalsIgnoreCase(takeAwayField)){
				this.applyPriceDiscountGrandTotal(resultSet, takeAwayValueList, takeAwayOperator);
			
			} else if(TakeAwayConstant.PER_ITEM_IN_CART.equalsIgnoreCase(takeAwayField)){
				this.applyPriceDiscountPerItemInCart(resultSet, takeAwayValueList, takeAwayOperator);
			
			} else if(TakeAwayConstant.ITEMS_IN_PROMO.equalsIgnoreCase(takeAwayField)){
				this.applyPriceDiscountByItemsInPromo(resultSet, takeAwayValueList, takeAwayOperator);
			
			} else if(TakeAwayConstant.SELECTED_ITEMS.equalsIgnoreCase(takeAwayField)){
				this.applyPriceDiscountBySelectedItems(resultSet, takeAwayValueList, takeAwayOperator);
			
			}
		} catch (ResultsetException e) {
			e.printStackTrace();
		}

		
	}
	
	public void applyLineTakeAway(XMLResultset resultSet, XMLIterator xmlOrderline) {	
		LOG.debug("Inside PriceDiscountImpl.applyLineTakeAway()");
		PromotionTakeAway takeAway = this.promotionTakeAway;
		String takeAwayField = takeAway.getField();
		String takeAwayOperator = takeAway.getOperator();
		List<String> takeAwayValueList = takeAway.getValues();
		try {
			if(TakeAwayConstant.PER_ITEM_IN_CART.equals(takeAwayField)){
				this.applyPriceDiscountPerItemInCart(xmlOrderline, takeAwayValueList, takeAwayOperator);
			} else if(TakeAwayConstant.ITEMS_IN_PROMO.equals(takeAwayField)){
				this.applyPriceDiscountByItemsInPromo(xmlOrderline, takeAwayValueList, takeAwayOperator);
			} else if(TakeAwayConstant.SELECTED_ITEMS.equals(takeAwayField)){
				this.applyPriceDiscountBySelectedItems(xmlOrderline, takeAwayValueList, takeAwayOperator);
			}
		} catch (ResultsetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void applyPriceDiscountGrandTotal(XMLResultset resultSet, List<String> takeAwayValueList, String operator)
			throws ResultsetException{
		LOG.debug("Inside PriceDiscountImpl.applyPriceDiscountGrandTotal()");
		//Total Price
		String totalPriceFromRequest = resultSet.getString(ConstantsForSales.TOTALPRICE);
		String totalDiscountFromRequest = resultSet.getString(ConstantsForSales.TOTALDISCOUNT);
		
		LOG.debug("Before Order Total Discount Total Price : "+totalPriceFromRequest);
		LOG.debug("Before Order Total Discount Total Discount : "+totalDiscountFromRequest);
		BigDecimal headerTotalPrice = new BigDecimal(totalPriceFromRequest);
		BigDecimal totalLineDiscount = new BigDecimal(totalDiscountFromRequest);
		BigDecimal headerDiscount = new BigDecimal(0);
		BigDecimal discountTotal = new BigDecimal(0);
		
		if(!takeAwayValueList.isEmpty()){
				//headerTotalPrice = this.getDiscountedValue(totalPriceFromRequest, takeAwayValueList.get(0), operator);
			//Get Total Line Discount
			headerDiscount = this.getDiscount(totalPriceFromRequest, takeAwayValueList.get(0), operator);
			//resultSet.appendField(TakeAwayConstant.REQ_ORDERHEADER_DISCOUNT, headerDiscount.toString());
			//resultSet.appendField(TakeAwayConstant.REQ_TOTAL_LINE_DISCOUNT, totalLineDiscount.toString());
			this.updRsAttr(resultSet, TakeAwayConstant.REQ_ORDERHEADER_DISCOUNT, headerDiscount.toString());
			this.updRsAttr(resultSet, TakeAwayConstant.REQ_TOTAL_LINE_DISCOUNT, totalLineDiscount.toString());
			
			LOG.debug("Header Discount : "+headerDiscount.toString());
			LOG.debug("TotalLine Discount : "+totalLineDiscount.toString());
			
			discountTotal = headerDiscount.add(totalLineDiscount);
			LOG.debug("Total Discount : "+discountTotal.toString());
			//Get Modified Total Price with Promotion Take Away Discount
			headerTotalPrice = headerTotalPrice.subtract(discountTotal);
		}
		LOG.debug("After Order Total Discount Total Price : "+headerTotalPrice.toString());
		LOG.debug("After Order Total Discount Total Discount : "+headerDiscount.toString());
		
		this.updRsAttr(resultSet, ConstantsForSales.GRANDTOTAL, headerTotalPrice.toString());
		this.updRsAttr(resultSet, ConstantsForSales.TOTALDISCOUNT, discountTotal.toString());
		
	}
	
	private void applyPriceDiscountPerItemInCart(XMLResultset resultSet, List<String> takeAwayValueList, String operator)
			throws ResultsetException{
		LOG.debug("Inside PriceDiscountImpl.applyPriceDiscountPerItemInCart()");
		try {
			if(!takeAwayValueList.isEmpty()){
				resultSet.moveFirst();
				XMLIterator lineIter = (XMLIterator) resultSet.getResultset(ConstantsForSales.ORDERLINE);
				lineIter.beforeFirst();
				while (lineIter.moveNext()) {
					applyPriceDiscountPerItemInCart(lineIter, takeAwayValueList,  operator);
				}
			}
		} catch (ResultsetException e) {
			e.printStackTrace();
		}
	}
	
	private void applyPriceDiscountPerItemInCart(XMLIterator xmlOrderline, List<String> takeAwayValueList, String operator)
			throws ResultsetException{
		LOG.debug("Inside PriceDiscountImpl.applyPriceDiscountPerItemInCart()");
		if(!takeAwayValueList.isEmpty()){
			String resellPrice = xmlOrderline.getString(ConstantsForSales.RESELLPRICE);
			BigDecimal quantity = getParameterAsDecimal(xmlOrderline.getString(ConstantsForSales.QUANTITY));
			
			//TOTAL LINE DISCOUNT = (unitPrice - discount) * quantity
			BigDecimal lineDiscount = getDiscount(resellPrice, takeAwayValueList.get(0), operator).multiply(quantity);
			this.updRsAttr(xmlOrderline, ConstantsForSales.LINEDISCOUNT, lineDiscount.toString());
			
			// LINETOTAL = LINEPRICE - LINEDISCOUNT
			BigDecimal lineTotal = getParameterAsDecimal(xmlOrderline.getString(ConstantsForSales.LINEPRICE)).subtract(lineDiscount);
			this.updRsAttr(xmlOrderline, ConstantsForSales.LINETOTAL, lineTotal.toString());

		}
	}

	private void applyPriceDiscountByItemsInPromo(XMLResultset resultSet, List<String> takeAwayValueList, String operator)
			throws ResultsetException{
		LOG.debug("Inside PriceDiscountImpl.applyPriceDiscountByItemsInPromo()");
		BigDecimal modLineTotal = new BigDecimal(0);		
		try {
			if(!takeAwayValueList.isEmpty()){
				resultSet.moveFirst();
				XMLIterator lineIter = (XMLIterator) resultSet.getResultset(ConstantsForSales.ORDERLINE);
				lineIter.beforeFirst();
				String itemIDFromRequest = "";
				while (lineIter.moveNext()) {
					itemIDFromRequest = lineIter.getString(TakeAwayConstant.REQ_ITEM_ID);
					if(this.promotionalItems.contains(itemIDFromRequest)){
						applyPriceDiscountByItemsInPromo(lineIter, takeAwayValueList, operator);
					}
				}
			}
		} catch (ResultsetException e) {
			e.printStackTrace();
		}
	}

	private void applyPriceDiscountByItemsInPromo(XMLIterator xmlOrderline, List<String> takeAwayValueList, String operator)
			throws ResultsetException{
		LOG.debug("Inside FreeItemImpl.applyPriceDiscountByItemsInPromo()");
		try {
			if(!takeAwayValueList.isEmpty()){

				String itemIDFromRequest = xmlOrderline.getString(TakeAwayConstant.REQ_ITEM_ID);
				if(this.promotionalItems.contains(itemIDFromRequest)){
					String resellPrice = xmlOrderline.getString(ConstantsForSales.RESELLPRICE);
					BigDecimal quantity = getParameterAsDecimal(xmlOrderline.getString(ConstantsForSales.QUANTITY));
					
					//TOTAL LINE DISCOUNT = (unitPrice - discount) * quantity
					BigDecimal lineDiscount = getDiscount(resellPrice, takeAwayValueList.get(0), operator).multiply(quantity);
					this.updRsAttr(xmlOrderline, ConstantsForSales.LINEDISCOUNT, lineDiscount.toString());
					
					// LINETOTAL = LINEPRICE - LINEDISCOUNT
					BigDecimal lineTotal = getParameterAsDecimal(xmlOrderline.getString(ConstantsForSales.LINEPRICE)).subtract(lineDiscount);
					this.updRsAttr(xmlOrderline, ConstantsForSales.LINETOTAL, lineTotal.toString());
					
//					String lineTotalFromRequest = xmlOrderline.getString(RulesContant.REQ_LINE_TOTAL);
//					modLineTotal = this.getDiscountedValue(lineTotalFromRequest, takeAwayValueList.get(0), operator);
//					this.updRsAttr(xmlOrderline, TakeAwayContant.REQ_LINE_TOTAL, modLineTotal.toString());						
				}
				
			}
		} catch (ResultsetException e) {
			e.printStackTrace();
		}
	}
	
	private void applyPriceDiscountBySelectedItems(XMLResultset resultSet, List<String> takeAwayValueList, String operator)
			throws ResultsetException{
		LOG.debug("Inside PriceDiscountImpl.applyPriceDiscountBySelectedItems()");

		try {
			if(!takeAwayValueList.isEmpty()){
				resultSet.moveFirst();
				XMLIterator lineIter = (XMLIterator) resultSet.getResultset(ConstantsForSales.ORDERLINE);
				lineIter.beforeFirst();
				while (lineIter.moveNext()) {
					boolean withSelectedItem = applyPriceDiscountBySelectedItems(lineIter, takeAwayValueList, operator);
					if(withSelectedItem){
						break;
					}
				}
			}
		} catch (ResultsetException e) {
			e.printStackTrace();
		}
		
	}
	
	private boolean applyPriceDiscountBySelectedItems(XMLIterator xmlOrderline, List<String> takeAwayValueList, String operator)
			throws ResultsetException{
		LOG.debug("Inside PriceDiscountImpl.applyPriceDiscountBySelectedItems()");
		PromotionTakeAway takeAway = this.promotionTakeAway;
		//Should be an ItemNumber
		String extraParam = takeAway.getExtraParams();

		BigDecimal modLineTotal = new BigDecimal(0);		
		try {
			if(!takeAwayValueList.isEmpty()){
				String itemIDFromRequest = xmlOrderline.getString(TakeAwayConstant.REQ_ITEM_ID);
				if(extraParam.equals(itemIDFromRequest)){
					String resellPrice = xmlOrderline.getString(ConstantsForSales.RESELLPRICE);
					BigDecimal quantity = getParameterAsDecimal(xmlOrderline.getString(ConstantsForSales.QUANTITY));
					
					//TOTAL LINE DISCOUNT = (unitPrice - discount) * quantity
					BigDecimal lineDiscount = getDiscount(resellPrice, takeAwayValueList.get(0), operator).multiply(quantity);
					this.updRsAttr(xmlOrderline, ConstantsForSales.LINEDISCOUNT, lineDiscount.toString());
					
					// LINETOTAL = LINEPRICE - LINEDISCOUNT
					BigDecimal lineTotal = getParameterAsDecimal(xmlOrderline.getString(ConstantsForSales.LINEPRICE)).subtract(lineDiscount);
					this.updRsAttr(xmlOrderline, ConstantsForSales.LINETOTAL, lineTotal.toString());
					
//					String lineTotalFromRequest = xmlOrderline.getString(RulesContant.REQ_LINE_TOTAL);
//					modLineTotal = this.getDiscountedValue(lineTotalFromRequest, takeAwayValueList.get(0), operator);
//					this.updRsAttr(xmlOrderline, TakeAwayContant.REQ_LINE_TOTAL, modLineTotal.toString());
					return true;
				}
			}
		} catch (ResultsetException e) {
			e.printStackTrace();
		}
		return false;
		
	}
	
	private String updRsAttr(final XMLResultset rs, final String rsPar, final String value) {
        return CustomStagesHelper.updateRsAttribute(rs, rsPar, value);
    }
    
    private String updRsAttr(final XMLIterator rs, final String rsPar, final String value) {
        return CustomStagesHelper.updateRsAttribute(rs, rsPar, value);
    }
    
	private BigDecimal getDiscountedValue(String strTotal, String strDiscountValue, String operator){
		BigDecimal modifiedTotal = new BigDecimal(0);
		BigDecimal total = new BigDecimal(strTotal);
		BigDecimal discountValue = new BigDecimal(strDiscountValue);
		
		if(TakeAwayConstant.OPERATOR_EQUAL.equals(operator)){
			//convertAmount
			discountValue = this.promotionTakeAway.calculateValueCurrency(strDiscountValue);
			//If = (exact amount)
			//less exact amount to 
			modifiedTotal= total.subtract(discountValue);
		} else if (TakeAwayConstant.OPERATOR_PERCENT.equals(operator)){
			//If % percentage (computation)
			BigDecimal discountedValue = total.multiply(discountValue);
			discountValue = discountValue.divide(new BigDecimal("100.0000"));
			modifiedTotal = total.subtract(discountedValue);
		}
		
		return modifiedTotal;
	}
	
	
	private BigDecimal getDiscount(String strTotal, String strDiscountValue, String operator){
		BigDecimal modifiedTotal = new BigDecimal(0);
		BigDecimal total = new BigDecimal(strTotal);
		BigDecimal discountValue = new BigDecimal(strDiscountValue);
		
		if(TakeAwayConstant.OPERATOR_EQUAL.equals(operator)){
			discountValue = this.promotionTakeAway.calculateValueCurrency(strDiscountValue);
			return discountValue;
		} else if (TakeAwayConstant.OPERATOR_PERCENT.equals(operator)){
			discountValue = discountValue.divide(new BigDecimal("100.0000"));
			return  total.multiply(discountValue);
		}
		return modifiedTotal;
	}
	
	private BigDecimal getParameterAsDecimal(final String val) {
        if (val != null) {
            try {
                return new BigDecimal(val);
            } catch (NumberFormatException e) {
                return new BigDecimal("0.0000");
            }
        }
        return new BigDecimal("0.0000");
    }
	
}
