/*
 * Created on 31-03-2004
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.io.DOMReader;
import org.dom4j.io.XMLWriter;
import org.w3c.dom.Node;
import org.w3c.dom.traversal.NodeIterator;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

/**
 * <p>
 * The <code>RemoveUnvalidRolesFromRequest</code> stage removes unvalid roles
 * from a request updating users from the Customer site. It is intenteded to be
 * employed to avoid assigning unvalid roles to users through URL-hacking.
 * </p>
 * 
 * <p>
 * <b>Required input in <code>PipelineContext</code>:</b><br>
 * </p>
 * 
 * <p>
 * <b>Generated output in <code>PipelineContext</code>:</b><br>
 * Any not allowed roles will no longer be in the request in the
 * <code>PipelineContext</code>.
 * </p>
 */

public class RemoveUnvalidRolesFromRequest implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(RemoveUnvalidRolesFromRequest.class);

    // private static final String COMPANY_USER_FEATURE_ELEMENT_ID = "77";
    private static final String CUSTOMER_USER_ROLE_TYPE = "MultiUser";

    private static final String ROLE_LOOKUP_PARAMETER = "@RoleType";

    private static final String ROLE_LOOKUP_ATTRIBUTE = "RoleID";

    private List allowedRoles = null;

    /**
     * <p>
     * Find roles allowed. Check the request if it contains any NOT allowed
     * roles and removed those from the request.
     * </p>
     * 
     * @throws PipelineRuntimeException
     * @see com.intentia.iec.pipeline.runtime.PipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
     */
    public void execute(PipelineContext context) throws PipelineRuntimeException {

        if (LOG.isDebugEnabled()) {
            LOG.debug("Attempting to remove unvalid roles from user edit request!");
        }

        // Verify type of request
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Request MUST be of type XMLRequest!");
        }

        XMLRequest request = (XMLRequest) context.getRequest();

        try {
            XMLRequest.extractRequestParameters(request);
            Parameters params = request.getParameters();
            try {
                if ("true".equals(params.getString("@SkipThisStage"))) {
                    LOG.debug("'@SkipThisStage' parameter is TRUE, skip this stage.");
                    return;
                }
            } catch (Exception e) {
                LOG.debug("'@SkipThisStage' parameter not found.");
            }
        } catch (RequestException e) {
            throw new PipelineRuntimeException("Request error in RemoveUnvalidRolesFromRequest stage", e);
        }

        findAllowedRoles();

        checkAndRemoveRoles(CustomStagesHelper.getRequest(context));
    }

    /**
     * <p>
     * Create the <code>List</code> with the roles that are allowed. The
     * search is done using the generated method <code>Role.Role_Lookup</code>
     * with <code>featureID = 77</code>.
     * </p>
     * 
     * @throws PipelineRuntimeException
     *             if fetching roles from search resultset fails.
     */
    private void findAllowedRoles() throws PipelineRuntimeException {

        allowedRoles = new ArrayList();

        // Note that the method used to find valid roles was changed from
        // Role_Lookup in 5.3 to
        // Role_ValidCustomerRoles in 6.0, which fetches all the roles belonging
        // to roleType "MultiUser"
        SearchPipelineExecuter search = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "Role",
                "ValidCustomerRoles");
        search.setParam(ROLE_LOOKUP_PARAMETER, CUSTOMER_USER_ROLE_TYPE);
        XMLResultset resultset = search.execute();

        try {
            resultset.beforeFirst();
            while (resultset.moveNext()) {
                allowedRoles.add(resultset.getString(ROLE_LOOKUP_ATTRIBUTE));
            }
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Failed to get RoleID from search result!", e);
        }
    }

    /**
     * <p>
     * Move through all the roles in the request and check if they are allowed.
     * If the role is not in the allowed list then it is removed from the
     * request.
     * </p>
     * 
     * @param request
     *            the request from the <code>PipelineContext</code>
     * @throws PipelineRuntimeException
     *             if fetching roleid from request or removing not allowed roles
     *             from the request fails.
     */
    private void checkAndRemoveRoles(XMLRequest request) throws PipelineRuntimeException {

        if (LOG.isDebugEnabled()) {
            try {
                ByteArrayOutputStream os = new ByteArrayOutputStream();
                Document dom4jRequest = new DOMReader().read(request.getRequestDoc());
                new XMLWriter().write(dom4jRequest);

                // XMLWriter should by default write an XML document
                // in the UTF-8 encoding. Therefore log the
                // ByteArrayOutputStream content using the UTF-8 parameter
                LOG.debug(os.toString("UTF-8"));
            } catch (RequestException e) {
                throw new PipelineRuntimeException(e);
            } catch (UnsupportedEncodingException e) {
                throw new PipelineRuntimeException("Error when logging request", e);
            } catch (IOException e) {
                throw new PipelineRuntimeException("Error when logging request", e);
            }
        }

        NodeIterator subsets = XMLRequestHelper.getSubsets(request, "Role");
        XMLRequestHelper requestHelper = new XMLRequestHelper(request);

        Node subset = subsets.nextNode();
        while (subset != null) {
            String roleID = null;
            try {
                roleID = requestHelper.getAttribute(subset, "RoleID");
            } catch (TransformerException e) {
                throw new PipelineRuntimeException("Failed to get RoleID attribute from request", e);
            }

            if (roleID == null) {
                continue;
            }

            if (!allowedRoles.contains(roleID)) {
                // remove role from request
                // Note:
                // we need to move the iterator before removing the node to
                // avoid
                // null pointer exception, since removing the node that the
                // iterator
                // is standing on also removes the knowledge about the nodes
                Node removeNode = subset;
                subset = subsets.nextNode();
                requestHelper.removeEntity(removeNode);
            } else {
                subset = subsets.nextNode();
            }
        }
    }
}
