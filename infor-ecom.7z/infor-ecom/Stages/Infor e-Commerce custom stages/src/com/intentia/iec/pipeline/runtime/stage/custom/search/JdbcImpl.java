package com.intentia.iec.pipeline.runtime.stage.custom.search;

import java.sql.Connection;

import org.apache.log4j.Logger;

import com.intentia.iec.connection.ConnectionException;
import com.intentia.iec.connection.ConnectionFactory;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;

/**
 * A JDBC helper class. Shields clients from JDBC issues (primarily safe clean
 * up).
 */
public final class JdbcImpl extends JdbcBase {
    private static final Logger LOG = Logger.getLogger(JdbcImpl.class);

    public Connection getConnection() throws PipelineRuntimeException {
        try {
            return (Connection) ConnectionFactory.getConnection(CustomStagesHelper.getConnectionName("esales.cursor"));
        } catch (ConnectionException e) {
            LOG.error("Error getting database connection", e);
            throw new PipelineRuntimeException();
        }
    }
}
