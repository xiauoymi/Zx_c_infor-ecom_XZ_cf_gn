package com.intentia.iec.pipeline.runtime.stage.custom.daf.drawing;

import com.intentia.icp.common.CMCollection;

/**
 * Utility class for DAF Drawing
 *
 */
public class DafDrawingUtils {

	/**
	 * Converts the shape code from DAF to e-Sales
	 * @param type
	 * @return
	 */
	public static String convertDafShapeCode(Short type) {
		if (type != null) {
			if (type.shortValue() == 10) {
				return DafDrawingConstants.ShapeCodes.CIRCLE;
			}
			if (type.shortValue() == 20) {
				return DafDrawingConstants.ShapeCodes.RECTANGLE;
			}
			if (type.shortValue() == 30) {
				return DafDrawingConstants.ShapeCodes.POLYGON;
			}			
		}
		
		return null;
	}
	
	/**
	 * Converts the shape code from e-Sales to DAF
	 * @param code
	 * @return
	 */
	public static short convertDafShapeCode(String code) {
		if (code != null) {
			if (DafDrawingConstants.ShapeCodes.CIRCLE.equals(code)) {
				return 10;
			}
			if (DafDrawingConstants.ShapeCodes.RECTANGLE.equals(code)) {
				return 20;
			}
			if (DafDrawingConstants.ShapeCodes.POLYGON.equals(code)) {
				return 30;
			}
		}
		
		return -1;
	}
	
	/**
	 * Converts the Is Default property from DAF to e-Sales
	 * @param isDefault
	 * @return
	 */
	public static String convertDafIsDefault(Short isDefault) {
		if (isDefault != null) {
			if (isDefault.shortValue() > 0) {
				return DafDrawingConstants.YES;
			}
		}
		return DafDrawingConstants.NO;
	}
	
	/**
	 * Converts the Is Default property from e-Sales to DAF
	 * @param isDefault
	 * @return
	 */
	public static short convertDafIsDefault(String isDefault) {
		if (DafDrawingConstants.YES.equals(isDefault) == true) {
			return 1;
		}
		return 0;
	}
	
	/**
	 * Converts the Status property from DAF to e-Sales
	 * @param status
	 * @return
	 */
	public static String convertDafStatus(Short status) {
		if (status != null) {
			switch (status.shortValue()) {
			case DafDrawingConstants.DAFStatusCodes.DRAFT:
				return DafDrawingConstants.StatusCodes.DRAFT;

			case DafDrawingConstants.DAFStatusCodes.APPROVED:
				return DafDrawingConstants.StatusCodes.APPROVED;				

			case DafDrawingConstants.DAFStatusCodes.INVALID:
				return DafDrawingConstants.StatusCodes.INVALID;
			}			
		}
		return "";
	}
	
	/**
	 * Converts the Status property from e-Sales to DAF
	 * @param status
	 * @return
	 */
	public static short convertDafStatus(String status) {
		if (status != null) {
			if (DafDrawingConstants.StatusCodes.DRAFT.equals(status) == true) {
				return DafDrawingConstants.DAFStatusCodes.DRAFT;
			}
			else if (DafDrawingConstants.StatusCodes.APPROVED.equals(status) == true) {
				return DafDrawingConstants.DAFStatusCodes.APPROVED;
			}
			else if (DafDrawingConstants.StatusCodes.INVALID.equals(status) == true) {
				return DafDrawingConstants.DAFStatusCodes.INVALID;
			}
		}
		return -1;
	}
	
	
	/**
	 * Checks if the coordinate has a valid format
	 * @param coordinate
	 * @param code
	 * @return
	 */
	public static boolean isValidCoordinate(String coordinate, String code) {
		String[] result = null;
		if (coordinate == null || code == null) {
			return false;
		}

		if (DafDrawingConstants.ShapeCodes.CIRCLE.equals(code) == true) {
		     result = coordinate.split(",");
		     if (result == null) {
		    	 return false;
		     }

		     // circle must have 3 values
		     if (result.length != 3) {
		    	 return false;
		     }		     
		}
		else if (DafDrawingConstants.ShapeCodes.RECTANGLE.equals(code) == true) {
		     result = coordinate.split(",");
		     if (result == null) {
		    	 return false;
		     }

		     // rectangle must have 4 values
		     if (result.length != 4) {
		    	 return false;
		     }		     
		}
		else if (DafDrawingConstants.ShapeCodes.POLYGON.equals(code) == true) {
		     result = coordinate.split(",");
		     if (result == null) {
		    	 return false;
		     }

		     // polygon must have pairs
		     if (result.length <= 0 || (result.length % 2) != 0) {
		    	 return false;
		     }
		}
		
		// check if values are valid integers
		for (int i = 0; i < result.length; i++) {
			try {
				Integer.parseInt(result[i]);
			}
			catch (Exception e) {
				return false;
			}
		}
		
		return true;
	}
	
	
	/**
	 * Checks if a hot spot from DAF is valid
	 * @param collection
	 * @return
	 */
	public static boolean isValidHotSpot(CMCollection collection) {
		String code = null;
		
		// check valid code
		if ((collection.getAttributeValue(DafDrawingConstants.ATTRIBUTE_SHAPE_CODE) instanceof Short) == false) {
			return false;
		}
		code = DafDrawingUtils.convertDafShapeCode((Short)collection.getAttributeValue(DafDrawingConstants.ATTRIBUTE_SHAPE_CODE));
		if (code == null) {
			return false;
		}
		
		// check valid item number
		if ((collection.getAttributeValue(DafDrawingConstants.ATTRIBUTE_ITEM_NUMBER) instanceof String) == false) {
			return false;
		}
		
		// check valid coordinate
		if ((collection.getAttributeValue(DafDrawingConstants.ATTRIBUTE_COORDINATES) instanceof String) == false) {
			return false;
		}

		//  check if valid coordinate format
		return isValidCoordinate((String) collection.getAttributeValue(DafDrawingConstants.ATTRIBUTE_COORDINATES), code);
	}
}
