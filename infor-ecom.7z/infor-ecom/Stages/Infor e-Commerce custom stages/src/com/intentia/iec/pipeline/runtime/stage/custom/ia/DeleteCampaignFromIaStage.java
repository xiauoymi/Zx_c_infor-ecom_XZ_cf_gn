package com.intentia.iec.pipeline.runtime.stage.custom.ia;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.ia.dao.IaDao;
import com.intentia.iec.pipeline.runtime.integration.ia.dao.impl.IaDaoRestImpl;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaConnectionException;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.ia.model.IaCampaign;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;

public class DeleteCampaignFromIaStage extends AbstractPipelineStage {

	private static final Logger log = Logger
			.getLogger(DeleteCampaignFromIaStage.class);

	private IaDao dao = null;

	public DeleteCampaignFromIaStage() {
	}

	@Override
	public void execute(PipelineContext context)
			throws PipelineRuntimeException {
		log.debug("Start DeleteCampaignFromIaStage . . .");

		CustomStagesHelper.extractRequestParameters(CustomStagesHelper
				.getRequest(context));

		XMLRequest request = (XMLRequest) context.getRequest();
		XMLResultset response = (XMLResultset) context.getResponse();

		try {
			Document reqDoc = request.getRequestDoc();
			if (reqDoc != null) {
				Element dSubNode = (Element) XPathAPI.selectSingleNode(reqDoc,
						"/request/delete/dsubsets");
				if (dSubNode != null) {
					log.debug("XMLRequest is a subset delete. Exiting DeleteCampaignFromIaStage.execute()...");
					return;
				}
			}

			boolean hasError = false;

			dao = new IaDaoRestImpl();
			IaCampaign campaign = new IaCampaign();

			boolean bval = response.isEmpty();

			if (!bval) {
				String id = response.getString("CampaignID");
				campaign.setId(id);

				try {
					dao.deleteCampaign(campaign);
				} catch (IaRuntimeException e) {
					log.error("Error while deleting campaign : " + campaign, e);
				}

				log.debug("DeleteCampaignFromIaStage has error:" + hasError);
			} else {
				log.debug("No Campaign Id is specified, existing from DeleteCampaignFromIaStage ...");
			}
		} catch (IaConnectionException e) {
			log.debug("Error while deleting campaign from IA.");
		} catch (ResultsetException e) {
			log.debug("Error while deleting campaign from IA.");
		} catch (RequestException e) {
			log.debug("Error while deleting campaign from IA.");
		} catch (TransformerException e) {
			log.debug("Error while deleting campaign from IA.");
		}
	}
}
