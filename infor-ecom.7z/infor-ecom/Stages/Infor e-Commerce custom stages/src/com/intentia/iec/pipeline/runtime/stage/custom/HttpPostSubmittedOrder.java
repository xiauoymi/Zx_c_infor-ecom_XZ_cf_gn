/*
 * Copyright 2004 by Intentia
 *
 * Created on 28-04-2004
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.log4j.Logger;

import sun.misc.BASE64Encoder;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.CommitPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.util.XMLDateFormat;

/**
 * This stage http posts an XML document for an order being submitted.
 * <p>
 * This is a specialized stage for use in the Intentia eSales application. The
 * stage is inserted in the pipelines of order submit methods in eSales.
 * <p>
 * Much of the code in the stage is used to provide extensive logging
 * information for success or failure of the order export attempts. Failed order
 * exports can be manually retried in the Business Center of the eSales Web
 * application.
 * <p>
 * The stage is configured using input parameters of the request in the pipeline
 * context.
 * <p>
 * The input parameter named 'Reexport' is a flag informing the stage if the
 * method executing the stage is used for retrying a previously failed order
 * export. It should have the value 'true' or 'false'.
 * <p>
 * The input parameter named 'Email' is used to identify the user executing the
 * stage in the log entries.
 * <p>
 * The input parameter named 'OrderID' is used to identify the order being
 * submitted or retried exported in the log entries.
 * <p>
 * The input parameter named 'UserGroupID' is also only used to identify the
 * user executing the stage in the log entries.
 * <p>
 * The input parameter named 'ExportAddress' is used to specify the HTTP address
 * of the destination for the order export.
 * <p>
 * The optional input parameters named 'ExportUserID' and 'ExportPassword' can
 * be used to add username and password for Basic Authentication to the HTTP
 * request.
 * <p>
 * The stage performs logging by executing a number of methods on the Log
 * business object of the eSales application using hardcoded Class names:<br>
 * 'com.intentia.iec.runtime.pipeline.Log.Add'<br>
 * 'com.intentia.iec.runtime.pipeline.Log.Update'<br>
 * 'com.intentia.iec.runtime.pipeline.Log.FindHeaderLogEntry'<br>
 * <p>
 * Here is an outline of the functionality of the stage:
 * <p>
 * If the business object method is used for order submit the add a header log
 * entry, else if the method id used for a manual order export retry then find
 * the existing header log entry.
 * <p>
 * The response XML document in the pipeline context is attempted HTTP POSTed.
 * If the HTTP POST fails an error log entry is added. Else if everything went
 * OK up till this point a log entry with status of the successfully completed
 * order export is added. Additionally the header log entry is updated to
 * indicate the completion of the order export for the OrderID.
 * 
 * @author niekar0
 * 
 */
public class HttpPostSubmittedOrder implements PipelineStage {
    private static final Logger LOG = Logger.getLogger(HttpPostSubmittedOrder.class);

    public void execute(PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("Inside HttpPostSubmittedOrder.execute()");

        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
        XMLRequest xmlRequest = (XMLRequest) context.getRequest();

        if (!(context.getResponse() instanceof XMLResultset)) {
            throw new PipelineRuntimeException("Contained response object MUST be of type 'XMLResultset'!");
        }
        XMLResultset response = (XMLResultset) context.getResponse();

        CustomStagesHelper.extractRequestParameters(xmlRequest);
        Parameters params = xmlRequest.getParameters();

        /* Add Log entry */

        // Fetch input parameter values from context.
        String inparamIsReexport = "";
        String inparamEmail = null;
        String inparamOrderID = null;
        String inparamUserGroupID = null;
        try {
            inparamIsReexport = params.getString("Reexport");
            inparamEmail = params.getString("Email");
            inparamOrderID = params.getString("OrderID");
            inparamUserGroupID = params.getString("UserGroupID");
        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Exception while fetching input parameter values.", e);
        }

        String headerLogEntryID = null;
        if (!"true".equalsIgnoreCase(inparamIsReexport)) {
            // Create the Header log entry.
            CommitPipelineExecuter addLogEntry = new CommitPipelineExecuter("com.intentia.iec.runtime.pipeline", "Log",
                    "Add");
            addLogEntry.addEntity();
            addLogEntry.setAttribute("Action", "Header");
            addLogEntry.setAttribute("Status", "Initialize");
            addLogEntry.setAttribute("UserGroupID", inparamUserGroupID);
            addLogEntry.setAttribute("UserEmail", inparamEmail);
            addLogEntry.setAttribute("OrderID", inparamOrderID);
            addLogEntry.setAttribute("Message", "");
            addLogEntry.setAttribute("RefLogEntryID", "");
            addLogEntry.setAttribute("DateTime", (new XMLDateFormat()).format(new java.util.Date()));
            XMLResultset res = addLogEntry.execute();
            try {
                headerLogEntryID = res.getParameters().getString("key");
            } catch (ParametersException e) {
                throw new PipelineRuntimeException("Exception while fetching result key parameter value.", e);
            }

            // Make new Header log entry reference itself.
            CommitPipelineExecuter updateLogEntry = new CommitPipelineExecuter("com.intentia.iec.runtime.pipeline",
                    "Log", "Update");
            updateLogEntry.addEntity();
            updateLogEntry.setEntityKey("LogID", headerLogEntryID);
            updateLogEntry.setAttribute("RefLogEntryID", headerLogEntryID);
            updateLogEntry.execute();
        } else { // Reexport
            // Search for the Header log entry.
            SearchPipelineExecuter findHeaderLogEntry = new SearchPipelineExecuter("com.intentia.iec.runtime.pipeline",
                    "Log", "FindHeaderLogEntry");
            findHeaderLogEntry.setParam("OrderID", inparamOrderID);
            findHeaderLogEntry.setParam("Action", "Header");
            XMLResultset rsLog = findHeaderLogEntry.execute();
            String idHeaderLogEntry = null;
            try {
                if (rsLog.moveFirst()) {
                    headerLogEntryID = rsLog.getString("LogID");
                }
            } catch (ResultsetException e) {
                throw new PipelineRuntimeException("Exception while finding Header log entry.", e);
            }
        }

        /* Export the order */

        // Fetch input parameter values from context.
        String httpAddress = null;
        String httpUserID = null;
        String httpPassword = null;
        try {
            httpAddress = params.getString("ExportAddress");
            httpUserID = params.getString("ExportUserID");
            httpPassword = params.getString("ExportPassword");
        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Exception while fetching input parameter values.", e);
        }

        LOG.info("Posting XMLResultset to address '" + httpAddress + "'. " + "Basic authentication with UserID '"
                + httpUserID + "' " + "and Password '" + httpPassword + "'");

        try {
            URL url = new URL(httpAddress);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "text/xml");
            if (httpUserID != null) {
                String auth = httpUserID + ":";
                if (httpPassword != null)
                    auth += httpPassword;
                BASE64Encoder encoder = new BASE64Encoder();
                String encoding = encoder.encode(auth.getBytes());
                conn.setRequestProperty("Authorization", "Basic " + encoding);
            }
            conn.connect();
            DataOutputStream out = new DataOutputStream(conn.getOutputStream());
            out.writeBytes(response.toString());

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));

            if (conn.getResponseCode() != 200) {
                throw new Exception("HTTP error: " + conn.getResponseCode() + ". " + conn.getResponseMessage());
            }
        } catch (Exception e) {
            CommitPipelineExecuter addErrLogEntry = new CommitPipelineExecuter("com.intentia.iec.runtime.pipeline",
                    "Log", "Add");
            addErrLogEntry.addEntity();
            addErrLogEntry.setAttribute("Action", "ExportToBuyer");
            addErrLogEntry.setAttribute("Status", "Error");
            addErrLogEntry.setAttribute("UserGroupID", inparamUserGroupID);
            addErrLogEntry.setAttribute("UserEmail", inparamEmail);
            addErrLogEntry.setAttribute("OrderID", inparamOrderID);
            addErrLogEntry.setAttribute("Message", "Exception: " + e + "<br>Export address: " + httpAddress);
            addErrLogEntry.setAttribute("RefLogEntryID", headerLogEntryID);
            addErrLogEntry.setAttribute("DateTime", (new XMLDateFormat()).format(new java.util.Date()));
            addErrLogEntry.execute();

            return;
        }

        /* We are only here, if everything went OK. */

        // Add a Log entry with info about the successfully completed export
        // action.
        CommitPipelineExecuter addLogEntry2 = new CommitPipelineExecuter("com.intentia.iec.runtime.pipeline", "Log",
                "Add");
        addLogEntry2.addEntity();
        addLogEntry2.setAttribute("Action", "ExportToBuyer");
        addLogEntry2.setAttribute("Status", "OK");
        addLogEntry2.setAttribute("UserGroupID", inparamUserGroupID);
        addLogEntry2.setAttribute("UserEmail", inparamEmail);
        addLogEntry2.setAttribute("OrderID", inparamOrderID);
        addLogEntry2.setAttribute("Message", "");
        addLogEntry2.setAttribute("RefLogEntryID", headerLogEntryID);
        addLogEntry2.setAttribute("DateTime", (new XMLDateFormat()).format(new java.util.Date()));
        addLogEntry2.execute();

        // Update the header Log entry to indicate completion of export
        CommitPipelineExecuter updateLogEntry2 = new CommitPipelineExecuter("com.intentia.iec.runtime.pipeline", "Log",
                "Update");
        updateLogEntry2.addEntity();
        updateLogEntry2.setEntityKey("LogID", headerLogEntryID);
        // updateLogEntry2.setAttribute("LogID", headerLogEntryID);
        updateLogEntry2.setAttribute("Status", "Completed");
        updateLogEntry2.execute();
    }
}
