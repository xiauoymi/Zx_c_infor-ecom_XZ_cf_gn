/*
 * Created on 24-04-2006
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;

import java.io.File;
import java.io.InputStream;
import java.io.IOException;

import org.apache.commons.transaction.util.FileHelper;

import org.apache.log4j.Logger;

/**
 * The <code>SaveImage</code> stage writes data from an input stream in the
 * request to a file in the file system.
 * 
 * The Path and FileName request parameters specify the location of the file,
 * relative to the base path specified in the Images.RootFolder application
 * property.
 */
public class SaveImage extends AbstractPipelineStage {

    private static final Logger LOG = Logger.getLogger(SaveImage.class);

    private final String fileSeparator = System.getProperty("file.separator");

    /*
     * (non-Javadoc)
     * 
     * @see com.intentia.iec.pipeline.runtime.AbstractPipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
     */
    public final void execute(final PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("Inside SaveImage.execute()");

        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Request must be of type 'XMLRequest'!");
        }
        XMLRequest xmlRequest = (XMLRequest) context.getRequest();
        try {
            XMLRequest.extractRequestParameters(xmlRequest);
        } catch (RequestException e) {
            throw new PipelineRuntimeException("Error parsing request parameters.", e);
        }
        Parameters params = xmlRequest.getParameters();
        InputStream input = xmlRequest.getInputStream();

        String fileName = null;
        String relativePath = null;
        try {
            fileName = params.getString("FileName");
            relativePath = params.getString("Path");
        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Error reading request parameters.", e);
        }

        String root = StageUtilityHelper.getAppDataImagesRootFolder();
        if (null == root) {
            throw new PipelineRuntimeException("Application Detail Images rootFolder not set.");
        }
        StringBuffer imagePath = new StringBuffer(root);
        imagePath.append(fileSeparator).append(replace(relativePath, "/", fileSeparator));

        File imageCatalogFolder = new File(imagePath.toString());
        if (!imageCatalogFolder.exists()) {
            if (!imageCatalogFolder.mkdirs()) {
                throw new PipelineRuntimeException("Error creating image folder: " + imagePath);
            }
        }

        imagePath.append(fileSeparator).append(fileName);
        File file = new File(imagePath.toString());
        try {
            FileHelper.copy(input, file);
        } catch (IOException e1) {
            throw new PipelineRuntimeException("Error writing image file.", e1);
        } finally {
            file = null;
        }
    }

    private String replace(final String str, final String pattern, final String replace) {
        int s = 0;
        int e = 0;
        StringBuffer result = new StringBuffer(str.length());

        while ((e = str.indexOf(pattern, s)) >= 0) {
            result.append(str.substring(s, e));
            result.append(replace);
            s = e + pattern.length();
        }
        result.append(str.substring(s));
        return result.toString();
    }
}
