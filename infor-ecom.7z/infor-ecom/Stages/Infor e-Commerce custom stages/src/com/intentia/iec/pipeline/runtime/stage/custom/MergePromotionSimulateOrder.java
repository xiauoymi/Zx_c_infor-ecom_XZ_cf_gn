package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;
import java.util.Map;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

/**
 * @author mumali
 * Merge details from Shadow Order tables with the Current order in the resultset
 */
public class MergePromotionSimulateOrder implements PipelineStage {
	
	private static final Logger LOG = Logger.getLogger(MergePromotionSimulateOrder.class);
	private XMLRequest xmlRequest = null;
	private XMLResultset xmlResultSet = null;
	private String orderID = null;
	private XMLResultset shadowOrderRS = null;
	private int currentOrderLineSize = 0;
	private int shadowOrderLineCount = 0;

	public void execute(PipelineContext context) throws PipelineRuntimeException {
		
		//CHECK IF M3 ENABLED AND SIMULATE ORDER ENABLED 
		if (!(("true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.CONNECTORENABLED)))
				|| ("true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.SIMULATE_ORDER))))) {
            return;
        }
		
		if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
		
        this.xmlRequest = (XMLRequest) context.getRequest();
        this.xmlResultSet = (XMLResultset) context.getResponse();
        
        try {
			this.orderID = this.getParameterFromRequest(ConstantsForSales.ORDER_ID_PARAM);
		} catch (ParametersException e) {
			String msg ="No ORDER ID";
			throw new PipelineRuntimeException(msg, e);
		}
        
        try {
        	
			compareShadowOrder();
			updateHeaderDetails();
			
			
			LOG.debug("AFTER MERGE : "+xmlResultSet);
		} catch (ResultsetException e) {
			throw new PipelineRuntimeException(e);
		} catch (ParametersException e) {
			throw new PipelineRuntimeException(e);
		}
	}
	
	private void compareShadowOrder() throws ResultsetException, ParametersException{
		retrieveShadowOrder();
		shadowOrderLineCount = shadowOrderRS.rowCount();
		if (shadowOrderRS == null || shadowOrderRS.isEmpty()) {
			return;
		}
		XMLIterator currentOrderLine = (XMLIterator) xmlResultSet.getResultset(ConstantsForSales.ORDERLINE);
		currentOrderLine.beforeFirst();
		currentOrderLineSize = currentOrderLine.rowCount();
		
		//CHECK UNAVAILABLE ITEMS
    	while (currentOrderLine.moveNext()) {
    		boolean lineExist = lineExistFromShadowOrder(currentOrderLine);
    		currentOrderLine.appendField(ConstantsForSales.LINE_SUFFIX, "0");
    		if(!lineExist){
    			updRsAttr(currentOrderLine, ConstantsForSales.ORDERLINESTATUSID, "90");
                updRsAttr(currentOrderLine, ConstantsForSales.ORDERLINESTATUS, "Deleted");
    		}
    	}
    	
    	//ADD NON EXISTING LINES
    	if(shadowOrderLineCount > currentOrderLineSize){
    		compareOrderLines();
    	}
	}
	
	private boolean lineExistFromShadowOrder(XMLIterator currentOrderLine) throws ResultsetException{
		double lineNumber = Double.parseDouble(n20(currentOrderLine.getString(ConstantsForSales.LINE_NUMBER)));
		double lineSuffix = 0;
		shadowOrderRS.moveFirst();
		XMLIterator shadowOrderLine = (XMLIterator) shadowOrderRS.getResultset(ConstantsForSales.SHADOW_ORDERLINE);
		shadowOrderLine.beforeFirst();
		while (shadowOrderLine.moveNext()) {
			double shadowLineNumber = Double.parseDouble(shadowOrderLine.getString(ConstantsForSales.DEMAND_LINE_NO));
			double shadowLineSuffix = Double.parseDouble(shadowOrderLine.getString(ConstantsForSales.LINE_SUFFIX));
			if(lineNumber == shadowLineNumber && lineSuffix == shadowLineSuffix){
				updRsAttr(currentOrderLine, ConstantsForSales.CONFIRMED_DELIVERY_DATE, shadowOrderLine.getString(ConstantsForSales.CONFIRMED_DELIVERY_DATE));
				updRsAttr(currentOrderLine, ConstantsForSales.RESELLPRICE, shadowOrderLine.getString(ConstantsForSales.SALES_PRICE));
				updRsAttr(currentOrderLine, ConstantsForSales.LINEPRICE, shadowOrderLine.getString(ConstantsForSales.LINEPRICE));
				updRsAttr(currentOrderLine, ConstantsForSales.LINETOTAL, shadowOrderLine.getString(ConstantsForSales.NET_LINE_AMOUNT));
				updRsAttr(currentOrderLine, ConstantsForSales.MVXWAREHOUSE, shadowOrderLine.getString(ConstantsForSales.MVXWAREHOUSE));
				updLineDiscount(currentOrderLine, shadowOrderLine);
				return true;
			}
		}
		return false;
	}
	
	private void compareOrderLines() throws ResultsetException{
		shadowOrderRS.moveFirst();
		XMLIterator shadowOrderLine = (XMLIterator) shadowOrderRS.getResultset(ConstantsForSales.SHADOW_ORDERLINE);
		shadowOrderLine.beforeFirst();
		while (shadowOrderLine.moveNext()) {
			double shadowLineNumber = Double.parseDouble(shadowOrderLine.getString(ConstantsForSales.DEMAND_LINE_NO));
			double shadowLineSuffix = Double.parseDouble(shadowOrderLine.getString(ConstantsForSales.LINE_SUFFIX));
			XMLIterator currentOrderLine = (XMLIterator) xmlResultSet.getResultset(ConstantsForSales.ORDERLINE);
			currentOrderLine.beforeFirst();
			boolean lineExist = false;
			while (currentOrderLine.moveNext()) {
				double currentLineNumber = Double.parseDouble(n20(currentOrderLine.getString(ConstantsForSales.LINE_NUMBER)));
				double lineSuffix = 0;
				if(shadowLineNumber == currentLineNumber &&  shadowLineSuffix == lineSuffix) {
					lineExist = true;
					break;
				} 
			}
			if(!lineExist){
				addNonExistingLines(currentOrderLine, shadowOrderLine);
			}
		}
	}
	
	private void addNonExistingLines(XMLIterator currentOrderLine, XMLIterator shadowOrderLine) throws ResultsetException {
		currentOrderLine.appendRow();
		for (Map.Entry<String, String> entry : ConstantsForSales.getCurrent_ShadowOrderLineMapping().entrySet()) {
			updRsAttr(currentOrderLine,  entry.getKey(), shadowOrderLine.getString(entry.getValue()));
		}
	}
	
	private void updLineDiscount(XMLIterator currentOrderLine, XMLIterator shadowOrderLine) throws ResultsetException {

        BigDecimal lineDiscount = getDecimal(shadowOrderLine.getString(ConstantsForSales.DISCOUNT1));
        lineDiscount = lineDiscount.add(getDecimal(shadowOrderLine.getString(ConstantsForSales.DISCOUNT2)));
        lineDiscount = lineDiscount.add(getDecimal(shadowOrderLine.getString(ConstantsForSales.DISCOUNT3)));
        lineDiscount = lineDiscount.add(getDecimal(shadowOrderLine.getString(ConstantsForSales.DISCOUNT4)));
        lineDiscount = lineDiscount.add(getDecimal(shadowOrderLine.getString(ConstantsForSales.DISCOUNT5)));
        lineDiscount = lineDiscount.add(getDecimal(shadowOrderLine.getString(ConstantsForSales.DISCOUNT6)));

        updRsAttr(currentOrderLine, ConstantsForSales.LINEDISCOUNT, lineDiscount.toString());
    }
	
	private void updateHeaderDetails() throws ResultsetException{
		shadowOrderRS.moveFirst();
		xmlResultSet.moveFirst();
		if (shadowOrderRS.rowCount() > 0 && xmlResultSet.rowCount() > 0) {
			for (Map.Entry<String, String> entry : ConstantsForSales.getCurrent_ShadowOrderHeaderMapping().entrySet()) {
				updRsAttr(xmlResultSet,  entry.getKey(), shadowOrderRS.getString(entry.getValue()));
			}
		}
	}
	
	private void retrieveShadowOrder() throws ParametersException{
		SearchPipelineExecuter pipeline = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                "ShadowOrder", "GetShadowOrderByOrderID");
    	pipeline.setParam("@LanguageCode", this.getParameterFromRequest(ConstantsForSales.LANGUAGE_CODE_PARAM));
    	pipeline.setParam("@MvxWarehouse", this.getParameterFromRequest(ConstantsForSales._MVXWAREHOUSE_PARAM));
    	pipeline.setParam("@UserGroupID", this.getParameterFromRequest(ConstantsForSales._USERGROUPID_PARAM));
    	pipeline.setParam("@UserID", this.getParameterFromRequest(ConstantsForSales.USER_ID_PARAM));
    	pipeline.setParam("altExchangeRate", this.getParameterFromRequest(ConstantsForSales.ALT_EXCHANGE_RATE_PARAM));
    	pipeline.setParam("exchangeRate", this.getParameterFromRequest(ConstantsForSales.EXCHANGE_RATE_PARAM));
    	pipeline.setParam("orderID", this.orderID);
    	
		try {
			shadowOrderRS = pipeline.execute();
		} catch (PipelineRuntimeException e) {
			e.printStackTrace();
		}
	}
	
	private String getParameterFromRequest(String param) throws ParametersException{
		return xmlRequest.getParameters().getString(param);
	}
	
	private String updRsAttr(final XMLIterator rs, final String rsPar, final String value) {
        return CustomStagesHelper.updateRsAttribute(rs, rsPar, value);
    }
	
	private String updRsAttr(final XMLResultset rs, final String rsPar, final String value) {
        return CustomStagesHelper.updateRsAttribute(rs, rsPar, value);
    }
	
	private BigDecimal getDecimal(String value){
		if(value!=null){
			return new BigDecimal(value);
		}
		return new BigDecimal(0);
	}
	
	private String n20(String value){
		if(value == null) return "0";
		else return value;
	}

}
