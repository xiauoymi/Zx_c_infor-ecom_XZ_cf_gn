package com.intentia.iec.pipeline.runtime.stage.custom.creditcard;

import java.math.BigDecimal;
import java.util.Set;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.creditcard.dao.CreditCardDao;
import com.intentia.iec.pipeline.runtime.integration.creditcard.dao.factory.DaoFactory;
import com.intentia.iec.pipeline.runtime.integration.creditcard.exception.CreditCardConnectionException;
import com.intentia.iec.pipeline.runtime.integration.creditcard.exception.CreditCardException;
import com.intentia.iec.pipeline.runtime.integration.creditcard.model.CardType;
import com.intentia.iec.pipeline.runtime.integration.creditcard.model.CreditCard;
import com.intentia.iec.pipeline.runtime.integration.creditcard.model.Payment;
import com.intentia.iec.pipeline.runtime.integration.creditcard.model.TransactionResult;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.sun.jms.util.Log;

public class AuthorizeCreditCardPaymentStage extends AbstractPipelineStage {

	private static final Logger log = Logger
			.getLogger(AuthorizeCreditCardPaymentStage.class);
	
	@Override
	public void execute(PipelineContext context) throws PipelineRuntimeException {
		//get params from pipeline
		log.debug("Start AuthorizeCreditCardPayment.execute() . . .");

		CustomStagesHelper.extractRequestParameters(CustomStagesHelper
				.getRequest(context));

		XMLRequest request = (XMLRequest) context.getRequest();
		Parameters requestParams = request.getParameters();
		TransactionResult transactionResult = getTransactionResult(requestParams);
		XMLResultset resultset = getResponse(context);
		
		log.debug("AuthorizeCreditCardPaymentStage.java ================ Is transactionResult null? " + (transactionResult == null));
		log.debug("AuthorizeCreditCardPaymentStage.java ================ auth num: " + transactionResult.getAuthorizationNumber());
		log.debug("AuthorizeCreditCardPaymentStage.java ================ ref num: " + transactionResult.getReferenceNumber());
		log.debug("AuthorizeCreditCardPaymentStage.java ================ is successful: " + transactionResult.isSuccessful());
		
		CustomStagesHelper.setResponseParameter(context, "authNumber", transactionResult.getAuthorizationNumber());
		CustomStagesHelper.setResponseParameter(context, "authResult", String.valueOf(transactionResult.isSuccessful()));
		CustomStagesHelper.setResponseParameter(context, "refNumber", transactionResult.getReferenceNumber());
		CustomStagesHelper.setResponseParameter(context, "authAmount", transactionResult.getActualAuthorizedAmount().toString());
		CustomStagesHelper.setResponseParameter(context, "responseCode", transactionResult.getResponseCode().toString());
		CustomStagesHelper.setResponseParameter(context, "responseMessage", transactionResult.getResponseMessage().toString());
	}

	private TransactionResult getTransactionResult(Parameters requestParams) {
		Payment payment = new Payment();
		CreditCard creditCard = new CreditCard();
		TransactionResult result = new TransactionResult();
		
		try {
			creditCard.setToken(requestParams.getString("paymentToken"));
			payment.setAmount(new BigDecimal(requestParams.getString("grandTotal")));
			creditCard.setNameOnCard(requestParams.getString("nameOnCard"));
			if (requestParams.getString("cvvNum") != null) {
				creditCard.setCvvNumber(requestParams.getString("cvvNum"));
				log.debug("AuthorizeCreditCardPaymentStage.java ================ cvvNum: " + creditCard.getCvvNumber());
			}
			log.debug("AuthorizeCreditCardPaymentStage.java ================ paymentToken: " + creditCard.getToken());
			log.debug("AuthorizeCreditCardPaymentStage.java ================ grandTotal: " + payment.getAmount());
			log.debug("AuthorizeCreditCardPaymentStage.java ================ nameOnCard: " + creditCard.getNameOnCard());
			
			CreditCardDao dao = DaoFactory.getDAOFactory().getCreditCardDao();
			result = dao.authorize(creditCard, payment);

			log.debug("Credit Card Authorization : " + result);
		} catch (CreditCardConnectionException e) {
			log.error(
					"Error while connecting to Credit Card Web Service",
					e);
		} catch (ParametersException e) {
			log.error(
					"Error getting parameter",
					e);
		} catch (CreditCardException e) {
			log.error(
					"Error with credit card information",
					e);
		} catch (Exception e) {
			log.error(
					"Error while attempting to authorize card",
					e);
		}
		return result;
	}
}
