/*
 * Created on 22-03-2006
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.w3c.dom.Node;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.utils.ApplicationMail;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

/**
 * <p>
 * The stage sends user information as mail if a parameter is true. The e-mail
 * (receiver) is extracted from the request. The mail server and sender is the
 * one defined for the application.
 * <p>
 * </p>
 * The text for the mail is retrieved from the text table (section given by the
 * mail text page parameter). The stage extracts user information from the
 * request, and password from a request parameter and the information is then
 * patched into a set of texts
 * </p>
 * <p>
 * <b>Input in <code>PipelineContext</code>:</b>
 * </p>
 * <p>
 * Request Parameters:
 * <ul>
 * <li><code>&#64;sendMail</code></li>
 * <li><code>&#64;generatedPassword</code></li>
 * <li><code>&#64;url</code></li>
 * <li><code>&#64;word</code></li>
 * <li><code>&#64;LanguageCode</code> (mandatory)</li>
 * <li><code>&#64;mailTextPage</code> (mandatory)</li>
 * </ul>
 * The parameter <code>&#64;sendMail</code> have to be true - otherwise no
 * mail is sent. The parameter <code>&#64;mailTextPage</code> tells what text
 * section to retrieve and use for generating the e-mail to the user. The
 * parameter <code>&#64;generatedPassword</code> tells what text section to
 * retrieve and use for generating the e-mail to the user. The parameters
 * <code>&#64;url</code> and <code>&#64;word</code> are alone for passing a
 * text, which will be patched into the mail body.
 * </p>
 * <p>
 * Attributes used for pathcing variables:
 * <ul>
 * <li><code>FirstName</code></li>
 * <li><code>MiddleName</code></li>
 * <li><code>LastName</code></li>
 * <li><code>Email</code></li>
 * </ul>
 * </p>
 * <p>
 * Recognised variables in the text:
 * <ul>
 * <li><code>${email}</code></li>
 * <li><code>${username}</code></li>
 * <li><code>${password}</code></li>
 * <li><code>${url}</code></li>
 * <li><code>${word}</code></li>
 * </ul>
 * </p>
 * <p>
 * </p>
 */
/*
 * The text uses the character code &#64; for @ to avoid to confuse the Java
 * auto formatter.
 */
public class SendUserInfoAsMail extends AbstractPipelineStage {

    private static final Logger LOG = Logger.getLogger(SendUserInfoAsMail.class);

    private static final String ENTITY_XPATH = "/request/entities/entity";

    // Input parameters to this stage.
    private static final String TEXT_PARAMETER = "@mailTextPage";

    private static final String LANGUAGE_PARAMETER = "@LanguageCode";

    private static final String SEND_MAIL_PARAMETER = "@sendMail";

    private static final String GENERATED_PASSWORD_PARAMETER = "@generatedPassword";

    private static final String URL_PARAMETER = "@url";

    private static final String WORD_PARAMETER = "@word";

    // Text names
    private static final String SUBJECT = "subject";

    // Allowed variables in message body
    private static final String PASSWORD_VARIABLE = "${password}";

    private static final int PASSWORD_VARIABLE_LENGTH = PASSWORD_VARIABLE.length();

    private static final String EMAIL_VARIABLE = "${email}";

    private static final int EMAIL_VARIABLE_LENGTH = EMAIL_VARIABLE.length();

    private static final String USERNAME_VARIABLE = "${username}";

    private static final int USERNAME_VARIABLE_LENGTH = USERNAME_VARIABLE.length();

    private static final String URL_VARIABLE = "${url}";

    private static final int URL_VARIABLE_LENGTH = URL_VARIABLE.length();

    private static final String WORD_VARIABLE = "${word}";

    private static final int WORD_VARIABLE_LENGTH = WORD_VARIABLE.length();

    private static final String NEWLINE_VARIABLE = "${nl}";

    private static final int NEWLINE_VARIABLE_LENGTH = NEWLINE_VARIABLE.length();

    // Internal variables
    private XMLRequestHelper requestHelper = null;

    private Parameters parameters = null;

    private Node entityNode = null;

    /*
     * (non-Javadoc) Pipeline entry point.
     */
    public void execute(final PipelineContext context) throws PipelineRuntimeException {

        // Verify type of request
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Request MUST be of type XMLRequest!");
        }

        XMLRequest request = (XMLRequest) context.getRequest();

        try {
            XMLRequest.extractRequestParameters(request);
            entityNode = XMLRequestHelper.getRequestNode(request, ENTITY_XPATH);
            if (entityNode == null) {
                LOG.debug("The request does not hold an entity node!");
                return;
            }
            parameters = request.getParameters();
            requestHelper = new XMLRequestHelper(request);

            // Get parameters from pipeline
            Boolean sendMail = parameters.getBoolean(SEND_MAIL_PARAMETER);
            if ((sendMail == null) || (!sendMail.booleanValue())) {
                LOG.debug("The attribute @sendMail is not true. Aborting mailing!");
                return;
            }
            String languageCode = parameters.getString(LANGUAGE_PARAMETER);
            String pageName = parameters.getString(TEXT_PARAMETER);

            XMLResultset rsText = getMailText(languageCode, pageName);
            if (!rsText.moveFirst()) {
                LOG.error("Couldn't find text section '" + pageName + "'. Aborting mailing.");
                return;
            }

            // Extract subject from text section
            String subject = null;
            StringBuffer body = new StringBuffer();
            String newLine = System.getProperty("line.separator");
            int pos;

            do {
                String name = rsText.getString("Name");
                if (SUBJECT.equals(name)) {
                    subject = rsText.getString("Text");
                } else {
                    StringBuffer lineText = new StringBuffer();
                    lineText.append(rsText.getString("Text"));
                    pos = lineText.indexOf(NEWLINE_VARIABLE);
                    if (pos > 0)
                        lineText.replace(pos, pos + NEWLINE_VARIABLE_LENGTH, newLine);
                    body.append(lineText);
                    body.append(newLine);
                }
            } while (rsText.moveNext());

            if ((subject == null) || (body.length() == 0)) {
                LOG.info("No subject or body given. Aborting mailing!");
                return;
            }

            // Build the user name
            String firstName = requestHelper.getAttribute(entityNode, ConstantsForSales.FIRST_NAME_ATTRIBUTE);
            String middleName = requestHelper.getAttribute(entityNode, ConstantsForSales.MIDDLE_NAME_ATTRIBUTE);
            String lastName = requestHelper.getAttribute(entityNode, ConstantsForSales.LAST_NAME_ATTRIBUTE);
            StringBuffer userName = new StringBuffer();
            if (firstName != null) {
                userName.append(firstName);
                userName.append(" ");
            }
            if (middleName != null) {
                userName.append(middleName);
                userName.append(" ");
            }
            if (lastName != null) {
                userName.append(lastName);
            }

            // Get the e-mail address to send the mail to as the request
            // attribute.
            String email = requestHelper.getAttribute(entityNode, ConstantsForSales.EMAIL_ATTRIBUTE);

            // Extract the generated password from the request
            String generatedPassword = parameters.getString(GENERATED_PASSWORD_PARAMETER);
            // Extract extra words to patch into the body
            String url = parameters.getString(URL_PARAMETER);
            String word = parameters.getString(WORD_PARAMETER);

            // Patch the variables in the body
            pos = body.indexOf(PASSWORD_VARIABLE);
            if ((pos >= 0) && (generatedPassword != null)) {
                body.replace(pos, pos + PASSWORD_VARIABLE_LENGTH, generatedPassword);
            }
            pos = body.indexOf(EMAIL_VARIABLE);
            if ((pos >= 0) && (email != null)) {
                body.replace(pos, pos + EMAIL_VARIABLE_LENGTH, email);
            }
            pos = body.indexOf(USERNAME_VARIABLE);
            if (pos >= 0) {
                body.replace(pos, pos + USERNAME_VARIABLE_LENGTH, userName.toString());
            }
            pos = body.indexOf(URL_VARIABLE);
            if ((pos >= 0) && (url != null)) {
                body.replace(pos, pos + URL_VARIABLE_LENGTH, url);
            }
            pos = body.indexOf(WORD_VARIABLE);
            if ((pos >= 0) && (word != null)) {
                body.replace(pos, pos + WORD_VARIABLE_LENGTH, word);
            }

            try {
                // Send the mail via the application mail server
                ApplicationMail.send(email, subject, body.toString());
            } catch (Exception e) {
                LOG.error("Unable to send email notification!", e);
            }

        } catch (RequestException e) {
            throw new PipelineRuntimeException("Failed to operate on request", e);
        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Failed to get parameter from request", e);
        } catch (TransformerException e) {
            throw new PipelineRuntimeException("Failed to get attribute from request", e);
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Failed to operate on resultset", e);
        }
    }

    private XMLResultset getMailText(final String languageCode, final String pageName) throws PipelineRuntimeException {

        // Business object
        final String textObject = "SiteText";

        // Method to call to get locale ID.
        final String textMethod = "GetSortedPageText";

        // Input parameters to the search stage.
        final String pageNameParameter = "@pageName";

        final String languageParameter = LANGUAGE_PARAMETER;

        // Get texts for mail
        // Get ID for the user with the given e-mail.
        SearchPipelineExecuter searchText = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, textObject,
                textMethod);
        searchText.setParam(languageParameter, languageCode);
        searchText.setParam(pageNameParameter, pageName);
        return searchText.execute();
    }
}
