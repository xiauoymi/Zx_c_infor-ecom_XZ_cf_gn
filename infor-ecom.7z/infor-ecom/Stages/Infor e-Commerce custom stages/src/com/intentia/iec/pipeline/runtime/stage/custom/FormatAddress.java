/*
 * Created on 08-03-2006
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.sqlserver.common.DatabaseType;
import com.intentia.iec.sqlserver.runtime.procedure.Parameter;
import com.intentia.iec.sqlserver.runtime.procedure.StageCallProcedure;

/**
 * <p>
 * The <code>FormatAddress</code> class contains mutual declarations and
 * methods used in the two stages <code>FormatAddressInRequest</code> and
 * <code>FormatAddressInResult</code>.
 * </p>
 */
public class FormatAddress {

    /**
     * Input parameter for stage - determines the attribute subset.
     */
    public static final String SUBSET_PARAMETER = "subset";

    /**
     * Input parameter for stage - determines the attribute prefix.
     */
    public static final String PREFIX_PARAMETER = "prefix";

    /**
     * Attribute (input) used for country code.
     */
    public static final String COUNTRY_ATTRIBUTE = "CountryID";

    /**
     * Attribute (input) used for state code.
     */
    public static final String STATE_ATTRIBUTE = "StateID";

    /**
     * Attribute (input) used for city.
     */
    public static final String CITY_ATTRIBUTE = "City";

    /**
     * Attribute (input) used for zip / postal code.
     */
    public static final String ZIP_ATTRIBUTE = "Zip";

    /**
     * Attribute where address3 is stored.
     */
    public static final String ADDRESS3_ATTRIBUTE = "Address3";

    /**
     * Attribute where address4 is stored.
     */
    public static final String ADDRESS4_ATTRIBUTE = "Address4";

    // Internal variables
    private String address3 = null;

    private String address4 = null;

    /**
     * Create an instance for formatting addresses.
     */
    public FormatAddress() {
    }

    /**
     * Format the address by calling stored procedure FormatAddress. The
     * formatted fields address3 and address4 can be extracted calling the
     * methods getAddress3 and getAddress4 afterwards.
     * 
     * @param countryCode
     * @param stateCode
     * @param city
     * @param zip
     * 
     * @throws PipelineRuntimeException
     */
    protected final void format(final String countryCode, final String stateCode, final String city, final String zip)
            throws PipelineRuntimeException {

        StageCallProcedure procedure = new StageCallProcedure("EXEC FormatAddress ?, ?, ?, ?, ?, ?",
                ConstantsForSales.DATABASE_CONNECTION_KEY);

        procedure.addInputParam("@countryCode", 1, DatabaseType.VARCHAR, Parameter.CONSTANT, countryCode);
        procedure.addInputParam("@stateCode", 2, DatabaseType.VARCHAR, Parameter.CONSTANT, stateCode);
        procedure.addInputParam("@city", 3, DatabaseType.VARCHAR, Parameter.CONSTANT, city);
        procedure.addInputParam("@zip", 4, DatabaseType.VARCHAR, Parameter.CONSTANT, zip);

        procedure.addOutputParam("@address3", 5, DatabaseType.VARCHAR, Parameter.PIPELINE_CONTEXT, ADDRESS3_ATTRIBUTE);
        procedure.addOutputParam("@address4", 6, DatabaseType.VARCHAR, Parameter.PIPELINE_CONTEXT, ADDRESS4_ATTRIBUTE);

        // create separate context for call to procedure
        PipelineContext procedureContext = new PipelineContext();
        procedure.execute(procedureContext);

        // Extract return parameters.
        address3 = (String) procedureContext.get(ADDRESS3_ATTRIBUTE);
        address4 = (String) procedureContext.get(ADDRESS4_ATTRIBUTE);
    }

    /**
     * @return The address3 field of the formatted address. To be called after
     *         calling formatting.
     */
    public final String getAddress3() {
        return address3;
    }

    /**
     * @return The address4 field of the formatted address. To be called after
     *         calling formatting.
     */
    public final String getAddress4() {
        return address4;
    }
}
