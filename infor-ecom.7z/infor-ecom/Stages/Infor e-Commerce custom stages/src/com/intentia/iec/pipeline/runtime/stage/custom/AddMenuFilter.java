/*
 * Created on 29-05-2006
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.util.FastStringBuffer;
import com.intentia.iec.util.PropertyLoader;

/**
 * This custom stage is important for the feature: <b>Control a menues presents
 * by an application property</b>. The custom stage reads the application
 * properties from the generated file
 * "../&lt;appName&gt;.ear/config/application.properties" and creates bindings
 * from these to filter the menues returned by the search stage being next in
 * the method pipeline. Note that the application.properties file just contains
 * the <i>Application Property Groups</i> values seen in the Design Center
 * Application Properties tabs.
 * 
 * The bindings are created such that
 * <ol>
 * <li>Menues where the business object attribute 'Menu.AppProperty' has the
 * value of <code>NULL</code> are included in the result.</li>
 * <li>Menues where the value of the business object attribute
 * 'Menu.AppProperty' is an application property name and this application
 * property has the value of <code>true</code> are inluded in the result.</li>
 * </ol>
 * 
 * @author pedjes0
 */
public class AddMenuFilter extends AbstractPipelineStage {
    private static final Logger LOG = Logger.getLogger(AddMenuFilter.class);

    private static final String REQUEST_START = "<?xml version='1.0' encoding='UTF-8'?><request><params><param name='@LanguageCode'>";

    private static final String REQUEST_MID = "</param><param name='@UserID'>";

    private static String requestEnd = null;

    private static boolean initialized = false;

    public static void initializeBindings() {
        if (!initialized) {
            // If requestEnd is already initialized then there is no reason to
            // enter the synchronized (and performance consuming) block.
            synchronized (AddMenuFilter.class) {
                // check initialization again just in case
                if (requestEnd == null) {
                    if (LOG.isDebugEnabled()) {
                        LOG.debug("Initializing menu bindings based on application properties.");
                    }

                    boolean falseBindings = false;

                    FastStringBuffer end = new FastStringBuffer();
                    end.append("</param></params><search>");
                    end.append("<bindings operator='or'><bindings operator='and'>");
                    end.append("<binding attribute='AppProperty' operator='null'/>");
                    end.append("</bindings>");

                    Properties props = PropertyLoader.loadProperties("/application.properties");
                    Iterator entries = props.entrySet().iterator();
                    while (entries.hasNext()) {
                        Map.Entry entry = (Map.Entry) entries.next();
                        if ("false".equals(entry.getValue())) {
                            if (!falseBindings) {
                                // Only build this <bindings> and clause if
                                // application properties with value 'false'
                                // exist.
                                end.append("<bindings operator='and'>");
                                falseBindings = true;
                            }

                            end.append("<binding attribute='AppProperty' operator='ne' value='");
                            end.append(entry.getKey().toString());
                            end.append("'/>");
                        }
                    }

                    if (falseBindings) {
                        end.append("</bindings>");
                    }

                    end.append("</bindings></search>");
                    end.append("</request>");

                    requestEnd = end.toString();
                    initialized = true;
                    if (LOG.isDebugEnabled()) {
                        LOG.debug("Finished initializing menu bindings.");
                    }
                }
            }
        }
    } /*
         * 
         */

    public final void execute(final PipelineContext context) throws PipelineRuntimeException {
        initializeBindings();

        if (context.getRequest() == null) {
            if (LOG.isDebugEnabled()) {
                LOG.debug("Request not available. Ending stage execution!");
            }
            return;
        }

        try {
            XMLRequest request = getRequest(context);
            XMLRequest.extractRequestParameters(request);

            // Create new request containing the expected parameters and the
            // application property bindings
            FastStringBuffer buffer = new FastStringBuffer();
            buffer.append(REQUEST_START);
            buffer.append(request.getParameters().getString("@LanguageCode"));
            buffer.append(REQUEST_MID);
            buffer.append(request.getParameters().getString("@UserID"));
            // use the staticly build request end including necessary bindings
            buffer.append(requestEnd);

            XMLRequest createdRequest = new XMLRequest(buffer.toString());

            if (LOG.isDebugEnabled()) {
                FastStringBuffer debug = new FastStringBuffer("Replacing request: ");
                debug.append(request.getRequestString());
                debug.append(" with request: ");
                debug.append(createdRequest.getRequestString());
                LOG.debug(debug.toString());
            }

            context.setRequest(createdRequest);
        } catch (ParametersException e) {
            throw new PipelineRuntimeException(e);
        } catch (RequestException e) {
            throw new PipelineRuntimeException(e);
        }
    }
}
