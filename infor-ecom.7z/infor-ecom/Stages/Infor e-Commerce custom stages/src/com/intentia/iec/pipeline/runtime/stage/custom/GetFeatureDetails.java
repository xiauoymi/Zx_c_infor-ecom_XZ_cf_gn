package com.intentia.iec.pipeline.runtime.stage.custom;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;

public class GetFeatureDetails implements PipelineStage {
    
    private static final Logger LOG = Logger.getLogger(GetFeatureDetails.class);
    
    private static final String SEQUENTIAL_CONFIG_ENABLED = "Items.Sequential configurator";
    
    private XMLRequest xmlRequest = null;
    
    public void execute(final PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("Entering GetFeatureDetails.execute()");
        
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
        xmlRequest = (XMLRequest) context.getRequest();

        try {
            XMLRequest.extractRequestParameters(xmlRequest);
        } catch (RequestException e) {
            throw new PipelineRuntimeException("Error extracting request parameters!", e);
        }
        
        //Movex connector not enabled => skip stage
        if (!"true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.CONNECTORENABLED))) {
            return;
        }

        if (!"true".equals(CustomStagesHelper.getKeyValue(SEQUENTIAL_CONFIG_ENABLED))) {
            return;
        }
        
		String mvxCompany = getCompany();
        String featureId = getFeatureIdParam();
        String featureType = getFeatureTypeParam();
        
        //TODO: Call PDS055MI.Get ????
        
		//Replace the following lines with the actual retrieval logic
		//Start of lines to be replaced
        StringBuffer buf = new StringBuffer("");
        buf.append("<?xml version='1.0' encoding='UTF-8'?>");
        buf.append("<resultset object='DoesNotMatter'>");
        buf.append("</resultset>");

        String response = buf.toString();
        context.setResponse(new XMLResultset(response));
		
		String textMaxLength = "60";
		String textMaxRows = "5";
		String textFilter = "1";
        
        if ("TXT3".equals(featureId)) {					
			textMaxLength = "0";
			textMaxRows = "0";
		}
		
		LOG.debug("Set TextMaxLength = " + textMaxLength);
		CustomStagesHelper.setResponseParameter(context, "TextMaxLength", textMaxLength);        
		
		LOG.debug("Set TextMaxRows = " + textMaxRows);
		CustomStagesHelper.setResponseParameter(context, "TextMaxRows", textMaxRows); 
		
		LOG.debug("Set TextFilter = " + textFilter);
        CustomStagesHelper.setResponseParameter(context, "TextFilter", textFilter);

		//End of lines to be replaced		
        
        LOG.debug("Exiting GetFeatureDetails.execute()");
    }
    
    private String getFeatureIdParam() {
        LOG.debug("Entering GetFeatureDetails.getFeatureIdParam");
        String featureId = "";
        try {
            featureId = xmlRequest.getParameters().getString("FeatureID");
            LOG.debug("FeatureID :" + featureId);
        } catch (ParametersException e) {
            LOG.debug("FeatureID is not in the request parameters.");
        }
        LOG.debug("Exiting GetFeatureDetails.getFeatureIdParam");
        return featureId;
    }
    
    private String getFeatureTypeParam() {
        LOG.debug("Entering GetFeatureDetails.getFeatureType");
        String featureType = "";
        try {
            featureType = xmlRequest.getParameters().getString("FeatureType");
            LOG.debug("FeatureType :" + featureType);
        } catch (ParametersException e) {
            LOG.debug("FeatureType is not in the request parameters.");
        }
        LOG.debug("Exiting GetFeatureDetails.getFeatureType");
        return featureType;
    }
	
	private String getCompany() {
        LOG.debug("Entering GetFeatureDetails.getCompany");
        String mvxCompany = "";
        try {
            mvxCompany = xmlRequest.getParameters().getString(ConstantsForSales.MVXCOMPANY);
            LOG.debug("MvxCompany :" + mvxCompany);
        } catch (ParametersException e) {
            LOG.debug("MvxCompany is not in the request parameters.");
        }
        LOG.debug("Exiting GetFeatureDetails.getCompany");
        return mvxCompany;
    }

}
