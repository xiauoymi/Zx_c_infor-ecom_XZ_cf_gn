/*
 * Created on 03-03-2004
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.util.HashSet;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.*;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.DeletePipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Types;




/**
 * <p>
 * The <code>HandleOrderLines</code> stage performs order line logic on a
 * commit request. The request is expected to be a collection of order lines
 * committed on the <tt>order</tt> business object. If the commit request is
 * empty then the stage will just execute without any action, since there are no
 * rows/entries to work on. The following operations are performed on the
 * request:
 * <p>
 * <ul>
 * <li> Preparation </li>
 * <li> Internal order line handling </li>
 * <li> External order line handling </li>
 * </ul>
 * <p>
 * <p>
 * <b>Preparation</b>
 * <p>
 * 1. Order lines with <code>null</code> quantities are removed<br>
 * 2. Order lines with non numeric quantities are removed<br>
 * 3. <tt>ShippingCountryID</tt> is set to <code>null</code> if it contains
 * an empty string<br>
 * 4. <tt>Quantity</tt> is set according to the minimum and modular quantity
 * defined for the item<br>
 * <p>
 * <b>Internal order line handling</b>
 * <p>
 * The order lines are compared to each other. If the <tt>ItemID</tt> and the
 * <tt>ConfigurationID</tt> for two order lines are the same, then the order
 * lines are merged (the quantities are added together in one order line and the
 * other is deleted) - unless both order lines are updates to existing order
 * lines and they have different keys, then both are kept.
 * <p>
 * <b>External order line handling</b>
 * <p>
 * The committed order lines are compared to the existing order lines in the
 * database. If the committed quantity is less than or equal to zero, the order
 * line is removed as well as the existing order line in the database (if any).
 * <p>
 * If the quantity is valid and the order line is new and an order line exists
 * in the database with the same <tt>ItemID</tt> (and <tt>ConfigurationID</tt>
 * if any), the new and the existing order line is merged, unless the property
 * <tt>"Ordering.Merge SKU in orderlines"</tt> is set to <tt>false</tt> or
 * if the parameter <tt>noOrderlineMerge</tt> is set to <tt>true</tt>.
 * <p>
 * <p>
 * <b>Required input in <code>PipelineContext</code>:</b><br>
 * The stage requires that the <code>PipelineContext</code> contains a commit
 * request representing order line updates on the order business object.
 * </p>
 * 
 * <p>
 * <b>Generated output in <code>PipelineContext</code>:</b><br>
 * When done the stage has modified the commit request in the
 * <code>PipelineContext</code>.
 * </p>
 * 
 * <b>Movex Connected</b>
 * <p>
 * If the Movex connection is enabled it also gets the latest prices for the
 * current user / user group from Movex for the products in the current request.
 * In case are the following parameters required:<br />
 * Input parameters:<br />
 * <code>mvxCompany</code>, <code>mvxFacility</code>,
 * <code>mvxOrderType</code>, <code>mvxWareHouse</code>,
 * <code>&#64;CurrencyCode</code>, <code>&#64;ListPriceGroup</code>, and
 * <code>UserGroupID</code><br />
 * 
 * Output parameter:<br />
 * <code>mvxStatus</code> (error if negative).
 * </p>
 */
/*
 * The text uses the character code &#64; for @ to avoid to confuse the Java
 * auto formatter.
 */

/*
 * Developer Notes: Before the business logic is performed, all the item ID's of
 * the commit request are converted to upper case in the <tt>makeItemIDsUpperCase</tt>
 * method. This is done because we need the item ID to be case-insensitive and
 * As XPath 1.0 does not support case-insensitive matches.
 */

public class HandleOrderLines implements PipelineStage {

    public static final String DUPLICATE_ORDERLINES = "duplicateOrderLines";

    public static final String DUPLICATE_ORDERLINES2 = "noOrderlineMerge";

    private static final Logger LOG = Logger.getLogger(HandleOrderLines.class);

    private boolean duplicateOrderLines = false;
    
    private String mvxConfiguratorItemID = null;

    private static final double MAX_ORDER_QUANTITY = 999999;

    private String currCode = "";

    private String langCode = "";

    private String mvxWarehouse = "";

    private int userGroup = 0;

    private int user = 0;
    
    private int ordseq = 0;
    
    private String isStyleItem = "";
    
    private XMLRequest xmlRequest = null;

    /**
     * This method executes the stage.
     * 
     * @see com.intentia.iec.pipeline.runtime.PipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
     */
    public void execute(PipelineContext context) throws PipelineRuntimeException {

        // Retreive XML request from context
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
        Document request;
        XMLRequest xmlRequest;
        try {
            CustomStagesHelper.extractRequestParameters(CustomStagesHelper.getRequest(context));
            xmlRequest = (XMLRequest) context.getRequest();
            request = xmlRequest.getRequestDoc();
        } catch (Exception e) {
            throw new PipelineRuntimeException("Failed to obtain XML request document from request", e);
        }
        XMLRequestHelper xmlHelper = new XMLRequestHelper(request);

        // Get property "Ordering.Merge SKU in orderlines"
        String duplicateOrderLinesString = null;
        duplicateOrderLinesString = CustomStagesHelper.getKeyValue("Ordering.Merge SKU in orderlines");
        if (duplicateOrderLinesString != null && duplicateOrderLinesString.matches("false")) {
            duplicateOrderLines = true;
        }

        // If the parameter HandleOrderLines.DUPLICATE_ORDERLINES2 is true,
        // duplicateOrderLines is set
        // to "true", no matter what value "Ordering.Merge SKU in orderlines"
        // contains
        String duplicateOrderLines2String = null;
        Parameters parameters = xmlRequest.getParameters();
        try {
            duplicateOrderLines2String = parameters.getString(HandleOrderLines.DUPLICATE_ORDERLINES2);
            currCode = parameters.getString("@CurrencyCode");
            langCode = parameters.getString("@LanguageCode");
            mvxWarehouse = parameters.getString("@MvxWarehouse");
            isStyleItem = parameters.getString("isConfigurable");
            if (parameters.getString("UserGroup") != null)
                userGroup = Integer.parseInt(parameters.getString("UserGroup"));
            if (parameters.getString("@UserID") != null)
                user = Integer.parseInt(parameters.getString("@UserID"));
        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Failed to obtain " + HandleOrderLines.DUPLICATE_ORDERLINES2
                    + " parameter from request, " + e.getMessage(), e);
        }
        if (duplicateOrderLines2String != null && duplicateOrderLinesString.matches("true")) {
            duplicateOrderLines = true;
        }
        
        Element root = request.getDocumentElement();
        String s = root.toString();
        
        //Check isStyleItem
        if (isStyleItem != null && isStyleItem.equals("Y")){
        	updateVariantItem(request, xmlHelper);
        }
        
        makeItemIDsUpperCase(request, xmlHelper);
        // xmlHelper.logRequest();updateVariantItem
        validateItemsAndRemoveNullQuantities(request, xmlHelper);
        // xmlHelper.logRequest();
        internalOrderlineHandling(request);
        // xmlHelper.logRequest();
        externalOrderlineHandling(context, request, xmlHelper);
        // xmlHelper.logRequest();
    }
    
    /**
     * Verify if mvxConfiguratorItemID is set - replace any existing ItemIDs if
     * they are different. This assumes that 1.) MvxConfiguratorItemID is only
     * set in cases wherein Configurable Items are involved and therefore should
     * not interfere with other scenarios
     * 
     * @param request
     * @param xmlHelper
     * @throws PipelineRuntimeException
     */
    private void updateVariantItem(Document request, XMLRequestHelper xmlHelper) throws PipelineRuntimeException {
        LOG.debug("Executing updateVariantItem method");        
        try {
            NodeList mvxConfNodeList = XPathAPI.selectNodeList(request,
            "request/params/param[@name=\"mvxConfiguratorItemID\"]");
            if (mvxConfNodeList.getLength()>0) {
                Node node = mvxConfNodeList.item(0);
                mvxConfiguratorItemID = node.getFirstChild().getNodeValue();
                LOG.debug("Found mvxConfiguratorItemID with value " + mvxConfiguratorItemID);
            } 
            
            if (mvxConfiguratorItemID!=null) {                
                NodeList nodeList = XPathAPI.selectNodeList(request,
                        "request/entities/entity/subsets/subset[@name=\"OrderLine\"]");                
    
                for (int j = 0; j < nodeList.getLength(); j++) {
                    Node node = nodeList.item(j);
                    String itemID = xmlHelper.getAttribute(node, "ItemID");
                    if (itemID != null && !itemID.equals(mvxConfiguratorItemID)) {
                        LOG.debug("Replacing ItemID " + itemID + " with " + mvxConfiguratorItemID);
                        xmlHelper.setAttribute(node, "ItemID", mvxConfiguratorItemID);
						
						//Removing MvxConfigurableID since variant items should have none of this
						NodeList nodeListConfId = XPathAPI.selectNodeList(request,
                        "request/entities/entity/subsets/subset[@name=\"OrderLine\"]/attributes/attribute[@name=\"MvxConfigurableID\"]");
						Node nodeConfId = nodeListConfId.item(0);
						xmlHelper.removeEntity(nodeConfId);						
                    }					
                }
            }
            else {                
                LOG.debug("No mvxConfiguratorItemID parameters found");
            }

        } catch (Exception e) {
            throw new PipelineRuntimeException("Error in HandleOrderLines stage - internalOrderlineHandling function",
                    e);
        }
    }

    /**
     * <p>
     * Make all <tt>ItemID's</tt> upper case.
     * </p>
     * 
     * We require the item id to be case-insensitive. As XPath 1.0 does not
     * support case-insensitive matches, we are left with two suboptimal ways of
     * doing this.
     * 
     * 1. We can do a "pseudo case-insensitive select" using the translate()
     * function, which converts a string by mapping one character into another,
     * e.g. get all elements that contain the string cat, ignoring case xpath =
     * "//*[contains(translate(.,'abcdefghijklmnopqrstuvwxyz',
     * 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'),'CAT')]";
     * 
     * 2. We replace all item IDs in the request with an uppercase version
     * before we do selects on the item ID.
     * 
     * Method 2 have been implemented as it is probably most performance
     * friendly
     * 
     * @param request
     *            contains the committed orderlines that are to be manipulated.
     * @param xmlHelper
     *            is a helper class for manipulating the request.
     * @throws PipelineRuntimeException
     */
    private void makeItemIDsUpperCase(Document request, XMLRequestHelper xmlHelper) throws PipelineRuntimeException {

        try {
            NodeList nodeList = XPathAPI.selectNodeList(request,
                    "request/entities/entity/subsets/subset[@name=\"OrderLine\"]");
            // "request/entities/entity/subsets/subset[@name=\"OrderLine\"]/entity");

            for (int j = 0; j < nodeList.getLength(); j++) {
                Node node = nodeList.item(j);
                String itemID = xmlHelper.getAttribute(node, "ItemID");
                if (itemID != null) {
                    xmlHelper.setAttribute(node, "ItemID", itemID.toUpperCase());
                }
            }

        } catch (Exception e) {
            throw new PipelineRuntimeException("Error in HandleOrderLines stage - internalOrderlineHandling function",
                    e);
        }
    }

    /**
     * Preparation
     * <p>
     * 1. Orderlines with null quantities are removed 2. Orderlines with non
     * numeric quantities are removed 3. <tt>ShippingCountryID</tt> is set to
     * null if it contains an empty string 4. <tt>Quantity</tt> is set
     * according to the minimum and modular quantity defined for the item
     * </p>
     * 
     * @param request
     *            the committed orderlines that are to be manipulated.
     * @param xmlHelper
     *            a <code>XMLRequestHelper</code> class for manipulating the
     *            request.
     * @throws PipelineRuntimeException
     */
    private void validateItemsAndRemoveNullQuantities(Document request, XMLRequestHelper xmlHelper)
            throws PipelineRuntimeException {

        LOG.debug("Inside HandleOrderLines.validateItemsAndRemoveNullQuantities()");

        try {
            // Get the items from the database that are being committed

            // Get the item ID's that are in the request document
            NodeList nodeList = XPathAPI.selectNodeList(request,
                    "request/entities/entity/subsets/subset[@name=\"OrderLine\"]");

            if (nodeList.getLength() > 0) {

                SearchPipelineExecuter spe = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "Item",
                        "GetSimple");
                XMLResultset res = null;

                boolean oneOrMoreItems = false;
                // Iterate over the orderlines and add bindings for each item
                for (int j = 0; j < nodeList.getLength(); j++) {
                    Node node = nodeList.item(j);

                    // Remove orderlines with null quantities
                    if (xmlHelper.isAttributeNull(node, "Quantity")) {
                        xmlHelper.removeEntity(node);
                    } else {

                        // Remove orderlines with non numeric quantities
                        String qty = xmlHelper.getAttribute(node, "Quantity");
                        if (qty != null) {
                            try {
                                // Remove orderline if it does not contain a
                                // valid numeric quantity
                                // Will throw an exception, and the orderline
                                // will be removed in the catch
                                double orderedQuantity = Double.parseDouble(qty);

                                // Set ShippingCountryID to null if it contains
                                // an empty string
                                String shippingID = xmlHelper.getAttribute(node, "ShippingCountryID");
                                if (shippingID != null && shippingID.length() == 0) {
                                    xmlHelper.setAttribute(node, "ShippingCountryID", null);
                                }

                                String itemID = xmlHelper.getAttribute(node, "ItemID");
                                if (itemID != null) {
                                    oneOrMoreItems = true;
                                    spe.setBinding("ItemID", itemID, "eq");

                                    double modQty = 0.00;
                                    if (mvxWarehouse != null) {
                                        String modString = getModMinQuantity(itemID, currCode, langCode, mvxWarehouse,
                                                shippingID, userGroup, user, "ModularQty");
                                        modQty = Double.parseDouble(modString);
                                    }
                                    double minQty = 0.00;
                                    if (mvxWarehouse != null) {
                                        String minString = getModMinQuantity(itemID, currCode, langCode, mvxWarehouse,
                                                shippingID, userGroup, user, "MinimumQty");
                                        minQty = Double.parseDouble(minString);
                                    }
                                    if (mvxWarehouse != null) {
                                        orderedQuantity = quantityCheck(orderedQuantity, minQty, modQty);
                                        xmlHelper.setAttribute(node, "Quantity", Double.toString(orderedQuantity));
                                    }
                                }
                            } catch (Exception e) {
                                xmlHelper.removeEntity(node);
                            }
                        }
                    }
                }

                if (oneOrMoreItems) {
                    res = spe.execute();
                    NodeList itemNodes = XPathAPI.selectNodeList(res.getDocument(), "//row");
                    for (int i = 0; i < itemNodes.getLength(); i++) {
                        Node node = itemNodes.item(i);
                        NamedNodeMap nnm = node.getAttributes();

                        String itemID = nnm.getNamedItem("ItemID").getNodeValue().toUpperCase();

                        double modularQuantity = 0;
                        Node value = nnm.getNamedItem("ModularQty");
                        if (value != null) {
                            String modularString = value.getNodeValue();
                            if (modularString != null) {
                                modularQuantity = Double.parseDouble(modularString);
                            }
                        }
                        double minimumQuantity = 0;
                        value = nnm.getNamedItem("MinimumQty");
                        if (value != null) {
                            String minimumString = value.getNodeValue();
                            if (minimumString != null) {
                                minimumQuantity = Double.parseDouble(minimumString);
                            }
                        }

                        // Get the committed orderline with this item ID
                        // TODO. Do we need to select caseinsensitive and then
                        // set the correct case in the request?
                        StringBuffer sb = new StringBuffer(
                                "request/entities/entity/subsets/subset[@name=\"OrderLine\" and attributes/attribute[@name=\"ItemID\"]=");
                        sb.append(getConcatStringForXPath(itemID));
                        sb.append("]");
                        NodeList nodeList2 = XPathAPI.selectNodeList(request, sb.toString());

                        for (int k = 0; k < nodeList2.getLength(); k++) {
                            Node node2 = nodeList2.item(k);
                            String quantityString = xmlHelper.getAttribute(node2, "Quantity");
                            if (quantityString != null) {
                                double quantity = Double.parseDouble(quantityString);
                                quantity = quantityCheck(quantity, minimumQuantity, modularQuantity);
                                xmlHelper.setAttribute(node2, "Quantity", (new Double(quantity)).toString());
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            throw new PipelineRuntimeException(
                    "Error in HandleOrderLines stage - validateItemsAndRemoveNullQuantities function", e);
        }
    }

    /**
     * <p>
     * Determines the correct quantity with regard to a minimum and a modular
     * quantity.
     * </p>
     * 
     * @param quantity
     *            the quantity to be checked
     * @param minimumQuantity
     *            the minimum allowed quantity
     * @param modularQuantity
     *            the modular allowed quantity
     * @return the correct quantity
     */
    private double quantityCheck(double quantity, final double minimumQuantity, final double modularQuantity) {
        if (quantity == 0) {
            // 0 is also a correct amount - deletes the orderline
        } else if (noFraction(quantity, modularQuantity) && quantity >= minimumQuantity
                && MAX_ORDER_QUANTITY >= quantity) {
            // User has bought correct amount
        } else {
            // User has not bought correct amount

            //assign the maximum order quantity if the submitted value is greater than that
            if (MAX_ORDER_QUANTITY < quantity) {
                quantity = calcMaxQuantity(MAX_ORDER_QUANTITY, modularQuantity);
            }

            double smallestQuantity;
            if (modularQuantity == 0) {
                smallestQuantity = minimumQuantity;
            } else {
                smallestQuantity = calcQuantity(minimumQuantity, modularQuantity);
            }

            if (quantity <= smallestQuantity) {
                quantity = smallestQuantity;
            } else {
                quantity = calcQuantity(quantity, modularQuantity);
            }

            // Ensure the precision to 4 decimals after the comma (use 10^4 =
            // 10000)
            quantity = Math.round(quantity * 10000) / 10000.0;
        }
        return quantity;
    }

    private double calcMaxQuantity(double maximumQuantity, double modularQuantity) {
        double calcQty = calcQuantity(maximumQuantity, modularQuantity);
        if (maximumQuantity < calcQty) {
            return calcQty - modularQuantity;
        }
        return calcQty;
    }

    private String getModMinQuantity(String itemID, String currencyCode, String languageCode, String warehouse,
            String shippingCode, int userGroupId, int userId, String attribute) throws PipelineRuntimeException {
        try {
            SearchPipelineExecuter seOrderItems = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                    "Item", "GetItemModularQty");
            seOrderItems.setParam("itemId", itemID);
            seOrderItems.setParam("@CurrencyCode", currencyCode);
            seOrderItems.setParam("@LanguageCode", languageCode);
            seOrderItems.setParam("@MvxWarehouse", warehouse);
            seOrderItems.setParam("@ShippingCountryCode", shippingCode);
            seOrderItems.setParam("@UserGroupID", String.valueOf(userGroupId));
            seOrderItems.setParam("@UserID", String.valueOf(userId));
            XMLResultset rs = seOrderItems.execute();
            rs.beforeFirst();
            rs.moveNext();
            return rs.getString(attribute);
        } catch (Exception e) {
            throw new PipelineRuntimeException("error");
        }
    }

    private boolean noFraction(double quantity, double modularQuantity) {
        if (modularQuantity <= 0.000001) {
            return true;
        } else {
            double q1 = calcQuantity(quantity, modularQuantity);
            return Math.abs(quantity - q1) < 0.0001;
        }
    }

    private double calcQuantity(double quantity, double modularQuantity) {
        if (modularQuantity <= 0.000001) {
            return quantity;
        }
        double d1 = quantity / modularQuantity;
        double d2 = Math.rint(d1);
        // results calculated by division operator might become incorrect, e.g.
        // 100.1 / 0.05 == 100.10000000000001
        // Therefore perform this calculation to ensure truncation to 4
        // decimals, which should elemininate
        // errors as the one above
        d1 = Math.round(d1 * 10000) / 10000.0;
        if (d1 == d2) {
            return quantity;
        }

        return Math.rint(d1 + 0.5) * modularQuantity;
    }

    /**
     * External orderline handling
     * <p>
     * The committed order lines are compared to the existing order lines in the
     * database. If the committed quantity is less than or equal to zero, the
     * orderline is removed as well as the existing orderline in the database
     * (if any).
     * <p>
     * If the quantity is valid and the orderline is new and an orderline exists
     * in the database with the same <tt>ItemID</tt> (and
     * <tt>configurationid</tt> if any), the new and the existing orderline is
     * merged, unless the property <tt>Ordering.Merge SKU in orderlines</tt>
     * is set to <tt>false</tt> or if the parameter <tt>noOrderlineMerge</tt>
     * is set to <tt>true</tt>.
     * 
     * @param context
     *            the context of the pipeline.
     * @param request
     *            the committed orderlines that are to be manipulated.
     * @param xmlHelper
     *            a <code>XMLRequestHelper</code> class for manipulating the
     *            request.
     * @throws PipelineRuntimeException
     */

    /*
     * Check the committed orderlines with the ones already present in the
     * database
     */
    private void externalOrderlineHandling(PipelineContext context, Document request, XMLRequestHelper xmlHelper)
            throws PipelineRuntimeException {

        LOG.debug("Inside HandleOrderLines.externalOrderlineHandling()");

        try {
            String orderID = null;
            Node nodeOrderID = null;
            try {
                nodeOrderID = XPathAPI.selectSingleNode(request, "request/entities/entity/keys/key/@value");
            } catch (Exception e) {
                LOG.fatal("Could not select xpath in XML request document", e);
                throw new PipelineRuntimeException("Could not select XPath in XML request document", e);
            }

            if (nodeOrderID != null) {
                orderID = nodeOrderID.getFirstChild().getNodeValue();

                // Get existing order lines from the database
                SearchPipelineExecuter spe = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                        "CurrentOrder", "GetExistingOrder");
                XMLResultset res = null;
                spe.setBinding("OrderID", orderID, "eq");
                res = spe.execute();
                Document xmlDoc = res.getDocument();

                // check the highest DRDLSequence from all OrderLines (they are not in-order)
                NodeList existingOrderLineNodes = XPathAPI.selectNodeList(res.getDocument(), "//row/OrderLine");
                for (int i=0; i < existingOrderLineNodes.getLength(); i++) {
                	Node nodelast = existingOrderLineNodes.item(i);
                	NamedNodeMap nmp = nodelast.getAttributes(); 
					
					if (nmp.getNamedItem("DRDLSequence").getNodeValue() != null) { 
						if (Integer.parseInt(nmp.getNamedItem("DRDLSequence").getNodeValue()) > ordseq) {
							ordseq = Integer.parseInt(nmp.getNamedItem("DRDLSequence").getNodeValue());
						}
					} 
			    }
                boolean existingOrderLines = existingOrderLineNodes.getLength() > 0;

                NodeList nodeList = XPathAPI.selectNodeList(request,
                        "request/entities/entity/subsets/subset[@name=\"OrderLine\"]");
                // "request/entities/entity/esubsets/esubset[@name=\"OrderLine\"]/entity");

                for (int i = 0; i < nodeList.getLength(); i++) {
                    Node node = nodeList.item(i);
                    handleOrderLine(context, node, xmlHelper, existingOrderLines, xmlDoc, orderID, i);
                }
            }
        } catch (Exception e) {
            throw new PipelineRuntimeException("Error in HandleOrderLines stage - externalOrderlineHandling function",
                    e);
        }
    }

    /**
     * <p>
     * Handle a single orderline.
     * </p>
     * 
     * @param context
     *            the context of the pipeline.
     * @param node
     *            a pointer to the orderline that is to be handled in the XML
     *            document
     * @param xmlHelper
     *            a <code>XMLRequestHelper</code> class for manipulating the
     *            request.
     * @param existingOrderLines
     *            a boolean indicating whether orderlines exists in the databse
     *            for the current order.
     * @param xmlDoc
     *            the XML document of the committed orderlines that are to be
     *            manipulated
     * @param orderID
     *            the orderid of the current order being handled
     * @throws PipelineRuntimeException
     */
    private void handleOrderLine(PipelineContext context, Node node, XMLRequestHelper xmlHelper,
    		boolean existingOrderLines, Document xmlDoc, String orderID, int i) throws PipelineRuntimeException {

        try {
            String qtyString = xmlHelper.getAttribute(node, "Quantity");
            if (qtyString != null) {

                boolean isHandled = false;
                double qty = Double.parseDouble(qtyString);
                String orderLineID = xmlHelper.getKey(node);

                if (orderLineID != null) {
                    LOG.debug("Updating an existing order line");

                    String mvxConfId = xmlHelper.getAttribute(node, ConstantsForSales.MVX_CONFIGURABLE_ID);
                    if(mvxConfId == null || "".equals(mvxConfId)){
                    	StringBuffer sbOrderLine = new StringBuffer("//row/OrderLine[@OrderLineID=\"");
                    	sbOrderLine.append(orderLineID);
                    	sbOrderLine.append("\"]");
                    	Node nodeOrderLine = XPathAPI.selectSingleNode(xmlDoc, sbOrderLine.toString());
                    	
                    	if (nodeOrderLine != null) {
                    		NamedNodeMap nodeMap = nodeOrderLine.getAttributes();
                    		if (nodeMap != null) {
                    			if (nodeMap.getNamedItem("MvxConfigurableID") != null) {
                    				mvxConfId = nodeMap.getNamedItem("MvxConfigurableID").getNodeValue();
                    				LOG.debug("Mvx Configurable ID: " + mvxConfId);
                    				if(mvxConfId != null && mvxConfId != ""){
                    					xmlHelper.setAttribute(node, "MvxConfigurableID", mvxConfId);
                    				}
                    			}
                    		}
                    	}
                    }
                    
                    if (qty <= 0) {
                        // Remove the committed orderline
                        xmlHelper.removeEntity(node);
                        isHandled = true;

                        // Remove possible existing order lines as well
                        if (existingOrderLines) {
                            StringBuffer sb = new StringBuffer("//row/OrderLine[@OrderLineID=\"");
                            sb.append(orderLineID);
                            sb.append("\"]");
                            Node orderLineNode = XPathAPI.selectSingleNode(xmlDoc, sb.toString());

                            if (orderLineNode != null) {
                            	String sku = null;
                            	String mvxConfigurableID = null;
                            	NamedNodeMap nnm = orderLineNode.getAttributes();
                            	if (nnm != null && nnm.getNamedItem("SKU") != null) {
                            		sku = nnm.getNamedItem("SKU").getNodeValue();
                                    
                                    if(nnm.getNamedItem("MvxConfigurableID") != null) {
                                    	mvxConfigurableID = nnm.getNamedItem("MvxConfigurableID").getNodeValue();
                                    }                                    
                            	}       
                            	
                            	XMLResultset response = new XMLResultset();
								context.setResponse(response);
								xmlRequest = (XMLRequest) context.getRequest();
								String paramOrderLineID = null;
								paramOrderLineID = xmlRequest.getParameters().getString("paramOrderLineID");
								LOG.debug("OrderLineID from parameters: " +paramOrderLineID);
								
								if (paramOrderLineID != null || paramOrderLineID != "") {
                            		deleteExistingOrderLine(orderID, orderLineID);
                            	}
                            	else {
                            		deleteExistingOrderLineBySku(orderID, sku, mvxConfigurableID);
                            	}
                            	
                                //deleteExistingOrderLine(orderID, orderLineID);
                            }
                        }
                    }
                } else if (!duplicateOrderLines && existingOrderLines) {
                    // We are NOT updating an existing order line
                    // Check if there is an existing order line with the same
                    // ItemID (and ConfigurationID)
                    LOG.debug("!duplicateOrderLines && existingOrderLines");

                    String itemID = xmlHelper.getAttribute(node, "ItemID");
                    String configurationID = xmlHelper.getAttribute(node, "ConfigurationID");
                    String mvxConfigurableID = xmlHelper.getAttribute(node, "MvxConfigurableID");                    
                    StringBuffer sb = new StringBuffer("//row/OrderLine[@ItemID=");
                    sb.append(getConcatStringForXPath(itemID));
                    if (configurationID != null) {
                        sb.append(" and ConfigurationID=\"");
                        sb.append(configurationID);
                        sb.append("\"");
                    }
                    if (mvxConfigurableID != null) {		
                        sb.append(" and MvxConfigurableID=\"");
                        sb.append(mvxConfigurableID);
                        sb.append("\"]");
                    }
                    else {
                    	sb.append(" and not(@MvxConfigurableID)");
                    	sb.append("]");
                    }
                    
                    //sb.append("]");

                    Node orderLineNode = XPathAPI.selectSingleNode(xmlDoc, sb.toString());
                    if (orderLineNode != null) {
                        if (qty <= 0) {
                            // Remove the orderline - both committed and in the
                            // database
                            xmlHelper.removeEntity(node);

                            // deleteInDatabase
                            NamedNodeMap nnm = orderLineNode.getAttributes();
                            String existingOrderLineID = nnm.getNamedItem("OrderLineID").getNodeValue();
                            deleteExistingOrderLine(orderID, existingOrderLineID);
                        } else {
                            // Add the quantities for the new and old orderlines
                            NamedNodeMap nnm = orderLineNode.getAttributes();
                            String qtyString2 = nnm.getNamedItem("Quantity").getNodeValue();
                            // quantity increment is not required as it adds
                            // while refreshing page
                            // qty += Double.parseDouble(qtyString2);
                            xmlHelper.setAttribute(node, "Quantity", Double.toString(qty));
                            // We update the existing orderline - use the key of
                            // the existing orderline
                            xmlHelper.setKey(node, nnm.getNamedItem("OrderLineID").getNodeValue());
                        }

                        isHandled = true;
                    }
                    else { 
						ordseq += 1; 
						xmlHelper.setAttribute(node, "DRDLSequence", Integer.toString(ordseq));
						LOG.debug("OrderLine not null. Set DRDLSequence to " + Integer.toString(ordseq));
					}
                } 
				else { 
					LOG.debug("New OrderLine. Set DRDLSequence to " + Integer.toString(i + 1));
					xmlHelper.setAttribute(node, "DRDLSequence", Integer.toString(i + 1));
                }

                // If reached here and not handled, the item does not exist
                // in any existing orderline.
                // However, if the quantity <= 0 the orderline is removed
                if (qty <= 0 && !isHandled) {
                    xmlHelper.removeEntity(node);
                }

                // Update prices
                if ((qty > 0.0000001d)
                        && ("true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.CONNECTORENABLED)))) {
                    try {
                        // TODO: Check if quantity has changed.
                        // Update the order line with prices from Movex
                        UpdatePricesInRequestFromMovex.updateLine(context, xmlHelper, node);
                    } catch (Exception e) {
                        // Ignore this error - just write a note to the log
                        LOG.error("Failed to update prices for " + xmlHelper.getAttribute(node, "ItemID"));
                    }
                }
            }
        } catch (Exception e) {
            throw new PipelineRuntimeException("Error in HandleOrderLines stage - handleOrderLine function", e);
        }
    }

    /**
     * Internal orderline handling
     * <p>
     * The orderlines are compared to each other. If the <tt>ItemID</tt> and
     * the <tt>configurationID</tt> for two orderlines are the same, then the
     * orderlines are merged (the quantities are added together in one orderline
     * and the other is deleted) - unless both orderlines are updates to
     * existing orderlines and they have different keys, then both are kept.
     * 
     * @param request
     *            the committed orderlines that are to be manipulated.
     * @throws PipelineRuntimeException
     */
    private void internalOrderlineHandling(Document request) throws PipelineRuntimeException {

        LOG.debug("Inside HandleOrderLines.internalOrderlineHandling()");

        XMLRequestHelper xmlHelper = new XMLRequestHelper(request);
        HashSet deletedNodes = new HashSet();

        try {

            // Select elements using the xpath string
            NodeList nodeList = XPathAPI.selectNodeList(request,
                    "request/entities/entity/subsets/subset[@name=\"OrderLine\"]");
            // "request/entities/entity/esubsets/esubset[@name=\"OrderLine\"]/entity");

            // -1 as we do not need to check the last one
            for (int j = 0; j < nodeList.getLength() - 1; j++) {
                Node node = nodeList.item(j);

                if (!deletedNodes.contains(node)) {

                    String itemID = xmlHelper.getAttribute(node, "ItemID");
                    String configurationID = xmlHelper.getAttribute(node, "ConfigurationID");
                    String mvxConfigurableID = xmlHelper.getAttribute(node, "MvxConfigurableID");
                    String key = xmlHelper.getKey(node);

                    // If the itemID and the configurationID are the same,
                    // then we must merge them
                    // If both orderlines are updates and they have different
                    // keys, then we keep both
                    StringBuffer xpath = new StringBuffer("request/entities/entity/subsets/subset[(");
                    // new
                    // StringBuffer("request/entities/entity/subsets/subset[(attributes/attribute[@name=\"ItemID\"]=\"");
                    boolean isFirstClause = true;

                    if (itemID != null) {
                        xpath.append("attributes/attribute[@name=\"ItemID\"]=");
                        xpath.append(getConcatStringForXPath(itemID));
                        isFirstClause = false;
                    }

                    if (configurationID != null) {
                        if (!isFirstClause) {
                            xpath.append(" and ");
                        }

                        xpath.append("attributes/attribute[@name=\"ConfigurationID\"]=\"");
                        xpath.append(configurationID);
                        xpath.append("\"");
                        isFirstClause = false;
                    }

                    if (mvxConfigurableID != null) {						
                        if (!isFirstClause) {
                            xpath.append(" and ");
                        }
                        xpath.append("attributes/attribute[@name=\"MvxConfigurableID\"]=\"");
                        xpath.append(mvxConfigurableID);
                        xpath.append("\"");
                        isFirstClause = false;
                    }


                    if (key != null) {
                        if (!isFirstClause) {
                            xpath.append(" and ");
                        }

                        // xpath.append("(count(keys/key)=0 or
                        // keys/key/@value=\"");
                        xpath.append("keys/key/@value=\"");
                        xpath.append(key);
                        // xpath.append("\")");
                        xpath.append("\"");
                        isFirstClause = false;
                    }

                    xpath.append(")]");

                    // Select elements using the xpath string
                    NodeList nodeList2 = XPathAPI.selectNodeList(request, xpath.toString());
                    boolean switchKeys = false;

                    // Iterate over all elements selected
                    for (int i = 0; i < nodeList2.getLength() && !switchKeys; i++) {

                        Node node2 = nodeList2.item(i);
                        // Do not compare to itself
                        if (!node.equals(node2)) {

                            String qty2 = xmlHelper.getAttribute(node2, "Quantity");
                            String qty1 = xmlHelper.getAttribute(node, "Quantity");
                            Double qty = new Double(Double.parseDouble(qty1) + Double.parseDouble(qty2));
                            if (MAX_ORDER_QUANTITY < qty) {
                                double modQty = 0.00;
                                if (mvxWarehouse != null) {
                                    String modString = getModMinQuantity(itemID, currCode, langCode, mvxWarehouse,
                                            null, userGroup, user, "ModularQty");
                                    modQty = Double.parseDouble(modString);
                                }
                                double minQty = 0.00;
                                if (mvxWarehouse != null) {
                                    String minString = getModMinQuantity(itemID, currCode, langCode, mvxWarehouse,
                                            null, userGroup, user, "MinimumQty");
                                    minQty = Double.parseDouble(minString);
                                }
                                qty = quantityCheck(qty.doubleValue(), minQty, modQty);
                            }
                            xmlHelper.setAttribute(node, "Quantity", qty.toString());

                            // If the second order line is an update and the
                            // first one is not, then we use the key for the
                            // second one
                            if (xmlHelper.isUpdate(node2) && !xmlHelper.isUpdate(node)) {
                                switchKeys = true;
                                xmlHelper.setKey(node, xmlHelper.getKey(node2));
                                // We have to do another xpath selection with
                                // the new key!
                                j = j - 1;
                            }

                            xmlHelper.removeEntity(node2); // move to end?
                            // Cannot remove from nodelist2 (no method on
                            // interface)!
                            // Instead we remember which nodes have been
                            // deleted!
                            deletedNodes.add(node2);
                        }
                    }
                }
            }
        } catch (Exception e) {
            throw new PipelineRuntimeException("Error in HandleOrderLines stage - internalOrderlineHandling function",
                    e);
        }
    }

    /**
     * <p>
     * Deletes an orderline in the database.
     * </p>
     * 
     * @param orderID
     *            the id for the order that is to be deleted
     * @param orderLineID
     *            the id for the orderline that is to be deleted
     * @throws PipelineRuntimeException
     */
    private void deleteExistingOrderLine(String orderID, String orderLineID) throws PipelineRuntimeException {

        try {
            DeletePipelineExecuter dpe = new DeletePipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "CurrentOrder",
                    "DeleteOrderLine");
            dpe.setMainKey("OrderID", orderID);
            dpe.setSubsetKey("OrderLine", "OrderLineID", orderLineID);
            dpe.execute();
        } catch (PipelineRuntimeException e) {
            throw new PipelineRuntimeException("Error executing DeleteOrderLine pipeline", e);
        }
    }
    
    private void deleteExistingOrderLineBySku(String orderID, String sku, String mvxConfigurableID) throws PipelineRuntimeException {

    	String SQL = "DELETE [OrderLine1] FROM [OrderHeader] [main] " +
    				"INNER JOIN [OrderLine] [OrderLine1] ON [main].[id] = [OrderLine1].[orderId] " + 
    				"INNER JOIN [Item] [Item1] ON [OrderLine1].[itemNumber] = [Item1].[itemNumber] " + 
    				"LEFT JOIN stylerelation ir ON ir.styleitemid = [Item1].id " +
    				"LEFT JOIN Item item2 ON ir.styleid = item2.id " +
    				"WHERE [main].[id] = ? and item2.itemnumber = ? and [OrderLine1].mvxConfigurableId ";
    	String ISNULL = " is null";

    	Connection con = null;
    	PreparedStatement stmt = null;
    	
    	String sql = SQL;
    	
    	if (mvxConfigurableID == null || mvxConfigurableID.length() == 0) {
    		sql += ISNULL;
    	}
    	else {
    		sql += " = " + mvxConfigurableID;
    	}
    	
    	try {
    		con=(Connection)CustomStagesHelper.getConnection("esales.cursor");
    		stmt = con.prepareStatement(sql);
    		
    		stmt.setObject(1,orderID,Types.INTEGER);
    		stmt.setObject(2,sku,Types.VARCHAR);
    		
    		LOG.debug("Deleting orderline by SKU = " + sql);
    		LOG.debug("Using orderID = " + orderID + " sku = " + sku + " configId = " + mvxConfigurableID);

    		boolean status = stmt.execute();
    		LOG.debug("Delete status = " + status);
    	}
    	catch (Exception e) {
    		throw new PipelineRuntimeException("Error deleting orderlines", e);
    	}
    	finally {
    		LOG.debug("Closing connections");
    		CustomStagesHelper.close(con, stmt, null);
    	}
    }
    
    
    /**
     * Creates a concat() query to escape the ' and " in the Item Numbers.
     * @param query
     * @return
     */
    private String getConcatStringForXPath(String query) {
    	String returnString = "";
     
    	if (query != null) {
    		
    		// look for ' OR "
            int quotePos = query.indexOf('\'');
            if (quotePos == -1) {
            	quotePos = query.indexOf('\"');
            }
            
            // if none found, return
            if (quotePos == -1)
            {
                returnString = "'" + query + "'";
            }
            else
            {
            	// create concat
                returnString = "concat(";
                while (quotePos != -1)
                {
                    String subString = query.substring(0, quotePos);
                    if ("".equals(subString) == false) {
                    	returnString += "'" + subString + "', ";	
                    }
                    
                    if (query.charAt(quotePos) == '\'')
                    {
                    	// single-quote
                        returnString += "\"'\", ";
                    }
                    else
                    {
                        //double-quote
                        returnString += "'\"', ";
                    }
                    
                    if (query.length() > (quotePos+1)) {
                    	// remove the processed string
                    	query = query.substring(quotePos + 1);	
                    }
                    else {
                    	query = "";
                    }

                    quotePos = query.indexOf('\'');
                    if (quotePos == -1) {
                    	quotePos = query.indexOf('\"');
                    }
                }
                returnString += "'" + query + "')";
            }
    	}

        return returnString;
    }
}
