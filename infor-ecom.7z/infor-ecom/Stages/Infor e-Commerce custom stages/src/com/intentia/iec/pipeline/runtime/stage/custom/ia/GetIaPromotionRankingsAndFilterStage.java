package com.intentia.iec.pipeline.runtime.stage.custom.ia;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.transform.TransformerException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.ia.dao.IaDao;
import com.intentia.iec.pipeline.runtime.integration.ia.dao.impl.IaDaoRpImpl;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaConnectionException;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.ia.model.IaPromotion;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.custom.StageUtilityHelper;

public class GetIaPromotionRankingsAndFilterStage extends AbstractPipelineStage {

	private static final Logger log = Logger
			.getLogger(GetIaPromotionRankingsAndFilterStage.class);

	private static final String DEFAULT_EVENT = "RecommendPromotions";
	private static final String DEFAULT_USER_ID = "0";
	private static final String DEFAULT_USERGROUP_ID = "0";
	private static final String DEFAULT_MAX_RECORD = "5";

	@Override
	public void execute(PipelineContext context)
			throws PipelineRuntimeException {
		log.debug("Executing GetIaPromotionRankingsAndFilterStage.execute()...");
		try {
			CustomStagesHelper.extractRequestParameters(CustomStagesHelper
					.getRequest(context));
			XMLRequest request = (XMLRequest) context.getRequest();
			Parameters requestParams = request.getParameters();
			XMLResultset response = (XMLResultset) context.getResponse();
			log.debug("Unsorted and unfiltered XMLResponse :" + response);

			Map<String, Node> responseToMap = new HashMap<String, Node>();
			Set<String> validPromotionIds = getValidPromotionIds(response,
					responseToMap);

			if (!validPromotionIds.isEmpty()) {
				List<IaPromotion> promotionRankings = retrievePromotionRankingFromIA(
						validPromotionIds, requestParams);

				if (promotionRankings != null && !promotionRankings.isEmpty()) {
					response = sortResponseMap(promotionRankings,
							responseToMap, response);
					context.setResponse(response);
				}
			}

		} catch (Exception e) {
			throw new PipelineRuntimeException(
					"Error while retrieving IA campaign rankings.", e);
		}
	}

	private Set<String> getValidPromotionIds(XMLResultset response,
			Map<String, Node> responseToMap) throws PipelineRuntimeException {
		Set<String> validPromotionIds = new HashSet<String>();
		try {
			Document responseDoc = response.getDocument();
			NodeList promotions = XPathAPI.selectNodeList(responseDoc,
					"/resultset/row/Promotion");
			if (promotions != null) {
				for (int i = 0; i < promotions.getLength(); i++) {
					Element promo = (Element) promotions.item(i);
					String promoId = promo.getAttribute("PromotionID");
					responseToMap.put(promoId, promo);
					validPromotionIds.add(promoId);
				}
			}
		} catch (ResultsetException e) {
			throw new PipelineRuntimeException(
					"Error while retrieving valid promotion IDs.", e);
		} catch (TransformerException e) {
			throw new PipelineRuntimeException(
					"Error while retrieving valid promotion IDs.", e);
		}

		log.debug("List of valid promotion IDs: " + validPromotionIds);

		return validPromotionIds;
	}

	private List<IaPromotion> retrievePromotionRankingFromIA(
			Set<String> validPromotionIds, Parameters requestParams)
			throws PipelineRuntimeException, ParametersException {
		List<IaPromotion> result = null;
		try {
			Map<String, String> params = new HashMap<String, String>();
			
			// TODO: Create parameter mapping...

			params.put("PromotionIds",
					StringUtils.join(validPromotionIds.toArray(), ","));
			params.put(
					"SessionId",
					StringUtils.defaultIfEmpty(
							requestParams.getString("SessionId"),
							requestParams
									.getString(ConstantsForSales.USER_ID_PARAM)
									+ "_"
									+ requestParams
											.getString(ConstantsForSales._USERGROUPID_PARAM)));
			params.put("UserId", StringUtils.defaultIfEmpty(
					requestParams.getString(ConstantsForSales.USER_ID_PARAM),
					DEFAULT_USER_ID));
			params.put("GroupId", StringUtils.defaultIfEmpty(requestParams
					.getString(ConstantsForSales._USERGROUPID_PARAM),
					DEFAULT_USERGROUP_ID));
			params.put("RecommendationsCount", StringUtils.defaultIfEmpty(
					requestParams.getString("MaxRecordParam"),
					DEFAULT_MAX_RECORD));
			params.put(
					"CurrentPageId",
					StringUtils.defaultIfEmpty(
							requestParams.getString("CurrentPageId"), ""));
			params.put("ItemCategoryIdsInCart", StringUtils.defaultIfEmpty(
					requestParams.getString("ItemCategoryIdsInCart"), ""));
			params.put("ViewedItemCategoryIds", StringUtils.defaultIfEmpty(
					requestParams.getString("ViewedItemCategoryIds"), ""));
			params.put("SearchedItemCategoryIds", StringUtils.defaultIfEmpty(
					requestParams.getString("SearchedItemCategoryIds"), ""));

			IaDao dao;
			dao = new IaDaoRpImpl();
			result = dao.getPromotions(
					StringUtils.defaultString(
							requestParams.getString("IaEvent"), DEFAULT_EVENT),
					params);

		} catch (IaConnectionException e) {
			log.error(
					"Error while connecting to IA server. Ignoring IA promotion ranking.",
					e);
		} catch (IaRuntimeException e) {
			log.error(
					"Error while retrieving promotion rankings from the IA server. Ignoring IA ranking.",
					e);
		}

		log.debug("IA Promotion Ranking: " + result.toString());

		return result;
	}

	private XMLResultset sortResponseMap(List<IaPromotion> promotionRankings,
			Map<String, Node> responseMap, XMLResultset response)
			throws PipelineRuntimeException {
		try {
			Document responseDoc = response.getDocument();
			Element resultsetNode = (Element) XPathAPI.selectSingleNode(
					responseDoc, "resultset");
			if (resultsetNode != null) {
				// remove existing resultset
				responseDoc.removeChild(resultsetNode);
				// create new resultset
				resultsetNode = responseDoc.createElement("resultset");
				resultsetNode.setAttribute("object", "Campaign");

				Element dummyRow = responseDoc.createElement("row");
				dummyRow.setAttribute("InternalName",
						"Dummy campaign holder for sorted promotions.");
				resultsetNode.appendChild(dummyRow);
				for (IaPromotion promo : promotionRankings) {
					Element row = (Element) responseMap.get(promo.getId());
					if (row != null) {
						if (promo.getScore() != 0) {
							row.setAttribute("Stats", String.valueOf(promo.getScore()));
						}
						dummyRow.appendChild(row);
					}
				}
				responseDoc.appendChild(resultsetNode);
			}
		} catch (Exception e) {
			throw new PipelineRuntimeException(
					"Error while creating new sorted XMLResponse.", e);
		}
		log.debug("Sorted XMLResponse: " + response);
		return response;
	}

}
