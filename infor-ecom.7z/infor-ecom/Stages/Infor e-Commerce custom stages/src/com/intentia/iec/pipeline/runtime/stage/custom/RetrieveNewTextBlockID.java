package com.intentia.iec.pipeline.runtime.stage.custom;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.connection.ConnectorException;
import com.intentia.iec.connection.IMovexApiResultset;
import com.intentia.iec.connection.IMovexConnection;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;

public class RetrieveNewTextBlockID implements PipelineStage {
    
    private static final Logger LOG = Logger.getLogger(RetrieveNewTextBlockID.class);
    
    private static final String CRS980MI = "esales.CRS980MI";
    
    private static final String RETRIEVE_NEW_TEXT_ID = "RtvNewTextID";    
        
    private Parameters requestParameters = null;

    public void execute(final PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("Entering RetrieveNewTextBlockID.execute()");
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
        
        XMLRequest request = (XMLRequest) context.getRequest();
        
        IMovexConnection con = null;
        try {
            con = (IMovexConnection) CustomStagesHelper.getConnection(CRS980MI);
            
            XMLRequest.extractRequestParameters(request);
            requestParameters = request.getParameters();
            
            Map input = new HashMap();
            input.put(IMovexConnection.TRANSACTION, RETRIEVE_NEW_TEXT_ID);
            input.put("CONO", requestParameters.getString(ConstantsForSales.MVXCOMPANY));            
            input.put("FILE", "MSYTXH00");
            
            IMovexApiResultset rs = CustomStagesHelper.callMovex(context, con, input, ConstantsForSales.MVXSTATUS);
            
            if (rs == null) {
                LOG.error("Resultset is empty.");
                return;
            } 
            
            if (!con.isOk()) {
                LOG.error("Failed to retrieve new text id. " + con.getLastMessage());
                return;
            }
            
            String textId = rs.getParamAsString("TXID");
			LOG.debug("Retrieved New Text ID : " + textId);
            CustomStagesHelper.setResponseParameter(context, "TextBlockID", textId);
            
            LOG.debug("Exiting RetrieveNewTextBlockID.execute()");                        
        } catch (RequestException e) {
            throw new PipelineRuntimeException("Failed to operate on request", e);
        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Failed to get parameter from request", e);
        } catch (PipelineRuntimeException e) {
            if (con == null) {                
                LOG.error("Failed to connect to Movex", e);
            } else {
                throw e;
            }           
        } finally {
            if (con != null) {
                try {
                    con.close();
                } catch (ConnectorException e) {
                    LOG.error("Failed to close connection!");
                }
            }
        }

    }

}
