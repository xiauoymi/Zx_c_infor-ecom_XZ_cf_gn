/*
 * Created on 25-04-2006
 */
package com.intentia.iec.pipeline.runtime.custom.pim;

/**
 * @author pedjes0
 * 
 */
public class CatalogImageException extends Exception {

    /**
     * @param cause
     */
    public CatalogImageException(final Throwable cause) {
        super(cause);
    }
}
