package com.intentia.iec.pipeline.runtime.stage.custom.daf.drawing;

/**
 * Class that represents an Equipment in e-Sales.
 *
 */
class Equipment {
	
	private String itemNumber = null;
	
	private String serialNumber = null;
	
	/**
	 * @param itemNumber
	 * @param serialNumber
	 */
	Equipment(String itemNumber, String serialNumber) {
		this.itemNumber = itemNumber;
		this.serialNumber = serialNumber;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((itemNumber == null) ? 0 : itemNumber.hashCode());
		result = prime * result
				+ ((serialNumber == null) ? 0 : serialNumber.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final Equipment other = (Equipment) obj;
		if (itemNumber == null) {
			if (other.itemNumber != null)
				return false;
		} else if (!itemNumber.equals(other.itemNumber))
			return false;
		if (serialNumber == null) {
			if (other.serialNumber != null)
				return false;
		} else if (!serialNumber.equals(other.serialNumber))
			return false;
		return true;
	}

	/**
	 * Returns the Item Number
	 * @return
	 */
	String getItemNumber() {
		return itemNumber;
	}

	/**
	 * Returns the Item Number
	 * @return
	 */
	String getSerialNumber() {
		return serialNumber;
	}
	
}