package com.intentia.iec.pipeline.runtime.stage.custom.lucene.search;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.Filter;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.Query;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.custom.lucene.manager.EsaQueryParser;
import com.intentia.iec.pipeline.runtime.stage.custom.lucene.manager.IndexManager;
import com.intentia.iec.pipeline.runtime.stage.custom.lucene.utils.IndexManagerUtil;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

/**
 * 
 * @author 15062
 * 
 */
public abstract class AbstractSearcherStage extends AbstractPipelineStage {

    private static final Logger LOG = Logger.getLogger(AbstractSearcherStage.class);

    private String _languageCode = null;

    private String _maxno = null;

    private String _offset = null;

    private String _queryString = null;

    private String _skipSortingResult = null;

    private Map<String, Map<String, String>> _searchScoresMap = new HashMap<String, Map<String, String>>();

    protected Parameters _requestParameters = null;

    protected abstract String getIndexName();

    protected abstract String getKeyAttributeName();

    protected abstract Filter createSearchFilters() throws PipelineRuntimeException;

    protected abstract XMLResultset getSearchResultDetails(Hits hits) throws PipelineRuntimeException;

    /**
     * 
     * @param context
     * @throws PipelineRuntimeException
     */
    public void execute(final PipelineContext context) throws PipelineRuntimeException {
        XMLResultset responseXML = null;
        try {
            if (!(context.getRequest() instanceof XMLRequest)) {
                throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
            }

            CustomStagesHelper.extractRequestParameters(CustomStagesHelper.getRequest(context));
            XMLRequest request = (XMLRequest) context.getRequest();
            _requestParameters = request.getParameters();

            // Check if this stage will be skipped.
            if ("true".equals(_requestParameters.getString(ConstantsForSales.SKIP_SEARCH_STAGE_PARAM))) {
                return;
            }

            getParameterValues(_requestParameters);
            Hits hits = searchIndex(_queryString);
            CustomStagesHelper.updateRequestParameter(request, ConstantsForSales.SKIP_SEARCH_STAGE_PARAM, "true");
            _requestParameters.set(ConstantsForSales.SKIP_SEARCH_STAGE_PARAM, "true");

            if (hits.length() > 0) {
                _requestParameters.set(ConstantsForSales.SKIP_GET_DEATAILS_STAGE_PARAM, "false");
                responseXML = getSearchResultDetails(hits);
                addScoresAndRowNumbers(responseXML);
                if (responseXML != null) {
                    if (!"true".equalsIgnoreCase(_skipSortingResult))
                        responseXML = IndexManagerUtil.sortXMLResultset(responseXML);
                    else
                        responseXML.beforeFirst();
                    Parameters outputParams = responseXML.getParameters();
                    outputParams.set(ConstantsForSales.TOTAL_SEARCH_COUNT_PARAM, hits.length());
                    if (LOG.isDebugEnabled()) {
                        XMLRequestHelper xmlHelper = new XMLRequestHelper(responseXML.getDocument());
                        LOG.debug("Sorted Response XML : ");
                        xmlHelper.logRequest();
                    }
                }
            }
            CustomStagesHelper.updateRequestParameter(request, ConstantsForSales.SKIP_GET_DEATAILS_STAGE_PARAM, "true");
            _requestParameters.set(ConstantsForSales.SKIP_GET_DEATAILS_STAGE_PARAM, "true");
            context.setResponse(responseXML);
        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Unable to parse request parameters", e);
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Unable to parse response XML", e);
        }
    }

    private void getParameterValues(Parameters parameters) throws PipelineRuntimeException {
        try {
            _queryString = parameters.getString(ConstantsForSales.QUERY_STRING_PARAM);
            _languageCode = parameters.getString(ConstantsForSales.LANGUAGE_CODE_PARAM);
            _skipSortingResult = parameters.getString(ConstantsForSales.SKIP_SORITNG_RESULT_PARAM);
            _maxno = parameters.getString("maxno");
            _offset = parameters.getString("offset");
        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Unable to get request parameter values", e);
        }
    }

    /**
     * 
     * @param queryString
     * @return
     * @throws PipelineRuntimeException
     */
    public Hits searchIndex(final String queryString) throws PipelineRuntimeException {
        IndexManager indexManager = null;
        Hits hits = null;
        Filter filter = null;
        String defaultField = null;
        if (queryString != null) {
            try {
                indexManager = IndexManager.getInstance(getIndexName());
                if (_languageCode == null)
                    _languageCode = ConstantsForSales.DEFAULT_LANGUAGE_CODE;

                defaultField = ConstantsForSales.KEYWORD_FIELD;

                if (indexManager.hasLocalizedFields())
                    defaultField += "_" + _languageCode;

                EsaQueryParser parser = new EsaQueryParser(defaultField, indexManager, _languageCode);
                configureQueryParser(parser);
                Query query = parser.parse(queryString);

                filter = createSearchFilters();

                hits = indexManager.search(query, filter, null);

            } catch (ParseException e) {
                throw new PipelineRuntimeException("Unable to parse query string '" + queryString + "'", e);
            }
        }
        return hits;
    }

    protected XMLResultset querySearchResultDetails(final Hits hits, final String BOName, final String BOMethodName,
            final String bindingAttribute) throws PipelineRuntimeException {
        XMLResultset result = null;
        int pagingLimit = ConstantsForSales.DEFAULT_PAGING_LIMIT;
        int pagingOffset = 0;

        if (_offset != null)
            pagingOffset = Integer.parseInt(_offset);
        if (_maxno != null)
            pagingLimit = pagingOffset + Integer.parseInt(_maxno) + 1;

        try {
            // Do a recursive call to the specified BO method
            SearchPipelineExecuter pipeline = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, BOName,
                    BOMethodName, SearchPipelineExecuter.OR);
            pipeline.setParam(ConstantsForSales.SKIP_SEARCH_STAGE_PARAM, "true");
            for (int i = pagingOffset; i < pagingLimit && i < hits.length() - pagingOffset; i++) {
                String keyFieldValue = hits.doc(i).get(ConstantsForSales.KEY_FIELD);
                pipeline.setBinding(bindingAttribute, keyFieldValue, "eq");

                // Add to search scores map
                Map<String, String> score = new HashMap<String, String>();
                score.put(ConstantsForSales.SEARCH_HIT_SCORE_ATTRIBUTE, String.valueOf(hits.score(i)));
                score.put(ConstantsForSales.SEARCH_ROW_NUMBER_ATTRIBUTE, String.valueOf(i));
                _searchScoresMap.put(keyFieldValue, score);
            }

            // Add request parameters
            Set<?> paramNames = _requestParameters.getParameterNames();
            for (Object param : paramNames) {
                String paramName = (String) param;
                pipeline.setParam(paramName, _requestParameters.getString(paramName));
            }

            result = pipeline.execute();

        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Unable to add request parameters", e);
        } catch (CorruptIndexException e) {
            throw new PipelineRuntimeException("Unable to access current index document", e);
        } catch (IOException e) {
            throw new PipelineRuntimeException("Unable to read index files", e);
        }

        return result;
    }

    private void addScoresAndRowNumbers(XMLResultset result) throws PipelineRuntimeException {
        try {
            if (result != null && !result.isEmpty()) {
                result.beforeFirst();
                while (result.moveNext()) {
                    String key = result.getString(getKeyAttributeName());
                    Map<String, String> score = _searchScoresMap.get(key);
                    if (score != null) {
                        result.appendField(ConstantsForSales.SEARCH_HIT_SCORE_ATTRIBUTE, score
                                .get(ConstantsForSales.SEARCH_HIT_SCORE_ATTRIBUTE));
                        result.appendField(ConstantsForSales.SEARCH_ROW_NUMBER_ATTRIBUTE, score
                                .get(ConstantsForSales.SEARCH_ROW_NUMBER_ATTRIBUTE));
                    }
                }
            }
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Unable to add hits scores to XML result set", e);
        }
    }

    /**
     * 
     * @param parser
     */
    private void configureQueryParser(QueryParser parser) {
        // TODO: get all configurations from application.properties file
        parser.setDefaultOperator(QueryParser.AND_OPERATOR);
    }
}
