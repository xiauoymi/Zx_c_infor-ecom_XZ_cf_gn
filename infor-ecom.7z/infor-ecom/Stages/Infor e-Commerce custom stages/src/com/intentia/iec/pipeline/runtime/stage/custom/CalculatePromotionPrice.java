package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.Decimal;

/**
 * <p>
 * Calculate the promotion price for the item.<br>
 * Get the List Price,NetPrice Nd Promotion Price and whichever price is
 * least,set it as Net Price in the response.
 * 
 */
public class CalculatePromotionPrice implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(CalculatePromotionPrice.class);

    private static String List_Price = "ListPrice";

    private static String Net_Price = "ResellPrice";

    private static String Promotion_Price = "PromotionPrice";

    public CalculatePromotionPrice() {
        super();
    }

    public void execute(PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("Inside CalculatePromotionPrice.execute()......");

        if (!(context.getResponse() instanceof XMLResultset)) {
            throw new PipelineRuntimeException("Contained response object MUST be of type 'XMLResultset'!");
        }
        XMLResultset response = (XMLResultset) context.getResponse();

        try {
            response.beforeFirst();
            while (response.moveNext()) {

                BigDecimal listPrice = response.getDecimal(List_Price);
                BigDecimal netPrice = response.getDecimal(Net_Price);

                if ("true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.PROMOTIONS))) {
                    BigDecimal promotionPrice = response.getDecimal(Promotion_Price);

                    System.out.println("list Price = " + listPrice + " ,netPrice = " + netPrice + "promotionprice="
                            + promotionPrice);

                    try {
                        if ((listPrice != null && listPrice.doubleValue() > 0) && (netPrice.compareTo(listPrice) > 0)
                                && (promotionPrice.compareTo(listPrice) > 0)) {
                            System.out.println("listPrice is the least = " + listPrice.toPlainString());
                            // response.setString(Net_Price,Decimal.toString(listPrice));

                        }
                    } catch (NullPointerException e) {
                        System.out.println("exception is " + e);
                        // response.setString(Net_Price,Decimal.toString(listPrice));
                    }

                    try {
                        if ((promotionPrice != null && promotionPrice.doubleValue() > 0)
                                && (listPrice.compareTo(promotionPrice) > 0)
                                && (netPrice.compareTo(promotionPrice) >= 0)) {
                            System.out.println("promotionPrice is the least= " + promotionPrice.toPlainString());
                            // response.setString(Net_Price,Decimal.toString(promotionPrice));
                        }
                    } catch (NullPointerException e) {
                        System.out.println("exception 2...................." + e);
                        // if(promotionPrice==null && netPrice !=null)
                        // {
                        // response.setString(Net_Price,Decimal.toString(netPrice));
                        // /}
                        // else
                        // {
                        // response.setString(Net_Price,Decimal.toString(listPrice));
                        // }
                    }

                } else {
                    if (listPrice != null && listPrice.doubleValue() > 0 && netPrice.compareTo(listPrice) > 0) {
                        System.out.println("listPrice is the least(promotions disabled)= " + listPrice.toPlainString());
                        response.setString(Net_Price, Decimal.toString(listPrice));
                    }
                }
            }

            response.beforeFirst();

        } catch (ResultsetException e) {
            throw new PipelineRuntimeException("Failed to get values from result set!", e);
        }

    }

}
