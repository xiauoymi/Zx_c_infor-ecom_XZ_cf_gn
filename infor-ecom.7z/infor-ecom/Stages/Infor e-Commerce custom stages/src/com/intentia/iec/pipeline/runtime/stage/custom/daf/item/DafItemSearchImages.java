package com.intentia.iec.pipeline.runtime.stage.custom.daf.item;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.intentia.icp.common.CMException;
import com.intentia.icp.common.CMItem;
import com.intentia.icp.common.CMItems;
import com.intentia.icp.common.CMResource;
import com.intentia.icp.common.CMResources;
import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.util.FastStringBuffer;

/**
 * This class retrieves one or all images for all items in the result set or parameter.
 * The supported BusinessObjects are Item, SparePart, Equipment, Promotions and CurrentOrder.
 *
 */
public class DafItemSearchImages extends AbstractDafSearchStage {
	private static final String MAINSET_ITEMS = "resultset/row";
	
	private static final String ITEMIMAGES = "ItemImages";
	
	private static final Logger LOG = Logger.getLogger(DafItemSearchImages.class);	

	/**
	 * Key used for most BusinessObjects
	 */
	private static final String ITEM_ID = "ItemID";
	
	private static final String IMAGE_ID = "ImageID";
	
	/**
	 * for Promotions BO, the ItemID attribute is actually ItemNumber
	 */
	private static final String ITEM_NUMBER = "ItemNumber";
	
	/**
	 * for CurrentOrder BO, the thumbnail attribute is different
	 */
	private static final String ITEM_IMAGE_THUMB = "ItemImageThumb";
	
	private static final String IMAGE_MASTER = "ImageMaster";
	
	private static final String IMAGE_PREVIEW = "ImagePreview";
	
	private static final String IMAGE_THUMB = "ImageThumb";
	
	private static final String PREVIEW_IMAGE = "PreviewImage";
	
	private static final String MASTER_IMAGE = "MasterImage";
	
	private static final String THUMB_IMAGE = "ThumbImage";
	
	private static final String PARAMETER_ID = "@DafItemID";
	
	/**
	 * If this parameter is included in the Parameter object, all images of the item will be retrieved
	 */
	private static final String PARAMETER_ALL_IMAGES = "@DafAllImages";	
	
	private static final String PIPELINE_PACKAGE = "com.intentia.iec.runtime.pipeline";
	
	private static final String PARAM = "param";
	
	private static final String PARAM_VALUE = "ParameterValue";
	
	private static final String PARAM_DEFAULT_PREVIEW = "DefItemImagePreview";
	
	private static final String PARAM_DEFAULT_THUMB = "DefItemImageThumb";
	
	private static final String APP_DETAILS_ROOT_URL = "rootUrl";
	
	private boolean allImages = false;
	
	private String defaultThumb = null;
	
	private String defaultPreview = null;
	
	private Set<String> itemNumbers = new HashSet<String>();
	
	private class Images {
		public String preview = null;
		private String master = null;
		public String thumb = null;
	}
	
	private Map<String, List<Images>> images = new HashMap<String, List<Images>>();
	
	private XMLResultset resultset = null;
	
	/**
	 * Query to get all images of all items
	 */
	private static final String SELECT_ITEMNUMBERS = DafItemImageConstants.TABLE + "[" + DafItemImageConstants.Attribute.Column.ITEM_NUMBER + " IN (";
	
	/**
	 * Image status must be Approved
	 */
	private static final String WHICH_ARE_APPROVED = ") AND " + DafItemImageConstants.Attribute.Column.STATUS + " = " + DafItemImageConstants.Status.APPROVED + "] SORTBY(" + DafItemImageConstants.Attribute.Column.IS_DEFAULT +" DESCENDING, @CREATETS ASCENDING)";
	
	/**
	 * Extracts item numbers that are present in the current ResultSet
	 * @throws ResultsetException
	 * @throws TransformerException
	 */
	private void getExistingItemNumbers() throws ResultsetException, TransformerException {
		this.resultset.moveFirst();
		
		Document xmlDoc = this.resultset.getDocument();
		NodeList nodeList = XPathAPI.selectNodeList(xmlDoc, MAINSET_ITEMS);
		
		// iterate through the main set
		for (int i = 0; i < nodeList.getLength(); i++) {
			Element e = (Element) nodeList.item(i);
			
			if (e.getAttribute(ITEM_ID) != null && e.getAttribute(ITEM_ID).length() > 0) {
				// has ItemID				
				// add item number to the Set
				itemNumbers.add(e.getAttribute(ITEM_ID));
			}
			else if ((e.getAttribute(ITEM_ID) == null || "".equals(e.getAttribute(ITEM_ID)) == true) &&
					(e.getAttribute(ITEM_NUMBER) != null && e.getAttribute(ITEM_NUMBER).length() > 0)) {
				// no ItemID but has ItemNumber (Promotion BO uses ItemNumber)
				itemNumbers.add(e.getAttribute(ITEM_NUMBER));
			}
			
			// for CurrentOrder BO
			// iterate through subset
			NodeList childNodes = e.getChildNodes();
			for (int j = 0; j < childNodes.getLength(); j++) {
				Element c = (Element) childNodes.item(j);
				if (c.getAttribute(ITEM_ID) != null && c.getAttribute(ITEM_ID).length() > 0) {
					// add item number to the Set
					itemNumbers.add(c.getAttribute(ITEM_ID));
				}
			}
		}
	}
	
	/**
	 * Returns the generated query that will be fed to DB2
	 * @return
	 */
	private String getXQuery() {
		if (this.itemNumbers.size() == 0) {
			// no items
			return null;
		}
		else {
			// generate query with all item numbers in the IN() clause
			StringBuffer buf = new StringBuffer(SELECT_ITEMNUMBERS);		
			boolean first = true;
			
			Iterator<String> it = this.itemNumbers.iterator();
			while (it.hasNext() == true) {
				String itemNumber = it.next();
				if (first == false) {
					buf.append(",");
				}
				buf.append("\"" + escapeXQuery(itemNumber) + "\"");
				first = false;
			}
			buf.append(WHICH_ARE_APPROVED);
			
			return buf.toString();
		}
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getQuery(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public String getQuery(PipelineContext context) throws ParametersException, ParserConfigurationException, SAXException, Exception {
		XMLRequest request = (XMLRequest) context.getRequest();
		
		Parameters params = request.getParameters();
		if (params.getString(PARAMETER_ID) != null) {
			//if parameter is present, add that to the list
			this.itemNumbers.add(params.getString(PARAMETER_ID));
			
			// check if all images of all items will be retrieved
			this.allImages = Boolean.valueOf(params.getString(PARAMETER_ALL_IMAGES));
		}

		if (context.getResponse() instanceof XMLResultset) {
			// retrieve all items in the current ResultSet
			this.resultset =(XMLResultset)context.getResponse();
			getExistingItemNumbers();
		}
		
		return getXQuery();
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getResultSize()
	 */
	@Override
	public int getResultSize() {
		// return all
		return 0;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getStartIndex()
	 */
	@Override
	public int getStartIndex() {
		// return from start
		return 0;
	}
	
	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafStage#getEmptyResultSet()
	 */
	@Override
	public XMLResultset getEmptyResultSet() {
        return null;        
	}
	
	/**
	 * Append a field to the ResultSet
	 * @param rs
	 * @param field
	 * @param value
	 * @throws ResultsetException
	 */
	private void appendField(XMLResultset rs, String field, String value) throws ResultsetException {
		if (rs  != null && field != null && value != null) {
			rs.appendField(field, value);
		}
	}
	
	/**
	 * Append a field to the ResultSet
	 * @param rs
	 * @param field
	 * @param value
	 * @throws ResultsetException
	 */
	private void appendField(XMLIterator rs, String field, String value) throws ResultsetException {
		if (rs  != null && field != null && value != null) {
			rs.appendField(field, value);
		}
	}
	
	/**
	 * Create a new ResultSet
	 * @return
	 * @throws ResultsetException
	 */
	private XMLResultset createResultset() throws ResultsetException {
		XMLResultset rsItems = new XMLResultset("<?xml version=\"1.0\" encoding=\"UTF-8\"?><resultset object=\"Item\"/>");
		rsItems.moveNext();
		
		// iterate through the images
		Iterator<String> it = this.images.keySet().iterator();
		while (it.hasNext() == true) {
			String key = it.next();
			List<Images> imgs = this.images.get(key);

			rsItems.appendRow();
			appendField(rsItems, ITEM_ID, key);

			// if there are images
			if (imgs.get(0) != null) {
				Images img = imgs.get(0);
				appendField(rsItems, IMAGE_MASTER, img.master);
				appendField(rsItems, IMAGE_PREVIEW, img.preview);
				appendField(rsItems, IMAGE_THUMB, img.thumb);
			}
			
			// if all images should be returned, create a subset
			if (this.allImages == true) {	
				// iterate through all iamges
				for (int i = 0; i < imgs.size(); i++) {
					Images img = imgs.get(i);

					XMLIterator rsImages = (XMLIterator) rsItems.appendResultset(ITEMIMAGES);
					rsImages.appendRow();

					// ImageID is just the iterator value. The expected value in the presentation is an integer.
					appendField(rsImages, IMAGE_ID, String.valueOf(i));
					appendField(rsImages, MASTER_IMAGE, img.master);
					appendField(rsImages, PREVIEW_IMAGE, img.preview);
					appendField(rsImages, THUMB_IMAGE, img.thumb);
				}
			}
		}
		
		return rsItems;
	}
	
	/**
	 * Set the element attribute
	 * @param e
	 * @param attribute
	 * @param value
	 */
	private void setAttribute(Element e, String attribute, String value) {
		if (e != null && attribute != null && value != null) {
			e.setAttribute(attribute, value);
		}
	}
	
	/**
	 * Replaces the image attributes in the existing ResultSet
	 * @throws ResultsetException
	 * @throws TransformerException
	 * @throws PipelineRuntimeException
	 */
	private void modifyResultset() throws ResultsetException, TransformerException, PipelineRuntimeException {
		if (this.resultset != null) {
			Document xmlDoc = this.resultset.getDocument();
			NodeList nodeList = XPathAPI.selectNodeList(xmlDoc, MAINSET_ITEMS);

			// iterate through the main set
			for (int i = 0; i < nodeList.getLength(); i++) {
				Element e = (Element) nodeList.item(i);
				
				// check if ItemID attribute exists
				String itemNumber = e.getAttribute(ITEM_ID);
				if (itemNumber == null || "".equals(itemNumber) == true) {
					// if not, check ItemNumber
					itemNumber = e.getAttribute(ITEM_NUMBER);
				}

				// if a valid ItemNumber/ItemID is present
				if (itemNumber != null && itemNumber.length() > 0) {
					List<Images> imgs = this.images.get(itemNumber);

					// if there are no images for the item, reset all attributes to default
					if (imgs == null || imgs.size() == 0) {
						LOG.debug("Resetting all attributes in mainset for item " + itemNumber);							
						e.removeAttribute(IMAGE_MASTER);						
						setAttribute(e, IMAGE_PREVIEW, getDefaultPreviewImage());
						setAttribute(e, IMAGE_THUMB, getDefaultThumbImage());
						
						// this is specific for Promotion BO
						e.removeAttribute(MASTER_IMAGE);
						setAttribute(e, PREVIEW_IMAGE, getDefaultPreviewImage());
						setAttribute(e, THUMB_IMAGE, getDefaultThumbImage());
					}
					else {
						// if there are images, use the URLs from DAF
						LOG.debug("Overwriting all attributes in mainset for item " + itemNumber);						
						Images img = imgs.get(0);
						e.setAttribute(IMAGE_MASTER, img.master);
						e.setAttribute(IMAGE_PREVIEW, img.preview);
						e.setAttribute(IMAGE_THUMB, img.thumb);
						
						// some BusinessObjects use different attributes
						e.setAttribute(MASTER_IMAGE, img.master);
						e.setAttribute(PREVIEW_IMAGE, img.preview);
						e.setAttribute(THUMB_IMAGE, img.thumb);
					}
					
					// this is for methods that want to retrieve all images and put them in a subset
					if (this.allImages == true) {
						
						// if all images will be retrieved, clear the subset
						LOG.debug("Removing all subsets for item " + itemNumber);						
						NodeList children = e.getChildNodes();
						for (int j = 0; j < children.getLength(); j++) {
							e.removeChild(children.item(j));
						}

						// and replace with a new one
						for (int j = 0; j < imgs.size(); j++) {
							LOG.debug("Creating child for item " + itemNumber);								
							Element itemImages = xmlDoc.createElement(ITEMIMAGES);
							setAttribute(itemImages, PREVIEW_IMAGE, imgs.get(j).preview);
							setAttribute(itemImages, THUMB_IMAGE, imgs.get(j).thumb);
							setAttribute(itemImages, MASTER_IMAGE, imgs.get(j).master);
							setAttribute(itemImages, IMAGE_ID, String.valueOf(j));
							e.appendChild(itemImages);
						}
					}
				}
				
				// This is for specific or CurrentOrder BO.
				NodeList childNodes = e.getChildNodes();
				for (int j = 0; j < childNodes.getLength(); j++) {
					Element c  = (Element)childNodes.item(j);
					
					// check if ItemID exists
					itemNumber = c.getAttribute(ITEM_ID);

					// if ItemID is missing, check ItemNumber
					if (itemNumber == null || "".equals(itemNumber) == true) {
						itemNumber = c.getAttribute(ITEM_NUMBER);
					}

					// if ItemNumber/ItemID is present
					if (itemNumber != null && itemNumber.length() > 0) {
						List<Images> imgs = this.images.get(itemNumber);

						// if no image from DAF, use the default thumbnail
						if (imgs == null || imgs.size() == 0) {
							setAttribute(c, ITEM_IMAGE_THUMB, getDefaultThumbImage());
						}
						else {
							setAttribute(c, ITEM_IMAGE_THUMB, imgs.get(0).thumb);
						}
					}
				}
			}
		}		
	}
	
	/**
	 * Returns the ResultSet
	 * @return
	 */
	private XMLResultset getResultset() {
		// if there is no ResultSet, create a new one
		if (this.resultset == null) {
			LOG.debug("Creating new resultset");

			try {								
				return createResultset();
			} catch (ResultsetException e) {
				LOG.error(e);
			}
		}
		else {
			// if there is, modify the existing one
			LOG.debug("Modifying existing resultset");			

			try {
				modifyResultset();
			} catch (Exception e) {
				e.printStackTrace();
				LOG.error(e);
			}
		}
		
		return null;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#processResult(com.intentia.icp.common.CMItems, int[])
	 */
	@Override
	public XMLResultset processResult(CMItems resultItems, int[] dafStatus) throws CMException, ParametersException {

		if (resultItems != null && resultItems.size() > 0) {
			LOG.debug("Number of images for item=" + resultItems.size());
			
			for (int i = 0; i < resultItems.size(); i++) {
				CMItem item = resultItems.get(i);
				String itemNumber = (String) item.getAttributeValue(DafItemImageConstants.Attribute.ITEM_NUMBER);
				
				// must have item number attribute
				if (itemNumber != null) {
					
					// if a new item, create an entry in the map with key = item number
					if (this.images.get(itemNumber) == null) {
						LOG.debug("Creating new Images list for=" + itemNumber);
						
						// the map will contain an ArrayList of images as value
						this.images.put(itemNumber, new ArrayList<Images>());
					}
					
					// if all images will be retrieved or if there is no image yet in the list
					if (this.allImages == true || (this.allImages == false && this.images.get(itemNumber).size() == 0)) {
						LOG.debug("Retrieving resource for item=" + item.getId());
						item.retrieveResources(this.connection);
						
						CMResources resources = item.getResources();					
						if (resources != null) {
							Images img = new Images();
						
							// iterate through the resources and search for the desired image types
							for (int j = 0; j < resources.size(); j++) {

								CMResource resource = resources.get(j);
								if (DafItemImageConstants.ImageType.PREVIEW.equals(resource.getAttributeValue(DafItemImageConstants.Resource.Attribute.IMAGE_TYPE)) == true) {
									img.preview = resource.getUrl().toString();
								}

								if (DafItemImageConstants.ImageType.THUMBNAIL.equals(resource.getAttributeValue(DafItemImageConstants.Resource.Attribute.IMAGE_TYPE)) == true) {
									img.thumb = resource.getUrl().toString();
								}
								
								if (DafItemImageConstants.ImageType.MASTER.equals(resource.getAttributeValue(DafItemImageConstants.Resource.Attribute.IMAGE_TYPE)) == true) {
									img.master = resource.getUrl().toString();
								}
							}

							// only add to the list if a valid image is present in the resource
							if (img.preview != null || img.thumb != null || img.master != null) {
								this.images.get(itemNumber).add(img);	
							}
						}								
					}
					else {
						// skipping because an image already exists for the item
						LOG.debug("Skipping resource for item=" + item.getId());
					}
				}
			}
		}
		return getResultset();
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#setOutputParameters(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public void setOutputParameters(PipelineContext context) throws PipelineRuntimeException {
		// intentionally blank
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafStage#getAttributeToDafDatabaseField(java.lang.String)
	 */
	@Override
	public String getAttributeToDafDatabaseField(String attribute) {
		return null;
	}
	
	/**
	 * Retrieve the default thumbnail image from the database
	 * @return
	 * @throws PipelineRuntimeException
	 */
	private String getDefaultThumbImage() throws PipelineRuntimeException {
		if (this.defaultThumb == null) {
			this.defaultThumb = getRootUrlPath() + getValueFromApplicationData(PARAM_DEFAULT_THUMB);
		}
		
		return this.defaultThumb;
	}
	
	/**
	 * Retrieve the default preview image from the database
	 * @return
	 * @throws PipelineRuntimeException
	 */
	private String getDefaultPreviewImage() throws PipelineRuntimeException {
		if (this.defaultPreview == null) {
			this.defaultPreview = getRootUrlPath() + getValueFromApplicationData(PARAM_DEFAULT_PREVIEW);
		}
		
		return this.defaultPreview;
	}

    /**
     * Get Images Root URL from Application Data.
     * @throws PipelineRuntimeException
     */
    private String getRootUrlPath() throws PipelineRuntimeException {

    	String imageRootPath = getValueFromApplicationData(APP_DETAILS_ROOT_URL);

        if (null == imageRootPath) {
            FastStringBuffer msg = new FastStringBuffer(100);
            msg.append("Missing application data: ").append(APP_DETAILS_ROOT_URL);
            throw new PipelineRuntimeException(msg.toString());
        }
        LOG.debug("Images rootUrl Path: " + imageRootPath.toString());
        return imageRootPath;
    }

    /**
     * Helper method for getting the connection parameters.
     * @param paramName
     * @return
     */
    private String getValueFromApplicationData(String paramName) {

        String paramValue = null;

        SearchPipelineExecuter spe = new SearchPipelineExecuter(
        		ConstantsForSales.PIPELINE_PACKAGE, ConstantsForSales.APPLICATION_DATA,
        		ConstantsForSales.APPLICATION_DATA_DETAILS);

        spe.setParam(PARAM, paramName);

        try {
            XMLResultset rs = spe.execute();
            rs.moveFirst();
            paramValue = rs.getString(PARAM_VALUE);
        } catch (PipelineRuntimeException e) {
            paramValue = "";
        } catch (ResultsetException e) {
            paramValue = "";
        }

        return paramValue;
    }
}
