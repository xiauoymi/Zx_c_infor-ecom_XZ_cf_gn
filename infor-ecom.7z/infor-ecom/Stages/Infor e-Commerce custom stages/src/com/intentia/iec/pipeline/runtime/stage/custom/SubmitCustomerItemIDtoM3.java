package com.intentia.iec.pipeline.runtime.stage.custom;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.connection.ConnectorException;
import com.intentia.iec.connection.IMovexApiResultset;
import com.intentia.iec.connection.IMovexConnection;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;

/**
 * Stage to send Customer Item M3 through API program OIS005MI.
 * <p>
 * The stage will exit immediately if application property
 * <code>Movex Connector / Enable</code> is false.
 * <p>
 */
public class SubmitCustomerItemIDtoM3 implements PipelineStage {

    private IMovexConnection movex = null;

    private static final Logger LOG = Logger.getLogger(SubmitCustomerItemIDtoM3.class);

    public void execute(PipelineContext context) throws PipelineRuntimeException {
        // Movex connector not enabled => skip stage
        if (!"true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.CONNECTORENABLED))) {
            return;
        }

        // Retreive XML request from context
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }

        try {
            movex = (IMovexConnection) CustomStagesHelper.getConnection(ConstantsForSales.OIS005MI);
            if (movex == null) {
                return;
            }

            Document request;
            XMLRequest xmlRequest;
            try {
                CustomStagesHelper.extractRequestParameters(CustomStagesHelper.getRequest(context));
                xmlRequest = (XMLRequest) context.getRequest();
                request = xmlRequest.getRequestDoc();
            } catch (Exception e) {
                throw new PipelineRuntimeException("Failed to obtain XML request document from request", e);
            }
            String customerNumber = xmlRequest.getParameters().getString("Customer");
            updateCustomerItemInM3(context, request, customerNumber);
        } catch (ParametersException e) {

        } finally {
            LOG.debug("Inside SubmitCustomerItemIDtoM3 closing connection............... ");
            if (movex != null) {
                try {
                    movex.close(); // close connection
                } catch (ConnectorException e) {
                    LOG.error("Failed to close connection!");
                }
            }
        }
    }

    /**
     * Update the Customer Item in entry by calling OIS005MI.Add and
     * OIS005MI.Del if need. There is no update method in M3.
     * 
     * @param context
     *            The response to put output in.
     * @param request
     *            the request to use.
     * @param customerNumber
     *            Customer Number
     * @throws PipelineRuntimeException
     */
    private void updateCustomerItemInM3(PipelineContext context, Document request, String customerNumber)
            throws PipelineRuntimeException {
        try {

            NodeList nodeList = XPathAPI.selectNodeList(request, "request/entities/entity/attributes");

            for (int j = 0; j < nodeList.getLength(); j++) {
                Node node = nodeList.item(j);
                NodeList attributeList = node.getChildNodes();
                String itemNumber = null;
                String customerItemID = null;
                for (int al = 0; al < attributeList.getLength(); al++) {
                    Node attribute = attributeList.item(al);
                    String nodeName = attribute.getAttributes().getNamedItem("name").getNodeValue();
                    if (nodeName.equals(ConstantsForSales.ITEMNUMBER)) {
                        if (attribute.getFirstChild().getNodeType() == Node.TEXT_NODE) {
                            itemNumber = attribute.getFirstChild().getNodeValue().toUpperCase();
                        }
                    } else if (nodeName.equals(ConstantsForSales.CUSTOMERITEMID)) {
                        if (attribute.getFirstChild().getNodeType() == Node.TEXT_NODE) {
                            customerItemID = attribute.getFirstChild().getNodeValue();
                        }
                    }
                }
                if (customerNumber != null && (!"".equals(customerNumber))) {
                    if (itemNumber != null && (!"".equals(itemNumber))) {

                        // Get Customer Item ID for Item
                        Map m3Inputs = new HashMap();
                        m3Inputs.put(IMovexConnection.TRANSACTION, ConstantsForSales.GET);
                        m3Inputs.put(ConstantsForSales.CUNO, customerNumber);
                        m3Inputs.put(ConstantsForSales.ITNO, itemNumber);

                        IMovexApiResultset m3result = CustomStagesHelper.callMovex(context, movex, m3Inputs,
                                "mvxStatus");

                        if (m3result.size() > 0) {
                            Map delCID = new HashMap();
                            delCID.put(IMovexConnection.TRANSACTION, ConstantsForSales.DEL);
                            delCID.put(ConstantsForSales.CUNO, customerNumber);
                            delCID.put(ConstantsForSales.ITNO, itemNumber);
                            m3result = CustomStagesHelper.callMovex(context, movex, delCID, "mvxStatus");
                        }

                        Map addCID = new HashMap();
                        addCID.put(IMovexConnection.TRANSACTION, ConstantsForSales.ADD);
                        addCID.put(ConstantsForSales.CUNO, customerNumber);
                        addCID.put(ConstantsForSales.ITNO, itemNumber);
                        addCID.put(ConstantsForSales.POPN, customerItemID);

                        m3result = CustomStagesHelper.callMovex(context, movex, addCID, "mvxStatus");
                    }

                }
            }

        } catch (Exception e) {
            throw new PipelineRuntimeException("Error in HandleOrderLines stage - internalOrderlineHandling function",
                    e);
        }
    }

}
