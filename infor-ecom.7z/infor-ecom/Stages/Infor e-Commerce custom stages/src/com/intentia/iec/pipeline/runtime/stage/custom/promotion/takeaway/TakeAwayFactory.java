/**
 * 
 */
package com.intentia.iec.pipeline.runtime.stage.custom.promotion.takeaway;

/**
 * @author gsantiago /mgumali
 * 
 */
public abstract class TakeAwayFactory {

	public static TakeAway getTakeAway(String takeawayType){
		TakeAway takeaway = null;
		if(TakeAwayConstant.FREE_ITEM.equals(takeawayType)){
			takeaway = FreeItemImpl.getInstance();
		} else if(TakeAwayConstant.PRICE_DISCOUNT.equals(takeawayType)){
			takeaway = PriceDiscountImpl.getInstance();
		} else if(TakeAwayConstant.FIX_PRICE.equals(takeawayType)){
			takeaway = FixPriceImpl.getInstance();
		} else if(TakeAwayConstant.FREE_SHIPPING.equals(takeawayType)){
			takeaway = FreeShippingImpl.getInstance();
		}
		return takeaway;
	}

}
