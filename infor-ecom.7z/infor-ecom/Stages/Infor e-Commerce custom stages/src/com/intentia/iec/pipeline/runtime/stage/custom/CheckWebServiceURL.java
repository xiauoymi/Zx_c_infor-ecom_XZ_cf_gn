package com.intentia.iec.pipeline.runtime.stage.custom;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import java.io.File;

/*
**	This custom stage checks the feature type 3 parameter from the request and validate it in the WebServiceURL repository path
**	This will return
		isLogoQuestion = "Y" : if WebServiceURL exists. 
		otherwise
		isLogoQuestion = "N"
**/

public class CheckWebServiceURL implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(CheckWebServiceURL.class);

    private XMLRequest xmlRequest = null;

    public void execute(PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("Entering CheckWebServiceURL.execute()");
		
	XMLResultset response = new XMLResultset();

	context.setResponse(response);

        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
        xmlRequest = (XMLRequest) context.getRequest();

        try {
            XMLRequest.extractRequestParameters(xmlRequest);
        } catch (RequestException e) {
            throw new PipelineRuntimeException("Error extracting request parameters!", e);
        }

        // Movex connector not enabled => skip stage
        if (!"true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.CONNECTORENABLED))) {
            return;
        }

        String Feature3Question = getFeature3QuestionParam();
        
		if (Feature3Question.indexOf("Logo ID") == 0) {
			CustomStagesHelper.setResponseParameter(context, "isLogoQuestion", "Y");
		} else {
			CustomStagesHelper.setResponseParameter(context, "isLogoQuestion", "N");
	    }
        LOG.debug("Exiting CheckWebServiceURL.execute()");
    }

    private String getFeature3QuestionParam() {
        LOG.debug("Entering CheckWebServiceURL.getFeature3QuestionParam");
        String Feature3Question = "";
        try {
            Feature3Question = xmlRequest.getParameters().getString("Feature3Question");
			LOG.debug("Feature Type 3 question :" +Feature3Question);
        } catch (ParametersException e) {
            LOG.debug("Feature Type 3 question is not in the request parameters.");
        }
        LOG.debug("Exiting CheckWebServiceURL.getFeature3QuestionParam");
        return Feature3Question;
    }
}