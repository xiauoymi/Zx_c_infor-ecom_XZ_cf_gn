package com.intentia.iec.pipeline.runtime.stage.custom;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.stage.utils.ApplicationParameter;

/**
 * This class is a Helper Class for Google Base Functionality Where it load the
 * SearchEngineItemBean from Resultset. Also using as a utility class.
 * 
 * @author xinc0082(Mayur)
 */
public class SearchEngineHelper {

    private static final Logger LOG = Logger.getLogger(SearchEngineHelper.class);

    public static String INSERT_SQL = "select [main].[id]	AS [ItemID], "
            + "	    [main].[itemNumber] AS [Number], "
            + "	    [itemtext].[name] AS [ItemName],"
            + "	    [itemtext].[description] AS [Description],"
            + "	    [itemimages].[previewImage] AS [ImageURL], "
            + "	    [brand].[name] AS [Brand],"
            + "	    [price].[amount] AS [Amount],"
            + "	    [codetext].[text] AS [Unit] "
            + "from Item as [main] LEFT JOIN ItemImages as [itemimages] ON"
            + " [main].[itemNumber]=[itemimages].[itemNumber] AND [itemimages].[defaultImage]='Y' LEFT JOIN Brand as [brand] ON"
            + "	 [main].[brandId]=[brand].[id] " + "Join [ItemText] as itemtext ON"
            + "	[main].[id] = [itemtext].[itemId] and [itemtext].[languageCode]=? "
            + "JOIN [Currency] AS [currency] ON [currency].[currencyCode]=? "
            + "JOIN [PriceGroup] AS [pricegroup] ON [pricegroup].[name]= ? "
            + "Left JOIN [Price] AS [price] ON [price].[itemId]=[main].[id] AND"
            + "						[price].[priceGroupId]=[pricegroup].[id] AND" + "						[price].[currencyCode]=? "
            + "Left join [Code] AS[code] ON [code].[id]=[main].[unitCodeId] "
            + "  			Left join [CodeText] AS [codetext]ON [codetext].[codeId]=[code].[id]"
            + "				and [codetext].[languageCode]=? "
            + "LEFT JOIN [SearchEngineItem] as gi on gi.[itemId]=[main].[id]  and gi.[searchEngineSystemId] = ? "
            + "where gi.[itemId] is  NULL AND [main].[isActive]='Y' ";

    public static String UPDATE_SQL = "select [main].[id]	AS [ItemID], "
            + "		[main].[itemNumber] AS [Number],"
            + "		[itemtext].[name] AS [ItemName],"
            + "		[itemtext].[description]AS [Description],"
            + "		[itemimages].[previewImage] AS [ImageURL],"
            + "	    [brand].[name] AS [Brand],"
            + "		[price].[amount] AS [Amount],"
            + "		[main].[unitCodeId] AS [UnitId],"
            + "		[codetext].[text] AS [Unit],"
            + "		[gi].[searchEngineItemId] AS [SearchEngineItemId]"
            + "from Item as [main] LEFT JOIN ItemImages as [itemimages] ON"
            + " [main].[itemNumber]=[itemimages].[itemNumber] AND [itemimages].[defaultImage]='Y' LEFT JOIN Brand as [brand] ON "
            + "	 [main].[brandId]=[brand].[id] " + "Join [ItemText] as itemtext ON"
            + "	[main].[id] = [itemtext].[itemId] and [itemtext].[languageCode] = ? "
            + "JOIN [Currency] AS [currency] ON [currency].[currencyCode] = ? "
            + "JOIN [PriceGroup] AS [pricegroup] ON [pricegroup].[name] = ? "
            + "Left JOIN [Price] AS [price] ON [price].[itemId]=[main].[id] AND"
            + "						[price].[priceGroupId]=[pricegroup].[id] AND" + "						[price].[currencyCode]=? "
            + "Left join [Code] AS[code] ON [code].[id]=[main].[unitCodeId]"
            + "			Left join [CodeText] AS [codetext]ON [codetext].[codeId]=[code].[id]"
            + "							and [codetext].[languageCode]=? "
            + "LEFT JOIN [SearchEngineItem] as gi on gi.[itemId]=[main].[id]"
            + "where gi.[itemId] is NOT NULL and gi.[searchEngineSystemId]= ? ";

    public static String DELETE_SQL = "SELECT [main].[searchEngineItemId] AS [SearchEngineItemId] from [SearchEngineItem] AS [main] where [main].[itemId] IS NULL ";

    public static String DELETEITEM_SQL = "DELETE FROM SearchEngineItem WHERE [SearchEngineItem].[searchEngineItemId] LIKE ? ";

    public static String DELETEITEM_ONLYFROM_SEARCHENGINE = "SELECT [main].[searchEngineItemId] AS [SearchEngineItemId] FROM [SearchEngineItem] AS [main] ";

    public static String INSERTSearchEngineItem_SQL = "INSERT INTO SearchEngineItem (itemId, searchEngineSystemId, searchEngineItemId) values (?, ?, ?) ";

    public static String Exchange_Rate_SQL = "Select [main].[exchangeRate] from [Currency] as [main]"
            + "where [main].[currencyCode]=? ";

    public static String INSERT_ASSORTMENTS = "SELECT DISTINCT [main].[id] AS [ItemID], "
            + "			[main].[itemNumber] AS [Number],  "
            + "			[itemtext].[name] AS [ItemName], "
            + "			[itemtext].[description] AS [Description], "
            + "			[itemimages].[previewImage] AS [ImageURL],  "
            + "			[brand].[name] AS [Brand], "
            + "			[price].[amount] AS [Amount], "
            + "			[codetext].[text] AS [Unit]   "
            + "	FROM Item AS [main] "
            + "	LEFT JOIN ItemImages AS [itemimages] ON [main].[itemNumber]=[itemimages].[itemNumber] AND [itemimages].[defaultImage]='Y' "
            + "	LEFT JOIN Brand AS [brand] ON [main].[brandId]=[brand].[id]  "
            + "	JOIN [ItemText] AS itemtext ON[main].[id] = [itemtext].[itemId] and [itemtext].[languageCode]= ? "
            + "	JOIN [Currency] AS [currency] ON [currency].[currencyCode] = ? "
            + "	JOIN [PriceGroup] AS [pricegroup] ON [pricegroup].[name] = ? "
            + "	LEFT JOIN [Price] AS [price] ON [price].[itemId]=[main].[id] AND [price].[priceGroupId]=[pricegroup].[id] "
            + "	AND [price].[currencyCode] = ? "
            + "	LEFT JOIN [Code] AS [code] ON [code].[id]=[main].[unitCodeId] "
            + "	LEFT JOIN [CodeText] AS [codetext]ON [codetext].[codeId]=[code].[id] and [codetext].[languageCode] = ? "
            + "	LEFT JOIN [SearchEngineItem] AS [gi] ON [gi].[itemId]=[main].[id]  and [gi].[searchEngineSystemId] = ? "
            + "	LEFT JOIN [CategoryExplosion] [ce] ON [main].[mainCategoryId] = [ce].[descendantId] "
            + "	INNER JOIN [AssortmentCategory] [ac] ON [ce].[parentId] = [ac].[categoryId] AND "
            + " [ac].[assortmentId] IN (SELECT [as].[assortmentId] FROM AssortmentSearchEngine AS [as]) "
            + "	WHERE [gi].[itemId] IS  NULL AND [main].[isActive]='Y' "
            + "	UNION "
            + "	SELECT DISTINCT [main].[id] AS [ItemID], "
            + "			[main].[itemNumber] AS [Number],  "
            + "			[itemtext].[name] AS [ItemName], "
            + "			[itemtext].[description] AS [Description], "
            + "			[itemimages].[previewImage] AS [ImageURL],  "
            + "			[brand].[name] AS [Brand], "
            + "			[price].[amount] AS [Amount], "
            + "			[codetext].[text] AS [Unit]   "
            + "	FROM Item AS [main] "
            + "	LEFT JOIN ItemImages AS [itemimages] ON [main].[itemNumber]=[itemimages].[itemNumber] AND [itemimages].[defaultImage]='Y' "
            + "	LEFT JOIN Brand AS [brand] ON [main].[brandId]=[brand].[id]  "
            + "	JOIN [ItemText] AS itemtext ON[main].[id] = [itemtext].[itemId] and [itemtext].[languageCode] = ? "
            + "	JOIN [Currency] AS [currency] ON [currency].[currencyCode] = ? "
            + "	JOIN [PriceGroup] AS [pricegroup] ON [pricegroup].[name] = ? "
            + "	LEFT JOIN [Price] AS [price] ON [price].[itemId]=[main].[id] AND [price].[priceGroupId]=[pricegroup].[id] "
            + "	AND [price].[currencyCode] = ? "
            + "	LEFT JOIN [Code] AS [code] ON [code].[id]=[main].[unitCodeId]   "
            + "	LEFT JOIN [CodeText] AS [codetext]ON [codetext].[codeId]=[code].[id] and [codetext].[languageCode] = ? "
            + "	LEFT JOIN [SearchEngineItem] AS [gi] ON [gi].[itemId]=[main].[id]  and [gi].[searchEngineSystemId] = ? "
            + "	INNER JOIN [AssortmentItem] AS [ai] ON [main].[id]  = [ai].[itemId] AND "
            + " [ai].[assortmentId] IN (SELECT [as].[assortmentId] FROM AssortmentSearchEngine AS [as]) "
            + "	WHERE [gi].[itemId] IS  NULL AND [main].[isActive]='Y'  ";

    public static String UPDATE_ASSORTMENTS = "SELECT DISTINCT [main].[id] AS [ItemID],  "
            + "		[main].[itemNumber] AS [Number], "
            + "		[itemtext].[name] AS [ItemName], "
            + "		[itemtext].[description]AS [Description], "
            + "		[itemimages].[previewImage] AS [ImageURL], "
            + "		[brand].[name] AS [Brand], "
            + "		[price].[amount] AS [Amount], "
            + "		[main].[unitCodeId] AS [UnitId], "
            + "		[codetext].[text] AS [Unit], "
            + "		[gi].[searchEngineItemId] AS [SearchEngineItemId] "
            + "from Item as [main] LEFT JOIN ItemImages as [itemimages] ON "
            + " [main].[itemNumber]=[itemimages].[itemNumber] AND [itemimages].[defaultImage]='Y' LEFT JOIN Brand as [brand] ON "
            + "	 [main].[brandId]=[brand].[id]  "
            + "Join [ItemText] as itemtext ON "
            + "	[main].[id] = [itemtext].[itemId] and [itemtext].[languageCode] = ?   "
            + "JOIN [Currency] AS [currency] ON [currency].[currencyCode] = ?  "
            + "JOIN [PriceGroup] AS [pricegroup] ON [pricegroup].[name] = ? "
            + "Left JOIN [Price] AS [price] ON [price].[itemId]=[main].[id] AND "
            + "						[price].[priceGroupId]=[pricegroup].[id] AND  "
            + "						[price].[currencyCode] = ?  "
            + "Left join [Code] AS[code] ON [code].[id]=[main].[unitCodeId]  "
            + "			Left join [CodeText] AS [codetext]ON [codetext].[codeId]=[code].[id] "
            + "							and [codetext].[languageCode] = ?  "
            + "LEFT JOIN [SearchEngineItem] as gi on gi.[itemId]=[main].[id] "
            + "LEFT JOIN [CategoryExplosion] [ce] ON [main].[mainCategoryId] = [ce].[descendantId] "
            + "INNER JOIN [AssortmentCategory] [ac] ON [ce].[parentId] = [ac].[categoryId] AND  "
            + " [ac].[assortmentId] IN (SELECT [as].[assortmentId] FROM AssortmentSearchEngine AS [as]) "
            + "where gi.[itemId] is NOT NULL and gi.[searchEngineSystemId]= ? "
            + "UNION "
            + "SELECT DISTINCT [main].[id] AS [ItemID],  "
            + "		[main].[itemNumber] AS [Number], "
            + "		[itemtext].[name] AS [ItemName], "
            + "		[itemtext].[description]AS [Description], "
            + "		[itemimages].[previewImage] AS [ImageURL], "
            + "		[brand].[name] AS [Brand], "
            + "		[price].[amount] AS [Amount], "
            + "		[main].[unitCodeId] AS [UnitId], "
            + "		[codetext].[text] AS [Unit], "
            + "		[gi].[searchEngineItemId] AS [SearchEngineItemId] "
            + "from Item as [main] LEFT JOIN ItemImages as [itemimages] ON "
            + "[main].[itemNumber]=[itemimages].[itemNumber] AND [itemimages].[defaultImage]='Y' LEFT JOIN Brand as [brand] ON  "
            + "	 [main].[brandId]=[brand].[id]  " + "Join [ItemText] as itemtext ON "
            + "	[main].[id] = [itemtext].[itemId] and [itemtext].[languageCode] = ?  "
            + "JOIN [Currency] AS [currency] ON [currency].[currencyCode] = ?  "
            + "JOIN [PriceGroup] AS [pricegroup] ON [pricegroup].[name] = ?  "
            + "Left JOIN [Price] AS [price] ON [price].[itemId]=[main].[id] AND "
            + "						[price].[priceGroupId]=[pricegroup].[id] AND  " + "						[price].[currencyCode] = ?  "
            + "Left join [Code] AS[code] ON [code].[id]=[main].[unitCodeId]  "
            + "			Left join [CodeText] AS [codetext]ON [codetext].[codeId]=[code].[id] "
            + "							and [codetext].[languageCode] = ?  "
            + "LEFT JOIN [SearchEngineItem] as gi on gi.[itemId]=[main].[id] "
            + "INNER JOIN [AssortmentItem] AS [ai] ON [main].[id]  = [ai].[itemId] AND "
            + "[ai].[assortmentId] IN (SELECT [as].[assortmentId] FROM AssortmentSearchEngine AS [as]) "
            + "where gi.[itemId] is NOT NULL and gi.[searchEngineSystemId]= ? ";

    public static String CHECK_ASSORTMENT = "SELECT * FROM AssortmentSearchEngine";

    public static String SELECT_SEARCHENGINES = "SELECT * FROM [SearchEngineSystem] WHERE flag = 'Y' ";

    public static String DEFAULT_MARKET_DATA = "SELECT [main].[id],[main].[listPriceGroupName],[main].[currencyCode] "
            + "FROM Market as [main] , UserGroup as [usergroup]"
            + "WHERE [usergroup].[marketId]=[main].[id] AND [usergroup].[name]='GuestB2C' ";

    public static final String TESTIMAGE_URL = "DefSearchEngineImageURL";

    public static SearchEngineItemBean getSearchEngineBeanForInsert(XMLResultset rs, String appUrl) {
        SearchEngineItemBean gbsItemBean = new SearchEngineItemBean();

        Long id = null;
        String baseUrl = null;
        String itemId = null;
        String title = null;
        String content = null;
        String unit = null;
        String itemDescription = null;
        float price = 0.0f;
        String summary = null;
        String imageURL = null;
        String brand = null;
        String testImageURL = null;

        LOG.debug("Inside SearchEngineHelper.getSearchEngineBeanForInsert()");

        try {

            id = new Long(rs.getString("ItemID"));
            itemId = rs.getString("Number");
            baseUrl = appUrl + "/esa/ItemDetails.jsp?@where.ItemID@EQ=" + itemId;

            title = rs.getString("ItemName");
            if (title == null) {
                title = "";
            }
            content = rs.getString("Description");
            if (content == null) {
                content = "";
            }
            unit = rs.getString("Unit");
            if (unit == null) {
                unit = "";
            }
            itemDescription = rs.getString("Description");
            if (itemDescription == null) {
                itemDescription = "";
            }
            if (rs.getString("Amount") == null) {
                price = 0.0f;
            } else {
                price = Float.parseFloat(rs.getString("Amount"));
            }
            summary = rs.getString("Description");
            if (summary == null) {
                summary = "";
            }

            // Setting Image URL to Upload Image on the Server
            try {
                testImageURL = ApplicationParameter.getValue(TESTIMAGE_URL).trim();
            } catch (Exception ex) {
                LOG
                        .error(
                                "Exception Occurred inside SearchEngineHelper.getSearchEngineBeanForInsert() in getting testImageURL = ",
                                ex);
                testImageURL = null;
            }

            if (testImageURL != null) {
                imageURL = testImageURL;
                LOG.debug("Inside getSearchEngineItemBeanForUpdate() imageURL = " + imageURL);
            } else if (testImageURL == null && rs.getString("ImageURL") == null) {
                imageURL = ApplicationParameter.getValue("ApplicationURLB2C").trim() + "/item/default/preview.jpg";
            } else if (testImageURL == null && rs.getString("ImageURL") != null) {
                imageURL = ApplicationParameter.getValue("ApplicationURLB2C").trim() + "/" + rs.getString("ImageURL");
            }

            brand = rs.getString("brand");
            if (brand == null) {
                brand = "";
            }

            // setter methods
            gbsItemBean.setId(id);
            gbsItemBean.setBaseUrl(baseUrl);
            gbsItemBean.setTitle(title);
            gbsItemBean.setContent(content);
            gbsItemBean.setUnit(unit);
            gbsItemBean.setItemDescription(itemDescription);
            gbsItemBean.setPrice(price);
            gbsItemBean.setSummary(summary);
            gbsItemBean.setImageURL(imageURL);
            gbsItemBean.setBrand(brand);

        } catch (Exception e) {
            LOG.error("Inside SearchEngineHelper.getSearchEngineBeanForInsert().....", e);
        }
        return gbsItemBean;
    } // end of getSearchEngineBeanForInsert()

    public static SearchEngineItemBean getSearchEngineItemBeanForUpdate(XMLResultset rs, String appUrl) {
        SearchEngineItemBean gbsItemBean = new SearchEngineItemBean();

        Long id = null;
        String baseUrl = null;
        String itemId = null;
        String title = null;
        String content = null;
        String unit = null;
        String itemDescription = null;
        float price = 0.0f;
        String summary = null;
        String imageURL = null;
        String brand = null;
        String searchEngineItemId = null;
        String testImageURL = null;

        LOG.debug("Inside SearchEngineItemBean.getSearchEngineItemBeanForUpdate()");

        try {
            id = new Long(rs.getString("ItemID"));
            itemId = rs.getString("Number");
            baseUrl = appUrl + "/esa/ItemDetails.jsp?@where.ItemID@EQ=" + itemId;

            title = rs.getString("ItemName");
            if (title == null) {
                title = "";
            }
            content = rs.getString("Description");
            if (content == null) {
                content = "";
            }
            unit = rs.getString("Unit");
            if (unit == null) {
                unit = "";
            }
            itemDescription = rs.getString("Description");
            if (itemDescription == null) {
                itemDescription = "";
            }
            if (rs.getString("Amount") == null) {
                price = 0.0f;
            } else {
                price = Float.parseFloat(rs.getString("Amount"));
            }
            summary = rs.getString("Description");
            if (summary == null) {
                summary = "";
            }

            // Setting Image URL to Upload Image on the Server
            try {
                testImageURL = ApplicationParameter.getValue(TESTIMAGE_URL).trim();
            } catch (Exception ex) {
                LOG
                        .error(
                                "Exception Occurred inside SearchEngineItemBean.getSearchEngineItemBeanForUpdate() in getting testImageURL = ",
                                ex);
                testImageURL = null;
            }

            if (testImageURL != null) {
                imageURL = testImageURL;
                LOG.debug("Inside getSearchEngineItemBeanForUpdate() imageURL = " + imageURL);
            } else if (testImageURL == null && rs.getString("ImageURL") == null) {
                imageURL = ApplicationParameter.getValue("ApplicationURLB2C").trim() + "/item/default/preview.jpg";
            } else if (testImageURL == null && rs.getString("ImageURL") != null) {
                imageURL = ApplicationParameter.getValue("ApplicationURLB2C").trim() + "/" + rs.getString("ImageURL");
            }

            brand = rs.getString("brand");
            if (brand == null) {
                brand = "";
            }
            searchEngineItemId = rs.getString("SearchEngineItemId");
            if (searchEngineItemId == null) {
                searchEngineItemId = null;
            }

            // setter methods
            gbsItemBean.setId(id);
            gbsItemBean.setBaseUrl(baseUrl);
            gbsItemBean.setTitle(title);
            gbsItemBean.setContent(content);
            gbsItemBean.setUnit(unit);
            gbsItemBean.setItemDescription(itemDescription);
            gbsItemBean.setPrice(price);
            gbsItemBean.setSummary(summary);
            gbsItemBean.setImageURL(imageURL);
            gbsItemBean.setBrand(brand);
            gbsItemBean.setSearchEngineItemId(searchEngineItemId);

        } catch (Exception e) {
            LOG.error("Inside getSearchEngineItemBeanForUpdate().....", e);
        }
        return gbsItemBean;

    }// end of getSearchEngineItemBeanForUpdate()

}
