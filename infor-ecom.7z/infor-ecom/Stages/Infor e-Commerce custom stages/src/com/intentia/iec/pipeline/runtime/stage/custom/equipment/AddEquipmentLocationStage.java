package com.intentia.iec.pipeline.runtime.stage.custom.equipment;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.connection.ConnectorException;
import com.intentia.iec.connection.IMovexApiResultset;
import com.intentia.iec.connection.IMovexConnection;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;

/**
 * This class calls MOS272MI-Add.
 *
 */
public class AddEquipmentLocationStage implements PipelineStage {
	
	private static final Logger LOG = Logger.getLogger(AddEquipmentLocationStage.class);
	
	private IMovexConnection movex = null; 
	
	private static final String MOS272MI = "esales.MOS272MI";
	
	private static final String PROGRAM_ADD = "Add";
	
	private static final String REQUEST_CONO = "CONO";
	
	private static final String REQUEST_REG_NUM = "regnum";
	
	private static final String REQUEST_START_DATE = "sdate";
	
	private static final String REQUEST_START_TIME = "stime";
	
	private static final String REQUEST_COORDINATE_X = "cx";
	
	private static final String REQUEST_COORDINATE_Y = "cy";
	
	private static final String REQUEST_COORDINATE_Z = "cz";
	
	private static final String REQUEST_CUSTOMER_NAME = "cname";
	
	private static final String REQUEST_CUSTOMER_ADDRESS1 = "cua1";
	
	private static final String REQUEST_CUSTOMER_ADDRESS2 = "cua2";
	
	private static final String REQUEST_CUSTOMER_ADDRESS3 = "cua3";
	
	private static final String REQUEST_CUSTOMER_ADDRESS4 = "cua4";
	
	private static final String REQUEST_POSTAL_CODE = "pcode";
	
	private static final String REQUEST_ITEM_NUMBER = "itno";
	
	private static final String REQUEST_DECIMALSEPARATOR = "decimalseparator";
	
	private static final String CONO = "CONO";
	
	private static final String TAIL = "TAIL";
	
	private static final String STDT = "STDT";
	
	private static final String STTI = "STTI";
	
	private static final String CORX = "CORX";
	
	private static final String CORY = "CORY";
	
	private static final String CORZ = "CORZ";
	
	private static final String CUA1 = "CUA1";
	
	private static final String CUA2 = "CUA2";
	
	private static final String CUA3 = "CUA3";
	
	private static final String CUA4 = "CUA4";
	
	private static final String CUNO = "CUNO";
	
	private static final String CUNM = "CUNM";
	
	private static final String PONO = "PONO";
	
	private static final String ITNO = "ITNO";
	
	private static final String SERN = "SERN";
	
	private static final String MVXSTATUS = "mvxStatus";

	public void execute(PipelineContext context) throws PipelineRuntimeException {
        // Movex connector not enabled => skip stage
        if (!"true".equals(CustomStagesHelper.getKeyValue(ConstantsForSales.CONNECTORENABLED))) {
            return;
        }
        
        // Retrieve XML request from context
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }
        
        XMLRequest request = (XMLRequest) context.getRequest();        	
    	Parameters parameters = request.getParameters(); 
    	int status = -1;

		try {
	    	// check if parameters are present
	    	if (parameters != null) {
	    		String m3Company = parameters.getString(REQUEST_CONO);
	    		String registrationNumber = parameters.getString(REQUEST_REG_NUM);
	    		String decimalSeparator = parameters.getString(REQUEST_DECIMALSEPARATOR);
	    		Date startDate = null;
	    		try {
	    			startDate = parameters.getDate(REQUEST_START_DATE);	
	    		}
	    		catch(ParametersException e) {	 
	    			LOG.error("Start date not specified", e);
	    		}
	    		
	    		// extract parameters
	    		String startTime = parameters.getString(REQUEST_START_TIME);
	    		String coordinateX = parameters.getString(REQUEST_COORDINATE_X);
	    		String coordinateY = parameters.getString(REQUEST_COORDINATE_Y);
	    		String coordinateZ = parameters.getString(REQUEST_COORDINATE_Z);
	    		String cname = parameters.getString(REQUEST_CUSTOMER_NAME);
	    		String cua1 = parameters.getString(REQUEST_CUSTOMER_ADDRESS1);
	    		String cua2 = parameters.getString(REQUEST_CUSTOMER_ADDRESS2);
	    		String cua3 = parameters.getString(REQUEST_CUSTOMER_ADDRESS3);
	    		String cua4 = parameters.getString(REQUEST_CUSTOMER_ADDRESS4);
	    		String postalCode = parameters.getString(REQUEST_POSTAL_CODE);
	    		String itemNumber = parameters.getString(REQUEST_ITEM_NUMBER);
	    		
	    		status = addLocation(context, m3Company, registrationNumber, startDate, startTime, coordinateX, coordinateY, coordinateZ, cname, cua1, cua2, cua3, cua4, postalCode, itemNumber, decimalSeparator);	    		
	    	}			
		} catch (ParametersException e) {
			LOG.error(e);
		} finally {
			try {
				CustomStagesHelper.getResponseParameters(context).setint(MVXSTATUS, status);
			} catch (ParametersException e1) {
				LOG.error(e1);
			}

			if (movex != null) {
            	LOG.debug("UpdateMeterReadingsStage closing connection");

            	try {
                    movex.close();
                } catch (ConnectorException e) {
                    LOG.error("Failed to close connection!");
                }
                movex = null;
            }
        }
	}
	
	/**
	 * Add to the input map, with null checking
	 * @param inputs
	 * @param key
	 * @param value
	 */
	private void safeAdd(Map<Object, Object> inputs, String key, String value) {
		if (key != null && value != null) {
			inputs.put(key, value);
		}
	}
	
	/**
	 * Calls the MOS272 Add API.
	 * @param context
	 * @param m3Company
	 * @param registrationNumber
	 * @param startDate
	 * @param startTime
	 * @param coordinateX
	 * @param coordinateY
	 * @param coordinateZ
	 * @param cname
	 * @param cua1
	 * @param cua2
	 * @param cua3
	 * @param cua4
	 * @param postalCode
	 * @return
	 * @throws PipelineRuntimeException
	 * @throws ParametersException
	 */
	private int addLocation(PipelineContext context, String m3Company, String registrationNumber, Date startDate, String startTime, 
			String coordinateX, String coordinateY, String coordinateZ,
			String cname, String cua1, String cua2, String cua3, String cua4, String postalCode,
			String itemNumber, 
			String decimalSeparator) throws PipelineRuntimeException, ParametersException {
		
		Map<Object, Object> inputs = new HashMap<Object, Object>();
		inputs.put(IMovexConnection.TRANSACTION, PROGRAM_ADD);
		inputs.put(CONO, m3Company);
		
		safeAdd(inputs, TAIL, "");
		safeAdd(inputs, STDT, convertDateFormat(startDate));
		safeAdd(inputs, STTI, startTime);
		
		if (coordinateX != null && ".".equals(decimalSeparator) == false) {			
			coordinateX = coordinateX.replaceAll(decimalSeparator, ".");
		}
		if (coordinateY != null && ".".equals(decimalSeparator) == false) {			
			coordinateY = coordinateY.replaceAll(decimalSeparator, ".");
		}
		if (coordinateZ != null && ".".equals(decimalSeparator) == false) {			
			coordinateZ = coordinateZ.replaceAll(decimalSeparator, ".");
		}
		
		safeAdd(inputs, CORX, coordinateX);
		safeAdd(inputs, CORY, coordinateY);
		safeAdd(inputs, CORZ, coordinateZ);
		safeAdd(inputs, CUNO, cname); // currently not working in 14.2. requested parameter is disabled in page so this wont be added to map
		safeAdd(inputs, CUNM, cname); // currently not working in 14.2. requested parameter is disabled in page so this wont be added to map
		safeAdd(inputs, CUA1, cua1);
		safeAdd(inputs, CUA2, cua2);
		safeAdd(inputs, CUA3, cua3);
		safeAdd(inputs, CUA4, cua4);
		safeAdd(inputs, PONO, postalCode);		
		safeAdd(inputs, ITNO, itemNumber);
		safeAdd(inputs, SERN, registrationNumber);

		// get connection
		if (movex == null) {
			movex = (IMovexConnection) CustomStagesHelper.getConnection(MOS272MI);	
		}
		
		if (movex != null) {
			// call API
			IMovexApiResultset result = CustomStagesHelper.callMovex(context, movex, inputs, MVXSTATUS);
			if (result != null) {
				LOG.debug("Add result=" + movex.getLastMessage());
				
				if (movex.isOk() == true) {
					return 0;
				}
			}
		}
		
		return -1;
	}
	
	/**
	 * Convert date to the expected format of M3-yyyyMMdd
	 * @param startDate
	 * @return
	 */
	private String convertDateFormat(Date startDate) {
		if (startDate != null) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(startDate);
			return String.format("%04d%02d%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH)); 
		}

		return null;
	}
}
