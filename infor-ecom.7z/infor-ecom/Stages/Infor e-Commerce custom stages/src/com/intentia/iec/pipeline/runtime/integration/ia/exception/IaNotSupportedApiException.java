package com.intentia.iec.pipeline.runtime.integration.ia.exception;

public class IaNotSupportedApiException extends Exception {

	private static final long serialVersionUID = 1L;

	public IaNotSupportedApiException() {
		super();
	}

	public IaNotSupportedApiException(String message) {
		super(message);
	}

	public IaNotSupportedApiException(Throwable cause) {
		super(cause);
	}

	public IaNotSupportedApiException(String message, Throwable cause) {
		super(message, cause);
	}

}
