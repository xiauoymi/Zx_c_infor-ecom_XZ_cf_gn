package com.intentia.iec.pipeline.runtime.stage.custom.lucene.search;

import org.apache.lucene.search.Filter;
import org.apache.lucene.search.Hits;

import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;

public class LesItemSearcherStage extends AbstractSearcherStage {

    private static final String INDEX_NAME = "LesItem";

    private static final String KEY_ATTRIBUTE_NAME = ConstantsForSales.ITEM_ID;

    private static final String BO_NAME = "Item";

    private static final String BO_METHOD_NAME = "LesSearch";

    protected String getIndexName() {
        return INDEX_NAME;
    }

    protected String getKeyAttributeName() {
        return KEY_ATTRIBUTE_NAME;
    }

    protected Filter createSearchFilters() throws PipelineRuntimeException {
        // TODO: Add Item visibility filters here...
        return null;
    }

    protected XMLResultset getSearchResultDetails(Hits hits) throws PipelineRuntimeException {
        return querySearchResultDetails(hits, BO_NAME, BO_METHOD_NAME, KEY_ATTRIBUTE_NAME);
    }
}