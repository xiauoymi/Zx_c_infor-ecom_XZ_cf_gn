package com.intentia.iec.pipeline.runtime.integration.ia.utils;

public class IaConstants {
	
	public IaConstants() {
		// do nothing...
	}
	
	public static final String DEF_SERVER_NAME = "localhost";
	public static final String DEF_PORT_NUMBER = "7206";
	public static final String DEF_REST_PORT_NUMBER = "7201";
	public static final String DEF_USERNAME = ""; 
	public static final String DEF_PASSWORD = "";
	public static final String DEF_REST_USERNAME = ""; 
	public static final String DEF_REST_PASSWORD = "";	
	public static final String DEF_PACKAGE_NAME = "eCommerce";
	public static final String DEF_REQUEST_TIMEOUT = "5";
	public static final String DEF_POLLING_INTERVAL = "15";
	public static final String DEF_LOGIN_TIMEOUT = "5";
	public static final String DEF_DATA_DELIMITER = "|";
	
	public static final String DEF_USER_ID = "0";
	public static final String DEF_USERGROUP_ID = "0";
	public static final String DEF_SESSION_ID = "0_0";
	public static final AcceptanceLevel DEF_ACCEPT_LEVEL = AcceptanceLevel.Clicked;

	public static final String CONF_SERVER_NAME = "IaServer";
	public static final String CONF_PORT_NUMBER = "IaPortNumber";
	public static final String CONF_REST_PORT_NUMBER = "IaRestApiPortNumber";
	public static final String CONF_USERNAME = "IaUsername";
	public static final String CONF_PASSWORD = "IaPassword";
	public static final String CONF_REST_USERNAME = "IaMarketerUsername";
	public static final String CONF_REST_PASSWORD = "IaMarketerPassword";
	public static final String CONF_PACKAGE_NAME = "IaPackageName";
	public static final String CONF_REQUEST_TIMEOUT = "IaRequestTimeout";
	public static final String CONF_POLLING_INTERVAL = "IaPollingInterval";
	public static final String CONF_LOGIN_TIMEOUT = "IaLoginTimeout";
	public static final String CONF_DATA_DELIMITER = "IaDataDelimiter";
	
	public static final String REST_REQUEST_CHARSET = "UTF-8";
	public static final String REST_REQUEST_TYPE = "text/xml";
	
	public static final String REST_CAMPAIGN_PREFIX = "Campaign_";
	public static final String REST_PROMOTION_PREFIX = "Promotion_";
	
	public static final String REST_URL_PACKAGE_NAME_VAR = "{$PACKAGE_NAME}";
	public static final String REST_URL_COMM_ID_VAR = "{$COMM_ID}";
	
	public static final String REST_URL_CONTEXT = "/REST/v1";
	public static final String REST_URL_REFINE_PACKAGE = "/server/pkgs/" + REST_URL_PACKAGE_NAME_VAR + "?location=edit";
	public static final String REST_URL_DEPLOY_PACKAGE = "/server/pkgs/" + REST_URL_PACKAGE_NAME_VAR + "?location=production";
	public static final String REST_URL_ADD_COMMUNICATION = "/pkgs/" + REST_URL_PACKAGE_NAME_VAR + "/communications/" + REST_URL_COMM_ID_VAR + "?location=edit";

	public static final String EVENT_PARAM_ACCEPT_LEVEL = "AcceptanceLevel";
	
	public enum AcceptanceLevel {
		Clicked, Accepted;
	}
	
}
