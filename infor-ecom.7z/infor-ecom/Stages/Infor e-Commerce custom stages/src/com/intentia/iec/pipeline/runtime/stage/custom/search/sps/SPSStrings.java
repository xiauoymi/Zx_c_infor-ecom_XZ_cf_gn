package com.intentia.iec.pipeline.runtime.stage.custom.search.sps;

/**
 * This will contain SPS-specific String definitions and override some
 * definitions in com.intentia.iec.pipeline.runtime.stage.custom.search.String.
 * 
 */
public final class SPSStrings {
    public static class Database {

        public static class Indexing {
            public static class Item {
                public static class Items {
                    public static final String sql = "                                                  "
                            + " select distinct                                                                 "
                            + "     i.id,                                                               "
                            + "     i.itemNumber,                                                       "
                            + "     m.[key] as manufacturerId,                                          "
                            + "     m.name as manufacturerName,                                         "
                            + "     i.mainCategoryId,                                                   "
                            + "     b.[key] as brandId, 												" 
                            + "     i.supplierId 														"
                            + " from Item i                                                             "
                            + "     left outer join Manufacturer m                                      "
                            + "         on m.id = i.manufacturerId                                      "
                            + "    	left outer join Brand b                           					"
                            + "        	on b.id = i.brandId 											"
                            + " 	left join Category mc 											"
                            + "			on i.mainCategoryId = mc.id 								"
                            + " 	left join SparePart p " 
                            + "			on p.productID = i.id "
                            + " 	left join SparePart c " 
                            + "			on c.sparePartID = i.id "
                            + " 	left join AlternativeItem aip " 
                            + "			on aip.productId = i.id "
                            + " 	left join AlternativeItem aic " 
                            + "			on aic.alternativeItemId = i.id "
                            + " where i.isActive = 'Y' and                                              "                            
                            + "     i.typeCodeId = (select id from Code where [key] = 'normalItemCode') "
                    		+ " 	and (p.productID is not null "
                    		+ " 		or c.sparePartID is not null "
                    		+ " 		or aip.productId is not null "
                    		+ " 		or aic.alternativeItemId is not null)";

                    public static final String sqlWithoutStyles = sql
                            + " and i.id not in (select styleItemId from StyleRelation)";
                }

                public static class SpareParts {
                    public static final String parentItem = "parentItem";

                    public static final String sql = "select distinct i.id as parentItem from Item i "
                    + " left join SparePart sp on sp.productID = i.id "
                    + " left join AlternativeItem ai on ai.productId = i.id "
                    + " where sparePartID = ?  or ai.alternativeItemId = ?" ; 
                    
                    
                }
            }
        }

        public static class Searching {
            public static class Item {
                public static class PassiveAttributes {
                    public static final String sqlHead = "                                                		"
                            + " select                                                       		"
                            + "     i.id,                                                    		"
                            + "     i.itemNumber,                                            		"
                            + "     i.hasSubItems,                                           		"
                            + "     i.isEmphasized,                                          		"
                            + "     tg2.rate,                                                 		"
                            + "     isnull(img.thumbImage,(select value from ApplicationData 		"
                            + "             where parameter = 'DefItemImageThumb'))          		"
                            + "         as imageThumb,                                       		"
                            + "     lp.amount as listPrice,                                  		"
                            + "     rp.amount as resellPrice,                                		"
                            + "     m.[key] as manufacturerId,                               		"
                            + "     coalesce(i.minQty, 1) as minQty,                         		"
                            + "     coalesce(i.modularQty, 1) as modularQty,                 		"
                            + "     i.isMvxConfigurable,                                     		"
                            + "     f.styleId,                                               		"
                            + "     i.supplierId,                                            		"
                            + "     b.[key] as brandId,                                  			"
                            + "     b.name as brandName,                                 			"
                            + "     it.description as description,                              	"
                            + "     mc.[key] as mainCategoryId,                              		"
                            + "     mct.name as mainCategoryName,                              		"
                            + "     m.name as manufacturerName,                              		"
                            + "     isnull(img.previewImage,(select value from ApplicationData 		"
                            + "             where parameter = 'DefItemImagePreview'))          		"
                            + "         as imagePreview,                                     		"
                            + " 	case when i.id in (select styleId from StyleRelation) 			"
                            + "			then 'Y' else 'N' end as isStyle, 							"
                            + " 	dbo.GetNetListPrice(lp.amount, rp.amount, 						"
                            + "			cid.maxDiscount, cp.amount) as netListPrice, 				"
                            + " 	dbo.GetTaxPrice(lp.amount, rp.amount, cid.maxDiscount, 			"
                            + " 		cp.amount, tg2.rate) as taxPrice, 							"
                            + " 	uct.text as unit, 												"
                            + " 	uc.code as unitCode, 											"
                            + " 	i.rating as itemRating,											"
                            + "     citem.customerItemId as customerItemId,						"
                            + "		case when exists ("
                            + "			SELECT 1 FROM Item i2 "
                            + "			INNER JOIN ItemVisible iv ON i2.id=iv.itemId AND i2.isActive='Y' "
                            + " 		LEFT JOIN UserAssortment ua ON ua.assortmentId = iv.assortmentId "
                            + " 		WHERE i2.id IN (SELECT sparePartID from SparePart WHERE productID=i.id) "
                            + " 		OR i2.id IN (SELECT alternativeItemId FROM AlternativeItem WHERE productId=i.id) "
                            + " 		AND ua.userId = ? AND ua.userGroupId = ? "                            
                            + " 		AND (0 = (SELECT COUNT(1) FROM WarehouseItem) OR 0 < (SELECT COUNT(1) FROM WarehouseItem wi INNER JOIN Warehouse w ON w.[id] = wi.warehouseId WHERE iv.itemId = wi.itemId AND w.warehouse = ?)) "
                            + "		) then 'Y' else 'N' end" 
                            + " 	         as hasChildItems,										"
                            + "		case when exists ("
                            + "		select 1 from BlowUpPrint bup " 
                            + "			where i.id = bup.itemId"
                            + "				and bup.statusCode = 'ApprovedBlowUpPrintStatus'"
                            + "				and bup.imageMaster is not null"
                            + "				and bup.serialNumber is null"
                            + "				and exists (select bupi.itemId from BlowUpPrintItem bupi "
                            + "               	inner join Item item2 on bupi.itemId = item2.id and item2.isActive='Y' "
                            + "					inner join ItemVisible iv on item2.id = iv.itemId "
                            + "					inner join UserAssortment ua on ua.assortmentId = iv.assortmentId "
                            + "						where bupi.blowUpPrintId = bup.id AND ua.userId = ? "
                            + "						and ua.userGroupId = ? "
                            + "						and (0 = (SELECT COUNT(*) FROM WarehouseItem) OR 0 < (SELECT COUNT(*) "
                            + "						FROM WarehouseItem wi INNER JOIN Warehouse w ON w.[id] = wi.warehouseId "
                            + "						WHERE bupi.itemId = wi.itemId AND w.warehouse = ?)))"                            
                            + "		) then 'Y' else 'N' end" 
                            + " 	         as hasDrawing											"
                            + " from Item i                                                  		"
                            + " 	left join ItemTaxGroup tg 										" 
                            + "    		on i.id = tg.itemId 										"
                            + " 	left join TaxGroup tg2 											"
                            + "    		on tg2.id = IsNull(tg.taxGroupId, 							"
                            + "				(select defaultTaxGroupId 								"
                            + "					from Country where countryCode = ?)) 				"
                            + "     left join Price lp                                       		"
                            + "         on i.id = lp.itemId                                  		"
                            + "             and lp.priceGroupId = ? 								" 
                            + "				and lp.currencyCode = ?  								"
                            + "     left join Price rp                                       		"
                            + "         on i.id = rp.itemId                                  		"
                            + "             and rp.priceGroupId = ? 								" 
                            + "				and rp.currencyCode = ?  								"
                            + "     left join Manufacturer m                                 		"
                            + "         on i.manufacturerId = m.id                           		"
                            + "     left join StyleFeatureRelation f                         		"
                            + "         on i.id = f.styleId                                  		"
                            + " 	left join ItemImages img 								 		" 
                            + "			on i.itemNumber = img.itemNumber				 	 		"
                            + "			and not exists (select * from ItemImages img2 	 	 		"
                            + "				where img.id = img2.id and img.defaultImage ='N')		"
                            + " 	left join Brand b on b.id = i.brandId			 				" 
                            + " 	left join ItemText it 											"
                            + "			on it.itemId = i.id 										" 
                            + " 			and it.languageCode = ?									"
                            + "		left join CustomerItemDiscount cid								" 
                            + "    		on	i.id = cid.itemId 										"
                            + "				and cid.customerId = ? 									" 
                            + " 	left join Code uc 												"
                            + "			on i.unitCodeId = uc.id 									" 
                            + " 	left join CodeText uct 											"
                            + "			on uc.id = uct.codeId										" 
                            + "				and uct.languageCode = ? 								"
                            + " 	left join Category mc 											" 
                            + "			on i.mainCategoryId = mc.id 								"
                            + " 	left join CategoryText mct 										" 
                            + "			on mc.id = mct.categoryId 									"
                            + "				and mct.languageCode = ? 								" 
                            + " 	left join CustomerPrice cp 										"
                            + "    		on i.id = cp.itemId 										" 
                            + "       		and cp.customerId = ? 									"
                            + "       		and cp.currencyCode = ? 								" 
                            + "		left join CustomerItem citem"
                            + "			on i.id = citem.itemId" 
                            + "				and citem.userGroupId = ?"                           
                            + " where i.isActive = 'Y'                                       		"
                            + "     and i.typeCodeId =                                       		"
                            + "         (select id from Code where [key] = 'normalItemCode') 		" 
                            + " and i.id in (";

                    public static final String hasChildItems = "hasChildItems";

                    public static final String hasDrawing = "hasDrawing";
                }
            }
        }
    }

    public static class Response {
        public static class ItemList {
            public static final String hasChildItems = "HasChildItems";

            public static final String hasDrawing = "HasDrawing";

            public static final String systemID = "SystemID";
        }
    }

    public static class Index {
        public static class Item {
            public static final String parentItem = "parentItem";
        }
    }

    public static class Request {

        public static class Param {
            public static final String childItemSearchString = "@ChildItemSearchString";
			
			public static final String wildcardSearch = "@WildCardSearch";
        }

        public static class SearchOrigin {
            public static final String CHILDITEM_SEARCH = "childItemSearch";
        }
    }
}
