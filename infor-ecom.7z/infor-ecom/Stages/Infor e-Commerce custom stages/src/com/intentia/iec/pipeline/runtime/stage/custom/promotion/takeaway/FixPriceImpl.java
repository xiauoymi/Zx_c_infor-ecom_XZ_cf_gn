package com.intentia.iec.pipeline.runtime.stage.custom.promotion.takeaway;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;

public class FixPriceImpl implements TakeAway {

	private static final Logger LOG = Logger.getLogger(FixPriceImpl.class);
	
	private static FixPriceImpl instance = null;
	
	private PromotionTakeAway promotionTakeAway = null;

	private List<String> promotionalItems = null;
	
	private Map<String, String> itemDetailsMap = null;
	
	protected FixPriceImpl() {
	      // Exists only to defeat instantiation.
	}
	public static FixPriceImpl getInstance() {
		if(instance == null) {
			instance = new FixPriceImpl();
		}
		return instance;
	}

	/**
	 * @return the promotionTakeAway
	 */
	public PromotionTakeAway getPromotionTakeAway() {
		return promotionTakeAway;
	}

	/**
	 * @param promotionTakeAway the promotionTakeAway to set
	 */
	public void setPromotionTakeAway(PromotionTakeAway promotionTakeAway) {
		this.promotionTakeAway = promotionTakeAway;
	}
	
	public void setPromotionalItems(List<String> promotionalItems) {
		this.promotionalItems = promotionalItems;
	}

	public void setItemParametersMap(Map<String, String> itemDetailsMap) {
		this.itemDetailsMap = itemDetailsMap;
	}

	/**
	 * Apply Header Level Promotion Take Away
	 */
	public void applyHeaderTakeaway(XMLResultset resultSet) {
		LOG.debug("Inside FixPriceImpl.applyHeaderTakeaway()");
		PromotionTakeAway takeAway = this.promotionTakeAway;
		String takeAwayField = takeAway.getField();
		String takeAwayOperator = takeAway.getOperator();
		List<String> takeAwayValueList = takeAway.getValues();
		try {
			if(TakeAwayConstant.ITEMS_IN_PROMO.equals(takeAwayField)){
				this.applyFixPriceByItemsInPromo(resultSet, takeAwayValueList, takeAwayOperator);
			} else if(TakeAwayConstant.SELECTED_ITEMS.equals(takeAwayField)){
				this.applyFixPriceBySelectedItems(resultSet, takeAwayValueList, takeAwayOperator);
			}
		} catch (ResultsetException e) {
			LOG.error("Error Inside QuantityImpl.applyHeaderTakeaway() - "+e.getMessage());
		}

	}
	
	/**
	 * Apply Line Level Promotion Take Away
	 */
	public void applyLineTakeAway(XMLResultset resultSet, XMLIterator xmlOrderline) {
		LOG.debug("Inside FixPriceImpl.applyLineTakeAway()");
		PromotionTakeAway takeAway = this.promotionTakeAway;
		String takeAwayField = takeAway.getField();
		String takeAwayOperator = takeAway.getOperator();
		List<String> takeAwayValueList = takeAway.getValues();
		try {
			if(TakeAwayConstant.ITEMS_IN_PROMO.equals(takeAwayField)){
				this.applyFixPriceByItemsInPromo(xmlOrderline, takeAwayValueList, takeAwayOperator);
			} else if(TakeAwayConstant.SELECTED_ITEMS.equals(takeAwayField)){
				this.applyFixPriceBySelectedItems(xmlOrderline, takeAwayValueList, takeAwayOperator);
			}
		} catch (ResultsetException e) {
			LOG.error("Error Inside QuantityImpl.applyLineTakeAway() - "+e.getMessage());
		}
	}
	
	/**
	 * Apply Fix Price by Items in Promotion for Promotion TakeAway
	 * 
	 * @param resultSet
	 * @param takeAwayValueList
	 * @param operator
	 * @throws ResultsetException
	 */
	private void applyFixPriceByItemsInPromo(XMLResultset resultSet, List<String> takeAwayValueList, String operator)
			throws ResultsetException{
		LOG.debug("Inside FixPriceImpl.applyFixPriceByItemsInPromo()");
		BigDecimal resellPrice = new BigDecimal(0);
		BigDecimal linePrice = new BigDecimal(0);
		BigDecimal lineQuantity = new BigDecimal(0);
		BigDecimal lineDiscount = new BigDecimal(0);
		BigDecimal lineTotal = new BigDecimal(0);
		BigDecimal modLinePrice = new BigDecimal(0);
		BigDecimal remainingNormalQuantity = new BigDecimal(0);
		BigDecimal multiplier = this.getFixPriceMultiplier(resultSet);
		boolean hasAppliedFixedPrice = false;
		try {
			if(!takeAwayValueList.isEmpty()){
				resultSet.moveFirst();
				XMLIterator xmlOrderline = (XMLIterator) resultSet.getResultset(ConstantsForSales.ORDERLINE);
				xmlOrderline.beforeFirst();
				String itemIDFromRequest = "";
				List<Map<String, String>> addOrderlineList = new ArrayList<Map<String, String>>();

				//convert fix price amont to the currency of the order before assigning it to the order
				BigDecimal takeAwayfixedPrice = this.promotionTakeAway.calculateValueCurrency(takeAwayValueList.get(0));
				while (xmlOrderline.moveNext()) {
					itemIDFromRequest = this.getStringValue(xmlOrderline, TakeAwayConstant.REQ_ITEM_ID);
					
					resellPrice = new BigDecimal(this.getStringValue(xmlOrderline, ConstantsForSales.RESELLPRICE));
					linePrice =  new BigDecimal(this.getStringValue(xmlOrderline, ConstantsForSales.LINEPRICE));
					lineQuantity = new BigDecimal(this.getStringValue(xmlOrderline, TakeAwayConstant.REQ_QUANTITY));
					remainingNormalQuantity = lineQuantity.subtract(multiplier);
					
					if(this.promotionalItems.contains(itemIDFromRequest)){
						if(hasAppliedFixedPrice){

							int result = lineQuantity.compareTo(multiplier);
							if(result == 1){
								//if item quantity > multiplier
								//Fixed Prices
								/*lineDiscount = resellPrice.subtract(takeAwayfixedPrice, mc);
								lineDiscount = lineDiscount.multiply(multiplier, mc);
								lineTotal = lineDiscount.multiply(multiplier, mc);*/
								
								//modLinePrice = resellPrice.multiply(multiplier, mc);
								lineTotal = resellPrice.multiply(multiplier);
								
								this.updRsAttr(xmlOrderline, ConstantsForSales.QUANTITY, multiplier.toString());
								this.updRsAttr(xmlOrderline, ConstantsForSales.LINEDISCOUNT, lineTotal.toString());
								this.updRsAttr(xmlOrderline, ConstantsForSales.LINEPRICE, lineTotal.toString());
								this.updRsAttr(xmlOrderline, ConstantsForSales.LINETOTAL, TakeAwayConstant.ZERO_BIG_DECIMAL_VALUE);

								// Normal Prices
								lineDiscount = new BigDecimal(TakeAwayConstant.ZERO_BIG_DECIMAL_VALUE);
								lineTotal = resellPrice.multiply(remainingNormalQuantity);
								Map<String, String> itemDetailsMap = new HashMap<String, String>();
								itemDetailsMap.put(ConstantsForSales.QUANTITY, remainingNormalQuantity.toString());
								itemDetailsMap.put(ConstantsForSales.PROMOTION_ID, "");
								itemDetailsMap.put(ConstantsForSales.LINEDISCOUNT, lineDiscount.toString());
								itemDetailsMap.put(ConstantsForSales.LINEPRICE, lineTotal.toString());
								itemDetailsMap.put(ConstantsForSales.LINETOTAL, lineTotal.toString());
								
								this.createXmlOrderlineAttributes(xmlOrderline, itemDetailsMap);
								addOrderlineList.add(itemDetailsMap);
							} else {
								//Apply 0.00 value in following Item in Promo found in the Order
								lineDiscount = resellPrice.multiply(multiplier);
								lineTotal = linePrice.subtract(lineDiscount);
								
								this.updRsAttr(xmlOrderline, ConstantsForSales.LINEDISCOUNT, lineDiscount.toString());
								this.updRsAttr(xmlOrderline, ConstantsForSales.LINETOTAL, lineTotal.toString());
							}

						} else {
							//Apply Fixed Price in 1st Item in Promotion found in the Order
							int result = lineQuantity.compareTo(multiplier);
							if(result == 1){
								//if item quantity > multiplier
								//Fixed Prices
								int result2 = takeAwayfixedPrice.compareTo(resellPrice);
								//if takeAwayFixedPrice  > resellprice
								if(result2 == 1){
									lineDiscount = resellPrice.subtract(takeAwayfixedPrice);
									lineDiscount = lineDiscount.multiply(multiplier);
									//lineTotal = takeAwayfixedPrice.multiply(multiplier, mc);
								} else {
									lineDiscount = resellPrice.subtract(takeAwayfixedPrice);
									lineDiscount = lineDiscount.multiply(multiplier);
									//lineTotal = linePrice.subtract(lineDiscount, mc);
								}
								modLinePrice = takeAwayfixedPrice.multiply(multiplier);									
								lineTotal = resellPrice.multiply(multiplier);

								this.updRsAttr(xmlOrderline, ConstantsForSales.QUANTITY, multiplier.toString());
								this.updRsAttr(xmlOrderline, ConstantsForSales.LINEDISCOUNT, lineDiscount.toString());
								this.updRsAttr(xmlOrderline, ConstantsForSales.LINEPRICE, lineTotal.toString());
								this.updRsAttr(xmlOrderline, ConstantsForSales.LINETOTAL, modLinePrice.toString());

								// Normal Prices
								lineDiscount = new BigDecimal(TakeAwayConstant.ZERO_BIG_DECIMAL_VALUE);
								lineTotal = resellPrice.multiply(remainingNormalQuantity);
								Map<String, String> itemDetailsMap = new HashMap<String, String>();
								itemDetailsMap.put(ConstantsForSales.QUANTITY, remainingNormalQuantity.toString());
								itemDetailsMap.put(ConstantsForSales.PROMOTION_ID, "");
								itemDetailsMap.put(ConstantsForSales.LINEDISCOUNT, lineDiscount.toString());
								itemDetailsMap.put(ConstantsForSales.LINEPRICE, lineTotal.toString());
								itemDetailsMap.put(ConstantsForSales.LINETOTAL, lineTotal.toString());
								
								this.createXmlOrderlineAttributes(xmlOrderline, itemDetailsMap);
								addOrderlineList.add(itemDetailsMap);
							} else {
								//linePrice = takeAwayfixedPrice.multiply(multiplier, mc);
								int result2 = takeAwayfixedPrice.compareTo(resellPrice);
								//if takeAwayFixedPrice  > resellprice
								if(result2 == 1){
									lineDiscount = resellPrice.subtract(takeAwayfixedPrice);
									lineDiscount = lineDiscount.multiply(multiplier);
									lineTotal = takeAwayfixedPrice.multiply(multiplier);
								} else {									
									lineDiscount = resellPrice.subtract(takeAwayfixedPrice);
									lineDiscount = lineDiscount.multiply(multiplier);
									lineTotal = linePrice.subtract(lineDiscount);
								}
								this.updRsAttr(xmlOrderline, ConstantsForSales.LINEDISCOUNT, lineDiscount.toString());
								this.updRsAttr(xmlOrderline, ConstantsForSales.LINETOTAL, lineTotal.toString());
							}

							hasAppliedFixedPrice = true;
						}
					}
				}
				
				this.createAdditionalOrderline(xmlOrderline, addOrderlineList);
			}
		} catch (ResultsetException e) {
			LOG.error("Error Inside FixPriceImpl.applyFixPriceByItemsInPromo() - "+e.getMessage());
		}
	}
	
	/**
	 * Apply Fix Price by Selected Items for Promotion TakeAway
	 *
	 * @param resultSet
	 * @param takeAwayValueList
	 * @param operator
	 * @throws ResultsetException
	 */
	private void applyFixPriceBySelectedItems(XMLResultset resultSet, List<String> takeAwayValueList, String operator)
			throws ResultsetException{
		LOG.debug("Inside FixPriceImpl.applyFixPriceBySelectedItems()");
		PromotionTakeAway takeAway = this.promotionTakeAway;
		//Should be an ItemNumber
		String extraParam = takeAway.getExtraParams();
		BigDecimal modResellPrice = new BigDecimal(0);		
		BigDecimal modLineTotal = new BigDecimal(0);
		
		if(!takeAwayValueList.isEmpty()){
			resultSet.moveFirst();
			XMLIterator xmlOrderline = (XMLIterator) resultSet.getResultset(ConstantsForSales.ORDERLINE);
			xmlOrderline.beforeFirst();
			String itemIDFromRequest = "";
			while (xmlOrderline.moveNext()) {
				// Check if item exist in Orderline
				itemIDFromRequest = this.getStringValue(xmlOrderline, TakeAwayConstant.REQ_ITEM_ID);
				if(extraParam.contains(itemIDFromRequest)){
					BigDecimal lineQuantity = new BigDecimal(this.getStringValue(xmlOrderline, TakeAwayConstant.REQ_QUANTITY));
					
					//Apply Fixed Price in selected item found in the Order
					modResellPrice = new BigDecimal(takeAwayValueList.get(0));
					modLineTotal = modResellPrice.multiply(lineQuantity);
					this.updRsAttr(xmlOrderline, ConstantsForSales.RESELLPRICE, modResellPrice.toString());
					//update line discount for fixed prices
					this.updRsAttr(xmlOrderline, ConstantsForSales.LINEDISCOUNT, modLineTotal.toString());
					this.updRsAttr(xmlOrderline, ConstantsForSales.LINETOTAL, modLineTotal.toString());
					break;
				}
			}
		}

	}
	
	/**
	 * Apply Fix Price by Items in Promotion for Promotion TakeAway
	 *
	 * @param xmlOrderline
	 * @param takeAwayValueList
	 * @param operator
	 * @throws ResultsetException
	 */
	private void applyFixPriceByItemsInPromo(XMLIterator xmlOrderline, List<String> takeAwayValueList, String operator)
			throws ResultsetException{
		LOG.debug("Inside FixPriceImpl.applyFixPriceByItemsInPromo()");
		BigDecimal modLineTotal = new BigDecimal(0);
		boolean hasAppliedFixedPrice = false;

		if(!takeAwayValueList.isEmpty()){
			String itemIDFromRequest =this.getStringValue(xmlOrderline, TakeAwayConstant.REQ_ITEM_ID);
			if(this.promotionalItems.contains(itemIDFromRequest)){
				if(hasAppliedFixedPrice){
					//Apply 0.00 value in following Item in Promo found in the Order
					modLineTotal = new BigDecimal(TakeAwayConstant.ZERO_BIG_DECIMAL_VALUE);
				} else {
					//Apply Fixed Price in 1st Item in Promo found in the Order
					modLineTotal = new BigDecimal(takeAwayValueList.get(0));
					hasAppliedFixedPrice = true;
				}
				this.updRsAttr(xmlOrderline, ConstantsForSales.RESELLPRICE, modLineTotal.toString());
			}
		}

	}
	
	/**
	 * Apply Fix Price by Selected Items for Promotion TakeAway
	 *
	 * @param xmlOrderline
	 * @param takeAwayValueList
	 * @param operator
	 * @throws ResultsetException
	 */
	private void applyFixPriceBySelectedItems(XMLIterator xmlOrderline, List<String> takeAwayValueList, String operator)
			throws ResultsetException{
		LOG.debug("Inside FixPriceImpl.applyFixPriceBySelectedItems()");
		PromotionTakeAway takeAway = this.promotionTakeAway;
		//Should be an ItemNumber
		String extraParam = takeAway.getExtraParams();
		BigDecimal modLineTotal = new BigDecimal(0);		

		if(!takeAwayValueList.isEmpty()){
			String itemIDFromRequest = "";
			// Check if item exist in Orderline
			itemIDFromRequest = this.getStringValue(xmlOrderline, TakeAwayConstant.REQ_ITEM_ID);
			if(extraParam.contains(itemIDFromRequest)){
				//Apply Fixed Price in selected item found in the Order
				modLineTotal = new BigDecimal(takeAwayValueList.get(0));
				this.updRsAttr(xmlOrderline, ConstantsForSales.RESELLPRICE, modLineTotal.toString());
			}
		}

	}
	
    private String updRsAttr(final XMLIterator rs, final String rsPar, final String value) {
        return CustomStagesHelper.updateRsAttribute(rs, rsPar, value);
    }
	
	private String getStringValue(XMLIterator xmlOrderline, String requestField){
		String stringFromRequest = "";
		try {
			stringFromRequest = xmlOrderline.getString(requestField);
			if("".equals(stringFromRequest) && (requestField.equals(ConstantsForSales.RESELLPRICE) 
					|| requestField.equals(ConstantsForSales.LINETOTAL) || requestField.equals(TakeAwayConstant.REQ_GRAND_TOTAL))){
				stringFromRequest = TakeAwayConstant.ZERO_BIG_DECIMAL_VALUE;
			}
		} catch (ResultsetException e) {
            LOG.error("Error Inside QuantityImpl.getStringValue() - "+e.getMessage());
		}
		return stringFromRequest;
	}
    
	private BigDecimal getFixPriceMultiplier(XMLResultset resultSet){
		List<String> promoItems = this.promotionalItems;
		BigDecimal multiplier = new BigDecimal(0);
		try {
			resultSet.moveFirst();
			XMLIterator xmlOrderline = (XMLIterator) resultSet.getResultset(ConstantsForSales.ORDERLINE);
			xmlOrderline.beforeFirst();
			String itemIDFromRequest = "";
			while (xmlOrderline.moveNext()) {
				// Check if item exist in Orderline
				itemIDFromRequest = this.getStringValue(xmlOrderline, TakeAwayConstant.REQ_ITEM_ID);
				if(promoItems.contains(itemIDFromRequest)){
					String quantityFromRequest = this.getStringValue(xmlOrderline, TakeAwayConstant.REQ_QUANTITY);
					BigDecimal lineQuantity = new BigDecimal(quantityFromRequest);
					int result = lineQuantity.compareTo(multiplier);
					if(multiplier.compareTo(new BigDecimal(0)) == 0){
						// first value assign to multiplier
						multiplier = new BigDecimal(quantityFromRequest);
					}
					if(result == -1){ // order quantity is less than multiplier
						// set lowest quantity for multiplier
						multiplier = new BigDecimal(quantityFromRequest);
					}
				}
			}
		} catch (ResultsetException e) {
			LOG.error("Error Inside FixPriceImpl.getFixPriceMultiplier() - "+e.getMessage());
		}
		
		return multiplier;
	}

	private void createAdditionalOrderline(XMLIterator xmlOrderline, List<Map<String, String>> itemDetailsList){
		LOG.debug("Inside FreeItemImpl.applyFreeItemByItemNumber()");
        try {
        	for (Map<String, String> itemDetailsMap : itemDetailsList) {
        		//Create additional row
        		xmlOrderline.move(xmlOrderline.rowCount());
        		xmlOrderline.appendRow();
				this.updateOrderLineAttributes(xmlOrderline, itemDetailsMap);
			}            
        } catch (ResultsetException e) {
            LOG.debug("Error Inside FreeItemImpl.applyFreeItemByItemNumber() - "+e.getMessage());
        } catch (PipelineRuntimeException e) {
			e.printStackTrace();
		}
	}

	private void createXmlOrderlineAttributes(XMLIterator xmlOrderline, Map<String, String> itemDetailsMap){

		itemDetailsMap.put(ConstantsForSales.ORDERLINEID, "");

		String strIsActive = this.getStringValue(xmlOrderline, ConstantsForSales.IS_ACTIVE); 
		if(!"".equals(strIsActive)){
			itemDetailsMap.put(ConstantsForSales.IS_ACTIVE, strIsActive);
		}
		String strIsListPrice = this.getStringValue(xmlOrderline, ConstantsForSales.ISLISTPRICE); 
		if(!"".equals(strIsActive)){
			itemDetailsMap.put(ConstantsForSales.ISLISTPRICE, strIsListPrice);
		}
		String strIsVisible = this.getStringValue(xmlOrderline, ConstantsForSales.IS_VISIBLE); 
		if(!"".equals(strIsActive)){
			itemDetailsMap.put(ConstantsForSales.IS_VISIBLE, strIsVisible);
		}
		String strItem1_id_ConstraintGenerated = this.getStringValue(xmlOrderline, "Item1_id_ConstraintGenerated"); 
		if(!"".equals(strIsActive)){
			itemDetailsMap.put("Item1_id_ConstraintGenerated", strItem1_id_ConstraintGenerated);
		}
		String strItemDescription = this.getStringValue(xmlOrderline, "ItemDescription"); 
		if(!"".equals(strIsActive)){
			itemDetailsMap.put("ItemDescription", strItemDescription);
		}
		String strItemID = this.getStringValue(xmlOrderline, ConstantsForSales.ITEMID); 
		if(!"".equals(strIsActive)){
			itemDetailsMap.put(ConstantsForSales.ITEMID, strItemID);
		}
		String strItemImageThumb = this.getStringValue(xmlOrderline, "ItemImageThumb"); 
		if(!"".equals(strIsActive)){
			itemDetailsMap.put("ItemImageThumb", strItemImageThumb);
		}
		String strItemName = this.getStringValue(xmlOrderline, ConstantsForSales.ITEMNAME); 
		if(!"".equals(strIsActive)){
			itemDetailsMap.put(ConstantsForSales.ITEMNAME, strItemName);
		}
		String strItemTax = this.getStringValue(xmlOrderline, ConstantsForSales.ITEM_TAX); 
		if(!"".equals(strIsActive)){
			itemDetailsMap.put(ConstantsForSales.ITEM_TAX, strItemTax);
		}
		String strLineDisPercent = this.getStringValue(xmlOrderline, ConstantsForSales.LINEDISPERCENT); 
		if(!"".equals(strIsActive)){
			itemDetailsMap.put(ConstantsForSales.LINEDISPERCENT, strLineDisPercent);
		}
		//String strLineDiscount = this.getStringValue(xmlOrderline, ConstantsForSales.LINEDISCOUNT); 
		//if(!"".equals(strIsActive)){
			//itemDetailsMap.put(ConstantsForSales.LINEDISCOUNT, strLineDiscount);
		//}
		//String strLinePrice = this.getStringValue(xmlOrderline, ConstantsForSales.LINEPRICE); 
		//if(!"".equals(strIsActive)){
			//itemDetailsMap.put(ConstantsForSales.LINEPRICE, strLinePrice);
		//}
		String strLineTax = this.getStringValue(xmlOrderline, ConstantsForSales.LINETAX); 
		if(!"".equals(strIsActive)){
			itemDetailsMap.put(ConstantsForSales.LINETAX, strLineTax);
		}
		//String strLineTotal = this.getStringValue(xmlOrderline, ConstantsForSales.LINETOTAL); 
		//if(!"".equals(strIsActive)){
			//itemDetailsMap.put(ConstantsForSales.LINETOTAL, strLineTotal);
		//}
		String strMinimumQty = this.getStringValue(xmlOrderline, ConstantsForSales.MINIMUM_QTY); 
		if(!"".equals(strIsActive)){
			itemDetailsMap.put(ConstantsForSales.MINIMUM_QTY, strMinimumQty);
		}
		String strModularQty = this.getStringValue(xmlOrderline, ConstantsForSales.MODULAR_QTY); 
		if(!"".equals(strIsActive)){
			itemDetailsMap.put(ConstantsForSales.MODULAR_QTY, strModularQty);
		}
		String strOrderLineStatus = this.getStringValue(xmlOrderline, ConstantsForSales.ORDERLINESTATUS); 
		if(!"".equals(strIsActive)){
			itemDetailsMap.put(ConstantsForSales.ORDERLINESTATUS, strOrderLineStatus);
		}
		//String strPromotionID = this.getStringValue(xmlOrderline, ConstantsForSales.PROMOTION_ID); 
		//if(!"".equals(strIsActive)){
			//itemDetailsMap.put(ConstantsForSales.PROMOTION_ID, strPromotionID);
		//}
		//String strQuantity = this.getStringValue(xmlOrderline, ConstantsForSales.QUANTITY); 
		//if(!"".equals(strIsActive)){
			//itemDetailsMap.put(ConstantsForSales.QUANTITY, strQuantity);
		//}
		String strResellPrice = this.getStringValue(xmlOrderline, ConstantsForSales.RESELLPRICE); 
		if(!"".equals(strIsActive)){
			itemDetailsMap.put(ConstantsForSales.RESELLPRICE, strResellPrice);
		}
		String strSKU = this.getStringValue(xmlOrderline, ConstantsForSales.SKU); 
		if(!"".equals(strIsActive)){
			itemDetailsMap.put(ConstantsForSales.SKU, strSKU);
		}
		String strSimulateOrderValidated = this.getStringValue(xmlOrderline, ConstantsForSales.SIMULATE_VALIDATOR_PARAM); 
		if(!"".equals(strIsActive)){
			itemDetailsMap.put(ConstantsForSales.SIMULATE_VALIDATOR_PARAM, strSimulateOrderValidated);
		}
		String strUnit = this.getStringValue(xmlOrderline, ConstantsForSales.UNIT); 
		if(!"".equals(strIsActive)){
			itemDetailsMap.put(ConstantsForSales.UNIT, strUnit);
		}
		String strUnitCode = this.getStringValue(xmlOrderline, ConstantsForSales.UNITCODE); 
		if(!"".equals(strIsActive)){
			itemDetailsMap.put(ConstantsForSales.UNITCODE, strUnitCode);
		}
		String strUseCID = this.getStringValue(xmlOrderline, ConstantsForSales.USECID); 
		if(!"".equals(strIsActive)){
			itemDetailsMap.put(ConstantsForSales.USECID, strUseCID);
		}

	}
	
    private void updateOrderLineAttributes(XMLIterator xmlOrderline, Map<String, String> itemDetailsMap) throws PipelineRuntimeException, ResultsetException {
    	LOG.debug("Inside FixPriceItemImpl.updateOrderLineAttributes()");

    	updRsAttr(xmlOrderline, ConstantsForSales.ORDERLINEID, itemDetailsMap.get(ConstantsForSales.ORDERLINEID) );
    	updRsAttr(xmlOrderline, ConstantsForSales.ORDERLINESTATUS, itemDetailsMap.get(ConstantsForSales.ORDERLINESTATUS));
		updRsAttr(xmlOrderline, ConstantsForSales.ITEMID, itemDetailsMap.get(ConstantsForSales.ITEMID) );
		updRsAttr(xmlOrderline, ConstantsForSales.ITEMNAME, itemDetailsMap.get(ConstantsForSales.ITEMNAME) );
		updRsAttr(xmlOrderline, ConstantsForSales.ITEM_DESCRIPTION, itemDetailsMap.get(ConstantsForSales.ITEM_DESCRIPTION) );
		updRsAttr(xmlOrderline, ConstantsForSales.ITEM_IMAGE_THUMB, itemDetailsMap.get(ConstantsForSales.ITEM_IMAGE_THUMB) );
		updRsAttr(xmlOrderline, ConstantsForSales.QUANTITY, itemDetailsMap.get(ConstantsForSales.QUANTITY) );
		updRsAttr(xmlOrderline, ConstantsForSales.UNIT, itemDetailsMap.get(ConstantsForSales.UNIT) );
		updRsAttr(xmlOrderline, ConstantsForSales.UNITCODE, itemDetailsMap.get(ConstantsForSales.UNITCODE) );

		updRsAttr(xmlOrderline, ConstantsForSales.LINEPRICE, itemDetailsMap.get(ConstantsForSales.LINEPRICE));
		updRsAttr(xmlOrderline, ConstantsForSales.LISTPRICE, itemDetailsMap.get(ConstantsForSales.LISTPRICE));
		updRsAttr(xmlOrderline, ConstantsForSales.RESELLPRICE, itemDetailsMap.get(ConstantsForSales.RESELLPRICE));
		updRsAttr(xmlOrderline, ConstantsForSales.LINEDISPERCENT, itemDetailsMap.get(ConstantsForSales.LINEDISPERCENT));
		updRsAttr(xmlOrderline, ConstantsForSales.LINEDISCOUNT, itemDetailsMap.get(ConstantsForSales.LINEDISCOUNT));
		updRsAttr(xmlOrderline, ConstantsForSales.LINETAX, itemDetailsMap.get(ConstantsForSales.LINETAX));
		updRsAttr(xmlOrderline, ConstantsForSales.LINETOTAL, itemDetailsMap.get(ConstantsForSales.LINETOTAL));
	
		updRsAttr(xmlOrderline, ConstantsForSales.ITEM_TAX, itemDetailsMap.get(ConstantsForSales.ITEM_TAX));
		updRsAttr(xmlOrderline, ConstantsForSales.PROMOTION_ID, itemDetailsMap.get(ConstantsForSales.PROMOTION_ID));
		updRsAttr(xmlOrderline, ConstantsForSales.IS_ACTIVE, itemDetailsMap.get(ConstantsForSales.IS_ACTIVE));
		updRsAttr(xmlOrderline, ConstantsForSales.IS_VISIBLE, itemDetailsMap.get(ConstantsForSales.IS_VISIBLE));
		updRsAttr(xmlOrderline, ConstantsForSales.ISLISTPRICE, itemDetailsMap.get(ConstantsForSales.ISLISTPRICE));
		
		updRsAttr(xmlOrderline, ConstantsForSales.USECID, itemDetailsMap.get(ConstantsForSales.USECID));
		updRsAttr(xmlOrderline, ConstantsForSales.SIMULATE_VALIDATOR_PARAM, itemDetailsMap.get(ConstantsForSales.SIMULATE_VALIDATOR_PARAM));
		updRsAttr(xmlOrderline, ConstantsForSales.SKU, itemDetailsMap.get(ConstantsForSales.SKU));
		
		updRsAttr(xmlOrderline, ConstantsForSales.MODULAR_QTY, itemDetailsMap.get(ConstantsForSales.MODULAR_QTY));
		updRsAttr(xmlOrderline, ConstantsForSales.MINIMUM_QTY, itemDetailsMap.get(ConstantsForSales.MINIMUM_QTY));
		updRsAttr(xmlOrderline, ConstantsForSales.SKU, itemDetailsMap.get(ConstantsForSales.SKU));
		
		updRsAttr(xmlOrderline, "Item1_id_ConstraintGenerated", itemDetailsMap.get("Item1_id_ConstraintGenerated"));
		updRsAttr(xmlOrderline, "ItemImageThumb", itemDetailsMap.get("ItemImageThumb"));
		updRsAttr(xmlOrderline, "ItemDescription", itemDetailsMap.get("ItemDescription"));

    }
	
	
	private BigDecimal getParameterAsDecimal(final String val) {
        if (val != null) {
            try {
                return new BigDecimal(val);
            } catch (NumberFormatException e) {
                return new BigDecimal("0.0000");
            }
        }
        return new BigDecimal("0.0000");
    }
	
}