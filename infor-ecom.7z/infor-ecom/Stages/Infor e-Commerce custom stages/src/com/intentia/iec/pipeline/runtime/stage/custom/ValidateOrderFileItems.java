package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;
import com.ibm.icu.text.DecimalFormat; /*import com.ibm.icu.text.DecimalFormatSymbols;*/
import com.ibm.icu.text.NumberFormat; /* import java.text.NumberFormat; */
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Locale;

import org.apache.log4j.Logger;
import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.Resultset;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.utils.CommitPipelineExecuter;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.sqlserver.runtime.jdbc.JDBCReader;
import com.intentia.iec.sqlserver.runtime.jdbc.LogPreparedStatement;
import com.intentia.iec.util.FastStringBuffer;

public class ValidateOrderFileItems extends AbstractPipelineStage {

    private static final Logger LOG = Logger.getLogger(ValidateOrderFileItems.class);

    private Parameters parameters = null;

    private Locale locale;

    private static final String PIPELINE_PACKAGE = "com.intentia.iec.runtime.pipeline";

    private static final String FILE_ID_PARAMETER = "FileID";

    private static final String LANGUAGE_CODE_PARAMETER = "LanguageCode";

    private static final String LIST_PRICE_GROUP_PARAMETER = "ListPriceGroup";

    private static final String MVXCOMPANY_PARAMETER = "MvxCompany";

    private static final String CURRENCY_CODE_PARAMETER = "CurrencyCode";

    private static final String MVXWAREHOUSE_PARAMETER = "MvxWarehouse";

    private static final String USERGROUPID_PARAMETER = "@UserGroupID";

    private static final String USERID_PARAMETER = "UserID";

    private static final String MVXCUNO_PARAMETER = "MvxCUNO";

    private static final String QTY_THOUSAND_PARAMETER = "ThousandSeparator";

    private static final String QTY_DECIMAL_PARAMETER = "DecimalSeparator";

    private static final String CID_ENABLED_PARAMETER = "CIDEnabled";

    // ATTRIBUTES
    // 1.) ORDERFILEITEMS
    private static final String ORDERFILEITEMS_ID_ATTRIB = "ID";

    private static final String ORDERFILEITEMS_ITEMID_ATTRIB = "ItemID";

    private static final String ORDERFILEITEMS_ORDER_QUANTITY_ATTRIB = "OrderQuantity";

//    private static final String ORDERFILEITEMS_VALID_QUANTITY_ATTRIB = "ValidQuantity";

    // 2.) ITEM.GETITEMFORCUSTOMER
    private static final String GETITEMFORCUSTOMER_MINIMUM_QUANTITY_ATTRIB = "MinimumQty";

    private static final String GETITEMFORCUSTOMER_MODULAR_QUANTITY_ATTRIB = "ModularQty";

    private static final String GETITEMFORCUSTOMER_ITEMID_ATTRIB = "ItemID";

    private static final String GETITEMFORCUSTOMER_CUSTOMERITEMID_ATTRIB = "CustomerItemID";

    private static final String GETITEMFORCUSTOMER_ISACTIVE_ATTRIB = "IsActive";

    private static final String GETITEMFORCUSTOMER_MVXCONFIGURABLE_ATTRIB = "MvxConfigurable";

    private static final String GETITEMFORCUSTOMER_ISSTYLE_ATTRIB = "IsStyle";

    // 3.) ORDERFILEITEM.ORDERFILEITEM_SIMPLELIST",
    private static final String ORDERFILEITEMLIST_FILEID_ATTRIB = "FileID";

    // 4.) ORDERFILEITEM.ORDERFILE_UPDATE
    private static final String ORDERFILE_UPDATE_FILEID_ATTRIB = "FileID";

    private static final String ORDERFILE_UPDATE_STATUS_ATTRIB = "Status";

    // INPUT PARAMETERS
    private int missingRequiredRequestParams = 0;

    private int fileID = 0;

    private String listPriceGroup = null;

    private String languageCode = null;

    private String mvxCompany = null;

    private String currencyCode = null;

    private String mvxWarehouse = null;

    private String userGroupID = null;

    private String userID = null;

    private String mvxCUNO = null;

    private String separatorThousand = null;

    private String separatorDecimal = null;

    private String CIDEnabled = null;

    private double ORDERLINE_MAX_QTY = 999999;

    private String lookupThousandSep = null;

    private String lookupDecimalSep = null;

    private String THOUSAND_QTY_SEPARATORS = "TextThousandSeperatorChar";

    private String DECIMAL_QTY_SEPARATORS = "TextDecimalSeperatorChar";

    // ORDER FILE ITEM STATUS CODES
    private static final String ORDERFILEITEM_OK_CODE = "OK";

    private static final String ORDERFILEITEM_INVALID_ITEM_CODE = "InvalidItem";

    private static final String ORDERFILEITEM_AMBIGUOUS_ITEM_CODE = "AmbiguousItem";

    private static final String ORDERFILEITEM_INVALID_MODULAR_QUANTITY_CODE = "InvalidModQty";

    private static final String ORDERFILEITEM_INVALID_MINIMUM_QUANTITY_CODE = "InvalidMinQty";

    private static final String ORDERFILEITEM_INVALID_MAXIMUM_QUANTITY_CODE = "InvalidMaxQty";

    private static final String ORDERFILEITEM_INVALID_ITEM_CONFIGURABLE = "InvalidItemConfig";

    private static final String ORDERFILEITEM_SEPARATOR_UNMATCH = "SepQtyUnmatched";

    // ITEM ID TYPES
    private static final String ITEMID_TYPE_STANDARD = "standard";

    private static final String ITEMID_TYPE_CUSTOMER = "customer";

    private static final String ITEMID_TYPE_AMBIGUOUS = "ambiguous";

    private static final String ORDER_FILE_STATUS_VALIDATED = "validated";

    private StringBuffer ErrorMessage = new StringBuffer("Missing Required Parameters: ");

    private static final String SQL_LOOKUP_CUSTOMERITEMID = "SELECT itemId from customerItem "
            + "WHERE customerItemId = ? AND userGroupId = ?";

    private static final String SQL_LOOKUP_STANDARDITEMID = "SELECT id from item WHERE itemNumber = ?";

    OrderFileItemBatchUpdate orderfileitembatchupdate;

    private Connection conn;

    @Override
    public void execute(PipelineContext context) throws PipelineRuntimeException {

        orderfileitembatchupdate = new OrderFileItemBatchUpdate("Update");

        // Get Request parameters
        getRequestParameters(context);

        // get quantity separators
        lookupThousandSep = getQuantitySep(THOUSAND_QTY_SEPARATORS);
        lookupDecimalSep = getQuantitySep(DECIMAL_QTY_SEPARATORS);

        // Validate Order File Items
        validateOrderFileItems();

        // Set Order File status
        setOrderFileStatus(String.valueOf(fileID), ORDER_FILE_STATUS_VALIDATED);

    }

    private void getRequestParameters(PipelineContext context) throws PipelineRuntimeException {

        // Verify type of request
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Request MUST be of type XMLRequest!");
        }

        XMLRequest request = (XMLRequest) context.getRequest();

        try {

            XMLRequest.extractRequestParameters(request);
            parameters = request.getParameters();

            // Fetch request parameters
            fileID = parameters.getint(FILE_ID_PARAMETER);
            languageCode = parameters.getString(LANGUAGE_CODE_PARAMETER);
            listPriceGroup = parameters.getString(LIST_PRICE_GROUP_PARAMETER);
            mvxCompany = parameters.getString(MVXCOMPANY_PARAMETER);
            currencyCode = parameters.getString(CURRENCY_CODE_PARAMETER);
            mvxWarehouse = parameters.getString(MVXWAREHOUSE_PARAMETER);
            userGroupID = parameters.getString(USERGROUPID_PARAMETER);
            userID = parameters.getString(USERID_PARAMETER);
            mvxCUNO = parameters.getString(MVXCUNO_PARAMETER);
            separatorThousand = parameters.getString(QTY_THOUSAND_PARAMETER);
            separatorDecimal = parameters.getString(QTY_DECIMAL_PARAMETER);
            CIDEnabled = parameters.getString(CID_ENABLED_PARAMETER);

            if ("space".equals(separatorThousand))
                separatorThousand = " ";

            if ("space".equals(separatorDecimal))
                separatorDecimal = " ";

            // Validate each required request parameter
            validateRequiredRequestParameters(String.valueOf(fileID), FILE_ID_PARAMETER);
            validateRequiredRequestParameters(languageCode, LANGUAGE_CODE_PARAMETER);
            validateRequiredRequestParameters(listPriceGroup, LIST_PRICE_GROUP_PARAMETER);
            validateRequiredRequestParameters(mvxCompany, MVXCOMPANY_PARAMETER);
            validateRequiredRequestParameters(currencyCode, CURRENCY_CODE_PARAMETER);
            validateRequiredRequestParameters(mvxWarehouse, MVXWAREHOUSE_PARAMETER);
            validateRequiredRequestParameters(userGroupID, USERGROUPID_PARAMETER);
            validateRequiredRequestParameters(userID, USERID_PARAMETER);
            validateRequiredRequestParameters(mvxCUNO, MVXCUNO_PARAMETER);
            validateRequiredRequestParameters(CIDEnabled, CID_ENABLED_PARAMETER);

            if (missingRequiredRequestParams > 0) {
                final String msg = ErrorMessage.toString();
                LOG.error(msg);
                throw new PipelineRuntimeException(msg);
            }

        } catch (RequestException e) {
            throw new PipelineRuntimeException(e);
        } catch (ParametersException e) {
            throw new PipelineRuntimeException(e);
        }
    }

    private void validateRequiredRequestParameters(String paramVariable, String param) {
        if (paramVariable == null) {
            ErrorMessage.append(param);
            missingRequiredRequestParams++;
        }
    }

    // Adjust Quantity to nearest valid Modular Quantity
    private double fixModularyQuantiy(double itemQty, double modularyQty) {

        // need to adjust modQty decimal scale
        // since only 3 decimal places is supported in the presentation layer
        modularyQty = ((double) (Math.round(modularyQty * 1000)) / 1000);

        double rNew = Math.ceil(itemQty / modularyQty) * modularyQty;

        // Check if adjusted quatity is not greater than the maximum qty
        if (rNew > ORDERLINE_MAX_QTY)
            rNew = rNew - modularyQty;

        // Try to ensure that a little unpreciseness does not result in
        // 1.0250000000000001 - modular quantity has 3 decimals
        rNew = ((double) (Math.round(rNew * 1000)) / 1000);

        return rNew;
    }

    private boolean noModularFraction(double itemQty, double rModularSize) {
        if (rModularSize == 0) {
            return true;
        } else {
            return Math.abs(itemQty - fixModularyQuantiy(itemQty, rModularSize)) < 0.00001;
        }
    }

    private void validateOrderFileItems() throws PipelineRuntimeException {

        XMLResultset orderFileItems = getOrderFileitems(String.valueOf(fileID));

        orderFileItems.beforeFirst();
        try {
            for (int i = 1; orderFileItems.moveNext(); ++i) {
                validateItem(orderFileItems.getString(ORDERFILEITEMS_ID_ATTRIB), orderFileItems
                        .getString(ORDERFILEITEMS_ITEMID_ATTRIB), orderFileItems
                        .getString(ORDERFILEITEMS_ORDER_QUANTITY_ATTRIB));
            }

            int i = orderfileitembatchupdate.executeBatchUpdate();

            LOG.debug("Updated Rows: " + i);

        } catch (ResultsetException e) {
            throw new PipelineRuntimeException();
        }
    }

    private void validateItem(String pID, String pItemID, String pOrderQuantity) throws PipelineRuntimeException {

        try {
            String vStatus = ORDERFILEITEM_OK_CODE;
            double orderQuantity = 0;
            String vAddToCart = null;
            String isCID = "N";

            setLocale(languageCode);

            String itemIdType = ITEMID_TYPE_STANDARD;

            if ("Y".equals(CIDEnabled))
                itemIdType = getItemIdType(pItemID, userGroupID);

            if (itemIdType == null) {
                vStatus = ORDERFILEITEM_INVALID_ITEM_CODE;
                vAddToCart = "N";
            } else if (ITEMID_TYPE_AMBIGUOUS.equalsIgnoreCase(itemIdType)) {
                vStatus = ORDERFILEITEM_AMBIGUOUS_ITEM_CODE;
                vAddToCart = "N";
            } else {
                if (ITEMID_TYPE_CUSTOMER.equalsIgnoreCase(itemIdType))
                    isCID = "Y";

                Resultset customerItem = getItemDetails(pItemID, itemIdType);
                int itemCount = 0;
                try {
                    itemCount = customerItem.rowCount();
                } catch (ResultsetException e) {
                    throw new PipelineRuntimeException(e);
                }

                if (itemCount > 0) {
                    customerItem.moveFirst();

                    String mvxConfig = "N";
                    String isStyle = "N";
                    try {
                        mvxConfig = customerItem.getString(GETITEMFORCUSTOMER_MVXCONFIGURABLE_ATTRIB);
                    } catch (ResultsetException e) {
                        LOG.debug("Error on Parsing MvxConfigurable Value!");
                    }

                    try {
                    	isStyle = customerItem.getString(GETITEMFORCUSTOMER_ISSTYLE_ATTRIB);
                    } catch (ResultsetException e) {
                        LOG.debug("Error on Parsing IsStyle Value!");
                    }                    

                    if ("Y".equals(mvxConfig) || "Y".equals(isStyle)) {
                        vStatus = ORDERFILEITEM_INVALID_ITEM_CONFIGURABLE;
                        vAddToCart = "N";
                    } else {

                        if (pOrderQuantity != null && !"".equals(pOrderQuantity)) {
                            try {
                                if (isNumericQtyValue(pOrderQuantity)) {
                                    if (checkQtySeparator(pOrderQuantity, separatorThousand, separatorDecimal)) {
                                        orderQuantity = unformatDecimal(pOrderQuantity).doubleValue();
                                    } else {
                                        vStatus = ORDERFILEITEM_SEPARATOR_UNMATCH;
                                        vAddToCart = "N";
                                    }
                                }
                            } catch (NumberFormatException e1) {
                                // Set Order Quantity when orderQuantity is null
                                orderQuantity = 0;
                            } catch (ParseException e) {
                                LOG.debug("Error on Parsing Order Quanity Value!");
                                vStatus = ORDERFILEITEM_SEPARATOR_UNMATCH;
                                vAddToCart = "N";
                            }
                        }

                        if (vStatus.equals(ORDERFILEITEM_OK_CODE)) {
                            double minimumQty = 0;
                            double modularQty = 0;
                            try {
                                minimumQty = customerItem.getDouble(GETITEMFORCUSTOMER_MINIMUM_QUANTITY_ATTRIB);
                                modularQty = customerItem.getDouble(GETITEMFORCUSTOMER_MODULAR_QUANTITY_ATTRIB);
                            } catch (ResultsetException e) {
                                LOG.debug("Unable to get Modular/Minimum Quantity for: " + pItemID);
                            }

                            // Validate Order Quantity of Item Number
                            if ((orderQuantity <= 0) && (minimumQty <= 0) && (modularQty <= 0)) {
                                vStatus = ORDERFILEITEM_INVALID_MINIMUM_QUANTITY_CODE;
                                orderQuantity = 1;
                            } else if ((orderQuantity <= 0) && (minimumQty <= 0) && (modularQty > 0)) {
                                vStatus = ORDERFILEITEM_INVALID_MODULAR_QUANTITY_CODE;
                                orderQuantity = modularQty;
                            } else {
                                if (orderQuantity < minimumQty) {
                                    vStatus = ORDERFILEITEM_INVALID_MINIMUM_QUANTITY_CODE;
                                    orderQuantity = minimumQty;
                                }

                                if (!noModularFraction(orderQuantity, modularQty) && modularQty > 0) {
                                    vStatus = ORDERFILEITEM_INVALID_MODULAR_QUANTITY_CODE;
                                    orderQuantity = fixModularyQuantiy(orderQuantity, modularQty);
                                }

                                if (orderQuantity > ORDERLINE_MAX_QTY) {
                                    vStatus = ORDERFILEITEM_INVALID_MAXIMUM_QUANTITY_CODE;
                                    orderQuantity = ORDERLINE_MAX_QTY;
                                    if (modularQty > 0)
                                        orderQuantity = fixModularyQuantiy(orderQuantity, modularQty);
                                }
                            }

                            if (!ORDERFILEITEM_OK_CODE.equals(vStatus))
                                vAddToCart = "N";
                            else
                                vAddToCart = "Y";
                        } else {
                            orderQuantity = 0;
                        }
                    } // end of ELSE of "MvxConfig = Y"
                } else { // start of ELSE of "itemCount > 0"
                    vStatus = ORDERFILEITEM_INVALID_ITEM_CODE;
                    vAddToCart = "N";
                }
            }

            orderfileitembatchupdate.addToBatchUpdate(pID, orderQuantity, vStatus, vAddToCart, pItemID, isCID);

        } catch (ResultsetException e) {
            final String msg = "Error getting values from the Resultset";
            LOG.error(msg, e);
            throw new PipelineRuntimeException(msg, e);
        }

    }

    private String getItemIdType(String pItemID, String userGroupID) throws PipelineRuntimeException {
        try {
            String type = null;
            int CIDMatchCount = 0;
            int standardMatchCount = 0;
            ResultSet resCID = null;
            ResultSet resStandard = null;

            conn = (Connection) CustomStagesHelper.getConnection("esales.cursor");
            if (!(conn instanceof Connection)) {
                throw new PipelineRuntimeException("Error on establishing database connection");
            } else {
                LOG.debug("Succesfully created SQL Connection!");
            }

            LogPreparedStatement pstmtCustomerItemId = new LogPreparedStatement(conn, SQL_LOOKUP_CUSTOMERITEMID);
            pstmtCustomerItemId.setString(1, pItemID);
            pstmtCustomerItemId.setString(2, userGroupID);

            LOG.debug("Executing SQL: " + pstmtCustomerItemId.getQuery());

            resCID = pstmtCustomerItemId.executeQuery();
            JDBCReader readerCID = new JDBCReader(resCID);
            CIDMatchCount = readerCID.getContent().rowCount();

            LogPreparedStatement pstmtStandardItemId = new LogPreparedStatement(conn, SQL_LOOKUP_STANDARDITEMID);
            pstmtStandardItemId.setString(1, pItemID);

            LOG.debug("Executing SQL: " + pstmtStandardItemId.getQuery());

            resStandard = pstmtStandardItemId.executeQuery();
            JDBCReader readerStandard = new JDBCReader(resStandard);
            standardMatchCount = readerStandard.getContent().rowCount();

            if ((CIDMatchCount > 1) || (standardMatchCount > 1) || (CIDMatchCount > 0 && standardMatchCount > 0))
                type = ITEMID_TYPE_AMBIGUOUS;
            else if (CIDMatchCount == 1)
                type = ITEMID_TYPE_CUSTOMER;
            else if (standardMatchCount == 1)
                type = ITEMID_TYPE_STANDARD;

            return type;

        } catch (Exception e) {
            LOG.debug(e.getMessage());
            throw new PipelineRuntimeException(e);
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    throw new PipelineRuntimeException("error closing connnection", e);
                }
            }
        }

    }

    private Resultset getItemDetails(String pItemID, String itemIdType) throws PipelineRuntimeException {
        try {
            SearchPipelineExecuter findCustomerItem = new SearchPipelineExecuter(PIPELINE_PACKAGE, "Item",
                    "GetItemForCustomer");

            findCustomerItem.setParam("@LanguageCode", languageCode);
            findCustomerItem.setParam("@ListPriceGroup", listPriceGroup);
            findCustomerItem.setParam("mvxCompany", mvxCompany);
            findCustomerItem.setParam("@CurrencyCode", currencyCode);
            findCustomerItem.setParam("@MvxWarehouse", mvxWarehouse);
            findCustomerItem.setParam("@UserGroupID", userGroupID);
            findCustomerItem.setParam("@UserID", userID);
            findCustomerItem.setParam("mvxCUNO", mvxCUNO);
            findCustomerItem.setBinding(GETITEMFORCUSTOMER_ISACTIVE_ATTRIB, "Y", "eq");

            if (ITEMID_TYPE_STANDARD.equalsIgnoreCase(itemIdType)) {
                findCustomerItem.setBinding(GETITEMFORCUSTOMER_ITEMID_ATTRIB, pItemID, "eq");
            } else if (ITEMID_TYPE_CUSTOMER.equalsIgnoreCase(itemIdType)) {
                findCustomerItem.setBinding(GETITEMFORCUSTOMER_CUSTOMERITEMID_ATTRIB, pItemID, "eq");
            } else {
                final String msg = "Unsupported Item ID Type";
                LOG.error(msg);
                throw new PipelineRuntimeException(msg);
            }

            Resultset customerItem = findCustomerItem.execute();

            return customerItem;

        } catch (Exception e) {
            LOG.debug(e.getMessage());
            throw new PipelineRuntimeException(e);
        }

    }

    // Save the process file to response
    private XMLResultset getOrderFileitems(String pFileID) throws PipelineRuntimeException {

        SearchPipelineExecuter seOrderFileItems = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                "OrderFileItem", "SimpleList");
        seOrderFileItems.setBinding(ORDERFILEITEMLIST_FILEID_ATTRIB, pFileID, "eq");

        XMLResultset rs = seOrderFileItems.execute();

        return rs;

    }

    public BigDecimal unformatDecimal(String value) throws ParseException {

        NumberFormat nf = NumberFormat.getNumberInstance(getLocale());
        String decimalSep = Character.toString(((DecimalFormat) nf).getDecimalFormatSymbols().getDecimalSeparator());

        /* Thousand separator replace */
        value = value.replaceAll(changeQtyRegExp(separatorThousand), "");
        /* Decimal separator replace */
        value = replaceDecimal(value, changeQtyRegExp(separatorDecimal), decimalSep);

        Number n = nf.parse(value);

        if (n instanceof com.ibm.icu.math.BigDecimal) {
            return new BigDecimal(((com.ibm.icu.math.BigDecimal) n).toString());
        }
        if (n instanceof BigDecimal) {
            return (BigDecimal) n;
        } else if (n instanceof java.lang.Double) {
            return new BigDecimal(n.doubleValue());
        } else if (n instanceof java.lang.Long) {
            return new BigDecimal(n.doubleValue());
        } else {
            FastStringBuffer error = new FastStringBuffer();
            error.append("Could not parse as decimal: ");
            error.append(value);
            error.append(". Parser returned unknown decimal type: ");
            error.append(n.getClass());
            throw new ParseException(error.toString(), 0);
        }
    }

    public void setLocale(String languageCode) {
        this.locale = new Locale(languageCode);
    }

    private Locale getLocale() {
        return locale;
    }

    public boolean isNumericQtyValue(String value) {
        LOG.debug("Start isNumeric");
        String validChars = "0123456789" + lookupThousandSep + lookupDecimalSep;
        char valueChar;
        if (value.length() == 0)
            return false;
        for (int a = 0; a < value.length(); a++) {
            valueChar = value.charAt(a);

            if (validChars.indexOf(valueChar) == -1) {
                LOG.debug("return false");
                return false;
            }
        }
        LOG.debug("return true");
        return true;
    }

    public boolean hasInvalidSeparator(String quantity) {
        char qtySeparator;

        for (int a = 0; a < lookupThousandSep.length(); a++) {
            qtySeparator = lookupThousandSep.charAt(a);
            if (separatorThousand.indexOf(qtySeparator) == -1 && separatorDecimal.indexOf(qtySeparator) == -1) {
                if (quantity.indexOf(qtySeparator) != -1) {
                    return true;
                }
            }
        }

        for (int a = 0; a < lookupDecimalSep.length(); a++) {
            qtySeparator = lookupDecimalSep.charAt(a);
            if (separatorThousand.indexOf(qtySeparator) == -1 && separatorDecimal.indexOf(qtySeparator) == -1) {
                if (quantity.indexOf(qtySeparator) != -1) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean checkQtySeparator(String value, String charThousand, String charDecimal) {
        int iPositionThousand = value.lastIndexOf(charThousand);
        int iPositionDecimal = value.lastIndexOf(charDecimal);
        boolean blnIsValid = true;
        int iCountDecimal = 0;

        // check for duplicate decimal
        for (int a = 0; a < value.length(); a++) {
            if (charDecimal.charAt(0) == value.charAt(a)) {
                iCountDecimal++;
            }
            if (iCountDecimal > 1) {
                blnIsValid = false;
                break;
            }
        }

        // check for separator position
        if (blnIsValid) {
            if (iPositionThousand > iPositionDecimal && iPositionDecimal != -1)
                blnIsValid = false;
        }

        if (!hasInvalidSeparator(value) && blnIsValid) {
            if (iPositionThousand != -1) {
                if ((value.length() >= (iPositionThousand + 4)) && (iPositionDecimal != -1)) { // with
                                                                                                // decimal
                    char nextChar = value.charAt(iPositionThousand + 4);
                    if (Character.isDigit(nextChar)) {
                        return false;
                    } else if (charDecimal.charAt(0) != nextChar) {
                        return false;
                    }
                } else { // without decimal
                    char nextChar = value.charAt(value.length() - 1);
                    if (!Character.isDigit(nextChar)) {
                        return false;
                    }
                }
            }

            if (iPositionDecimal != -1) {
                if ((iPositionDecimal - 4) >= 0 && (iPositionThousand != -1)) { // with
                                                                                // thousand
                                                                                // sep
                    char prevChar = value.charAt(iPositionDecimal - 4);
                    if (Character.isDigit(prevChar)) {
                        return false;
                    } else if (charThousand.charAt(0) != prevChar) {
                        return false;
                    }
                } else if ((iPositionDecimal - 4) >= -3) {
                    char prevChar = value.charAt(0);
                    if (!Character.isDigit(prevChar)) {
                        return false;
                    }
                }
            }
            return true;
        }
        return false;
    }

    public String replaceDecimal(String value, String oldDecimal, String newDecimal) {
        int iDecimalPlace = value.lastIndexOf(oldDecimal);
        if (iDecimalPlace != -1) {
            String valueDecimal = value.substring(iDecimalPlace);
            valueDecimal = valueDecimal.replace(changeQtyRegExp(oldDecimal), newDecimal);
            value = value.substring(0, iDecimalPlace) + valueDecimal;
        }
        return value;
    }

    public String changeQtyRegExp(String value) {
        if (".".equals(value))
            value = "\\.";
        return value;
    }

    // Set order file status to "processed"
    private void setOrderFileStatus(String pKey, String pStatus) throws PipelineRuntimeException {
        try {
            CommitPipelineExecuter coe = new CommitPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "OrderFile",
                    "Update");

            coe.addEntity();
            coe.setEntityKey(ORDERFILE_UPDATE_FILEID_ATTRIB, pKey);
            coe.setAttribute(ORDERFILE_UPDATE_STATUS_ATTRIB, pStatus);

            coe.execute();
        } catch (Exception e) {
            throw new PipelineRuntimeException(e);
        }
    }

    public String getQuantitySep(String codeType) throws PipelineRuntimeException {
        String sThousandSeparators = "";

        SearchPipelineExecuter seThousandSep = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "Code",
                "Lookup");

        seThousandSep.setParam("codeType", codeType);
        seThousandSep.setParam("@LanguageCode", languageCode);

        try {
            XMLResultset rs = seThousandSep.execute();
            rs.beforeFirst();
            while (rs.hasNext()) {
                rs.moveNext();
                if (!rs.getString("Code").equals("space")) {
                    sThousandSeparators = sThousandSeparators.concat(rs.getString("Code"));
                } else {
                    sThousandSeparators = sThousandSeparators.concat(" ");
                }

            }

        } catch (ResultsetException e) {
            LOG.error("Unable to get Thousand Separators");
        }

        return sThousandSeparators;
    }
}
