package com.intentia.iec.pipeline.runtime.integration.ia.utils;

import java.io.IOException;
import java.io.StringWriter;
import java.net.URISyntaxException;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.log4j.Logger;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.exception.MethodInvocationException;
import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.apache.velocity.runtime.RuntimeConstants;

import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaConnectionException;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.ia.model.IaCampaign;
import com.intentia.iec.pipeline.runtime.integration.ia.model.IaPromotion;
import com.intentia.iec.pipeline.runtime.stage.custom.StageUtilityHelper;

/**
 * Singletone class that will manage and perform all invocation to AI's RESTful
 * APIs.
 * 
 * @author ejamolod
 * @date 12/02/2013
 */
public class IaRestApiClient {

	private static final String VM_TEMPLATE_PATH = "/com/intentia/iec/pipeline/runtime/integration/ia/utils/templates/";

	private static final Logger log = Logger.getLogger(IaRestApiClient.class);

	private static IaRestApiClient instance = null;
	private static String restContextUrl = null;
	private static String packageName = null;

	private static Template campaignPayloadTmpl = null;
	private static Template promotionPayloadTmpl = null;

	private IaRestApiClient() {
		// do nothing...
	}

	public enum RestHttpMethods {
		GET, PATCH, POST, PUT, DELETE
	}

	public static IaRestApiClient getInstance() throws IaConnectionException {
		try {
			if (instance == null || true) { // TODO For testing only. Remove
											// "true".
				log.debug("Creating new instance of IaRestApiClient...");
				synchronized (IaRestApiClient.class) {
					instance = new IaRestApiClient();
					initialize();
				}
			}
		} catch (Exception e) {
			log.error("Unable to create IA REST API client.", e);
			throw new IaConnectionException(
					"Unable to create IA REST API client.", e);
		}

		return instance;
	}

	private static void initialize() throws IaRuntimeException {
		setContextUrl();
		setPayloadTmpl();
	}

	public void refinePackage() throws IaRuntimeException {
		this.invoke(IaConstants.REST_URL_REFINE_PACKAGE, RestHttpMethods.PUT);
	}

	public void deployPackage() throws IaRuntimeException {
		this.invoke(IaConstants.REST_URL_DEPLOY_PACKAGE, RestHttpMethods.PUT);
	}

	public void createCampaign(IaCampaign campaign) throws IaRuntimeException {
		if (campaign != null) {
			String id = IaConstants.REST_CAMPAIGN_PREFIX + campaign.getId();
			String payload = createPayloadXml(id, campaign.getInternalName(),
					campaignPayloadTmpl);
			createCommunication(id, payload);
		}
	}

	public void deleteCampaign(IaCampaign campaign) 
			throws IaRuntimeException{
		if (campaign != null) {
			this.refinePackage();

			String id = IaConstants.REST_CAMPAIGN_PREFIX + campaign.getId();
			String url = IaConstants.REST_URL_ADD_COMMUNICATION.replace(
					IaConstants.REST_URL_COMM_ID_VAR, id);
			this.invoke(url, RestHttpMethods.DELETE, null);
			
			this.deployPackage();
		}
	}
	
	public void deletePromotion(IaPromotion promotion)
			throws IaRuntimeException{
		
		if (promotion != null) {
			this.refinePackage();

			String id = IaConstants.REST_PROMOTION_PREFIX + promotion.getId();
			String url = IaConstants.REST_URL_ADD_COMMUNICATION.replace(
					IaConstants.REST_URL_COMM_ID_VAR, id);
			this.invoke(url, RestHttpMethods.DELETE, null);
			
			this.deployPackage();
		}
	}
	
	public void createPromotion(IaPromotion promotion)
			throws IaRuntimeException {
		String id = IaConstants.REST_PROMOTION_PREFIX + promotion.getId();
		String payload = createPayloadXml(id, promotion.getInternalName(),
				promotionPayloadTmpl);
		createCommunication(id, payload);
	}

	public void createCommunication(String id, String payload)
			throws IaRuntimeException {
		// Refine package first
		this.refinePackage();

		String url = IaConstants.REST_URL_ADD_COMMUNICATION.replace(
				IaConstants.REST_URL_COMM_ID_VAR, id);
		this.invoke(url, RestHttpMethods.PUT, payload);
		
		this.refinePackage();
	}

	public void invoke(String url, RestHttpMethods method)
			throws IaRuntimeException {
		this.invoke(url, method, null);
	}

	@SuppressWarnings("unused")
	public void invoke(String url, RestHttpMethods method, String payload)
			throws IaRuntimeException {

		if (url == null) {
			throw new IaRuntimeException(
					"Target API endpoint URL cannot be NULL.");
		}

		HttpUriRequest request = createRequest(url, method, payload);
		HttpResponse response = sendRequest(request);
	}

	private static void setContextUrl() throws IaRuntimeException {
		String serverAddress = getConfig(IaConstants.CONF_SERVER_NAME,
				IaConstants.DEF_SERVER_NAME);
		int portNumber = Integer.parseInt(getConfig(
				IaConstants.CONF_REST_PORT_NUMBER,
				IaConstants.DEF_REST_PORT_NUMBER));

		packageName = getConfig(IaConstants.CONF_PACKAGE_NAME,
				IaConstants.DEF_PACKAGE_NAME);

		try {
			URIBuilder uri = new URIBuilder();
			uri.setScheme("http");
			uri.setHost(serverAddress);
			uri.setPort(portNumber);
			uri.setPath("/" + IaConstants.REST_URL_CONTEXT);
			restContextUrl = uri.build().toString();
			log.debug("IA REST API CONTEXT URL: " + restContextUrl);
		} catch (URISyntaxException e) {
			throw new IaRuntimeException(
					"Error while setting AI's REST API URL.", e);
		}
	}

	private static void setPayloadTmpl() throws IaRuntimeException {
		try {
			Properties props = new Properties();
			props.put("resource.loader", "class");
			props.put("class.resource.loader.class",
					"org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");

			Velocity.init(props);
		
			campaignPayloadTmpl = Velocity.getTemplate(VM_TEMPLATE_PATH
					+ "campaignRequestPayload.vm");
			promotionPayloadTmpl = Velocity.getTemplate(VM_TEMPLATE_PATH
					+ "promotionRequestPayload.vm");
		
			if (campaignPayloadTmpl == null) {
				throw new IaRuntimeException(
						"Unable to load campain payload template from : "
								+ VM_TEMPLATE_PATH);
			}

			if (promotionPayloadTmpl == null) {
				throw new IaRuntimeException(
						"Unable to load promotion payload template from : "
								+ VM_TEMPLATE_PATH);
			}

		} catch (ResourceNotFoundException e) {
			try {
				setPayloadTmplByFileResourceLoader(); //For unit testing
			} catch (Exception e2) {
				throw new IaRuntimeException(
						"Unable to find request payload template from: "
								+ VM_TEMPLATE_PATH, e2);
			}
		} catch (ParseErrorException e) {
			throw new IaRuntimeException(
					"Error while parsing request payload templates from: "
							+ VM_TEMPLATE_PATH, e);
		} catch (Exception e) {
			throw new IaRuntimeException(
					"Error while setting request payload templates from: "
							+ VM_TEMPLATE_PATH, e);
		}

	}

	private static void setPayloadTmplByFileResourceLoader() throws Exception {
		String tmplDir = instance.getClass().getResource("./templates/")
				.getPath();
		log.debug("Request Payload template dir: " + tmplDir);
		try {
			Properties prop = new Properties();
			prop.setProperty("file.resource.loader.path", tmplDir);
			Velocity.init(prop);
			campaignPayloadTmpl = Velocity
					.getTemplate("campaignRequestPayload.vm");
			promotionPayloadTmpl = Velocity
					.getTemplate("promotionRequestPayload.vm");
		}  catch (Exception e) {
			throw new Exception(
					"Error while setting request payload templates from: "
							+ tmplDir, e);
		}
	}

	private HttpResponse sendRequest(HttpUriRequest request)
			throws IaRuntimeException {
		HttpResponse response = null;
		if (request != null) {
			log.debug("Invoking IA REST API: [" + request.getMethod() + "] "
					+ request.getURI() + " ...");
			CloseableHttpClient httpclient = HttpClients.createDefault();
			try {

				response = httpclient.execute(request);
				int statusCode = response.getStatusLine().getStatusCode();
				if (!(statusCode == HttpStatus.SC_OK || statusCode == HttpStatus.SC_CREATED)) {
					
					throw new IaRuntimeException(
							"Error while invoking Rest API:"
									+ request.getURI().toString()
									+ "\n caused by: HTTP error code = "
									+ statusCode);
				}

			} catch (ClientProtocolException e) {
				throw new IaRuntimeException("Error while invoking Rest API : "
						+ request.getURI(), e);
			} catch (IOException e) {
				throw new IaRuntimeException("Error while invoking Rest API : "
						+ request.getURI(), e);
			} finally {
				try {
					httpclient.close();
				} catch (IOException e) {
					log.error("Unable to close http client.", e);
				}
			}
			log.debug("Done invoking IA REST API!");
		}
		return response;
	}

	private HttpUriRequest createRequest(String url, RestHttpMethods method,
			String payload) throws IaRuntimeException {
		HttpUriRequest request = null;

		// set package name
		url = url.replace(IaConstants.REST_URL_PACKAGE_NAME_VAR, packageName);

		// append base URL
		url = restContextUrl + url;

		switch (method) {
		case GET:
			request = new HttpGet(url);
			break;
		case PATCH:
			request = new HttpPost(url);
			addPayload(request, payload);
			break;
		case POST:
			request = new HttpPost(url);
			addPayload(request, payload);
			break;
		case PUT:
			request = new HttpPut(url);
			addPayload(request, payload);
			break;
		case DELETE:
			request = new HttpDelete(url);
			break;
		default:
			throw new IaRuntimeException("Unsupported REST HTTP method: "
					+ method);
		}
		setAuthToken(request);
		return request;
	}

	private void setAuthToken(HttpUriRequest request)
	{
		String username = getConfig(IaConstants.CONF_REST_USERNAME,	IaConstants.DEF_REST_USERNAME);
		String password = getConfig(IaConstants.CONF_REST_PASSWORD, IaConstants.DEF_REST_PASSWORD);
		
		StringBuffer buf = new StringBuffer();
		buf.append((username == null)?"":RPBase64Encoder._encode(username));
		buf.append(":");
		buf.append((password == null)?"":RPBase64Encoder._encode(password));
		
		String credentials = buf.toString();
		
        String encoded1_64 = RPBase64Encoder.encode(credentials);
		String xorStr = IaAuthTokenEncryptor.applyXOR(encoded1_64);
        String token = RPBase64Encoder.encode(xorStr);
        request.addHeader("Cookie", "RPVolt="+token);
	}

	private void addPayload(HttpUriRequest request, String payload)
			throws IaRuntimeException {
		if (request != null && payload != null) {
			StringEntity entity = new StringEntity(payload, ContentType.create(
					IaConstants.REST_REQUEST_TYPE,
					IaConstants.REST_REQUEST_CHARSET));
			if (request instanceof HttpPost) {
				((HttpPost) request).setEntity(entity);
			} else if (request instanceof HttpPut) {
				((HttpPut) request).setEntity(entity);
			}
		}
	}

	private static String getConfig(String name, String defaultValue) {
		try {
			String value = StageUtilityHelper.getValueFromApplicationData(name);
			return StringUtils.defaultIfEmpty(value, defaultValue);
		} catch (Exception e) {
			log.error("Error while fetching the value of config param '" + name
					+ "'. Setting value to default = " + defaultValue, e);
			return defaultValue;
		} catch (NoClassDefFoundError e) { // Not recommended! For testing only.
			log.error("Error while fetching the value of config param '" + name
					+ "'. Setting value to default = " + defaultValue, e);
			return defaultValue;
		}
	}

	private String createPayloadXml(String id, String name, Template tmpl)
			throws IaRuntimeException {
		String payload = "";
		VelocityContext params = new VelocityContext();
		params.put("id", id);
		params.put("name", name);
		// TODO: Add other params here...

		StringWriter writter = new StringWriter();
		try {
			tmpl.merge(params, writter);
			payload = writter.toString();
		} catch (ResourceNotFoundException e) {
			throw new IaRuntimeException("Error while creating Payload XML.", e);
		} catch (ParseErrorException e) {
			throw new IaRuntimeException("Error while creating Payload XML.", e);
		} catch (MethodInvocationException e) {
			throw new IaRuntimeException("Error while creating Payload XML.", e);
		} catch (Exception e) {
			throw new IaRuntimeException("Error while creating Payload XML.", e);
		} finally {
			try {
				writter.close();
			} catch (IOException e) {
				log.error("Unable to close velocity StringWriter.", e);
			}
		}

		log.debug("IA REST XML Payload: \n" + payload);
		return payload;
	}
}
