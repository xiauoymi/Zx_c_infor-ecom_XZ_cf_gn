package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.w3c.dom.Node;
import org.w3c.dom.traversal.NodeIterator;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

/**
 * When saving values to the order, the currency should have the shopper's
 * currency. So when the merchant is updating the Order, the value need to be
 * converted from merchant's currency to shopper's currency. This stage is being
 * called from the RFQ_Update method of CurrentOrder BO
 * 
 * @author Kristina Camille Lutz
 * 
 */
public class CalculateShopperCurrencyValues implements PipelineStage {

    private static Logger LOG = Logger.getLogger(CalculateShopperCurrencyValues.class);

    private static final String RFQ_CURRENCY = "rfqCurrency";

    private XMLRequest xmlRequest = null;

    private XMLRequestHelper requestHelper = null;

    private CurrencyConverter converter;

    public void execute(PipelineContext context) throws PipelineRuntimeException {
        LOG.debug("Entering execute method");

        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }

        xmlRequest = (XMLRequest) context.getRequest();
        CustomStagesHelper.extractRequestParameters(xmlRequest);
        Parameters requestParameters = CustomStagesHelper.getRequestParameters(context);

        // skip conversion to merchant currency if user is not an admin user
        if ("true".equalsIgnoreCase(getRequestParameterString(requestParameters, ConstantsForSales.NOT_ADMIN_QUOTE))) {
            return;
        }

        String shopperCurrency = getRequestParameterString(requestParameters, RFQ_CURRENCY);
        if ("".equals(shopperCurrency)) {
            return;
        }

        String merchantCurrency = getRequestParameterString(requestParameters, ConstantsForSales.CURRENCYCODE_PARAM);
        BigDecimal merchantExchangeRate = getRequestParameterDecimal(requestParameters,
                ConstantsForSales.EXCHANGE_RATE_PARAM);

        requestHelper = new XMLRequestHelper(xmlRequest);
        converter = new CurrencyConverter(merchantCurrency, merchantExchangeRate, shopperCurrency);        
        updateOrderValues();
        LOG.debug("Exiting execute method");
    }

    /**
     * Update the prices in the order to shopper currency
     * @throws PipelineRuntimeException
     */
    private void updateOrderValues() throws PipelineRuntimeException {
        LOG.debug("Entering updateOrderValues method");
        NodeIterator iterator = XMLRequestHelper.getSubsets(xmlRequest, ConstantsForSales.ORDERLINE);
        //create an iterator that runs over all nodes in the request
        Node entityNode = iterator.nextNode();
        while (entityNode != null) {
            updateLineValues(entityNode);
            entityNode = iterator.nextNode();
        }
        LOG.debug("Exiting updateOrderValues method");
    }

    /**
     * Calls method to update values of the order line
     * @param node - a node in the request
     * @throws PipelineRuntimeException
     */
    private void updateLineValues(Node node) throws PipelineRuntimeException {
        LOG.debug("Entering updateLineValues method");
        computeValue(node, ConstantsForSales.RESELLPRICE);
        LOG.debug("Exiting updateLineValues method");
    }

    /**
     * Gets the value of the parameter from the request, computes the
     * converted value for the new currency, and posts/overwrites the new value
     * back to the request
     * @param node - a node in the request
     * @param parameter - the name of the attribute
     * @throws PipelineRuntimeException
     */
    private void computeValue(final Node node, String parameter) throws PipelineRuntimeException {
        BigDecimal price;
        String paramValue;
        try {
            paramValue = n2E(requestHelper.getAttribute(node, parameter)).trim();
            LOG.debug("Value for " + parameter + ": " + paramValue);
            try {
                price = new BigDecimal(paramValue);
            } catch (NumberFormatException e) {
                return;
            }
            String s = converter.getConvertedValue(price);            
            LOG.debug("Converted value for " + parameter + ": " + s);
            requestHelper.setAttribute(node, parameter, s);
        } catch (TransformerException e) {
            throw new PipelineRuntimeException("Failed to get/set attribute in request", e);
        }
    }

    /**
     * Gets the named parameter from the given parameter block as a string.
     * 
     * @param requestParam
     *            parameters from the request
     * @param parameterName
     *            name of the requested parameter
     * 
     * @return the parameter value as a string - empty if not found
     */
    private static String getRequestParameterString(final Parameters requestParam, final String parameterName) {
        LOG.debug("Entering getRequestParameterString method");
        String param = null;
        try {
            param = n2E(requestParam.getString(parameterName));
        } catch (ParametersException e) {
            LOG.error("Missing parameter: " + parameterName);
        }
        LOG.debug("Exiting getRequestParameterString method");
        return param;
    }

    /**
     * Gets the named parameter as a BigDecimal
     * 
     * @param requestParam
     *            parameters from the request
     * @param parameterName -
     *            name of the requested parameter
     * 
     * @return the parameter value as BigDecimal - zero if not found
     */
    private static BigDecimal getRequestParameterDecimal(final Parameters requestParam, final String parameterName) {
        LOG.debug("Entering getRequestParameterDecimal method");
        BigDecimal param = null;
        try {
            param = requestParam.getDecimal(parameterName);
        } catch (ParametersException e) {
            LOG.error("Missing parameter: " + parameterName);
        }
        if (param == null) {
            param = new BigDecimal(0);
        }
        LOG.debug("Exiting getRequestParameterDecimal method");
        return param;
    }

    /**
     * Ensure that the string is not null.
     * 
     * @param s
     *            String to check.
     * @return returns the string empty if string is null.
     */
    private static String n2E(final String s) {
        if (s == null) {
            return "";
        } else {
            return s;
        }
    }
}
