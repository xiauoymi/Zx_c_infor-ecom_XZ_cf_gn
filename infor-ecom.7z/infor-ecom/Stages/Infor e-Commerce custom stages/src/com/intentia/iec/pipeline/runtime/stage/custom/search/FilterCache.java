package com.intentia.iec.pipeline.runtime.stage.custom.search;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.lucene.search.Filter;

// @ThreadSafe
@SuppressWarnings("serial")
public final class FilterCache {
    private static final Logger LOG = Logger.getLogger(FilterCache.class);

    private static final int HITRATE_CALC_COUNT = 100;

    private static final float FILL_FACTOR = .75f;

    private static final double HUNDRED_PERCENT = 100.0;

    // @GuardedBy("this")
    private final Map<String, Filter> keyToFilterMap;

    // @GuardedBy("this")
    private int filterTries = 0;

    // @GuardedBy("this")
    private int filterFails = 0;

    public FilterCache(final int capacity) {
        LOG.debug("Initializing filter cache with a capacity of " + capacity);
        keyToFilterMap = new LinkedHashMap<String, Filter>(capacity, FILL_FACTOR, true) {
            protected boolean removeEldestEntry(final Map.Entry<String, Filter> eldest) {
                if (size() > capacity) {
                    LOG.debug("Eldest entry removed from filter cache");
                    return true;
                } else {
                    return false;
                }
            }
        };
    }

    public synchronized Filter getFilter(final String key) {
        Filter filter = keyToFilterMap.get(key);
        filterTries++;
        if (filter == null) {
            LOG.debug("Filter not found in cache. Key: " + key);
            filterFails++;
        } else {
            LOG.debug("Filter found in cache. Key: " + key);
        }
        if (filterTries == HITRATE_CALC_COUNT) {
            LOG.info("Filter cache hit rate: " + (HITRATE_CALC_COUNT - filterFails) * HUNDRED_PERCENT
                    / HITRATE_CALC_COUNT + " %");
            filterTries = 0;
            filterFails = 0;
        }
        return filter;
    }

    public synchronized void addFilter(final String key, final Filter filter) {
        LOG.debug("Filter added to cache. Key: " + key);
        keyToFilterMap.put(key, filter);
    }
}
