package com.intentia.iec.pipeline.runtime.stage.custom.search;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.search.TermQuery;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;

// @Immutable
public final class BaseDataImpl implements BaseData {
    private static final Logger LOG = Logger.getLogger(BaseDataImpl.class);

    private final boolean useWarehousing;

    private final Map<String, String> categoryPathByKey = new HashMap<String, String>();

    public BaseDataImpl(final Searcher indexSearcher) throws PipelineRuntimeException {
        try {
            Query query = new TermQuery(new Term(Strings.Index.entryType, Strings.Index.settings));
            Hits hits = indexSearcher.search(query);
            if (hits.length() != 1) {
                LOG.error("There must be one settings entry in the index");
                throw new PipelineRuntimeException();
            }
            Document doc = hits.doc(0);
            String warehousing = doc.get(Strings.Index.Settings.warehousing);
            useWarehousing = Boolean.valueOf(warehousing);
        } catch (IOException e) {
            LOG.error("Error getting warehousing setting from index", e);
            throw new PipelineRuntimeException();
        }
        try {
            Query query = new TermQuery(new Term(Strings.Index.entryType, Strings.Index.categoryBaseData));
            Hits hits = indexSearcher.search(query);
            for (int i = 0, n = hits.length(); i < n; i++) {
                Document doc = hits.doc(i);
                String categoryKey = doc.get(Strings.Index.CategoryBaseData.categoryKey);
                String categoryPath = doc.get(Strings.Index.CategoryBaseData.categoryPath);
                categoryPathByKey.put(categoryKey, categoryPath);
            }
        } catch (IOException e) {
            LOG.error("Error getting category data from index", e);
            throw new PipelineRuntimeException();
        }
    }

    public boolean isWarehousingUsed() {
        return useWarehousing;
    }

    public String getCategoryPathByKey(final String categoryKey) {
        return categoryPathByKey.get(categoryKey);
    }

}
