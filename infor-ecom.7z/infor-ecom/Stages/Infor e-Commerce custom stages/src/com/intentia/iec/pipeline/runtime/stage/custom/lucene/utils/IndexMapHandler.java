package com.intentia.iec.pipeline.runtime.stage.custom.lucene.utils;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

public class IndexMapHandler extends DefaultHandler {

    private static String OBJECT_TAG = "object";

    private static String SUBSET_TAG = "subset";

    private static String ATTRIBUTE_TAG = "attribute";

    private static String FIELD_TAG = "field";

    private static String NAME_ATTRIB = "name";

    private static String ALIAS_ATTRIB = "alias";

    private static String TYPE_ATTRIB = "type";

    private static String IS_LOCALIZE_ATTRIB = "is-localize";

    private static String IS_SORTABLE_ATTRIB = "is-sortable";

    private Map<String, Set<String>> _attributeFieldMapping = new HashMap<String, Set<String>>();

    private Set<String> _fields = new HashSet<String>();

    private Map<String, String> _fieldTypes = new HashMap<String, String>();

    private Set<String> _localizedFields = new HashSet<String>();

    private Set<String> _sortableFields = new HashSet<String>();

    private String _objectName = null;

    private String _subsetsName = null;

    private String _attributeName = null;

    private String _attributeType = null;

    private String _attributeIsLocalize = null;

    private String _attributeIsSortable = null;

    private String _fieldName = null;

    public void startElement(String namespace, String localName, String qName, Attributes attributes) {
        if (localName.equalsIgnoreCase(OBJECT_TAG)) {
            if (attributes.getValue(ALIAS_ATTRIB) != null)
                _objectName = attributes.getValue(ALIAS_ATTRIB);
            else
                _objectName = attributes.getValue(NAME_ATTRIB);
            _subsetsName = "";
        } else if (localName.equalsIgnoreCase(SUBSET_TAG)) {
            _subsetsName += "_" + attributes.getValue(NAME_ATTRIB);
        } else if (localName.equalsIgnoreCase(ATTRIBUTE_TAG)) {
            _attributeName = _objectName + _subsetsName + "_" + attributes.getValue(NAME_ATTRIB);
            _attributeType = attributes.getValue(TYPE_ATTRIB);
            _attributeIsLocalize = attributes.getValue(IS_LOCALIZE_ATTRIB);
            _attributeIsSortable = attributes.getValue(IS_SORTABLE_ATTRIB);
        } else if (localName.equalsIgnoreCase(FIELD_TAG)) {
            _fieldName = attributes.getValue(NAME_ATTRIB);
        }
    }

    public void endElement(String uri, String localName, String qName) {
        if (localName.equalsIgnoreCase(OBJECT_TAG)) {
            resetAll();
        } else if (localName.equalsIgnoreCase(SUBSET_TAG)) {
            _subsetsName = "";
        } else if (localName.equalsIgnoreCase(ATTRIBUTE_TAG)) {
            _attributeFieldMapping.put(_attributeName, new HashSet<String>(_fields));
            _fields.clear();
        } else if (localName.equalsIgnoreCase(FIELD_TAG)) {
            if (_fieldName != null) {
                _fieldName = IndexManagerUtil.standardizeFieldName(_fieldName);
                _fields.add(_fieldName);
                _fieldTypes.put(_fieldName, _attributeType);
                if ("true".equalsIgnoreCase(_attributeIsLocalize))
                    _localizedFields.add(_fieldName);
                if ("true".equalsIgnoreCase(_attributeIsSortable))
                    _sortableFields.add(_fieldName);
            }
        }
    }

    public Map<String, Set<String>> getAttributeFieldMapping() {
        return _attributeFieldMapping;
    }

    public Map<String, String> getFieldTypes() {
        return _fieldTypes;
    }

    public Set<String> getLocalizedFields() {
        return _localizedFields;
    }

    public Set<String> getSortableFields() {
        return _sortableFields;
    }

    private void resetAll() {
        _objectName = null;
        _subsetsName = null;
        _attributeName = null;
        _attributeType = null;
        _fieldName = null;
        _attributeIsLocalize = null;
        _fields.clear();
    }
}
