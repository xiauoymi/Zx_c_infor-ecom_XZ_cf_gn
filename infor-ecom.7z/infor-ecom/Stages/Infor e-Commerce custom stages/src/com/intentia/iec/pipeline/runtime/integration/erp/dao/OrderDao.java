package com.intentia.iec.pipeline.runtime.integration.erp.dao;

import com.intentia.iec.pipeline.runtime.integration.erp.exception.ErpConnectionException;
import com.intentia.iec.pipeline.runtime.integration.erp.exception.ErpRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.erp.model.OrderLinePriceRequest;
import com.intentia.iec.pipeline.runtime.integration.erp.model.OrderLinesPrice;
import com.intentia.iec.pipeline.runtime.integration.erp.model.OrderTotal;
import com.intentia.iec.pipeline.runtime.integration.erp.model.OrderTotalRequest;

public interface OrderDao {

	OrderTotal getOrderTotal(OrderTotalRequest request) throws ErpRuntimeException, ErpConnectionException;	

	OrderLinesPrice getOrderLinePrice(OrderLinePriceRequest request) throws ErpRuntimeException, ErpConnectionException;
	
}
