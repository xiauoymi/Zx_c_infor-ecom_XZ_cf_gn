package com.intentia.iec.pipeline.runtime.integration.erp.model;

import java.util.List;

public class ItemAvailability {

	private String tenantId;

	private String accountingEntityId;

	private List<AvailabilityDetail> details;

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public String getAccountingEntityId() {
		return accountingEntityId;
	}

	public void setAccountingEntityId(String accountingEntityId) {
		this.accountingEntityId = accountingEntityId;
	}

	public List<AvailabilityDetail> getDetails() {
		return details;
	}

	public void setDetails(List<AvailabilityDetail> details) {
		this.details = details;
	}

}
