package com.intentia.iec.pipeline.runtime.stage.custom;

/**
 * This is the SearchEngineItemBean class which is using to upload data to the
 * google base system.
 * 
 * @author xinc0082(Mayur)
 */
public class SearchEngineItemBean {

    Long id = null;

    String baseUrl = null;

    String title = null;

    String content = null;

    String unit = null;

    String itemDescription = null;

    float price = 0.0f;

    String summary = null;

    String imageURL = null;

    String brand = null;

    String searchEngineItemId = null;

    public SearchEngineItemBean() {
        id = null;
        title = "";
        content = "";
        unit = "";
        itemDescription = "";
        price = 0.0f;
        summary = "";
        imageURL = "";
        brand = "";
        searchEngineItemId = null;

    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public String getItemDescription() {
        return itemDescription;
    }

    public void setItemDescription(String itemDescription) {
        this.itemDescription = itemDescription;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getSearchEngineItemId() {
        return searchEngineItemId;
    }

    public void setSearchEngineItemId(String searchEngineItemId) {
        this.searchEngineItemId = searchEngineItemId;
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

}
