package com.intentia.iec.pipeline.runtime.integration.ia.exception;

public class IaRuntimeException extends Exception {

	private static final long serialVersionUID = 1L;

	public IaRuntimeException() {
		super();
	}

	public IaRuntimeException(String message) {
		super(message);
	}

	public IaRuntimeException(Throwable cause) {
		super(cause);
	}

	public IaRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}

}
