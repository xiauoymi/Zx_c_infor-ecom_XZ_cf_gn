/*
 * Created on 06-03-2006
 */
package com.intentia.iec.pipeline.runtime.custom.pim;

import java.io.Writer;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

/**
 * Utility class for writing XML requests from the {@link DeleteSet} and
 * {@link Entity} instances.
 * 
 * @author PEDJES0
 * 
 */
public class XMLRequestWriter {

    private final Writer output;

    private XMLStreamWriter writer = null;

    private String encoding = "UTF-8";

    static {
        System.setProperty("javax.xml.stream.XMLOutputFactory", "weblogic.xml.stax.XMLStreamOutputFactory");
        // props.getProperty("javax.xml.stream.XMLOutputFactory"));
    }

    /**
     * 
     */
    public XMLRequestWriter(final Writer output) {
        super();
        this.output = output;
    }

    private XMLStreamWriter initWriter() throws XMLStreamException {
        if (writer == null) {
            writer = XMLOutputFactory.newInstance().createXMLStreamWriter(output);
        }
        return writer;
    }

    public final void write(final DeleteSet request) throws XMLStreamException {
        initWriter();
        writer.writeStartElement("delete");
        if (request.getKey() == null) {
            // TODO throw Exception ?
        }
        writeKey(request.getKey());

        if (request.getChildren() != null) {
            writeDeleteSubsets(request.getChildren());
        }
        writer.writeEndElement();
    }

    private void writeDeleteSubsets(final List subsets) throws XMLStreamException {
        writer.writeStartElement("dsubsets");

        Iterator it = subsets.iterator();
        while (it.hasNext()) {
            Subset subset = (Subset) it.next();
            writer.writeStartElement("dsubset");
            writer.writeAttribute("name", subset.getName());
            if (subset.getKey() == null) {
                // TODO throw Exception ?
            }
            writeKey(subset.getKey());

            writer.writeEndElement();
        }

        writer.writeEndElement();
    }

    public final void writeRequestStart() throws XMLStreamException {
        initWriter();
        writer.writeStartDocument(encoding, "1.0");
        writer.writeStartElement("request");
    }

    public final void writeRequestEnd() throws XMLStreamException {
        writer.writeEndElement();
        writer.writeEndDocument();
    }

    public final void writeCommitStart() throws XMLStreamException {
        writeRequestStart();
        writer.writeStartElement("entities");
    }

    public final void writeCommitEnd() throws XMLStreamException {
        writer.writeEndElement();
        writeRequestEnd();
    }

    public final void write(final Entity request) throws XMLStreamException {
        writer.writeStartElement("entity");
        if (request.getKey() != null) {
            writeKey(request.getKey());
        }

        if (request.getAttributes() != null) {
            writeAttributes(request.getAttributes());
        }

        Collection subsets = request.getTextSubsets();
        if (subsets != null || request.getChildren() != null) {
            writeSubsets(subsets, request.getChildren());
        }

        writer.writeEndElement();
    }

    public final void writeAttributes(final List attributes) throws XMLStreamException {
        writer.writeStartElement("attributes");
        Iterator it = attributes.iterator();
        while (it.hasNext()) {
            Attribute attr = (Attribute) it.next();
            writer.writeStartElement("attribute");
            writer.writeAttribute("name", attr.getName());
            if (attr.getValue() == null) {
                writer.writeAttribute("null", "true");
            } else {
                writer.writeCharacters(attr.getValue());
            }
            writer.writeEndElement();
        }
        writer.writeEndElement();
    }

    public final void writeSubsets(final Collection textSubsets, final Collection subsets) throws XMLStreamException {
        writer.writeStartElement("subsets");

        if (textSubsets != null) {
            Iterator it = textSubsets.iterator();
            while (it.hasNext()) {
                writeSubset((Subset) it.next());
            }
        }

        if (subsets != null) {
            Iterator it = subsets.iterator();
            while (it.hasNext()) {
                writeSubset((Subset) it.next());
            }
        }

        writer.writeEndElement();
    }

    public final void writeSubset(final Subset subset) throws XMLStreamException {
        writer.writeStartElement("subset");
        writer.writeAttribute("name", subset.getName());

        if (subset.getKey() != null) {
            writeKey(subset.getKey());
        }

        if (subset.getAttributes() != null) {
            writeAttributes(subset.getAttributes());
        }

        // TODO write subsubsets?
        writer.writeEndElement();
    }

    public final void writeKey(final String keyValue) throws XMLStreamException {
        writer.writeStartElement("keys");
        writer.writeStartElement("key");
        writer.writeAttribute("value", keyValue);
        writer.writeEndElement();
        writer.writeEndElement();
    }
}
