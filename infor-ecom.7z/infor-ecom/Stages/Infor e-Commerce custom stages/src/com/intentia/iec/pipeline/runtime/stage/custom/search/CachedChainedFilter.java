package com.intentia.iec.pipeline.runtime.stage.custom.search;

import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.misc.ChainedFilter;
import org.apache.lucene.search.Filter;

/**
 * A filter which is composed of other filters. The sub-filters are combined
 * with a bitwise-AND operation. Both this chained filter and the sub-filters
 * can be stored in the filter cache.
 */
public final class CachedChainedFilter extends FilterBase {
    private List<FilterBase> filterList;

    private List<Integer> logicList = null;

    public CachedChainedFilter() {
        filterList = new ArrayList<FilterBase>();
        logicList = new ArrayList<Integer>();
    }

    /**
     * Add a filter to this composite of filters.
     * 
     * @param filter
     *            the new filter to add
     */
    public void add(final FilterBase filter) {
        add(filter, ChainedFilter.AND);
    }

    public void add(final FilterBase filter, int logic) {
        filterList.add(filter);
        logicList.add(logic);
    }

    public String createCacheKey() {
        StringBuilder buf = new StringBuilder(100);
        buf.append("ChainedFilter: ");
        for (int i = 0; i < filterList.size(); i++) {
            buf.append(filterList.get(i).getCacheKey());
            if (i < filterList.size() - 1) {
                buf.append(" + ");
            }
        }
        return buf.toString();
    }

    public Filter createFilter(final DataHolder dataHolder) {
        if (filterList.isEmpty()) {
            return null;
        } else if (filterList.size() == 1) {
            return filterList.get(0).getFilter(dataHolder);
        } else {
            Filter[] filters = new Filter[filterList.size()];
            for (int i = 0; i < filters.length; i++) {
                filters[i] = filterList.get(i).getFilter(dataHolder);
            }
            // Create array of logics
            int[] logicArray = new int[logicList.size()];
            for (int i = 0; i < logicList.size(); i++) {
                logicArray[i] = logicList.get(i).intValue();
            }

            return new ChainedFilter(filters, logicArray);
        }
    }
}
