package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

public class MergeStyleItemID implements PipelineStage {
	
	private static final Logger LOG = Logger.getLogger(MergeStyleItemID.class);
	
	public void execute(PipelineContext context) throws PipelineRuntimeException {
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
        }      
        
        String mergeSKUProperty = CustomStagesHelper.getKeyValue("Ordering.Merge SKU in orderlines");
        if (mergeSKUProperty != null && Boolean.valueOf(mergeSKUProperty) == false) {
        	throw new PipelineRuntimeException("Should not invoke this method if Ordering.Merge SKU in orderlines=false");
        }
        
        if (context.getResponse() instanceof XMLResultset) {
        	XMLResultset result = (XMLResultset) context.getResponse();
        	
			try {
				Document document = result.getDocument();
	        	if (document != null) {
	        		
	        		NodeList nodeList = XPathAPI.selectNodeList(document,"resultset/row/OrderLine");
	        		
	        		if (nodeList != null && nodeList.getLength() >= 1) {
	        			
	        			Set<Element> deletedNodes = new HashSet<Element>();
	        			for (int i = 0; i < nodeList.getLength(); i++) {
	        				Element node = (Element)nodeList.item(i);
	        				
	        				String sku = node.getAttribute("SKU");	
	        				String itemId = node.getAttribute("ItemID");
	        				String mvxConfigurableID = node.getAttribute("MvxConfigurableID"); 
	        				String styleName= node.getAttribute("SKUName");
	        				
	        				if (sku != null && sku.length() > 0 && deletedNodes.contains(node) == false) {
	        					
	        					StringBuffer sb = new StringBuffer("resultset/row/OrderLine[(");
	        					sb.append("@SKU=\"");
	        					sb.append(sku);
	        					sb.append("\"");
	        					sb.append(" and ");	        					
	        					
	        					if (mvxConfigurableID != null && mvxConfigurableID.length() > 0) {
	        						sb.append("@MvxConfigurableID=\"");
	                                sb.append(mvxConfigurableID);
	                                sb.append("\"");
	        					}
	        					else {
	        						sb.append("not(@MvxConfigurableID)");
	        					}
	        					
	        					sb.append(")]");
	        					
	        					NodeList similarNodes = XPathAPI.selectNodeList(document,sb.toString());
	        					if (similarNodes != null && similarNodes.getLength() >= 1) {
	        						LOG.debug("SET CustomerItemID: "+(node.getAttribute("CustomerItemID")));
	        						node.setAttribute("CustomerItemID", "");
	        						//retrieve style item name
	        						
	        						if (styleName!=null && !styleName.equals("")){
	        							node.setAttribute("ItemName", styleName);
	        						}
	        						Element	orderLine = document.createElement("OrderLine");
	        						orderLine.setAttribute("OrderLineID", node.getAttribute("OrderLineID"));
	        						node.appendChild(orderLine);
	        						
	        						for (int j = 0; j < similarNodes.getLength(); j++) {
	        							Element similar = (Element)similarNodes.item(j);

	        							if (node.equals(similar) == false && deletedNodes.contains(similar) == false && sameSku(node, similar) == true) {
	        								double qty1 = Double.parseDouble(node.getAttribute("Quantity"));
	        								double qty2 = Double.parseDouble(similar.getAttribute("Quantity"));	 
	        								
	        								LOG.debug("SETTING NEW QUANTITY "+(qty1+qty2));
	        								node.setAttribute("Quantity", Double.toString(qty1+qty2));
	        								node.setAttribute("SKUIsMerged", "Y");
	        								
	        								BigDecimal lineTotal1 = new BigDecimal(n20(node.getAttribute("LineTotal")));
	        								BigDecimal lineTotal2 = new BigDecimal(n20(similar.getAttribute("LineTotal"))); 
	        								node.setAttribute("LineTotal", String.valueOf(lineTotal1.add(lineTotal2)));
	        								
	        								orderLine = document.createElement("OrderLine");
	        								orderLine.setAttribute("OrderLineID", similar.getAttribute("OrderLineID"));
	    	        						node.appendChild(orderLine);
	        								
	        								deletedNodes.add(similar);
	        							}	
	        						}
	        					}	        					
	        				}
	        				else {
	        					LOG.debug("Skipping merge. No Sku = "+itemId);
	        				}
	        			}        				
        				
        				Iterator<Element> it = deletedNodes.iterator();
        				while (it.hasNext() == true) {
        					Element e = it.next();
        					
        					if (e.getParentNode() != null) {
        						e.getParentNode().removeChild(e);
        					}
        				}
        				deletedNodes.clear();
	        		}
	        		
	        		XMLResultset resultset = (XMLResultset) context.getResponse();
	                LOG.debug("Resultset after MergeStyleItemID = "+resultset.toString());	
	        	}
			} catch (ResultsetException e) {
				throw new PipelineRuntimeException("Error in merging SKUs", e);
			} catch (TransformerException e) {
				throw new PipelineRuntimeException("Error in merging SKUs", e);
			}
        }        
	}
	
	private boolean sameSku(Element node, Element similar) {
		if (node != null && similar != null) {
			String sku1 = node.getAttribute("SKU");
			String sku2 = similar.getAttribute("SKU");
			
			if (sku1 != null && sku2 != null) {
				return sku1.equals(sku2);
			}
		}
		return false;
	}
	
	private String n20(String val) {
		if (val == null || "".equals(val)) {
			return "0";
		} else {
			return val;
		}
	}
}

