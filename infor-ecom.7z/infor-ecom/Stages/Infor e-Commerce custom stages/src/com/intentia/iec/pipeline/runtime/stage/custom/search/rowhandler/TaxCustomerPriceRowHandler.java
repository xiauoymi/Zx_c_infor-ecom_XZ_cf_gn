package com.intentia.iec.pipeline.runtime.stage.custom.search.rowhandler;

import static com.intentia.iec.pipeline.runtime.stage.custom.search.IndexerUtils.addIndexedField;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.lucene.document.Document;

import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Jdbc;
import com.intentia.iec.pipeline.runtime.stage.custom.search.SearchUtils;
import com.intentia.iec.pipeline.runtime.stage.custom.search.Strings;

/**
 * Adds taxed customer prices to the index.
 *
 */
public class TaxCustomerPriceRowHandler implements Jdbc.RowHandler {
    private Document doc = null;

    public TaxCustomerPriceRowHandler(Document doc) {
        this.doc = doc;
    }

    public void processRow(ResultSet rs) throws SQLException, PipelineRuntimeException {
        // field is price_customerid_currency_countrycode
        String customerId = rs.getString(Strings.Database.Indexing.Item.TaxCustomerPrice.customerId);
        String taxPrice = rs.getString(Strings.Database.Indexing.Item.TaxCustomerPrice.taxPrice);
        String currencyCode = rs.getString(Strings.Database.Indexing.Item.TaxCustomerPrice.currencyCode);
        String countryCode = rs.getString(Strings.Database.Indexing.Item.TaxCustomerPrice.countryCode);
        if (currencyCode != null) {
            String field = Strings.Index.Item.taxPricePrefix + customerId + "_" + currencyCode + "_" + countryCode;
            String value = SearchUtils.toPaddedString(taxPrice);
            addIndexedField(doc, field.toLowerCase(), value.toLowerCase());
        }
    }
}