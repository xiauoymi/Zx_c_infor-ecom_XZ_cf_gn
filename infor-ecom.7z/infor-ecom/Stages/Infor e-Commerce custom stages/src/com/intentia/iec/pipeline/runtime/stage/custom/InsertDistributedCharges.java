package com.intentia.iec.pipeline.runtime.stage.custom;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.businessobject.input.RequestException;

public class InsertDistributedCharges implements PipelineStage{


	public void execute(PipelineContext context) throws PipelineRuntimeException {

		if (!(context.getRequest() instanceof XMLRequest)) {
			throw new PipelineRuntimeException("Cannot process request. Must be of type 'XMLRequest'!");
		}
		try {
			XMLRequest xmlRequest = (XMLRequest) context.getRequest(); 
	        XMLRequest.extractRequestParameters(xmlRequest);
			int orderID = new Integer(xmlRequest.getParameters().getString("orderID"));
			BigDecimal value = new BigDecimal(xmlRequest.getParameters().getString("value"));
			String reasonCode = xmlRequest.getParameters().getString("reasonCode");
			updateChargeTaxtoDB(orderID, value, reasonCode);
		} catch (ParametersException e) {
			throw new PipelineRuntimeException(e);
		} catch (SQLException e) {
			throw new PipelineRuntimeException(e);
		} catch (RequestException e){
			 throw new PipelineRuntimeException("Error extracting request parameters!", e);
		}

	}


	private void updateChargeTaxtoDB(int orderID, BigDecimal value, String reasonCode) throws PipelineRuntimeException, SQLException{
		PreparedStatement pstmt = null;
		Connection conn = null;
		try {
			conn = (Connection) CustomStagesHelper.getConnection("esales.cursor");	

			String sqlInsert = "INSERT INTO [DistributedCharges] (orderId, reasonCode, value) VALUES (?,?,?)";
			pstmt = conn.prepareStatement(sqlInsert);	
			pstmt.setInt(1, orderID);
			pstmt.setString(2, reasonCode);
			pstmt.setBigDecimal(3, value);						
			pstmt.executeUpdate();
			pstmt.clearParameters();

		} catch (SQLException se) {
			throw new PipelineRuntimeException("Error executing updateChargeTaxtoDB function", se);
		} catch (Exception e) {
			throw new PipelineRuntimeException(e);
		} finally {
			pstmt.close();
			conn.close();
		}
	}
}





