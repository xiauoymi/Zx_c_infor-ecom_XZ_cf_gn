package com.intentia.iec.pipeline.runtime.stage.custom.ia;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.ia.dao.IaDao;
import com.intentia.iec.pipeline.runtime.integration.ia.dao.impl.IaDaoRpImpl;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaConnectionException;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.ia.model.IaCampaign;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;

//===========================================
//TODO: DELETE THIS CLASS. Not being used.
//===========================================
public class GetIaCampaignsStage extends AbstractPipelineStage {

	private static final Logger log = Logger
			.getLogger(GetIaCampaignsStage.class);

	private static final String DEFAULT_EVENT = "GetOffers";
	private static final String DEFAULT_USER_ID = "0";
	private static final String DEFAULT_MAX_RECORD = "5";
	private static final String DEFAULT_QUERY = "";

	public static final String PARAM_NO_IA_CAMPAIGNS = "noInteractionAdvisorCampaigns";

	@SuppressWarnings("unchecked")
	@Override
	public void execute(PipelineContext context)
			throws PipelineRuntimeException {
		log.debug("Executing GetIaCampaignsStage.execute()...");
		try {
			CustomStagesHelper.extractRequestParameters(CustomStagesHelper
					.getRequest(context));
			XMLRequest request = (XMLRequest) context.getRequest();
			Parameters requestParams = request.getParameters();
			XMLResultset result = new XMLResultset();

			List<String> campaignIds = Arrays.asList("6,7,8");

			List<IaCampaign> campaigns = retrieveCampaignRankingFromIA(
					campaignIds, requestParams);

			if (campaigns != null && !campaigns.isEmpty()) {
				for (IaCampaign campaign : campaigns) {
					XMLResultset campaignDetails = getCampaignDetails(campaign.getId());
					if(campaignDetails != null && !campaignDetails.isEmpty()) {
						campaignDetails.moveFirst();
					}
				}
			} else {
				result = getEmptyResponse();
			}

			log.debug(result.toString());
			context.setResponse(result);

		} catch (Exception e) {
			throw new PipelineRuntimeException(
					"Error while retrieving IA campaign rankings.", e);
		}
	}

	private XMLResultset getCampaignDetails(String campaignId)
			throws PipelineRuntimeException {
		XMLResultset result;
		// Execute BO method
		SearchPipelineExecuter pipeline = new SearchPipelineExecuter(
				ConstantsForSales.PIPELINE_PACKAGE, "Campaign", "Details");
		pipeline.setBinding("CampaignID", campaignId, "eq");
		result = pipeline.execute();
		return result;
	}

	private List<IaCampaign> retrieveCampaignRankingFromIA(
			List<String> campaignIds, Parameters requestParams)
			throws PipelineRuntimeException, ParametersException {
		List<IaCampaign> result = null;
		try {
			Map<String, String> params = new HashMap<String, String>();
			params.put("SessionId", StringUtils.defaultString(
					requestParams.getString(ConstantsForSales.USER_ID_PARAM),
					DEFAULT_USER_ID));
			params.put("MaxOffers", StringUtils.defaultString(
					requestParams.getString("MaxRecord"), DEFAULT_MAX_RECORD));
			params.put("Query", StringUtils.defaultString(
					requestParams.getString("Query"), DEFAULT_QUERY));

			try {
				IaDao dao;
				dao = new IaDaoRpImpl();
				result = dao.getCampaigns(
						StringUtils.defaultString(
								requestParams.getString("CampaignEvent"),
								DEFAULT_EVENT), params);
			} catch (IaRuntimeException e) {
				log.error(
						"Error while retrieving campaign rankings from the IA server. Ignoring IA ranking.",
						e);
			}
		} catch (IaConnectionException e) {
			throw new PipelineRuntimeException(
					"Error while connecting to the IA server", e);
		}

		log.debug("IA Campaign Ranking: " + result.toString());

		return result;
	}

	private XMLResultset getEmptyResponse() {
		StringBuilder responseStr = new StringBuilder();
		responseStr.append(ConstantsForSales.XML_DATA_HEADER);
		responseStr.append("<resultset object=\"Campaign\">");
		responseStr.append("</resultset>");
		return new XMLResultset(responseStr.toString());
	}
}
