package com.intentia.iec.pipeline.runtime.stage.custom.promotion.takeaway;

import java.util.List;
import java.util.Map;

import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;

public interface TakeAway{

	void applyHeaderTakeaway(XMLResultset resultSet);
	
	void applyLineTakeAway(XMLResultset resultSet, XMLIterator xmlOrderline);

	void setPromotionTakeAway(PromotionTakeAway promotionTakeAway);
	
	void setPromotionalItems(List<String> promotionalItems);

	void setItemParametersMap(Map<String, String> itemDetailsMap);
}
