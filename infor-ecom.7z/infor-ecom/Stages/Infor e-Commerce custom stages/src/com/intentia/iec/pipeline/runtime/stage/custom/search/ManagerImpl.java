package com.intentia.iec.pipeline.runtime.stage.custom.search;

import java.io.File;
import java.io.FilenameFilter;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Properties;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.util.FastStringBuffer;
import com.intentia.iec.util.PropertyLoader;

/** Implementation of the Manager interface. */
// @Threadsafe
// removed final so that SPS can inherit from this class
public class ManagerImpl implements Manager {
    private static final Logger LOG = Logger.getLogger(ManagerImpl.class);

    protected static final String APP_PROP_FILENAME = "/application.properties";

    private static final String APP_PROP_FILTER_CAPACITY = "Search Engine.Filter Cache Capacity";

    private static final String APP_PROP_INDEX_FOLDER = "Search Engine.Index Folder";

    /**
     * Key use to retrieved Search Engine Index Folder from the Database.
     */
    private static final String APP_DETAILS_SEARCH_ENGINE_INDEX_FOLDER = "IndexFolder";

    protected static final String APP_PROP_PAGES_B2C = "Application.Pages B2C";

    private static final String FOLDERNAME_FORMAT = "%d-%02d-%02d %02d.%02d.%02d";

    public static final Manager INSTANCE = new ManagerImpl();

    protected static final int DEFAULT_FILTERCACHE_CAPACITY = 10;

    protected static final int MIN_FILTERCACHE_CAPACITY = 1;

    protected static final int MAX_FILTERCACHE_CAPACITY = 1000;

    private static final String DEFAULT_INDEX_FOLDER = "C:/lucene-index";

    private static final int DATAHOLDER_SWAP_DELAY = 3000;

    protected static final String DEFAULT_APP_TYPE = Strings.Application.Type.b2b;

    protected String indexFolder;

    protected int filterCacheCapacity;

    protected String applicationType;

    // @GuardedBy("this")
    protected DataHolder dataHolder;

    /** Manager is a singleton; prevent external instantiation. */
    protected ManagerImpl() {
        Properties properties = PropertyLoader.loadProperties(APP_PROP_FILENAME);
        if (properties == null) {
            indexFolder = DEFAULT_INDEX_FOLDER;
            filterCacheCapacity = DEFAULT_FILTERCACHE_CAPACITY;
            applicationType = DEFAULT_APP_TYPE;
            LOG.debug("Error reading application properties" + " (using defaults instead)");
        } else {
            // Load index folder setting
            try {
                getSEIndexFolderPath();
            } catch (PipelineRuntimeException e) {
                LOG.debug(e.getMessage());
            }
            // Load filter cache capacity setting
            String capStr = properties.getProperty(APP_PROP_FILTER_CAPACITY);
            int cap = 0;
            if (capStr != null) {
                cap = Integer.parseInt(capStr);
            }
            if (cap < MIN_FILTERCACHE_CAPACITY || cap > MAX_FILTERCACHE_CAPACITY) {
                cap = DEFAULT_FILTERCACHE_CAPACITY;
            }
            filterCacheCapacity = cap;
            // Load B2C pages setting
            capStr = properties.getProperty(APP_PROP_PAGES_B2C);
            if (capStr.equalsIgnoreCase("true")) {
                applicationType = Strings.Application.Type.b2c;
            } else {
                applicationType = Strings.Application.Type.b2b;
            }
        }
        LOG.debug("Index folder: " + indexFolder);
        LOG.debug("Filter cache capacity: " + filterCacheCapacity);
    }

    /**
     * Get Search Engine Index Folder from Application Data.
     * 
     * @return
     * @throws PipelineRuntimeException
     */
    private String getSEIndexFolderPath() throws PipelineRuntimeException {

        indexFolder = getValueFromApplicationData(APP_DETAILS_SEARCH_ENGINE_INDEX_FOLDER);

        if (null == indexFolder) {
            FastStringBuffer msg = new FastStringBuffer(100);
            msg.append("Missing application data: ").append(APP_DETAILS_SEARCH_ENGINE_INDEX_FOLDER);
            throw new PipelineRuntimeException(msg.toString());
        }
        LOG.debug("Search Engine Index Folder Path: " + indexFolder.toString());

        return indexFolder;
    }

    public int getFilterCacheCapacity() {
        return filterCacheCapacity;
    }

    public synchronized DataHolder getDataHolder() throws PipelineRuntimeException {
        if (dataHolder == null) {
            dataHolder = new DataHolderImpl(INSTANCE);
        }
        return dataHolder;
    }

    public synchronized void reloadData() throws PipelineRuntimeException {
        LOG.info("Swapping Lucene search data");
        // Will be null if the first operation after a restart is indexing
        if (dataHolder != null) {
            try {
                // Allow other threads to finish using the current cache.
                // Don't allow new searches to commence (lock is held).
                Thread.sleep(DATAHOLDER_SWAP_DELAY);
            } catch (InterruptedException ignore) {
            }
            dataHolder.close();
        }
        dataHolder = null; // Will be reloaded on next search
    }

    public String getParentFolder() {
        try {
            return this.getSEIndexFolderPath();
        } catch (PipelineRuntimeException e) {
            LOG.debug("Error reading application date" + " (using defaults instead)");
            return DEFAULT_INDEX_FOLDER;
        }
    }

    public String getNewFolderName() {
        Calendar cal = Calendar.getInstance();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss");
        return df.format(cal.getTime());
    }

    public String getCurrentFolder() {
        File parentFolder = new File(getParentFolder());
        String[] folders = parentFolder.list(new FilenameFilter() {
            public boolean accept(final File dir, final String name) {
                return name.startsWith(IndexerStageUtils.FOLDER_PREFIX);
            }
        });
        if (folders.length == 0) {
            return null;
        }
        Arrays.sort(folders);
        return folders[folders.length - 1];
    }

    public String getApplicationType() {
        return applicationType;
    }

    private String getValueFromApplicationData(String pParamName) {

        String paramValue;

        SearchPipelineExecuter spe = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                ConstantsForSales.APPLICATION_DATA, ConstantsForSales.APPLICATION_DATA_DETAILS);

        spe.setParam("param", pParamName);

        try {
            XMLResultset rs = spe.execute();
            rs.moveFirst();
            paramValue = rs.getString("ParameterValue");
        } catch (PipelineRuntimeException e) {
            paramValue = "";
        } catch (ResultsetException e) {
            paramValue = "";
        }

        return paramValue;

    }
}
