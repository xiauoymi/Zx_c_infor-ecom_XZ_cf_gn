/*
 * Created on 06-03-2006
 */
package com.intentia.iec.pipeline.runtime.custom.pim;

import java.util.LinkedList;
import java.util.List;

/**
 * @author PEDJES0
 * 
 */
public class Set {
    private List attributes = null;

    public final void addAttribute(final String name, final String value) {
        if (attributes == null) {
            attributes = new LinkedList();
        }

        attributes.add(new Attribute(name, value));
    }

    public final List getAttributes() {
        return attributes;
    }

}
