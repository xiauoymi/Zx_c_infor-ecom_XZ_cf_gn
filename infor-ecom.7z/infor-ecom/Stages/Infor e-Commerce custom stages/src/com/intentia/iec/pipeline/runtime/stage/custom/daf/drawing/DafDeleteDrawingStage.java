package com.intentia.iec.pipeline.runtime.stage.custom.daf.drawing;

import java.io.StringReader;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.log4j.Logger;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.intentia.icp.common.CMException;
import com.intentia.icp.common.CMItem;
import com.intentia.icp.common.CMItems;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage;

/**
 * Deletes a Drawing item on DAF.
 *
 */
public class DafDeleteDrawingStage extends AbstractDafSearchStage {
	private static final Logger LOG = Logger.getLogger(DafDeleteDrawingStage.class);
	
	private DafDrawingRequestSaxHandler handler = null;	
	
	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getQuery(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	public String getQuery(PipelineContext context) throws ParametersException, ParserConfigurationException, SAXException, Exception {
		XMLRequest request = (XMLRequest)context.getRequest();
		try {
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser parser = factory.newSAXParser();
			
			this.handler = new DafDrawingRequestSaxHandler();
	        String xml = request.getRequestString();
	        LOG.debug("Parsing request:\n" + xml);
	        parser.parse(new InputSource(new StringReader(xml)), handler);
	        
	        // search using @ITEMID
	        if (this.handler.getKey() != null) {
	        	return DafDrawingConstants.TABLE + "[" + DafDrawingConstants.COLUMN_ITEMID + " = \"" + this.handler.getKey() + "\"]";	
	        }
		}
		catch (Exception e) {
			throw e;
		}
		
		return null;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getResultSize()
	 */
	@Override
	public int getResultSize() {
		return 0;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getStartIndex()
	 */
	@Override
	public int getStartIndex() {
		return 0;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#processResult(com.intentia.icp.common.CMItems, int[])
	 */
	@Override
	public XMLResultset processResult(CMItems resultItems, int[] dafStatus) throws CMException, ParametersException {
		XMLResultset resultset = getEmptyResultSet();
		if (resultItems != null) {			
			for (int i = 0; i < resultItems.size(); i++) {
				CMItem item = resultItems.get(i);
				if (item.isCheckedOut() == true) {
					// if item is checked-out, it cannot be deleted
					LOG.debug("Cannot delete item is checked out=" + item.getId());
				}
				else {
					// delete item
					LOG.debug("Deleting item=" + item.getId());
					item.delete(this.connection);					
				}
			}
		}
		
		return resultset;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#setOutputParameters(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public void setOutputParameters(PipelineContext context) throws PipelineRuntimeException {
		// intentionally blank		
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafStage#getAttributeToDafDatabaseField(java.lang.String)
	 */
	@Override
	public String getAttributeToDafDatabaseField(String attribute) {
		return null;
	}
}
