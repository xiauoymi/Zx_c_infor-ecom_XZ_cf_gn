package com.intentia.iec.pipeline.runtime.stage.custom;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.log4j.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;

/**
 * This class calls the provider of the XML data that contains the logo information.
 * It will parse the XML data and create an object that the eSales presentation can use.
 *
 */
public abstract class RetrieveLogoXmlStage implements PipelineStage {
	
	private static final Logger LOG = Logger.getLogger(RetrieveLogoXmlStage.class);
	
	/**
	 * The ID of the parameter that will contain the questions and answers object.
	 */
	private static final String PARAMETER_MAP = "LogoQAndA";
	
	/**
	 * This method should return the XML data that contains the questions and answers.
	 * @param context
	 * @return
	 */
	public abstract String getLogoXml(PipelineContext context);

	/**
	 * This method should return that XML tag that will contain the questions and answers.
	 * @return
	 */
	public abstract String getQuestionAndAnswerContainer();

	/**
	 * This method should return the XML tag that will contain the question.
	 * @return
	 */
	public abstract String getQuestionTag();

	/**
	 * This method should return the XML tag that will contain the answer.
	 * @return
	 */
	public abstract String getAnswerTag();

	/**
	 * This method should return the XML tag that will contain the unit.
	 * @return
	 */
	public abstract String getUnitTag();
	
	/**
	 * Parses the XML returned by the provider. Creates a java.util.Map object
	 * that contains the questions and answers.
	 *
	 */
	private class LogoXmlFileHandler extends DefaultHandler {
		
		private String container = null;
		private String questionTag = null;
		private String answerTag = null;
		private String unitTag = null;
		
		private String currentQuestion = null;
		private String currentAnswer = null;
		private String currentUnit = null;
		
		private boolean inContainer = false;
		private boolean inQuestion = false;
		private boolean inAnswer = false;
		private boolean inUnit = false;
		
		private Map<String, List<String>> questionsAndAnswers = new HashMap<String, List<String>>();
		
		private LogoXmlFileHandler(String container, String questionTag, String answerTag, String unitTag) {
			this.container = container;
			this.questionTag = questionTag;
			this.answerTag = answerTag;
			this.unitTag = unitTag;
		}
		
		public void startElement(final String uri, final String localName, final String qName, final Attributes attributes) throws SAXException {
			// check if inside the container tag
			if (this.container.equals(qName) == true) {
				this.inContainer = true;
				
				// try to get attributes, if present
				this.currentQuestion = attributes.getValue(this.questionTag);
				this.currentAnswer = attributes.getValue(this.answerTag);
				
				if (this.unitTag != null) {
					this.currentUnit = attributes.getValue(this.unitTag);
				}
				
				// try to add to map
				addToMap();
			}
			
			// if inside the container and tag is found, set the boolean flag to indicate that a match was found
			if (this.inContainer == true && this.questionTag.equals(qName) == true) {			
				this.inQuestion = true;
			}
			else if (this.inContainer == true && this.answerTag.equals(qName) == true) {			
				this.inAnswer = true;
			}
			else if (this.unitTag != null && this.inContainer == true && this.unitTag.equals(qName) == true) {			
				this.inUnit = true;
			}
		}
		
		public void endElement(final String uri, final String localName, final String qName) throws SAXException {
			// reset values
			if (this.container.equals(qName) == true) {
				this.inContainer = false;
				
				this.inQuestion = false;
				this.inAnswer = false;
				this.inUnit = false;

				this.currentQuestion = null;
				this.currentAnswer = null;
				this.currentUnit = null;
			}
			
			if (this.inContainer == true && this.questionTag.equals(qName) == true) {			
				this.inQuestion = false;				
			}
			else if (this.inContainer == true && this.answerTag.equals(qName) == true) {			
				this.inAnswer = false;
			}
			else if (this.unitTag != null && this.inContainer == true && this.unitTag.equals(qName) == true) {			
				this.inUnit = false;
			}
		}
		
		public void characters(char[] ch, int start, int length) {
			// if nodetext was used, convert the character array to string and store
			if (this.inQuestion == true) {
				this.currentQuestion = new String(ch, start, length);
				addToMap();
			}
			else if (this.inAnswer == true) {
				this.currentAnswer = new String(ch, start, length);
				addToMap();
			}
			else if (this.inUnit == true) {
				this.currentUnit = new String(ch, start, length);
				addToMap();
			}
		}	
		
		private Map<String, List<String>> getParsedMap() {
			return this.questionsAndAnswers;
		}
		
		private void addToMap() {
			// question and answer will only be added if both are present.
			// unit is optional
			if (this.currentQuestion != null && this.currentAnswer != null) {
				LOG.debug("Adding Q= "+this.currentQuestion + " A= " + this.currentAnswer + " U= " + this.currentUnit);
				
				List<String> list = this.questionsAndAnswers.get(this.currentQuestion);
				
				if (list == null) {
					list = new ArrayList<String>();
					list.add(this.currentAnswer);
				}
				
				// if unit was provided, add to list
				if (this.currentUnit != null && list.size() == 1) {
					list.add(this.currentUnit);
				}
				
				// add to Map
				this.questionsAndAnswers.put(this.currentQuestion, list);
			}
		}
	}	
	
	/**
	 * Converts the XML (String) to a java.util.Map
	 * @param logoXml
	 * @return
	 * @throws SAXException
	 * @throws IOException
	 * @throws ParserConfigurationException
	 */
	private Map<String, List<String>> convertToMap(String logoXml) throws SAXException, IOException, ParserConfigurationException {
		if (logoXml != null) {
			String container = getQuestionAndAnswerContainer();
			String questionTag = getQuestionTag();
			String answerTag = getAnswerTag();
			String unitTag = getUnitTag();
			
			if (container != null && questionTag != null && answerTag != null) {
				LogoXmlFileHandler handler = new LogoXmlFileHandler(container, questionTag, answerTag, unitTag);				
				getParser().parse(new ByteArrayInputStream(logoXml.getBytes("UTF-8")), handler);
				
				return handler.getParsedMap();
			}
		}
		
		return null;
	}
	
	private SAXParserFactory parserFactory;
	
	private SAXParser getParser() throws ParserConfigurationException,
			SAXException {
		if (this.parserFactory == null) {
			this.parserFactory = SAXParserFactory.newInstance();
		}
		return this.parserFactory.newSAXParser();
	}	


	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.PipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	public void execute(PipelineContext context) throws PipelineRuntimeException {
		LOG.debug("Executing RetrieveLogoXmlStage");
		try {
			// call XML data provider
			String logoXml = getLogoXml(context);				
			LOG.debug("XML from provider retrieved = " + logoXml);
			
			// if XML data was provided, convert to java.util.Map
			if (logoXml != null) {
				Map<String, List<String>> map = convertToMap(logoXml);
				
				// if no response object is present, create a dummy resultset.
				if (context.getResponse() == null) {
			        context.setResponse(new XMLResultset("<?xml version='1.0' encoding='UTF-8'?>"));			        
				}	
				
				// set the Map object to the resultset 
				setQuestionsAndAnswers(context, map);
			}
		}
		catch (Exception e) {
			LOG.error(e);
			throw new PipelineRuntimeException(e);
		}
	}
	
	/**
	 * Stores the questions and answers Map to the resultset.
	 * @param context
	 * @param map
	 * @throws PipelineRuntimeException
	 * @throws ParametersException
	 */
	private void setQuestionsAndAnswers(PipelineContext context, Map<String, List<String>> map) throws PipelineRuntimeException, ParametersException {
		if (context != null && map != null) {
			LOG.debug("Setting questions and answers to output parameter.");
			((XMLResultset)context.getResponse()).getParameters().set(PARAMETER_MAP, map);	
		}
	}
}
