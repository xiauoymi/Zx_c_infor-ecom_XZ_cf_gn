package com.intentia.iec.pipeline.runtime.stage.custom.ia;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.ia.dao.IaDao;
import com.intentia.iec.pipeline.runtime.integration.ia.dao.impl.IaDaoRestImpl;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaConnectionException;
import com.intentia.iec.pipeline.runtime.integration.ia.exception.IaRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.ia.model.IaCampaign;
import com.intentia.iec.pipeline.runtime.integration.ia.model.IaPromotion;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;

public class DeletePromotionFromIaStage extends AbstractPipelineStage {

	private static final Logger log = Logger
			.getLogger(DeletePromotionFromIaStage.class);

	private IaDao dao = null;
	
	public DeletePromotionFromIaStage(){
		
	}
	
	@Override
	public void execute(PipelineContext context) throws PipelineRuntimeException {
		log.debug("Start DeletePromotionFromIaStage . . .");
		
		CustomStagesHelper.extractRequestParameters(CustomStagesHelper
				.getRequest(context));

		XMLRequest request = (XMLRequest) context.getRequest();
		XMLResultset response = (XMLResultset) context.getResponse();
		
		try {
			Document reqDoc = request.getRequestDoc();
			if (reqDoc != null) {
				Element dSubNode = (Element) XPathAPI.selectSingleNode(reqDoc,
						"/request/delete/dsubsets");
				if (dSubNode != null) {
					log.debug("XMLRequest is a subset delete. Exiting DeletePromotionFromIaStage.execute()...");
					return;
				}
			}
			
		boolean hasError = false;

			dao = new IaDaoRestImpl();
			IaPromotion promotion = new IaPromotion();
		
			boolean bval = response.isEmpty();
			
			if( !bval )
			{
				String id = response.getString("PromotionID");
				promotion.setId(id);
	
				try {
					dao.deletePromotion(promotion);
				} catch (IaRuntimeException e) {
					log.error("Error while deleting promotion : " + promotion, e);
				}
	
				log.debug("DeletePromotionFromIaStage has error:" + hasError);
			}
			else
			{
				log.debug("No Promotion Id is specified, existing from DeletePromotionFromIaStage ...");
			}
		} catch (IaConnectionException e) {
			log.debug(
					"Error while deleting promotion from IA.");
		} catch (ResultsetException e) {
			log.debug(
					"Error while deleting promotion from IA.");
		} catch (RequestException e) {
			log.debug(
					"Error while deleting promotion from IA.");
		} catch (TransformerException e) {
			log.debug(
					"Error while deleting promotion from IA.");
		} 	
	}

}
