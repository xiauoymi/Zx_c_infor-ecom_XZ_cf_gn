package com.intentia.iec.pipeline.runtime.stage.custom.daf.drawing;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.intentia.icp.common.CMCollection;
import com.intentia.icp.common.CMCollections;
import com.intentia.icp.common.CMException;
import com.intentia.icp.common.CMItem;
import com.intentia.icp.common.CMItems;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage;

/**
 * Sets the Has Drawing attribute of equipment displayed in the Equipment List.
 *
 */
public class MarkHasDrawingEquipmentStage extends AbstractDafSearchStage {
	private static final Logger LOG = Logger.getLogger(MarkHasDrawingEquipmentStage.class);
	
	private static final String MAINSET_ITEMS = "resultset/row";
	
	private static final String ITEM_ID = "ItemID";
	
	private static final String SERIAL_NUMBER = "SerialNumber";
	
	private static final String HAS_DRAWING = "HasDrawing";
	
	/**
	 * Query to search for all Drawings of all equipment displayed in the Equipment List page
	 */
	private static final String SELECT_EQUIPMENT = DafDrawingConstants.TABLE + "[" + DafDrawingConstants.COLUMN_SERIAL_NUMBER + " IN (";
	
	/**
	 * Must have hot spots and unsorted.
	 * This is different from DafSearchDrawingDetailsCCStage.WITH_HOTSPOTS
	 * Must have no serial number.
	 */
	private static final String WITH_HOTSPOTS = ") AND " + DafDrawingConstants.COLUMN_NAME + " IS NOT NULL AND " + DafDrawingConstants.COLUMN_DRAWING_NUMBER + " IS NOT NULL AND ESA_DrawingHotspots/@ESA_SerialNumber!=\"\" AND ESA_DrawingHotspots/@ESA_Coordinates IS NOT NULL AND ESA_DrawingHotspots/@ESA_ShapeCode IS NOT NULL AND ESA_DrawingHotspots/@ESA_ItemNumber IS NOT NULL AND " + DafDrawingConstants.COLUMN_STATUS + " = " + DafDrawingConstants.DAFStatusCodes.APPROVED + "]";
	
	private XMLResultset resultset = null;
	
	private static final String PARENTITEMNUMBER = "ParentItemNumber";
	
	private static final String PARENTSERIALNUMBER = "ParentSerialNumber";
	
	private static final String CHILDITEMNUMBER = "ChildItemNumber";
	
	private static final String CHILDSERIALNUMBER = "ChildSerialNumber";
	
	/**
	 * SQL statement that retrieves the as-built structure values from e-Sales database.
	 */
	private static final String SQL = 
		"select distinct p.itemNumber as ParentItemNumber, parent.serialNumber as ParentSerialNumber, c.itemNumber as ChildItemNumber, child.serialNumber as ChildSerialNumber " +
		"from AsBuiltStructure asb " +
		"inner join Equipment parent on asb.parentEquipmentId=parent.id " +
		"inner join Item p on parent.itemId=p.id " +
		"inner join Equipment child on asb.childEquipmentId=child.id " +
		"inner join Item c on child.itemId=c.id ";

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getQuery(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public String getQuery(PipelineContext context) throws ParametersException, ParserConfigurationException, SAXException, Exception {
		
		// skip stage if Image Mapper property = false?
		if (Boolean.valueOf(CustomStagesHelper.getKeyValue("Application.Image Mapper")).booleanValue() == false) {
			return null;
		}		
		
		if (context.getResponse() instanceof XMLResultset) {
			// get all serial numbers in the Equipment List page
			Set<Equipment> set = getEquipmentListSerialNumbers(context);
			
			if (set.isEmpty() == false) {
				// get query string for all Item Numbers 
				return getXQuery(set);
			}
		}
		return null;
	}
	
	/**
	 * Returns a Set containing all equipment displayed in the page
	 * @param context
	 * @return
	 * @throws ResultsetException
	 * @throws TransformerException
	 */
	private Set<Equipment> getEquipmentListSerialNumbers(PipelineContext context) throws ResultsetException, TransformerException {
		Set<Equipment> equipment = new HashSet<Equipment>();
		this.resultset = (XMLResultset) context.getResponse();
		this.resultset.moveFirst();
		
		Document xmlDoc = this.resultset.getDocument();
		NodeList nodeList = XPathAPI.selectNodeList(xmlDoc, MAINSET_ITEMS);
		
		// iterate through the main set
		for (int i = 0; i < nodeList.getLength(); i++) {
			Element e = (Element) nodeList.item(i);
			if (e.getAttribute(ITEM_ID) != null && !"".equals(e.getAttribute(ITEM_ID)) 
					&& e.getAttribute(SERIAL_NUMBER) != null && !"".equals(e.getAttribute(SERIAL_NUMBER))) {
				// add equipment to the Set
				Equipment x = new Equipment(e.getAttribute(ITEM_ID), e.getAttribute(SERIAL_NUMBER));				
				equipment.add(x);
			}
		}		
		
		return equipment;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getResultSize()
	 */
	@Override
	public int getResultSize() {
		return 0;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#getStartIndex()
	 */
	@Override
	public int getStartIndex() {
		return 0;
	}
	
	/**
	 * Returns all valid as-built structure in the e-Sales database.
	 * @return
	 */
	private Map<Equipment, Set<Equipment>> getAsBuiltStructure() {
		Map<Equipment, Set<Equipment>> ret = new HashMap<Equipment, Set<Equipment>>();
		
		Connection conn = null; 
		PreparedStatement stmt = null;
		try {
			conn = (Connection) CustomStagesHelper.getConnection("esales.cursor");
			stmt = conn.prepareStatement(SQL);			
			
			LOG.debug("Executing SQL statement=" + SQL);

			long startTime = System.currentTimeMillis();
			ResultSet sqlResultSet = stmt.executeQuery();
			long stopTime = System.currentTimeMillis();
			LOG.debug("Total execution time: " + (stopTime - startTime) + " ms");			

			if (sqlResultSet != null) {
				while (sqlResultSet.next() == true) {
					// get parent, child
					String parentItemNumber = sqlResultSet.getString(PARENTITEMNUMBER);
					String parentSerialNumber = sqlResultSet.getString(PARENTSERIALNUMBER);
					String childItemNumber = sqlResultSet.getString(CHILDITEMNUMBER);
					String childSerialNumber = sqlResultSet.getString(CHILDSERIALNUMBER);

					// store product-child in Map
					if (parentItemNumber != null && parentSerialNumber != null && 
							childItemNumber != null && childSerialNumber != null) {
						
						Equipment parent = new Equipment(parentItemNumber, parentSerialNumber);
						
						
						if (ret.get(parent) == null) {
							ret.put(parent, new HashSet<Equipment>());
						}
						
						Equipment child = new Equipment(childItemNumber, childSerialNumber);
						
						// add child to parent
						Set<Equipment> parentSet = ret.get(parent);
						parentSet.add(child);
					}
				}
			}
			
		} catch (PipelineRuntimeException e) {
			LOG.error(e);
		} catch (SQLException e) {
			LOG.error(e);
		}
		finally {
			LOG.debug("Closing statement object.");
			if (stmt != null) {
				try {
					stmt.close();
				}
				catch (SQLException e) {
					LOG.error(e);
				}
				stmt = null;
			}
			
			LOG.debug("Closing connection object.");
			if (conn != null) {
				try {
					conn.close();
				}
				catch (SQLException e) {
					LOG.error(e);
				}
				conn = null;
			}
		}
		
		LOG.debug("Number of as-built structure=" + ret.size());
		return ret;
	}
	
	/**
	 * Returns a Set of Serial Numbers with valid Drawings
	 * @param resultItems from DAF
	 * @param asBuiltStructure from e-Sales database
	 * @return
	 */
	private Set<Equipment> getEquipmentWithValidDrawings(CMItems resultItems, Map<Equipment, Set<Equipment>> asBuiltStructure) {
		Set<Equipment> ret = new HashSet<Equipment>();
		
		if (resultItems != null && resultItems.size() > 0 && asBuiltStructure != null && asBuiltStructure.size() > 0) {
			for (int i = 0; i < resultItems.size(); i++) {
				CMItem item = resultItems.get(i);
				CMCollections collections = item.getCollections(DafDrawingConstants.ATTRIBUTE_HOTSPOTS);
				
				// check if there is a valid hot spot in the drawing
				if (collections != null && collections.size() > 0) {
					String itemNumber = (String) item.getAttributeValue(DafDrawingConstants.ATTRIBUTE_ITEM_NUMBER);
					String serialNumber = (String) item.getAttributeValue(DafDrawingConstants.ATTRIBUTE_SERIAL_NUMBER);
					Equipment parentEquipment = new Equipment(itemNumber, serialNumber);
					
					Iterator<?> it = collections.iterator();

					while (it.hasNext() == true) {
						CMCollection collection = (CMCollection) it.next();
						// check if valid hot spot
						boolean valid = DafDrawingUtils.isValidHotSpot(collection);

						if (valid == true) {
							// check if any hot spot serial number is in the asbuilt structure
							String hotspotItemNumber = (String) collection.getAttributeValue(DafDrawingConstants.ATTRIBUTE_ITEM_NUMBER);
							String hotspotSerialNumber = (String) collection.getAttributeValue(DafDrawingConstants.ATTRIBUTE_SERIAL_NUMBER);
							
							Equipment hotspotEquipment = new Equipment(hotspotItemNumber, hotspotSerialNumber);
							
							Set<Equipment> children = asBuiltStructure.get(parentEquipment);

							if (children != null && children.contains(hotspotEquipment) == true) {	
								// add to Set
								ret.add(parentEquipment);
								break;
							}
						}
					}
				}
			}
		}
		
		LOG.debug("Equipment with valid drawings in this page=" + ret.size());
		return ret;
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#processResult(com.intentia.icp.common.CMItems, int[])
	 */
	@Override
	public XMLResultset processResult(CMItems resultItems, int[] dafStatus) throws CMException, ParametersException {
		if (resultItems != null && resultItems.size() > 0) {
			LOG.debug("Drawings found=" + resultItems.size());
			
			// get as-built structure in e-Sales
			Map<Equipment, Set<Equipment>> asbuiltStructure = getAsBuiltStructure();
			
			// get equipment with valid Drawings from DAF
			Set<Equipment> equipment = getEquipmentWithValidDrawings(resultItems, asbuiltStructure);
			
			try {				
				markDrawing(equipment);
			}
			catch (Exception e) {
				LOG.error(e);
			}
		}
		return null;
	}
	
	/**
	 * Sets the Has Drawing attribute on the XMLResultset.
	 * @param itemNumbers
	 * @throws ResultsetException
	 * @throws TransformerException
	 */
	private void markDrawing(Set<Equipment> equipment) throws ResultsetException, TransformerException {
		if (this.resultset != null && equipment != null && equipment.isEmpty() == false) {
			Document xmlDoc = this.resultset.getDocument();
			NodeList nodeList = XPathAPI.selectNodeList(xmlDoc, MAINSET_ITEMS);

			// iterate through the main set
			for (int i = 0; i < nodeList.getLength(); i++) {
				Element e = (Element) nodeList.item(i);
				
				// check if ItemID attribute exists
				if (e.getAttribute(ITEM_ID) != null && !"".equals(e.getAttribute(ITEM_ID))
						&& e.getAttribute(SERIAL_NUMBER) != null && !"".equals(e.getAttribute(SERIAL_NUMBER))) {
					
					// check if equipment is in Set of valid Drawings 
					
					Equipment check = new Equipment(e.getAttribute(ITEM_ID), e.getAttribute(SERIAL_NUMBER));
					
					if (equipment.contains(check) == true) {
						e.setAttribute(HAS_DRAWING, DafDrawingConstants.YES);
					}
					else {
						e.setAttribute(HAS_DRAWING, DafDrawingConstants.NO);
					}
				}
			}
		}
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafSearchStage#setOutputParameters(com.intentia.iec.pipeline.runtime.PipelineContext)
	 */
	@Override
	public void setOutputParameters(PipelineContext context) throws PipelineRuntimeException {
		// intentionally blank
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafStage#getEmptyResultSet()
	 */
	@Override
	public XMLResultset getEmptyResultSet() {
		return null; 
	}

	/* (non-Javadoc)
	 * @see com.intentia.iec.pipeline.runtime.stage.custom.daf.AbstractDafStage#getAttributeToDafDatabaseField(java.lang.String)
	 */
	@Override
	public String getAttributeToDafDatabaseField(String attribute) {
		return null;
	}
	
	/**
	 * Returns query string to get Drawings of equipment displayed in the page
	 * @param set
	 * @return
	 */
	private String getXQuery(Set<Equipment> set) {
		StringBuffer buf = new StringBuffer(SELECT_EQUIPMENT);		
		boolean first = true;
		
		if (set != null) {
			Iterator<Equipment> it = set.iterator();
			while (it.hasNext() == true) {
				Equipment equipment = it.next();
				if (first == false) {
					buf.append(",");
				}
				buf.append("\"" + encodeXML(equipment.getSerialNumber()) + "\"");
				first = false;
			}
			buf.append(WITH_HOTSPOTS);
		}
		
		return buf.toString();
	}
}
