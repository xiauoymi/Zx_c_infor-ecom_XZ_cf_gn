package com.intentia.iec.pipeline.runtime.integration.erp.model;

import java.util.List;

public class OrderLinePriceRequest {

	private String tenantId;

	private String accountingEntityId;

	private String customerPartyId;

	private String orderType;

	private String currencyId;

	private String userName;
	
	private String facility;
	

	public String getFacility() {
		return facility;
	}

	public void setFacility(String facility) {
		this.facility = facility;
	}

	private List<LinePrice> orderlines;

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public String getAccountingEntityId() {
		return accountingEntityId;
	}

	public void setAccountingEntityId(String accountingEntityId) {
		this.accountingEntityId = accountingEntityId;
	}

	public String getCustomerPartyId() {
		return customerPartyId;
	}

	public void setCustomerPartyId(String customerPartyId) {
		this.customerPartyId = customerPartyId;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public String getCurrencyId() {
		return currencyId;
	}

	public void setCurrencyId(String currencyId) {
		this.currencyId = currencyId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public List<LinePrice> getOrderlines() {
		return orderlines;
	}

	public void setOrderlines(List<LinePrice> orderlines) {
		this.orderlines = orderlines;
	}

}
