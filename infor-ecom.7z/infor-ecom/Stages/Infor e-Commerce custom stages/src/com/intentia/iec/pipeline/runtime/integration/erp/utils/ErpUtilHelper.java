package com.intentia.iec.pipeline.runtime.integration.erp.utils;

import java.math.BigDecimal;
import java.net.URL;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.ibm.icu.text.NumberFormat;
import com.infor.iec.ion.webservice.itemprice.CatalogPriceRequestParams;
import com.infor.iec.ion.webservice.itemprice.InputCatalogItems;
import com.infor.iec.ion.webservice.itemprice.LinePriceRequestParams;
import com.infor.iec.ion.webservice.itemprice.InputOrderLines;
import com.infor.iec.ion.webservice.itemprice.LinePriceResponseParams;
import com.infor.iec.ion.webservice.itemprice.OutputOrderLines;
import com.infor.iec.ion.webservice.ordertotal.OrderTotalRequestParams;
import com.infor.iec.ion.webservice.ordertotal.OrderLines;
import com.infor.iec.ion.webservice.ordertotal.OrderTotalResponseParams;
import com.infor.iec.ion.webservice.ordertotal.DistributedCharges;
import com.infor.iec.ion.webservice.ordertotal.DistributedTaxes;
import com.infor.iec.ion.webservice.atp.OrderPromiseResponseParams;
import com.infor.iec.ion.webservice.itemprice.CatalogPriceResponseParams;
import com.infor.iec.ion.webservice.itemprice.OutputCatalogItems;
import com.infor.iec.ion.webservice.atp.ATPInfo;
import com.infor.iec.ion.webservice.atp.OrderPromiseRequestParams;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.integration.erp.model.LinePrice;
import com.intentia.iec.pipeline.runtime.stage.custom.ConstantsForSales;
import com.intentia.iec.pipeline.runtime.stage.custom.CustomStagesHelper;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.util.FastStringBuffer;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Service;
import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.PortInfo;

public class ErpUtilHelper {
	
	private static final Logger LOG = Logger.getLogger(ErpUtilHelper.class);
	
	
	public static String getItemUnit(String item) {
		String unit = null;
		
		// Retrieving Item UnitofMeasure in Item table.
		try {
			SearchPipelineExecuter spe = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "Item",	"GetSimple");
			spe.setBinding("ItemID", item, "eq");
			XMLResultset speResult = spe.execute();
			speResult.beforeFirst();
			speResult.moveNext();
			unit = speResult.getString("UnitCode");
		} catch (Exception e) {
			LOG.debug("Error Executing SearchPipelineExecuterStage For WebServiceUSerID in ApplicationData!", e);
		}
		return unit;
	}
	
	
	public static Map<String,String> getVirtualEnterprise() {
		HashMap<String, String> virtualMap = new HashMap<String, String>();
		// Retrieving VirtualEnterprise.
		try {
			SearchPipelineExecuter spe = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "MvxVirtualEnterprise",	"List");
			XMLResultset speResult = spe.execute();
			speResult.beforeFirst();
			speResult.moveNext();
			virtualMap.put("Facility", speResult.getString("AccountingEntity"));
			virtualMap.put("Warehouse", speResult.getString("Warehouse"));
			virtualMap.put("TenantId", speResult.getString("TenantId"));
		} catch (Exception e) {
			LOG.debug("Error Executing SearchPipelineExecuterStage For WebServiceUSerID in ApplicationData!", e);
		}
		return virtualMap;
	}
	
	public static HashMap<String, Double> getExistingOrdersTotals(String orderID) {
		HashMap<String, Double> totalMap = new HashMap<String, Double>();
		
		// Retrieving Existing Order's totals in OrderHeader table.
		try {
			SearchPipelineExecuter spe = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "CurrentOrder",
					"GetExistingOrder");

			spe.setBinding(ConstantsForSales.ORDERID, orderID, "eq");
			XMLResultset res = spe.execute();

				res.beforeFirst();
				res.moveNext();
				Document resDoc = res.getDocument();

				// Get OrderLine node in the response document
				NodeList olineList = XPathAPI.selectNodeList(resDoc, "//row/OrderLine");

				int i = 0;
				int loopLine = olineList.getLength();

				while (loopLine != 0) {
					Node oLineNode = olineList.item(i);
					if (Double.parseDouble(oLineNode.getAttributes().getNamedItem(ConstantsForSales.LINETOTAL).getNodeValue()) > 0.00) {
						String orderGrandTotal = null;
						String orderTotalPrice = null;

						orderGrandTotal = res.getString(ConstantsForSales.GRANDTOTAL);
						orderTotalPrice = res.getString(ConstantsForSales.TOTALPRICE);

						if (!orderGrandTotal.equals(null) && !orderTotalPrice.equals(null)) {
							totalMap.put("GrandTotal", Double.parseDouble(res.getString(ConstantsForSales.GRANDTOTAL)));
							totalMap.put("TotalPrice", Double.parseDouble(res.getString(ConstantsForSales.TOTALPRICE)));
							totalMap.put("TotalDiscount",Double.parseDouble(res.getString(ConstantsForSales.TOTALDISCOUNT)));
						}

					}
					loopLine--;
				}

		} catch (Exception e) {
			LOG.debug("Error Executing GetExistingOrder SearchPipelineExecuter!", e);
		}

		return totalMap;
	}
	
	public static List<LinePrice> getExistingOrderLines(String orderID, String warehouseId){
		LOG.debug("Inside ErpUtilHelper getExistingOrderLines");
		List<LinePrice> orderLines= new ArrayList<LinePrice>();
		String shippingAddressId;
		// Retrieving Existing Order's totals in OrderHeader table.
		try {
			SearchPipelineExecuter pipeline =
					new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "CurrentOrder", "GetExistingOrder");
			pipeline.setBinding(ConstantsForSales.ORDERID, orderID, "eq");

			try {
				XMLResultset existingOrder = pipeline.execute();
				
				if (existingOrder != null && !existingOrder.isEmpty()) {
					existingOrder.moveFirst();
					shippingAddressId=existingOrder.getString("MvxShippingAddressID");
					XMLIterator currentOrderLines = (XMLIterator) existingOrder.getResultset(ConstantsForSales.ORDERLINE);
	                if (currentOrderLines != null && !currentOrderLines.isEmpty()) {
	                    currentOrderLines.beforeFirst();
						while (currentOrderLines.moveNext()) {
							LinePrice orderline = new LinePrice();
							orderline.setItemId(currentOrderLines.getString(ConstantsForSales.ITEM_ID));
							orderline.setQuantity(Double.parseDouble(currentOrderLines.getString(ConstantsForSales.QUANTITY)));
							orderline.setUnitCode(ErpUtilHelper.getItemUnit(currentOrderLines.getString(ConstantsForSales.ITEM_ID)));
							orderline.setWarehouseId(warehouseId);				
							orderline.setConfigurationNumber(currentOrderLines.getString("ConfigurationID"));
							if(CustomStagesHelper.getKeyValue("ION.Webservice ShippingAddressID").equals("true")){
								orderline.setShippingAddressId(currentOrderLines.getString("MvxShippingAddressID")==null?shippingAddressId:currentOrderLines.getString("MvxShippingAddressID"));
							}
							orderLines.add(orderline);	
						}
					}
				}
				
			} catch (PipelineRuntimeException e) {
				e.printStackTrace();
			} catch (ResultsetException e) {
				e.printStackTrace();
			}
			
		} catch (Exception e) {
			LOG.debug("Error Executing GetExistingOrder SearchPipelineExecuter!", e);
		}
		
		return orderLines;
	}
	
	public static List<LinePrice> getExistingOrderLines(String orderID, String warehouseId,String ShippingAddressID){
		LOG.debug("Inside ErpUtilHelper getExistingOrderLines");
		List<LinePrice> orderLines= new ArrayList<LinePrice>();
		String shippingAddressId;
		// Retrieving Existing Order's totals in OrderHeader table.
		try {
			SearchPipelineExecuter pipeline =
					new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "CurrentOrder", "GetExistingOrder");
			pipeline.setBinding(ConstantsForSales.ORDERID, orderID, "eq");

			try {
				XMLResultset existingOrder = pipeline.execute();
				
				if (existingOrder != null && !existingOrder.isEmpty()) {
					existingOrder.moveFirst();
					shippingAddressId=existingOrder.getString("MvxShippingAddressID");
					if(shippingAddressId==null || shippingAddressId.equals("")){
						shippingAddressId=ShippingAddressID;
					}
					XMLIterator currentOrderLines = (XMLIterator) existingOrder.getResultset(ConstantsForSales.ORDERLINE);
	                if (currentOrderLines != null && !currentOrderLines.isEmpty()) {
	                    currentOrderLines.beforeFirst();
						while (currentOrderLines.moveNext()) {
							LinePrice orderline = new LinePrice();
							orderline.setItemId(currentOrderLines.getString(ConstantsForSales.ITEM_ID));
							orderline.setQuantity(Double.parseDouble(currentOrderLines.getString(ConstantsForSales.QUANTITY)));
							orderline.setUnitCode(ErpUtilHelper.getItemUnit(currentOrderLines.getString(ConstantsForSales.ITEM_ID)));
							orderline.setWarehouseId(warehouseId);				
							orderline.setConfigurationNumber(currentOrderLines.getString("ConfigurationID"));
							if(CustomStagesHelper.getKeyValue("ION.Webservice ShippingAddressID").equals("true")){
								orderline.setShippingAddressId(currentOrderLines.getString("MvxShippingAddressID")==null?shippingAddressId:currentOrderLines.getString("MvxShippingAddressID"));
							}
							orderLines.add(orderline);	
						}
					}
				}
				
			} catch (PipelineRuntimeException e) {
				e.printStackTrace();
			} catch (ResultsetException e) {
				e.printStackTrace();
			}
			
		} catch (Exception e) {
			LOG.debug("Error Executing GetExistingOrder SearchPipelineExecuter!", e);
		}
		
		return orderLines;
	}
	
	public static String getWSRegisteredUser(String wsUserID) {
		String userID = "";
		// Retrieving WSLoggedIn User in ApplicationData table.
		try {
			SearchPipelineExecuter spe = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE, "ApplicationData","Details");
			spe.setParam("param", wsUserID);
			XMLResultset speResult = spe.execute();
			speResult.beforeFirst();
			speResult.moveNext();
			userID = speResult.getString("ParameterValue");
		} catch (Exception e) {
			LOG.debug("Error Executing SearchPipelineExecuterStage For WebServiceUSerID in ApplicationData!", e);
		}
		return userID;
	}
	
	/*
	 * Converts java.util.Date to javax.xml.datatype.XMLGregorianCalendar
	 */
	public static XMLGregorianCalendar toXMLGregorianCalendar(Date date){
		XMLGregorianCalendar xmlCalendar = null;
		try {
			GregorianCalendar gCalendar = new GregorianCalendar();
			gCalendar.setTime(date);
			xmlCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gCalendar);
		} catch (DatatypeConfigurationException e) {
			LOG.error(e.toString());
		}
		return xmlCalendar;
	}

	/*
	 * Converts XMLGregorianCalendar to java.util.Date in Java
	 */
	public static Date toDate(XMLGregorianCalendar calendar){
		if(calendar == null) {
			return null;
		}
		return calendar.toGregorianCalendar().getTime();
	}
	
	public static BigDecimal stringToDecimal(String value) throws ParseException {
		NumberFormat nf = NumberFormat.getNumberInstance();
		//Number n = nf.parse(value);
		Number n = nf.parse(nf.format(new Double(value)));
		if (n instanceof com.ibm.icu.math.BigDecimal) {
			return new BigDecimal(((com.ibm.icu.math.BigDecimal) n).toString());
		} else if (n instanceof BigDecimal) {
			return (BigDecimal) n;
		} else if (n instanceof Long) {
			return new BigDecimal(n.toString());
		} else {
			FastStringBuffer error = new FastStringBuffer();
			error.append("Could not parse as decimal: ");
			error.append(value);
			error.append(". Parser returned unknown decimal type: ");
			error.append(n.getClass());
			throw new ParseException(error.toString(), 0);
		}
	}
	

	public static void debugInOrderLinePrice(LinePriceRequestParams wsRequest){
		LOG.debug("OrderLinePrice.AccountingEntityid = "+wsRequest.getAccountingEntityID());
		LOG.debug("OrderLinePrice.TenantId = "+wsRequest.getTenantID());
		LOG.debug("OrderLinePrice.CurrencyId = "+wsRequest.getCurrencyID());
		LOG.debug("OrderLinePrice.CustomerPartyId = "+wsRequest.getCustomerPartyID());
		LOG.debug("OrderLinePrice.OrderTypeCode = "+wsRequest.getOrderTypeCode());
		LOG.debug("OrderLinePrice.UserName = "+wsRequest.getUserName());
		
		for(InputOrderLines line : wsRequest.getArrayOfInputOrderLines()) {
			LOG.debug("==========OrderLinePriceRequest========== ");
			LOG.debug("OrderLinePrice.ItemId = "+line.getItemID());
			LOG.debug("OrderLinePrice.CustomerItemId = "+line.getCustomerItemID());
			LOG.debug("OrderLinePrice.Quantity = "+line.getQuantity());
			LOG.debug("OrderLinePrice.Quantity = "+line.getQuantity());
			LOG.debug("OrderLinePrice.UnitCode = "+line.getUnitCode());
			LOG.debug("OrderLinePrice.WarehouseId = "+line.getWarehouseLocationID());
			LOG.debug("OrderLinePrice.ConfigurationID = "+line.getConfigurationID());
			LOG.debug("OrderLinePrice.ShippingAddressID = "+line.getShippingAddressID());
		}
	}
	
	public static void debutOutOrderLinePrice(LinePriceResponseParams wsResponse){
		if (wsResponse != null){
			LOG.debug("OrderLinePriceResponse.ErrorReasonCode = "+wsResponse.getErrorReasonCode());
			LOG.debug("OrderLinePriceResponse.ErrorReasonDescription = "+wsResponse.getErrorReasonDescription());
			for(OutputOrderLines line : wsResponse.getArrayOfOutputOrderLines()) {
				LOG.debug("==========OrderLinePriceResponse========== ");
				LOG.debug("OrderLinePriceResponse.ItemID = "+line.getItemID());
				LOG.debug("OrderLinePriceResponse.CurrencyID = "+line.getCurrencyID());
				LOG.debug("OrderLinePriceResponse.Quantity = "+line.getQuantity());
				LOG.debug("OrderLinePriceResponse.TotalAmount = "+line.getTotalAmount());
				LOG.debug("OrderLinePriceResponse.ExtendedAmount = "+line.getExtendedAmount());
				LOG.debug("OrderLinePriceResponse.UnitCode = "+line.getUnitCode());
				LOG.debug("OrderLinePriceResponse.DistributedChargeAmount = "+line.getDistributedChargeAmount());
				LOG.debug("OrderLinePriceResponse.UnitPriceAmount = "+line.getUnitPriceAmount());
				LOG.debug("OrderLinePriceResponse.WarehouseLocationID = "+line.getWarehouseLocationID());
				LOG.debug("OrderLinePriceResponse.CustomerItemID = "+line.getCustomerItemID());
				
			}
		}else {
			LOG.debug("OrderLinePriceResponse == null");
		}			
			
	}
	
	public static void debugInOrderTotalPrice(OrderTotalRequestParams wsRequest){
		LOG.debug("OrderTotalPriceRequest.AccountingEntityid = "+wsRequest.getAccountingEntityID());
		LOG.debug("OrderTotalPriceRequest.TenantId = "+wsRequest.getTenantID());
		LOG.debug("OrderTotalPriceRequest.CurrencyId = "+wsRequest.getCurrencyID());
		LOG.debug("OrderTotalPriceRequest.CustomerPartyId = "+wsRequest.getCurrencyID());
		LOG.debug("OrderTotalPriceRequest.OrderTypeCode = "+wsRequest.getOrderTypeCode());
		LOG.debug("OrderTotalPriceRequest.UserName = "+wsRequest.getUserName());
		
		for(OrderLines line : wsRequest.getArrayOfOrderLines()) {
			LOG.debug("==========OrderTotalLinePriceRequest========== ");
			LOG.debug("OrderTotalLinePriceRequest.ItemId = "+line.getItemID());
			LOG.debug("OrderTotalLinePriceRequest.CustomerItemId = "+line.getCustomerItemID());
			LOG.debug("OrderTotalLinePriceRequest.Quantity = "+line.getQuantity());
			LOG.debug("OrderTotalLinePriceRequest.UnitCode = "+line.getUnitCode());
			LOG.debug("OrderTotalLinePriceRequest.WarehouseId = "+line.getWarehouseLocationID());
			LOG.debug("OrderTotalLinePriceRequest.ConfigurationID = "+line.getConfigurationID());
			LOG.debug("OrderTotalLinePriceRequest.ShippingAddressId = "+line.getShippingAddressID());	
		}
	}
	
	public static void debutOutOrderTotalPrice(OrderTotalResponseParams wsResponse){
		if (wsResponse != null){
			LOG.debug("OrderTotalPriceResponse.ErrorReasonCode = "+wsResponse.getErrorReasonCode());
			LOG.debug("OrderTotalPriceResponse.ErrorReasonDescription = "+wsResponse.getErrorReasonDescription());
			LOG.debug("OrderTotalPriceResponse.TotalLines = "+wsResponse.getTotalLines());
			LOG.debug("OrderTotalPriceResponse.RoundingOff = "+wsResponse.getRoundingOff());
			LOG.debug("OrderTotalPriceResponse.CurrencyID = "+wsResponse.getCurrencyID());
			LOG.debug("OrderTotalPriceResponse.ExtendedAmount = "+wsResponse.getExtendedAmount());
			LOG.debug("OrderTotalPriceResponse.TotalAmount = "+wsResponse.getTotalAmount());
			
			for(DistributedCharges charge : wsResponse.getArrayOfDistributedCharges()) {
				LOG.debug("==========OrderTotalPriceResponse Charges========== ");
				LOG.debug("OrderTotalPriceResponse.DistributedChargeAmount = "+charge.getDistributedChargeAmount());
				LOG.debug("OrderTotalPriceResponse.DistributedChargeDescription = "+charge.getDistributedChargeDescription());
				LOG.debug("OrderTotalPriceResponse.DescriptionLanguageCode = "+charge.getDescriptionLanguageCode());
			}

			for(DistributedTaxes taxes : wsResponse.getArrayOfDistributedTaxes()) {
				LOG.debug("==========OrderTotalPriceResponse Taxes========== ");
				LOG.debug("OrderTotalPriceResponse.DistributedTaxDescription = "+taxes.getDistributedTaxAmount());
				LOG.debug("OrderTotalPriceResponse.DistributedTaxDescription = "+taxes.getDistributedTaxDescription());
				LOG.debug("OrderTotalPriceResponse.DescriptionLanguageCod = "+taxes.getDescriptionLanguageCode());
			}
		}else {
			LOG.debug("OrderTotalPriceResponse == null");
		}			
			
	}
	
	
	public static void debugInOrderPromise(OrderPromiseRequestParams wsRequest){
		LOG.debug("OrderPromiseRequest.AccountingEntityid = "+wsRequest.getAccountingEntityID());
		LOG.debug("OrderPromiseRequest.TenantId = "+wsRequest.getTenantID());
		LOG.debug("OrderPromiseRequest.ItemID = "+wsRequest.getItemID());
		LOG.debug("OrderPromiseRequest.WarehouseLocationID = "+wsRequest.getWarehouseLocationID());
		LOG.debug("OrderPromiseRequest.CustomerItemID = "+wsRequest.getCustomerItemID());
		LOG.debug("OrderPromiseRequest.Quantity = "+wsRequest.getQuantity());
		LOG.debug("OrderPromiseRequest.UnitCode = "+wsRequest.getUnitCode());
		LOG.debug("OrderPromiseRequest.UserName = "+wsRequest.getUserName());
		LOG.debug("OrderPromiseRequest.RequiredDeliveryDate = "+toDate(wsRequest.getRequiredDeliveryDate()).toString());
		LOG.debug("OrderPromiseRequest.ShippingAddressID = "+ wsRequest.getShippingAddressID());
	}
	
	public static void debugOutOrderPromise(OrderPromiseResponseParams wsResponse){
		if (wsResponse != null){
			LOG.debug("OrderPromiseResponse.ErrorReasonCode = "+wsResponse.getErrorReasonCode());
			LOG.debug("OrderPromiseResponse.ErrorReasonDescription = "+wsResponse.getErrorReasonDescription());		
			for(ATPInfo wsoutATPInfo : wsResponse.getArrayOfATPInfo()) {
				LOG.debug("==========OrderPromiseATPResponse========== ");
				LOG.debug("OrderPromiseResponse.ATPDate = "+((wsoutATPInfo.getATPDate() != null && !wsoutATPInfo.getATPDate().trim().isEmpty()) ? wsoutATPInfo.getATPDate().toString() : ""));
				LOG.debug("OrderPromiseResponse.UnitCode = "+wsoutATPInfo.getUnitCode());
				LOG.debug("OrderPromiseResponse.ATPQuantity = "+wsoutATPInfo.getATPQuantity());
				LOG.debug("OrderPromiseResponse.WarehouseLocationID = "+wsoutATPInfo.getWarehouseLocationID());
			}
		}else {
			LOG.debug("OrderPromiseResponse == null");
		}
			
	}
	
	public static void debugInCatalogPrice(CatalogPriceRequestParams wsRequest){
		LOG.debug("CatalogPriceRequest.AccountingEntityid = "+wsRequest.getAccountingEntityID());
		LOG.debug("CatalogPriceRequest.TenantId = "+wsRequest.getTenantID());
		LOG.debug("CatalogPriceRequest.CurrencyID = "+wsRequest.getCurrencyID());
		LOG.debug("CatalogPriceRequest.CustomerPartyID = "+wsRequest.getCustomerPartyID());
		LOG.debug("CatalogPriceRequest.WarehouseLocationID = "+wsRequest.getWarehouseLocationID());
		LOG.debug("CatalogPriceRequest.PriceGroup = "+wsRequest.getPriceGroup());
		LOG.debug("CatalogPriceRequest.UserName = "+wsRequest.getUserName());
		for(InputCatalogItems item : wsRequest.getArrayOfInputCatalogItems()) {			
			LOG.debug("==========CatalogPriceRequest Items========== ");
			LOG.debug("CatalogPriceRequest.CustomerItemID = "+item.getCustomerItemID());
			LOG.debug("CatalogPriceRequest.ItemID = "+item.getItemID());
			LOG.debug("CatalogPriceRequest.UnitCode = "+item.getUnitCode());
			LOG.debug("CatalogPriceRequest.ShippingAddressID = "+item.getShippingAddressID());
		}	
	}
	
	public static void debugOutCatalogPrice(CatalogPriceResponseParams wsResponse){
		if (wsResponse != null && wsResponse.getArrayOfOutputCatalogItems() !=null){
			LOG.debug("CatalogPriceResponse.ErrorReasonCode = "+wsResponse.getErrorReasonCode());
			LOG.debug("CatalogPriceResponse.ErrorReasonDescription = "+wsResponse.getErrorReasonDescription());
			for(OutputCatalogItems wsoutCatalogItem : wsResponse.getArrayOfOutputCatalogItems()) {				
				LOG.debug("==========CatalogPriceResponse Items========== ");
				LOG.debug("CatalogPriceResponse.ItemID = "+wsoutCatalogItem.getItemID());
				LOG.debug("CatalogPriceResponse.UnitCode = "+wsoutCatalogItem.getUnitCode());
				LOG.debug("CatalogPriceResponse.UnitBaseAmount = "+wsoutCatalogItem.getUnitBaseAmount());
				LOG.debug("CatalogPriceResponse.UnitPriceAmount = "+wsoutCatalogItem.getUnitPriceAmount());
				LOG.debug("CatalogPriceResponse.WarehouseLocationID = "+wsoutCatalogItem.getWarehouseLocationID());
			}
		}else {
			LOG.debug("CatalogPriceResponse == null");
		}	

	}
	
	public static void setBindingProvider(BindingProvider bindingProvider, URL url){
		LOG.debug("setBindingProvider Endpoint: "+url.toString());
		bindingProvider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,url.toString());
	}
	
	public static void setSOAPLoggingHandler(Service service){
		service.setHandlerResolver(new HandlerResolver(){
			@Override
			public List<Handler> getHandlerChain(PortInfo portInfo) {
				List<Handler> handlerChain = new ArrayList<Handler>();
				handlerChain.add(new SOAPLoggingHandler());
				return handlerChain;
			}

		});
	}
	

}
