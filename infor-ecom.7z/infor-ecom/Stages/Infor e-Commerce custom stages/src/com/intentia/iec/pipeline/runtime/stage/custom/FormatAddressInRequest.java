/*
 * Created on 08-03-2006
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import javax.xml.transform.TransformerException;

import org.apache.log4j.Logger;
import org.w3c.dom.Node;
import org.w3c.dom.traversal.NodeIterator;

import com.intentia.iec.businessobject.Parameters;
import com.intentia.iec.businessobject.ParametersException;
import com.intentia.iec.businessobject.input.RequestException;
import com.intentia.iec.businessobject.input.XMLRequest;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.PipelineStage;
import com.intentia.iec.pipeline.runtime.stage.utils.XMLRequestHelper;

/**
 * <p>
 * The <code>FormatAddressInRequest</code> stage formats an address in the
 * request. The stage is meant to be placed before an update stage.
 * </p>
 * 
 * <p>
 * <b>Input in <code>PipelineContext</code>:</b><br>
 * Parameters:
 * <ul>
 * <li><code>subset</code> (optional)</li>
 * <li><code>prefix</code> (optional)</li>
 * </ul>
 * The parameter <code>subset</code> tells what subset to operate in. The code
 * will iterate over the members in the subset. The stage can not work in both
 * main and subset. have, e.g. <code>Shipping</code> means
 * <code>ShippingCountryID</code>. The parameter <code>prefix</code> tells
 * what prefix the attribute names have, e.g. <code>Shipping</code> means
 * <code>ShippingCountryID</code>.
 * </p>
 * <p>
 * Attributes (mentioned without prefix):
 * <ul>
 * <li><code>CountryID</code></li>
 * <li><code>StateID</code></li>
 * <li><code>City</code></li>
 * <li><code>Zip</code></li>
 * <li><code>Address3</code></li>
 * <li><code>Address4</code></li>
 * </ul>
 * </p>
 * 
 * <p>
 * <b>Generated output in <code>PipelineContext</code>:</b><br>
 * When done the stage has added a value to the attributes
 * <ul>
 * <li><code>Address3</code></li>
 * <li><code>Address4</code></li>
 * </ul>
 * The prefix does also apply here, so it can be <code>ShippingAddress3</code>
 * if <code>prefix</code> is <code>Shipping</code>.
 * </p>
 */
public class FormatAddressInRequest implements PipelineStage {

    private static final Logger LOG = Logger.getLogger(FormatAddressInRequest.class);

    private static final String ENTITY_XPATH = "/request/entities/entity";

    private String prefix = null;

    private XMLRequestHelper requestHelper = null;

    /**
     * <p>
     * The stage formats the address fields <code>Address3</code> and
     * <code>Address4</code>.
     * </p>
     * 
     * @throws PipelineRuntimeException
     *             if {conditions for throwing}
     * @see com.intentia.iec.pipeline.runtime.PipelineStage#execute(com.intentia.iec.pipeline.runtime.PipelineContext)
     */
    public void execute(PipelineContext context) throws PipelineRuntimeException {

        // Verify type of request
        if (!(context.getRequest() instanceof XMLRequest)) {
            throw new PipelineRuntimeException("Request MUST be of type XMLRequest!");
        }

        XMLRequest request = (XMLRequest) context.getRequest();

        try {
            // Get parameters
            XMLRequest.extractRequestParameters(request);
            Parameters parameters = request.getParameters();
            String subset = parameters.getString(FormatAddress.SUBSET_PARAMETER);
            prefix = n2E(parameters.getString(FormatAddress.PREFIX_PARAMETER));

            requestHelper = new XMLRequestHelper(request);

            if (subset == null || subset.length() == 0) {
                // Format address fields in main set
                Node entityNode = XMLRequestHelper.getRequestNode(request, ENTITY_XPATH);
                if (entityNode == null) {
                    LOG.debug("The request does not hold an entity node!");
                    return;
                }
                formatAddress(entityNode);
            } else {
                // Format address fields in subset
                NodeIterator nodes = XMLRequestHelper.getSubsets(request, subset);
                while (true) {
                    Node entityNode = nodes.nextNode();
                    if (entityNode == null) {
                        break;
                    }
                    formatAddress(entityNode);
                }
            }

        } catch (ParametersException e) {
            throw new PipelineRuntimeException("Failed to obtain a parameter from request", e);
        } catch (RequestException e) {
            throw new PipelineRuntimeException("Failed to operate on request", e);
        }
    }

    /**
     * Format the address in the given XML node by calling the address
     * formatter.
     * 
     * @param entityNode
     *            Node with attributes to operate on.
     * @throws PipelineRuntimeException
     */
    private void formatAddress(final Node entityNode) throws PipelineRuntimeException {

        try {
            String countryCode = n2E(requestHelper.getAttribute(entityNode, prefix + FormatAddress.COUNTRY_ATTRIBUTE));
            String stateCode = n2E(requestHelper.getAttribute(entityNode, prefix + FormatAddress.STATE_ATTRIBUTE));
            String city = n2E(requestHelper.getAttribute(entityNode, prefix + FormatAddress.CITY_ATTRIBUTE));
            String zip = n2E(requestHelper.getAttribute(entityNode, prefix + FormatAddress.ZIP_ATTRIBUTE));
            if (countryCode.length() == 0) {
                LOG.debug("Attribute for country code must be present in order to format an address!");
                return;
            }

            // Do the formatting
            FormatAddress formatter = new FormatAddress();
            formatter.format(countryCode, stateCode, city, zip);

            // Insert returned values as attributes in the main request.
            requestHelper.setAttribute(entityNode, prefix + FormatAddress.ADDRESS3_ATTRIBUTE, formatter.getAddress3());
            requestHelper.setAttribute(entityNode, prefix + FormatAddress.ADDRESS4_ATTRIBUTE, formatter.getAddress4());

        } catch (TransformerException e) {
            throw new PipelineRuntimeException("Failed to get/set attribute in request", e);
        }
    }

    /**
     * Ensure that the string is not null.
     * 
     * @param s
     *            String to check.
     * @return returns the string empty if string is null.
     */
    private String n2E(final String s) {

        if (s == null) {
            return "";
        } else {
            return s;
        }
    }
}
