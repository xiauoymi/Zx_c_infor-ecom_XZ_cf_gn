/*
 * Created on 04-04-2006
 */
package com.intentia.iec.pipeline.runtime.stage.custom;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Map.Entry;

import org.apache.log4j.Logger;

import com.intentia.iec.businessobject.output.Resultset;
import com.intentia.iec.businessobject.output.ResultsetException;
import com.intentia.iec.businessobject.output.XMLIterator;
import com.intentia.iec.businessobject.output.XMLResultset;
import com.intentia.iec.pipeline.runtime.AbstractPipelineStage;
import com.intentia.iec.pipeline.runtime.PipelineContext;
import com.intentia.iec.pipeline.runtime.PipelineRuntimeException;
import com.intentia.iec.pipeline.runtime.stage.utils.SearchPipelineExecuter;
import com.intentia.iec.util.FastStringBuffer;
import com.intentia.iec.util.PropertyLoader;

/**
 * @author pedjes0
 * 
 */
public class HandleImages extends AbstractPipelineStage {
    private static final class BOSet {
        private final String name;

        private List attributes;

        private List subsets;

        private BOSet(final String name) {
            this.name = name;
        }

        private String getName() {
            return name;
        }

        private List getSubsets() {
            return subsets;
        }

        private BOSet getSubset(final String subsetName) {
            if (subsets != null) {
                Iterator it = subsets.iterator();
                while (it.hasNext()) {
                    BOSet set = (BOSet) it.next();
                    if (set.getName().equals(subsetName)) {
                        return set;
                    }
                }
            }
            return null;
        }

        private BOSet addSubset(final String subsetName) {
            BOSet subset = getSubset(subsetName);
            if (subset == null) {
                subset = new BOSet(subsetName);
                if (subsets == null) {
                    subsets = new LinkedList();
                }
                subsets.add(subset);
            }
            return subset;
        }

        private List getAttributes() {
            return attributes;
        }

        private void addAttribute(final String attribute) {
            if (attributes == null) {
                attributes = new LinkedList();
            }
            attributes.add(attribute);
        }
    }

    /**
     * Filename for the property file containing the Application Properties.
     */
    public static final String APPLICATION_PROPS = "/application.properties";

    private static boolean isInitialized = false;

    private static Map businessObjects = new HashMap();

    /**
     * Key use to retrieved Images Root URL from the Database.
     */
    private static final String APP_DETAILS_ROOT_URL = "rootUrl";

    private String imageRootPath = null;

    private static final Logger LOG = Logger.getLogger(HandleImages.class);

    static synchronized void initConfiguration() throws PipelineRuntimeException {
        if (isInitialized) {
            return;
        }

        Properties properties = PropertyLoader.loadProperties(APPLICATION_PROPS);
        if (properties == null) {
            FastStringBuffer error = new FastStringBuffer("Error reading file '");
            error.append(APPLICATION_PROPS);
            error.append("'.");
            throw new PipelineRuntimeException(error.toString());
        }

        Iterator it = properties.entrySet().iterator();
        while (it.hasNext()) {
            Entry entry = (Entry) it.next();
            String prop = (String) entry.getKey();
            if (prop.startsWith("Images.BO.")) {
                String businessObject = prop.substring(10);
                String value = (String) entry.getValue();
                BOSet mainSet = new BOSet(businessObject);
                businessObjects.put(businessObject, mainSet);
                // A property value specifies a list of business object
                // attributes, that must be handled by this stage. Each
                // attribute definition is separated by a semicolon
                String[] attributeDefs = value.split(";");
                for (int i = 0; i < attributeDefs.length; i++) {
                    // An attribute can be definition in the main set or in a
                    // subset. Subsets are separated from each other and from
                    // the attribute by a colon.
                    BOSet set = mainSet;
                    String[] parts = attributeDefs[i].split(":");
                    int subsetCount = parts.length - 1;
                    for (int j = 0; j < subsetCount; j++) {
                        set = set.addSubset(parts[j].trim());
                    }
                    set.addAttribute(parts[subsetCount].trim());
                }
            }
        }

        isInitialized = true;
    }

    /**
     * Get rootUrl Path from Application Data.
     * 
     * @throws PipelineRuntimeException
     */
    private void getRootUrlPath() throws PipelineRuntimeException {

        imageRootPath = getValueFromApplicationData(APP_DETAILS_ROOT_URL);

        if (null == imageRootPath) {
            FastStringBuffer msg = new FastStringBuffer(100);
            msg.append("Missing application data: ").append(APP_DETAILS_ROOT_URL);
            throw new PipelineRuntimeException(msg.toString());
        }
        LOG.debug("Images rootUrl Path: " + imageRootPath.toString());
    }

    /*
     * (non-Javadoc)
     */
    public final void execute(final PipelineContext context) throws PipelineRuntimeException {
        initConfiguration();

        BOSet businessObject = (BOSet) businessObjects.get(context.getObjectName());
        if (businessObject == null) {
            if (LOG.isDebugEnabled()) {
                FastStringBuffer debug = new FastStringBuffer();
                debug.append("No image attributes specified for business object '");
                debug.append(context.getObjectName());
                debug.append(HandleImages.class.getName());
                debug.append("'. Returning from stage '");
                debug.append(HandleImages.class.getName());
                debug.append("'.");
                LOG.debug(debug.toString());
            }
            return;
        }

        XMLResultset resultset = getResponse(context);
        if (resultset == null) {
            if (LOG.isDebugEnabled()) {
                FastStringBuffer debug = new FastStringBuffer();
                debug.append("Resultset not present in the pipeline. Returning from stage '");
                debug.append(HandleImages.class.getName());
                debug.append("'.");
                LOG.debug(debug.toString());
            }
            return;
        }

        try {
            this.getRootUrlPath();
            handleImageAttributes(resultset, businessObject);
        } catch (ResultsetException e) {
            throw new PipelineRuntimeException(e);
        }

    }

    private void handleImageAttributes(final Resultset resultset, final BOSet boSet) throws ResultsetException,
            PipelineRuntimeException {

        resultset.beforeFirst();
        while (resultset.hasNext()) {
            resultset.moveNext();
            if (boSet.getAttributes() != null) {
                Iterator attributes = boSet.getAttributes().iterator();
                while (attributes.hasNext()) {
                    String attribute = (String) attributes.next();
                    String imageValue = resultset.getString(attribute);
                    if (imageValue != null && !imageValue.startsWith("http://")) {
                        // resultset
                        imageValue = imageRootPath + imageValue;
                        if (resultset instanceof XMLResultset) {
                            // Main set - cast to XMLResultset
                            ((XMLResultset) resultset).setString(attribute, imageValue);
                        } else {
                            // Sub set - cast to XMLIterator
                            ((XMLIterator) resultset).setString(attribute, imageValue);
                        }
                    }
                }
            }

            if (boSet.getSubsets() != null) {
                Iterator subsets = boSet.getSubsets().iterator();
                while (subsets.hasNext()) {
                    BOSet subset = (BOSet) subsets.next();

                    Resultset subResult = (XMLIterator) resultset.getResultset(subset.getName());
                    if (subResult != null) {
                        handleImageAttributes(subResult, subset);
                    }
                }
            }
        }
        // Move cursor back before the first entry
        resultset.beforeFirst();
    }

    private static String getValueFromApplicationData(String pParamName) {

        String paramValue;

        SearchPipelineExecuter spe = new SearchPipelineExecuter(ConstantsForSales.PIPELINE_PACKAGE,
                ConstantsForSales.APPLICATION_DATA, ConstantsForSales.APPLICATION_DATA_DETAILS);

        spe.setParam("param", pParamName);

        try {
            XMLResultset rs = spe.execute();
            rs.moveFirst();
            paramValue = rs.getString("ParameterValue");
        } catch (PipelineRuntimeException e) {
            paramValue = "";
        } catch (ResultsetException e) {
            paramValue = "";
        }

        return paramValue;

    }
}
