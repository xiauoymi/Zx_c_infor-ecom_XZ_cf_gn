String.prototype.trim = function() {
	return this.replace(/^\s+|\s+$/g,"");
}

// Enters the text 'txt' in the html element with id 'id' and starts a progress bar of trailing dots.
function progressBar(id, txt)
{
 try{
  id.className = 'progressbar';
  if (id.innerHTML.trim().length == 0) {
    id.innerHTML = txt;
    putToCenter(id);
  } //else if (id.innerHTML.indexOf(" . . . . . . . . . .") > 0)
    //id.innerHTML = id.innerHTML = id.innerHTML.replace(/ \./gi, '');
  else
    //id.innerHTML += " .";
  id.innerHTML = id.innerHTML.replace(/<font>|<\/font>/gi, ''); // To fix strange behaviour in NS7
  }catch( e){}
  return 0;
}


function finalSubmit(button) {
  if (button.disabled != true) {
    button.disabled = true;
    button.className += ' disabled';  
    return true;
  }
  return false;
}


function putToCenter(elem) {
  var scrOfX = 0, scrOfY = 0;
  if( typeof( window.pageYOffset ) == 'number' ) {
    //Netscape compliant
    scrOfY = window.pageYOffset;
    scrOfX = window.pageXOffset;
  } else if( document.body && ( document.body.scrollLeft || document.body.scrollTop ) ) {
    //DOM compliant
    scrOfY = document.body.scrollTop;
    scrOfX = document.body.scrollLeft;
  } else if( document.documentElement && ( document.documentElement.scrollLeft || document.documentElement.scrollTop ) ) {
    //IE6 standards compliant mode
    scrOfY = document.documentElement.scrollTop;
    scrOfX = document.documentElement.scrollLeft;
  }
  var top = scrOfY + (getWinHeight()/2);
  var left = scrOfX + (getWinWidth()/2);
  elem.style.top = top + "px";
  elem.style.left = left + "px";
}

function getWinWidth() {
  var winWidth = 0;
  if( typeof( window.innerWidth ) == 'number' ) {
    //Non-IE
    winWidth = window.innerWidth;
  } else if( document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) {
    //IE 6+ in 'standards compliant mode'
    winWidth = document.documentElement.clientWidth;
  } else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) {
    //IE 4 compatible
    winWidth = document.body.clientWidth;
  }
    return winWidth;
}

function getWinHeight() {
  var winHeight = 0;
  if( typeof( window.innerHeight) == 'number' ) {
    //Non-IE
    winHeight = window.innerHeight;
  } else if( document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) {
    //IE 6+ in 'standards compliant mode'
    winHeight = document.documentElement.clientHeight;
  } else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) {
    //IE 4 compatible
    winHeight = document.body.clientHeight;
  }
  return winHeight;
}


window.onscroll = scrollEvent;
window.onresize = scrollEvent;
function scrollEvent() {
	if(document.getElementById('submitprogress'))
		putToCenter(document.getElementById('submitprogress'));
}
