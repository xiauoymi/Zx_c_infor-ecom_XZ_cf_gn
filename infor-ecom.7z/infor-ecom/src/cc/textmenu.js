var totalTextMenus = 0;
var textMenu = new Array();
var activeMenu= new Array();
var normalMenu= new Array();
var totalTexts = 0;
var texts = new Array();

function tocText(pageName, textId, menuNum)
{
  this.pageName = pageName;
  this.textId = textId;
  this.menuNum = menuNum;
}

function createTocText(pageName, textId, menuNum)
{
  texts[totalTexts] = new tocText(pageName, textId, menuNum);
  totalTexts++;
}

function setMenus(inPagename)
{
  for (i in texts) {	
    if (texts[i].pageName == inPagename) {
      var menuNum = texts[i].menuNum; 	
      
      if (textMenu[menuNum]) {
        textMenu[menuNum].className = normalMenu[menuNum];
	    
	textMenu[menuNum].onmouseout=function() { 
	  this.className=normalMenu[menuNum];
	}    
      }
	    
      textMenu[menuNum] = document.getElementById(texts[i].textId);
      if (!textMenu[menuNum])	
        return;
	
      textMenu[menuNum].className = activeMenu[menuNum];
	
      textMenu[menuNum].onmouseout=function() { 
        this.className=activeMenu[menuNum];
      }
    }
  }
}

