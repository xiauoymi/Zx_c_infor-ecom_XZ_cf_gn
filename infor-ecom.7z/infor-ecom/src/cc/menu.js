var totalGraphics = 0;
var graphic = new Array();
var totalMenus = 0;
var menuInfo = new Array();

function tocGraphic(imageSrcOn, imageSrcOff, imageSrcSelected, name, pagename, menuNum)
{
  this.name = name;
  this.pagename = pagename;
  this.menuNum = menuNum;
  this.off = new Image ();
  this.off.src = imageSrcOff;
  this.on = new Image ();
  this.on.src = imageSrcOn;
  this.selected = new Image ();
  this.selected.src = imageSrcSelected;
}

function createTocGraphic(imageSrcOn, imageSrcOff, imageSrcSelected, name, pagename, menuNum)
{
  graphic[totalGraphics] = new tocGraphic(imageSrcOn, imageSrcOff, imageSrcSelected, name, pagename, menuNum);
  totalGraphics++;
}

function doClick(num, menuNum)
{
  var selected = menuInfo[menuNum][0];
  var offset = menuInfo[menuNum][2];
  num = num*1 + offset;

  if (document.images[graphic[num].name])
    document.images[graphic[num].name].src = graphic[num].selected.src;

  if (num != selected && selected != -1)
    if (document.images[graphic[selected].name])
      document.images[graphic[selected].name].src = graphic[selected].off.src;

  menuInfo[menuNum][0] = num;
}

function doMouseOver(num, menuNum)
{
  var selected = menuInfo[menuNum][0];
  var highlighted = menuInfo[menuNum][1];
  var offset = menuInfo[menuNum][2];
  num = num*1 + offset;

  if (num != selected)
    if (document.images[graphic[num].name])
      document.images[graphic[num].name].src = graphic[num].on.src;

  if (highlighted != selected && highlighted != num && highlighted != -1)
    if (document.images[graphic[highlighted].name])
      document.images[graphic[highlighted].name].src = graphic[highlighted].off.src;

  menuInfo[menuNum][1] = num;
}

function doMouseOut(menuNum)
{
  var selected = menuInfo[menuNum][0];
  var highlighted = menuInfo[menuNum][1];

  if (highlighted != selected && highlighted != -1)
    if (document.images[graphic[highlighted].name])
      document.images[graphic[highlighted].name].src = graphic[highlighted].off.src;

  menuInfo[menuNum][1] = -1;
}

function setMenus(inPagename)
{
    for (i in graphic)
    {
        if (graphic[i].pagename == inPagename)
        {
            var offset = menuInfo[graphic[i].menuNum][2];
            doClick(i - offset, graphic[i].menuNum);
        }
    }
}
