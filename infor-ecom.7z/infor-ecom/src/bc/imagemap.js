	/* 
	 */
	var IMAGEMAPID = 'ImageMap';
	var IMAGEID = 'ImageMapImage';

	var DRAWINGMODE_NONE = 0;

	var DRAWINGMODE_RECTANGLE_START = 10;

	var DRAWINGMODE_CIRCLE_START = 20;

	var DRAWINGMODE_POLYGON_START = 30;

	var SHAPE_NONE = -1;
	var SHAPE_RECTANGLE = 0;
	var SHAPE_CIRCLE = 1;
	var SHAPE_POLYGON = 2;
	
	var SHAPE_RECTANGLE_STRING = 'ItemShapeRectangle';
	var SHAPE_CIRCLE_STRING = 'ItemShapeCircle';
	var SHAPE_POLYGON_STRING = 'ItemShapePolygon';
	
	var KEYCODE_DELETE = 46;

	this.newShape = SHAPE_NONE;

	this.isIE = (navigator.appName == "Microsoft Internet Explorer");

	this.drawingMode = DRAWINGMODE_NONE;

	this.arrLabels = [];
	
	this.arrShapes = [];

	this.arrCanvas = [];
	this.curIndex = -1;

	this.topLeft = {};
	this.topLeft.x = 0;
	this.topLeft.y = 0;

	this.bottomRight = {};
	this.bottomRight.x = 0;
	this.bottomRight.y = 0;
	
	this.lastPolygonPoint = {};
	this.lastPolygonPoint.x = 0;
	this.lastPolygonPoint.y = 0;
	
	this.circleMidPoint = {};
	this.circleMidPoint.x = 0;
	this.circleMidPoint.y = 0;
	
	this.callbackStart = null;	
	this.callbackEnd = null;	
	this.callbackSelect = null;
	this.callbackDelete = null;
	
	this.selectedArea = -1;
	
	var STROKECOLOR = '#0000ff';
	
	var FILLCOLOR = '#CCCCCC';

	this.shade = FILLCOLOR; 

	function ImageMap(funcStart, funcEnd, funcSelect, funcDelete) {	
		this.callbackStart = funcStart;
		this.callbackEnd = funcEnd;
		this.callbackSelect = funcSelect;
		this.callbackDelete = funcDelete;
		Event.observe($(IMAGEID), 'click', function(event){onMouseClick(event)});
		Event.observe($(IMAGEID), 'mousemove', function(event){onMouseMove(event)});
		
		document.observe('keydown', function(event){onKeyDown(event)});
	}

	/*
	x = left position
	y = top position
	
	shape = shape that will be placed inside the canvas
   */
   function createNewCanvas(x, y, shape) {   
		var id = this.arrCanvas.length;
		this.arrCanvas[id] = document.createElement('canvas');
		this.arrCanvas[id].id = 'canvas' + id;
		this.arrCanvas[id].style.left = x  + 'px';
		this.arrCanvas[id].style.top  = y  + 'px';

		this.arrCanvas[id].style.position = 'absolute';

		this.arrCanvas[id].style.width  = 0  + 'px';
		this.arrCanvas[id].style.height = 0  + 'px';
		
		this.arrCanvas[id].style.opacity = 50 / 100;
		this.arrCanvas[id].style.filter  = 'alpha(opacity='+50+')';
		this.arrCanvas[id].style.backgroundColor  = '#ffffff';
		
		this.arrCanvas[id].onmousemove = this.onMouseMoveInsideMap.bind(this);
		this.arrCanvas[id].onmousedown = this.onMouseClickInsideMap.bind(this);
		
		if (typeof G_vmlCanvasManager != "undefined") {		
			this.arrCanvas[id] = G_vmlCanvasManager.initElement(this.arrCanvas[id]);
		}		

		return id;
   }
   
   /*
	Creates a shape that will store the points of the map.
   */
   function createNewShape(shape) {   
		var idx = this.arrShapes.length;
		this.arrShapes[idx] = {};		
		this.arrShapes[idx].shape = shape;
		this.arrShapes[idx].showFill = false;
		this.arrShapes[idx].points = [];		
   }
   
   function setShowFill(idx) {
		if (idx < this.arrShapes.length) {
			this.arrShapes[idx].showFill = true;
		}
   }
   
   function createNewLabel(x, y, lbl) {
		var idx = this.arrLabels.length;
		this.arrLabels[idx] = document.createElement('div');
		this.arrLabels[idx].id = 'hotspotlabel';
		this.arrLabels[idx].className = 'hotspotlabel';

		this.arrLabels[idx].style.height  = 15  + 'px';
		this.arrLabels[idx].style.width  = 27  + 'px';
		this.arrLabels[idx].style.position = 'absolute';
		setLabelCoordinates(idx, x, y);

		this.arrLabels[idx].innerHTML = lbl;		
   }

   function setLabelCoordinates(idx, x, y) {
		if (idx < this.arrLabels.length) {
			// align to center
			var midLeft = x - (parseInt(this.arrLabels[idx].style.width, 10)/2);
			var midTop = y - (parseInt(this.arrLabels[idx].style.height, 10)/2);
			if (midLeft < 0) {
				midLeft = 0;
			}
			if (midTop < 0) {
				midTop = 0;
			}
			this.arrLabels[idx].style.left = midLeft  + 'px';
			this.arrLabels[idx].style.top  = midTop  + 'px';
		}
   }
   
   function hideLabel(idx) {
		setLabelVisibility(idx, 'hidden');
   }
   
   function showLabel(idx) {
		setLabelVisibility(idx, 'visible');
   }
   
   function setLabelVisibility(idx, attr) {
		if (idx < this.arrLabels.length) {
			this.arrLabels[idx].style.visibility = attr;
		}      
   }
   
   function setTitle(idx, title) {
		if (idx < this.arrCanvas.length) {
			this.arrCanvas[idx].title = title;
		}
   }   

	/*
		Adds a point to a shape.
	*/   
   function addPointToShape(idx, x, y) {
		var len = this.arrShapes[idx].points.length;
		this.arrShapes[idx].points[len] = {};
		this.arrShapes[idx].points[len].x = x;
		this.arrShapes[idx].points[len].y = y;
   }
   
   function createEmpty() {
		var imagemap = document.getElementById(IMAGEMAPID);
		
		this.curIndex = createNewCanvas(0, 0, this.newShape);		
		createNewShape(this.newShape);
		createNewLabel(0, 0, (this.curIndex+1));
		
		hideLabel(this.curIndex);

		imagemap.appendChild(this.arrCanvas[this.curIndex]);
		imagemap.appendChild(this.arrLabels[this.curIndex]);   
   }
   
   function setCanvasCoordinates(idx, x, y) {
		this.arrCanvas[idx].style.left = x  + 'px';
		this.arrCanvas[idx].style.top  = y  + 'px';   
   }
   
   function codeToShapeString(code) {  
		if (code == SHAPE_RECTANGLE) {
			return SHAPE_RECTANGLE_STRING;
		}
		else if (code == SHAPE_CIRCLE) {
			return SHAPE_CIRCLE_STRING;
		}
		else if (code == SHAPE_POLYGON) {
			return SHAPE_POLYGON_STRING;
		}
		else {
			return '';
		}
   }
   
   /*
	when user clicks add image map
   */
   function startMapping(x, y) {
		this.topLeft.x = x;
		this.topLeft.y = y;
		this.bottomRight.x = x;
		this.bottomRight.y = y;

		if (this.newShape == SHAPE_RECTANGLE) {
			createEmpty();
			setCanvasCoordinates(this.curIndex, x, y);
			this.drawingMode = DRAWINGMODE_RECTANGLE_START;			
		}
		else if (this.newShape == SHAPE_CIRCLE) {
			createEmpty();
			setCanvasCoordinates(this.curIndex, x, y);
			this.circleMidPoint.x = x;
			this.circleMidPoint.y = y;
			this.drawingMode = DRAWINGMODE_CIRCLE_START;			
		}
		else if (this.newShape == SHAPE_POLYGON) {
			createEmpty();
			setCanvasCoordinates(this.curIndex, x, y);
			this.drawingMode = DRAWINGMODE_POLYGON_START;			

			addPointToShape(this.curIndex, x, y);	
		}
		
		if (this.callbackStart != null) {
			this.callbackStart(this.curIndex, codeToShapeString(this.newShape));
		}
   }
   
	function convertToCoordinates(idx) {
		var ret = '';
		if (idx < this.arrShapes.length) {

			if (this.arrShapes[idx].shape == SHAPE_RECTANGLE && this.arrShapes[idx].points.length == 2) {
				for(i = 0; i < this.arrShapes[idx].points.length; i++) {
					ret = ret + this.arrShapes[idx].points[i].x + ',' + this.arrShapes[idx].points[i].y;
					if (i < 1) {
						ret = ret + ',';
					}
				}
			}
			else if (this.arrShapes[idx].shape == SHAPE_POLYGON && this.arrShapes[idx].points.length > 0) {
				for(i = 0; i < this.arrShapes[idx].points.length; i++) {
					ret = ret + this.arrShapes[idx].points[i].x + ',' + this.arrShapes[idx].points[i].y;
					if (i < (this.arrShapes[idx].points.length-1)) {
						ret = ret + ',';
					}
				}				
			}
			else if (this.arrShapes[idx].shape == SHAPE_CIRCLE && this.arrShapes[idx].points.length == 2) {
				var radius = Math.floor((this.arrShapes[idx].points[1].x - this.arrShapes[idx].points[0].x) / 2);
				var cx = this.arrShapes[idx].points[0].x + radius;
				var cy = this.arrShapes[idx].points[0].y + radius;
				ret = cx + ',' + cy + ',' + radius;
			}
		}

		return ret;
	}

	/*
		mapping for a particular shape has ended
	*/   
   function endMapping() {
		var callbackParam = this.curIndex;
		
		resetVariables();
		
		if (this.callbackEnd != null) {
			this.callbackEnd(callbackParam, convertToCoordinates(callbackParam));
		}
   }
   
   function resetVariables() {
		this.drawingMode = DRAWINGMODE_NONE;
		this.curIndex = -1;

		this.topLeft.x = 0;
		this.topLeft.y = 0;

		this.bottomRight.x = 0;
		this.bottomRight.y = 0;
		
		this.circleMidPoint.x = 0;
		this.circleMidPoint.y = 0;
		
		//this.newShape = SHAPE_NONE;
   }

   /*
	stores the top-left and bottom-right coordinates.
   */
   function storeRectanglePoints() {   
		var top = parseInt(this.arrCanvas[this.curIndex].style.top, 10);
		var left = parseInt(this.arrCanvas[this.curIndex].style.left, 10);
		var bottom = top + parseInt(this.arrCanvas[this.curIndex].style.height, 10);
		var right = left + parseInt(this.arrCanvas[this.curIndex].style.width, 10);   
      
		addPointToShape(this.curIndex, left, top);
		addPointToShape(this.curIndex, right, bottom);
   }
   
   function storeLoadedRectanglePoints(idx, left, top, right, bottom) {
		addPointToShape(idx, left, top);
		addPointToShape(idx, right, bottom);   
   }
   
   function storeLoadedCirclePoints(idx, left, top, right, bottom) {
		addPointToShape(idx, left, top);
		addPointToShape(idx, right, bottom);   
   }

	/*
	*/
   function storeCirclePoints() {   
		var top = parseInt(this.arrCanvas[this.curIndex].style.top, 10);
		var left = parseInt(this.arrCanvas[this.curIndex].style.left, 10);
		var bottom = top + parseInt(this.arrCanvas[this.curIndex].style.height, 10);
		var right = left + parseInt(this.arrCanvas[this.curIndex].style.width, 10);
      
		addPointToShape(this.curIndex, left, top);
		addPointToShape(this.curIndex, right, bottom);		
   }   
   
   function getOffsetPos(element) {
		var xpos = 0;
		var ypos = 0;
		if (element != null) {
			var elementOffsetParent = element.offsetParent;
			// If the element has an offset parent
			if (elementOffsetParent) {
				// While there is an offset parent
				while ((elementOffsetParent = element.offsetParent)) {
					//offset might give negative in opera when the image is scrolled
					if (element.offsetLeft > 0) {xpos += element.offsetLeft;}
					if (element.offsetTop > 0) {ypos += element.offsetTop;}
					element = elementOffsetParent;
				}
			}
			else {
				xpos = element.offsetLeft;
				ypos = element.offsetTop;
			}
		}
		return {x: xpos, y: ypos};
	}
	
	function trimPolygon(idx) {
		var POLYGONMARGIN = 0;

		if (idx < this.arrShapes.length && idx < this.arrCanvas.length) {
			if (this.arrShapes[idx].shape == SHAPE_POLYGON) {
				if (this.arrShapes[idx].points.length > 0) {

					var image = document.getElementById(IMAGEID);
					var left = this.arrShapes[idx].points[0].x;
					var right = this.arrShapes[idx].points[0].x;
					var top = this.arrShapes[idx].points[0].y;
					var bottom = this.arrShapes[idx].points[0].y;
					
					for (i = 1; i < this.arrShapes[idx].points.length; i++) {
						if (this.arrShapes[idx].points[i].x < left) {
							left = this.arrShapes[idx].points[i].x;
						}
						if (this.arrShapes[idx].points[i].x > right) {
							right = this.arrShapes[idx].points[i].x;
						}
						if (this.arrShapes[idx].points[i].y < top) {
							top = this.arrShapes[idx].points[i].y;
						}
						if (this.arrShapes[idx].points[i].y > bottom) {
							bottom = this.arrShapes[idx].points[i].y;
						}						
					}
					
					left = left - POLYGONMARGIN;
					if (left < 0) { left = 0; };
					
					right = right + POLYGONMARGIN;
					if (right > image.width) { right = image.width; };
					
					top = top - POLYGONMARGIN;
					if (top < 0) { top = 0; };
					
					bottom = bottom + POLYGONMARGIN;
					if (bottom > image.height) { bottom = image.height };
					
					if (left > image.width || top > image.height) {
						hideCanvas(idx);
					}
					else {
						this.arrCanvas[idx].style.width = (right - left) + 'px';
						this.arrCanvas[idx].width = (right - left);

						this.arrCanvas[idx].style.height = (bottom - top) + 'px';
						this.arrCanvas[idx].height = (bottom - top);

						this.arrCanvas[idx].style.top  = top  + 'px';
						this.arrCanvas[idx].style.left = left  + 'px';
						
						drawPolygon(idx, 0, 0);
						setLabelCoordinates(idx, left + Math.floor((right - left)/2), top + Math.floor((bottom-top)/2));
					}
				}
			}
		}
	}
	
	function hideCanvas(idx) {
		if (idx < this.arrCanvas.length) {
			this.arrCanvas[idx].style.width = 0 + 'px';
			this.arrCanvas[idx].width = 0;

			this.arrCanvas[idx].style.height = 0 + 'px';
			this.arrCanvas[idx].height = 0;

			this.arrCanvas[idx].style.top  = 0  + 'px';
			this.arrCanvas[idx].style.left = 0  + 'px';		
		}
		hideLabel(idx);	
	}
	
	function endMappingRectangle(index, forced) {
		storeRectanglePoints();
		showLabel(index);
		endMapping();
		
		if (forced == false) {
			this.selectedArea = index;
			sendCallBackSelect();
		}
	}
	
	function endMappingCircle(index, forced) {
		storeCirclePoints();
		showLabel(index);
		endMapping();

		if (forced == false) {
			this.selectedArea = index;
			sendCallBackSelect();
		}		
	}
	
	function endMappingPolygon(index, forced) {
		showLabel(index);
		endMapping();
		trimPolygon(index);
		
		if (forced == false) {
			this.selectedArea = index;
			sendCallBackSelect();
		}		
	}
	
	function sendCallBackSelect() {
		if (this.callbackSelect != null) {
			this.callbackSelect(this.selectedArea);
		}	
	}
   
   /*
   */
   function onMouseClick(event) {
		if (this.selectedArea != -1) {
			this.selectedArea = -1; // reset
			sendCallBackSelect();
		}		
		var image = document.getElementById(IMAGEID);
		var pos = getOffsetPos(image);
		var x = (this.isIE) ? (window.event.x - image.offsetLeft) : (event.pageX - pos.x);
		var y = (this.isIE) ? (window.event.y - image.offsetTop)  : (event.pageY - pos.y);
		var offX = (this.isIE) ? (image.offsetLeft) : (pos.x);
		var offY = (this.isIE) ? (image.offsetTop) : (pos.y);
		
		var imagemap = document.getElementById(IMAGEMAPID);		
		x = x + imagemap.scrollLeft;
		y = y + imagemap.scrollTop;
		
		if (x<0 || y<0 || x>image.width || y>image.height) {return;}

		if (!event) {
			event = window.event;
		}

		if (this.drawingMode == DRAWINGMODE_NONE && this.newShape != SHAPE_NONE) {
			startMapping(x, y);
		}
		else if (this.drawingMode == DRAWINGMODE_RECTANGLE_START) {
			endMappingRectangle(this.curIndex, false);
		}
		else if (this.drawingMode == DRAWINGMODE_CIRCLE_START) {
			endMappingCircle(this.curIndex, false);
		}
		else if (this.drawingMode == DRAWINGMODE_POLYGON_START) {
			addPointToShape(this.curIndex, x, y);
			if (event.shiftKey)	{
				endMappingPolygon(this.curIndex, false);
			}
		}
	}
	
	/*
	*/
	function onMouseMove(event) {	
		var image = document.getElementById(IMAGEID);
		var pos = getOffsetPos(image);
		var x = (this.isIE) ? (window.event.x - image.offsetLeft) : (event.pageX - pos.x);
		var y = (this.isIE) ? (window.event.y - image.offsetTop)  : (event.pageY - pos.y);

		var imagemap = document.getElementById(IMAGEMAPID);		
		x = x + imagemap.scrollLeft;
		y = y + imagemap.scrollTop;	
		
		if (x<0 || y<0 || x>image.width || y>image.height) {return;}

		if (this.drawingMode == DRAWINGMODE_RECTANGLE_START) {
			processMouseMoveRectangle(x, y);
		}
		else if (this.drawingMode == DRAWINGMODE_CIRCLE_START) {		
			processMouseMoveCircle(x, y);
		}
		else if (this.drawingMode == DRAWINGMODE_POLYGON_START) {
			processMouseMovePolygon(x, y);
		}
	}
	
	/*
		resize the canvas if mouse is moved.
	*/
	function processMouseMoveRectangle(x, y) {
		if (this.curIndex == -1) {return;}
		var lblX = 0;
		var lblY = 0;

		if (x < this.topLeft.x) {
			this.arrCanvas[this.curIndex].style.left = x + 'px';
			lblX = x;
		}
		else {
			this.arrCanvas[this.curIndex].style.left = this.topLeft.x + 'px';
			lblX = this.topLeft.x;
		}
			
		if (y < this.topLeft.y) {
			this.arrCanvas[this.curIndex].style.top = y + 'px';
			lblY = y;
		}
		else {
			this.arrCanvas[this.curIndex].style.top = this.topLeft.y + 'px';
			lblY = this.topLeft.y;
		}

		var width = Math.abs(x - this.topLeft.x);
		var height = Math.abs(y - this.topLeft.y);		
		drawRectangle(this.curIndex, lblX, lblY, lblX + width, lblY + height);

		/*
		var width = Math.abs(x - this.topLeft.x);
		var height = Math.abs(y - this.topLeft.y);
		
		this.arrCanvas[this.curIndex].style.width = width;
		this.arrCanvas[this.curIndex].style.height = height;
		this.arrCanvas[this.curIndex].width = width;
		this.arrCanvas[this.curIndex].height = height;
		*/
		
		//setLabelCoordinates(this.curIndex, lblX, lblY);
		setLabelCoordinates(this.curIndex, lblX + Math.floor(width/2), lblY + Math.floor(height/2));
	}
	
	function redraw(idx) {
		if (idx < this.arrShapes.length) {
			if (this.arrShapes[idx].shape == SHAPE_RECTANGLE) {
				redrawRectangle(idx);
			}
			else if (this.arrShapes[idx].shape == SHAPE_CIRCLE) {
				redrawCircle(idx);
			}
			else if (this.arrShapes[idx].shape == SHAPE_POLYGON) {
				redrawPolygon(idx);
			}
		}
	}
	
	function redrawCircle(idx) {
		if (idx < this.arrCanvas.length) {
			var radius = Math.floor(this.arrCanvas[idx].width/2) - 1;
			var context = this.arrCanvas[idx].getContext("2d");

			//clear canvas
			context.clearRect(0, 0, this.arrCanvas[idx].width, this.arrCanvas[idx].width);
			//draw circle
			context.beginPath();
			context.strokeStyle = STROKECOLOR;		
			// center x, center y, radius
			context.arc(radius+1, radius+1, radius, 0, Math.PI*2, 0);			
			context.closePath();

			if (idx < this.arrShapes.length) {
				if (this.arrShapes[idx].showFill == true) {
					context.fillStyle = this.shade;
					context.fill();
				}
			}

			context.stroke();
			
			//draw center
			context.strokeStyle = STROKECOLOR;
			context.strokeRect(radius, radius, 1, 1);			
		}
	}

	/*
		draw a circle
	*/	
	function drawCircle(index, left, top, width) {
		var image = document.getElementById(IMAGEID);
		if (left > image.width || (left+width) > image.width || top > image.height || (top+width) > image.height) {
			hideCanvas(index);
		}
		else {
			this.arrCanvas[index].style.left = left + 'px';
			this.arrCanvas[index].style.top = top + 'px';	
			this.arrCanvas[index].style.width = width + 'px';
			this.arrCanvas[index].style.height = width + 'px';
			this.arrCanvas[index].width = width;
			this.arrCanvas[index].height = width;
			
			//get canvas context
			redrawCircle(index);
		}
	}
	
	function getMinValueInImage(value) {
		if (value < 0) {
			return 0;
		}
		return value;
	}
	
	function getMaxValueInImage(max, value) {
		if (value > max) {
			return max;
		}
		return value;
	}
	
	function getLessValue(v1, v2) {
		if (v1 < v2) {
			return v1;
		}
		return v2;
	}
	
	function processMouseMoveCircle(x, y) {
		if (this.curIndex == -1) {return;}
		
		var image = document.getElementById(IMAGEID);
		var xdiff = 0;
		var ydiff = 0;
		var radius  = 0;
		var width = 0;
		var left = 0;
		var right = 0;
		var top = 0;
		var bottom = 0;

		xdiff = Math.abs(this.circleMidPoint.x - x);
		ydiff = Math.abs(this.circleMidPoint.y - y);	
	
		if (xdiff < ydiff) {
			radius = xdiff;
		}
		else {
			radius = ydiff;
		}
		
		/*
		left = this.circleMidPoint.x - radius;
		right = this.circleMidPoint.x + radius;
		top = this.circleMidPoint.y - radius;		
		bottom = this.circleMidPoint.y + radius;
		*/
		left = getMinValueInImage(this.circleMidPoint.x - radius);
		right = getMaxValueInImage(image.width, this.circleMidPoint.x + radius);
		top = getMinValueInImage(this.circleMidPoint.y - radius);
		bottom = getMaxValueInImage(image.height, this.circleMidPoint.y + radius);
		
		radius = getLessValue(radius, this.circleMidPoint.x-left);
		radius = getLessValue(radius, right-this.circleMidPoint.x);
		radius = getLessValue(radius, this.circleMidPoint.y-top);
		radius = getLessValue(radius, bottom-this.circleMidPoint.y);

		width = radius * 2;
		
		drawCircle(this.curIndex, this.circleMidPoint.x - radius, this.circleMidPoint.y - radius, width);
		//setLabelCoordinates(this.curIndex, newLeft, newTop);
		setLabelCoordinates(this.curIndex, this.circleMidPoint.x, this.circleMidPoint.y);
	}
	
	/*
		resize the canvas if mouse is moved and redraw the circle.
	*/
	function processMouseMoveCircle1(x, y) {
		if (this.curIndex == -1) {return;}	
		var xdiff = 0;
		var ydiff = 0;
		var width  = 0;
		var newLeft = this.topLeft.x; 
		var newTop = this.topLeft.y;
		
		// left up
		if (x < this.topLeft.x && y < this.topLeft.y) {
			// in this case, topLeft is actually the bottomRight. this is where the canvas will pivot
			xdiff = Math.abs(x - this.topLeft.x);
			ydiff = Math.abs(y - this.topLeft.y);

			// choose shorter side
			if (xdiff < ydiff) {
				width = xdiff;
			}
			else {
				width = ydiff;
			}
			
			// new x,y coordinates will be distance from the pivot
			newLeft = this.topLeft.x - width;
			newTop = this.topLeft.y - width;		
		}
		//left down
		else if (x < this.topLeft.x && y > this.topLeft.y) {
			xdiff = Math.abs(x - this.topLeft.x);
			ydiff = Math.abs(y - this.topLeft.y);

			// choose shorter side
			if (xdiff < ydiff) {
				width = xdiff;
			}
			else {
				width = ydiff;
			}
			
			// new x,y coordinates will be distance from the pivot
			newLeft = this.topLeft.x - width;
			newTop = this.topLeft.y;
		}
		// right down
		else if (x > this.topLeft.x && y > this.topLeft.y) {
			xdiff = Math.abs(x - this.topLeft.x);
			ydiff = Math.abs(y - this.topLeft.y);

			// choose shorter side
			if (xdiff < ydiff) {
				width = xdiff;
			}
			else {
				width = ydiff;
			}
			
			// new x,y coordinates will be distance from the pivot
			newTop = this.topLeft.y
			newLeft = this.topLeft.x;
		}
		// right up
		else if (x > this.topLeft.x && y < this.topLeft.y) {
			xdiff = Math.abs(x - this.topLeft.x);
			ydiff = Math.abs(y - this.topLeft.y);

			// choose shorter side
			if (xdiff < ydiff) {
				width = xdiff;
			}
			else {
				width = ydiff;
			}
			
			// new x,y coordinates will be distance from the pivot
			newLeft = this.topLeft.x;
			newTop = this.topLeft.y	- width;	
		}		

		drawCircle(this.curIndex, newLeft, newTop, width);
		//setLabelCoordinates(this.curIndex, newLeft, newTop);
		setLabelCoordinates(this.curIndex, newLeft + Math.floor(width/2), newTop + Math.floor(width/2));
	}	
	
	/*
	*/
	function processMouseMovePolygon(x, y) {
		if (this.curIndex == -1) {return;}
		if (x < this.topLeft.x) {		
			var width = parseInt(this.arrCanvas[this.curIndex].style.width, 10) + 
				(parseInt(this.arrCanvas[this.curIndex].style.left, 10) - x);
		
			this.arrCanvas[this.curIndex].style.width = width;			
			this.arrCanvas[this.curIndex].width = width;

			this.arrCanvas[this.curIndex].style.left = x + 'px';
			this.topLeft.x = x;					
		}
		else if (x > (this.topLeft.x + parseInt(this.arrCanvas[this.curIndex].style.width, 10))) {				
			var width = (x - this.topLeft.x);
			this.arrCanvas[this.curIndex].style.width = width;
			this.arrCanvas[this.curIndex].width = width;
		}
		
		if (y < this.topLeft.y) {
			var height = parseInt(this.arrCanvas[this.curIndex].style.height, 10) + 
				(parseInt(this.arrCanvas[this.curIndex].style.top, 10) - y);
			
			this.arrCanvas[this.curIndex].style.height = height;			
			this.arrCanvas[this.curIndex].height = height;

			this.arrCanvas[this.curIndex].style.top = y + 'px';
			this.topLeft.y = y;
		}
		else if (y > (this.topLeft.y + parseInt(this.arrCanvas[this.curIndex].style.height, 10))) {
			var height = (y - this.topLeft.y)
			this.arrCanvas[this.curIndex].style.height =  height;
			this.arrCanvas[this.curIndex].height = height;
		}

		this.lastPolygonPoint.x = x;
		this.lastPolygonPoint.y = y;
		drawPolygon(this.curIndex, x, y);
		//setLabelCoordinates(this.curIndex, this.topLeft.x, this.topLeft.y);
		setLabelCoordinates(this.curIndex, 
							this.topLeft.x + Math.floor(this.arrCanvas[this.curIndex].width/2), 
							this.topLeft.y + Math.floor(this.arrCanvas[this.curIndex].height/2));
	}

	onMouseMoveInsideMap = function(event)  {
		onMouseMove(event);
	}
	
	onMouseClickInsideMap = function(event)  {
		if (this.newShape == SHAPE_NONE) {
			var target = null;
			if (this.isIE == true) {
				target = window.event.srcElement;
			}
			else {
				target = event.currentTarget;
			}
			if (target.tagName == 'DIV') {
				target = target.parentNode;
			}
			if (target.tagName == 'image' || target.tagName == 'group' || target.tagName == 'shape' || target.tagName == 'stroke') {
				target = target.parentNode.parentNode;
			}
			
			var id = getId(target.id);
			if (id != '') {
				this.selectedArea = parseInt(id, 10);
			}
			sendCallBackSelect();
		}
		else {			
			onMouseClick(event);
		}				
	}
	
	function getId(target) {
		var ret = '';
		if (target != null) {
			var index = target.indexOf('canvas');
			if (index != -1) {
				ret = target.substring(index + 'canvas'.length);
			}
		}
		
		return ret;
	}
	
	function redrawPolygon(idx) {
		drawPolygon(idx, 0, 0);
	}
	
	function drawPolygon(idx, x, y) {
		if (idx < this.arrShapes.length) {
		
			//get canvas context
			var context = this.arrCanvas[idx].getContext("2d");
			var width = parseInt(this.arrCanvas[idx].style.width, 10);
			var height = parseInt(this.arrCanvas[idx].style.height, 10);
			var left = parseInt(this.arrCanvas[idx].style.left, 10);
			var top = parseInt(this.arrCanvas[idx].style.top, 10);			

			//clear canvas
			context.clearRect(0, 0, width, height);
			//draw polygon
			context.beginPath();
			context.strokeStyle = STROKECOLOR;
			
			context.moveTo(this.arrShapes[idx].points[0].x - left, this.arrShapes[idx].points[0].y - top);

			for (i=1, le = this.arrShapes[idx].points.length; i<le; i++) {
				context.lineTo(this.arrShapes[idx].points[i].x - left, this.arrShapes[idx].points[i].y - top);
			}
			
			if (this.drawingMode == DRAWINGMODE_POLYGON_START) {			
				context.lineTo(x - left, y - top);
			}			

			context.lineTo(this.arrShapes[idx].points[0].x - left, this.arrShapes[idx].points[0].y - top);
			
			context.closePath();

			if (idx < this.arrShapes.length) {
				if (this.arrShapes[idx].showFill == true) {
					context.fillStyle = this.shade;
					context.fill();
				}
			}

			context.stroke();
		}	
	}
	
	function redrawRectangle(idx) {
		if (idx < this.arrCanvas.length) {
			//get canvas context
			var context = this.arrCanvas[idx].getContext("2d");
			context.clearRect(0, 0, this.arrCanvas[idx].width, this.arrCanvas[idx].height);

			context.strokeStyle = STROKECOLOR;
			context.lineWidth = 2;

			context.beginPath();
			context.rect(0, 0, this.arrCanvas[idx].width, this.arrCanvas[idx].height);
			context.closePath();
			
			if (idx < this.arrShapes.length) {
				if (this.arrShapes[idx].showFill == true) {
					context.fillStyle = this.shade;
					context.fill();
				}
			}
			
			context.stroke();
		}
	}
	
	function drawRectangle(idx, left, top, right, bottom) {
		var image = document.getElementById(IMAGEID);
		if (left > image.width || right > image.width || top > image.height || bottom > image.height) {
			hideCanvas(idx);
		}
		else {
			var width = (right - left);
			var height = (bottom - top)
			this.arrCanvas[idx].left = left + 'px';
			this.arrCanvas[idx].top = top + 'px';
			this.arrCanvas[idx].style.width =  width + 'px';
			this.arrCanvas[idx].style.height =  height + 'px';
			this.arrCanvas[idx].width = width;
			this.arrCanvas[idx].height = height;
			
			redrawRectangle(idx);
		}
	}
	
	function loadRect(coordinates, title) {
		var imagemap = document.getElementById(IMAGEMAPID);
		var coorTokens = coordinates.split(',');
		var left = 0;
		var top = 0;
		var right = 0;
		var bottom = 0;
		var idx = -1;
		var width = 0;
		var height = 0;

		if (coorTokens == null) {
			return;
		}

		// expect 4 points
		if (coorTokens.length != 4) {
			return;
		}
		
		left = parseInt(coorTokens[0], 10);
		top = parseInt(coorTokens[1], 10);
		right = parseInt(coorTokens[2], 10);
		bottom = parseInt(coorTokens[3], 10);
		width = right - left;
		height = bottom - top;
		
		idx = createNewCanvas(left, top, SHAPE_RECTANGLE);
		createNewShape(SHAPE_RECTANGLE);
		createNewLabel(left + Math.floor(width/2), top + Math.floor(height/2), (idx+1));
		setShowFill(idx);
		setTitle(idx, title);

		imagemap.appendChild(this.arrCanvas[idx]);
		imagemap.appendChild(this.arrLabels[idx]);		
		
		storeLoadedRectanglePoints(idx, left, top, right, bottom);
		drawRectangle(idx, left, top, right, bottom);		
	}
	
	function loadCircle(coordinates, title) {
		var imagemap = document.getElementById(IMAGEMAPID);
		var coorTokens = coordinates.split(',');
		var cX = 0;
		var cY = 0;
		var radius = 0;
		var idx = -1;

		if (coorTokens == null) {
			return;
		}

		// expect 3 points
		if (coorTokens.length != 3) {
			return;
		}
		
		cX = parseInt(coorTokens[0], 10);
		cY = parseInt(coorTokens[1], 10);
		radius = parseInt(coorTokens[2], 10);
		
		idx = createNewCanvas(cX - radius, cY - radius, SHAPE_CIRCLE);
		createNewShape(SHAPE_CIRCLE);
		createNewLabel(cX, cY, (idx+1));
		setShowFill(idx);
		setTitle(idx, title);
		
		imagemap.appendChild(this.arrCanvas[idx]);
		imagemap.appendChild(this.arrLabels[idx]);
		
		storeLoadedCirclePoints(idx, cX - radius, cY - radius, cX + radius, cY + radius);
		drawCircle(idx, cX - radius, cY - radius, radius * 2);
	}
	
	function loadPolygon(coordinates, title) {
		var imagemap = document.getElementById(IMAGEMAPID);
		var coorTokens = coordinates.split(',');
		var points = [];
		var idx = -1;
		
		if (coorTokens == null) {
			return;
		}
		
		// expect pairs of x,y coordinate
		if (coorTokens.length % 2 != 0 && coorTokens.length <= 0) {
			return;
		}
		
		for (i = 0; i < coorTokens.length; i = i + 2) {
			points[i/2] = {};
			points[i/2].x = parseInt(coorTokens[i], 10);
			points[i/2].y = parseInt(coorTokens[i+1], 10);
		}
		idx = createNewCanvas(0, 0, SHAPE_POLYGON);
		createNewShape(SHAPE_POLYGON);
		setShowFill(idx);
		setTitle(idx, title);

		imagemap.appendChild(this.arrCanvas[idx]);

		for (i = 0; i < points.length; i++) {
			addPointToShape(idx, points[i].x, points[i].y);
		}

		createNewLabel(0, 0, (idx+1));
		imagemap.appendChild(this.arrLabels[idx]);		
		
		// trim will also draw
		trimPolygon(idx);
	}
	
	function resetShape(idx) {
		if (idx != -1 && idx < this.arrShapes.length && idx < this.arrCanvas.length) {
			this.arrCanvas[idx].style.left = 0  + 'px';
			this.arrCanvas[idx].style.top  = 0  + 'px';

			this.arrCanvas[idx].style.width  = 0  + 'px';
			this.arrCanvas[idx].style.height = 0  + 'px';
			this.arrCanvas[idx].width  = 0;
			this.arrCanvas[idx].height = 0;

			this.arrShapes[idx].points = [];
			this.arrShapes[idx].shape = this.newShape;
		}
	}
	
	function forceEndMapping() {
		if (this.curIndex != -1) {
			if (this.newShape == SHAPE_RECTANGLE) {
				endMappingRectangle(this.curIndex, true);
			}
			else if (this.newShape == SHAPE_CIRCLE) {
				endMappingCircle(this.curIndex, true);
			}
			else if (this.newShape == SHAPE_POLYGON) {
				addPointToShape(this.curIndex, this.lastPolygonPoint.x, this.lastPolygonPoint.y);
				endMappingPolygon(this.curIndex, true);
			}
			this.curIndex = -1;
		}	
	}
	
	function onKeyDown(e) {
		if (this.selectedArea != -1) {
			var keyCode = 0;
			if (this.isIE == true) {
				keyCode = event.keyCode;
			}
			else {
				keyCode = e.keyCode;
			}
			
			if (keyCode == KEYCODE_DELETE) {
				if (this.callbackDelete != null) {
					this.callbackDelete(this.selectedArea);
				}
				else {
					ImageMapRemoveShape(this.selectedArea);
				}				
			}
		}		
	}
	
	function ImageMapAddExistingShape(coordinates, shape, title) {
		if (shape == SHAPE_RECTANGLE_STRING) {
			loadRect(coordinates, title);
		}
		else if (shape == SHAPE_CIRCLE_STRING) {
			loadCircle(coordinates, title);
		}
		else if (shape == SHAPE_POLYGON_STRING) {
			loadPolygon(coordinates, title);
		}
	}
	
	function ImageMapRemoveShape(id) {
		var imagemap = null;
		if (id < this.arrShapes.length && id < this.arrCanvas.length) {
			imagemap = document.getElementById(IMAGEMAPID);
			imagemap.removeChild(this.arrCanvas[id]);

			this.arrCanvas[id].onmousemove = null;
			this.arrCanvas[id].onmousedown = null;
			this.arrCanvas[id] = null;
						
			this.arrShapes[id] = null;
		}
		if (id < this.arrLabels.length) {
			imagemap = document.getElementById(IMAGEMAPID);
			imagemap.removeChild(this.arrLabels[id]);
			
			this.arrLabels[id] = null;
		}
		
		if (id == this.curIndex) {
			resetVariables();
		}
		if (id == this.selectedArea) {
			this.selectedArea = -1;
			sendCallBackSelect();
		}		
	}
	
	function ImageMapChangeShape(idx, shape) {
		if (shape == SHAPE_POLYGON_STRING) {
			this.newShape = SHAPE_POLYGON;			
		}
		else if (shape == SHAPE_CIRCLE_STRING) {
			this.newShape = SHAPE_CIRCLE;
		}
		else if (shape == SHAPE_RECTANGLE_STRING) {
			this.newShape = SHAPE_RECTANGLE;
		}
		resetShape(idx);
	}
	
	function ImageMapSetNewShape(shape) {
		forceEndMapping();
			
		if (shape == SHAPE_POLYGON_STRING) {
			this.newShape = SHAPE_POLYGON;
		}
		else if (shape == SHAPE_CIRCLE_STRING) {
			this.newShape = SHAPE_CIRCLE;
		}
		else if (shape == SHAPE_RECTANGLE_STRING) {
			this.newShape = SHAPE_RECTANGLE;
		}
		else {
			this.newShape = SHAPE_NONE;
		}	
	}	
	
	function ImageMapSetTitle(idx, title) {
		setTitle(idx, title);
	}
	
	function ImageMapGetSelectedArea() {
		return this.selectedArea;
	}
	
	function ImageMapSetShowFill(idx) {
		setShowFill(idx);
		redraw(idx);
	}

	function ImageMapSetShadeColor(newShade) {
		this.shade = newShade;
	}