// Copyright 2012 Google Inc.

/**
 * @author Chris Broadfoot (Google)
 * @fileoverview
 * Allows developers to specify a static set of stores to be used in the
 * storelocator.
 */

/**
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


/**
 * A DataFeed with a static set of stores. Provides sorting of stores by
 * proximity and feature filtering (store must have <em>all</em> features from
 * the filter).
 * @example <pre>
 * var dataFeed = new storeLocator.StaticDataFeed();
 * jQuery.getJSON('stores.json', function(json) {
 *   var stores = parseStores(json);
 *   dataFeed.setStores(stores);
 * });
 * new storeLocator.View(map, dataFeed);
 * </pre>
 * @implements {storeLocator.DataFeed}
 * @constructor
 * @implements storeLocator_StaticDataFeed
 */
storeLocator.StaticDataFeed = function() {
  /**
   * The static list of stores.
   * @private
   * @type {Array.<storeLocator.Store>}
   */
  this.stores_ = [];
  this.referencePoint;
  this.storeType = null;
};
storeLocator['StaticDataFeed'] = storeLocator.StaticDataFeed;

/**
 * This will contain a callback to be called if getStores was called before
 * setStores (i.e. if the map is waiting for data from the data source).
 * @private
 * @type {Function}
 */
storeLocator.StaticDataFeed.prototype.firstCallback_;

/**
 * Set the stores for this data feed.
 * @param {!Array.<!storeLocator.Store>} stores  the stores for this data feed.
 */
storeLocator.StaticDataFeed.prototype.setStores = function(stores) {
  this.stores_ = stores;
  if (this.firstCallback_) {
    this.firstCallback_();
  } else {
    delete this.firstCallback_;
  }
};

/**
 * @inheritDoc
 */
storeLocator.StaticDataFeed.prototype.getStores = function(bounds, features,
    callback) {

  // Prevent race condition - if getStores is called before stores are loaded.
  if (!this.stores_.length) {
    var that = this;
    this.firstCallback_ = function() {
      that.getStores(bounds, features, callback);
    };
    return;
  }

  // Filter stores for features.
  var stores = [];
  //alert(this.getStoreType());
  for (var i = 0, store; store = this.stores_[i]; i++) {
	  
    //if (store.hasAllFeatures(features)) {
	if(this.getStoreType()==null || this.getStoreType()=="" || store.getProp('storeType')== this.getStoreType()){  
		if(!this.getReferencePoint()){
			this.setReferencePoint(store.getLocation());
		}
    	store.setDistance(this.distanceTo(this.getReferencePoint(), store));
        stores.push(store);
    }
  }
  
  //this.sortByDistance_(this.getReferencePoint(), stores);
  //this.sortStoreTypeByDistance_(stores);
  callback(this.sortStoreTypeByDistance_(stores));
};


storeLocator.StaticDataFeed.prototype.alertList = function(stores) {
	for (var i = 0, store; store = stores[i]; i++) {
		alert(store.getProp('storeType') +" "+store.getProp('storename')+" "+store.getDistance());
	}
	alert(stores.length);
};

storeLocator.StaticDataFeed.prototype.sortStoreTypeByDistance_ = function(stores) {
	var allStores = [];
	var storesByType = [];
	var type = "";
	for (var i = 0, store; store = stores[i]; i++) {
		if(i != 0 && type != stores[i].getProp('storeType')){
			this.sortByDistance_(this.getReferencePoint(), storesByType);
			if(storesByType.length > 0){
			for (var j = 0, storesByType; storej = storesByType[j]; j++) {
				allStores.push(storej);
				}
			}
			storesByType = [];
		}
		storesByType.push(store);
		type = store.getProp('storeType');
	}
	if(storesByType.length > 0){
		this.sortByDistance_(this.getReferencePoint(), storesByType);
		for (var i = 0, storesByType; store = storesByType[i]; i++) {
			allStores.push(store);
		}
	}
	return allStores;
};

/**
 * Sorts a list of given stores by distance from a point in ascending order.
 * Directly manipulates the given array (has side effects).
 * @private
 * @param {google.maps.LatLng} latLng the point to sort from.
 * @param {!Array.<!storeLocator.Store>} stores  the stores to sort.
 */
storeLocator.StaticDataFeed.prototype.sortByDistance_ = function(latLng,
    stores) {
  stores.sort(function(a, b) {
    return a.getDistance() - b.getDistance();
  });
	
};

storeLocator.StaticDataFeed.prototype.distanceTo = function(point, store) {
	  var R = 6371; // mean radius of earth
	  var location = store.getLocation();
	  var lat1 = storeLocator.toRad_(location.lat());
	  var lon1 = storeLocator.toRad_(location.lng());
	  var lat2 = storeLocator.toRad_(point.lat());
	  var lon2 = storeLocator.toRad_(point.lng());
	  var dLat = lat2 - lat1;
	  var dLon = lon2 - lon1;

	  var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
	          Math.cos(lat1) * Math.cos(lat2) *
	          Math.sin(dLon / 2) * Math.sin(dLon / 2);
	  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
	  return R * c;
	};

storeLocator.StaticDataFeed.prototype.setReferencePoint = function(position){
	this.referencePoint = position;
};

storeLocator.StaticDataFeed.prototype.getReferencePoint = function(){
	return this.referencePoint;
};

storeLocator.StaticDataFeed.prototype.setStoreType = function(storeType){
	this.storeType = storeType;
};

storeLocator.StaticDataFeed.prototype.getStoreType = function(){
	return this.storeType;
};

