/* 
 *  IEC Widgets 
 *  This will create/instantiates all iecWidgets. 
 *   
 *  Author: Efren Jamolod 
 *  Date:   11/25/2013 
 */
  
$.iec = $.iec || {}; 
(function($){ 
    $.fn.iecWidgets = function() { 
        var IEC_WIDGET_CLASS = '.iecWidget'; 
          
        //instantiate iecBaseWidget 
        $.iec.iecBaseWidget(); 
          
        return $(IEC_WIDGET_CLASS, this).each(function() { 
            var $this = $(this); 
              
            // create widget as campaign banner 
            if ($this.hasClass('iecCampaignBannerWidget')) { 
                $this.iecCampaignBannerWidget(); 
            } 
              
            // create widget as promotion banner 
            else if ($this.hasClass('iecPromotionBannerWidget')) { 
                $this.iecPromotionBannerWidget(); 
            } 
              
            // create widget as item recommendations  
            else if ($this.hasClass('iecItemRecommendationWidget')) { 
                $this.iecItemRecommendationWidget(); 
            } 
              
            // create widget as user activity log  
            else if ($this.hasClass('iecUserActivityLogWidget')) { 
                $this.iecUserActivityLogWidget(); 
            } 
            
			// create widget as item descriptions
            else if ($this.hasClass('iecItemDetailsWidget')) { 
                $this.iecItemDetailsWidget(); 
            }			
              
        }); 
    }; 
  
}(jQuery));