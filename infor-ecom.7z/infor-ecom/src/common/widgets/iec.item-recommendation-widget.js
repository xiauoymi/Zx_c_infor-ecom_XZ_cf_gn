/*
 *  IEC Item Recommendation Widget
 *  This will load recommendations from the specified URL in the 'source' option.
 *  
 * 	Author: Efren Jamolod
 *  Date:	11/25/2013
 */

$.iec = $.iec || {};
(function($) {
	$.widget("iec.iecItemRecommendationWidget", $.iec.iecBaseWidget, {
		
		// Defaults settings
		defaults : {
			'source' : 'GetRecommendations.jsp'
		},
		

		// Set up the widget
		_create : function() {
			//Merge defaults and data attributes
			this._mergeOptions(this.defaults);
			
			// Load recommendations
			if (!$(this.element).is('.loaded') || this.options.reload) {
				this._loadRecommendations();
			}
		},
		

		// Perform Ajax call to load recommendations based on widget attributes
		_loadRecommendations : function() {
			var thisWidget = this;
			
			//do 'get' ajax call
			$.get(
				thisWidget.options.source + '?' + gCsrfTokenUrlParam,
				thisWidget.options,
				function(data) {
					thisWidget._renderRecommendations(data);
				}
			);
		},

		// Render response recommendations
		_renderRecommendations : function(response) {
			var thisWidgetElem = $(this.element);
			thisWidgetElem.html(response);
			thisWidgetElem.addClass('loaded');
		}

	}); // END OF '$.widget()' 

}(jQuery));