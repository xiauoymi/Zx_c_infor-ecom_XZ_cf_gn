/*
   For Tag Library List - Buttons Behavior
*/
	
	function modifyStartAndEndDateField(viewType, firstDay, lastDay){
				if(viewType == 'thisQuarter'){					
					document.getElementById('begdate').value = firstDay;
					document.getElementById('enddate').value = lastDay;
				} else if (viewType == 'thisYear') {
					document.getElementById('begdate').value = firstDay;
					document.getElementById('enddate').value = lastDay;
				} else if (viewType == 'thisMonth') {
					document.getElementById('begdate').value = firstDay;
					document.getElementById('enddate').value = lastDay;
				} else {
					document.getElementById('begdate').value = '';
					document.getElementById('enddate').value = '';
				}
			}

	function showAddOnSearchFields() { 
		var divEle = document.getElementsByTagName('div');
		for (var i=0; i<divEle.length; i++) {
			if(divEle[i].className == 'listfilterfielddiv hide'){
				divEle[i].className = 'listfilterfielddiv show';
				document.getElementById('advButtonFields').value = 'show';				
			} else if (divEle[i].className == 'listfilterfielddiv show') {
				divEle[i].className = 'listfilterfielddiv hide';
				document.getElementById('advButtonFields').value = 'hide';
			}
			
			if(divEle[i].className == 'hideDiv buttonAlignRight'){
				divEle[i].className = 'showDiv buttonAlignRight';
			} else if (divEle[i].className == 'showDiv buttonAlignRight') {
				divEle[i].className = 'hideDiv buttonAlignRight';
			}
			if(divEle[i].className == 'floatLeftViewByHide'){
				divEle[i].className = 'floatLeftViewByShow';
			} else if (divEle[i].className == 'floatLeftViewByShow') {
				divEle[i].className = 'floatLeftViewByHide';
			}
		}
		if(document.getElementById('trImgId') != null){
			var trImgEle = document.getElementById('trImgId');
			if(trImgEle.className == 'hideDiv'){
				trImgEle.className = 'show';
			} else {
				trImgEle.className = 'hideDiv';
			}
		}
	
	
	}
	
	function toggleButtonImage(){
		var buttonID = document.getElementById('advanceSearch');
		if(buttonID.className == 'isolateButtonSpacing tabular_entry_button buttonToggleExpand'){
			buttonID.className = 'isolateButtonSpacing tabular_entry_button buttonToggleCollapse ';
		} else {
			buttonID.className = 'isolateButtonSpacing tabular_entry_button buttonToggleExpand';
		}
	}

	function showSelectedButton(id, type, token, arrayIECIds, filterFieldIds){	
		var viewIds;
		var isContinue = true;
		var viewTypeIds = ['activeOrders', 'thisQuarter', 'thisYear', 'all'];
		viewIds = viewTypeIds.concat(arrayIECIds);
				
		if(isContinue){
			for (var i=0; i < viewIds.length; i++) {
				var buttonID = document.getElementById(viewIds[i]);
				if(buttonID != null){
					if(id == viewIds[i]){
						if(viewIds[i] == 'thisQuarter' || viewIds[i] == 'orderNumber') {
							buttonID.className = 'nonTabularButtonSpacing tabular_entry_button  tabularButtonSelect';
						} else {
							buttonID.className = 'tabular_entry_button  tabularButtonSelect';
						}
					} else {
						if(viewIds[i] == 'thisQuarter' || viewIds[i] == 'orderNumber') {
							buttonID.className = 'nonTabularButtonSpacing tabular_entry_button';
						} else {
							buttonID.className = 'tabular_entry_button';
						}
					}				
				}
			}		
		}
		setHiddenFieldValue(id, type, token, filterFieldIds);
	}
	
	function setHiddenFieldValue(hiddenFieldValue, hiddenFieldId, token, filterFieldIds){

		if(hiddenFieldValue != '' && hiddenFieldId != ''){
			// set search criteria for selected button
			document.getElementById(hiddenFieldId).value = hiddenFieldValue;
			//alert(document.getElementById(hiddenFieldId).value);
		}
		
		var hidViewType = document.getElementById('ViewType').value;
		var hidOrganizeType = document.getElementById('OrganizeType').value;
		var hidAdvButFields = document.getElementById('advButtonFields').value;

		//ReUse functionality of serversidedhtml.js
		var url = "defaultOrderViewValues.jsp?"+token+"&defViewType="+hidViewType+"&defOrganizeType="+hidOrganizeType+"&defAdvButFields="+hidAdvButFields;
		var xmlhttp=false;
		if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
			xmlhttp = new XMLHttpRequest();
		}
		
		var strFilterFields = "&";
		for (var i=0; i < filterFieldIds.length; i++) {
			strFilterFields = strFilterFields + filterFieldIds[i]+'='+document.getElementById(filterFieldIds[i]).value;
			if((i+1) <filterFieldIds.length ){
				strFilterFields = strFilterFields + '&';
			}
		}
		
		xmlhttp.open("GET", url+strFilterFields , false);
		xmlhttp.send(null);

		document.previousOrderSearchForm.submit();

	}
	
	// Array of Ids to Add into the Database
		var arrayIdsToAdd = new Array();
		// Arrays of Ids to Remove from the Database
		var arrayIdsToRemove = new Array(); 
		// Change to True to show alert boxes!
		var isDebugIds = false;
		// Determine if there are changes made in the selection
		var hasChanges = false;
		
		var imgFalse = '../common/style-bc/09_checkbox_rest.gif';
		var imgTrue = '../common/style-bc/09_checkbox_active.gif';
		//change the checkbox status and the replacement image
		function checkChange(i, codeIds) {
			
			hasCheckChange = true;
			
			var checkBoxId = 'checkBox'+i;
			var checkBoxImgId = 'checkImage'+i;
			var checkBox = document.getElementById(checkBoxId);
			var checkBoxImage = document.getElementById(checkBoxImgId);
			var checkedValue = checkBox.checked;
			var chckImgSrc = checkBoxImage.src;
			
			// Used for IE defect for JS indexOf			
			if (!Array.prototype.indexOf) {
			  Array.prototype.indexOf = function(elt /*, from*/)
			  {
				var len = this.length >>> 0;

				var from = Number(arguments[1]) || 0;
				from = (from < 0)
					 ? Math.ceil(from)
					 : Math.floor(from);
				if (from < 0)
				  from += len;

				for (; from < len; from++)
				{
				  if (from in this &&
					  this[from] === elt)
					return from;
				}
				return -1;
			  };
			}

			if(chckImgSrc.indexOf('09_checkbox_rest.gif') == -1){
				// exist check true
				document.getElementById(checkBoxId).checked  = false;
				checkBoxImage.src = imgFalse;
				//Remove Id Selected
				iecUserCodeToRemove(codeIds);
			} else {
				// not exist check false
				document.getElementById(checkBoxId).checked  = true;
				checkBoxImage.src = imgTrue;
				// Add Id Selected
				iecUserCodeToAdd(codeIds);	
			}
			validateChanges();
		}
		
		// Checks if there Ids to add or remove from the database
		function validateChanges(){             
			if(arrayIdsToAdd.length > 0 || arrayIdsToRemove.length > 0){
				hasChanges = true;
			} else if(arrayIdsToRemove.length == 0 && arrayIdsToAdd.length == 0){
				hasChanges = false;
			}
			
			if(isDebugIds){
				if(arrayIdsToAdd.length > 0){
					alert('Added Ids - '+arrayIdsToAdd);
				}
				if(arrayIdsToRemove.length > 0){
					//alert('Removed Ids - '+arrayIdsToRemove);
				}
			}
		}
		
		function createFieldsToUpdateDelete(userId){
	
			var inputHidId;
			var inputCodeId;
			var inputUserId ;
			
			if(arrayIdsToAdd.length > 0){
				inputHidId = document.createElement("input");
				inputHidId.setAttribute("type", "hidden");
				inputHidId.setAttribute("name", "@update@comp.UpdateIECUserCOStatus");
				inputHidId.setAttribute("value", "Update");
				document.getElementById("previousOrderSearchFormId").appendChild(inputHidId);
				
			}
			
			if(arrayIdsToRemove.length > 0){
				inputHidId = document.createElement("input");
				inputHidId.setAttribute("type", "hidden");
				inputHidId.setAttribute("name", "@delete@comp.DeleteIECUserCOStatus");
				inputHidId.setAttribute("value", "delete");
				document.getElementById("previousOrderSearchFormId").appendChild(inputHidId);
			}
			var counter = 1;
			var x = arrayIdsToAdd.length;
			// Ids To Add
			for(var i=0; i<x; i++){
				var codeIdToAdd = arrayIdsToAdd[i];
				var CodeId = codeIdToAdd.split("_")[0];

				inputCodeId = document.createElement("input");
				inputCodeId.setAttribute("type", "hidden");
				inputCodeId.setAttribute("name", "@field.CodeID@key.+NEW"+counter+"@comp.UpdateIECUserCOStatus");
				inputCodeId.setAttribute("value", CodeId);
				document.getElementById("previousOrderSearchFormId").appendChild(inputCodeId);
				
				inputUserId = document.createElement("input");
				inputUserId.setAttribute("type", "hidden");
				inputUserId.setAttribute("name", "@field.UserID@key.+NEW"+counter+"@comp.UpdateIECUserCOStatus");
				inputUserId.setAttribute("value", userId);
				
				document.getElementById("previousOrderSearchFormId").appendChild(inputUserId);
				counter++;
			}
			
			var y = arrayIdsToRemove.length;
			var counter = 1;
			
			// Ids To Remove
			for(var i=0; i<y; i++){
				var codeIdToRemove = arrayIdsToRemove[i];
				var IECUserCOStatId = codeIdToRemove.split("_")[1];
				
				inputHidId = document.createElement("input");
				inputHidId.setAttribute("type", "hidden");
				inputHidId.setAttribute("name", "@field.ID@key!deletekeyDeleteIECUserCOStatus"+counter+"@delete@comp.DeleteIECUserCOStatus");
				inputHidId.setAttribute("value", "");
				document.getElementById("previousOrderSearchFormId").appendChild(inputHidId);
				
				inputHidId = document.createElement("input");
				inputHidId.setAttribute("type", "hidden");
				inputHidId.setAttribute("name", "deletekeyDeleteIECUserCOStatus"+counter);
				inputHidId.setAttribute("value", "="+IECUserCOStatId);
				
				document.getElementById("previousOrderSearchFormId").appendChild(inputHidId);
				counter++;
			}
		}
		
		function iecUserCodeToAdd(codeIds){
			// Used for IE defect for JS indexOf			
			if (!Array.prototype.indexOf) {
			  Array.prototype.indexOf = function(elt /*, from*/)
			  {
				var len = this.length >>> 0;

				var from = Number(arguments[1]) || 0;
				from = (from < 0)
					 ? Math.ceil(from)
					 : Math.floor(from);
				if (from < 0)
				  from += len;

				for (; from < len; from++)
				{
				  if (from in this &&
					  this[from] === elt)
					return from;
				}
				return -1;
			  };
			}
			
			var index = arrayIdsToAdd.indexOf(codeIds);
			//alert('add ' + codeIds+ ' ' +index);
			if(index == -1){
				// Does not Exist in Array | ID Still not yet save in DB
				//if(codeIds.split("_")[1] == '0'){
					arrayIdsToAdd.push(codeIds);
				//}
			} 
			/*index = arrayIdsToRemove.indexOf(codeIds);
			if(index != -1){
				arrayIdsToRemove.splice(index, 1);
			}*/
			arrayIdsToRemove = jQuery.grep(arrayIdsToRemove, function (a) {
        		return a != codeIds; 
    		});
			
			
		}
		
		function iecUserCodeToRemove(codeIds){
			// Used for IE defect for JS indexOf			
			if (!Array.prototype.indexOf) {
			  Array.prototype.indexOf = function(elt /*, from*/)
			  {
				var len = this.length >>> 0;

				var from = Number(arguments[1]) || 0;
				from = (from < 0)
					 ? Math.ceil(from)
					 : Math.floor(from);
				if (from < 0)
				  from += len;

				for (; from < len; from++)
				{
				  if (from in this &&
					  this[from] === elt)
					return from;
				}
				return -1;
			  };
			}
			var index = arrayIdsToRemove.indexOf(codeIds);
			//alert('remove ' + codeIds+ ' ' +index);
			if(index == -1){
				// Does not Exist in Array | ID already save in DB 
				//if(codeIds.split("_")[1] != '0'){
					arrayIdsToRemove.push(codeIds);
				//}
			}
			/*index = arrayIdsToAdd.indexOf(codeIds);
			if(index != -1){
				arrayIdsToAdd.splice(index, 1);
			}*/
			arrayIdsToAdd = jQuery.grep(arrayIdsToAdd, function (a) {
        		return a != codeIds; 
    		});
		}
	
	
	
	