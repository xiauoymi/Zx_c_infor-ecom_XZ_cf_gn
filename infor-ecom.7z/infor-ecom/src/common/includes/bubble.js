function Bubble(textBoxId, divContentId, sticky) {
	this.bubbleParent = document.getElementById(textBoxId);
	this.contentElement = document.getElementById(divContentId);
	this.isSticky = sticky;
}

Bubble.prototype.createNewContainer = Bubble_createNewContainer;
Bubble.prototype.show = Bubble_show;
Bubble.prototype.hide = Bubble_hide;
Bubble.prototype.hideOnMouseOut = Bubble_hideOnMouseOut;
Bubble.prototype.setLeft = Bubble_setLeft;
Bubble.prototype.setTop = Bubble_setTop;

function Bubble_hideOnMouseOut() {
	var oldOnmouseout = this.bubbleParent.onmouseout;
	this.bubbleParent.bubble = this;
	
	if (typeof this.bubbleParent.onmouseout != 'function') {
		this.bubbleParent.onmouseout = function() { this.bubble.hide(); };
	} else {
		this.bubbleParent.onmouseout = function() {
			oldOnmouseout();
			this.bubble.hide();
		}
	}
}

function Bubble_hide() {
  this.showing = false; 
  this.contentElement.style.display = "none";
  this.container.style.display = "none";  
}

function Bubble_show() {
	if (!this.showing) {
		if (!this.container) {
			this.createNewContainer();
			this.bubbleParent.parentNode.appendChild(this.container);			
			this.contentElement.parentNode.insertBefore(this.container, this.contentElement.nextSibling);		
			this.contentElement.parentNode.removeChild(this.contentElement);		
			this.midDiv.appendChild(this.contentElement);				
			if (!this.isSticky) this.hideOnMouseOut();
		}
		
		this.arrowDiv.style.width = "";
		this.midDiv.style.width = "";		
		this.topDiv.style.width = "";
		this.bottomDiv.style.width = "";
		
		this.contentElement.style.display = "";
		
		this.setLeft(0);
		this.container.style.display = "";
			
		var w = this.contentElement.offsetWidth;		
		this.arrowDiv.style.width = (w + 30) + "px";
		this.midDiv.style.width = w + "px";		
		this.topDiv.style.width = w + "px";
		this.bottomDiv.style.width = w + "px";
		
		this.showing = true;
	}
}

function Bubble_setLeft(xcoord) {
	this.container.style.left = xcoord + "px";
}

function Bubble_setTop(ycoord) {
	this.container.style.top = ycoord + "px";
}

function Bubble_createNewContainer() {
	var topDiv = document.createElement("DIV"); 
	topDiv.className = 'bubble_top';	

	var topRightDiv = document.createElement("DIV");
	topRightDiv.className = 'bubble_topright';
	topRightDiv.appendChild(topDiv);
	
	var mainDiv = document.createElement("DIV"); 
	mainDiv.id = 'bubbleMain_' + this.contentElement.id;
	mainDiv.className = 'bubble_main';
	
	var closeImg = document.createElement("IMG");
	closeImg.src = "../common/style/orderbook_delete.gif";		
	
	var closeAnchor = document.createElement("A");
	closeAnchor.onclick = function() { this.bubble.hide(); };
	//closeAnchor.href = "#";
	closeAnchor.bubble = this;
	closeAnchor.appendChild(closeImg);
	
	var closeDiv = document.createElement("DIV"); 
	closeDiv.className = 'bubble_close';
	closeDiv.appendChild(closeAnchor);
			
	var arrowDiv = document.createElement("DIV"); 
	arrowDiv.className = 'bubble_arrow';
	
	var topLeftDiv = document.createElement("DIV");
	topLeftDiv.className = 'bubble_topleft';
	topLeftDiv.appendChild(topRightDiv);
	topLeftDiv.appendChild(arrowDiv);	
	if (this.isSticky) {
		topLeftDiv.appendChild(closeDiv);
	} 
	
	var midDiv = document.createElement("DIV"); 
	midDiv.className = 'bubble_mid';	
	midDiv.style.maxWidth = "350px";	
	midDiv.style.minWidth = "240px";	
	
	var rightDiv = document.createElement("DIV"); 
	rightDiv.className = 'bubble_right';
	rightDiv.appendChild(midDiv);
	
	var leftDiv = document.createElement("DIV"); 
	leftDiv.className = 'bubble_left';
	leftDiv.appendChild(rightDiv);
	
	var bottomDiv = document.createElement("DIV"); 
	bottomDiv.className = 'bubble_bottom';
	
	var bottomRightDiv = document.createElement("DIV"); 
	bottomRightDiv.className = 'bubble_bottomright';
	bottomRightDiv.appendChild(bottomDiv);
	
	var bottomLeftDiv = document.createElement("DIV"); 
	bottomLeftDiv.className = 'bubble_bottomleft';
	bottomLeftDiv.appendChild(bottomRightDiv);
	
	mainDiv.appendChild(topLeftDiv);
	mainDiv.appendChild(leftDiv);
	mainDiv.appendChild(bottomLeftDiv);	
	
	this.container = mainDiv;
	this.midDiv = midDiv;
	this.arrowDiv = arrowDiv;
	this.topDiv = topDiv;
	this.bottomDiv = bottomDiv;
}

function getOffsetPos(element) {
	var xpos = 0;
	var ypos = 0;
	if (element) {
		var elementOffsetParent = element.offsetParent;
		// If the element has an offset parent
		if (elementOffsetParent) {
			// While there is an offset parent
			while ((elementOffsetParent = element.offsetParent)) {
				//offset might give negative in opera when the image is scrolled
				if (element.offsetLeft > 0) {xpos += element.offsetLeft;}
				if (element.offsetTop > 0) {ypos += element.offsetTop;}
				element = elementOffsetParent;
			}
		}
		else {
			xpos = element.offsetLeft;
			ypos = element.offsetTop;
		}
	}

	return {x: xpos, y: ypos};
}
