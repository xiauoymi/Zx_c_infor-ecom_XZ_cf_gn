$(document).ready(function() {
	//loadBanners();
	// banner implementation was moved to iec.banner-widget.js
});

function loadBanners(target, reload) {
	if(target == null) {
		target = $('.bannerHolder');
	}
	
	target.each(
		function() {
			var holder = $(this);
			if(!holder.is('.loaded') || reload ) {
				$.get(holder.data('source') + '?' + gCsrfTokenUrlParam, 
				holder.data(),
				function(response) {
					holder.html(response);
					holder.addClass('loaded');
					holder.addClass(holder.data('sectionName'));
					var banners = $('.banners', holder);
					if(holder.data('rotate') && $('li', banners).length > 1 ) {
						if(holder.data('autoPlay')) {
							var delay = banners.data('delayTime');
							var fade = banners.data('fadeTime');
							banners.slidesjs({
								play: {
									active: true,
									auto: true,
									interval: delay,
									swap: true,
									pauseOnHover: true,
									restartDelay: fade
								}
							});
						} else {
							banners.slidesjs();
						}
					} else {
						banners.slidesjs({
							navigation: {
								active: false
							},
							pagination: {
								active: false
							}
						});
					}
				});
			}
		});
};


