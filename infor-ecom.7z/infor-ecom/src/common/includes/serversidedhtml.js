var xmlhttp;
function getServerSideInfo(url) {
  var xmlhttp=false;
  /*@cc_on @*/
  /*@if (@_jscript_version >= 5)
  // JScript gives us Conditional compilation, we can cope with old IE versions.
  // and security blocked creation of the objects.
  try {
    xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
  } catch (e) {
    try {
      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    } catch (E) {
      xmlhttp = false;
    }
  }
  @end @*/

  if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
    xmlhttp = new XMLHttpRequest();
  }

  xmlhttp.open("GET", url , false);
  xmlhttp.send(null);

  return xmlhttp.responseText;
}

// Each element in optionArray must be an array of size 2 where 
// optionArray[i][0] is the text of the option and 
// optionArray[i][1] is the value of the option. 
function setSelectOptions(the_select, optionArray, selectedValue) {
  var msddHandler = null;
  if ($(the_select).isMsDropDown && $(the_select).isMsDropDown() == true) {
	  msddHandler = $(the_select).msDropDown().data("dd");
  }
	
  if (msddHandler) {
	  //Remove all elements
	  for(i=the_select.length; i>-1; i--){
		  msddHandler.remove(i);
	  }
	  
	  //Insert new elements
	  for (i=0; i < optionArray.length; i++) {
		  
		var _option = new Option(optionArray[i][0],optionArray[i][1]);
		// Set the option
		  msddHandler.add(_option);
		  
		// Set selected option
		  if(_option.value==selectedValue) {
			  msddHandler.set("selectedIndex", i);
		  }
	  }
	  
	  
	  // visibleRows
	  msddHandler.visibleRows(7);
	  msddHandler.refresh();

	  
  }	else {
  // Remove all elements
  for(i=the_select.length; i>-1; i--){
    the_select.remove(i);
  }

  // Insert new elements
  for (i=0; i < optionArray.length; i++)
  {
    var _option = new Option(optionArray[i][0],optionArray[i][1]);

    // Set the option
    the_select.options[i] = _option;

    // Set selected option
    if(_option.value==selectedValue)
      the_select.selectedIndex = i;
  }
  }
}

// As the replace method in the String object is not working properly
// we have to create our own.
function replaceAll(str,matchstr,newstr){
  tmp = str;
  while(tmp.indexOf(matchstr)!=-1){
    tmp = tmp.replace(matchstr,newstr);
  }
  return tmp;
}
