/*
 *  All generic/global scripts that needs to be triggered on document ready.
 *  
 * 	Author: Efren Jamolod
 *  Date:	11/27/2013
 */

$(document).ready(function() {
	
	//initialize all iecWidgets
	$(document).iecWidgets();
	
	//Flag is window is active
	(function() {
		$.windowActive = true;
		$.isWindowActive = function () {
		    return $.windowActive;
		};
		$(window).focus(function() {
		    $.windowActive = true;
		});
		$(window).hover(function() {
		    $.windowActive = true;
		});
		$(window).blur(function() {
		    $.windowActive = false;
		});
		$(window).mouseout(function() {
		    $.windowActive = false;
		});
	})();
	
});
