<script type="text/javascript">

function setComboBoxValue(box_id, value) {
    var parent_box = document.getElementById(box_id + "_parent");
    var input_box = document.getElementById(box_id + "_dispVal"); 
    var box_value = document.getElementById(box_id + "_value_" + value); 
    if (parent_box && input_box && box_value) {
        var _value = box_value.getAttribute("name");
        if (_value != null) {
            input_box.innerHTML = box_value.innerHTML;

            var hiddenInput = parent_box.getElementsByTagName('input')[0];
            if (hiddenInput) {
                if(_value == '') {
                hiddenInput.value = _value;
                } else {
                hiddenInput.value = _value;
                }
               
            }
           
            box_value.blur();
        }
    }
}

function setMaxNo(box_id, value, thisForm) {
    var parent_box = document.getElementById(box_id + "_parent");
    var input_box = document.getElementById(box_id + "_dispVal"); 
    var box_value = document.getElementById(box_id + "_value_" + value); 
    if (parent_box && input_box && box_value) {
        var _value = box_value.getAttribute("name");
        if (_value) {
            var hiddenInput = parent_box.getElementsByTagName('input')[0];
            if (hiddenInput) {
                hiddenInput.value = _value;
            }
            input_box.innerHTML = box_value.innerHTML;
           
            box_value.blur();
            
        }
        document.getElementsByTagName('form')[0].submit();    
    }
}

function showDiv(id) {
    var div = document.getElementById(id);
    if (div) {
        if (div.style.display != 'inline') {
            var onblur = function() {
                var blur = function() {
                    hideDiv(id);
                }
                setTimeout(blur, 100);
            }
            div.style.display = 'block';
            div.onblur = onblur;
            div.focus();
        } else {
            div.onblur = function() {};
            div.style.display = 'none';
        }
    }
}

function hideDiv(id) {
    var div = document.getElementById(id);
    if (div) {
        if (div.style.display == 'block') {
            div.style.display = 'none';
        }
    }
}

</script>