<script type="text/javascript">

function styleTabs() {
    var tabNumber=1;
    var tabs = document.getElementsByTagName("a");
        for(var i = 0; i < tabs.length; i++) {
            if(tabs[i].parentNode.tagName=="LI") {
                if(tabs[i].parentNode.className=="active"){
                    tabs[i].className = "tab"+(tabNumber)+" active";
                }
                else{
                    tabs[i].className = "tab"+(tabNumber);
                }
                tabNumber++;
			}
		}
    
}
window.onload=styleTabs;
</script>