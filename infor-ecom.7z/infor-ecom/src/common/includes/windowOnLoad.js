<script type="text/javascript">
	$(document).ready(function(){
		//hide colon symbol if label is blank
		$('.entry_label').each(function(){
			var label = $(this).text();
			label = label.replace(/(^\s+|\s+$)/g, "");
			if ($.trim(label) == "") {
				$(this).addClass("blank");
			}
		});
		
		//remove footnotes for readonly/disabled fields
		$('.entry_field :input').each(function(){
			var $input = $(this);
			if (($input.hasClass('readonly') || $input.prop('readonly') || $input.prop('disabled'))
					&& !($input.hasClass('finderInput'))) {
				var $sibling = $input.next();
				if (!$sibling.is('span') || $sibling.is('span.inputRight')) {
					$sibling = $input.parent().next();	
				}
				
				if ($sibling.is('span') && $sibling.hasClass('footnote')) {
					$sibling.hide();
				}
			}
		});
	});

    var woms = new Array();
    
    function womAdd(func){  
        woms[woms.length] = func;
    }
    
    function womOn(){  
        window.onload = womGo;
    }
    
    function womGo(){
	for(var i = 0;i < woms.length;i++)
        try{
            eval(woms[i]);
        }catch(err){}
    }
    
    function checkIfExists(eType,findClass) {
    var aElm=document.getElementsByTagName(eType);
    for(var i=0; i<aElm.length; i++) {
        if(aElm[i].className==findClass || aElm[i].className==' '+findClass) {
            return true;
            }
        }        
            return false;
    }

    function findThisElement(eType,findClass) {
    var aElm=document.body.getElementsByTagName(eType);
    for(var i=0; i<aElm.length; i++) {
        if(aElm[i].className==findClass || aElm[i].className==' '+findClass) {
            return aElm[i];
            }
        }        
    }

    function leftCornerHilight(){
      var fElem = checkIfExists('th','first sorted');
      if(fElem) {
      var corElem = document.getElementById('entry_iteratorheader_left');
      corElem.className = 'entry_iteratorheader_left_hilighted';
      }

      }
    function RightCornerHilight(){
     var lElem = checkIfExists('th','sorted');
     if(lElem) {
     var beforeRCorner = findThisElement('th','sorted');
         var rightCornerTag;
            if(beforeRCorner.nextSibling.nodeType == 3)
                rightCornerTag = beforeRCorner.nextSibling.nextSibling;
            
            else rightCornerTag = beforeRCorner.nextSibling;

            if (rightCornerTag.className == 'entry_iteratorheader_right') {
                 rightCornerTag.className = 'entry_iteratorheader_right_hilighted';
            }
       }
    }

    function ListHeaderTextHilightOnMouseover() {
      var hTextList = document.body.getElementsByTagName('nobr');
        if(hTextList) {
          for(var i=0; i<hTextList.length; i++) {
            if (hTextList[i].parentNode.tagName=='SPAN' || hTextList[i].parentNode.tagName=='span' ) {
            hTextList[i].onmouseover= function() {this.style.color='#0065A4';};
            hTextList[i].onmouseout= function() {this.style.color='#FFFFFF';};
            }
          }
        }
    }
    
    function is_ie() {
    	return false;
      //var agt = navigator.userAgent.toLowerCase();
      //return ((agt.indexOf("msie") != -1) && (agt.indexOf("opera") == -1));
    }
    
    function radioButtonInit(){
        var radioInputs = document.getElementsByTagName("input");
        for(var i = 0; i < radioInputs.length; i++) {
            if(radioInputs[i].getAttribute('type')=="radio"){
                var radioDiv = radioInputs[i].parentNode;
                if(radioDiv && radioDiv.tagName=="DIV"){
                    if(radioInputs[i].checked){
                        radioDiv.style.backgroundPosition = "0 -52px";
                    }else{
                        radioDiv.style.backgroundPosition = "0 0";
                    }
                }
            }
        }
    }
    
    function RemoveLeftBorder(){
        /*var cells = document.getElementsByTagName("td");
        for(var i = 0; i < cells.length; i++) {
            if(cells[i].className=="list_iterator_leftpad" || cells[i].className=="entry_iterator_leftpad"){
                var firstCol = cells[i].nextSibling;
                if(firstCol){
                    firstCol.className = firstCol.className +" first";
                }
            }
        }*/
    }
    
    function doInitTableSize() {
      var oGroupBox = document.getElementsByTagName('Table'); 
      var sClassName;
      var iCntr = 0;
      var iWidth = 720;
      var sWidth = ((document.body.clientWidth < 735) ? ("720px") : "98%");
      var bIsIE = is_ie();
      var bIsMulticolumnParent = false;
      
      if (oGroupBox.length) {     
        if (!bIsIE) {
          for (var a=0; a < oGroupBox.length; a++){
            bIsMulticolumnParent = false;
            sClassName = oGroupBox[a].className;
            if ((sClassName == "entry_multicolumn") || (sClassName == "group") || (sClassName == "list_iterator") || (sClassName == "entry_iterator")){
              try {
                if (sClassName == "group") {
                  bIsMulticolumnParent = (oGroupBox[a].parentNode.parentNode.parentNode.parentNode.parentNode.className == "entry_multicolumn");
                } 
              } catch (e) {}
              if (!bIsMulticolumnParent) {
                oGroupBox[a].style.minWidth = "720px";
              }              
            }
          }
        } else {
          for (var a=0; a < oGroupBox.length; a++){
            bIsMulticolumnParent = false
            sClassName = oGroupBox[a].className;
            if ((sClassName == "entry_multicolumn") || (sClassName == "group") || (sClassName == "list_iterator") || (sClassName == "entry_iterator")){
              try {
                if (sClassName == "group") {
                  bIsMulticolumnParent = (oGroupBox[a].parentNode.parentNode.parentNode.parentNode.parentNode.className == "entry_multicolumn");
                } 
              } catch (e) {}
              if (!bIsMulticolumnParent) {
                oGroupBox[a].style.minWidth = "720px";
              }
              if (!bIsMulticolumnParent) {
                oGroupBox[a].resizeable = true;              
                if (iCntr == 0) {
                  oGroupBox[a].style.width = sWidth;              
                  iWidth = oGroupBox[a].offsetWidth;              
                  iCntr++;
                } else {
                  oGroupBox[a].style.width = iWidth + "px";
                }
              }
            }
          }
        }
      } else {
        if (oGroupBox != null) {
          sClassName = oGroupBox.className;
          if ((sClassName == "entry_multicolumn") || (sClassName == "group") || (sClassName == "list_iterator") || (sClassName == "entry_iterator")){
            if (!bIsIE) {
              try {
                if (sClassName == "group") {
                  bIsMulticolumnParent = (oGroupBox.parentNode.parentNode.parentNode.parentNode.parentNode.className == "entry_multicolumn");
                } 
              } catch (e) {}
              if (!bIsMulticolumnParent) {
                oGroupBox.style.minWidth = "720px";
              }
            } else {
              try {
                if (sClassName == "group") {
                  bIsMulticolumnParent = (oGroupBox.parentNode.parentNode.parentNode.parentNode.parentNode.className == "entry_multicolumn");
                } 
              } catch (e) {}
              if (!bIsMulticolumnParent) {
                oGroupBox.resizeable = true;
                oGroupBox.style.width = sWidth;
              }
            }
          }
        }
      }
    }
    
    function doResizeTables() {
      var oGroupBox = document.getElementsByTagName('Table'); 
      var iCntr = 0;
      var iWidth = 720;
      var sWidth = ((document.body.clientWidth < 735) ? ("720px") : "98%");
      
      if (oGroupBox.length) {      
        for (var a=0; a < oGroupBox.length; a++) {
          if (oGroupBox[a].resizeable) {
            if (iCntr == 0) {
              oGroupBox[a].style.width = sWidth;
              iWidth = oGroupBox[a].offsetWidth;
              sWidth = iWidth + "px";
              iCntr++;
            } else {
              oGroupBox[a].style.width = sWidth;
            }
          }
        }  
      } else {
        if ((oGroupBox != null) && (oGroupBox.resizeable)) {
          oGroupBox.style.width = sWidth; 
        }
      }
    }
    
    if (is_ie()) {
      onafterprint = doResizeTables;
      onresize = doResizeTables;
    }
    
    womAdd('replaceChecks()');
    womAdd('radioButtonInit()');
    //womAdd('initInputFile()');
    womAdd('Input.initialize()');
    //womAdd('initSelect()');
    //womAdd('styleTabs()');
    //womAdd("initSearchBox('searchBox','input','../common/style-bc/02_input_field_box-s.gif','../common/style-bc/02_input_field_box-3_search.gif')");
	//womAdd("initSearchBox('code','input','../common/style-bc/02_input_field_box-s.gif','../common/style-bc/02_input_field_box-3_search.gif')");
    //womAdd('RemoveLeftBorder()');
    //womAdd('leftCornerHilight()');
    //womAdd('RightCornerHilight()');
    //womAdd('doInitTableSize()');
    //womAdd('ListHeaderTextHilightOnMouseover()');
    womOn();
</script>
