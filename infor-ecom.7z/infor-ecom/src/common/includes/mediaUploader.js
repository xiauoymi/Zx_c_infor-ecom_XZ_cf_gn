// Infor eCom JavaScript File: mediaUploader.js

$(document).ready(function() {
	$('.mediaUploaderPlaceHolder').each(
		function() {
			$(this).mediaUploader($(this).data());
		}
	);
});