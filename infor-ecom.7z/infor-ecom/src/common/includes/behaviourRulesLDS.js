
<script id="thecalendarscript" type="text/javascript">

var dPCount = 0;
var datePickerCal;
var datePattern;
var divObj;
var iframeObj;
var anchorObj;

function instantiateCal(){
	//Creating an instance of CalendarPopUp to use by several date input fields on a page
	datePickerCal = new CalendarPopup("calPopUpDiv");
    datePickerCal.setDayHeaders("Su","Mo","Tu","Wd","Th","Fr","Sa");
	document.datePickerCal = datePickerCal;

	//Setup language
	setUpLang();
	
	//Insert div
	divObj = document.createElement("div");
	divObj.name="calPopUpDiv";
	divObj.frameborder="no";
	divObj.id = "calPopUpDiv";
	divObj.style["z-index"] = "1001";
	divObj.style.zIndex = "1001";
	divObj.style.display= "none";
	divObj.style.position= "absolute";
	divObj.style.backgroundColor= "white";
	divObj.style.layerBackgroundColor= "white";
	divObj.style.width= "176px";
	divObj.style.height= "158px";
    divObj.style.top="119px";
    divObj.style.left="23px";
	document.body.appendChild(divObj);
	
	//Insert Iframe to solve floating select box problem with IE
	iframeObj = document.createElement("iframe");
	iframeObj.name="calPopUpIframe";
	iframeObj.frameborder="no";
	iframeObj.id = "calPopUpIframe";
	iframeObj.style.zIndex = "1000";
	iframeObj.style.display= "none";
	iframeObj.style.position="absolute";
	iframeObj.style.top= "0px";
	iframeObj.style.left= "0px";
	iframeObj.style.width="176px";
	iframeObj.style.height="158px";
	iframeObj.style.borderStyle="none none none none";
	document.body.appendChild(iframeObj);
}

function datePickerImage(){
	var imgObj = document.createElement("IMG");
	imgObj.src = "../common/style-bc/17_datepicker_btncal_rest.gif";
	imgObj.alt = "<%=jsEncode(com.intentia.iec.http.Text.getSiteText(request, "pseudopage", "pickadate"))%>";
    //imgObj.src = "";
    //imgObj.alt = " ";
	imgObj.title = "<%=jsEncode(com.intentia.iec.http.Text.getSiteText(request, "pseudopage", "pickadate"))%>";
	imgObj.border = "0";
	imgObj.name = "datePickerImg";
	imgObj.className = "datePicker";

	imgObj.onmouseover= function(){doMouseOver(imgObj);};
	imgObj.onmouseout = function(){doMouseOut(imgObj);};
	anchorObj.appendChild(imgObj);
	dPCount++;
}

function doMouseOver(img) {
	img.style.cursor='pointer';
	img.src='../common/style-bc/17_datepicker_btncal_hover.gif';
}

function doMouseOut(img) {
	img.style.cursor='default';
	img.src='../common/style-bc/17_datepicker_btncal_rest.gif';
}

var behaviourRules = {
	'input.datepicker' : function(el){
		//First time the function(el) for the datepicker element is called on the page
		if (dPCount == 0) {
			instantiateCal();
		}
		//Each time the function(el) for the datepicker element is called on the page
		var inputObj = el;
		if (!inputObj.id){
		  	 inputObj.id = 'datePickerInput' + (dPCount + 1);
		}
		//Insert anchor
		anchorObj = document.createElement("A");
    		anchorObj.href = "#";
    		anchorObj.id='anchor' + inputObj.id;
    		
    		if (datePickerCal != null){
				anchorObj.onclick = function() {
				//Only enable future dates
				datePickerCal.addDisabledDates(null,formatDate(new Date(new Date().getTime() - 1000 * 60 * 60 * 24),"yyyy-MM-dd"));
				//Disable sundays
				/*
				if (newWeekStartDay==0){
					datePickerCal.setDisabledWeekDays(0);
				}
				else {
					datePickerCal.setDisabledWeekDays(6);
				}
				*/
				datePickerCal.select(document.getElementById(this.id.slice(6)) ,this.id , datePattern);
		  		return false;
			};
		}
		inputObj.parentNode.insertBefore(anchorObj, inputObj.nextSibling);
		
		//Insert datepicker image
		datePickerImage();
	},
	'input.datepickerall' : function(el){
		//First time the function(el) for the datepicker element is called on the page
		if (dPCount == 0) {
			instantiateCal();
		}
		
		//Each time the function(el) for the datepicker element is called on the page
		var inputObj = el;
		if (!inputObj.id){
		  	 inputObj.id = 'datePickerInput' + (dPCount + 1);
		}
		//Insert anchor
		anchorObj = document.createElement("A");
    		anchorObj.href = "#";
    		anchorObj.id='anchor' + inputObj.id;
    		if (datePickerCal != null){
				anchorObj.onclick = function() {
				//No date restrictions
				datePickerCal.disabledDatesExpression = "";
				//No disabled days
				datePickerCal.disabledWeekDays = new Object();	
							
		  		datePickerCal.select(document.getElementById(this.id.slice(6)) ,this.id , datePattern);
		  		return false;
			};
		}
		inputObj.parentNode.insertBefore(anchorObj, inputObj.nextSibling);
		
		//Insert datepicker image
		datePickerImage();
	}
};
Behaviour.register(behaviourRules);


</script>
