function pageWidth() {
  return window.innerWidth != null? window.innerWidth: document.body != null? document.body.clientWidth:null;
}

function getPageOffsetLeft (el) {
  var ol=el.offsetLeft;
  while ((el=el.offsetParent) != null) { ol += el.offsetLeft; }
  return ol;
}

var startList = function() {
  if (document.all&&document.getElementById || true) {
    var uls = document.getElementsByTagName("UL");
    for (var j=0; j<uls.length; j++){
      if(uls[j].className.indexOf("contextmenu") != -1){
        var menuRoot = uls[j]; 
        if (getPageOffsetLeft(menuRoot) + 180 > pageWidth()) {
          menuRoot.className+=" contextmenuright"
        }
        /* Test if IE 5.0 is used */
        if (document.all&&document.getElementById) {
          for (var i=0; i<menuRoot.childNodes.length; i++) {
            var menu = menuRoot.childNodes[i];
  
            /* Set hover functionality on menu */
            if (menu.nodeName=="LI") {
              menu.onmouseover=function() {
                this.className+=" menuover";
              }
              menu.onmouseout=function() {
                this.className=this.className.replace(" menuover", "");
              }
              for (var l=0; l<menu.childNodes.length; l++) {
                if(menu.childNodes[l].nodeName=="UL"){
                  var menuItems = menu.childNodes[l].childNodes;
                  for(var k=0; k<menuItems.length; k++){
                    var menuItem = menuItems[k];
                   /* Set hover functionality on menu item*/
                    if (menuItem.nodeName=="LI") {
                      menuItem.onmouseover=function() {
                        this.className+=" itemover";
                      }
                      menuItem.onmouseout=function() {
                        this.className=this.className.replace(" itemover", "");
                      }
                    }
                  }
                }
              }
            }
          }
        }        
      }
    }
  }
}
window.onload=startList;