
<script id="ValidatePassword" type="text/javascript">
// Copyright (c) 2006 Infor
// Version Infor e-Commerce 5.2

function ValidatePassword(objField, objFieldData)
{
  if ((objFieldData.condition!=null) && (!eval(objFieldData.condition)))
	  return null;
	
  strFirstPasswordField = objFieldData.firstfield
  if (strFirstPasswordField == null)
    return null;

  objFirstPasswordField = objField.form.elements[strFirstPasswordField];
  if (objFirstPasswordField == null)
    for (n = 0; n < objField.form.elements.length; n++)
    {
      objElem = objField.form.elements[n];
      if (objElem.name != null && objElem.name.substring(0,  strFirstPasswordField.length) == strFirstPasswordField)
      {
        objFirstPasswordField = objElem;
        break;
      }
    }

  if (objFirstPasswordField != null && objFirstPasswordField.value != objField.value)
    return {err:"<%=jsEncode(getSiteText(request, "error", "err_password"))%>"};

  return null;
}

gValidationFunctions["password"] = ValidatePassword;

</script>
