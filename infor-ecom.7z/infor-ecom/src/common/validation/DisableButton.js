
<script id="DisableButton" type="text/javascript">
var ButtonHitCount=0;
function disableButton(){
	if (ButtonHitCount == 1){
		return false;
	}
	else{
		 ButtonHitCount = 1;
		 return true;
	}
}
</script>
