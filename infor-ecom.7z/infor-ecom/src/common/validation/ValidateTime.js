
<script id="ValidateTime" type="text/javascript">
// Copyright (c) 2006 Infor
// Version Infor e-Commerce 5.2

function ValidateTime(objField, objFieldData) {

    if ((objFieldData.condition!=null) && (!eval(objFieldData.condition)))
    return null;

    strFieldValue = objField.value;

    if (objFieldData.mandatory == "true" && strFieldValue == "")
    return {err:"<%=jsEncode(getSiteText(request, "error", "err_mandatory"))%>"};


    if (strFieldValue == "")
    return null;

    var timePattern = /^(\d{1,2}):(\d{2})?$/;
    var mArray = strFieldValue.match(timePattern);
    if (mArray == null) {
        return {err:"<%=jsEncode(getSiteText(request, "error", "err_time"))%>"};
    }
    var hour = mArray[1];
    var minute = mArray[2];
    if (hour < 0  || hour > 23) {
        return {err:"<%=jsEncode(getSiteText(request, "error", "err_time"))%>"};
    }

    if (minute<0 || minute > 59) {
        return {err:"<%=jsEncode(getSiteText(request, "error", "err_time"))%>"};
    }

    return null;
}

gValidationFunctions["time"] = ValidateTime;

</script>
