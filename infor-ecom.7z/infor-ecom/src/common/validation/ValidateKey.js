
<script id="ValidateKey" type="text/javascript">
// Copyright (c) 2006 Infor
// Version Infor e-Commerce 5.2

function ValidateKey(objField)
{
  var iChars = '@+="';

  if (objField != null) {
    for (var i = 0; i < objField.value.length; i++) {
      if (iChars.indexOf(objField.value.charAt(i)) != -1) {
        alert ('<%=jsEncode(getSiteText(request, "error", "err_keychar"))%>' + ' ' + iChars);
        objField.focus();
        return false;
      }
    }
  }
  return true;
}

</script>
