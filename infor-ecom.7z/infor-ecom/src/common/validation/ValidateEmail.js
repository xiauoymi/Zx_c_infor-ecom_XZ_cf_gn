
<script id="ValidateEmail" type="text/javascript">
// Copyright (c) 2006 Infor
// Version Infor e-Commerce 5.2

function ValidateEmail(objField, objFieldData)
{
  if ((objFieldData.condition != null) && (!eval(objFieldData.condition)))
    return null;
	
  strFieldValue = objField.value;

  if (objFieldData.mandatory == "true" && strFieldValue == "")
      return {err:"<%=jsEncode(getSiteText(request, "error", "err_mandatory"))%>"};
  if (strFieldValue == "")
    return null;

  strRegExp = objFieldData.invalidregexp;
  if (strRegExp != null)
  {
    re = new RegExp(strRegExp);
    if (re.test(strFieldValue))
      return {err:"<%=jsEncode(getSiteText(request, "error", "err_regexp"))%>", p0:strRegExp};
  }

  nMin = objFieldData.min;
  if (nMin != null && strFieldValue.length < nMin)
    return {err:"<%=jsEncode(getSiteText(request, "error", "err_textmin"))%>", p0:nMin};

  nMax = objFieldData.max;
  if (nMax != null && strFieldValue.length > nMax)
    return {err:"<%=jsEncode(getSiteText(request, "error", "err_textmax"))%>", p0:nMax};

  /* The following pattern is used to check if the entered e-mail address
     fits the user@domain format.  It also is used to separate the username
     from the domain. */
  var emailPat=/^(.+)@(.+)$/
  /* The following string represents the pattern for matching all special
     characters.  We don't want to allow special characters in the address.
     These characters include ( ) < > @ , ; : \ " . [ ]    */
  var specialChars="\\(\\)<>@,;:\\\\\\\"\\.\\[\\]"
  /* The following string represents the range of characters allowed in a
     username or domainname.  It really states which chars aren't allowed. */
  var validChars="\[^\\s" + specialChars + "\]"
  /* The following pattern applies if the "user" is a quoted string (in
     which case, there are no rules about which characters are allowed
     and which aren't; anything goes).  E.g. "jiminy cricket"@disney.com
     is a legal e-mail address. */
  var quotedUser="(\"[^\"]*\")"
  /* The following pattern applies for domains that are IP addresses,
     rather than symbolic names.  E.g. joe@[123.124.233.4] is a legal
     e-mail address. NOTE: The square brackets are required. */
  var ipDomainPat=/^\[(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\]$/
  /* The following string represents an atom (basically a series of
     non-special characters.) */
  var atom=validChars + '+'
  /* The following string represents one word in the typical username.
     For example, in john.doe@somewhere.com, john and doe are words.
     Basically, a word is either an atom or quoted string. */
  var word="(" + atom + "|" + quotedUser + ")"
  // The following pattern describes the structure of the user
  var userPat=new RegExp("^" + word + "(\\." + word + ")*$")
  /* The following pattern describes the structure of a normal symbolic
     domain, as opposed to ipDomainPat, shown above. */
  var domainPat=new RegExp("^" + atom + "(\\." + atom +")*$")


  /* Finally, let's start trying to figure out if the supplied address is
     valid. */

  /* Begin with the coarse pattern to simply break up user@domain into
     different pieces that are easy to analyze. */
  var matchArray=strFieldValue.match(emailPat)
  if (matchArray==null) {
    /* Too many/few @'s or something; basically, this address doesn't
       even fit the general mould of a valid e-mail address. */
    return {err:"<%=com.intentia.iec.http.Text.getSiteText(request, "error", "err_emailinvalid")%>"};
  }
  var user=matchArray[1]
  var domain=matchArray[2]

  // See if "user" is valid
  if (user.match(userPat)==null) {
    // user is not valid
    return {err:"<%=com.intentia.iec.http.Text.getSiteText(request, "error", "err_emailinvalid")%>"};
  }

  /* if the e-mail address is at an IP address (as opposed to a symbolic
     host name) make sure the IP address is valid. */
  var IPArray=domain.match(ipDomainPat)
  if (IPArray!=null) {
    // this is an IP address
  	for (var i=1;i<=4;i++) {
  	  if (IPArray[i]>255) {
        return {err:"<%=com.intentia.iec.http.Text.getSiteText(request, "error", "err_emailinvalid")%>"};
  	  }
    }
    return null
  }

  // Domain is symbolic name
  var domainArray=domain.match(domainPat)
  if (domainArray==null) {
    return {err:"<%=com.intentia.iec.http.Text.getSiteText(request, "error", "err_emailinvalid")%>"};
  }

  /* domain name seems valid, but now make sure that it ends in a
     word with two letters (country top level domains), three letters
     (com, edu etc.) or four letters (info) and that there's a hostname
     preceding the domain. */

  /* Now we need to break up the domain to get a count of how many atoms
     it consists of. */
  var atomPat=new RegExp(atom,"g")
  var domArr=domain.match(atomPat)
  var len=domArr.length
  if (domArr[domArr.length-1].length<2 ||
      domArr[domArr.length-1].length>4) {
    // the address must end in a two letter or three letter word.
    return {err:"<%=com.intentia.iec.http.Text.getSiteText(request, "error", "err_emailinvalid")%>"};
  }

  // Make sure there's a host name preceding the domain.
  if (len<2) {
    return {err:"<%=com.intentia.iec.http.Text.getSiteText(request, "error", "err_emailinvalid")%>"};
  }

  return null;
}

gValidationFunctions["email"] = ValidateEmail;

</script>
