
<script id="ValidateInteger" type="text/javascript">
// Copyright (c) 2006 Infor
// Version Infor e-Commerce 5.2

function ValidateInteger(objField, objFieldData)
{
  if ((objFieldData.condition!=null) && (!eval(objFieldData.condition)))
	  return null;
	
  strFieldValue = objField.value;
	
  if (objFieldData.mandatory == "true" && strFieldValue == "")
      return {err:"<%=jsEncode(getSiteText(request, "error", "err_mandatory"))%>"};
  if (strFieldValue == "")
    return null;

  if (strFieldValue.indexOf(".") != -1 || strFieldValue.indexOf(",") != -1)
    return {err:"<%=jsEncode(getSiteText(request, "error", "err_intpoint"))%>"};

  if (isNaN(strFieldValue))
    return {err:"<%=jsEncode(getSiteText(request, "error", "err_nan"))%>"};

  nMin = objFieldData.min;
  if (nMin != null && Number(strFieldValue) < Number(nMin))
    return {err:"<%=jsEncode(getSiteText(request, "error", "err_nummin"))%>", p0:nMin};

  nMax = objFieldData.max;
  if (nMax != null && Number(strFieldValue) > Number(nMax))
    return {err:"<%=jsEncode(getSiteText(request, "error", "err_nummax"))%>", p0:nMax};

  if (objFieldData.invalidvalues)
  {
    var invalidvalues;
    invalidvalues = objFieldData.invalidvalues.split(",");
    for (var i=0; i<invalidvalues.length; i++)
      if (strFieldValue == invalidvalues[i])
        return {err:"<%=jsEncode(getSiteText(request, "error", "err_invalidvalue"))%>"};
  }

  return null;
}

gValidationFunctions["integer"] = ValidateInteger;

</script>
