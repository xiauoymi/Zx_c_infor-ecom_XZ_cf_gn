
<script id="Rearrange_main_right_center" type="text/javascript">
function Rearrange_main(left,mid,main) {
main.style.left=left+"px";
main.style.width=mid+"px";
}

function Rearrange_right(left, right) {
right.style.left=left+"px";
}

function Rearrange_center_top(left,mid,top) {
top.style.width=(mid)+"px";
top.style.left=(left)+"px";
}
</script>
