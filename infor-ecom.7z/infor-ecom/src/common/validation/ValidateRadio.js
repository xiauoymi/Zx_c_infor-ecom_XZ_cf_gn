
<script id="ValidateRadio" type="text/javascript">
// Copyright (c) 2006 Infor
// Version Infor e-Commerce 5.2

function ValidateRadio(objField, objFieldData)
{
  if ((objFieldData.condition!=null) && (!eval(objFieldData.condition)))
	  return null;
	
  blnCheck = false;
  for (i = 0; i < objField.length; i++)
    if (objField[i].checked)
      blnCheck = true;
  if (objFieldData.mandatory == "true" && !blnCheck)
      return {err:"<%=jsEncode(getSiteText(request, "error", "err_mandatory"))%>"};

  return null;
}

gValidationFunctions["radio"] = ValidateRadio;

</script>
