<!--METADATA TYPE="DesignerControl" startspan
    <OBJECT ID=Rearrange_calendar
       ClassID="clsid:2EB3F785-083F-4D26-B633-6BB2DCCEEDFE">
        <PARAM Name="Comments" Value="">
        <PARAM Name="CustomAttributes" Value="">
        <PARAM Name="Text" Value="function CalendarDisplay(main,left,layoutright,mid,top,mainwidth,rightwidth,centerwidth) {
var main_left = main.style.left;
main_left = main_left.substring(0,main_left.indexOf(&quot;px&quot;));
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if(main_left.length == 0 || main_left == '' || parseInt(main_left)&lt;210) {
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Rearrange_main(left,mainwidth,main);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Rearrange_right((left+rightwidth),mid, layoutright);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if(top!=null) {
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Rearrange_center_top(left,centerwidth,top);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}
}">
        <PARAM Name="Type" Value="text/javascript">
        <PARAM Name="ContainsValueSpecs" Value="-1">
        <PARAM Name="_Version" Value="65536">
        <PARAM Name="_StockProps" Value="16">
        <PARAM Name="_NameDirty" Value="-1">
    </OBJECT>
-->
<!--METADATA TYPE="DesignerControl" endspan-->