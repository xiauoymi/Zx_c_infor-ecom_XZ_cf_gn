<!--METADATA TYPE="DesignerControl" startspan
    <OBJECT ID=Rearrange_main
       ClassID="clsid:2EB3F785-083F-4D26-B633-6BB2DCCEEDFE">
        <PARAM Name="Comments" Value="">
        <PARAM Name="CustomAttributes" Value="">
        <PARAM Name="Text" Value="function Rearrange_main(left,mid,main) {
main.style.left=left+&quot;px&quot;;
main.style.width=mid+&quot;px&quot;;

}
">
        <PARAM Name="Type" Value="text/javascript">
        <PARAM Name="ContainsValueSpecs" Value="-1">
        <PARAM Name="_Version" Value="65536">
        <PARAM Name="_StockProps" Value="16">
        <PARAM Name="_NameDirty" Value="-1">
    </OBJECT>
-->
<!--METADATA TYPE="DesignerControl" endspan-->