var defaultStore;
var view;
var map;
var prevMapMarker;
var panel;
var dataFeed;
var searchBox;
var locationSearch;
var zoomLevel = 10;
var arrStoreList= new Array();

function SimpleStaticFeed() {
	$.extend(this, new storeLocator.StaticDataFeed);
	var that = this;
	var retstores = getStoresFromDB();
	that.setStores(retstores);
	if (retstores.length > 0) {
		defaultStore = retstores[0];
	}
}

SimpleStaticFeed.prototype.FEATURES_ = new storeLocator.FeatureSet();

SimpleStaticFeed.prototype.getFeatures = function() {
	return this.FEATURES_;
};

SimpleStaticFeed.prototype.getStores = function(bounds, features, callback) {
	callback(this.stores);
};

SimpleStaticFeed.prototype.getCenter = function() {
	if (defaultStore) {
		return defaultStore.getLocation();
	}
	return new google.maps.LatLng(-28, 135);
};



function loadMap(location, zoomLevelParam) {
	zoomLevel = zoomLevelParam;
	dataFeed = new SimpleStaticFeed();

	map = new google.maps.Map(document.getElementById('map-canvas'), {
		center : dataFeed.getCenter(),
		zoom : zoomLevel,
		mapTypeId : google.maps.MapTypeId.ROADMAP
	});
	
	
	var searchInput = (document.getElementById('locationsearch'));
	var searchBox = new google.maps.places.SearchBox(searchInput);
	var markers = [];
    
	google.maps.event.addListener(searchBox, 'places_changed', function() {
		view.close_infowindow();
		var places = searchBox.getPlaces();

		for ( var i = 0, marker; marker = markers[i]; i++) {
			marker.setMap(null);
		}

		markers = [];
		var bounds = new google.maps.LatLngBounds();
		for ( var i = 0, place; place = places[i]; i++) {
			var image = {
				url : place.icon,
				size : new google.maps.Size(71, 71),
				origin : new google.maps.Point(0, 0),
				anchor : new google.maps.Point(17, 34),
				scaledSize : new google.maps.Size(25, 25)
			};

			var marker = new google.maps.Marker({
				map : map,
				icon : '../common/themes/core/images/location_marker.png',
				title : place.name,
				position : place.geometry.location
				
			});
			if(prevMapMarker){
				prevMapMarker.setMap(null);
			}
			prevMapMarker=marker;

			markers.push(marker);
			map.setCenter(marker.getPosition());
			bounds.extend(place.geometry.location);
		}

		map.fitBounds(bounds);
		map.setZoom(zoomLevel);
		dataFeed.setReferencePoint(map.getCenter());
		
	});

	google.maps.event.addListener(map, 'bounds_changed', function() {
		var bounds = map.getBounds();
		searchBox.setBounds(bounds);
		
	});
	
	var panelDiv = document.getElementById('panel');

	view = new storeLocator.View(map, dataFeed, {
		geolocation : true
	});

	panel = new storeLocator.Panel(panelDiv, {
		view : view
	});
	view.getMap().setZoom(zoomLevel);
	panel.setZoom(zoomLevel);

	
	$('.storelocator-filter').remove();
	$('.store-list').wrap('<div></div>');
	$('#panel').perfectScrollbar();
	locationSearch = location;
	setDefaultLocation();
};


function setDefaultLocation() {
	panel.searchPosition(locationSearch);
	//map.setZoom(zoomLevel);
	setTimeout('dropPin()', 2000);
	setTimeout('setMapZoom()', 3000);
}

function setMapZoom() {
	map.setZoom(zoomLevel);
}


function dropPin(){
	//panel.searchPosition(locationSearch);
	if(prevMapMarker){
		prevMapMarker.setMap(null);
	}
	var marker = new google.maps.Marker({
		map : map,
		icon : '../common/themes/core/images/location_marker.png',
		title : locationSearch,
		position : view.getMap().getCenter()
	});
	prevMapMarker=marker;
	dataFeed.setReferencePoint(map.getCenter());
	$('#panel').perfectScrollbar("update");
	//map.setZoom(zoomLevel);
}

function handleGeoLocation(locationError){
	var toolTipDiv = $('div#tooltip');
	var retValue = false;
	if(navigator.geolocation) {
		navigator.geolocation.getCurrentPosition(function(position) {
			var pos = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
			if(prevMapMarker){
				prevMapMarker.setMap(null);
			}
			var marker = new google.maps.Marker({
				map : map,
				icon : '../common/themes/core/images/location_marker.png',
				position: pos
			});
			map.setCenter(pos);
			map.setZoom(zoomLevel);
			dataFeed.setReferencePoint(map.getCenter());
			prevMapMarker = marker;
			retValue = true;
		}, function() {
			toolTipDiv.removeClass('hide');
			retValue = false;
		},{timeout:10000});
	} else {
		toolTipDiv.removeClass('hide');
		retValue = false;
	}
	return retValue;
}

function updateStoresByType(storeType){
	arrStoreList=[];
	dataFeed.setStoreType(storeType);
	panel.featureFilter_changed();
	view.clearMarkers();
	view.refreshView();
	$(".gm-style .gm-style-iw").next().hide();
}

function hideShowList(storeType,that){
	if($("li."+storeType+"List").css("display")!="none"){
		$(that).children().removeClass("shownStore").addClass("hiddenStore");
		//$("li."+storeType+"List").hide({easing:"swing"});
		$("li."+storeType+"List").slideUp();
		var val=arrStoreList.indexOf(storeType);
		if(val<0){
			arrStoreList.push(storeType);
		}
	}
	else{
		$(that).children().removeClass("hiddenStore").addClass("shownStore");
		//$("li."+storeType+"List").show({easing:"swing"});
		$("li."+storeType+"List").slideDown();
		var val=arrStoreList.indexOf(storeType);
		if(val>-1){
			arrStoreList.splice(val,1);
		}
	}
}



//google.maps.event.addDomListener(window, 'load', loadMap);