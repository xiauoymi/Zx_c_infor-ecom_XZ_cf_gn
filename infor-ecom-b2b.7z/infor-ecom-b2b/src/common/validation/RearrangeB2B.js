
<script id="RearrangeB2B" type="text/javascript">
function RearrangeB2B(winSize,top_bg,top_center,top_right,right_inner,right_bottom,right_outer,right_bg,language,main,right,left,mid)   {
top_bg.style.width=(winSize-2) + "px";
top_center.style.width=(winSize-2) + "px";
top_right.style.left=(winSize-24) + "px";
right_inner.style.left=(winSize-175) + "px";
right_bottom.style.left=(winSize-175) + "px";
right_outer.style.left=(winSize-185) + "px";
right_bg.style.left=(winSize-12) + "px";
language.style.left=(winSize-24) + "px";
main.style.width=(mid) + "px";
main.style.left=(left) + "px";
right.style.left=(mid+left+15) + "px";
}  
</script>
