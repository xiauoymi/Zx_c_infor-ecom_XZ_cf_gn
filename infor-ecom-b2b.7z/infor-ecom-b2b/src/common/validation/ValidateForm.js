
<script id="ValidateForm" type="text/javascript">
// Copyright (c) 2006 Infor
// Version Infor e-Commerce 5.2

var gValidationFunctions = new Object();
var gValidationFunction = null;
var currentElem;
function ValidateForm(objForm) {
	var listvaluenotfound = true;
	var checked = false;

	if (objForm != null) {
		for (var i=0; i<objForm.elements.length; i++) {
			objField = objForm.elements[i];

			if(objField.disabled) {
				// ignore disabled elements
				continue;
			}
			
			if (objField.getAttribute("jsValidation") == null) {
				continue;
			}

			objFieldData = eval("x = " + objField.getAttribute("jsValidation"));
			
			if( objFieldData.allmandatory && listvaluenotfound) {
				checked = true;
				if(objField.value == "") {
					listvaluenotfound = true;
				}
				else {
					listvaluenotfound = false;
				}
			}

			strTestType = objFieldData.type;

			if (strTestType == null) {
				continue;
			}

			fctValidate = gValidationFunctions[strTestType];
			if (fctValidate == null) {
				continue;
			}

			objError = fctValidate(objField, objFieldData);
			if (objError != null) {
				strErrKey = objError.err;
				if (objFieldData[strErrKey] != null) {
					strErrKey = objFieldData[strErrKey];
				}

				strErrorPrompt = strErrKey;

				if (strErrKey != null && strErrKey != "") {
					for (n = 0; objError["p" + n] != null; n++) {
						strErrorPrompt = strErrorPrompt.replace("%%" + n, objError["p" + n]);
					}
				}

				alert(strErrorPrompt );

				if (strTestType == "radio") {
					objField[0].focus();
				}
				else {
					if(BrowserDetect.browser=='Firefox' || BrowserDetect.browser=='Safari') {
					   myCurrentElem = objField;
					   setTimeout('myCurrentElem.focus();' , 0);
					} else {
					   objField.focus();
					}
				}
				return false;
			}
		}
	}
	if(listvaluenotfound && checked) {
		alert("<%=jsEncode(getSiteText(request, "error", "err_mandatorylist"))%>");
		return false;
	}
	else {
		return true;
	}
}

</script>
