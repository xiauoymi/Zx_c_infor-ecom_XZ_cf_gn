
<script id="ValidateDate" type="text/javascript">
// Copyright (c) 2006 Infor
// Version Infor e-Commerce 5.2

/* In the JavaScript Date object the month numbers are 0 to 11 */

/* Handle two-digit year number */
function fullYear(year)
{
  y = parseInt(year, 10);
  /*if (y >= 0 && y <=50)
    y += 2000;
  else if (y >= 51 && y <=99)
    y += 1900;*/

   var today = new Date();			
   // get current century floor (e.g., 2000)
   var currCent = parseInt(today.getFullYear() / 100) * 100;
   var threshold = today.getFullYear() - (currCent - 50);
   if (y >= threshold) {
      y += currCent - 100;
   } else {
      if (y < (today.getFullYear() - (currCent + 50))) {
         y += currCent + 100;
      } else {
         y += currCent;	
      }	
   }
   return y;
}

function isValidDate(day, month, year)
{
  if (!day || !month || !year)
    return false;

  re = new RegExp("[^0-9]");
  if (re.test(day) || re.test(month) || re.test(year))
    return false;

  if(year.length != 2 && year.length !=4)
	  return false;

  day = parseInt(day, 10);
  month = parseInt(month, 10);
  year = parseInt(year, 10);
  if (isNaN(day) || isNaN(month) || isNaN(year))
    return false;

  if(year>9999)
     return false;

  test = new Date(fullYear(year), month - 1, day);
  if (fullYear(year) == test.getFullYear() && (month - 1) == test.getMonth() && day == test.getDate())
    return true;
  else
    return false;
}

function ValidateDate(objField, objFieldData)
{
  if ((objFieldData.condition!=null) && (!eval(objFieldData.condition)))
    return null;

  strFieldValue = objField.value;

  if (objFieldData.mandatory == "true" && strFieldValue == "")
      return {err:"<%=jsEncode(getSiteText(request, "error", "err_mandatory"))%>"};
  if (strFieldValue == "")
    return null;

  strPrototype = "<%=__user.formatDateTime(new java.util.GregorianCalendar(2099,11,31).getTime(), 2)%>";
  if (strPrototype == null)
    return null;

  nDStart = strPrototype.search("31");
  nMStart = strPrototype.search("12");
  nYStart = strPrototype.search("99");

  nDIndex = nDStart < nMStart ? 0 : 1; nDIndex += nDStart < nYStart ? 0 : 1;
  nMIndex = nMStart < nDStart ? 0 : 1; nMIndex += nMStart < nYStart ? 0 : 1;
  nYIndex = nYStart < nDStart ? 0 : 1; nYIndex += nYStart < nMStart ? 0 : 1;

  //strSep = strPrototype.charAt(strPrototype.search("[^0-9]"));	// this line fails if the date pattern has multiple separators

  rgxSplitter = /[^0-9]/;
  arrDateParts = strFieldValue.split(rgxSplitter);			// this approach solves the issue on date patterns with mulitple separators, Ex."dd/mm-yy"

  if ((arrDateParts.length != 3) || (!isValidDate(arrDateParts[nDIndex], arrDateParts[nMIndex], arrDateParts[nYIndex]))) {
    var strDateFormat = '<%= __user.getDatePattern()%>';
    strDateFormat=strDateFormat.toLowerCase();

    return {err:"<%=jsEncode(getSiteText(request, "error", "err_date"))%>", p0:strDateFormat};
  }		

  dDate = new Date(fullYear(arrDateParts[nYIndex]), arrDateParts[nMIndex] - 1, arrDateParts[nDIndex]);
	
  if (objFieldData.min != null)
  {
    arrMinDateParts = objFieldData.min.split(rgxSplitter);
    dMinDate = new Date(fullYear(arrMinDateParts[nYIndex]), arrMinDateParts[nMIndex] - 1, arrMinDateParts[nDIndex]);
    if (dDate.getTime() < dMinDate.getTime())
      return {err:"<%=jsEncode(getSiteText(request, "error", "err_datemin"))%>", p0:objFieldData.min};
  }

  if (objFieldData.max != null)
  {
    arrMaxDateParts = objFieldData.max.split(rgxSplitter);
    dMaxDate = new Date(fullYear(arrMaxDateParts[nYIndex]), arrMaxDateParts[nMIndex] - 1, arrMaxDateParts[nDIndex]);
    if (dDate.getTime() > dMaxDate.getTime())
      return {err:"<%=jsEncode(getSiteText(request, "error", "err_datemax"))%>", p0:objFieldData.max};
  }

  if (objFieldData.minfield != null && (typeof objField.form.elements[objFieldData.minfield]) != "undefined")
  {
    arrMinDateParts = objField.form.elements[objFieldData.minfield].value.split(rgxSplitter);
    dMinDate = new Date(fullYear(arrMinDateParts[nYIndex]), arrMinDateParts[nMIndex] - 1, arrMinDateParts[nDIndex]);
    if (dDate.getTime() < dMinDate.getTime())
      return {err:"<%=jsEncode(getSiteText(request, "error", "err_dateminfield"))%>", p0:objField.form.elements[objFieldData.minfield].value};
  }
	
  if (objFieldData.maxfield != null && (typeof objField.form.elements[objFieldData.maxfield]) != "undefined")
  {
    arrMaxDateParts = objField.form.elements[objFieldData.maxfield].value.split(rgxSplitter);
    dMaxDate = new Date(fullYear(arrMaxDateParts[nYIndex]), arrMaxDateParts[nMIndex] - 1, arrMaxDateParts[nDIndex]);
    if (dDate.getTime() > dMaxDate.getTime())
      return {err:"<%=jsEncode(getSiteText(request, "error", "err_datemaxfield"))%>", p0:objField.form.elements[objFieldData.maxfield].value};
  }
	
  return null;
}

gValidationFunctions["date"] = ValidateDate;
</script>
