
<script id="Mozilla_rearrange" type="text/javascript">
function NonIE(main,layoutright, top) {
                         var left=210;
                         var right=210;
                                var mid = window.innerWidth - (left+right+25);
                                 if(mid >530)
                                            {
                                                   Rearrange_main(left,mid,main);
                                                   Rearrange_right((left+mid+30), layoutright);
                                                   if(top!=null) {
                                                              Rearrange_center_top(left,mid,top);
                                                          }
                                               }
                                      }



</script>
