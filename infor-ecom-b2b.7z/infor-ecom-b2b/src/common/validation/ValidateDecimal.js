
<script id="//Copyright" type="text/javascript">
// Copyright (c) 2006 Infor
// Version Infor e-Commerce 5.2

var  strDecPoint = ".";

function ValidateNumeric(objField, doAlert) {
	var strAlert = null;

	if (objField.disabled) {
		return null;         // ignore disabled elements
	}

	strFieldValue = objField.value;

	if (strFieldValue == "") {
		return null;
	}

	strPrototype = "<%=__user.format(1234.5)%>";
	strThousandSeparator = strPrototype.charAt(strPrototype.search("2") - 1);
	strDecPoint = strPrototype.charAt(strPrototype.search("5") - 1);

	nonblockingSpaceRE = /[\s\xA0]+$/;
	// trim all thousand separators
	if (strThousandSeparator == " " || strThousandSeparator.match(nonblockingSpaceRE)) {
		strFieldValueTrimmed = ClearSpaces(strFieldValue);
	}
	else {
		var trimRE = new RegExp('['+strThousandSeparator+']', 'g');
		var strFieldValueTrimmed = strFieldValue.replace(trimRE, '');
	}

	var re = new RegExp("^\\d*\\"+ strDecPoint + "{0,1}\\d*$");

	if (!re.test(strFieldValueTrimmed) || strFieldValue == "."  ||   strFieldValue == ",") {
		strAlert='<%=jsEncode(getSiteText(request, "error", "err_nan"))%>';
		if (doAlert == true) {	
			alert(strAlert);		
			if(BrowserDetect.browser=='Firefox' || BrowserDetect.browser=='Safari') {
				myCurrentElem = objField;
				setTimeout('myCurrentElem.focus();' , 0);
			} else {
				objField.focus();
			}
		}
	}
	else {
		objField.value = strFieldValueTrimmed;
	}

	return strAlert;
}


function ValidateDecimal(objField, objFieldData) {

	//if(objField.disabled)  return null;         // ignore disabled elements

	if ((objFieldData.condition!=null) && (!eval(objFieldData.condition))) {
		return null;
	}

	strFieldValue =  ClearSpaces(objField.value);
	if (objFieldData.mandatory == "true" && strFieldValue == "") {
		return {err:"<%=getSiteText(request, "error", "err_mandatory")%>"};
	}

	var validationResult = ValidateNumeric(objField, false);

	if (validationResult != null) {
		return {err:validationResult};
	}

	if (strDecPoint == ".") {
		strFieldValue = strFieldValue.replace(/,/g, "");
	}
	else {
		strFieldValue = strFieldValue.replace(/\./g, "");
		strFieldValue = strFieldValue.replace(",", ".");
	}

	nFieldValue = parseFloat(strFieldValue);
	/*
	if (objFieldData.min != null)
	{
	nMin = parseFloat(objFieldData.min);
	if (nFieldValue < nMin) {
	return {err:"<%=getSiteText(request, "error", "err_nummin")%>", p0:nMin};
	}
	} */

	if (objFieldData.max != null) {
		nMax = parseFloat(objFieldData.max);
		if (nFieldValue > nMax) {
			return {err:"<%=getSiteText(request, "error", "err_nummax")%>", p0:nMax};
		}
	}

	if (objFieldData.minfield != null && (typeof objField.form.elements[objFieldData.minfield]) != "undefined") {
		var strMinFieldValue = objField.form.elements[objFieldData.minfield].value;

		if (strDecPoint == ".") {
			strMinFieldValue = strMinFieldValue.replace(/,/g, "");
		}
		else {
			strMinFieldValue = strMinFieldValue.replace(/\./g, "");
			strMinFieldValue = strMinFieldValue.replace(",", ".");
		}

		if (parseFloat(strFieldValue) < parseFloat(strMinFieldValue)) {
			return {err:"<%=getSiteText(request, "error", "err_nummin")%>", p0:strMinFieldValue};
		}
	}

	return null;
}

function removeCommas( strValue ) {
	/************************************************
	DESCRIPTION: Removes commas from source string.

	PARAMETERS:
	strValue - Source string from which commas will
	be removed;

	RETURNS: Source string with commas removed.
	*************************************************/
	var objRegExp = /,/g; //search for commas globally

	//replace all matches with empty strings
	return strValue.replace(objRegExp,'');
}


function ClearSpaces(r) {
	var strTemp = new String(r);
	return strTemp.replace(/ /g, "").replace(/\xA0/g, "");
}

gValidationFunctions["decimal"] = ValidateDecimal;

</script>
