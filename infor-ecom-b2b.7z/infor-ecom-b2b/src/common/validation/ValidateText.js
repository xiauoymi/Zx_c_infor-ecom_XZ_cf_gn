
<script id="ValidateText" type="text/javascript">
// Copyright (c) 2006 Infor
// Version Infor e-Commerce 5.2

function removeNewLine(s) {	
  if (s != null) {
	  while (s.substring(0,1) == String.fromCharCode(10) || s.substring(0,1) == String.fromCharCode(13)) {
		s = s.substring(1,s.length);
	  }
	  while (s.substring(s.length-1,s.length) == String.fromCharCode(10) || s.substring(s.length-1,s.length) == String.fromCharCode(13)) {
		s = s.substring(0,s.length-1);
	  }
  }
  return s;
}

function ValidateText(objField, objFieldData) {
  if ( objFieldData == null ) {
	return null;
  }

  if((objFieldData.condition != null) && (!eval(objFieldData.condition))){
  	return null;
  }
	
  strFieldValue = objField.value;

  if (objFieldData.mandatory == "true" && strFieldValue == "")
    return {err:"<%=jsEncode(getSiteText(request, "error", "err_mandatory"))%>"};
  if (strFieldValue == "")
    return null;

  strRegExp = objFieldData.invalidregexp;
  if (strRegExp != null)
  {
    re = new RegExp(strRegExp);
    if (re.test(strFieldValue))
      return {err:"<%=jsEncode(getSiteText(request, "error", "err_invalidregexp"))%>", p0:strRegExp};
  }

  strRegExp = objFieldData.validregexp;
  if (strRegExp != null)
  {
    re = new RegExp(strRegExp);
    if (!re.test(strFieldValue))
      return {err:"<%=jsEncode(getSiteText(request, "error", "err_validregexp"))%>", p0:strRegExp};
  }

  nMin = objFieldData.min;
  if (nMin != null && strFieldValue.length < nMin)
    return {err:"<%=jsEncode(getSiteText(request, "error", "err_textmin"))%>", p0:nMin};

  nMax = objFieldData.max;
  if (nMax != null && strFieldValue.length > nMax)
    return {err:"<%=jsEncode(getSiteText(request, "error", "err_textmax"))%>", p0:nMax};

  var strUniqueAttr = objFieldData.uniqueAttr;
  if (strUniqueAttr != null) {
    var strUrl = '../common/includes/UniqueAttribute.jsp?<%=getApplicationProperty(ApplicationProperties.CSRFGuard.TokenName)%>=<%=getCsrfTokenValue(request,getApplicationProperty(ApplicationProperties.CSRFGuard.TokenName))%>&' + strUniqueAttr + '=' + encodeURIComponent(strFieldValue);
    var isUnique = removeNewLine(getServerSideInfo(strUrl));
    if (isUnique != 'true')
      return {err:"<%=jsEncode(getSiteText(request, "error", "err_textunique"))%>"};
  }

  return null;
}

gValidationFunctions["text"] = ValidateText;

</script>
