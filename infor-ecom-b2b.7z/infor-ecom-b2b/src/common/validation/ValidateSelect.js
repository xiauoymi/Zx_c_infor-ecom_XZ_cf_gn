
<script id="ValidateSelect" type="text/javascript">
// Copyright (c) 2006 Infor
// Version Infor e-Commerce 5.2

function ValidateSelect(objField, objFieldData) {
  if ( objFieldData == null ) {
	return null;
  }

  if ((objFieldData.condition!=null) && (!eval(objFieldData.condition)))
    return null;
	
  strFieldValue = "";
  for (i = 0; i < objField.options.length; i++)
    if (objField.options[i].selected)
    {
      if (strFieldValue != "")
        strFieldValue += ", ";
      strFieldValue += objField.options[i].value;
    }

  if (objFieldData.mandatory == "true" && strFieldValue == "")
    return {err:"<%=jsEncode(getSiteText(request, "error", "err_mandatory"))%>"};

  if (objFieldData.invalidvalues)
  {
    invalidvalues = objFieldData.invalidvalues.split(",");
    for (i = 0; i < invalidvalues.length; i++)
    {
      strInvalidValue = invalidvalues[i];
      strInvalidValue = strInvalidValue.replace(/(^\s*)|(\s*$)/g, "");
      if (strFieldValue == strInvalidValue)
        return {err:"<%=jsEncode(getSiteText(request, "error", "err_invalidvalue"))%>"};
    }
  }

  return null;
}

gValidationFunctions["select"] = ValidateSelect;

</script>
