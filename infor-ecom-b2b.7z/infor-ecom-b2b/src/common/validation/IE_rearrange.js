
<script id="IE_Rearrange" type="text/javascript">
function IE(main,layoutright, top) {
                            var left=210;
                            var right=210;
                            var mid = document.body.clientWidth - (left+right+25);

                             if(mid >630 )
                               {
                                    Rearrange_main(left,mid,main);
                                    Rearrange_right((left+mid+40), layoutright);
                                                if(top!=null) {
                                                    Rearrange_center_top(left,mid,top);
                                                }

                                    }

}


</script>
