/*
 *  IEC Banner Widget
 *  This will load banners from the specified URL in the 'source' option.
 *  
 * 	Author: Efren Jamolod
 *  Date:	11/25/2013
 */

(function($) {

	$.widget("iec.iecCampaignBannerWidget", $.iec.iecBannerWidget, {

		// Defaults settings
		defaults : {
			'source' : 'GetCampaigns.jsp'
		},
		

		// Set up the widget
		_create : function() {
			//call parent method
			this._super();
			$(this.element).addClass('iecCampaignBannerWidget');
		}
		

	}); // END OF '$.widget()' 

}(jQuery));