/*
 *  IEC Base Widget
 *  This is the base widget that all IEC widgets should extend. This will hold common widget functionalities.
 *  
 * 	Author: Efren Jamolod
 *  Date:	11/25/2013
 *  
 *  Depends:
 *		jquery.core.js
 *		jquery.ui.core.js
 *		jquery.ui.widget.js
 */

$.iec = $.iec || {};
(function($) {

	$.widget("iec.iecBaseWidget", {

		version: "@VERSION",
		 
		// Defaults settings
		baseDefaults : {
			clear : null,
			'reload' : false,
		},
		
		
		// Set up the widget
		_create : function() {
			this._mergeOptions(this.defaults);
		},

		
		// Merge defaults and data attributes
		_mergeOptions : function(defautls) {
			var params = this._getParamsFromData(this.element.data());
			this.options = $.extend({}, this.options, defautls);
			this.options = $.extend({}, this.options, this.baseDefaults);
			this.options = $.extend({}, this.options, params);			
		},


		// Return params from data-* attribute only
		_getParamsFromData : function(data) {
			var params = {};
			var widgetQName = (this.namespace + this.widgetName).toLowerCase();
			$.each(data, function(key, value) {
				if (key.toLowerCase() != widgetQName) {
					params[key] = value;
				}
			});

			return params;
		},

		// Use the _setOption method to respond to changes to options
		_setOption : function(key, value) {
			// TODO: Add handling here, if needed
		},

		// Use the destroy method to clean up any modifications your widget has
		// made to the DOM
		destroy : function() {
			$.Widget.prototype.destroy.call(this);
		}

	}); // END OF '$.widget()' 

}(jQuery));