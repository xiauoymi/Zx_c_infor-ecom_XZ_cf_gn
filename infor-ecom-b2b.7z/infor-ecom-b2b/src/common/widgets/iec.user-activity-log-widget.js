/*
 *  IEC Item Recommendation Widget
 *  This will load recommendations from the specified URL in the 'source' option.
 *  
 * 	Author: Efren Jamolod
 *  Date:	11/25/2013
 */

$.iec = $.iec || {};
(function($) {
	$.widget("iec.iecUserActivityLogWidget", $.iec.iecBaseWidget, {

		// Defaults settings
		defaults : {
			'source' : 'LogUserActivity.jsp'
		},

		// Set up the widget
		_create : function() {
			// merge defaults and data attributes
			this._mergeOptions(this.defaults);
			// log activity
			this.log();
		},

		// Log user activity
		log : function() {
			var thisWidget = this;
			// do 'get' ajax call
			$.get(thisWidget.options.source + '?' + gCsrfTokenUrlParam,
					thisWidget.options, function(data) {
						$(thisWidget).html('OK');
					});
		}
	}); // END OF '$.widget()' 

}(jQuery));