/*
 *  IEC Banner Widget
 *  This will load banners from the specified URL in the 'source' option.
 *  
 * 	Author: Efren Jamolod
 *  Date:	11/25/2013
 */



(function($) {
	
	$.widget("iec.iecBannerWidget", $.iec.iecBaseWidget, {

		// Defaults settings
		defaults : {
			'source' : '/'
		},

		// Set up the widget
		_create : function() {
			// Merge defaults and data attributes
			this._mergeOptions(this.defaults);

			// Load banners
			if (!$(this.element).is('.loaded') || this.options.reload) {
				$(this.element).addClass('iecBannerWidget');
				this._loadBanners();
			}
		},

		// Perform Ajax call to load banners from the specified source
		_loadBanners : function() {
			var thisWidget = this;

			// do 'get' ajax call
			$.get(this.options.source + '?' + gCsrfTokenUrlParam, this.options,
					function(data) {
						thisWidget._renderBanners(data);
					});
		},

		// Render response banners
		_renderBanners : function(response) {
			
			var thisWidget = this;
			var thisWidgetElem = $(this.element);
			
			thisWidgetElem.html(response);
			thisWidgetElem.addClass(thisWidget.options.sectionName);

			var banners = $('ul.banners', thisWidgetElem);
			var bannerCount = $('li', banners).length;

			var bannerDefaultSettings = {
					// Width and height must be set to keep aspect ratio
					width: thisWidgetElem.width(),
					height: 500
			};
					
			
			
			if (thisWidget.options.rotate && bannerCount > 1) {
				if (thisWidget.options.autoPlay) {
					var delay = thisWidget.options.delayTime;
					var fade = thisWidget.options.fadeTime;
					banners.slidesjs($.extend({}, bannerDefaultSettings,
						{
							play : {
								active : true,
								auto : true,
								interval : delay,
								swap : true,
								pauseOnHover : true,
								restartDelay : fade
							},
							callback : {
								complete : function(current) {
									thisWidget._handleOnVisible(banners, current);
								}
							}
						})
					);
				} else {
					banners.slidesjs($.extend({}, bannerDefaultSettings,
						{
							callback : {
								complete : function(current) {
									thisWidget._handleOnVisible(banners, current);
								}
							}
						})
					);
				}

			} else if (bannerCount == 1) {
				banners.slidesjs($.extend({}, bannerDefaultSettings,
					{
						navigation : {
							active : false
						},
						pagination : {
							active : false
						}
					})
				);
				banners.find(".slidesjs-slide").css("left", "0px"); // Fixes bug in Chrome: ECOMM-2152
			} else {
				// banners.hide();
				thisWidgetElem.height('auto');
			}

			thisWidget._handleOnVisible(banners, 1);
			thisWidgetElem.addClass('loaded');
		},

		// handle everytime a banner will be visible to the user
		_handleOnVisible : function(banners, current) {
			var thisWidget = this;
			var currentSlide = ($('.slideEntry', banners))[current-1];
			if(currentSlide && thisWidget._onScreen(thisWidget.element)) {
				// Log user activity
				$('.iecUserActivityLogWidget', currentSlide).each(function() {
					var logger = $(this).clone().iecUserActivityLogWidget();
					logger.remove();
				});
			}
		},

		// Return params from data-* attribute only
		_getParamsFromData : function(data) {
			var params = {};
			var widgetQName = (this.namespace + this.widgetName).toLowerCase();
			$.each(data, function(key, value) {
				if (key.toLowerCase() != widgetQName) {
					params[key] = value;
				}
			});

			return params;
		},

		// Use the _setOption method to respond to changes to options
		_setOption : function(key, value) {
			// TODO: Add handling here, if needed
		},
		
		// Check if banner is on-screen
		_onScreen : function(bannerElem) {
			//Check first if windows is active
			if(!$.windowActive) {
				return false;
			}
			
		    var screen = $(window);
		    var scrnTop = screen.scrollTop();
		    var scrnHeight = screen.height();
		    var scrnBottom = scrnTop + scrnHeight;
		    var banner = $(bannerElem);
		    var bnrTop = banner.offset().top;
		    var bnrHeight = banner.height();
		    var bnrBottom = bnrTop + bnrHeight;

		    var result = (bnrTop >= scrnTop && bnrTop < scrnBottom) ||
		           		 (bnrBottom > scrnTop && bnrBottom <= scrnBottom) ||
		           		 (bnrHeight > scrnHeight && bnrTop <= scrnTop && bnrBottom >= scrnBottom);

		    return result;
		  }

	}); // END OF '$.widget()' 
	
	}(jQuery));
