/* 
 *  IEC Item Description Widget 
 *  This will load Item Description from the specified URL in the 'source' option. 
 *   
 *  Author: Efren Jamolod 
 *  Date:   11/25/2013 
 */

$.iec = $.iec || {}; 
(function($) { 
    $.widget("iec.iecItemDetailsWidget", $.iec.iecBaseWidget, { 
          
        // Defaults settings 
        defaults : { 
            'source' : 'ItemDynamicAttributes.jsp'
        }, 
          
  
        // Set up the widget 
        _create : function() { 
            //Merge defaults and data attributes 
            this._mergeOptions(this.defaults); 
              
            // Load descriptions 
            if (!$(this.element).is('.loaded') || this.options.reload) { 
                this._loadDescriptions(); 
            } 
        }, 
          
  
        // Perform Ajax call to load descriptions based on widget attributes 
        _loadDescriptions : function() { 
            var thisWidget = this;
              
            //do 'get' ajax call 
            $.get( 
                thisWidget.options.source + '?' + gCsrfTokenUrlParam, 
                thisWidget._getParamsFromData(thisWidget.element.data()), 
                function(data) { 
                    thisWidget._renderDescription(data); 
                } 
            ); 
        }, 
  
        // Render response item descriptions 
        _renderDescription : function(response) { 
            var $thisWidgetElem = $(this.element);
            var attrMaxHeight = parseInt($thisWidgetElem.attr('data-max-height'));
            $thisWidgetElem.html(response);
            
            if ($.trim($thisWidgetElem.html()).length == 0) {
            	$(".mainDescription").css({"border-top":"none"});    
            	$(".linkIconsSection").css({"border-top":"none"});
            	$(".itemDetailsHolder .itemDetails .itemDescriptions").hide();
            }
            else {
            	$(".iecLongAttributes").readmore({
            		speed: 175,
            		embedCSS: false,
            		maxHeight: attrMaxHeight
            	});
            }
            $thisWidgetElem.addClass("loaded"); 
        }
    }); // END OF '$.widget()' 
}(jQuery));