<script type="text/javascript">
<!--

var W3CDOM = (document.createElement && document.getElementsByTagName);

function initSelect() {
	if (!W3CDOM) return;
	var fakeFileUpload = document.createElement('div');
	fakeFileUpload.className = 'fakeselect';
    var spanLeft = document.createElement('span')
    spanLeft.className="inputLeft";
    //fakeFileUpload.appendChild(spanLeft);
	fakeFileUpload.appendChild(document.createElement('input'));
	var image = document.createElement('img');
	image.src='../common/style-bc/comboArrow.gif';
    image.className='comboButton';
	fakeFileUpload.appendChild(image);
	var selectComponent = document.getElementsByTagName('select');
	for (var i=0;i<selectComponent.length;i++) {
		if (selectComponent[i].getAttribute('noscript')) continue;
        if (selectComponent[i].scrollWidth==0) continue;
        if(selectComponent[i].nextSibling){
            if(selectComponent[i].nextSibling.tagName=="div" && selectComponent[i].nextSibling.className=="fakeselect")
                continue;
        }
		if (selectComponent[i].parentNode.className != 'selectinput') continue;
        
        var origIndex=selectComponent[i].selectedIndex;
        
        var opSize=0;
        var opIndex=0;
        for(var j=0; j<selectComponent[i].options.length; j++){
            if(opSize<selectComponent[i].options[j].text.length){
                opSize = selectComponent[i].options[j].text.length;
                opIndex=j;
            }
        }
        selectComponent[i].selectedIndex=opIndex;
        //alert("display "+selectComponent[i].style.display);
        //alert("original index "+origIndex);
        //alert("new index "+selectComponent[i].selectedIndex);
        //alert("offset "+selectComponent[i].scrollWidth);
        //alert("value "+selectComponent[i].value);
        
        selectComponent[i].parentNode.style.width=selectComponent[i].offsetWidth+10;
        selectComponent[i].className = 'select hidden';
		var clone = fakeFileUpload.cloneNode(true);
        clone.style.width=selectComponent[i].offsetWidth+10;
        selectComponent[i].parentNode.appendChild(clone);
		selectComponent[i].relatedElement = clone.getElementsByTagName('input')[0];
        //selectComponent[i].style.width=selectComponent[i].offsetWidth;
        selectComponent[i].relatedElement.style.width=(selectComponent[i].offsetWidth)-17;
        
        selectComponent[i].selectedIndex=origIndex;
        if(selectComponent[i].onchange2==null){
            selectComponent[i].onchange2 = selectComponent[i].onchange;
        
            selectComponent[i].onchange =selectComponent[i].onkeydown= function () {
                this.relatedElement.value = this.options[this.selectedIndex].text;
                if(this.onchange2){
                    eval(this.onchange2());          
                }
            }
        }
        
        if (selectComponent[i].value){
            selectComponent[i].relatedElement.value = selectComponent[i].options[selectComponent[i].selectedIndex].text;
        }
		
	}
}

// -->

</script>