/* ==========================================================================================
   Infor e-Commerce jQuery Plugin 
   Theme: "core"
   Author: Vergara, Robert
   Date: 08/06/2013
   customScrollableDropDown
   Options:
   width - integer (in px)
   visibleRows - integer
   ========================================================================================== */

(function( $ ) {     
	$.fn.customScrollableDropdown = function( options ) {
		var thisObj = $( this );	
		var needsScroll = false;
		
		// Establish our default settings
        var settings = $.extend({
            width        : 185,
            visibleRows  : 7,
        }, options);
          	        
    	var updatePerfectScrollbar = function(element) {
    		var scrollbar_y = element.find('.ps-scrollbar-y');
    		$.when(
    			$(element).perfectScrollbar('update')
    		).done(function(evt){
    			scrollbar_y.show();
    		});
    	};  
		
    	var scrollDropDownIfNeeded = function(element) {
    		var scrolldiv = $(element).parent().parent();
    		//if scroll is needed
    		var opt =  $(element);
    		if (opt.length > 0) {
    			var pos = parseInt(($(opt).position().top));
    			var ch = parseInt(scrolldiv.height());

    			if (pos > ch || pos < 0) {
    				var topVal = pos + scrolldiv.scrollTop() - (ch/2);
    				$.when(    					
    					$(scrolldiv).animate({scrollTop:topVal}, 200)
    				).done(function(){
    					updatePerfectScrollbar(scrolldiv);    					
    				});
    			} else {    				
    				updatePerfectScrollbar(scrolldiv);
    			}
    		} else {
    			updatePerfectScrollbar(scrolldiv);
    		}
    	};


		return this.each( function() {				
			var uniqueId = thisObj.uniqueId().attr('id');
			$.when(  
				buildContainer(uniqueId)
			).done(
				$.when(	
				thisObj.children().each( function() {
					$(thisObj).siblings('.selectBox_' + uniqueId).children('.selectOptions').children('.scrolldiv')
						.append("<span class='selectOption' value='" + $(this).attr("value") + "'>" + $(this).html() + "</span>");
				})	
				).done( function() {
					enableSelectBoxes(thisObj.siblings('.selectBox_' + uniqueId));
					var numRows = 0;
					var newHeight = 0;
					var spanElem = thisObj.siblings('.selectBox_' + uniqueId).children('.selectOptions').children('.scrolldiv').children('span');
					var spanCSS = $(thisObj).siblings('.selectBox_' + uniqueId).children('.selectOptions').children('.scrolldiv').children('span:first');
					
					var elemHeight = parseInt(spanCSS.css("line-height").replace(/[^0-9]+/g, '')) + parseInt(spanCSS.css("padding-top").replace(/[^0-9]+/g, '')) + parseInt(spanCSS.css("padding-bottom").replace(/[^0-9]+/g, ''));
					var elemFontSize = parseInt(spanCSS.css("font-size").replace(/[^0-9]+/g, ''));

					$.each(spanElem, function () {
						numRows++;
						newHeight = newHeight + elemHeight;  // ($(this).text() == "" ? elemHeight - elemFontSize  : elemHeight); 
						if (numRows == settings.visibleRows) {							
							needsScroll = true;					
							return false;
						}						 						
					});						
					$(thisObj).siblings('.selectBox_' + uniqueId).children(' .selectOptions').css("height", newHeight + 'px');
					if (needsScroll) {						
						$(thisObj).siblings('.selectBox_' + uniqueId).children(' .selectOptions').perfectScrollbar();
					}
					thisObj.remove();
				})
			);	
        });
		
		function buildContainer( container ) {
			var optionSelected = thisObj.children('option:selected').text();
			var optionSelectedValue = thisObj.children('option:selected').attr("value");
			$.when(
			    $('#' + container).after("<div class='selectBox selectBox_" + container + "'></div>")
			).done( function() {
				$.when(
					$(thisObj).siblings('.selectBox_' + container).append("<span class='selected'>" + (optionSelected != "" ? optionSelected : "") + "</span>")
						.append("<span class='selectArrow'></span>")
						.append("<input id='" + container + "_Text' class='inputText' type='text' value='' autocomplete='off' name='@where." + container + "_Text'>")
						.append("<input id='" + container + "_TextHidden' class='inputTextHidden' type='text' style='display:none;' value='" + (optionSelectedValue != "" ? optionSelectedValue : "") + "' name='" + thisObj.attr("name") + "'>")
						.append("<div class='selectOptions' style='height: 300px;'></div>")
				).done( function (){
					$(thisObj).siblings('.selectBox_' + container).children('span.selected').css("width", settings.width + 'px');					
					$(thisObj).siblings('.selectBox_' + container).children('.selectOptions').append("<div class='scrolldiv'></div>");					
				});								
			});    
		}
		
		function enableSelectBoxes(dropDown){
			dropDown.each(function(){
				$('body').click(function(evt) {
					var elems = dropDown.children('span.selected,span.selectArrow');
					var hideSelect = true;
					var target = evt.target;
					$.each(elems, function() {
						if (target == $(this).get(0)) {
							hideSelect = false;
							return false;
						}  
					});				
					if(hideSelect && dropDown != null) {
						dropDown.children('div.selectOptions').css("display", "none");
						dropDown.children('.inputText').css('display','none');
					}
				});	
				
				$(this).children('span.selected').html($(this).children('div.selectOptions').children('span.selectOption:first').html());
				$(this).attr('value',$(this).children('div.selectOptions').children('span.selectOption:first').attr('value'));
				
				$(this).children('span.selected,span.selectArrow').click(function(){
					if($(this).parent().children('div.selectOptions').css('display') == 'none'){
						$(this).parent().children('div.selectOptions').css('display','block');
						$(this).parent().children('.selectOptions').css("width", (settings.width + $(this).parent().children('span.selectArrow').width()) + 'px' );
						var scrollupdate = dropDown.children('.selectOptions');												
						var navigate = scrollupdate.find('span.navigate');
						if (scrollupdate.find("span.selectOption").hasClass("navigate") == true) {
							scrollDropDownIfNeeded(navigate);
						} else {
							scrollupdate.scrollTop(0);
						}						
						scrollupdate.perfectScrollbar('update');
						dropDown.children('span.selected').click();
					} else {
						$(this).parent().children('div.selectOptions').css('display','none');
						$(this).siblings('.inputText').css({"display": "none", "width" : ($(this).siblings('span.selected').width() - 10) + 'px'});
					}
				});
				
				$(this).children('span.selected').click(function(){
					$(this).parent().children('div.selectOptions').css('display','block');
					$(this).keyup();
				});			
								
				$(this).find('span.selectOption').click(function(){								
					$(this).closest(dropDown).attr('value',$(this).attr('value'));
					$(this).closest('div.selectOptions').siblings('span.selected').html($(this).html());		
					$(this).closest('div.selectOptions').parent().children('.inputText').css("display", "none");
					$(this).closest('div.selectOptions').parent().children('.inputTextHidden').val($(this).attr('value'));
					$(this).closest('div.selectOptions').css('display','none');
					$(this).siblings(".navigate").removeClass("navigate");
					$(this).addClass("navigate");
				});
				
				$(this).children('span.selected').keyup(function(){
					var inputVar = $(this).siblings('.inputText');
					inputVar.css({"display": "block", "width" : ($(this).width() - 10) + 'px'});
					inputVar.focus();
					inputVar.keyup(function(evt) {
						var keyCod = (evt.keyCode ? evt.keyCode : evt.which);
						if (keyCod == 38 || keyCod == 40 || keyCod == 13) {
							// Do nothing
						} else {
							filterSelect(dropDown, $(this).val(), true);
							dropDown.children('.selectOptions').perfectScrollbar('update');
						}	
					});									
				});					
				
				$(this).children('span.selected').siblings('.inputText').bind("valuechange", function() {					
					if (this.value == "") {						
						filterSelect(dropDown, "", false);
						dropDown.children('.selectOptions').find(".navigate").removeClass("navigate");
						dropDown.children('.selectOptions').perfectScrollbar('update');	
						$(this).siblings('span.selected').html($(this).siblings('selectOptions').find('span.selectOption:first').html());
					}
				});		
				
				$(this).children('span.selected').siblings('.inputText').bind("keydown", function(evt) {
					var keyCod = (evt.keyCode ? evt.keyCode : evt.which);
					if (keyCod == 38 || keyCod == 40 || keyCod == 13) {
						if(keyCod == 13) {
							  evt.preventDefault();		
 							  navigate(keyCod, $(this));
                              return false;		  
						} else {
							navigate(keyCod, $(this));
						}												
					} else {
						$(this).siblings('div.selectOptions').find('span.selectOption').each(function () {
							$(this).removeClass("navigate");
						});
					}
				});

				$(this).children('span.selected').siblings('.inputTextHidden').bind("valuechange", function() {
					if (this.value == "") {
						filterSelect(dropDown, "", false);
						dropDown.children('.selectOptions').find(".navigate").removeClass("navigate");
						dropDown.children('.selectOptions').perfectScrollbar('update');	
						$(this).siblings('span.selected').html($(this).siblings('.selectOptions').find('span.selectOption:first').html());
					}
				});
				
			});
		}	
		
		function filterSelect(dropDown, inputVal, show) {
			if (show) {
				if (dropDown.children('.selectOptions').css('display') == 'none') dropDown.children('.selectOptions').css('display', 'block');
			}
			var spanElem = dropDown.children('.selectOptions').children('.scrolldiv').children('span');
			var inputLen = inputVal.length;
			var newHeight = 0;			
			var numRows = 0;
			$.each(spanElem, function () {						
				if ($(this).html().substring(0, inputLen).toUpperCase() == inputVal.toUpperCase() || inputLen == 0) {
					numRows++;
					$(this).removeClass("displaynone");
				} else {
					$(this).addClass("displaynone");
					
				}				
			});
			var spanCSS = spanElem.get(0);
			
			var elemHeight = parseInt($(spanCSS).css("line-height").replace(/[^0-9]+/g, '')) + parseInt($(spanCSS).css("padding-top").replace(/[^0-9]+/g, '')) + parseInt($(spanCSS).css("padding-bottom").replace(/[^0-9]+/g, ''));
			if (numRows <= settings.visibleRows) { 
				newHeight = elemHeight * numRows;
			} else if (numRows > settings.visibleRows) {
				newHeight = elemHeight * settings.visibleRows;
			}
			dropDown.children('.selectOptions').css("height", newHeight + 'px');			
		}		
		
		function navigate(key_Code, $this) {
			var numoptions = $this.siblings('div.selectOptions').find('span.selectOption').length;
			var selectOption = $this.siblings('div.selectOptions').find('span.selectOption').not(".displaynone");
			var navigate = selectOption.closest('span.navigate'); 
			var idx = $(navigate).index();
			var selected;
			if (idx == -1) {
				selected = $this.siblings('div.selectOptions').find('span.selectOption').not(".displaynone")[0];
				$(selected).addClass("navigate");
			} 
		
			switch (key_Code) {	
			case 38:   // Up Arrow
				if (idx > 0 && idx <= numoptions - 1) {
					selected = $(selectOption).closest('.navigate').prev();
					$(navigate).removeClass("navigate");
					$(selected).addClass("navigate");
					scrollDropDownIfNeeded(selected);
				}
				break;
			case 40:   // Down Arrow 
				if (idx >= 0 && idx < numoptions - 1) {					
					selected = $(selectOption).closest('.navigate').next();
					$(navigate).removeClass("navigate");					
					$(selected).addClass("navigate");
					scrollDropDownIfNeeded(selected);
				}				
				break;
			case 13:  // Enter
				$(navigate).click();
				break;
			}						
		}
				
	};     
}
( jQuery ));