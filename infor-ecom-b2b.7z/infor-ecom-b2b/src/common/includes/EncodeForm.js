
<script id="EncodeForm" type="text/javascript">
function EncodeItemId(id)
{
	var ret = "";
	var sub = id.indexOf("+_");

	if (sub != -1)
	{
		ret = id.substring(0, sub + 2);

		for (var i = sub + 2; i < id.length; i++)
		{
 			if (id.charAt(i) == '@') { ret += '@'; }
			else { ret += encodeURIComponent(id.charAt(i)); }
		}
	}
	else
	{
		ret = id;
	}



	return ret;
}

function EncodeForm()
{
  for (var i=0; i<document.forms.length; i++)
  {
	for (var j=0; j<document.forms[i].elements.length; j++)
	{
		document.forms[i].elements[j].name = EncodeItemId(document.forms[i].elements[j].name);
	}
  }

  return true;
}

</script>
