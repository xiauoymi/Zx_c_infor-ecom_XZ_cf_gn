$(document).ready(function() {
	initDebugButton();
	initIaMgtButton();
});

function initDebugButton() {
	if($('#debugButton')) {
		$('#debugButton').click(function(event) {
			$('.iaDebug').fadeToggle('fast', 'linear');
		});
	}
}

function initIaMgtButton() {
	if($('#iaMgtButton')) {
		$('#iaMgtButton').click(function(event) {
			event.preventDefault();
			window.open('http://localhost:7201/Manager/', 'IA Manager'); //TODO: use the one from Application Details
		});
	}
}