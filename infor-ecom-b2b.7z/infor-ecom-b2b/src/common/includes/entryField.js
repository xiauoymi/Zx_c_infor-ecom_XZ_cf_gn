<script type="text/javascript">
function initEntryDetailField(){
    var areaElem = document.getElementsByTagName('TEXTAREA'); 
    for (var a=0;a < areaElem.length; a++){
        var parentDiv = areaElem[a].parentNode;
        if(parentDiv.tagName=='DIV'){
/*            if(areaElem[a].cols >= 60)
            parentDiv.style.width="600px";
            else
            parentDiv.style.width="440px";
*/
            var parentDivWidth = areaElem[a].cols * 10;
            parentDiv.style.width=parentDivWidth;
        }
    }
    
    var selectElem = document.getElementsByTagName('SELECT'); 
    for (var a=0;a < selectElem.length; a++){
        var parentDiv = selectElem[a].parentNode;
        if(parentDiv.tagName=='DIV'){
            //alert(selectElem[a].offsetWidth);
            parentDiv.style.width=selectElem[a].offsetWidth+40;
        }
        if(selectElem[a].previousSibling) {
            parentDiv.style.width=selectElem[a].offsetWidth+250;
        }
    }
    var oElem = document.getElementsByTagName('DIV'); 
    var smallContainer = 250;
    var medContainer = 287;
    var lrgContainer = 367;
    var fiftyContainer = 365;
    for (var a=0;a < oElem.length; a++){
        var parentDiv = oElem[a].parentNode;
        var inputs = parentDiv.getElementsByTagName("INPUT");
        var cnt=0;
        for (var b=0;b < inputs.length; b++){
            if(inputs[b].className=="list_button"){
               cnt++;
            }
        }
        if (oElem[a].className == "inputContainerSmall"){      
            if(cnt>0){
                parentDiv.style.width=smallContainer+(cnt*40)+"px";
            }else{
                oElem[a].parentNode.style.width=smallContainer+"px";
            }
        }else if (oElem[a].className == "inputContainerMedium"){ 
            if(cnt>0){
                parentDiv.style.width=medContainer+(cnt*40)+"px";
            }else{
                oElem[a].parentNode.style.width=medContainer+"px";
            }
        }else if (oElem[a].className == "inputContainerLarge"){ 
            if(cnt>0){
                parentDiv.style.width=lrgContainer+(cnt*40)+"px";
            }else{
                oElem[a].parentNode.style.width=lrgContainer+"px";
            }
        }else if (oElem[a].className == "inputContainer_50"){ 
            if(cnt>0){
                parentDiv.style.width=fiftyContainer+(cnt*40)+"px";
            }else{
                oElem[a].parentNode.style.width=fiftyContainer+"px";
            }
        }
    }
    
    //disabled fields
    var disabledFields = document.getElementsByTagName('INPUT'); 
    for (var a=0;a < disabledFields.length; a++){
        if(disabledFields[a].disabled || disabledFields[a].className=="readonly"){
            var spanLeft = disabledFields[a].previousSibling;
            spanLeft.style.background = "transparent url(../common/style-bc/input_field_box_gray-1.png) no-repeat scroll 0% ";
            disabledFields[a].style.background = "transparent url(../common/style-bc/02_input_field_box_gray-2.gif) repeat-x scroll 0% ";
            var spanRight = disabledFields[a].nextSibling;
            spanRight.style.background = "transparent url(../common/style-bc/input_field_box_gray-3.png) no-repeat scroll 0% ";
         }
    }
}

function disableFields(){
    var disabledFields = document.getElementsByTagName('INPUT'); 
    for (var a=0;a < disabledFields.length; a++){
        if(disabledFields[a].disabled || disabledFields[a].className=="readonly"){
            var spanLeft = disabledFields[a].previousSibling;
            if(spanLeft && spanLeft.tagName=="SPAN"){
                spanLeft.style.background = "transparent url(../common/style-bc/input_field_box_gray-1.png) no-repeat scroll 0% ";
                disabledFields[a].style.background = "transparent url(../common/style-bc/02_input_field_box_gray-2.gif) repeat-x scroll 0% ";
            }
            var spanRight = disabledFields[a].nextSibling;
            if(spanRight && spanRight.tagName=="SPAN"){
                spanRight.style.background = "transparent url(../common/style-bc/input_field_box_gray-3.png) no-repeat scroll 0% ";
            }
         }else{
            var spanLeft = disabledFields[a].previousSibling;
            if(spanLeft && spanLeft.tagName=="SPAN"){
                spanLeft.style.background = "transparent url(../common/style-bc/02_input_field_box-1.png) no-repeat scroll 0% ";
                disabledFields[a].style.background = "transparent url(../common/style-bc/02_input_field_box-2.png) repeat-x scroll 0% ";
            }
            var spanRight = disabledFields[a].nextSibling;
            if(spanRight && spanRight.tagName=="SPAN"){
                spanRight.style.background = "transparent url(../common/style-bc/02_input_field_box-3.png) no-repeat scroll 0% ";
            }
         }
    }
}

function initEntryDetailField(){}
function disableFields(){}

</script>
