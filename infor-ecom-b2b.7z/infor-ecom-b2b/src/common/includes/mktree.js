// mktree
// ===================================================================
// Based on work by Matt Kruse http://www.mattkruse.com/
// ===================================================================

//dojo.require("dojo.debug.console");
//djConfig.isDebug = true;

if (!document.MkTree) {

document.MkTree = function(id, getChildGroups) {

var that = this;
var treeId = id;
var autoCloseSiblings = false;
var autoOpenFirstChild = false;
var treeClass = 'mktree';
var nodeClosedClass = 'liClosed';
var nodeOpenClass = 'liOpen';
var nodeBulletClass = 'liBullet';
var nodeLinkClass = 'bullet';
var preProcessTrees = true;
this.getChildGroups = getChildGroups;

this.setAutoCloseSiblings = function(autoClose) {
    autoCloseSiblings = autoClose;
}

this.setAutoOpenFirstChild= function(autoOpen) {
    autoOpenFirstChild = autoOpen;
}

// convert trees in the document, by processing all uls of class 'mktree'
function convertTrees(id) {
  if(preProcessTrees) {
    if(!document.createElement) {
      return;
    }
    if (id) {
		if( document.getElementById(id)!=null){
      var ul = document.getElementById(id);
	  if(ul!=null)
		{
      if (ul.nodeName == "UL" && ul.className == treeClass) {
        processList(ul);
      }
		}
		}
    } else {
      var uls = document.getElementsByTagName("ul");
      for(var uli = 0; uli < uls.length; uli++) {
        var ul=uls[uli];
        if(ul.nodeName=="UL" && ul.className==treeClass) {
          processList(ul);
        }
      }
    }
  }
}
convertTrees(id);

// fully expand a list with a given ID
this.expandTree = function(treeId) {
  var ul = document.getElementById(treeId);
  if(ul != null) {
    that.expandCollapseList(ul,nodeOpenClass);
  }
}

// fully collapse a list with a given ID
this.collapseTree = function(treeId) {
  var ul = document.getElementById(treeId);
  if(ul != null) {
    that.expandCollapseList(ul,nodeClosedClass);
  }
}

// fully expand a branch to a list item with a given ID
this.expandToItem = function(treeId, itemId) {
  var ul = document.getElementById(treeId);
  var item = document.getElementById(itemId);
  if (ul == null || item == null) {
    return false;
  }
  var pitem = item.parentNode;
  if (pitem.id == treeId) {
    return false;
  }
  if (pitem.nodeName == "UL") {
    processList(pitem);
  }
  pitem = pitem.parentNode;
  if (pitem.nodeName == "LI") {
    pitem.className = nodeOpenClass;
    that.expandToItem(treeId, pitem.id);
  }

  if (item.scrollIntoView) {
    item.scrollIntoView(false);
  }
  return true;
}

// find a link inside an item and fully expand the list to that item
this.expandToLink = function(loc) {
  var as = document.getElementById(treeId).getElementsByTagName('A');
  for (var i=0; i<as.length; i++) {
    if (as[i].href.indexOf(loc) > -1) {
      for (var p = as[i].parentNode; p != null && (p.id != that.treeId); p = p.parentNode) {
        if (p.nodeName == "LI") {
          that.liOpen(p);
        }
      }
    }
  }
}

// fully expand a branch to a list item with a given ID, and expand the list item itself
this.expandItem = function(treeId, itemId) {
  var li = document.getElementById(itemId);
  if (li == null) {
    // node not loaded yet, get and expand parent
    var parentId = (getParentId == undefined) ? '' : getParentId(itemId);
    if (parentId != undefined && parentId.length > 0) {
      expandItem(treeId, parentId);
      li = document.getElementById(itemId);
    }
    // exit recursion if parent not found or node still not loaded
    if (li == null) {
      return;
    }
  }
  that.liOpen(li);
}

// fully expand or collapse a list
// - expand if cName = nodeOpenClass
// - collapse if cName = nodeClosedClass
this.expandCollapseList = function(ul,cName) {
  // Iterate LIs
  for (var li = ul.firstChild; li != null; li = li.nextSibling ) {
    if (li.nodeName == "LI") {
      // open/close li node
      if (cName == nodeOpenClass && li.className == nodeClosedClass) {
        that.liOpen(li);
      } else if (cName == nodeClosedClass && li.className == nodeOpenClass) {
        that.liClose(li);
      }
      // expand sublists if any
      for (var subUl = li.firstChild; subUl != null; subUl = subUl.nextSibling) {
        if (subUl.nodeName=="UL") {
          that.expandCollapseList(subUl,cName);
        }
      }
    }
  }
}

// click span element inside li node
function spanClick() {

	if(null!=document.TreeForm)
	{
		document.TreeForm.Action.value=this.parentNode.id;

		//alert(document.TreeForm.Action.value);
		postAction('TreeUpdate.jsp', dojo.byId('TreeForm'));
		//alert('postAction done');
	} 

  var li = this.parentNode;
  if (li.className == nodeOpenClass && !autoOpenFirstChild) {
    that.liClose(li);
  } else {
    that.liOpen(li,autoOpenFirstChild);
  }
}

// close li node  
this.liClose = function(li) {
  li.className = nodeClosedClass;
}

// open li node - load sublist if not already done
this.liOpen = function(li,autoOpenFirstChild) {
  var ul = li.firstChild;  
  // get sublist
  while (ul != null && ul.nodeName != "UL") {
    ul = ul.nextSibling
  }  
  // Perform lazy load if sublist is not loaded yet
  if (ul == null) {
    var childGroups = (that.getChildGroups == undefined) ? '' : that.getChildGroups(li.id); 
    if (childGroups != '') {
      ul = document.createElement("UL"); 
      ul.innerHTML = childGroups;
      li.appendChild(ul); 
    }
  }
  if (autoCloseSiblings) {
    for (var sli = li.parentNode.firstChild; sli != null; sli = sli.nextSibling) {
      that.liClose(sli);
    }
  }
  if (ul == null) {
    // still no sublist, so it must be a leaf node
    li.className = nodeBulletClass;
  } else {
    // process sublist and open it
    processList(ul);
    li.className = nodeOpenClass;
    
  
    // open first child
    if (autoOpenFirstChild) {
      var openChild = null;
      for (var sli = ul.lastChild; sli != null; sli = sli.previousSibling) {
        if (sli.nodeName == "LI") {
          if (openChild == null || sli.className != nodeClosedClass) {
            openChild = sli;
          }					
        }
      }
      if (openChild != null) {
        that.liOpen(openChild,autoOpenFirstChild);
        var s = openChild.firstChild;
        if (s) {
          for (var a = s.firstChild; a != null; a = a.nextSibling) {
            if (a.nodeName == "A") {
              if (location.href.indexOf(a.href) < 0) {
                location.href = a.href;
              }
              break;
            }
          }
        }
      }
    }
  }
}

// process ul, i.e. append a clickable span element to all li nodes inside the list 
function processList(ul) {
  if (ul.isProcessed != undefined) {
    return;
  }
  
  // Iterate LIs
  // Append a <span> element after each <li>
  //  - if leaf node   : a bullet icon
  //  - if non-leaf node : a clickable expand/collapse icon
  for (var li = ul.firstChild; li != null; li = li.nextSibling) {
    if (li.nodeName == "LI") {  
      var s = document.createElement("SPAN");
      var t = '\u00A0'; // &nbsp;
      s.className = nodeLinkClass;
      if (li.className != nodeBulletClass) {
        // This LI is a +/- node
        li.className = nodeClosedClass;
        // If it's just text, make the text work as the link also
        s.onclick = spanClick;
      }
      else {
        // This LI is a bullet node
        s.onclick = function () { return; }
      }

      var c = li.firstChild;
      if (c) {
        li.replaceChild(s,c);
        s.appendChild(c);
      } else {
        li.insertBefore(s,li.firstChild);
      }          
    }
  }
  ul.isProcessed = true;  
}
}
}


function getWinHeight() {
  var winHeight = 0;
  if( typeof( window.innerHeight) == 'number' ) {
    //Non-IE
    winHeight = window.innerHeight;
  } else if( document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) {
    //IE 6+ in 'standards compliant mode'
    winHeight = document.documentElement.clientHeight;
  } else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) {
    //IE 4 compatible
    winHeight = document.body.clientHeight;
  }
  return winHeight;
}

/*
function move_DesignElements() { 
IE7 = ((document.all)&&(navigator.appVersion.indexOf("MSIE 7.")!=-1)) ? true : false;
var browser=navigator.appName;
var b_version=navigator.appVersion;
var version=parseFloat(b_version);

var len=document.getElementsByTagName("div");
for(i=0;i < len.length ;i++)
 {  if( len[i].className == "left_outer" || len[i].className == "left_inner" || len[i].className == "left_bg" || len[i].className == "left_bottom"  ||
        len[i].className == "right_outer" || len[i].className == "right_inner" || len[i].className == "right_bg" || len[i].className == "right_bottom")
      {

       if( len[i].className == "left_bottom" || len[i].className == "right_bottom") { len[i].style.top = document.body.clientHeight+"px";
       } else { 
         len[i].style.height = document.body.clientHeight+"px"; }
     }
    if ((browser=="Microsoft Internet Explorer") && (version>6)) {
       document.getElementById('layout_bottom').style.top = document.body.clientHeight+10+"px";
    }
 }
}
*/