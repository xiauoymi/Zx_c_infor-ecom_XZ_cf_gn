
<script id="texteditor" type="text/javascript">
// Infor eCom JavaScript File: textEditor.js

$(document).ready(function() {
	$('.textEditor').each(
		function() {
			$(this).data('texteditorlabel', '<%=getSiteText(request, "texteditor", "texteditor")%>');
			$(this).data('previewlabel', '<%=getSiteText(request, "texteditor", "preview")%>');
			$(this).data('cancellabel', '<%=getSiteText(request, "texteditor", "cancel")%>');
			$(this).data('donelabel', '<%=getSiteText(request, "texteditor", "done")%>');
			$(this).textEditor($(this).data());
		}
	);
});
</script>
