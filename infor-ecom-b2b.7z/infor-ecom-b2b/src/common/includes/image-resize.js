/**
 * 
 */

function resizeImage(selector){//this method resizes all images to its aspect ratio and align it to center
	if(selector==null){
		selector=".fitAspectRatio";
	}
	$(selector).each(function(){
		var patt = new RegExp("/default/|../common/");
		if(!patt.test($(this).attr("src"))){
			if(!$(this).hasClass("fitAspectRatio")){
				$(this).addClass("fitAspectRatio");
			}
			if(!$(this).hasClass("centerImage")){
				var container=$(this).parent();
				if(container.is("a")){
					container=$(container).parent();
				}
				$(container).css("position","relative");//Added this to prevent the images from going out of its container
				$(this).addClass("centerImage");
			}
		}
		else{
			$(this).removeClass("fitAspectRatio");
		}
	});
}

