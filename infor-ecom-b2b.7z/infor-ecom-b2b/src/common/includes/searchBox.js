<script type="text/javascript">
var ie = (document.all) ? true : false;
function changeTextImg(oSearchBox,Img1,Img2,Img3,Img4){

var oSearchBoxR = document.getElementsByTagName('span');
    if (oSearchBox.id == "searchBox" || oSearchBox.id == "code"){	
	     if(oSearchBox.value ==""){
	       oSearchBox.style.background="transparent url("+Img1+") repeat-x scroll 0%";
	       oSearchBox.parentNode.childNodes[2].style.background="transparent url("+Img3+") no-repeat scroll 0%";
	    }
	    else{
	       oSearchBox.style.background="transparent url("+Img2+") repeat-x scroll 0%";
	       oSearchBox.parentNode.childNodes[2].style.background="transparent url("+Img4+") no-repeat scroll 0%";       
	    }    
	}
}

function initSearchBox(objName,objType,Img1,Img2){
var oSearchBox = document.getElementsByTagName(objType);    
    if (oSearchBox.length > 0){    
        for (var a=0;a<oSearchBox.length;a++){
            if (oSearchBox[a].id == objName && oSearchBox[a].onkeyup != undefined) {				
              if(oSearchBox[a].value == ""){            
                oSearchBox[a].style.background="transparent url("+Img1+") repeat-x scroll 0%";                
                oSearchBox[a].parentNode.childNodes[2].style.background="transparent url("+Img2+") no-repeat scroll 0%";
              }
            }               
        }
    }
}

function setStyleByClass(t,c,p,v){
	var elements;
	if(t == '*') {
		// '*' not supported by IE/Win 5.5 and below
		elements = (ie) ? document.all : document.getElementsByTagName('*');
	} else {                   
		elements = document.getElementsByTagName(t);                            
	}
        
	for(var i = 0; i < elements.length; i++){
		var node = elements.item(i);        
		for(var j = 0; j < node.attributes.length; j++) {                
			if(node.attributes.item(j).nodeName == 'class') {				
				if(node.attributes.item(j).nodeValue == c) {
					eval('node.style.' + p + " = '" +v + "'");                    
				}
			}
		}
	}
}


 function detectBrowserIE(){
     var sBrowser = navigator.appName; 
     if (sBrowser == "Microsoft Internet Explorer"){
        return 1;
     }else{
        return 2;
     }      
 }
 
 function initGroupBox(){
 
  var oElem = document.getElementsByTagName('DIV');        
  for (var a=0;a < oElem.length; a++){
    if (oElem[a].className == "entry_detailsbody"){                 
        for (var b=0; b < oElem[a].childNodes.length; b++){
            var oGroupBox = oElem[a].childNodes[b];
            if (oGroupBox.tagName == "TABLE"){
               for (var c=0; c < oGroupBox.childNodes.length; c++){
                    if (oGroupBox.childNodes[c].tagName == "TBODY"){
                        if (oGroupBox.childNodes[c].childNodes.length < 3 ){                            
                           var oCenter = oElem[a].parentNode;                           
                          
                           if (detectBrowserIE() == 1){
                            var oRight = oCenter.parentNode.childNodes[2];
                            var oLeft = oCenter.parentNode.childNodes[0];                            
                            oLeft.className = "grp_corner_l";
                            oCenter.className = "grp_center_s";
                            oRight.className = "grp_corner_r";                            
                           }else{                                  						   
                            var oLeft = oCenter.parentNode.childNodes[1];
                            var oRight = oCenter.parentNode.childNodes[3];                           
                            oLeft.childNodes[1].setAttribute("class","entry_leftdetailsbody_s");
                            oCenter.setAttribute("class","grp_center_s");
                            oRight.childNodes[1].setAttribute("class","entry_rightdetailsbody_s");                           
                           }                                                     
                        }
                    }
               }
            }            
        }
    }
  }
 }

/* function initWorkBenchGroupBox(){
   
  var oElem = document.getElementsByTagName('DIV');
  for (var a=0;a < oElem.length; a++){
    if (oElem[a].className == "entry_detailsbody"){            
        var oPTR = oElem[a].parentNode.parentNode;
        oElem[a].parentNode.className = "grp_center_s";
        oPTR.childNodes[1].childNodes[1].className = "entry_leftdetailsbody_s";
        oPTR.childNodes[3].childNodes[1].className = "entry_rightdetailsbody_s";        
    }
  }
}*/

function initWorkBenchGroupBox(){
var oElem = document.getElementsByTagName('DIV');
  for (var a=0;a < oElem.length; a++){
    if (oElem[a].className == "entry_detailsbody"){            
        var oPTR = oElem[a].parentNode.parentNode;                
        //alert(oPTR.childNodes[1].childNodes[0].className);
        if (detectBrowserIE() == 1){
           // alert(oPTR.childNodes[0].childNodes[0].className);
            /*for (var b = 0; b < oPTR.childNodes[1].childNodes[0].childNodes.length; b++){
                //alert(oPTR.childNodes[0].childNodes[0].childNodes[b].tagName);
            }            */ oElem[a].parentNode.className = "grp_center_s";
            oPTR.childNodes[0].childNodes[0].className = "entry_leftdetailsbody_s";
            oPTR.childNodes[2].childNodes[0].className = "entry_rightdetailsbody_s";        
        }
        else{        
            oElem[a].parentNode.className = "grp_center_s";
            oPTR.childNodes[1].childNodes[1].className = "entry_leftdetailsbody_s";
            oPTR.childNodes[3].childNodes[1].className = "entry_rightdetailsbody_s";        
            //alert(oPTR.childNodes[3].childNodes[1].className);        
        }
    }
  }
  
}

function initAdvanceSearchPosition(mode){
    if (mode != 0){      
	    if (detectBrowserIE() != 1){
	        setStyleByClass("span","entry_leftdetailsbody","background",        
	        "transparent url(../common/style-bc/13_groupbox_panel_l_sml.gif) no-repeat scroll 0% 0%");
	        setStyleByClass("td","grp_center","background",
	        "transparent url(../common/style-bc/13_groupbox_panel_cn_sml.gif) repeat-x scroll 0% 0%");
	        setStyleByClass("span","entry_rightdetailsbody","background",
	        "transparent url(../common/style-bc/13_groupbox_panel_r_sml.gif) no-repeat scroll 0% 0%");        
	        setStyleByClass("span","entry_leftdetailsbody","height","80px");
	        setStyleByClass("td","grp_center","height","80px");
	        setStyleByClass("span","entry_rightdetailsbody","height","80px");
		}else{
	        setStyleByClass("span","entry_leftdetailsbody","background",        
	        "transparent url(../common/style-bc/groupbox_l_sml.gif) no-repeat scroll 0% 0%");
	        setStyleByClass("td","grp_center","background",
	        "transparent url(../common/style-bc/groupbox_c_sml.gif) repeat-x scroll 0% 0%");
	        setStyleByClass("span","entry_rightdetailsbody","background",
	        "transparent url(../common/style-bc/groupbox_r_sml.gif) no-repeat scroll 0% 0%");        
			
	        setStyleByClass("span","entry_leftdetailsbody","height","80px");
	        setStyleByClass("td","grp_center","height","80px");
	        setStyleByClass("span","entry_rightdetailsbody","height","80px");			
		}
    }else{
        setStyleByClass("span","entry_leftdetailsbody","background",        
        "transparent url(../common/style-bc/13_groupbox_panel_l.gif) no-repeat scroll 0% 0%");
        setStyleByClass("td","grp_center","background",
        "transparent url(../common/style-bc/13_groupbox_panel_cn.gif) repeat-x scroll 0% 0%");
        setStyleByClass("span","entry_rightdetailsbody","background",
        "transparent url(../common/style-bc/13_groupbox_panel_r.gif) no-repeat scroll 0% 0%");
        setStyleByClass("span","entry_leftdetailsbody","height","133px");
        setStyleByClass("td","grp_center","height","133px");
        setStyleByClass("span","entry_rightdetailsbody","height","133px");        
    }   
}

function adjustFrameSize(iSize,sFrameId){
   var oTargetFrame = parent.document.getElementsByTagName('frameset');
   for (var a = 0; a < oTargetFrame.length; a++){
     if (sFrameId == oTargetFrame[a].id){
        oTargetFrame[a].rows = iSize+",*";
     }
   }
   
}

function changeTextImg(oSearchBox,Img1,Img2,Img3,Img4){}
function setStyleByClass(t,c,p,v){}
function detectBrowserIE() {return false;}
function initGroupBox(){}
function initWorkBenchGroupBox(){}
function initAdvanceSearchPosition(){}
function adjustFrameSize(){}

function supports_input_placeholder() {
	var i = document.createElement('input');
	return 'placeholder' in i;
}

function initSearchBox(objName,objType,Img1,Img2){
	$('.listFilterFieldContainer input').each(function(){
			if (this.id == "searchBox" || this.id == "code" || this.id == "market") {
			var $this = $(this);
			var nextSib = $this.next("span.inputRight");
			var prevSib = $this.prev("span.inputLeft");
			prevSib.css("display", "inline-block");
			nextSib.css("display", "inline-block");
		}
	});
}

$(document).ready(function(){
	var searchtext = '<%=__user.format(getSiteText(request, "PseudoPage", "searchplaceholder"))%>';
	$('.listFilterFieldContainer input').each(function(){
		if (this.id == "searchBox" || this.id == "code" || this.id == "market") {
			var $this = $(this);
			var nextSib = $this.next("span.inputRight");
			var prevSib = $this.prev("span.inputLeft");
			//prevSib.disableSelection();
			prevSib.addClass("searchplaceholder").text(searchtext);
			if ($this.val() != "") {
				prevSib.hide();
				nextSib.hide();
			}
			
			var zindex = prevSib.zIndex();
			prevSib.zIndex(zindex);
			$this.zIndex(zindex + 1);
			prevSib.click(function(){$this.focus();});
			prevSib.dblclick(function(){$this.focus()});
			$this.keyup(function(){
				if ($this.val() == "") {
					prevSib.css("display", "inline-block");
					nextSib.css("display", "inline-block");
				} else {
					prevSib.hide();
					nextSib.hide();
				}
			});
		}
	});
});


</script>

