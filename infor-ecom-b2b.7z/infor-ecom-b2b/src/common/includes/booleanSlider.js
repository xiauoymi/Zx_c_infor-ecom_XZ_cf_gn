
$(document).ready(function(){
	$('input.booleanSlider:checkbox').each(function(idx, checkbox){
		var $checkbox = $(checkbox);
		var boolSliderDiv = null;
		boolSliderDiv =	$('<div>').attr('id','booleanSliderDiv_'+idx);
		boolSliderDiv.addClass('bool-slider');
		if(checkbox.checked) {
			boolSliderDiv.addClass("true");
        } else {
        	boolSliderDiv.addClass("false");
        }
		
		boolSliderDiv.append('<div class="inset"><div class="control"></div></div>');
		boolSliderDiv.insertBefore($checkbox);
		boolSliderDiv.data('checkbox',checkbox);
		$('.control',boolSliderDiv).click(function() {
	        if (!$(this).parent().parent().hasClass('disabled')) {
	            if ($(this).parent().parent().hasClass('true')) {
	                $(this).parent().parent().addClass('false').removeClass('true');
	            } else {
	                $(this).parent().parent().addClass('true').removeClass('false');
	            }
	            
	            var chk = $(this).parent().parent().data('checkbox');
	            if (chk) {
	            	$(chk).click();
	            }
	        }
		});
		$checkbox.hide();
	});
});

function resetBooleanSliders() {
	$('.bool-slider').each(function(){
		var $this = $(this);
		var chk = $this.data('checkbox');
		if (chk) {
			$this.removeClass('true');
			$this.removeClass('false');
			$this.addClass(''+chk.checked);
		}
	});
}
