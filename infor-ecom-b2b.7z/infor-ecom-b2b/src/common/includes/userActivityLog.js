function triggerUserActivityLogs() {
	$('.userActivityLogTrigger').each(
		function() {
			$.get('InsertUserActivityLog.jsp?%40field.ID%40key.%2B0%40comp.UserActivityLog&' + gCsrfTokenUrlParam, 
			$(this).data(),
			function(response) {
				//alert('response = ' + response);
			});
		});
};

$(document).ready(function() {
	triggerUserActivityLogs();
});