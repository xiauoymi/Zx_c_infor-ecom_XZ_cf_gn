var step=4;
var interval=10;

function moveDown(id){
  var content=document.getElementById(id);
 if(content!=null) {
  var contentheight=content.offsetHeight;
  stopScroll(id);	  
  if (content.offsetTop>=content.offsetParent.offsetHeight-contentheight)
    content.style.top=content.offsetTop-step+"px";
  content.movedownvar=setTimeout("moveDown('"+id+"')",interval);
 }
}

function moveUp(id){
  var content=document.getElementById(id);
  if(content!=null) {
  var contentheight=content.offsetHeight;  
  stopScroll(id);	  
  if (content.offsetTop<0)
    content.style.top=content.offsetTop+step+"px";
    content.moveupvar=setTimeout("moveUp('"+id+"')",interval);
  }
}

function stopScroll(id){
  var content=document.getElementById(id);
  if(content!=null) {
  if (content.moveupvar) 
    clearTimeout(content.moveupvar);
  if (content.movedownvar) 
    clearTimeout(content.movedownvar);
 }
}

function moveTop(id){
  var content=document.getElementById(id);
  if(content!=null) {
  stopScroll(id);
  content.style.top=0+"px";
  }
}
