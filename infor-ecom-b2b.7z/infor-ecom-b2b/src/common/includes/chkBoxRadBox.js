<script type="text/javascript">
var inputs;
var imgFalse = '../common/style-bc/09_checkbox_rest.gif';
var imgTrue = '../common/style-bc/09_checkbox_active.gif';

function replaceChecks() {
    
    //get all the input fields on the page
    inputs = document.getElementsByTagName('input');

    //cycle trough the input fields
    for(var i=0; i < inputs.length; i++) {

        //check if the input is a checkbox
        if(inputs[i].getAttribute('type') == 'checkbox') {
        	var className = inputs[i].className;
        	if (className.indexOf('booleanSlider') < 0 && $(inputs[i]).is(":visible")) {
        		//create a new image
                var img = document.createElement('img');
                
                //check if the checkbox is checked
                if(inputs[i].checked) {
                    img.src = imgTrue;
                } else {
                    img.src = imgFalse;
                }

                //set image ID and onclick action
                img.id = 'checkImage'+i;
                //set image
                img.onclick = new Function('checkChange('+i+')');
                //place image in front of the checkbox
                inputs[i].parentNode.insertBefore(img, inputs[i]);
                
                //onchange
                inputs[i].onchange = new Function('onChangeCheck('+i+')');
                
                //hide the checkbox
                inputs[i].style.display='none';
        	}
        }
        else if(inputs[i].getAttribute('type') == 'radio') {
            if(inputs[i].checked){
                inputs[i].parentNode.className = "radio selected";
                inputs[i].parentNode.style.backgroundPosition = "0 -52px";
            }else{
                inputs[i].parentNode.className = "radio";
				inputs[i].parentNode.style.backgroundPosition = "0 0";
            }
        }
    }
}

//change the checkbox status and the replacement image
function checkChange(i) {
    if(inputs[i].checked) {
        inputs[i].checked = '';
        document.getElementById('checkImage'+i).src=imgFalse;
    } else {
        inputs[i].checked = 'checked';
        document.getElementById('checkImage'+i).src=imgTrue;
    }
    if(inputs[i].onclick){
        eval(inputs[i].onclick());
    }
}

function resetChecks(){
    for(var i=0; i < inputs.length; i++) {
        if(inputs[i].getAttribute('type') == 'checkbox') {
        	if (document.getElementById('checkImage'+i)) {
        		if(inputs[i].checked) {
                    document.getElementById('checkImage'+i).src=imgTrue;
                } else {
                    document.getElementById('checkImage'+i).src=imgFalse;
                }
        	}
        }
    }
}

function replaceNewChecks() {
    //get all the input fields on the page
    inputs = document.getElementsByTagName('input');

    //cycle trough the input fields
    for(var i=0; i < inputs.length; i++) {

        //check if the input is a checkbox
        if(inputs[i].getAttribute('type') == 'checkbox') {
        	var className = inputs[i].className;
        	if (className.indexOf('booleanSlider') < 0 && $(inputs[i]).is(":visible")) {
        		var x = inputs[i].previousSibling;
            	
            	if (x && x.tagName == "IMG" && x.className == "checkImage") continue;
            	
                //create a new image
                var img = document.createElement('img');
                
                img.className = "checkImage";
                
                //check if the checkbox is checked
                if(inputs[i].checked) {
                    img.src = imgTrue;
                } else {
                    img.src = imgFalse;
                }
                

                //set image ID and onclick action
                img.id = 'checkImage'+i;
                //set image
                img.onclick = new Function('checkChange('+i+')');
                //place image in front of the checkbox
                inputs[i].parentNode.insertBefore(img, inputs[i]);
                
                //onchange
                inputs[i].onchange = new Function('onChangeCheck('+i+')');
                
                //hide the checkbox
                inputs[i].style.display='none';
        	}
        }
        else if(inputs[i].getAttribute('type') == 'radio') {
            if(inputs[i].checked){
                inputs[i].parentNode.className = "radio selected";
                inputs[i].parentNode.style.backgroundPosition = "0 -52px";
            }else{
                inputs[i].parentNode.className = "radio";
				inputs[i].parentNode.style.backgroundPosition = "0 0";
            }
        }
    }
}



</script>