var highlightCSS = "background: #739B4E; color: highlighttext";
var offset = 1;
if(document.all){
        offset = 0;
}
var expanded = false;

function selectOnKeydown(evt){
    var keyCode;
    var ret = true;
    if(window.event){
        keyCode = evt.keyCode;
  }else if(evt.which){
        keyCode = evt.which;
  }
    switch(keyCode){
        case 38:
            //alert("UP KEY");
            handleDownKey(evt,"");
            ret = false;
            break;
        case 40:
            handleDownKey(evt, "UP");
            //alert("DOWN KEY"); 
            ret = false;
            break;
        //case 27:
            //alert("ESC KEY");
         //   break;
        //case 13:
            //alert("Enter KEY");
            //ret = false;
         //   break;
        case 32:
            //alert("Space KEY");
            viewDropDown(evt);
            ret = false;
            break;
        default:
            searchCombo(evt, String.fromCharCode(keyCode));
            break;
    }
    return ret;
}

//==================
function getClassName(el_nd){
	var ret = "";
	try{
		if(document.all){
			ret = el_nd.className;
		}else{
			ret = el_nd.getAttribute("class");
			if(ret==null){
				ret = "";
			}
		}
	}catch(e){}	
	return ret;
}
function searchCombo(evt, ch){
    var node;
    var sourceElem;    
    if(!document.all){
        node = evt.target;
        while(node.nodeType != node.ELEMENT_NODE){
            node = node.parentNode;
        }
        sourceElem = node;
    }else{
        node = evt.srcElement;
    }    
    while(node.nodeName!="TABLE"){
        node = node.parentNode;
    }
    var selectSpanNode = node.parentNode;
    var selectedIndex = findSelected(selectSpanNode);
    options = getOptionDiv(selectSpanNode).childNodes;    
    cl = options[selectedIndex].getAttribute("value").toUpperCase();    
    if(cl.indexOf(ch)==0){
        //get the next option and check if it starts with the seach char        
        if((selectedIndex) < (options.length-1)){
            cl = options[selectedIndex+1].getAttribute("value").toUpperCase();
            if(cl.indexOf(ch)==0){
                highlightSelected(selectSpanNode, false);
                options[selectedIndex].removeAttribute("selected");
                options[selectedIndex+1].setAttribute("selected",1);
                copySelected(selectSpanNode);
                highlightSelected(selectSpanNode, true);
                options[selectedIndex+1].scrollIntoView(false);
            }
        }else{
        
            //iterate each option and check the start chars match
        for(var optIdx = 0; optIdx<options.length; optIdx++){
            if(options[optIdx].nodeName =="DIV"){
	            cl = options[optIdx].getAttribute("value").toUpperCase();
	            if(cl.indexOf(ch)==0){
	                highlightSelected(selectSpanNode, false);
	                options[selectedIndex].removeAttribute("selected");
	                options[optIdx].setAttribute("selected",1);                
	                copySelected(selectSpanNode);
	                highlightSelected(selectSpanNode, true);
	                options[optIdx].scrollIntoView(false);
	                break;
	            }
            }
        }       
        }
        
    }else{
        //iterate each option and check the start chars match
        for(var optIdx = 0; optIdx<options.length; optIdx++){
            if(options[optIdx].nodeName =="DIV"){
	            cl = options[optIdx].getAttribute("value").toUpperCase();
	            if(cl.indexOf(ch)==0){
	                highlightSelected(selectSpanNode, false);
	                options[selectedIndex].removeAttribute("selected");               
	                options[optIdx].setAttribute("selected",1);                
	                copySelected(selectSpanNode);
	                highlightSelected(selectSpanNode, true);
	                options[optIdx].scrollIntoView(false);
	                break;
	            }
            }
        }        
    }
}

function optionClick(evt) {
	
	var el;
    if(document.all){
        el = getReal(evt.srcElement, "className", "option");
    }else{
        el = getReal(evt.target, "className", "option");
    }
    
	if (getClassName(el) == "option") {
		dropdown  = el.parentNode;
		selectBox = dropdown.parentNode;
		
		oldSelected = dropdown.childNodes[findSelected(selectBox)]

		if(oldSelected != el) {
			oldSelected.removeAttribute("selected");
			el.setAttribute("selected", 1);
			el.scrollIntoView(false);
			selectBox.selectedIndex = findSelected(selectBox);
		}
				
		if (el.backupCss != null)
			el.style.cssText = el.backupCss;
		copySelected(selectBox);		
		highlightSelected(selectBox, true);		
		toggleDropDown(dropdown);
		//var inp = lookupNode(selectBox.childNodes[0],"INPUT");		
		//if(inp.onchange){		
		//	inp.onchange();
		//}              
     }	
}

function optionOver(evt) {
	var toEl;
	var fromEl;
    
    if(window.event != null){
        toEl = getReal(window.event.toElement, "className", "option");
        fromEl = getReal(window.event.fromElement, "className", "option");
    }else{
        toEl = getReal(evt.target, "className", "option");
        fromEl = getReal(evt.relatedTarget, "className", "option");
    }
    
	if (toEl == fromEl) return;
	var el = toEl;
	
	if (getClassName(el) == "option") {
		if (el.backupCss == null){
			el.backupCss = el.style.cssText;
        }
		highlightSelected(el.parentNode.parentNode, false);
		el.style.cssText = el.backupCss + "; " + highlightCSS;
		this.highlighted = true;
	}    
    
}

function optionOut(evt) {
    var toEl;
	var fromEl;
    
    if(window.event != null){
        toEl = getReal(window.event.toElement, "className", "option");
        fromEl = getReal(window.event.fromElement, "className", "option");
    }else{
        toEl = getReal(evt.relatedTarget, "className", "option");
        fromEl = getReal(evt.target, "className", "option");
    }    
    
	if (fromEl == fromEl.parentNode.childNodes[findSelected(fromEl.parentNode.parentNode)]) {		
        if (toEl == null)
			return;
		if (getClassName(toEl) != "option")
			return;
	}
	
	if (toEl != null) {        
		if (getClassName(toEl) != "option") {            
			if (getClassName(fromEl) == "option")                
				highlightSelected(fromEl.parentNode.parentNode, true);
		}
	}
	
	if (toEl == fromEl) return;
	var el = fromEl;    
	if (getClassName(el) == "option") {        
		if (el.backupCss != null){
			el.style.cssText = el.backupCss;            
        }
	}
}


function highlightSelected(el,add) {
	//if(!expanded) return;
	var selectedIndex = findSelected(el);	
	selected = getOptionDiv(el).childNodes[selectedIndex];        
	if (add) {
		if (selected.backupCss == undefined)
			selected.backupCss = selected.style.cssText;
		selected.style.cssText = selected.backupCss + "; " + highlightCSS;        
	}
	else if (!add) {
		if (selected.backupCss != undefined)
			selected.style.cssText = selected.backupCss;            
	}
}

function getReal(el, type, value) {
	temp = el;
	try {
		while ((temp != null) && (temp.nodeName != "BODY")) {
			if (eval("temp." + type) == value) {
				el = temp;
				return el;
			}
			temp = temp.parentElement;
		}
	}catch (e){}
	return el;
}

function getOptionDiv(el){
    for(var x=0;x<el.childNodes.length;x++){
        if(el.childNodes[x].nodeName=="DIV"){
            return el.childNodes[x];
        }
    }
    return el;
}
function findSelected(el) {
	var selected = null;    
            ec = getOptionDiv(el).childNodes;        
            for (var i=0; i<ec.length; i++){                                
                if(ec[i].nodeName=="DIV"){
                    if (ec[i].getAttribute("selected") != null) {
                        if (selected == null) {
                            selected = i;
                        }else{
                            ec[i].removeAttribute("selected");
                        }
                    }
                }
            }        
	if (selected == null)
		selected = 0;    
	return selected;
}
function lookupNode(nd, name){
    nod = nd;
    for(var idx=0;idx<nd.childNodes.length;idx++){
        if(nd.childNodes[idx].nodeName==name){
            return nd.childNodes[idx];
        }else{
            lookUP = lookupNode(nd.childNodes[idx], name);
            if(lookUP!=null){
                return lookUP;
            }
        }
    }
    return null;
}
function changeInputValues(inp, v_value, v_id){
	inp.value = v_value;
	inp.nextSibling.nextSibling.value = v_id;
	if(inp.onchange){		
		inp.onchange();
	}
}
function copySelected(el) {
	var selectedIndex = findSelected(el);
	var selectedND = getOptionDiv(el).childNodes[selectedIndex];
    var inp = lookupNode(el.childNodes[0],"INPUT");
    if(inp!=null){
        //inp.setAttribute("value", selectedND.getAttribute("value"));
        //inp.value = selectedND.getAttribute("value");
        //copy the id to the hidden
        //inp.nextSibling.nextSibling.setAttribute("value", selectedND.getAttribute("id"));
        //inp.nextSibling.nextSibling.value = selectedND.getAttribute("id");
        changeInputValues(inp, selectedND.getAttribute("value"), selectedND.getAttribute("id"));
    }
}
function handleDownKey(evt, dir){
    var node;
    var sourceElem;
    if(!document.all){
        node = evt.target;
        while(node.nodeType != node.ELEMENT_NODE){
            node = node.parentNode;
        }
        sourceElem = node;
    }else{
        node = evt.srcElement;
    }    
    while(node.nodeName!="TABLE"){
        node = node.parentNode;
    }
    
    var selectSpanNode = node.parentNode;
    var selectedIndex = findSelected(selectSpanNode);
    highlightSelected(selectSpanNode, false);
    getOptionDiv(selectSpanNode).childNodes[selectedIndex].removeAttribute("selected");    
    if("UP" == dir){
        selectedIndex++;
        if(selectedIndex > (getOptionDiv(selectSpanNode).childNodes.length - 1) ){    
            selectedIndex = 0;
        }
    }else{
            selectedIndex--;
        if(selectedIndex < 0){
            selectedIndex = getOptionDiv(selectSpanNode).childNodes.length - 1;
        }
    }
    var selectedDiv = getOptionDiv(selectSpanNode).childNodes[selectedIndex];
    selectedDiv.setAttribute("selected",1);    
    var val = selectedDiv.getAttribute("value");
    var val_id = selectedDiv.getAttribute("id");
    selectedDiv.scrollIntoView(false); 
    if(document.all){
        //evt.srcElement.value = val;
        changeInputValues(evt.srcElement, val, val_id);
    }else{
        //sourceElem.setAttribute("value",val);
        //sourceElem.value=val;
        changeInputValues(sourceElem, val, val_id);
    }
    highlightSelected(selectSpanNode, true);
}

//=================================
function viewDropDown(evt){

	if(!document.all){
        node = evt.target;
        while(node.nodeType != node.ELEMENT_NODE){
            node = node.parentNode;
        }
        sourceElem = node;
    }else{
        node = evt.srcElement;
    }    
    while(node.nodeName!="TABLE"){
        node = node.parentNode;
    }
    var inp = lookupNode(node,"INPUT");
    var selectSpanNode = node.parentNode;	
	toggleDropDown(node.nextSibling);
	highlightSelected(selectSpanNode, true);
	var selectedIndex = findSelected(selectSpanNode);
	var optionDIV = getOptionDiv(selectSpanNode);
	optionDIV.childNodes[selectedIndex].scrollIntoView(false);
	if(inp.select){
		inp.select();
	}
}
//=================================
function toggleDropDown(el) {        
	//if (getClassName(el) == "dropdown") {
		var dropDown = el;		
		if (dropDown.style.display == "")
			dropDown.style.display="none";
			
		if (dropDown.style.display=="none")
			showDropDown(dropDown);
		else
			hideDropDown(dropDown);
	//}	
}

function hideDropDown(el) {
	if (typeof(fade) == "function")
		fade(el, false);
	else
		el.style.display="none";
	expanded = false;
	expandedOptionND = null;
}

function showDropDown(el) {
	if (typeof(fade) == "function")
		fade(el, true);
	else if (typeof(swipe) == "function")
		swipe(el, 2);
	else
		el.style.display="block";
	expanded = true;
	if(expandedOptionND!=undefined){
		hideDropDown(expandedOptionND);
	}
	expandedOptionND = el;
}

var expandedOptionND;

function click(e) {
	var clickedElement;
	if (document.all){			
		clickedElement = event.srcElement.className;
    }else{
        clickedElement = e.target.getAttribute("class");
	}	
	if("inputRightCombo" != clickedElement &&
		"dropdown" != clickedElement &&
		"option" != clickedElement ){
		if(expandedOptionND!=null){
			hideDropDown(expandedOptionND);
		}
	}
	return true;
}

if (document.captureEvents) {	
	document.captureEvents(Event.MOUSEDOWN);
}
document.onmousedown=click;
