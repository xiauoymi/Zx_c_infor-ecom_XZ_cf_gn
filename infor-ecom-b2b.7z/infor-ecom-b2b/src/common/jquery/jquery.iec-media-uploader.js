/*
 *  jQuery IEC Media Uploader Plugin
 * 
 * 
 */


(function( $ ) {

  $.widget( "iec.mediaUploader", {
 
    // These options will be used as defaults
    options: { 
      clear: null,
	  'handler' : 'MediaUploaderDefaultHandler.jsp',
	  'entity' : 'mediaUpload'
    },
 
    // Set up the widget
    _create: function() {
		//Convert 'options.tag' to array/json
		this._convertOptionTags();
		
		//Load media uploader wireframe
		if(!$('.mediaUploader', this.element).length) {
			this._initMediaUploader();
		}
    },
	
    // Use the _setOption method to respond to changes to options
    _setOption: function( key, value ) {
		//TODO: Add handling here, if needed
    },
	
	_initMediaUploader : function() {
		var thisPlugin = this;
		$.post(this.options.handler, // + '?' + gCsrfTokenUrlParam, //TODO: Add CSRF Token
			this.options,
			function(response) {
				$(thisPlugin.element).html(response);
				//Init View Type buttons
				thisPlugin._initViewTypeButtons();
				//Init Dialog
				thisPlugin._initMediaUploadDialog();
				//Init Upload Button
				thisPlugin._initUploadButton();
				thisPlugin._initDeleteAllButton();
				//Load media list
				thisPlugin.runOnLoad();
				//Init File Uploader
				thisPlugin._initFileUploader();
				//Init Add Links dialog
				thisPlugin._initAddLinksDialog();
				thisPlugin._initHelpButton();
			}
		);
	},
	
	_initViewTypeButtons : function() {	
		var thisPlugin = this;
		$('.viewTypeButtons', thisPlugin.element).buttonset();
		$('.viewTypeButtons input', thisPlugin.element).each(function() {
			var $btn = $(this);
			var isGroup = $btn.is('.groupBtn');
			var $target = $('.' + $btn.data('target'));
			if(isGroup) {
				$btn
				.click(function() {
					$('.group', $target).each(function() {
						var $group = $(this);
						if($group.children('.entry').length > 1) {
							$group.addClass('groupMutilple');
						} else {
							$group.removeClass('groupMutilple');
						}
					});
				});
			} else {
				$btn
				.click(function() {
					$('.group', $target).each(function() {
						var $group = $(this);
						$group.removeClass('groupMutilple');
					});
				});
			}
		});
	},
	
	_initMediaListEntries: function(elem) {
		var $elem = $(elem);			
		//Init Preview buttons
		this._initPreviewButtons($elem);
		//Init Delete buttons
		this._initDeleteButtons($elem);
		//Fade-in/show entries
		$('.fade', $elem).fadeIn(800);
	},
	
	_initMediaUploadDialog : function() {
		var thisPlugin = this;
		var cancelText = $('.mediaUploaderCancelButton', thisPlugin.element).first().text();
		var applyText = $('.mediaUploaderApplyButton', thisPlugin.element).first().text();

		$('.mediaUploaderDialog', thisPlugin.element).dialog({
			autoOpen: false,
			width: 800,
			height: 500,
			modal: true,
			position: ['center', 'center'],
			closeOnEscape: false,
			closeText : thisPlugin.options.closeText,
			buttons: [
				{
					text: cancelText,
					click: function() {
						$(this).dialog('close');
					} 
				}, 
				{
					text: applyText,
					click: function() {
						var entries = $('#fileupload .files .groupUploaded');
						var mediaList = thisPlugin._generateMediaList(entries);
						//invoke callback method
						thisPlugin.runOnSuccess(mediaList);
						$(this).dialog('close');						
						//Remove active state of View Type button
						$('.mediaUploader .viewTypeButtons').find('.ui-state-active').removeClass('ui-state-active');
					} 
				}
			],
			beforeClose: function( event, ui ) {
				//return confirm('Are you sure to cancel?');
				$('.mediaUploaderHelpContent').hide();
			},
			appendTo: $('.mediaUploader', thisPlugin.element)
		});
		
	},
	
	_initHelpButton : function() {
		var thisPlugin = this;
		if (thisPlugin.options.helpMessage) {
			var helpText = $('.mediaUploaderHelpButton', thisPlugin.element).first().text();
			var $content = $('.mediaUploaderHelpContent').hide();
			$('.mediaUploaderHelpContent .content').html(thisPlugin.options.helpMessage);
			
			var $btn = $('<button type="button"></button>')
				.button({
					 icons: {
						 primary: "ui-icon-help"
					 },
					 label: helpText
				})
				.addClass('mediaHelpButton');
			
			$('.mediaUploader .ui-dialog-buttonpane').prepend(
				$('<div/>').addClass('ui-dialog-buttonset-left').append(
					$btn
				)
			);
			
			$btn.click(function(){
				if (!$content.is(":visible")) {
					var posLeft = $btn.offset().left + 10;
					var posTop = $btn.offset().top - 200;
					if($("div.ui-tabs.ui-widget").length!=0){
						posTop=$btn.offset().top-$("div.ui-tabs.ui-widget").offset().top-200;
					}
					$content.css({
									'top': posTop + 'px',
									'left': posLeft + 'px', 
									//'height':'160px', 
									//'width' :'500px', 
									'z-index':($('.mediaUploaderDialog').zIndex()+1)
								})
							.toggle('fold', {}, 700 );
					$('.mediaUploaderHelpContent').perfectScrollbar('update');
				} else {
					$content.toggle('fold', {}, 700 );
				}
			});
			$('.mediaUploaderHelpContent').perfectScrollbar();
		}
	},

	_initUploadButton : function() {
		$('.mainButtons .uploadButton', this.element)
			.button()
			.click(function() {
				var $dialogElem = $(this).parents('.mediaUploader').find('.mediaUploaderDialog');
				$('.files', $dialogElem).html('');
				$('.dragDropMessage', $dialogElem).show();
				$dialogElem.dialog('open');
			});
	},
	
	_initDeleteAllButton : function() {
		var thisPlugin = this;
		$('.mainButtons .deleteAllButton', this.element)
			.button()
			.click(function() {
				$('.delete', thisPlugin.element).click();
			});
	},
	
	_initFileUploader : function() {
		var thisPlugin = this;
		// Initialize the jQuery File Upload widget:
		$('#fileupload', thisPlugin.element).fileupload({
			url: 'MediaUploaderUploadFile.jsp?entity=' + thisPlugin.options.entity,
			dropZone: $('.mediaUploaderDialog'),
			previewMaxWidth: 145,
			previewMaxHeight: 125,
			send: function(e, data) {
				var ctx = $(data.context[0]);
				ctx.find('.progress').show();
			}			
		}).bind('fileuploaddone', function (e, data) {
			setTimeout(function() {
				thisPlugin._initUploadedMediaEntry($(data.context[0]));
			}, 2000);
		}).bind('fileuploadadd', function (e, data) {
			$('.dragDropMessage', thisPlugin.element).hide();
		});

		//Make upload canvas droppable
		$('.uploadCanvas', this.element).droppable({
			accept: ".groupMutilple .entryUploaded",
			activeClass: "highlightTargetGroup",
			drop: function( event, ui ) {
				//console.log('Dropped to canvas:' + ui.draggable );
				var $entry = $(ui.draggable[0]);
				var filesHolfer = $('.uploadCanvas ul.files');
				filesHolfer.append(tmpl('template-download', {files: []}));
				var $newGroup = $('.group:last-child', filesHolfer);
				$newGroup.droppable({
					accept: ".entryUploaded",
					obstacle: "#butNotHere",
					activeClass: "highlightTargetGroup",
					drop: function( event, ui ) {
						//console.log('Dropped:' + ui.draggable );
						thisPlugin._moveMediaEntry(ui.draggable[0], this);
					}
				});
				thisPlugin._moveMediaEntry($entry, $newGroup);
				thisPlugin._initMediaListEntries($newGroup);
				$newGroup.fadeIn(800);
			}
		});

		//Disable browsers drag and drop functionality
		$(document).bind('drop dragover', function (e) {
			e.preventDefault();
		});
		
		//Init Add Links button
		thisPlugin._initAddLinksButtons(thisPlugin.element);
	},
	
	_initUploadedMediaEntry : function(entryGroup) {
		var thisPlugin = this;
		var $entryGroup = $(entryGroup);
		$entry = $entryGroup.find('.entry');
		
		//init Preview button
		//thisPlugin._initPreviewButtons($entryGroup);
		
		
		//init tag list
		thisPlugin._initTagList($entry);
		
		
		//move to existing group
		/*
		var groupId = $entryGroup.attr('id');
		var $target = $('.uploadCanvas .files').find('#' + groupId);
		if($target.length) {
			methods._moveMediaEntry.call($entryGroup, $entry, $target);
		}
		*/
		
		//make group droppable		
		$entryGroup.droppable({
			accept: ".entryUploaded",
			activeClass: "highlightTargetGroup",
			greedy: true,
			drop: function( event, ui ) {
				//console.log('Dropped:' + ui.draggable );
				thisPlugin._moveMediaEntry(ui.draggable[0], $entryGroup);
			}
		});
		
		//make entry draggable
		$entry.draggable({
			revert: "invalid", 
			containment: "body",
			helper: "clone",
			cursor: "move"
		});
		
		//make entry droppable as well		
		$entry.droppable({
			accept: ".entryUploaded",
			activeClass: "highlightTargetEntry",
			greedy: true,
			drop: function( event, ui ) {
				//console.log('Dropped:' + ui.draggable );
				var targetGroup = $(this).parent('.group');
				thisPlugin._moveMediaEntry(ui.draggable[0], targetGroup);
			}
		});
																														   
		return $entry;
	},
	
	_moveMediaEntry : function(entry, target) {
		var thisPlugin = this;
		var $entry = $(entry);
		var $target = $(target);
		var $entryGroup = $entry.parent();
		
		if(!$target.find($entry.context).length) {
			thisPlugin._updateColSpan($target, 1); 		// adjustment = 1, since 1 new entry will be moved to $target
			thisPlugin._updateColSpan($entryGroup, -2); 	// adjustment = -2, since 2 entries (including the clone) will be removed to $entryGroup
			$entry.fadeOut(300,function() {
				$entry.appendTo($target).fadeIn(300, function() {
						var targetEntryCnt = $target.find('.entry').length;
						if(targetEntryCnt > 1) {
							$target.addClass('groupMutilple');
						} else {
							$target.removeClass('groupMutilple');
							$target.data('colspan', 1);
						}
						
						var sourceEntryCnt = $entryGroup.find('.entry').length;
						if(sourceEntryCnt == 0) {
							$entryGroup.fadeOut();
							$entryGroup.remove();
						} else if (sourceEntryCnt == 1) {
							$entryGroup.removeClass('groupMutilple');
						}			
					}
				);
			});
			
			if($entry.data('group') != $target.attr('id')) {
				$entry.attr('data-group-new', $target.attr('id'));
			}
			
			//Remove active state of View Type button
			$('.mediaUploaderDialog .viewTypeButtons').find('.ui-state-active').removeClass('ui-state-active');	
		}
	},
	
	_generateMediaList : function(entries) {
		var mediaList = new Array();
		$(entries).each(function() {
			var group = new Object();
			var files = new Array();
			
			if($(this).is('.entry')) {
				var file = new Object();
				
				var $data = $(this).data();
				file.id = $(this).attr('id');
				file.group = $data.group;
				file.name = $data.entryName;
				file.tag = $data.tag;
				file.language = $data.lang;
				file.type = $data.type;
				
				//Add image URL
				var img = $('.previewImg', this);
				if(img) {
					file.url = img.data().url;
				}
				
				group.name = $data.group;;
				
				//Add to array
				files.push(file);
			} else {
				var groupId = $(this).attr('id').replace('group_', '');
				group.name = groupId;
				
				$('.entry', this).each(function() {
					var file = new Object();
					var $data = $(this).data();
					file.group = $data.group;
					file.id = null;
					file.name = $data.entryName;
					file.tag = $data.tag;
					file.language = $data.lang;
					file.type = $data.type;
					
					//Add image URL
					var img = $('.previewImg', this);
					if(img) {
						file.url = img.data().url;
					}
					
					//Add to array
					files.push(file);
				});
			}
			group.files = files;
			mediaList.push(group);
		});
		//console.log('JSON mediaList: ' + JSON.stringify(mediaList));
		return mediaList;
	},
	
	_initTagList : function(entry) {
		var thisPlugin = this;
		if(thisPlugin.options.tags != null) {
			$('.tag', entry).each(function() {
				$(this).autocomplete({
					 source: function (request, response) {
						response($.ui.autocomplete.filter(thisPlugin.options.tags, request.term));
					},
					select: function (event, ui) {
						var option = ui.item;
						$(this).val(option.label);
						$(entry).attr('data-tag', option.value);
						$(entry).data('tag', option.value);
						return false;
					}, 
					change: function( event, ui ) {
						if (ui.item == null) {
							if(thisPlugin.options.customTagEnabled) {
								var customTag = $(this).val();
								$(entry).attr('data-tag', customTag);
								$(entry).data('tag', customTag);
								thisPlugin.options.tags.push(customTag);
							} else {
								var defaultTag = thisPlugin.options.defaultTag;
								if(thisPlugin.options.isMapTags) {
									$(this).val(thisPlugin.options.tagsMap[defaultTag]);
								} else {
									$(this).val(defaultTag);
								}
								$(entry).attr('data-tag', defaultTag);
								$(entry).data('tag', defaultTag);
							}
							return false;
						}
					},
					minLength: 0
				}).on("click", function () {
					$(this).autocomplete("search", '');
				});
				
				//set default tag
				var entryTag = entry.data().tag;
				if(thisPlugin.options.isMapTags) {
					if(!thisPlugin.options.tagsMap[entryTag]) { //if not in the options, then use default tag
						entryTag = thisPlugin.options.defaultTag;
					}
					$(this).val(thisPlugin.options.tagsMap[entryTag]);
				} else {
					if($.inArray(entryTag, thisPlugin.options.tags) == -1) { //if not in the options, then use default tag
						entryTag = thisPlugin.options.defaultTag;
					}
					$(this).val(entryTag);
				}
				$(entry).attr('data-tag', entryTag);
				$(entry).data('tag', entryTag);
			}).show();
		} 
	},
	
	_initPreviewButtons : function(elem) {
		var thisPlugin = this;
		elem.find('.preview')
		.button({
			icons: {
				primary: "ui-icon-zoomin"
			}
		}).click(function() {
			var $btn = $(this);
			var target = null;
			var index = 1;
			if($btn.is('.groupPreview')) {
				var targetGroup = $btn.parents('.group').first();
				var files = targetGroup.parents('.files');
				var firstElem = $('.entry', targetGroup).first();
				index = $('.entry', files).index(firstElem) + 1;
				target = $btn.closest('.group').closest('div');
			} else {
				target = $btn.parents('.entry');
				var files = target.parents('.files');
				index = $('.entry', files).index(target) + 1;
				target = files;
			}
			
			//Preview target
			if(target.length) {
				thisPlugin._previewEntries(target, index);
			}
			
		}).show();		
	},
	
	_initDeleteButtons : function(elem) {
		var thisPlugin = this;
		elem.find('.delete')
		.button({
			icons: {
				primary: "ui-icon-trash"
			}
		}).click(function() {
			var $btn = $(this);
			var target = null;
			var mediaList = null;
			if($btn.is('.groupDelete')) {
				target = $(this).parents('.group').first();
				mediaList = thisPlugin._generateMediaList($('.entry', target));
			} else {
				target = $(this).parents('.entry');
				//if(target.siblings('.entry').length <= 1) {
				if(thisPlugin.options.groupDeleteOnly == true && target.siblings('.entry').length >= 1) {
					target = target.parent('.group').first();
					mediaList = thisPlugin._generateMediaList($('.entry', target));
				} else {
					mediaList = thisPlugin._generateMediaList(target);
				}
			}
			
			//invoke callback 'data-on-delete' function here.. 
			var result = thisPlugin.runOnDelete(mediaList);
			
			if(result) {
				target.fadeOut(function() {
					$(this).remove();
				});
			} else {
				//TODO: display error message here...
				//console.log('Delete faild: ' + mediaList);
			}
		});		
	},
	
	_initAddLinksButtons : function(elem) {
		var thisPlugin = this;
		elem.find('.addLinks')
		.button({
			icons: {
				primary: "ui-icon-link"
			}
		})
		.click(function() {
			var dialog = $('.addLinksDialog', elem);
			$('textarea', dialog).val('');
			dialog.show();
		});
	},
	
	_initAddLinksDialog : function(elem) {
		var thisPlugin = this;
		var dialog = $('.addLinksDialog', elem);
		$('.closeButton', dialog)
		.button()
		.click(function() {
			dialog.hide();
		});
		
		$('.addLinksButton', dialog)
		.button()
		.click(function() {
			var links = $('textarea', dialog).val().split('\n');
			thisPlugin._addLinksAsEntries($('.mediaUploaderDialog .files', elem), links);
			dialog.hide();
		});
	},
	
	_addLinksAsEntries : function(holder, links) {
		if(links != null && links.length > 0) {
			var thisPlugin = this;
			$('.dragDropMessage', thisPlugin.element).hide();
			$.each(links, function(){
				var url = this;
				if(url != '') {
					var file = new Object();
					file.name = url;
					file.url = url;
					file.type = 'mediaUrl';
					file.group = null;
					file.id = null;
					file.tag = null;
					file.language = null;			
					var entryHtml = tmpl('template-download', {files: [file]});
					$(holder).append(entryHtml);
					var $newGroup = $('.group:last-child', $(holder));
					thisPlugin._initUploadedMediaEntry($newGroup);
					thisPlugin._initMediaListEntries($newGroup);
					$newGroup.fadeIn(800);
				}
			});
		}
	},
	
	_updateColSpan : function(elem, adjustment) {
		var $elem = $(elem);
		var entryCnt = $elem.find('.entry').length;
		if(adjustment) {
			entryCnt += adjustment; 
		}
		var newColSpan = calculateColSpan(entryCnt, 4);
		var currentColSpan = $elem.data('colspan');
		$elem.removeClass('colSpan' + currentColSpan);
		$elem.addClass('colSpan' + newColSpan);
		$elem.data('colspan', newColSpan);
	},
	
	_isFunction : function (name) {
		var obj = window[name];
		return $.isFunction(obj);
	},
	
	_convertOptionTags : function () {
		var tags = this.options.tags;
		if (tags != null) {
			var tagsArr = [];
			var tagsMap = {};
			
			$.each(tags.split(','), function(){
				tagsArr.push($.trim(this));
			});
			
			if(tagsArr.length > 0) {
				if(tags.indexOf(':') > 0) { //key-value pair
					var jsonObj = [];
					for (var i = 0; i < tagsArr.length; i++) {
						var option = tagsArr[i].split(':');
						jsonObj.push({value: option[0], label: option[1]});
						tagsMap[option[0]] = option[1];
					}
					this.options.tags = jsonObj;
					this.options.isMapTags = true;
					this.options.tagsMap = tagsMap;
				} else {
					this.options.isMapTags = false;
					this.options.tags = tagsArr;
				}
			}
		}
	},
	
	_previewEntries : function (entries, startIndex) {
		if(entries.length > 0) {
			
			var thisPlugin = this;
			var previewScreen = $('.previewScreen', thisPlugin.element);
			var previewScreenContent = $('.content', previewScreen);
			
			if(previewScreen) {
				previewScreenContent.html('');
				var slides = $('<ul/>').attr('id', 'slides');
				$('.entry', entries).clone().appendTo(slides);
				
				//wrap all entried with <li/>
				$('.entry', slides).wrap('<li/>');
				
				//Append slides to preview screen
				slides.appendTo(previewScreenContent);
				var imageCount=$(".previewImg",slides).length;
				//console.log(imageCount);
				//Display popup
				if($("div.ui-tabs.ui-widget").length!=0){
					previewScreen.bPopup({
						appendTo : $('.mediaList', thisPlugin.element),
						position:["auto",($("div.ui-tabs.ui-widget").offset().top-200)*-1]
					});
				}
				else{
					previewScreen.bPopup({
						appendTo : $('.mediaList', thisPlugin.element)
					});
				}
				//Convert to image rotator
				if(imageCount>1){
					$(slides).slidesjs({
						start: startIndex,
						width: 600,
						height: 400,
						navigation: {
						  effect: "fade"
						},
						pagination: {
						  effect: "fade"
						},
						effect: {
						  fade: {
							speed: 400
						  }
						}
					});
					}
					else{
						//disable pagination of slides
						$(slides).slidesjs({
							start: startIndex,
							width: 600,
							height: 400,
							navigation: {
								active: false
							},
							pagination: {
								active: false
							}
						});
						if(/(webkit)/.test(navigator.userAgent.toLowerCase())){
			              $(".slidesjs-slide").addClass('webkitBannerAlign');
			           	}
					}
			}
		}
	},

	runOnLoad : function() {
		var onLoad = this.options.onLoad;
		if(onLoad) {
			var mediaList = '';
			if(this._isFunction(onLoad)) { 
				mediaList = window[onLoad].call(this);
			}
		}
	},
	
	runOnSuccess: function(mediaList) {
		var thisPlugin = this;
		var onSuccess = this.options.onSuccess;
		if(onSuccess) {
			if(this._isFunction(onSuccess)) { 
				return window[onSuccess].call(this, mediaList);
				//TODO: Call _trigger() here...
			}				
		}
		return false;
	},
	
	runOnDelete: function(mediaList) {
		var thisPlugin = this;
		var onDelete = this.options.onDelete;
		if(onDelete) {
			if(this._isFunction(onDelete)) { 
				return window[onDelete].call(this, mediaList);
				//TODO: Call _trigger() here...
			}				
		}
		return false;
	},
	
	displayMediaList : function(mediaGroupList, fullReload, groupView) {
		var mediaListHolder = $('.mediaList', this.element);
		var fileHolder = mediaListHolder.find('.files');
		if(!fileHolder.length) {
			fileHolder = $('<ul/>').addClass('files');
		}
		
		if(fullReload) {
			fileHolder.html('');
		}
		
		$.each(mediaGroupList, function(index, groupObj){
			//Set view Type
			groupObj.view = 'mediaList';
			var groupsHtml = tmpl('template-download', groupObj);
			fileHolder.append(groupsHtml);
		});
		this._initMediaListEntries(fileHolder);
		fileHolder.appendTo(mediaListHolder);
		
		if (groupView == true) {
			$('.mediaUploader .viewTypeButtons .groupBtn', this.element).click();	
		} else if (groupView == false) {
			$('.mediaUploader .viewTypeButtons .ungroupBtn', this.element).click();
		} else if(fullReload) {
			//by defualt set to 'Ungroup'
			$('.mediaUploader .viewTypeButtons .ungroupBtn', this.element).click();
		}
	},
	
    // Use the destroy method to clean up any modifications your widget has made to the DOM
    destroy: function() {
      $.Widget.prototype.destroy.call( this );
    }

  });
  
}( jQuery ) );

//Global Funtions:
function calculateColSpan(entryCount, perGroup) {
	if(entryCount > perGroup) {
		var rem = entryCount % perGroup;
		var colSpan = (entryCount - rem) / perGroup;
		if(rem > 0) {
			colSpan++;
		}
		return colSpan;
	} else {
		return 1;
	}
}

jQuery.browser={};
(function(){
	jQuery.browser.msie=false;
	jQuery.browser.version=0;
	if(navigator.userAgent.match(/MSIE ([0-9]+)\./)){
		jQuery.browser.msie=true;jQuery.browser.version=RegExp.$1;
	}
})();

(function(){
	// Store a reference to the original remove method.
	var _origshow = $.fn.show;
	 
	// Define overriding method.
	jQuery.fn.show = function(){
		// Log the fact that we are calling our override.
		//console.log( "Override method" );
		//alert('' + $.browser.msie + ' ' + this.is('li.template-upload'));
		if ($.browser.msie && (this.is('li.template-upload') || this.is('li.template-download'))) {
			return _origshow.apply(this, arguments).css('display','inline');
		} else {
			// Execute the original method.
			return _origshow.apply(this, arguments);	
		}
	};
})();
