/*
 *  jQuery IEC Text Editor Plugin
 * 
 * 
 */

(function( $ ) {
$.widget( "iec.textEditor", {

	// These options will be used as defaults
	options: { 
	  clear: null,
	  previewlabel: 'Preview',
	  texteditorlabel: 'Text Editor',
	  cancellabel: 'Cancel',
	  donelabel: 'Done'
	},
 
	// Set up the widget
	_create: function() {
		if(!$('.textEditor', this.element).length) {
			this._addTextEditorDialogHolder();
			this._initTextEditor();
		}
	},
	
	// Use the _setOption method to respond to changes to options
	_setOption: function( key, value ) {
		//TODO: Add handling here, if needed
	},
	
	_initTextEditor: function() {
		var textarea = $(this.element);
		var textEditorContainer = textarea.parent();
		textEditorContainer.addClass('textEditorContainer');
		textarea.cleditor({ width: "280",
			height: "120",
				controls: ""
		});

		var editorPreview = $('<div class="textEditorPreview" />');
		textEditorContainer.append(editorPreview);
		
		this._addActionButtons(editorPreview);
	},
	
	_addActionButtons: function(editorPreview) {
		var thisPlugin = this;
		var buttonHolder = $('<div class="bottonHolder" />');
		var editBtn = $('<button />').button({
				 icons: {
					 primary: 'ui-icon-pencil'
				 },
				 label: thisPlugin.options.texteditorlabel,
				 text: false
			}).click(function(event) {
				event.preventDefault();
				var textarea = $(thisPlugin.element)
				thisPlugin._showTextEditorDialog(textarea);
			});		
		buttonHolder.append(editBtn);
		
		var previewBtn = $('<button />').button({
				 icons: {
					 primary: 'ui-icon-search'
				 },
				 label: thisPlugin.options.previewlabel,
				 text: false
			}).click(function(event) {
				event.preventDefault();
				window.open(thisPlugin.options.previewUrl + '&isPreview=true', 'TextEditorPreview');
			});
		buttonHolder.append(previewBtn);
		
		editorPreview.prepend(buttonHolder);
	},
	
	_showTextEditorDialog : function(textarea) {
		var thisPlugin = this;
		var SIZE_OFFSET = 50;
		var width = $(window).width() - SIZE_OFFSET;
		var height = $(window).height() - SIZE_OFFSET;
		var cEditor = null;
		var textEditorTextArea = $('#textEditorTextArea');
		textEditorTextArea.val(textarea.val());
		
		var textEditorDialog = $('#textEditorDialogHolder');
		textEditorDialog.dialog({
			title : thisPlugin.options.texteditorlabel,
			autoOpen: false,
			modal: true,
			width: width,
			height: height,
			buttons: [
				{
					text: thisPlugin.options.cancellabel,
					click: function() {
						$(this).dialog('close');
					} 
				},
				{
					text: thisPlugin.options.donelabel,
					click: function() {
						textarea.val(textEditorTextArea.val());
						var c = textarea.cleditor()[0].updateFrame();
						$(this).dialog('close');
						//textEditorTextArea.cleditor()[0].refresh();
					}
				}
			]
		});
		
		textEditorTextArea.cleditor()[0].updateFrame();
		//textEditorTextArea.cleditor()[0].refresh();
		textEditorDialog.dialog('open');
	},
	
	_addTextEditorDialogHolder : function() {
		if ($('#textEditorDialogHolder').length > 0) return;
		var editorDialogHolder = $('<div id="textEditorDialogHolder"></div>');
		editorDialogHolder.appendTo('body');
		editorDialogHolder.dialog({autoOpen: false});
		var textarea = $('<textarea id="textEditorTextArea"></textarea>');
		editorDialogHolder.append(textarea);
		
		var cEditor = textarea.cleditor({
			width: '100%',
			height: '100%',
			controls:     // controls to add to the toolbar
				"bold italic underline strikethrough subscript superscript | font size " +
				"style | color highlight removeformat | bullets numbering | outdent " +
				"indent | alignleft center alignright justify | undo redo | " +
				"image link unlink | cut copy paste pastetext | source",
			docLinkTags : '<link title="e-Sales Theme" href="../common/themes/core/theme.css" type="text/css" rel="stylesheet">'
		})[0];
		//return editorDialog;
	}
	
}); //END OF:  $.widget()
}(jQuery));
